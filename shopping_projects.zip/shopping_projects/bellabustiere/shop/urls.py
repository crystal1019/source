'''
@author: chaol
'''
from django.conf.urls.defaults import *


urlpatterns = patterns('',
    (r'^productlanding/(?P<code>.*).html$', 'bellabustiere.shop.views.product', {'type':'pop'}),
    (r'^productlanding/(?P<code>.*)/(?P<slug>.*).html$', 'bellabustiere.shop.views.product', {'type':'pop'}),
    (r'^product/(?P<code>.*)/(?P<slug>.*).html$', 'bellabustiere.shop.views.product'),
    (r'^voucher.html$','bellabustiere.shop.views.voucher'),
    (r'^quantitysummury.html$', 'bellabustiere.shop.views.quantitysummury'),
    (r'^shoppingbag.html$', 'bellabustiere.shop.views.shoppingbag'),
    (r'^featured.xml$', 'bellabustiere.shop.views.featuredxml'), # STEP 1
    (r'^cart.html$', 'bellabustiere.shop.views.cart'), # STEP 1
    (r'^checkout-billing.html$', 'bellabustiere.shop.views.checkoutbilling'), # STEP 2
    (r'^checkout-shipping.html$', 'bellabustiere.shop.views.checkoutshipping'), # STEP 2
    (r'^checkout-delivery.html$', 'bellabustiere.shop.views.checkoutdelivery'), # STEP 3
    (r'^checkout-payment.html$', 'bellabustiere.shop.views.checkoutpayment'), # STEP 4
   # (r'^confirm.html$', 'bellabustiere.shop.views.confirm'),
    (r'^checkout-final(?P<orderid>\d+).html$', 'bellabustiere.shop.views.checkoutsuccess'), # STEP 5
    (r'^addtocart.json$', 'bellabustiere.shop.views.addtocart'),
    (r'^cartsummary.json$', 'bellabustiere.shop.views.cartsummary'),
    (r'^calculateshipping.json$','bellabustiere.shop.views.calculateshipping'),
    url(r'^collections/$', 'mossandspy.shop.views.collections', name='collectionhome'),
    (r'^collections/(?P<slug>.*).html$', 'mossandspy.shop.views.collections', ),
    (r'^collections.json$', 'mossandspy.shop.views.collections', {'datatype':'json'}),
    (r'^(?P<nav>.*)/(?P<code>.*)/(?P<slug>.*).html$', 'bellabustiere.shop.views.category'),
    (r'^(?P<nav>.*)/(?P<code>.*).html$', 'bellabustiere.shop.views.category'),
    (r'^(?P<nav>.*)/$', 'bellabustiere.shop.views.category'),
    (r'^sizechart.html$', 'bellabustiere.website.views.sizechart'),
    (r'^$', 'bellabustiere.shop.views.home'),
  #  (r'^i/(?P<w>\d+)/(?P<h>\d+)/(?P<crop>\d)/(?P<path>.*)$', 'bellabustiere.shop.imageviews.imager'),
  #  (r'^i/(?P<w>\d+)/(?P<h>\d+)/(?P<path>.*)$', 'bellabustiere.shop.imageviews.imager'),
)
