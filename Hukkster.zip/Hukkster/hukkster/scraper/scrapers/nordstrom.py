#coding=utf-8
import logging
import re
import lxml.html
from urlparse import urljoin, urlparse
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions, HukksterTechnicalDifficulties


logger = logging.getLogger('scraper')


class NordStromScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'nordstrom.com'

    def clean_string2(self, val):
        try:
            val = self.clean_string(val)
            return val.replace(u'\xa0', ' ')
        except AttributeError:
            return val

    def _extract_float(self, root, xpath_expr, text_pattern, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(root, xpath_expr, is_expected_to_be_found)
        if node is not None:
            float_text = self.clean_string(node.text_content())
            m = re.search(text_pattern, float_text.encode("utf8"))
            if m:
                float_text = m.group(1).replace(",", "")
                float_value = float(float_text)
                return float_value
            else:
                if is_expected_to_be_found:
                    logging.debug("Error: Found no float value using %r" % xpath_expr)
                return None
        else:
            if is_expected_to_be_found:
                logging.debug("Error: Found no node using %r" % xpath_expr)
            return None

    def _expect_and_extract_single_node(self, root, xpath_expr, is_expected_to_be_found=True):
        nodes = root.xpath(xpath_expr)
        if len(nodes) == 0:
            if is_expected_to_be_found:
                logging.debug("Error: Unabled to find a node with xpath expression: %r" % xpath_expr)
            return None
        else:
            if len(nodes) > 1:
                logging.debug("Error: Found more than one node using %r" % xpath_expr)
            return nodes[0]

    def _expect_and_extract_single_node_text_content(self, root, xpath_expr, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(root, xpath_expr, is_expected_to_be_found=True)
        if node is not None:
            return node.text_content()
        else:
            return ""

    def _extract_img_url(self, root, xpath_expr):
        img_node = self._expect_and_extract_single_node(root, xpath_expr)
        if img_node is not None:
            return urljoin(self.url, img_node.attrib["src"])
        else:
            return ""

    def _extract_attr_value(self, root, xpath_expr):
        return self._expect_and_extract_single_node(root, xpath_expr)

    def _extract_value_using_regex(self, pattern, text):
        m = re.search(pattern, text)
        if m:
            return m.group(1)
        else:
            logging.debug("Error: Failed to extract value using pattern '%s'" % pattern)
            return None

    def _convertThumbnailToGigantic(self, thumbnail_url):
        parse_result = urlparse(thumbnail_url)
        # Check if the thumbnail url is expected. If not, there may be problems to check.
        matched_obj = re.search(r"\/imagegallery\/store\/product\/Thumbnail\/\d+\/.*\.jpg", parse_result.path)
        if matched_obj is None:
            logging.debug("Error: unexpected thumbnail url '%s'" % thumbnail_url)
        return thumbnail_url.replace("/Thumbnail/", "/Gigantic/")

    def parseProductInfosInJS(self):
        m = re.search(r'"availSkuCount"\:(\d+)', self.html)
        if m is not None:
            avail_prod_count = int(m.group(1))
        else:
            avail_prod_count = 0

        prod_texts = [m.group(0) for m in re.finditer(r'{("skuId"\:[^}]+)}', self.html)]
        prod_infos = []
        for prod_text in prod_texts:
            price_text = self._extract_value_using_regex(r'price"\:"[^\d]+([\d\,\.]+)', prod_text)
            if price_text is not None:
                price = float(price_text.replace(",", ""))
            else:
                logging.debug("Error: Failed to extract price in '%s'" % prod_text)
                raise HukksterTechnicalDifficulties

            m = re.search(r'thumbnail"\:"([^"]+)', prod_text)
            if m is not None:
                thumbnail_url = m.group(1)
                gigantic_url = self._convertThumbnailToGigantic(thumbnail_url)

            prod_infos.append(
                {
                    "selections": {
                        "size": re.search(r'size1Value"\:"([^"]+)', prod_text).group(1),
                        "color": re.search(r'dropDown2Value"\:"([^"]+)', prod_text).group(1),
                    },
                    "original_price": {"value": price},
                    "current_price": {"value": price},
                    "image": gigantic_url,
                }
            )
        if avail_prod_count != len(prod_infos):
            logging.debug("Error: The availSkuCount is %s, but there are only %s products found in the javascript." % (
            avail_prod_count, len(prod_infos)))
        return prod_infos

    def parse_products(self, root, raw_data):
        title = self._expect_and_extract_single_node_text_content(root, "//h1")
        local_id = self._extract_value_using_regex(r'div[^>]+id\="skuSelector"[^>]+styleId\="(\d+)"', 
                    self.html)
        prod_infos = self.parseProductInfosInJS()
        for prod_info in prod_infos:
            prod_info["local_id"] = local_id
            prod_info["title"] = title
            prod_info["url"] = raw_data["url"]
            prod_info["store"] = "nordstrom"
            prod_info["promos"] = []
        return prod_infos

    def parse(self):
        raw_data = self.parse_opengraph()

        # Parsing the HTML
        logging.debug('Parsing HTML data')
        encoding = "utf-8"
        root = lxml.html.fromstring(unicode(self.html, encoding))
        logging.debug('Finished parsing HTML data')

        products = self.parse_products(root, raw_data)

        # Giving up, it doesn't look as a product
        if products is None or not len(products):
            raise HukksterTooManyOptions(NordStromScraper.get_domain(), self.url)

        return products

