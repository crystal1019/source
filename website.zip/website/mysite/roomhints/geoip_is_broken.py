import simplejson as json
import subprocess

def geoip_hack(ip):
    p = subprocess.Popen('python /home/roomhints/devel/RH/website/mysite/roomhints/geoip_standalone.py ' + str(ip), shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    results = json.loads(out)
    return results
    
