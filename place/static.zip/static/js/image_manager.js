function ImageManager(options){
    var src = '/assets/image_manager/';
    Dialog.call(this, src, null, options);

    this.im_element = null;
    this.uploader = null;
    this.size = 'large';
    this.clickable = false;
    this.selectable = false;
    this.single_select = false;
    this.topic = null;


    utils.applyIf(this, options);

    // Ensure ok button is enabled style-wise
    $('#dialog-ok').removeClass('disabled');
}

ImageManager.prototype = new Dialog();
ImageManager.prototype.constructor = ImageManager;

ImageManager.prototype._bindEvents = function() {
    Dialog.prototype._bindEvents.call(this);
    var self = this;
    this.on('beforeshow', function(){
        self.parameters = {
            'clickable': self.clickable ? true : null,
            'selectable': self.selectable ? true : null,
            'topic'    : self.topic
        };
    });
    this.on('show', function(){
      self.im_element = $('#image-manager');
      self._uploader_setup();
    });

    this.on('close', function() {
        self._unbindEvents();
    });

    $(document).on('click', '#image-manager .thumbnail .delete', function() {
        self.deleteImage($(this).parents('li').eq(0));
    });

    $(document).on('click', '#image-manager li.selectable .thumbnail', function(){
        var elem = $(this).parents('li').eq(0);
        if (elem.hasClass('selected')) {
            elem.removeClass('selected');
        }
        else {
          if(self.single_select) {
            $('#image-manager li.selectable').removeClass('selected');
          }
          elem.addClass('selected');
        }
    });
};

ImageManager.prototype._unbindEvents = function() {
  Dialog.prototype._unbindEvents.call(this);
  $(document).off('click', '#image-manager .thumbnail .delete');
  $(document).off('click', '#image-manager li.selectable .thumbnail');
};

ImageManager.prototype._uploader_setup = function() {
    var self = this;
    this.uploader = new qq.FileUploader({
      element: $(self.im_element).find('.im-tool-section')[0],
      action: '/assets/image_upload/',
      params: this.parameters,
      debug: false,
      multiple: true,
      maxConnections: 5,
      allowedExtensions: ['jpeg', 'jpg', 'png', 'gif'],
      sizeLimit: 10485760,
      dragText: '<h4>Drop files here</h4>',
      uploadButtonText: 'Add more images by clicking or dropping files here.',
      showMessage: function(message) {
        // console.log(message);
      },
      onSubmit: function(id, fileName) {
        $('.im-tool-section').removeClass('default');
      },
      onComplete: function(id, fileName, responseJSON) {
        if (responseJSON.success) {
            self.addThumbnail(responseJSON.html);
            var item = this._getItemByFileId(id);
            $(item).delay(3000).fadeOut(1000, function() {
              $(item).remove();
              if ($('#image-manager .qq-upload-list li').length === 0) {
                $('#image-manager .im-tool-section').addClass('default');
              }
            });
        }
        else {

        }
      },
      template: '<div class="qq-uploader">' +
                  '<div class="qq-upload-button" style="width: auto;">{uploadButtonText}</div>' +
                  '<div class="qq-upload-drop-area">{dragText}</div>' +
                  '<div class="list"><ul class="qq-upload-list" style="margin-top: 10px; text-align: center;"></ul></div>' +
                '</div>',
      fileTemplate: '<li>' +
                  '<span class="qq-upload-finished"></span>' +
                  '<span class="qq-upload-file"></span>' +
                  '<span class="qq-upload-size"></span>' +
                  '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
                  '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
                  '<span class="qq-upload-spinner"></span>' +
                  '<div class="qq-progress-bar"></div>' +
                  '<div class="clear_both"></div>' +
                  '</li>'
    });
};

ImageManager.prototype.addThumbnail = function(html) {
    $('#image-manager .im-preview-section > .thumbnails').append(html);
};

ImageManager.prototype._makeClickable = function() {
  //$('#image-manager a.thumbnail').
};

ImageManager.prototype.deleteImage = function(element) {
    var self = this;
    var e = $(element);
    var img_id = e.data('asset');
    $.ajax({
        url: '/assets/delete_image/',
        type: 'post',
        data: {
            'id': e.data('asset'),
            'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
        },
        success: function(obj) {
            e.remove();
            self.fire('delete_image', obj.data.objects);
        },
        error: function(err) {
            //console.log(err);
        }
    });
};

ImageManager.prototype.selectedThumbnails = function() {
  return $('#image-manager li.selected');
};

/*

 END IMAGEMANAGER

*/

function ImageEditor(topic, asset, options){
    var src = '/assets/image_editor/';
    Dialog.call(this, src, null, options);

    this.ie_element = $('#image-editor');
    this.uploader = null;
    this.size = 'large';
    this.asset = asset;
    this.topic = topic;
    this.include_submit = false;
    this.aspect_ratio = 2.34;
    utils.applyIf(this, options);

    // Ensure ok button is enabled style-wise
    $('#dialog-ok').removeClass('disabled');
}

ImageEditor.prototype = new Dialog();
ImageEditor.prototype.constructor = ImageEditor;

ImageEditor.prototype._bindEvents = function() {
    Dialog.prototype._bindEvents.call(this);
    var self = this;
    
    this.on('beforeshow', function() {
        self.parameters = {
            'asset': self.asset,
            'topic': self.topic
        };
    });

    this.on('show', function(){
        self._initCroppingTool();
    });
};

ImageEditor.prototype._initCroppingTool = function() {
    var x_input   = $('#id_x');
    var y_input   = $('#id_y');
    var x2_input  = $('#id_x2');
    var y2_input  = $('#id_y2');
    var w_input   = $('#id_w');
    var h_input   = $('#id_h');

    var img = $('#image-editor .image');
    // Update the image crop inputs
    function updateForm(c) {
        x_input.val(c.x);
        y_input.val(c.y);
        x2_input.val(c.x2);
        y2_input.val(c.y2);
        w_input.val(c.w);
        h_input.val(c.h);
    }

    // Add jcrop tool to image.
      
    img.Jcrop({
        aspectRatio: this.aspect_ratio,
        boxHeight  : 300,
        setSelect  : [ 100, 100, 10, 10 ],
        bgOpacity  : 0.7,
        bgColor    : '#f1f1f1',
        onSelect   : updateForm,
        onChange   : updateForm
    });

    // Set inputs for image width and height values
    $('#id_scale_width').val(img.width());
    $('#id_scale_height').val(img.height());
};

ImageEditor.prototype.vals = function() {
  var data = {};
  $.each($('#image_editor_form').serializeArray(), function(_, kv) {
    data[kv.name] = kv.value;
  });
  return data;
};

