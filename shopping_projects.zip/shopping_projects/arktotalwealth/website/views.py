# Create your views here.
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.template import loader, RequestContext
import csv
from django.conf import settings
from arktotalwealth.website.models import *
from arktotalwealth import common
from arktotalwealth.website.forms import *
from haystack.views import SearchView, search_view_factory
from haystack.forms import SearchForm, HighlightedSearchForm
from haystack.query import SearchQuerySet
from django.template import RequestContext

class MySearchView(SearchView):
    def __name__(self):
        return "MySearchView"
    
    def extra_context(self):
        extra = super(MySearchView, self).extra_context()
        extra = common.commondict(extra)
        return extra

def search(request,uri):
    sqs = SearchQuerySet().highlight()
    return search_view_factory(view_class=MySearchView,form_class=SearchForm,template='search.html',searchqueryset=sqs)(request)




def export(request):
    link = ''
    t = loader.get_template('importemails.html')
    rp = request.POST
    if  rp.get("subscriptionexport"):   
        file = csv.writer(open(settings.CSV_EXPORT_ROOT,'wb'),delimiter=',')
        file.writerow(['first name', 'surname', 'email', 'phone', 'interest', 'comments'])
        enquiry = Enquiry.objects.all()
        for x in enquiry:
            file.writerow([x.first_name,x.surname,x.email,x.phone,x.interest,x.comments])
            
        link = "<a href='%s'>Download Here</a>" %settings.CSV_EXPORT_URL
    
    c = RequestContext(request, {'link':link})
    return HttpResponse(t.render(c))
        
        
def home(request):
    t = loader.get_template('index.html')
    jsbanner = ImagePlayer.objects.filter(in_js=True).order_by('-priority')
    try:
        page = MiscPage.objects.get(path='index',active=True)
    except:
        page = ''
        
    popform = 0
    if "messagepop" in request.GET:
        if request.GET['messagepop'] == 'popform':
            popform = 1
    c = RequestContext(request,common.commondict({'jsbanner':jsbanner,'page':page,"openpath": ["home",], 'popform':popform},request)) 
    return HttpResponse(t.render(c))

def catchall(request, path):
    form = ''
    msg = ''
    try:
        if path == 'email_enquiry.html':
            rp = request.POST.copy()
            if rp:
                try:
                    ip = request.META["HTTP_CF_CONNECTING_IP"] 
                except:
                    ip = request.META["REMOTE_ADDR"]
                rp['ip'] = ip
                form = EnquiryForm(rp)
                if form.is_valid():

            
                    check_spammer = SpammerList.objects.filter(ip=ip)
                    if not check_spammer:
                        uu = form.save()
                        msg = 'success'
                        form = EnquiryForm()
                        receivers = EmailReceiver.objects.filter(type='enquiry')
                        receivers = [x.email for x in receivers]
                        common.sendEmail(settings.EMAIL_FROM,receivers,'New Enquiry', 'email_enquiry.html', context=uu)
                        if uu.subscribed:
                            common.api_emarket(uu.get_xmlstring(), uu.email)
                    
            else:
                form = EnquiryForm()  
        
        
        page = MiscPage.objects.get(path=path, active=True)
        path = MiscPage.objects.get(path='contact.html') if page.in_contact else page
        topnav = MiscPage.objects.filter(in_contact = True, active=True).exclude(path='contact.html') if page.in_contact else ''
        
        
        t = loader.get_template('miscpage.html') if not page.in_contact else loader.get_template('page.html')
        
        c = RequestContext(request,common.commondict({'page':page, 'path':path, 'topnav':topnav, 'form':form, 'msg':msg}, request))
        return HttpResponse(t.render(c))
    except:
        try:
            if 'mediacenter/' in path:
                
                url = path.replace('mediacenter/', 'financial-advice/')
                return HttpResponseRedirect('/' + url)
                
            elif 'mediacentre/' in path:
                url = path.replace('mediacentre/', 'financial-advice/')
            
                return HttpResponseRedirect('/' + url)
            else:
                raise Http404
        except:
            raise Http404
    
def message(request):
    t = loader.get_template('message.html')
    rp = request.POST.copy()
    msg = ''
    if rp:
        try:
            ip = request.META["HTTP_CF_CONNECTING_IP"] 
        except:
            ip = request.META["REMOTE_ADDR"]
        rp['ip'] = ip
        form = MessageForm(rp)
        if form.is_valid():

    
            check_spammer = SpammerList.objects.filter(ip=ip)
            if not check_spammer:
                uu = form.save()
                msg = 'success'
                form = MessageForm()
                receivers = EmailReceiver.objects.filter(type='enquiry')
                receivers = [x.email for x in receivers]
                common.sendEmail(settings.EMAIL_FROM,receivers,'New Message', 'email_enquiry.html', context=uu)
                if uu.subscribed:
                    common.api_emarket(uu.get_xmlstring(), uu.email)
    else:
        form = MessageForm()
    
    c = RequestContext(request,common.commondict({'form':form,'msg':msg}, request))
    return HttpResponse(t.render(c))