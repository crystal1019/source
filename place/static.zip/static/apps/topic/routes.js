// topic_app.config(['$routeProvider', function($routeProvider, $location) {
//     $routeProvider
//         .when('/inputmap', {
//             // templateUrl: '/static/apps/topic/partials/inputmap.html',
//             // controller: 'InputMapCtrl'
//         })
       
//         // .otherwise({
//         //     redirectTo: '/team'
//         // });
//     }
// ]);