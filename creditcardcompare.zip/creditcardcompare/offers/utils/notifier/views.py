from django.conf import settings
from django.views.generic.edit import View
from django.shortcuts import render_to_response
from offers.helpers.boyd.mail import GenericMailThread


class Conversion(View):
    template_name = 'notifier/email.html'
    
    def get(self, request, *args, **kwargs):
        GenericMailThread(**{
            'email': settings.ADMINS[0][1] if settings.DEBUG else settings.ADMINS[1][1],
            'subject': '1 Conversion on %s' % settings.INTERNAL_LINK,
            'context': {'details': '1 conversion happened just right now!'},
            'template': self.template_name,
            'connection': None,  # remove this line to use Sendgrid
        }).start()
        return render_to_response(self.template_name, {})


class JSErrorView(View):
    template_name = 'notifier/email.html'
    
    def get(self, request, *args, **kwargs):
        GenericMailThread(**{
            'email': settings.ADMINS[0][1],
            'subject': 'Javascript Error Triggered!',
            'context': {
                    'details': request,
                    'remoteaddr': request.META.get('REMOTE_ADDR', ''),
                    'browser': request.META.get('HTTP_USER_AGENT', ''),
                    'is_mobile': request.session['is_mobile'],
                },
            'template': self.template_name,
        }).start()
        return render_to_response(self.template_name, {})
        