import re, threading
from django.conf import settings
from offers.helpers.template.loaders import _agent


class FormatBase:
    is_mobile = False
    
    def __init__(self, meta):
        self.meta = meta
        formatter = re.sub('[^A-z]', '', meta.meta_field.key.lower().replace(' ', '_'))
        if _agent.is_mobile:
            self.is_mobile = True
        try:
            self._data = getattr(self, formatter)()
        except AttributeError:
            self._data = (self.get_value(meta.key), )
    
    def __getitem__(self, index):
        try:
            return self._data[index]
        except IndexError:
            return
        
    def m(self, value, value_m):
        return value_m if self.is_mobile else value
        
    def get_value(self, key, field='value_or_default'):
        meta = self.meta.offer.metafield(key)
        try:
            return getattr(meta, field)
        except TypeError:
            if field is None:
                return meta
        except Exception:
            pass
        return '-' 