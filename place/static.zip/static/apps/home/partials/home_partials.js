angular.module('ProfileMenuApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('/static/apps/common/partials/topic_card.html',
    "<figure ng-repeat=\"topic in topics\" class=\"topic_box\" ng-class=\"topic.featured && highlight_featured ? 'featured':''\"><header ng-if=\"topic.featured && highlight_featured\">Featured topic</header><div class=\"inner\"><a ng-if=\"topic.image\" href=\"{{topic.url}}\"><img alt=\"\" role=\"presentation\" ng-src=\"{{topic.image|thumbnailexists}}\"><h4>{{topic.title}}</h4></a><h4 ng-if=\"!topic.image\"><a href=\"{{topic.url}}\">{{topic.title}}</a></h4><figcaption>By <a href=\"/explore/?q='{{ topic.organization }}'&amp;type=organization\">{{ topic.organization }}</a></figcaption><summary><p>{{topic.abstract}}</p></summary><section ng-if=\"topic.is_archived\"><p class=\"ftr_pin archived\">Archived</p></section><section><img alt=\"Category:\" class=\"card-icon\" role=\"heading\" ng-src=\"{{topic.categoryIcon}}\"> <span class=\"category\">{{topic.category | capitalize:true}}</span></section><section ng-if=\"topic.keywords\"><img alt=\"Tags:\" class=\"card-icon\" role=\"heading\" ng-src=\"/static/img/ico_tag.png\"> <span class=\"tags\"><a ng-repeat=\"keyword in topic.keywords\" href=\"/explore/?q=&quot;{{keyword}}&quot;&amp;type=tag\">{{keyword}}<span ng-if=\"!$last\">,</span></a></span></section></div></figure>"
  );

}]);
