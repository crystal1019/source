import masterpage

import method_db
import method_user
import method_comment
import method_url
	
class EditComment(masterpage.MasterPage):
	def post(self):
		#  Get logged in user
		user = method_user.getLoggedInUser()
		comment_id = method_url.getId(self)
		comment = method_comment.getCommentWithId(comment_id)
		
		is_allowed = False
		if method_user.userIsAdmin():
			is_allowed = True
		elif user and user.uid == comment.author_id:
			is_allowed = True
		if not is_allowed:
			self.redirect(method_url.getUrlForComment(comment))
			return
			
		if comment_id:
			delete_action = self.request.get('Delete')
			if delete_action:
				method_comment.deleteComment(comment)
			else:
				comment.text = self.request.get('text')
				if not comment.author_id and self.request.get('name'):
					comment.author_name = self.request.get('name')
				method_db.putObject(comment)
		method_comment.clearCache(comment)	
		method_db.refreshCommentCount(comment.ancestor_id, comment.type)
		ancestor = method_db.getObjectWithTypeAndId(comment.ancestor_id, comment.type)
		method_db.onObjectUpdated(ancestor)		
		self.redirect(method_url.getUrlForComment(comment))
	
	def get(self):
		if method_user.getLoggedInUser() is None:
			self.redirectToLogin()	
			return	
		comment_id = method_url.getId(self)
		comment = method_comment.getCommentWithId(comment_id)
		if not comment:
			self.response.out.write('comment is null')
			return
			#self.redirect(self.request.referer)		
		is_allowed = False
		user = method_user.getLoggedInUser()
		if method_user.userIsAdmin():
			is_allowed = True
		elif user and user.uid == comment.author_id:
			is_allowed = True
		if not is_allowed:
			self.redirect(method_url.getUrlForComment(comment))
			return	
		template_values = {
			'comment': comment,
		}		 
		
		self.pushPage(template_values, 'Edit Comment', 'html/editcomment.html')	  
		
