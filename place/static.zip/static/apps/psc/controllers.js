angular.module('psc.controllers', [])
    .controller('PSCCtrl', ["$scope", "$http", "$location", "$modal", "ClientData", "$q",
        function($scope, $http, $location, $modal, ClientData, $q) {
            $scope.ClientData = ClientData;
            $scope.$location = $location;
            $scope.psc_client = data.id;
            // Set map url in root scope.  This is set to MapData.url inside MapCtrl before map is loaded
            $scope.map_url = "/connect/admin/map/";
            $scope.dirty_tabs = {};
            $scope.is_dirty = false;
            $scope.invalid_tabs = [];
            $scope.map_tools_view = false;
            $scope.saving = false;
            $scope.save_success = false;
            $scope.save_fail = false;
            $scope.has_feature = function(ft){
            	if (ft === 'demo') {
            		return false;
            	}
            	return true;
            };
            $scope.toggle = function(help_sec) {
	            $scope.$broadcast('event:toggle', help_sec);
	        };
            $scope.safeApply = function(fn) {
                var phase = this.$root.$$phase;
                if (phase == '$apply' || phase == '$digest') {
                    if (fn) {
                        fn();
                    }
                } else {
                    this.$apply(fn);
                }
            };
            $scope.safeApply = function(fn) {
                var phase = this.$root.$$phase;
                if (phase == '$apply' || phase == '$digest') {
                    if (fn) {
                        fn();
                    }
                } else {
                    this.$apply(fn);
                }
            };
            $scope.save = function() {
                var tabs_saved = [];
                ////////////////////////////////////////////////////////////////////////////////////////////
                //
                // Each scope has an is_valid attr updated when form data changes
                // If not valid, add #/path value to error array so that tab can be highlighted
                //
                // If valid, call scope.save() which does any processing necessary, then calls *Service.save()
                //
                ////////////////////////////////////////////////////////////////////////////////////////////
                $scope.tabs_errors = [];
                var promises = []
                _.each($scope.dirty_tabs, function(scope, path) {
                    if (!scope.is_valid) {
                        if (!_.contains($scope.tabs_errors, path)) {
                            $scope.tabs_errors.push(path)
                        }
                    }
                });

                // Jump to 1st tab with error
                // Still need to mark all tabs that are errored
                if ($scope.tabs_errors.length > 0) {
                    $location.path($scope.tabs_errors[0]);
                    $scope.save_fail = true;
                }

                if($scope.tabs_errors.length === 0){
                    $scope.saving = true;
                    _.each($scope.dirty_tabs, function(scope, path) {
                        promises.push(scope.save());
                        tabs_saved.push(path)
                    });
                    $q.all(promises).then(function(data){
                        $scope.saving = false;
                        $scope.save_success = true;
                    });
                }
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //
                // Find forms in each scope that was successfully saved and set to $pristine so $watch works on them again.
                // Then delete from dirty tabs
                //
                // ** Form naming convention ** - form_formName
                //
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////
                _.each(tabs_saved, function(tab) {
                    _.each($scope.dirty_tabs[tab], function(val, key) {
                        if (key.match(/^form_/)) {
                            $scope.dirty_tabs[tab][key].$setPristine();
                        }
                    });
                    delete $scope.dirty_tabs[tab];
                });
                tabs_saved = [];
            }
            // $scope.$on('$routeChangeSuccess', function(){
            //     if (!$scope.ClientData.active) {
            //         $scope.ClientData.load($scope.psc_client);
            //     }
            // });
            $scope.$on("tabchange", function(e, tab, child_scope) {
                if (!_.has($scope.dirty_tabs, tab)) {
                    $scope.dirty_tabs[tab] = child_scope;
                }
            });
            $scope.$on("tabreset", function(e, tab) {
                if (_.has($scope.dirty_tabs, tab)) {
                    delete $scope.dirty_tabs[tab];
                }
            });
            $scope.$on("tabvalid", function(e, tab, is_valid) {
                var idx = $scope.invalid_tabs.indexOf(tab);
                if (!is_valid && idx === -1) {
                    $scope.invalid_tabs.push(tab);
                } else if (is_valid && idx > -1) {
                    $scope.invalid_tabs.splice($scope.invalid_tabs.indexOf(tab));
                }
            });
            // Track dirty and invalid tabs
            $scope.$watch(function() {
                return _.keys($scope.dirty_tabs).length + " " + $scope.invalid_tabs.length
            }, function(n, o) {
                if (_.keys($scope.dirty_tabs).length > 0 && $scope.invalid_tabs.length === 0) {
                    $scope.is_dirty = true;
                } else {
                    $scope.is_dirty = false;
                }
            });
            $scope.$watch("$location.path()", function(new_val) {
                $scope.current_tab = new_val;
            });
            // Save on ctrl+s
            $(window).keypress(function(event) {
                if (!(event.which == 115 && event.ctrlKey) && !(event.which == 19)) return true;
                $scope.save(); // Doesn't work. :|
                event.preventDefault();
                return false;
            });
        }
    ])
    .controller('SettingsPSCCtrl', ["$scope", "$http", "ClientData",
        function($scope, $http, ClientData) {
            $scope.ClientData = ClientData;
            $scope.is_valid = true;
            // Search for the models in a form and return
            // a list of model objects
            $scope.getFormModels = function(form_name) {
                var models = [];
                _.each($scope[form_name], function(v, k) {
                    if (_.has($scope[form_name][k], '$modelValue')) {
                        models.push($scope[form_name][k]);
                    }
                });
                return models;
            }
            // Basically looking for form_psc_settings to be available in the scope,
            // this watch should only run once
            var form_psc_settings_watcher = $scope.$watch("form_psc_settings", function() {
                if ($scope.ClientData.active) {
                    _.each($scope.ClientData.models.form_psc_settings, function(o) {
                        if (o.$invalid) {
                            if (!$scope.form_psc_settings.$dirty) {
                                $scope.form_psc_settings.$setDirty();
                            }
                            _.each($scope.form_psc_settings[o.$name].$error, function(v, k) {
                                if (v) {
                                    $scope.form_psc_settings[o.$name].$setValidity(k, false);
                                    $scope.form_psc_settings[o.$name].$dirty = true;
                                }
                            });
                        }
                    });
                }
                // Remove the watch
                form_psc_settings_watcher();
            });
            $scope.$watch("current_tab", function(n) {
                if (!$scope.ClientData.active) {
                    // Load data
                    $scope.ClientData.load($scope.psc_client).then(function(obj) {
                        // Capture models in the form
                        if (!_.has($scope.ClientData.models, 'form_psc_settings')) {
                            $scope.ClientData.models['form_psc_settings'] = $scope.getFormModels('form_psc_settings');
                        }
                    }, function(reason) {});
                }
            })
            $scope.save = function() {
                return $scope.ClientData.save();
            };
            $scope.$watch("form_psc_settings.$dirty + ' ' + form_psc_settings.$valid", function(n, o) {
                if (o !== n) {
                    $scope.is_valid = angular.copy($scope.form_psc_settings.$valid);
                    $scope.$emit("tabvalid", "/settings", $scope.form_psc_settings.$valid);
                    if ($scope.form_psc_settings.$dirty) {
                        $scope.$emit("tabchange", "/settings", $scope);
                        // Reset external validation errors
                        _.each(ClientData.ext_errors, function(v, k) {
                            $scope.form_psc_settings[k].$error.ext_validation_msgs = [];
                            $scope.form_psc_settings[k].$setValidity("ext_validation", true);
                        });
                    } else {
                        $scope.$emit("tabreset", "/settings");
                    }
                }
            });
            $scope.$watch("ClientData.ext_errors", function(n, o) {
                _.each(n, function(v, k) {
                    $scope.form_psc_settings[k].$error.ext_validation_msgs = [];
                    _.each(v, function(msg) {
                        $scope.form_psc_settings[k].$error.ext_validation_msgs.push(msg);
                    });
                    $scope.form_psc_settings[k].$setValidity("ext_validation", false);
                });
            });
        }
    ])
    .controller('TeamPSCCtrl', ["$scope", "$http", "$log", "TeamData",
        function($scope, $http, $log, TeamData) {
            $scope.TeamData = TeamData;
            $scope.is_valid = true;
            $scope.$watch("current_tab", function(n) {
                if (n == "/team") {
                    if (!TeamData.active) {
                        TeamData.load($scope.psc_client).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            tminvite_model = {
                first_name: "",
                last_name: "",
                email: ""
            };
            $scope.tminvite = angular.copy(tminvite_model);
            $scope.removeTeamMember = function(admin, type) {
                // id checks that object has been saved on the server previously, so we dont try
                // to delete something that doesn"t "exist" yet
                if (angular.isDefined(admin.id)) {
                    var change = {
                        "action": "remove",
                        "type": type,
                        "admin": angular.copy(admin)
                    };
                    $scope.TeamData.save_stack.push(change);
                } else {
                    // Removes unsent invite from being saved
                    $scope.TeamData.save_stack = _.reject($scope.TeamData.save_stack, function(obj) {
                        return obj.info.email === admin.email;
                    });
                }
                $scope.TeamData.store[type] = _.reject($scope.TeamData.store[type], function(obj) {
                    return obj === admin;
                });
                $scope.$emit("tabchange", "/team", $scope);
            };
            $scope.inviteTeamMember = function() {
                $scope.TeamData.store.team_invites.push(angular.copy($scope.tminvite));
                var invite = {
                    "action": "invite",
                    "info": angular.copy($scope.tminvite)
                }
                $scope.TeamData.save_stack.push(invite);
                $scope["invite_team_member_form"].$setPristine();
                $scope.tminvite = angular.copy(tminvite_model);
                $scope.$emit("tabchange", "/team", $scope);
            };
            $scope.save = function() {
                return $scope.TeamData.save();
            }
        }
    ])
    .controller('ReportsCtrl', ["$scope", "$http",
        function($scope, $http) {
            $scope.psc_client = data.id;
            $scope.connections = [];
            $scope.$watch("current_tab", function(n) {
                if (n == "/report") {
                    $http({
                        method: 'GET',
                        url: "/psc/admin/report/",
                        params: {
                            'id': $scope.psc_client
                        }
                    }).success(function(obj) {
                        if (obj.success) {
                            $scope.connections = obj.data.connections;
                        } else {
                            $scope.connections = [];
                        }
                    });
                }
            });
        }
    ]);