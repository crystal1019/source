from google.appengine.api import users
import masterpage

import method_user
import method_cache
import method_question
import method_forum

import logging

class Favorites(masterpage.MasterPage):
	def getQuestions(self, favorites):
		questions = []
		if favorites == None:
			return []
		for fav in favorites:
			q = method_question.getQuestionWithId(fav, True)
			if q:
				questions.append(q)
		return questions
	
	def getForumPosts(self, favorites):
		forums = []
		if favorites == None:
			return []
		for fav in favorites:
			f = method_forum.getForumPostWithId(fav)
			if f is not None:
				forums.append(f)
		return forums	
	
	def getAttributes(self, attributes):
		atts = []
		if attributes:
			for a in attributes:
				attribute = {}
				attribute['name'] = method_question.getAttributeNameWithPid(a)
				attribute['pretty_id'] = a
				atts.append(attribute)
		return atts

	def get(self):
		user = method_user.getLoggedInUser()
		if not user:
			self.redirectToLogin()
			return
			
		page_cache_key = 'user_favorites_html'
		user_html = method_cache.getObjectForTypeAndKey(page_cache_key, user.user.email())
		if not user_html:
			if not user:
				self.redirect(users.create_login_url(self.request.uri))
				return
				
			name = user.name
			favorites = method_user.getFavoritesForEmailAndId(user.user.email(), user.uid)
			favorite_attributes = method_user.getFavoriteAttributesForEmailAndId(user.user.email(), user.uid)
			favorite_forums = method_user.getFavoriteForumsForEmailAndId(user.user.email(), user.uid)
			favorite_users = method_user.getFavoriteUsersForEmailAndId(user.user.email(), user.uid)			
			attributes = self.getAttributes(favorite_attributes)
			questions = self.getQuestions(favorites)
			forums = self.getForumPosts(favorite_forums)
			users = method_user.getUsersInList(favorite_users)			
			
			template_values = {
				'name': name,
				'forum_all': user.favorite_forum_all,
				'questions': questions,
				'users': users,
				'forums': forums,
				'attributes': attributes
			}
			user_html = self.getBody(template_values, 'html/control-userfavorites.html')
			user_html = name.encode('utf-8') + '###TITLE###' + user_html
			method_cache.setObjectForTypeAndKey(page_cache_key, str(user.uid), user_html)
		
		parts = user_html.split('###TITLE###')
		title = parts[0]
		user_html = parts[1]			
						
		template_values = {}
		template_values['rendered_body'] = user_html
		self.pushPage(template_values, title, 'html/favorites.html')				