import os, random, shutil
from django.core import mail
from django.conf import settings
from django.test import TestCase


class TestEmailScanner(TestCase):
    def setUp(self):
        self.home = os.path.join(settings.MEDIA_ROOT, 'home')
        self.inboxes = []
        self.replicate_postfix_directory()
        
    def test_can_search_all_inbox(self):
        from django.core.management import call_command
        self.create_random_file()
        self.create_random_file()
        self.create_random_file()
        
        call_command('scanemails', homedir=self.home)
        self.assertEqual(len(mail.outbox), 3)
            
    def tearDown(self):
        shutil.rmtree(self.home)
        
    def create_random_file(self):
        maildir = random.choice(self.inboxes)
        f = open(os.path.join(maildir, 'mail'), 'w')
        f.write('')
        f.close()
    
    def replicate_postfix_directory(self):
        sample_users = ['andy.boyd',
                        'david.boyd',
                        'noel',
                        'team']
        sample_sites = ['moneychoices',
                        'creditcardcompare',
                        'broadbandcompare',
                        'savingup']
        new_mail_dir = '%(site_name)s/homes/%(username)s/Maildir/new'
        
        for site_name in sample_sites:
            for username in sample_users:
                mail_dir = new_mail_dir % {'site_name': site_name, 'username': username}
                try:
                    os.makedirs(os.path.join(self.home, mail_dir))
                except WindowsError:
                    pass
                self.inboxes.append(os.path.join(self.home, mail_dir))