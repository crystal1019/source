angular.module('activity.controllers', []).controller('LiveReportsCtrl', [
    '$scope', '$http', 'ConnectionReportData', 'PollReportData', 'DiscussionReportData', 'SurveyReportData', 'NoticeboardReportData', 'MapLayer',
    function($scope, $http, ConnectionReportData, PollReportData, DiscussionReportData, SurveyReportData, NoticeboardReportData, MapLayer) {

        //chart options
        $scope.chartOptions = {
            series: {
                lines: {
                    show: true
                },
                points: {
                    show: false
                }
            },
            colors: ["#cede4f", "#52b6c8"],
            legend: {
                noColumns: 2,
                container: $("#legend")
            },
            xaxis: {
                mode: "time",
                position: "bottom",
                axisLabel: 'Date',
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 14,
                axisLabelFontFamily: "'helveticaneuelt_stdregular', Arial, 'Helvetica Neue', Helvetica, sans-serif"
            },
            yaxis: {
                ticks: 10,
                min: 0,
                axisLabel: 'Count',
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 14,
                axisLabelFontFamily: 'Arial'
            },
            selection: {
                mode: "x"
            }
        };
        //set liveReportData to conntection data
        $scope.orderedlist = [];
        $scope.LiveReportData = ConnectionReportData;
        $scope.MapLayer = MapLayer;
        $scope.highlighted = null;
        $scope.filterType = "Day";
        $scope.dataSet = 'Connections';
        $scope.events_attached = false;
        $scope.highlight_from_table = false;
        $scope.createOrderedlist = function() {
            //create the ordered list and set total count
            $scope.orderedlist = [];
            //add elements to orderedlist
            _.each($scope.LiveReportData.store.ordered_labels, function(label) {
                //prevent duplicate entries in table
                var exists = _.find($scope.orderedlist, function(item) {
                    return item.name == label;
                });
                if (!exists) {
                    $scope.orderedlist.push({
                        name: label,
                        count: 0,
                        percent: null,
                        origColor: null
                    });
                }
            });
        };
        $scope.onLiveLoad = function() {
            //create the ordered list
            $scope.createOrderedlist();
            //loop to add total counts for each poly
            _.each($scope.LiveReportData.store.data_points, function(data_point) {
                _.each(data_point.labels, function(value, key) {
                    var item = _.find($scope.orderedlist, function(a) {
                        return a.name === key;
                    });
                    if (item) {
                        item.count += value;
                    }
                });
            });
            //copy ordered list into table
            $scope.LiveReportData.originaltable = angular.copy($scope.orderedlist);
            //get the percentages
            $scope.getPercentages();
            $scope.createMap();
        };
        $scope.createMap = function() {
            $scope.MapLayer.gmap = new GMap2('activity_map', {
                zoom: $scope.LiveReportData.store.map_zoom,
                center: new google.maps.LatLng($scope.LiveReportData.store.map_center[0], $scope.LiveReportData.store.map_center[1]),
                drawingControl: false
            });
            $scope.MapLayer.layer = new GPolygonLayer($scope.MapLayer.gmap, 'polygon');
            $scope.MapLayer.layer.loadEncodedPolygons($scope.LiveReportData.store.geo, true);
            if (!$scope.events_attached) {
                $scope.bindMapEvents();
            }
            $scope.updateMap();
        };
        $scope.bindMapEvents = function() {
            $scope.events_attached = true;
            $scope.MapLayer.layer.bind('mouse_in', function(label, table) {
                $scope.highlight_from_table = table;
                var features = _.reject($scope.MapLayer.layer.features, function(feat) {
                    return feat.label !== label;
                });

                _.each(features, function(ft) {
                    ft.setOptions({
                        fillColor: "#00FF00"
                    });
                    if (table) {
                        var bounds = ft.getBounds();
                        var boundCenter = bounds.getCenter();
                        var boundsNE = bounds.getNorthEast();
                        var boundsSW = bounds.getSouthWest();

                        var mapBounds = $scope.MapLayer.gmap.map.getBounds();

                        if (!mapBounds.contains(boundsNE) && !mapBounds.contains(boundsSW)) {
                            $scope.MapLayer.gmap.map.panTo(boundCenter);
                            $scope.MapLayer.gmap.map.fitBounds(bounds);
                        }
                    }
                });
                obj = _.find($scope.orderedlist, function(o) {
                    return o.name === label;
                });
                if (angular.isDefined(obj)) {
                    if (table) {
                        $scope.highlighted = obj;
                    } else {
                        $scope.$apply(function() {
                            $scope.highlighted = obj;
                        });
                    }
                }

            });
            $scope.MapLayer.layer.bind('mouse_out', function(label, origColor) {
                var features = _.reject($scope.MapLayer.layer.features, function(feat) {
                    return feat.label !== label;
                });
                _.each(features, function(ft) {
                    ft.setOptions({
                        fillColor: origColor
                    });
                });
                if (!$scope.$$phase) {
                    $scope.$apply(function() {
                        $scope.highlighted = null;
                    });
                }
            });
        };
        $scope.updateMap = function() {
            _.each($scope.MapLayer.layer.features, function(f) {
                obj = _.find($scope.orderedlist, function(o) {
                    return o.name === f.label;
                });
                if (angular.isDefined(obj)) {
                    pct = obj.percent;
                    if (pct === 0) {
                        f.setOptions({
                            'fillColor': '#5C5C5C',
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 1 && pct < 5) {
                        f.setOptions({
                            'fillColor': "#313695",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 5 && pct < 10) {
                        f.setOptions({
                            'fillColor': "#4575B4",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 10 && pct < 15) {
                        f.setOptions({
                            'fillColor': "#74ADD1",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 15 && pct < 20) {
                        f.setOptions({
                            'fillColor': "#ABD9E9",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 20 && pct < 25) {
                        f.setOptions({
                            'fillColor': "#E0F3F8",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 25 && pct < 30) {
                        f.setOptions({
                            'fillColor': "#FEE090",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 30 && pct < 35) {
                        f.setOptions({
                            'fillColor': "#FDAE61",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 35 && pct < 40) {
                        f.setOptions({
                            'fillColor': "#F46D43",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 40 && pct < 45) {
                        f.setOptions({
                            'fillColor': "#D73027",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    if (pct >= 45) {
                        f.setOptions({
                            'fillColor': "#A50026",
                            'strokeColor:': '#FFFFFF'
                        });
                    }
                    obj.origColor = f.fillColor;
                }
                google.maps.event.addListener(
                    f, 'mouseover', function() {
                        $scope.MapLayer.layer.trigger('mouse_in', f.label, false);
                    });
                var origColor = f.fillColor;
                google.maps.event.addListener(
                    f, 'mouseout', function() {
                        $scope.MapLayer.layer.trigger('mouse_out', f.label, obj.origColor);
                    });
            });
        };
        //switch to select each data type
        $scope.swapContent = function() {
            switch ($scope.dataSet) {
                case "Connections":
                    $scope.LiveReportData = ConnectionReportData;
                    break;
                case "Noticeboard":
                    $scope.LiveReportData = NoticeboardReportData;
                    break;
                case "Polls":
                    $scope.LiveReportData = PollReportData;
                    break;
                case "Survey":
                    $scope.LiveReportData = SurveyReportData;
                    break;
                case "Discussion":
                    $scope.LiveReportData = DiscussionReportData;
                    break;
            }

            //if the data is present load, create map and update chart
            if (!$scope.LiveReportData.active) {
                $scope.LiveReportData.load($scope.topic).then(function(obj) {
                    $scope.onLiveLoad();
                    $scope.createMap();
                    $scope.updateChart();
                }, function(reason) {});
            } else {
                $scope.onLiveLoad();
                $scope.createMap();
                $scope.updateChart();
            }
        };
        //reset the graph depending on the type of graph displayed
        $scope.resetGraph = function() {
            $scope.orderedlist = $scope.LiveReportData.originaltable;
            switch ($scope.filterType) {
                case "Day":
                    $scope.updateChart();
                    $scope.selectRange();
                    break;
                case "Week":
                    weekArray();
                    $scope.selectRange();
                    break;
                case "Month":
                    monthArray();
                    $scope.selectRange();
                    break;
            }
        };
        //filter the graph and plot the results
        $scope.filterGraph = function() {
            switch ($scope.filterType) {
                case "Day":
                    $scope.updateChart();
                    $scope.selectRange();
                    break;
                case "Week":
                    weekArray();
                    $scope.selectRange();
                    break;
                case "Month":
                    monthArray();
                    $scope.selectRange();
                    break;
            }
        };
        //create the week array
        function weekArray() {
            c = 0; //count for days
            weekCount = 0; //count for weeks
            highestPlot = 0; //var for highest plot
            //create week array
            arrayWeek = [{
                label: $scope.dataSet,
                data: []
            }];
            //loop to create an array with total counts for each week
            for (a = 0; a < arrayDay[0].data.length; a++) {
                if (c == 7) {
                    obj = [new Date(arrayDay[0].data[a][0]).getTime(), weekCount];
                    arrayWeek[0].data.push(obj);
                    c = 0;
                    weekCount = 0;
                } else {
                    weekCount = weekCount + arrayDay[0].data[a][1];
                    c++;
                }
                //get the highest plot
                for (b = 0; b < arrayWeek[0].data.length; b++) {
                    if (arrayWeek[0].data[b][1] > highestPlot) {
                        highestPlot = arrayWeek[0].data[b][1];
                    }
                }
            }
            // add the published date to the graph
            arrayWeek.push({
                label: "Published Date",
                data: [
                    [publish_date, 0],
                    [publish_date, highestPlot]
                ]
            });

            $.plot("#graph_content", arrayWeek, $scope.chartOptions);
        }

        function monthArray() {
            monthCount = 0; //var to handle month count
            highestPlot = 0; //var for the highest plot used for the pusblished line
            //array for months
            arrayMonth = [{
                label: $scope.dataSet,
                data: []
            }];
            //set the current month equal to the first month
            var currentMonth = new Date(arrayDay[0].data[0][0]).getMonth();
            for (a = 0; a < arrayDay[0].data.length; a++) {
                //if the month is equal to current month add the count to the month count
                //else push the month and count, reset the monthcount and set current month
                if (new Date(arrayDay[0].data[a][0]).getMonth() == currentMonth) {
                    monthCount = monthCount + arrayDay[0].data[a][1];
                } else {
                    obj = [new Date(arrayDay[0].data[a][0]).getTime(), monthCount];
                    arrayMonth[0].data.push(obj);
                    monthCount = 0;
                    currentMonth = new Date(arrayDay[0].data[a][0]).getMonth();
                }
            }
            //find the highest plot for that month
            for (b = 0; b < arrayMonth[0].data.length; b++) {
                if (arrayMonth[0].data[b][1] > highestPlot) {
                    highestPlot = arrayMonth[0].data[b][1];
                }
            }
            //push the published date line with the highest plot
            arrayMonth.push({
                label: "Published Date",
                data: [
                    [publish_date, 0],
                    [publish_date, highestPlot]
                ]
            });
            //plot the graph

            $.plot("#graph_content", arrayMonth, $scope.chartOptions);
        }
        //select the graph ranges
        $scope.selectRange = function(event, ranges) {
            var to; //first selection
            var from; //last selection

            switch ($scope.filterType) {
                case "Day":
                    chart = arrayDay;
                    break;
                case "Week":
                    chart = arrayWeek;
                    break;
                case "Month":
                    chart = arrayMonth;
                    break;
            }
            // if there are ranges set them to vars
            //else the vars equal the first and last of the array
            if (angular.isDefined(ranges)) {
                to = ranges.xaxis.to;
                from = ranges.xaxis.from;
            } else {
                to = _.last($scope.LiveReportData.store.data_points).date;
                from = $scope.LiveReportData.store.data_points[0].date;
            }
            //plot the corresponding graph using the limits

            $.plot($("#graph_content"), chart, $.extend(true, {}, $scope.chartOptions, {
                xaxis: {
                    min: from,
                    max: to
                }
            }));
            //create the orderedlist
            $scope.createOrderedlist();
            for (i = 0; i < $scope.LiveReportData.store.data_points.length; i++) {
                //if the date of the data point in greater than from
                if ($scope.LiveReportData.store.data_points[i].date > from) {
                    //if the date of the data point is less than to
                    if ($scope.LiveReportData.store.data_points[i].date < to) {
                        //loop throught the labels
                        angular.forEach($scope.LiveReportData.store.data_points[i].labels, function(value, key) {
                            for (a = 0; a < $scope.orderedlist.length; a++) {
                                //if the key == the name add to the count of that poly
                                if (key == $scope.orderedlist[a].name) {
                                    $scope.orderedlist[a].count = $scope.orderedlist[a].count + value;
                                }
                            }
                        });
                    }
                }
            }
            //get the percent array
            $scope.getPercentages();
            //clear the map to create new polygons
            $scope.updateMap();
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        };
        $scope.getPercentages = function() {
            $scope.totalCount = 0; //total poly count
            var percent = 0; //percentage
            //get the total count
            for (a = 0; a < $scope.orderedlist.length; a++) {
                $scope.totalCount = $scope.totalCount + $scope.orderedlist[a].count;
            }
            //loop through the list and get the percentages of each poly
            for (b = 0; b < $scope.orderedlist.length; b++) {
                if ($scope.totalCount !== 0) {
                    percent = ($scope.orderedlist[b].count / $scope.totalCount) * 100;
                }
                $scope.orderedlist[b].percent = Math.floor(percent + 0.5);
            }
        };
        //download table data
        $scope.tableDownload = function() {
            array = [];
            //headers
            array.push(["Name", "Count", "Percentage"]);
            //add each poly to the array
            for (a = 0; a < $scope.orderedlist.length; a++) {
                var b = $scope.orderedlist[a];
                array.push([b.name, b.count, b.percent]);
            }
            //create the csv
            $scope.createCSV(array, "Table");
        };
        //download chart data
        $scope.chartDownload = function() {
            switch ($scope.filterType) {
                case "Day":
                    $scope.chart = arrayDay;
                    break;
                case "Week":
                    $scope.chart = arrayWeek;
                    break;
                case "Month":
                    $scope.chart = arrayMonth;
                    break;
            }
            array = [];
            var date = new Date($scope.chart[1].data[0][0]);
            var d = date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
            //add published date
            array.push(["Published Date", d]);
            //add headers
            array.push(["Date", "Count"]);
            //push each data point to the array
            for (a = 0; a < $scope.chart[0].data.length; a++) {
                var b = $scope.chart[0].data[a];
                date = new Date(b[0]);
                d = date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
                array.push([d, b[1]]);
            }
            //create the csv
            $scope.createCSV(array, "Chart");
        };
        //on mousein set highlighted = true on that tr
        $scope.highlight = function(poly) {
            $scope.MapLayer.layer.trigger('mouse_in', poly.name, true);
        };
        //on mouseout reset tr
        $scope.unhighlight = function(poly) {
            $scope.highlighted = null;
            $scope.MapLayer.layer.trigger('mouse_out', poly.name, poly.origColor);
        };
        //function to create csv
        $scope.createCSV = function(array, title) {
            csvContentArray = [];
            //loop through the array
            array.forEach(function(infoArray, index) {
                //join data and push to the array
                dataString = infoArray.join(",");
                csvContentArray.push(dataString);
            });
            //append a new line to the end of the content
            csvContent = csvContentArray.join("\n");
            //create an a element
            a = document.createElement('a');
            //set the download name
            a.download = $scope.dataSet + "_" + title + ".csv";
            //append the data
            a.href = 'data:text/csv;charset=utf-8,' + escape(csvContent);
            //add to html
            document.body.appendChild(a);
            //download csv
            a.click();
        };
        $scope.updateChart = function() {
            arrayDay = [{
                label: $scope.dataSet,
                data: []
            }];
            var today = new Date().getTime();
            $scope.LiveReportData.store.data_points.push({
                date: today
            });
            publish_date = new Date($scope.LiveReportData.store.published_date).getTime();
            updatedArray = [];
            if ($scope.LiveReportData.store.data_points[0].date > publish_date) {
                updatedArray.push(publish_date);
            }
            for (b = 0; b < $scope.LiveReportData.store.data_points.length; b++) {
                updatedArray.push($scope.LiveReportData.store.data_points[b]);
            }
            $scope.LiveReportData.store.data_points = newDataArray(updatedArray);
            for (i = 0; i < $scope.LiveReportData.store.data_points.length; i++) {
                var total = 0;
                if (angular.isDefined($scope.LiveReportData.store.data_points[i].labels)) {
                    angular.forEach($scope.LiveReportData.store.data_points[i].labels, function(value, key) {
                        total = total + value;
                    });
                }
                obj = [new Date($scope.LiveReportData.store.data_points[i].date).getTime(), total];
                arrayDay[0].data.push(obj);
            }
            highestPlot = 0;
            for (b = 0; b < arrayDay[0].data.length; b++) {
                if (arrayDay[0].data[b][1] > highestPlot) {
                    highestPlot = arrayDay[0].data[b][1];
                }
            }
            arrayDay.push({
                label: "Published Date",
                data: [
                    [publish_date, 0],
                    [publish_date, highestPlot]
                ]
            });

            $.plot("#graph_content", arrayDay, $scope.chartOptions);
            $("#graph_content").bind("plotselected", $scope.selectRange);
        };
        //if the data is not active load
        //else create orderedlist and map from new data
        // Load data
        $scope.$watch("current_tab", function(tab) {
            if (tab == "/activity") {
                if ($scope.has_feature('activity_map')) {
                    if (!$scope.LiveReportData.active) {

                        var psc = false;
                        var id = $scope.topic;
                        if (angular.isDefined($scope.psc_client)) {
                            id = $scope.psc_client;
                            psc = true;
                        }
                        $scope.LiveReportData.load(id, psc).then(function(obj) {
                            $scope.onLiveLoad();
                            $scope.updateChart();
                        }, function(reason) {});
                    }
                }
            }
        });
    }
]);