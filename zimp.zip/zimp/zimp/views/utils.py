from zimp.models import *

MONTHS = [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
]


def get_loja(request):
    return Retailer.objects.first()


def pagination(page, index):
    n = index
    min_page = max(1, n - 4)
    max_page = min(n + 4, page.paginator.num_pages)
    return range(min_page, max_page + 1)

