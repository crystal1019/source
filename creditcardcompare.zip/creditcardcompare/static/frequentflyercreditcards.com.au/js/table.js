function initTableSorter(){
	$("#offer-list").tablesorter({debug: false});
	$('.compare-checkbox').click(function(evt){ toggleControls(); });
};
$(document).ready(function() { 
	initTableSorter();
	
	function loadPage(evt, caller){
		$('#table').html('<div style="width: 128px; margin: auto auto 0 auto;"><img src="http://media.frequentflyercreditcards.com.au/production/images/transfer.gif" alt="Loading..."/></div>');
		jQuery.scrollTo($('#table'));
		evt.stopPropagation();
		evt.preventDefault();
		jQuery.ajax({
			type: 'GET',
			url: caller.href.replace('#','?'),
			dataType: 'json',
			error: function() {},
			success: function(data) {
				$('#table').html(data.html);
				initTableSorter();
				$('.paginate').click(function(evt) {loadPage(evt, this);});
			}
		});
	};
	$('.paginate').click(function(evt) {loadPage(evt, this);});
});