
  function validateEmail(form1){      
       var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
       return emailPattern.test(form1);
   }
   function chkform(form1)
   {
	   	if(document.form1.id_first_name.value=="")
		{
			alert("Enter Your First Name");
			document.form1.id_first_name.focus();
			return false;
		}
		if(document.form1.id_last_name.value=="")
		{
			alert("Enter Your Last Name");
			document.form1.id_last_name.focus();
			return false;
		}
		if(document.form1.id_email.value==""||document.form1.id_email.value=="Email Address :")
		{
			alert("Please Enter your email");
			document.form1.id_email.focus();
			return false;
		}
		if(!validateEmail(document.form1.id_email.value))
		{
			alert("Please enter correct email address");
			document.form1.id_email.focus();
			return false;
		}
		if(document.form1.answer.value=="")
		{
			alert("Submit Your Answer");
			document.form1.answer.focus();
			return false;
		}
       
    return true;
   }
