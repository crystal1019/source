# for strftime jinja2 filter
date_format = '<strong>%B %e, %Y</strong> %I:%M %p'
date_format_short = '<strong>%B %e</strong> %I:%M %p'