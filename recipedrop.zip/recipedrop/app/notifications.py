import json
from django.http import HttpResponse
from models import Notification

def viewed(request):
    if request.method == 'POST':
        notifications = json.loads(request.POST['viewed_notifications'])
        for nid in notifications:
            n = Notification.objects.get(id = nid)
            n.seen = True
            n.save()

    return HttpResponse()
        
