# Django settings for bellabustiere project.

DEBUG = True
TEMPLATE_DEBUG = DEBUG

ADMINS = (
    ('chaol', 'chaol@1md.com.au'),
)


MANAGERS = ADMINS

DATABASES = {
    'default': {
            'ENGINE':'django.db.backends.mysql',
            'HOST':'127.0.0.1',
            'NAME':'bellabustiere',
            'USER':'root',
            'PASSWORD':'root',
            'OPTIONS':{"init_command": "SET storage_engine=INNODB" } 
        }
    }

GEOIP_PATH = '/Users/chaol/workspace/bellabustiere/media/geodata/'
GEOIP_LIBRARY_PATH = '/opt/local/lib/libGeoIP.dylib'
GEOIP_COUNTRY = 'GeoIP.dat'
GEOIP_CITY = 'GeoLiteCity.dat'

TXT_SHOP_ORDER_STATUS_IN_PROGRESS = "In Progress"
TXT_SHOP_ORDER_STATUS_ORDERED = "Ordered"

TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE = "Unable to calculate Freight & Handling, please check if your postcode and suburb are matching"

MANAGERS = ADMINS


AUTH_PROFILE_MODULE = "userprofile.Profile"

PRODUCTS_PER_PAGE = 9

BLOG_POSTS_PER_PAGE = 5


SITE_NAME = 'Bella Bustiere'
SITE_DOMAIN = 'bellabustiere.com.au'
DOMAIN = 'bellabustiere.local'
PRIVATE_KEY = 'dou8leiv7@3l+f$3wemqwdy!$4(w6#&$d7z$s!cd!en$@n(0^^m@sh6cdou8le'
PRIVATE_MESSAGE = 'greedy is good'

EMAIL_FROM = 'info@bellabustiere.com.au'

EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'maclocaltest@gmail.com'
EMAIL_HOST_PASSWORD = 'mactestlocal888'
EMAIL_PORT = 587
EMAIL_USE_TLS = True


TIME_ZONE = 'Australia/Sydney'

LANGUAGE_CODE = 'en-us'

SITE_ID = 1


USE_I18N = False

HAYSTACK_SITECONF = 'bellabustiere.search_sites'
HAYSTACK_SEARCH_ENGINE = 'whoosh'
HAYSTACK_WHOOSH_PATH = '/Users/chaol/workspace/bellabustiere/media/whoosh_index/'
CAPTCHA_OUTPUT_FORMAT = "<td width='108' valign='top'>%(image)s</td><td align='left' valign='middle'>%(hidden_field)s %(text_field)s"


EWAYID = ''

USERNAME = '' 
PASSWORD = ''
SIGNATURE = ''

MYOB_PATH = '/Users/chaol/workspace/bellabustiere/media/csvs/myob.txt'

MYOB_CUSTOMER_PATH = '/Users/chaol/workspace/bellabustiere/media/csvs/myob_customer.txt'


PRICE_FILTER_DICT = {'1':('$0 - $25',0,25), '2':('$25 - $50', 25,50), '3':("$50 - $100",50,100), '4':("$100 - $200",100,200), '5':("$200 - $300",200,300), '6':('$300 - $400',300,400), '7':('$400 - $500',400,500), '8':('Above $500',500,10000)}


MEDIA_ROOT = '/Users/chaol/workspace/bellabustiere/media/'

MEDIA_URL = '/media/'

ADMIN_MEDIA_PREFIX = '/media/adminmedia/'

STATIC_URL = '/media/'

WHOLESALE_SHIPPING = 'automatic'

SECRET_KEY = 'q@kudm#a1t4xs=gq@!t7%u3qtpy3b9z(#zxyhg8w1=qb%ig*j-'

TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.gzip.GZipMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
   # 'bellabustiere.Middleware.SecureRequiredMiddleware',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    "django.contrib.auth.context_processors.auth",
    "django.core.context_processors.request",
)

GRAPPELLI_ADMIN_TITLE = 'Bella Bustiere'

ROOT_URLCONF = 'bellabustiere.urls'

TEMPLATE_DIRS = (
    "/Users/chaol/workspace/bellabustiere/bellabustiere/templates",
)

PASSWORD_REQUIRED_PASSWORD = 'Password111'

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'bellabustiere.blog',
    'bellabustiere.website',
    'bellabustiere.shop',
    'bellabustiere.userprofile',
    'bellabustiere.stockists',
    'grappelli',
    'tagging',
    'filebrowser',
    'captcha',
    'mptt',
    'haystack',
    'password_required',
    #'sorl.thumbnail',
    #'tinymce',
    'django.contrib.admin',
    'django.contrib.sitemaps',
)

FIXTURE_DIRS = (
   '/home/craig/website/backend/fixtures/',
)
