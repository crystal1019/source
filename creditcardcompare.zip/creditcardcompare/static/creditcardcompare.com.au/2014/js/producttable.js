var _ccc_table = {
	parse:function(){
		$('div[producttable]').each(this.init);
	},
	init:function(i){
		if($(this).children('.product1listcontent').length == 0 || this.getAttribute('producttable') == 'enabled'){
			return;
		} else {
			this.setAttribute('producttable','enabled');
		}
		var use = {scope:null , id:null,num:i,div:this,
			changeContent:function(e){
				if(e.data == use.id){
					return;
				}
				$(e.target).attr('class','product1listitemselected');
				$(use.target).attr('class','product1listitem hand-pointer');
				$(use.div).find('.product1listcontent').eq(use.id).toggleClass('product1listhidden') ;//.hide();
				$(use.div).find('.product1listcontent').eq(e.data).toggleClass('product1listhidden') ; ;//.show();

				use.id = e.data;
				use.target = e.target;
			}};
//first().children().
		$(this).find('.product1list').children().each(function(i){
			$(this).bind('click',i,use.changeContent);
			if(i==0){
				use.scope = this;
			}
		});
		use.changeContent({target:use.scope , data:0});
	}
};