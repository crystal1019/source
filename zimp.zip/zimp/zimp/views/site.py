import os
import json
import datetime
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, logout as auth_logout, login as auth_login
from django.shortcuts import render
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, Page
from django.db.models.aggregates import Sum
from django.utils.formats import mark_safe
from django.contrib.auth.decorators import login_required
from zimp.models import *
from .utils import *
from . import lojista, marca, shopping


def login(request):
    if request.method == 'POST':
        #authenticate(password=request.POST['password'], email=request.POST['email'])
        try:
            user = User.objects.get(email=request.POST['email'])

            auth_login(request, user)
            return HttpResponseRedirect('/')
        except:
            raise
            messages.error(request, 'Usuário/senha inválido!')
    return render(request, 'zimp/site/login.html')


@login_required
def dashboard(request):
    view_type = request.user.panel
    loja = get_loja(request)
    hoje = datetime.date.today()
    mes = hoje.month
    ano = hoje.year

    c = connection.cursor()
    c.execute("""select day(created_at) as dia,
sum(case type when 0 then value else 0 end) as checkin,
sum(case type when 1 then value else 0 end) as acumulo,
sum(case type when 3 then value else 0 end) as resgate,
sum(case type when 2 then value else 0 end) as compartilhamento
from vw_transactions as v where month(created_at) = %s and year(created_at) = %s group by date(created_at)""", (mes, ano))
    rows = c.fetchall()[:]
    acumulos = []
    resgates = []
    checkins = []
    compartilhamentos = []
    days = []
    for r in rows:
        days.append(str(r[0]))
        checkins.append(str(r[1]))
        acumulos.append(str(r[2]))
        resgates.append(str(r[3]))
        compartilhamentos.append(str(r[4]))

    c = connection.cursor()
    c.execute("""select month(created_at) as mes,
sum(case type when 1 then value else 0 end) as acumulo,
sum(case type when 2 then value else 0 end) as resgate
from vw_transactions as v group by month(created_at)""")
    rows = c.fetchall()[:]
    acumulos2 = []
    resgates2 = []
    months = []
    for r in rows:
        months.append(MONTHS[r[0] - 1])
        acumulos2.append(str(r[1]))
        resgates2.append(str(r[2]))


    ## POR GENERO

    c = connection.cursor()
    c.execute("""select i.gender, concat(idade1, '-', idade2) as faixa, count(v.id) as qt
  from rep_idades i
  left join vw_rep_movimento_perfil v on v.gender = i.gender and v.idade between idade1 and idade2
  group by i.id, i.gender
  order by i.gender, i.id""")
    rows = c.fetchall()[:]
    masculino = []
    feminino = []
    for r in rows:
        if r[0] == 1:
            masculino.append(-r[2])
        else:
            feminino.append(r[2])

    ## NOVOS X REVISITANTES

    c = connection.cursor()
    c.execute("""SELECT sum(novo) as novo, sum(revisitante) as revisitante from vw_cliente_revisitante""")
    rows = c.fetchone()
    novos_clientes = rows[0]
    revisitantes_clientes = rows[1]

    c = connection.cursor()
    c.execute("""SELECT
sum(qt_checkin), sum(qt_compra), sum(qt_resgate), sum(qt_compartilhado),
sum(checkin), sum(compra), sum(resgate), sum(compartilhado)
FROM vw_rep_movimento""")
    total = c.fetchone()

    ## TAG CLOUD
    c = connection.cursor()
    c.execute("""select brand, count(*) as qt from vw_movimento_marca group by brand""")
    tag = c.fetchall()

    ## CHECKING VS COMPRA
    try:
        checkin_compra = total[1] / total[0] * 100
    except:
        checkin_compra = 0

    ## SHARE VS COMPRA
    try:
        share_compra = total[3] / total[0] * 100
    except:
        share_compra = 0

    ## MEDIA FREQUENCIA
    try:
        media_compra = int(total[1] / 12)
    except:
        media_compra = 0


    c = connection.cursor()
    c.execute("""select valor, total from vw_share_wallet where retailer_id = %s and mes = %s and ano = %s""",
              (loja.pk, mes, ano)
    )
    share_wallet = c.fetchone()
    ## WALLET
    try:
        share_wallet = share_wallet[0] / share_wallet[1] * 100
    except:
        share_wallet = 0

    return render(request, 'zimp/site/dashboard.html', {
        'view_type': view_type,
        'active_page': 'dashboard',
        'days': mark_safe(json.dumps(days)),
        'novos_clientes': novos_clientes,
        'revisitantes_clientes': revisitantes_clientes,
        'acumulos': mark_safe(','.join(acumulos)),
        'resgates': mark_safe(','.join(resgates)),
        'checkins': mark_safe(','.join(checkins)),
        'compartilhamentos': mark_safe(','.join(compartilhamentos)),
        'months': mark_safe(json.dumps(months)),
        'acumulos2': mark_safe(','.join(acumulos2)),
        'resgates2': mark_safe(','.join(resgates2)),
        'masculino': json.dumps(masculino),
        'feminino': json.dumps(feminino),
        'total_checkin': total[0],
        'total_acumulo': total[1],
        'total_resgate': total[2],
        'total_compartilhado': total[3],
        'valor_checkin': total[4],
        'valor_acumulo': total[5],
        'valor_resgate': total[6],
        'valor_compartilhado': total[7],
        'tag': tag,
        'checkin_compra': checkin_compra,
        'share_compra': share_compra,
        'media_compra': media_compra,
        'share_wallet': share_wallet,
    })


def reports(request):
    folder = request.user.panel
    path = os.path.join(os.path.dirname(__file__), '..', 'reports', folder, 'reports')
    replist = []
    for f in os.listdir(path):
        if (os.path.splitext(f)[1] == '.frx') or (os.path.isdir(f)):
            replist.append({
                'href': '/reports/?report=%s/reports/%s&fmt=pdf' % (folder, f),
                'name': os.path.splitext(f)[0],
            })
    return render(request, 'zimp/site/reports.html', {
        'active_page': 'reports',
        'replist': replist,
        'view_type': folder,
    })


@login_required
def extrato(request):
    view_type = request.user.panel
    errors = False
    rows = Transactions.objects.filter(type__in=[1, 2])
    data1 = request.GET.get('data1')
    data2 = request.GET.get('data2')
    page = request.GET.get('p')
    fmt = request.GET.get('fmt', 'html')
    filter_url = ''
    try:
        if data1 and data2:
            data1 = datetime.datetime.strptime(data1, '%d/%m/%Y')
            data2 = datetime.datetime.strptime(data2, '%d/%m/%Y')
            data2 += datetime.timedelta(days=1)
            filter_url = '?data1=%s&data2=%s&' % (request.GET.get('data1'), request.GET.get('data2'))
            rows = rows.filter(created_at__gte=data1, created_at__lt=data2)
    except:
        messages.error(request, 'Não foi possível filtrar o período informado! O formato da data deve ser "DD/MM/AAAA".')

    acumulo = rows.filter(type=1).aggregate(total=Sum('value'))['total'] or 0
    resgate = rows.filter(type=2).aggregate(total=Sum('value'))['total'] or 0
    total = acumulo - resgate
    page_list = []
    if fmt == 'html':
        rows = Paginator(rows, 10)
        try:
            rows = rows.page(page)
            page = int(page)
        except PageNotAnInteger:
            page = 1
            rows = rows.page(page)
        except EmptyPage:
            page = 0
            rows = rows.page(rows.num_pages)
        page_list = pagination(rows, page)

    context = {
        'view_type': view_type,
        'active_page': 'acumulos',
        'rows': rows,
        'total': total,
        'filter_url': filter_url,
        'page': page,
        'page_list': page_list,
        'acumulo': acumulo,
        'resgate': resgate,
    }

    if request.user.role == 5:
        context['lojas'] = Retailer.objects.filter(brand_id=request.user.admin_of)

    template_name = 'zimp/site/extrato.html'

    if fmt == 'csv':
        r = render(request, 'zimp/site/extrato.csv.html', context, content_type='text/csv')
        r['Content-Disposition'] = 'attachment; filename=extrato.csv'
    else:
        r = render(request, template_name, context)

    return r


@login_required
def alcance(request):
    view_type = request.user.panel
    c = connection.cursor()
    tipo = request.GET.get('type', 'mes')
    data1 = request.GET.get('data1')
    data2 = request.GET.get('data2')
    if data1 == 'None':
        data1 = None
    if data2 == 'None':
        data2 = None
    if not data1 or not data2:
        if tipo == 'mes':
            data2 = datetime.date.today()
            data1 = data2 - datetime.timedelta(days=365)
            return HttpResponseRedirect('%s?type=%s&data1=%s&data2=%s' % (request.path, tipo, data1.strftime('%d/%m/%Y'), data2.strftime('%d/%m/%Y')))
        elif tipo == 'dia':
            data2 = datetime.date.today()
            data1 = data2 - datetime.timedelta(days=30)
            return HttpResponseRedirect('%s?type=%s&data1=%s&data2=%s' % (request.path, tipo, data1.strftime('%d/%m/%Y'), data2.strftime('%d/%m/%Y')))
    if data1 and data2:
        data1 = datetime.datetime.strptime(data1, '%d/%m/%Y')
        data2 = datetime.datetime.strptime(data2, '%d/%m/%Y')
    if tipo == 'dia':
        c.execute("""select day(data) as dia, checkin from vw_rep_movimento_grupo_dia where data between %s and %s""", (data1, data2))
    else:
        c.execute("""select mes, qt_checkin from vw_rep_movimento_grupo_mes""")
    rows = c.fetchall()[:]
    acumulos = []
    months = []
    for r in rows:
        if tipo == 'dia':
            months.append(r[0])
        else:
            months.append(MONTHS[r[0] - 1])
        acumulos.append(str(r[1]))
    lojas = None
    if view_type != 'lojista':
        lojas = Retailer.objects.filter(brand_id=request.user.admin_of)

    return render(request, 'zimp/site/alcance.html', {
        'view_type': view_type,
        'months': mark_safe(json.dumps(months)),
        'active_page': 'alcance',
        'acumulos': mark_safe(','.join(acumulos)),
        'lojas': lojas,
    })


@login_required
def fatura(request):
    view_type = request.user.panel
    mes = request.GET.get('mes')
    fmt = request.GET.get('fmt')
    c = connection.cursor()
    if mes:
        c.execute("""select created_at, sum(value) as value,
case type when 1 then 'ACÚMULO' when 2 then 'CHECK-IN' end as type,
count(*) as qt
from vw_transactions as v
where type in (1,2) and month(created_at) = %s
group by created_at, type""",
                  (mes,)
        )
        rows = c.fetchall()[:]
        context = {
            'active_page': 'fatura',
            'rows': rows,
            'mes': MONTHS[int(mes) - 1],
            'ano': datetime.date.today().year,
            'view_type': view_type,
        }

        if fmt == 'csv':
            r = render(request, 'zimp/site/fatura_mes.csv.html', context, content_type='text/csv')
            r['Content-Disposition'] = 'attachment; filename=extrato.csv'
            return r
        return render(request, 'zimp/site/fatura_mes.html', context)
    else:
        c.execute("""select month(created_at) as mes, year(created_at) as ano,
sum(case type when 1 then value else 0 end) as acumulo
from vw_transactions as v
where type = 1 and created_at between date_sub(current_date, interval 12 month) and current_date
group by ano, mes order by ano, mes""")
        rows = []

        for r in c.fetchall()[:]:
            r = list(r)
            r.append(MONTHS[r[0] - 1])
            rows.append(r)

        return render(request, 'zimp/site/fatura.html', {
            'active_page': 'fatura',
            'rows': rows,
            'mes': datetime.date.today().month,
            'view_type': view_type,
        })


@login_required
def usuarios(request):
    view_type = request.user.panel
    q = request.GET.get('q')
    if q:
        rows = User.objects.filter(userinfo__name__icontains=q)
    else:
        rows = User.objects.all()
    return render(request, 'zimp/site/usuarios.html', {
        'view_type': view_type,
        'active_page': 'usuarios',
        'rows': rows,
    })


@login_required
def logout(request):
    auth_logout(request)
    return HttpResponseRedirect('/login/')
