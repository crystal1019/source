from django.shortcuts import render
from apps.models import InputForm
from scraper import scrapping

# Create your views here.

def index(request):

    if request.method == 'POST':
        form = InputForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            scraper = scrapping()
            results = scraper.get_data(username, password)
            if results == '':
                context = {'results': 'http://www.smartmfi.com/ is down. Please try again later.'}
                return render(request, 'index.html', context)
            if not results:
                context = {'results': 'Incorrect password!'}
                return render(request, 'index.html', context)
            context = {'results':'Done. These are all the results in product.csv file.'}
            return render(request, 'index.html', context)

        else:
            context = {'results': 'The data introduced is not valid.'}
            return render(request, 'index.html', context)
    else:
        context = {'results': 'Please enter a password!'}
        return render(request, 'index.html', context)

