from django.conf import settings
from django.db import IntegrityError
# from django.utils.cache import patch_vary_headers
from django.utils.html import strip_spaces_between_tags as short
from models import UserAgent, IS_MOBILE
from offers.helpers.template.loaders import set_agent

class SpacelessMiddleware(object):
    def process_response(self, request, response):
        if (not settings.DEBUG or settings.SPACELESS_HTML) and 'text/html' in response.get('Content-Type', ''):
            response.content = short(response.content)
        return response


class MobileMiddleware(object):
    '''
        1. The model detects device.
        2. The middleware stores/sends device data into _agent/session. 
        model <-- middleware --> _agent/session
        
        template.models.IS_MOBILE
        _agent.is_mobile
        request.session['is_mobile']
    '''
    
    def process_request(self, request):
        agent = self._get_agent(request)
        if request.is_ajax() == False and agent != None:
            agent.hit()
        self._set_is_mobile(request, getattr(agent, 'is_mobile', IS_MOBILE))
        
    def _get_agent(self, request):
        user_agent = request.META.get('HTTP_USER_AGENT', '')
        try:
            return UserAgent.objects.get(agent=user_agent)
        except UserAgent.DoesNotExist:
            try:
                return UserAgent.objects.create(agent=user_agent)
            except IntegrityError:
                pass
        
    def _set_is_mobile(self, request, is_mobile):
        try:
            is_desktop = request.COOKIES['desktop-template'] == 'true'
        except KeyError:
            pass
        else:
            is_mobile = not is_desktop
        request.session['is_mobile'] = is_mobile
        set_agent(is_mobile)
        
    #===========================================================================
    # This is no longer needed, making the site slow. Let ETag do the job
    #===========================================================================
#     def process_response(self, request, response):
#         patch_vary_headers(response, ['User-Agent'])
#         return response
        