import re
from django import forms
from offers.helpers.lead.forms import LeadForm


class MinimumRepaymentForm(forms.Form):
    amount = forms.CharField()
    minimum_repayment = forms.CharField()
    minimum_repayment_type = forms.ChoiceField(choices=(('$', '$'), ('%', '%')))
    overpayment = forms.CharField(required=False)
    overpayment_type = forms.ChoiceField(choices=(('$', '$'), ('%', '%')))
    rate = forms.CharField()
    
    float_format = lambda self, name: re.sub("[^\d\.-]", "", self.cleaned_data.get(name, ''))
    
    def __init__(self, *args, **kwargs):
        super(MinimumRepaymentForm, self).__init__(*args, **kwargs)
        self.fields['amount'].error_messages['required'] = 'Please enter loan amount'
        self.fields['minimum_repayment'].error_messages['required'] = 'Please enter minimum repayment'
        self.fields['rate'].error_messages['required'] = 'Please enter interest rate'
        
    def _strip_non_numeric(self, name):
        try:
            data = float(re.sub("[^\d\.-]", "", self.cleaned_data.get(name, '')))
        except ValueError:
            if self.fields[name].required or self.cleaned_data.get(name, ''):
                raise forms.ValidationError(u'Please enter a valid %s.' % self[name].label)
        else:
            if data <= 0 and name != 'rate':
                raise forms.ValidationError(u'Please enter a valid %s.' % self[name].label)
            return data
    
    def clean_amount(self):
        return self._strip_non_numeric('amount')
    
    def clean_minimum_repayment(self):
        return self._strip_non_numeric('minimum_repayment')
    
    def clean_overpayment(self):
        return self._strip_non_numeric('overpayment')
        
    def clean_rate(self):
        return self._strip_non_numeric('rate')
    

TERMS = ((1,'1 year'),
         (2,'2 years'),
         (3,'3 years'),
         (4,'4 years'),
         (5,'5 years'),
         (6,'6 years'),
         (7,'7 years'),
         (8,'8 years'),
         (9,'9 years'),
         (10,'10 years'),
         )


class CarLoanForm(LeadForm):
    amount = forms.FloatField()
    term = forms.ChoiceField(choices=TERMS)
    rate = forms.DecimalField()
    
   
    def __init__(self, *args, **kwargs):
        super(CarLoanForm, self).__init__(*args, **kwargs)
        self.fields['amount'].error_messages['required'] = 'Please enter loan amount'
        self.fields['term'].error_messages['required'] = 'Please enter term'
        self.fields['rate'].error_messages['required'] = 'Please enter rate'
    