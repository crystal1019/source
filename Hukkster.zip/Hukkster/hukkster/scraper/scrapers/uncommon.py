import json
import opengraph
import re
import pprint
import logging
from urlparse import urljoin
from lxml.html import fromstring, tostring

from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions

logger = logging.getLogger('scraper')


def get_all_text(t):
    tl = t.xpath('.//text()')
    if isinstance(tl, list):
        return "".join(tl).strip()
    return tl

#class UncommonScraper(object):
class UncommonScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'uncommongoods.com'

    # def fetch_url(self):
    #     with open('data.html', 'r') as f:
    #         self.html = f.read()

    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ""
        skus = lxml.xpath('.//form[@name="itemForm"]/input[@name="sku"]/@value')
        if skus:
                sku = skus[0]
        #print "sku=",sku

        title = raw_data['title'].encode('ascii','xmlcharrefreplace')

        price = lxml.xpath('.//span[@class="titlePrice"]/text()')
        if price:                
            prices = re.findall(r'(\d+\.\d+)', price[0])
            price = float(prices[len(prices) - 1])
        #print "price=",price

        variands = []
        variants = lxml.xpath('.//label[@for="selectitem"]/select[@id="selectitem"]/option/text()')
        variants = [x.strip() for x in variants]
        variants = [x for x in variants if not x.startswith("choose from list below")]
        print "variants=",variants

        image = lxml.xpath('.//img[@class="mainImage"]/@src')
        if image:
            image = image[0]
        else:
            image = ''
        print "image=",image

        images = []
        images = lxml.xpath('.//div[@class="altViewArea"]/a/@href')
        print "alt images=",len(images),images

        selections = []

        data_url = lxml.getroottree().xpath('.//link[@rel="canonical"]/@href')
        if data_url:
            data_url = data_url[0]
        #print "data_url=",data_url
        data_store = urljoin(data_url,'/')

        data_image = image

        for variant in variants:
            data = {'title': title,
                    'current_price': {
                        'value': price
                        },
                    'url': data_url,
                    'store': data_store,
                    'image': data_image,
                    'images': images,
                    'local_id': sku,
                    'selections': {
                         'variant': variant,
                         #'color': color,
                         },
                    'promos': []
                }
            selections.append(data)
        return selections

    def parse_multi_product(self, lxml, raw_data):
        tl = lxml.xpath('.//div[@id="mainContent"]')
        #print "multi=",len(tl)
        selections = []
        for te in tl:
            sel = self.parse_single_product(te, raw_data)
            selections.extend(sel)
        return selections

    def parse(self):
        logger.debug('%s parse started' % UncommonScraper.get_domain())
        raw_data = {}
        #print "html=",self.html
        try:
            og = opengraph.OpenGraph(html=self.html)
            raw_data = dict([(k, v) for k, v in og.items()])
            # print "opengraph data:"
            # pprint.pprint(raw_data)
            lxml = fromstring(self.html)
        except:
            return []
        selections = self.parse_multi_product(lxml, raw_data)
        return selections

if __name__ == '__main__':
    s = UncommonScraper()
    s.fetch_url()
    print "Result=",
    pprint.pprint(s.parse())
