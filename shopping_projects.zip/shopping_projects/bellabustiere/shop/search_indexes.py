import datetime
from haystack.indexes import *
from haystack import site
from bellabustiere.shop.models import *

class ProductIndex(SearchIndex):
    text =  CharField(document=True, use_template=True)
    content_auto = EdgeNgramField(model_attr='get_all_content')


    def index_queryset(self):
        """Used when the entire index for model is updated."""
        return Product.objects.filter(status__display_to_user=True, sites__id=settings.SITE_ID)    

    
site.register(Product, ProductIndex)