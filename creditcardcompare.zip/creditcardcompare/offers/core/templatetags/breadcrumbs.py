from django import template
from django.conf import settings
from django.contrib.flatpages.models import FlatPage

register = template.Library()

from offers.core.templatetags import varname_re

class BreadcrumbsForFlatpageNode(template.Node):
    def __init__(self, flatpage, varname):
        self.flatpage = template.Variable(flatpage)
        self.varname = varname

    def render(self, context):
        try:
            flatpage = self.flatpage.resolve(context)
        except template.VariableDoesNotExist:
            context[self.varname] = list()
            return ''
        else:
            url_parts = flatpage.url.split('/')
            trail = list((dict(name='Home', url='/'),))
            url = '/'
            for part in url_parts:
                if part:
                    url += part + '/'
                    try:
                        page = FlatPage.objects.get(url__exact=url, sites=settings.SITE_ID)
                    except FlatPage.DoesNotExist:
                        continue
                    else:
                        trail.append(dict(name=page.title, url=page.get_absolute_url()))
            context[self.varname] = trail
            return ''

class BreadcrumbsForCategoryNode(template.Node):
    def __init__(self, category, varname):
        self.category = template.Variable(category)
        self.varname = varname

    def render(self, context):
        try:
            category = self.category.resolve(context)
        except template.VariableDoesNotExist:
            context[self.varname] = list()
            return ''
        else:
            trail = list()
            while category:
                if not category.slug.endswith('-issuers') and not category.slug.endswith('-features') and category.parent:
                    trail.insert(0, dict(name=category.name, url=category.get_absolute_url()))
                category = category.parent
            trail.insert(0, dict(name='Home', url='/'))
            context[self.varname] = trail
            return ''

@register.tag(name='breadcrumbs_for_flatpage')
def do_breadcrumbs_for_flatpage(parser, token):
    try:
        tag_name, flatpage, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 4 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    return BreadcrumbsForFlatpageNode(flatpage, varname)

@register.tag(name='breadcrumbs_for_category')
def do_breadcrumbs_for_category(parser, token):
    try:
        tag_name, category, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 4 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    return BreadcrumbsForCategoryNode(category, varname)
