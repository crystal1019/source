import cgi
import urllib
import lxml.html
import logging
import json
import demjson
from urlparse import urlparse
from urlparse import urlunparse
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions
from ..scraper_utils import ScraperUtility
from ..scraper_utils import ParseFailedError


logger = logging.getLogger('scraper')


class CoutureZapposScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'couture.zappos.com'

    def _extract_js_dict(self, var_name):
        pattern = r"var\s+" + var_name + r"\s+=\s+(?P<json_text>\{[^\;]+)\;"
        json_text = self.util._extract_value_dict_using_regex(pattern, self.html, 
                failure_msg="Failed to extract %s from javascript" % var_name)["json_text"]
        return demjson.decode(json_text)

    def _extract_local_id(self):
        sku_text = self.util._expect_and_extract_single_node_text_content("//h1[@id='prHead']/span[@class='sku']")
        value_dict = self.util._extract_value_dict_using_regex(r"SKU\:\s+\#(?P<sku>\d+)", sku_text, 
                    failure_msg="unexpected sku text: %r" % sku_text)
        return value_dict["sku"]

    def _extract_color_prices(self):
        return self._extract_js_dict("colorPrices")

    def _extract_title(self):
        return self.util.og_data["title"]

    def _extract_colors(self):
        colorNames = self._extract_js_dict("colorNames")
        return colorNames

    def _extract_image(self):
        detailed_image = self.util.og_data["image"]
        tail_length = len("DETAILED.jpg")
        if detailed_image.endswith("DETAILED.jpg"):
            return detailed_image[:-tail_length] + "MULTIVIEW.jpg"
        else:
            logging.debug("Error: unexpected image url format, fixes required. %s" % detailed_image)
            raise ParseFailedError()

    def _extract_size_info(self):
        dimensionIdToNameJson = self._extract_js_dict("dimensionIdToNameJson")
        dimensionId = name = None
        for dimensionId, name in dimensionIdToNameJson.items():
            if name == "size":
                break
        if dimensionId is None:
            logging.debug("Error: failed to find the 'size' dimension in javascript")
            raise ParseFailedError()
        sizeDimensionId = dimensionId
        valueIdToNameJSON = self._extract_js_dict("valueIdToNameJSON")
        return sizeDimensionId, valueIdToNameJSON

    def _extract_stock_json_content(self):
        sizeDimensionId, valueIdToNameJSON = self._extract_size_info()
        stock_json_content_text = self.util._extract_value_dict_using_regex(
                r"var\s+stockJSON\s+=\s+(?P<stock_json_content>\[[^\]]+\])",
                self.html)["stock_json_content"]
        stock_json_content = json.loads(stock_json_content_text)
        stock_info_dict = {}
        for stock_item in stock_json_content:
            if not stock_item.has_key(sizeDimensionId):
                logging.debug("Error: Failed to find the id(=%s) of sizeDimensionId in the stockJSON item: %r",
                        (sizeDimensionId, stock_item))
                raise ParseFailedError()
            else:
                size_id = stock_item[sizeDimensionId]
                color_size_pair = (stock_item["color"], (size_id, valueIdToNameJSON[size_id]["value"]))
                stock_info_dict[color_size_pair] = stock_info_dict.get(color_size_pair, 0) + \
                                int(stock_item.get("onHand", "0"))
        return stock_info_dict

    def parse_products(self):
        local_id = self._extract_local_id()
        url = self.util.og_data["url"]
        title = self._extract_title()
        image = self._extract_image()
        colorNames = self._extract_colors()
        stock_info_dict = self._extract_stock_json_content()
        colorPrices = self._extract_color_prices()

        product_data_list = []
        for color_id, size_tuple in stock_info_dict.keys():
            size_id, size_text = size_tuple
            color_text = colorNames[color_id]
            sold_out = stock_info_dict.get((color_id, size_tuple), 0) < 1
            if not sold_out:
                product_data = {}
                product_data["title"] = title
                product_data["url"] = url
                product_data["store"] = "couture.zappos"
                product_data["local_id"] = local_id
                product_data["promos"] = []
                product_data["selections"] = {"size": size_text, "color": color_text}
                product_data["image"] = image
                prices = colorPrices[color_id]
                product_data["original_price"] = {"value": prices["wasInt"]}
                product_data["current_price"] = {"value": prices["nowInt"]}
                product_data_list.append(product_data)
        return product_data_list

    def parse(self):
        self.util = ScraperUtility(self, parse_open_graph_info=True)

        try:
            products = self.parse_products()
        except ParseFailedError:
            products = None

        # Giving up, it doesn't look as a product
        if products is None or not len(products):
            raise HukksterTooManyOptions(self.get_domain(), self.url)

        return products

