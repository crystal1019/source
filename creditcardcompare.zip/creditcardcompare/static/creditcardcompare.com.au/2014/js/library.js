$(document).ready(function() {
	$('.ajax-submit-button').click(function(evt) {
		$(this).css('background-image', 'url("' + $(this).attr('progress-cog') + '")'
									).css('background-repeat','no-repeat'
									).css('background-position','center center');
		evt.stopPropagation();
		evt.preventDefault();
		htmlform = $(this).closest('form')[0];
		if (validate(htmlform,'email')){
			signup(evt, htmlform);
		}else{
			$(this).css('background-image', 'none');
		};
	});
});
function signup(evt, htmlform){
	jQuery.ajax({
		type: $(htmlform).attr('method'),
		url: $(htmlform).attr('action'),
		data: $(htmlform).serialize(),
		dataType: 'json',
		error: function() {
			$(htmlform).html($(htmlform).attr('failure-response-text')||'failed to submit form!');
		},
		success: function(data) {
			$(htmlform).html($(htmlform).attr('success-response-text')||data.result);
		}
	});
};
function validate(htmlform, email) {
   var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
   var address = htmlform.elements[email].value;
   if(reg.test(address) == false) {
      setTimeout(function() { alert('Invalid Email Address'); }, 10);
      return false;
   }else{
   	  return true;
   };
};
$(document).ajaxSend(function(event, xhr, settings) {
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    function sameOrigin(url) {
        // url could be relative or scheme relative or absolute
        var host = document.location.host; // host + port
        var protocol = document.location.protocol;
        var sr_origin = '//' + host;
        var origin = protocol + sr_origin;
        // Allow absolute or scheme relative URLs to same origin
        return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
            (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
            !(/^(\/\/|http:|https:).*/.test(url));
    }
    function safeMethod(method) {
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }

    if (!safeMethod(settings.type) && sameOrigin(settings.url)) {
        xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
    }
});
!function(d,s,id){
	var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';
	if(!d.getElementById(id)){
		js=d.createElement(s);
		js.id=id;
		js.src=p+'://platform.twitter.com/widgets.js';
		fjs.parentNode.insertBefore(js,fjs);
}}(document, 'script', 'twitter-wjs');
