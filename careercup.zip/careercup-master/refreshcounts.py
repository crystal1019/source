import memcache

import objects
import masterpage

import method_db
import method_question
import method_url

from datetime import datetime
	
class RefreshCounts(masterpage.MasterPage):				  	

	def count_all(self, cls):
		"""
		Count *all* of the rows (without maxing out at 1000)
		"""
		count = 0
		query = cls.order(objects.Question._key)

		while count % 1000 == 0:
			current_count = query.count()
			if current_count == 0:
				break

			count += current_count

			if current_count == 1000:
				last_key = query.fetch(1, 999)[0].key()
				query = query.filter('__key__ > ', last_key)

		return count

	def get_total_count(self,model,filter_text, attribute_id, cacheTime = 60,maxNumber = 1000):
		cacheName = model.kind() + "_totalCount" + attribute_id
		total = memcache.get(cacheName)
		if total == None:
			index = 0
			currentTotal = total = len(model.all().filter(filter_text, attribute_id).filter('visible =', True).fetch(maxNumber,0 ))
			while currentTotal == maxNumber:
				index += 1
				currentTotal = len(model.all().filter(filter_text, attribute_id).filter('visible =', True).fetch(maxNumber,maxNumber * index))
				total += currentTotal
			memcache.add(cacheName, total, cacheTime)
		return total

	def validate(self, arr, sz, steps):
		valid = True
		
		# Validation
		for i in range(1, sz):
			# Each step checks 1, (1), OR 2, (2)
			if valid or not(valid):
				index = (i-1) * 2
				string = ' ' + str(i) + ' '
				if arr[index] != string:
					if valid:
						self.response.out.write(str(sz) + '  = ' + str(steps) + ' steps <br/>')
						self.response.out.write('<br/>Fail: ')
					self.response.out.write(str(string) + ' ')
					valid = False
				index = (i-1)* 2 + 1
				string = '(' + str(i) + ')'
				if arr[index] != string:
					if valid:
						self.response.out.write(str(sz) + '  = ' + str(steps) + ' steps <br/>')
						self.response.out.write('<br/>Fail: ')						
					self.response.out.write(str(string) + ' ')
					valid = False
				
		if not valid:		
			self.response.out.write('<br/>')
			self.response.out.write(arr)
			self.response.out.write('<br/>---------<br/><br/>')
			
		return valid
		
	def getCountForFilterAndId(self, qry):
		cnt = self.count_all(qry.query(objects.Question.visible == True))
		self.response.out.write(cnt)
		return cnt
		
	def refreshAttribute(self, attribute):
		attribute_id = attribute.pretty_id
		qry = objects.Question.query(objects.Question.visible == True)	
		if attribute.type == 'job':
			qry = qry.filter(objects.Question.jobs_pretty == attribute_id)
		elif attribute.type == 'topic':
			qry = qry.filter(objects.Question.topics_pretty == attribute_id)
		elif attribute.type == 'company':
			qry = qry.filter(objects.Question.companies_pretty == attribute_id)
		count = self.count_all(qry)	
		previous_count = attribute.question_count
		refresh_time = attribute.last_refresh
		if refresh_time and count != 1000:
			s = refresh_time.strftime('%B %d, %Y')
		else:
			s = "never"
		attribute.question_count = int(count)
		attribute.last_refresh = datetime.now()
		attribute.image = None
		method_db.putObject(attribute)
		if previous_count != count:
			self.response.out.write('<strong>')
		self.response.out.write('Refreshed ' + attribute.text + ' from ' + str(previous_count) + ' to + ' + str(count) + '.  Last refresh at ' + s + '<br/>')
		if previous_count != count:
			self.response.out.write('</strong>')	

	def get(self):
		pid = method_url.getStringParam(self, 'pid')
		if pid:
			attribute = method_question.getAttributeWithPid(pid)
			self.refreshAttribute(attribute)
		else:
			attributes = objects.Attribute.query().order(objects.Attribute.last_refresh).fetch(50)
			for attribute in attributes:
				self.refreshAttribute(attribute)
			
		self.response.out.write('Refresh Done')
		
