from arktotalwealth.overview.models import *
from django.contrib import admin

class OverviewPageAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug':('title',)}
    list_display= ('__unicode__','parent','priority','active','landingpage','landing_tooltip')
    list_editable = ('parent','priority','active','landingpage','landing_tooltip')
    list_filter = ('parent','active','landingpage','landing_tooltip')
    filter_horizontal = ('action_links',)
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]

admin.site.register(OverviewPage, OverviewPageAdmin)