#Overview
wear is meant to be a web app with lots of different sub apps.  Available sub-apps will change based on incoming url.  For example, csi.example.com will have one set of sub-apps available and pcsvcs.example.com will have a different set.  Sub-apps should be shown in different tabs.

# Features
the web app should have the following features:
* Authentication: some pages should be accessible without authentication.  Those pages will not have any "sign in" link to them.  Other pages should be available through authentication only.
* Branding:  the app may need to look like web sties from other customers.  Therefore it should have the following:
** configurable logo
** similar colors and fonts
* Configuration based on config file:  there are multiple parts of the system and ideally they would use the same the json config file.
* rest server: at some point the django app should replace the current flask rest server

# Milestones
The app and its design are a work in progress.  Here are some first known milestones

## Milestone 1: Basic Framework
Milestone 1 will create the basic framework for the app.  It should have these features:
* basic django app with instructions on how to install/deploy on a clean server
* config file: app should read file apptworks.json to get config info and info read based on url sub-domain.  There should be a dev override for subdomain name for test purposes but it should turn itself off for prod system by reading the domain name (e.g. if domainName == 'appointment.works': subdomain = subdomain else subdomain = 'domain1')
* branding: logo and css files configurable; path gotten from config file
* unauthenticated page: one page that says "Hello unathenticated World"  Page should have logo but no sign in link
* login page: standard login page asking for user/pwd.  No need for a new account option or fb or openId access or any other third party authentication
* db stored user info: credentials sohuld be stored in a mysql db.  Data stored sohuld include first name, last name, email and access level.
* access levels: features need to be dependent on user access level.  Currently there should be two levels:  "ADMIN" user will have everything, including a "create user" and "change user" feature that allows changing any user's pwd.
"POWER" user will have everything except the "create user" and "change user" options.  There is no need for POWER users to be able to change their own settings.  All user admin is done by ADMIN.
* three sample sub-apps.  They can just say "Hello \[subdomain] World from Sub app \[#]"
* two subdomains listed in config file: #1 should have sub-apps 1 and 2; #2 should have sub-apps 3 and 2, in that order


## Milestone 2: Report sub-app
Milestone 2 will have the first sub-app.  The app will be a reporting system that can create drill-down reports that wil ljoin tables from multiple mysql databases.  Features:
* accessible data is dependent on subdomain
* available search/report options are based on a config file
* drill-down fields and subsequent queries are based on a config file.
* ability to export reports to tab separated values
* ability to save report settings

## Milestone 3: rest server
Milestone 3 is to convert the flask rest app to django but add authentication for some of the calls.


