/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	JS Library.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
ieHover = function() {
	var ieEls = document.getElementById("page").getElementsByTagName("LI");
	for (var i=0; i<ieEls.length; i++) {
		ieEls[i].onmouseover=function() { this.className+=" hover"; }
		ieEls[i].onmouseout=function() { this.className=this.className.replace(new RegExp(" hover\\b"), ""); }
	}
};
if (window.attachEvent) window.attachEvent("onload", ieHover);
try{document.execCommand("BackgroundImageCache",false,true);}catch(err){}
jQuery(document).ready(function() {
	jQuery('input[value]').each(function(){
		if(this.type == 'text' || this.type == 'password') {
			jQuery(this).focus(function(){ if (this.value == this.defaultValue) { this.value = ''; }
			}).blur(function(){ if (!this.value.length) { this.value = this.defaultValue; }});
		}
	});
	jQuery('textarea').each(function(){
		jQuery(this).focus(function(){ if (this.value == this.defaultValue) { this.value = ''; }
		}).blur(function(){ if (!this.value.length) { this.value = this.defaultValue; }});
	});
});