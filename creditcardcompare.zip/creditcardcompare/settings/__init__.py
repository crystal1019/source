import locale, logging, os
from ConfigParser import ConfigParser


PROJECT_DIR = os.path.dirname(os.path.dirname(__file__))
conf = ConfigParser()
conf.read(os.path.join(PROJECT_DIR, '../conf', 'ccc.conf'))

try:
    locale.setlocale(locale.LC_ALL, 'en_AU')
except locale.Error:
    try:
        locale.setlocale(locale.LC_ALL, 'en_AU.UTF-8')
    except locale.Error:
        pass

DEBUG = False
TEMPLATE_DEBUG = DEBUG

ADMINS = (
    ('Noel', 'tellnoel@gmail.com'),
    ('Andy Boyd', 'boydcreative@googlemail.com'),
)
MANAGERS = ADMINS

SENDGRID = {
    'EMAIL_HOST': 'smtp.sendgrid.net',
    'EMAIL_HOST_USER': conf.get('sendgrid', 'EMAIL_HOST_USER'),
    'EMAIL_HOST_PASSWORD': conf.get('sendgrid', 'EMAIL_HOST_PASSWORD'),
    'EMAIL_PORT': 587,
    'EMAIL_USE_TLS': True,
}

DATABASES = {
    'default': {
        'NAME': conf.get('database', 'NAME'),
        'ENGINE': 'django.db.backends.mysql',                      
        'USER': conf.get('database', 'USER'),
        'PASSWORD': conf.get('database', 'PASSWORD'),
        'HOST': conf.get('database', 'HOST'),
    },
}

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-AU'
TIME_ZONE = 'Australia/Sydney'
USE_I18N = False
USE_ETAGS = True
APPEND_SLASH = False
ROOT_URLCONF = 'offers.urls'
SECRET_KEY = conf.get('keys', 'SECRET_KEY')
MEDIA_ROOT = os.path.join(PROJECT_DIR, '../../public_html/media')
STATIC_ROOT = os.path.join(PROJECT_DIR, '../../public_html/static')

STATICFILES_DIRS = (
    os.path.join(PROJECT_DIR, 'static'),
)
# List of finder classes that know how to find static files in
# various locations.
STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
#    'django.contrib.staticfiles.finders.DefaultStorageFinder',
    'compressor.finders.CompressorFinder',
)
# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'offers.helpers.template.loaders.WithMobileLoader',
    'django.template.loaders.app_directories.Loader',
#     'django.template.loaders.eggs.load_template_source',
)
MIDDLEWARE_CLASSES = (
    'offers.core.middleware.RedirectMiddleware',
    'offers.helpers.template.middleware.SpacelessMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'reversion.middleware.RevisionMiddleware',
    'offers.tools.flatpages.middleware.FlatpageFallbackMiddleware',
    'offers.helpers.lead.middleware.DownloadMiddleware',
#    'debug_toolbar.middleware.DebugToolbarMiddleware',
    'offers.helpers.template.middleware.MobileMiddleware',
)
TEMPLATE_CONTEXT_PROCESSORS = (
    'django.contrib.auth.context_processors.auth',
    'django.contrib.messages.context_processors.messages',
    'django.core.context_processors.debug',
#    'django.core.context_processors.i18n',
    'django.core.context_processors.media',
    'django.core.context_processors.request',
    'offers.core.context_processors.categories',
    'offers.core.context_processors.sites',
    'django.core.context_processors.static',
    'offers.tools.flatpages.context_processors.anchors',
)
INSTALLED_APPS = [
    'django.contrib.auth',
    'django.contrib.admin',
    'django.contrib.contenttypes',
    'django.contrib.flatpages',
    'django.contrib.humanize',
    'django.contrib.redirects',
    'django.contrib.sessions',
    'django.contrib.sitemaps',
    'django.contrib.sites',
    'django.contrib.staticfiles',
    'django.contrib.webdesign',
    
    'compressor',  # https://github.com/django-compressor/django-compressor/archive/develop.zip
    'django_markwhat',
    'fts',  # functional tests
    'nested_inlines',  # https://github.com/noelpur/django-nested-inlines/archive/master.zip
    'offers.core',
    'reversion',
    'robots',  # https://github.com/jezdez/django-robots/archive/master.zip
    'slimmer',
    'storages',  # https://github.com/iserko/django-storages/archive/master.zip
    
    'offers.helpers.boyd',
    'offers.helpers.lead',
    'offers.helpers.messages',
    'offers.helpers.template',
    
    'offers.tools.beatcard',
    'offers.tools.calculator',
    'offers.tools.datagovau',
    'offers.tools.flatpages',
    'offers.tools.lightbox',
    'offers.tools.rate_alert',
    'offers.tools.reviews',
    'offers.tools.smart_search',
    
    'offers.utils.cache_admin',
    'offers.utils.chronograph',
    'offers.utils.data_cache',
    'offers.utils.notifier',
    'offers.utils.sites',
]

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
    }
}

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '127.0.0.1:11211',
    }
}
CACHE_MIDDLEWARE_SECONDS = 60*60
CACHE_MIDDLEWARE_KEY_PREFIX = 'ccc-prod'

GLOBAL_LOG_LEVEL = logging.CRITICAL

#==============================================================================
# Application settings
#==============================================================================

EMAIL_CONFIRMATION_DAYS = 7
#COMMENTS_APP = 'reviews'
REVIEW_MODERATOR = "team@creditcardcompare.com.au"
AUTH_PROFILE_MODULE = "offers.core.AuthorProfile"

#WEB_ROOT = os.path.join(project_dir,'..','..','public_html', 'cache')
#STATIC_GENERATOR_URLS = (
#    r'^/balance-transfer-credit-cards.php$',
#)

ROBOTS_USE_SITEMAP = False

FB_CLIENT_ID = conf.get('facebook', 'FB_CLIENT_ID')
FB_CLIENT_SECRET = conf.get('facebook', 'FB_CLIENT_SECRET')
FB_NAMESPACE = conf.get('facebook', 'FB_NAMESPACE')

AWS_ACCESS_KEY_ID = conf.get('aws', 'AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = conf.get('aws', 'AWS_SECRET_ACCESS_KEY')
AWS_STORAGE_BUCKET_NAME = conf.get('aws', 'AWS_STORAGE_BUCKET_NAME')
AWS_S3_CUSTOM_DOMAIN = conf.get('aws', 'AWS_S3_CUSTOM_DOMAIN')
AWS_S3_SECURE_URLS = False
AWS_HEADERS = {
    'Cache-Control': 'max-age=2592000',
}
AWS_IS_GZIPPED = True

BITLY_TOKEN = 'd49a95709a372135fc1946895849f29cd51f4205'

DEFAULT_FILE_STORAGE = 'offers.utils.s3utils.MediaS3BotoStorage' 
STATICFILES_STORAGE = 'offers.utils.s3utils.StaticS3BotoStorage'
COMPRESS_STORAGE = 'offers.utils.s3utils.CompressedS3BotoStorage'
STATIC_URL = 'http://%s/static/' % AWS_S3_CUSTOM_DOMAIN
MEDIA_URL = 'http://%s/media/' % AWS_S3_CUSTOM_DOMAIN
ADMIN_MEDIA_PREFIX = STATIC_URL + 'moneycompare.com.au/admin_media/'

COMPRESS_CSS_FILTERS = [
    'compressor.filters.css_default.CssAbsoluteFilter',
    'compressor.filters.cssmin.CSSMinFilter',
]

#==============================================================================
# Site specific settings
#==============================================================================
HOMEPAGE_CATEGORY = {
    'creditcardcompare.com.au': 'credit-card-compare-home',
    'frequentflyercreditcards.com.au': 'frequent-flyer-homepage',
    'savingup.com.au': 'home-page',
}
STATES = (
    (1, 'New South Wales'),
    (2, 'Victoria'),
    (3, 'Queensland'),
    (4, 'South Australia'),
    (5, 'Western Australia'),
    (6, 'Tasmania'),
    (7, 'Northern Territory'),
    (8, 'Australian Capital Territory'),
)
