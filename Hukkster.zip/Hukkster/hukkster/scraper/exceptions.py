class HukksterTooManyOptions(Exception):
    """Raised when a website is supported but user tries to hukk non-product page."""
    def __init__(self, domain, url, status=404):
        self.domain = domain
        self.url = url
        self.status = status
        self.message = {
            'data': {
                'text':'Please click on a specific product and then try hukking again.',
                'host': self.domain,
                'footer-right': 'See our <a href="{{core_host}}/faq" target="_blank">FAQ</a> or <a href="#" class="close">Return to shopping</a>',
                'title': 'So many options!',
                'url': self.url
            },
            'status': self.status,
            'msg': 'unsupported page: Host "%s" is supported, but "%s" is not an item page' % (self.domain, self.url),
            'path': '/find',
        }


class HukksterNotSupported(Exception):
    """Raised when a website is not supported by Hukkster."""
    def __init__(self, domain, url, status=404):
        self.domain = domain
        self.url = url
        self.status = status
        self.message = {
            'data': {
                'host': self.domain,
                'footer-left': '<a href="{{core_host}}/featured-stores" target="_blank">View Featured Store List</a>',
                'text': 'This site isn\'t working with our bookmarklet. We will let you know when this site is supported',
                'footer-right': '<a href="#" class="close">Return to shopping &raquo;</a>',
                'title': 'Uh-oh!',
                'url': url
            },
            'msg': 'unsupported store: Host "%s" in "%s" is not supported (yet!)' % (self.domain, self.url),
            'path': '/find',
            'status': self.status
        }


class HukksterTechnicalDifficulties(Exception):
    """Raised when something weird happens (network or parsing errors)."""
    message = {
        'data': {
            'title': 'Uh-oh!',
            'text': 'Sorry, we are experiencing technical difficulties. Please <a href="mailto:questions@hukkster.com">email us</a> and we\'ll help you troubleshoot this issue.'
        },
        'status': 500,
        'msg': 'not jsonp',
        'path': '/find'
    }
