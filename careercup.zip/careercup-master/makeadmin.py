import masterpage

import method_url
import method_db
import method_user
	
class MakeAdmin(masterpage.MasterPage):

	def post(self):
		if not method_user.userIsAdmin():
			self.response.out.write("You must be logged in as an administrator.")
			return
		
		id = method_url.getId(self)	
		user = method_user.getUserWithId(id)
		if user:
			if user.admin:
				user.admin = False
			else:
				user.admin = True
			method_db.putObject(user)

		self.redirect('/user?id=' + str(user.uid))
	
	def get(self):
		if not method_user.userIsAdmin():
			self.response.out.write("You must be logged in as an administrator.")
			return
		
		id = method_url.getId(self)		   
		user = method_user.getUserWithId(id)
		if method_url.getStringParam(self, 'ban'):
			user.banned = True
			user.banned_message = method_url.getStringParam(self, 'ban')
			method_db.putObject(user)
			self.response.out.write('This user has been banned.')
			return
		
		template_values = {
			'displayname': user.name,
			'is_admin': user.admin,
		}		 
		
		self.pushPage(template_values, 'Make Admin', 'html/makeadmin.html')	  
		
