from django.conf.urls.defaults import *

urlpatterns = patterns('berowrawatersinn.restaurant.views',
        (r'^$', 'home'),
        (r'^(?P<slug>.*).html$', 'home'),
                       
)