from google.appengine.ext.webapp import template
import os

import masterpage

import method_db
import method_question
import method_cache
		
class ViewRss(masterpage.MasterPage):  

	def getQuestions(self):
		# Get questions.
		return method_db.addInfoToList(method_question.getRecentQuestions())
		
	def get(self):
		rss = method_cache.getObjectForTypeAndKey('rss', None)
		if not rss:
			questions = self.getQuestions()
		
			template_values = {
				'questions': questions,
			}
			path = os.path.join(os.path.dirname(__file__), 'html/rsstemplate.xml')
			rss = template.render(path, template_values) 
			method_cache.setObjectForTypeAndKey('rss', None, rss, 43200)
		self.response.out.write(rss)