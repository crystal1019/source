from django.conf import settings

def anchors(request):
    if settings.SITE_ID == 8:  # creditcardcompare.com.au
        return {'anchors': ['CreditCardCompare.com.au', 'CreditCardCompare', 'www.CreditCardCompare.com.au', 'http://www.creditcardcompare.com.au']}
    return {}
