from django.template import Library

register = Library()

@register.filter
def deslugify(value):
    return value.replace('-', ' ')
