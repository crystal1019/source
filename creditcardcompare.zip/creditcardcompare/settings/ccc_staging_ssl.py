import sys
from settings.ccc_staging import *


EMAIL_SUBJECT_PREFIX = '[STAGING CCC SSL ALERT]'
AWS_S3_SECURE_URLS = True
AWS_S3_CUSTOM_DOMAIN = '%s.s3.amazonaws.com' % AWS_STORAGE_BUCKET_NAME
STATIC_URL = '//%s/static/' % AWS_S3_CUSTOM_DOMAIN
MEDIA_URL = '//%s/media/' % AWS_S3_CUSTOM_DOMAIN
IMAGE_URL = MEDIA_URL[:-1]
ADMIN_MEDIA_PREFIX = STATIC_URL + 'admin/'
COMPRESS_ENABLED = False
