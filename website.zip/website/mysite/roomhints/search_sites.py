import haystack

haystack.autodiscover() 
