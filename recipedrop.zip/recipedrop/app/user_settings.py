from django.core.context_processors import csrf
from django.shortcuts import render_to_response, redirect
from django.template import RequestContext
from django.contrib.auth.decorators import login_required

import forms
from models import Setting

@login_required
def settings(request):
    c = RequestContext(request)
    c.update(csrf(request))

    if request.method == 'POST':
        if request.POST['action'] == 'update_settings':
            form = forms.SettingsForm(request.POST)
            if form.is_valid():
                save_settings(form, request.user)
                return redirect('/?msg=settings_saved')

        elif request.POST['action'] == 'change_password':
            form = forms.ChangePasswordForm(request.POST)
            if form.is_valid():
                if change_password(form, request.user):
                    return redirect('/?msg=pwd_changed')

    settings = settings_dict(request.user)

    settings_form = forms.SettingsForm(initial = settings)
    change_pwd_form = forms.ChangePasswordForm()

    c.update({
            'settings_form': settings_form,
            'change_pwd_form': change_pwd_form,
            })
    return render_to_response('settings.html', c)

def change_password(form, user):
    old_pwd = form.cleaned_data['current_password']
    new_pwd = form.cleaned_data['new_password']

    if user.check_password(old_pwd):
        user.set_password(new_pwd)
        user.save()
        return True
    else:
        return False

def settings_dict(user):
    settings = Setting.objects.filter(
        user = user
        )
    return dict(map(lambda setting: [setting.key, setting.value], settings))

def default_settings_dict():
    fields = forms.SettingsForm().fields
    for key in fields:
        fields[key] = fields[key].initial
    return fields

def save_settings(form, user):
    settings = Setting.objects.filter(
        user = user
        )
    
    for field in form.fields:
        existed = False
        for setting in settings:
            if setting.key == field:
                setting.value = form.cleaned_data[field]
                setting.save()
                existed = True

        if not existed:
            setting = Setting.objects.create(
                user = user,
                key = field,
                value = form.cleaned_data[field]
                )
            setting.save()
