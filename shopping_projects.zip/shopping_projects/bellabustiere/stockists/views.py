'''
@author: chaol
'''

from django.template import Context, loader, RequestContext
from django.http import HttpResponse, HttpResponseRedirect
import datetime, time
from models import *
from django.db import connection

import pprint, hashlib


from django.core.cache import cache
from django.core.paginator import *
from django.contrib.auth import authenticate
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout

from django.contrib.auth.models import AnonymousUser

from django.conf import settings

from bellabustiere import common

def getRegionCategory(ss):
    thecategory = []
    for x in ss:
        for xx in x.category.all():
            if xx not in thecategory:
                thecategory.append(xx) 
    return thecategory

def stockists(request, region, category=None):
    t = loader.get_template('stockists.html')
    s = Stockist.objects.filter(sites=settings.SITE_ID,region__iexact=region).order_by("state", "suburb") if not category else Stockist.objects.filter(sites=settings.SITE_ID,region__iexact=region, category__slug=category).order_by("state", "suburb")
    
    ss = Stockist.objects.filter(sites=settings.SITE_ID,region__exact='AUSTRALIA')
    aucategory = getRegionCategory(ss)

    ss = Stockist.objects.filter(sites=settings.SITE_ID,region__exact='INTERNATIONAL')
    intcategory = getRegionCategory(ss)
    
    openpath = ["stockists", region]
    c = RequestContext(request,common.commonDict({
        'stockists': s,
        'openpath': openpath,
        
        'aucategory':aucategory,
        'intcategory':intcategory,
        'region':region,
        'category':category,
    }, request))
    return HttpResponse(t.render(c))
