import cgi
import math

def createUrlWithAttribute(me, key, value):
	if not('?' in me.request.url):
		return me.request.url + '?' + key + '=' + value
	urlparts = me.request.url.split('?',1)
	if urlparts is None or len(urlparts) <= 1:
		return None
	suffix = urlparts[1]
	if suffix is None or suffix == '':
		return None
	params = cgi.parse_qs(suffix)
	if params is None or len(params) == 0:
		return None
	# TODO(gayle): Check if it's an int 
	values = [value]
	params[key] = values
	
	url = urlparts[0] + '?'
	count = 0
	for param in params:
		if count > 0:
			url += '&'
		url += param + '=' + params[param][0]
		count = count + 1
	return url
	
def getUrlWithoutPage(me):
	root_url = me.request.url
	if 'n=' in root_url:
		page_num = getStringParam(me, 'n')
		if '?n='+str(page_num) in root_url:
			root_url = root_url.replace('?n=' + str(page_num), '?')
		elif '&n='+str(page_num) in root_url:
			root_url = root_url.replace('&n=' + str(page_num), '') + '&'
	else:
		if '?' in root_url:
			root_url = root_url + '&'
		else:
			root_url = root_url + '?'
	return root_url

def getStringParamFromUrl(url, key):
	urlparts = url.split('?',1)
	if urlparts is None or len(urlparts) <= 1:
		return None
	suffix = urlparts[1]
	if suffix is None or suffix == '':
		return None
	params = cgi.parse_qs(suffix)
	if params is None or len(params) == 0:
		return None
	# TODO(gayle): Check if it's an int 
	if key in params:
		return params[key][0]
	else:
		return None	

def getStringParam(me, key):
	return getStringParamFromUrl(me.request.url, key)

def getIntParamFromUrl(url, key):
	s = getStringParamFromUrl(url, key)
	if not(s):
		return None
	try:
		return long(s)
	except:
		return None

def getFirstPageOfSet(set_size, current_page):
	return current_page - current_page % set_size
	
def getLastPageOfSet(set_size, current_page):
	return getFirstPageOfSet(set_size, current_page) + set_size - 1

def doPageCalculations(has_more_sets, page_num, pages_per_set, per_page, count):
	first_page_of_set = getFirstPageOfSet(pages_per_set, page_num)
	last_page_of_set = getLastPageOfSet(pages_per_set, page_num)	
	
	if not has_more_sets:
		next_set = -1
	else:
		next_set = last_page_of_set + 1
		
	pages_in_set = int(math.ceil(count / per_page))
	last_page_of_set = min(last_page_of_set, first_page_of_set + pages_in_set)

	if last_page_of_set > page_num:
		next_page = page_num + 1
	else:
		next_page = -1
	return {'first_page_of_set': first_page_of_set + 1,
			'last_page_of_set': last_page_of_set + 1,
			'next_set': next_set + 1,
			'next_page': next_page + 1,
			'previous_set': first_page_of_set,
			'current_page': page_num + 1,
			'pages_all': range(first_page_of_set + 1, last_page_of_set + 2)}

def getIntParam(me, key): 
	return getIntParamFromUrl(me.request.url, key)
		
def getBooleanParam(me, key):
	v = getIntParam(me, key)
	if v == 1:
		return True
	return False
		
def getId(me):
	return getIntParam(me, 'id')

def getPid(me):
	return getStringParam(me, 'pid')	
	
def getUrlForComment(comment):
	url = getUrlWithType(comment.type)
	if not url:
		url = 'question' # just taking a guess...
	if comment and comment.ancestor_id:
		url = '/' + url + '?id=' + str(comment.ancestor_id)
	else:
		url = ''
	return url
	
def getUrlWithType(type):
	if type == 'question':
		return 'question'
	elif type == 'attribute':
		return 'page'
	elif type == 'forum' or type == 'forumpost':
		return 'forumpost'			  
	elif type == 'user':
		return 'user'	
	return None	  