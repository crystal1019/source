from django.apps import AppConfig

class SiteConfig(AppConfig):
    name = 'offers.utils.sites'
    label = 'custom_sites'

default_app_config = 'offers.utils.sites.SiteConfig'