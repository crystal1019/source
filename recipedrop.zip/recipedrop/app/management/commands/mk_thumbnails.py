from django.core.management.base import BaseCommand, CommandError
from django.conf import settings
from app.models import RecipeImage
import StringIO
import boto
from PIL import Image
import os
import sys
import math
from io import BytesIO


METAMIME = {'JPEG':{'Content-Type': 'image/jpeg'},
            'PNG': {'Content-Type': 'image/png'},
            '*Unknown*':{'Content-Type': 'application/octet-stream'},
            }


def check_contents_mime(b,contents):
    try:
        file = BytesIO(contents)
        im = Image.open(file)
        return im.format
    except IOError:
        return '*Unknown*'


class Command(BaseCommand):
    def handle(self, *args, **options):
        if not settings.LIVE:
            raise CommandError("Must be run on live site!")

        width = int(args[0])
        height = int(args[1])

        ris = RecipeImage.objects.all()
        s3 = boto.connect_s3()
        bucket = s3.create_bucket(settings.S3_BUCKET)
        for ri in ris:
            #if not 'ajdun' in ri.upload:
            #    continue
            print ri.upload

            try:
                path = ri.upload
#            if not bucket.get_key('%s_thumbnail' % path):
                print 'Making thumbnail of %s' % path
                _, ext = os.path.splitext(path)
                ext = ext[1:]
                if ext.upper() == u'JPG':
                    ext = 'JPEG'
                contents = bucket.get_key(path).get_contents_as_string()
                contents = StringIO.StringIO(contents)
                img = Image.open(contents)

                img.thumbnail((width, max(height, width)), Image.ANTIALIAS)

                (w, h) = img.size
#            resized = img.resize((width,
#                                  int(((width * 1.0) / w) * h)))

                if w < width:
                    img = img.resize((width,
                                      int(math.ceil(((width * 1.0) / w) * h))),
                                     Image.ANTIALIAS)
                (w, h) = img.size
                if h < height:
                    img = img.resize((int(math.ceil(((height * 1.0 / h) * w))),
                                      height),
                                      Image.ANTIALIAS)
                (w, h) = img.size

                img = img.crop((0, 0, width, height))

#                img.thumbnail((width, width), Image.ANTIALIAS)

                out_resized = StringIO.StringIO()
                img.save(out_resized, ext)
                key = bucket.new_key('%s_thumbnail' % path)
                key.set_contents_from_string(out_resized.getvalue())

                key.set_acl('public-read')

                image_format = check_contents_mime(bucket, out_resized.getvalue())    
                print "format=",image_format
                newmime = METAMIME.get(image_format,'application/octet-stream')
                key.copy(key.bucket, key.name, preserve_acl=True, metadata=newmime)

            except:
                print "Unexpected error:", sys.exc_info()[0]
