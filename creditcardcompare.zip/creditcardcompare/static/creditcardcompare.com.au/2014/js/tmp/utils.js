//////////////////////////////////////////////////
//////////////////////////////////////////////////
// ----------------------->
var $u = (function () {
    function $u() {
    }
    $u.isArray = //////////////////////////////////////////////////
    //////////////////////////////////////////////////
    // -----------------------> GLOBAL
    function (item) {
        return item.constructor == Array;
    };
    $u.isString = function (item) {
        return typeof (item) == 'string';
    };
    $u.isNumber = function (item) {
        return typeof (item) == 'number';
    };

    $u.isType = function (Class, Instance) {
        try  {
            return Class.prototype.isPrototypeOf(Instance);
        } catch (e) {
        }
        return false;
    };

    $u.destroy = function (item) {
        if (item) {
            if (item.hasOwnProperty('dispose')) {
                item.dispose();
            }
            for (var key in item) {
                delete item[key];
            }
        }
    };

    $u.applyParams = //////////////////////////////////////////////////
    //////////////////////////////////////////////////
    // -----------------------> OBJECT
    function (target, params) {
        for (var p in params) {
            target[p] = params[p];
        }
    };

    $u.applyAll = function (target, key, value) {
        for (var p in target) {
            target[p][key] = value;
        }
    };

    $u.copyTo = function (source) {
        var args = [];
        for (var _i = 0; _i < (arguments.length - 1); _i++) {
            args[_i] = arguments[_i + 1];
        }
        for (var i = 1; i < arguments.length; i++) {
            $u.applyParams(arguments[i], source);
        }
    };

    $u.searchByParam = function (source, paramName, value) {
        for (var n in source) {
            if (source[n][paramName] == value) {
                return source[n];
            }
        }
        return null;
    };

    $u.pull = //////////////////////////////////////////////////
    //////////////////////////////////////////////////
    // -----------------------> DIGS
    function (source, path) {
        try  {
            var p = path.split(".");
            var l = p.length;
            var r = source[p[0]];
            for (var i = 1; i < l; i++) {
                r = r[p[i]];
            }
            return r;
        } catch (e) {
        }
        return null;
    };

    $u.push = function (source, path, value) {
        try  {
            var p = path.split(".");
            var l = p.length - 1;
            var r = source[p[0]];
            for (var i = 1; i < l; i++) {
                r = r[p[i]];
            }
            r[p[i]] = value;
        } catch (e) {
        }
        return source;
    };

    $u.pushBranch = function (source, path, value) {
        try  {
            var p = path.split(".");
            var l = p.length - 1;
            var r = source;
            for (var i = 0; i < l; i++) {
                if (r[p[i]]) {
                    r = r[p[i]];
                } else {
                    r = r[p[i]] = {};
                }
            }
            r[p[l]] = value;
        } catch (e) {
        }
        return source;
    };

    $u.searchAndSplice = //////////////////////////////////////////////////
    //////////////////////////////////////////////////
    // -----------------------> ARRAY
    function (source, item) {
        var i = source.indexOf(item);
        if (i != -1) {
            source.splice(i, 1);
            return true;
        }
        return false;
    };

    $u.randomize = function (source) {
        var currentIndex = source.length, temporaryValue, randomIndex;
        while (0 !== currentIndex) {
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;
            temporaryValue = source[currentIndex];
            source[currentIndex] = source[randomIndex];
            source[randomIndex] = temporaryValue;
        }
    };

    $u.eachCall = function (src, func, args) {
        for (var i = 0; i < src.length; i++) {
            src[i][func].apply(null, args);
        }
    };
    $u.safeEachCall = function (src, func, args) {
        for (var i = 0; i < src.length; i++) {
            try  {
                src[i][func].apply(null, args);
            } catch (e) {
            }
        }
    };

    $u.getTextBetween = //////////////////////////////////////////////////
    //////////////////////////////////////////////////
    // -----------------------> STRING
    function (source, char1, char2) {
        var s = source.indexOf(char1);
        if (s == -1) {
            return "";
        }
        var e = source.indexOf(char2 || char1, s + 1);
        return source.substring(s + 1, e < 0 ? Number.MAX_VALUE : e);
    };

    $u.del = //////////////////////////////////////////////////
    //////////////////////////////////////////////////
    // -----------------------> FUNCTION
    function (thisObj, func) {
        return function () {
            return func.apply(thisObj, arguments);
        };
    };
    $u.del2 = function (thisObj, name) {
        return function () {
            return thisObj[name].apply(arguments);
        };
    };

    $u.readTag = function (name, compileTypes) {
        var a = document.getElementsByTagName(name);
        if (a.length > 0) {
            var r = this.htmlToJSON(a[0], null, compileTypes);
        }
        return r;
    };
    $u.readTags = function (name, compileTypes) {
        var a = document.getElementsByTagName(name);
        var t = [];
        for (var i = 0; i < a.length; i++) {
            t.push(this.htmlToJSON(a[i], null, compileTypes));
        }
        return t;
    };

    $u.htmlToJSON = function (tag, sub, parseTypes) {
        if (typeof sub === "undefined") { sub = null; }
        sub = sub || this._defaultTagChild;
        var result = {};

        for (var attr, i = 0, attrs = tag.attributes, l = attrs.length; i < l; i++) {
            attr = attrs.item(i);
            var data = attr.nodeValue;
            if (parseTypes && parseTypes[attr.nodeName]) {
                try  {
                    data = parseTypes[attr.nodeName](data);
                } catch (e) {
                    // console.log('Tag parse:error:could not parse attr [' + attr.nodeName + ']');
                    data = attr.nodeValue;
                }
            }
            result[attr.nodeName] = data;
        }

        // ------> CHILDREN
        var num = tag.children.length;
        if (num > 0) {
            var arr = [];
            for (var i = 0; i < num; i++) {
                arr.push(this.htmlToJSON(tag.children[i], sub, parseTypes));
            }
            result[sub] = arr;
        }
        return result;
    };
    $u._defaultTagChild = 'children';
    return $u;
})();
//# sourceMappingURL=utils.js.map
