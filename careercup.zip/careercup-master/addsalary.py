import datetime

import objects
import masterpage

import method_db
import method_question
import method_user
import method_date
import method_cache
	
class AddSalary(masterpage.MasterPage):
	def validate(self, list):
		for a in list:
			if a <= 0:
				return False
		return True		  
					
	def post(self):
		if self.isSpammer():
			return		
		
		#  Get logged in user
		user = method_user.getLoggedInUser()
			
		company_id = self.mergeSelectedAttributes('dropdownCompanies[]', 'OtherCompany', 'company')
		
		salary = objects.SalaryInfo()
		
		# Get author info
		if user:
			author_id = user.uid
			author_image = user.image
			author_name = user.name
		else:
			author_name = self.request.get('Name')
			author_id = None
			author_image = None
			if not(author_name):
				author_name = 'Anonymous'
				
		salary.author_name = author_name
		salary.author_id = author_id
		salary.author_image = author_image	
		
		# Add attribute info
		salary.company_id = company_id
		
		salary.salary = self.request.get('Salary')								
		salary.team = self.request.get('Team')	
		salary.job_title = self.request.get('JobTitle');
		salary.country = self.getCountry()	
		salary.job_type = self.request.get('dropdownJobType')
		salary.location = self.request.get('Location')
		salary.salary_info = self.request.get('AboutOffer')
		salary.candidate_info = self.request.get('AboutCandidate')
		salary.education = self.request.get('Education')
		salary.work_experience = self.request.get('WorkExperience')
		salary.years_experience = self.request.get('YearsExperience')		
		salary.offer_date = datetime.datetime(int(self.request.get('dropdownOfferYear')), int(self.request.get('dropdownOfferMonth')), 3)
		method_db.putObject(salary, False)
		method_cache.clearObjectForTypeAndId('salaries', None)
		
		self.redirect('/salary')


	def getCountry(self):
		int_attribute = self.request.get('dropdownCountry')
		if int_attribute == '': # id is 0 -> "new" was selected
			return self.request.get('OtherCountry')
		else:
			return int_attribute

	def mergeSelectedAttributes(self, dropdown_id, textbox_id, type):
		new_attribute = self.request.get(textbox_id).strip()
		int_attribute = self.request.get(dropdown_id)
		if int_attribute == '': # id is 0 -> "new" was selected
			if new_attribute:
				pretty_id = method_question.addAttribute(new_attribute, type)
				return pretty_id
		else:
			return int_attribute

	def putErrorMessage(self, error_message):		
		control = self.request.get('lblError')
		control = error_message		  
		#self.response.out.write('<script>control = document.getElementById("lblError"); control.value = error_message; </script>')
	
		#path = os.path.join(os.path.dirname(__file__), 'html/addquestion.html')
		#self.response.out.write(template.render(path, template_values)) 
		
	
	def get(self):		
		body = method_cache.getObjectForTypeAndKey('salaries', None)
		jobs = method_question.getAttributesByTypeSorted('job', 'alpha')
		companies = method_question.getAttributesByTypeSorted('company', 'alpha')
				
		if not body:								
			salaries_html = method_cache.getObjectForTypeAndKey('salaries', None)
		
			salaries = objects.SalaryInfo.query(objects.SalaryInfo.visible == True).order(objects.SalaryInfo.company_id).order(-objects.SalaryInfo.offer_date)
			salaries2 = []
			countries = []
			for salary in salaries:
				salary = method_db.addInfoToObject(salary)
				if salary.country not in countries:
					countries.append(salary.country)
				attribute = method_question.getAttributeWithPid(salary.company_id)
				if attribute:
					salary.company_name = attribute.text
					if salary.offer_date:
						salary.offer_date_string = method_date.getMonthAndYearString(salary.offer_date)
					else:
						salary.offer_date_string = 'Unknown'
					salaries2.append(salary)					

			

			for a in jobs:
				a.selected = "0"
			for a in companies:
				a.selected = "0"
			
			template_values = {
				'jobs': jobs,
				'parent_tab': 'salary',	
				'countries': countries,
				'companies': companies,
				'salaries': salaries2,
			}		 
			
			body = self.getBody(template_values, 'html/control-salarylist.html')
			method_cache.setObjectForTypeAndKey('salaries', None, body)

		template_values = {'parent_tab': 'salary', 
							'salary_html': body,
							'jobs': jobs,
							'companies': companies,
							}
							
		self.pushPage(template_values, 'Software Engineering Salaries', 'html/addsalary.html')			  
		
