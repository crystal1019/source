from google.appengine.ext import db

import objects
import masterpage

import method_user
import method_url
import method_db
import method_question
import method_cache

from google.appengine.api import images

class EditAttribute(masterpage.MasterPage):	
		
	def post(self):
		# TODO(gayle): Do not require login.
		method_user.getLoggedInUser()
		if not(method_user.userIsAdmin()):
			self.redirectToLogin()
			return
		
		pid = method_url.getStringParam(self, 'pid')
		attribute = method_question.getAttributeWithPid(pid)
		
		if self.request.get('Submit'):
			attribute.text = self.request.get('name')
			method_db.putObject(attribute)
		elif self.request.get('Delete'):
			type = attribute.type
			if type == 'company':
				filter_text = 'companies_pretty ='
			elif type == 'job':
				filter_text = 'jobs_pretty ='
			else:
				filter_text = 'topics_pretty ='
			questions = objects.Question.query.filter(filter_text, attribute.uid)
			for question in questions:
				if type == 'company':
					question.companies_pretty.remove(attribute.pretty_id)
				elif type == 'job':
					question.jobs_pretty.remove(attribute.pretty_id)
				else:
					question.topics_pretty.remove(attribute.pretty_id)
				method_db.putObject(question)
			attribute.key.delete()
			method_question.clearAttributeCache(None)
		
		self.redirect('/editattribute?pid=' + str(attribute.pretty_id))
			
	def get(self):
		if not(method_user.userIsAdmin()):
			self.redirectToLogin()
			return		
		
		pid = method_url.getStringParam(self, 'pid')
		attribute = method_question.getAttributeWithPid(pid)
		if not attribute:
			self.displayError('No Attribute', 'No attribute found with this id.')
			return
		
		template_values = {
			'attribute': attribute,
		}		 
		
		self.pushPage(template_values, 'Edit Attribute', 'html/editattribute.html')   
		
