from django.contrib import admin
from models import *

admin.site.register(Locale)
admin.site.register(UserProfile)
admin.site.register(Organization)
admin.site.register(JobType)
admin.site.register(Job)
admin.site.register(JobTypeExample)
admin.site.register(File)