
-- Find a hint with a specific price
select h.id,h.price from roomhints_hint h where h.price=1995;
-- Find a hint of a showroom with a specific price
select p.id,h.id,h.price from roomhints_project p, roomhints_roomhint rh, roomhints_hint h where p.roomtype_id=2 and p.id=rh.project_id and  rh.hint_id = h.id and h.price=1995;
