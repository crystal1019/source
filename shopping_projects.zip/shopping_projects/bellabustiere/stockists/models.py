'''
@author: chaol
'''

from django.db import models
from django.contrib.sites.models import Site

class SellCategory(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField()
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name
    
    def get_absolute_url(self, region):
        return '/stockists/%s/%s.html' %(region,self.slug)
    
    def get_au_url(self):
        return self.get_absolute_url('AUSTRALIA')
    
    def get_int_url(self):
        return self.get_absolute_url('INTERNATIONAL')
    

class Stockist(models.Model):
    suburb = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    address2 = models.CharField(max_length=255,blank=True,null=True)
    postcode = models.CharField(max_length=10)
    state = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    fax = models.CharField(max_length=50,blank=True,null=True)
    email = models.EmailField(null=True)
    website = models.CharField(max_length=100,blank=True,null=True)
    region = models.CharField(max_length=50, choices=(("AUSTRALIA", "AUSTRALIA"), ("INTERNATIONAL","INTERNATIONAL")))
    category = models.ManyToManyField(SellCategory,blank=True,null=True)
    sites = models.ManyToManyField(Site)
    
    def __unicode__(self):
        return self.name
    



    