from django.conf.urls import patterns, include, url

urlpatterns = patterns(
    'app.schools.views',
    (r'^$', 'schools'),
    (r'^builder/', 'builder'),
    (r'^browse/', 'browse'),
    (r'^student_portal/', 'student_portal'),

)
