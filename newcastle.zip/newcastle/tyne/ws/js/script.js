var tmp_calendar, tmp_dialog;
$(document).ready(function(){
	
	tmp_calendar = new Calendar("container");
	tmp_dialog = new UserInfoDialog("first-dialog", tmp_calendar );
	tmp_calendar.initialize_calender();
});