'''Codes categorized in these items:
1. Has frontend
2. 
'''