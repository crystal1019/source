from django.contrib import admin
from arktotalwealth.component.models import *

class ActionLinkAdmin(admin.ModelAdmin):
	list_display = ('__unicode__','link')
	list_editable = ('link',)
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup_bold.js',]		  

admin.site.register(ActionLink, ActionLinkAdmin)
admin.site.register(GenericComponent)