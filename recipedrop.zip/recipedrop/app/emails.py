import boto

from django.core.mail import send_mail
from django.conf import settings
from django.core.urlresolvers import reverse

host = 'http://www.recipedrop.com'
from_addr = 'RecipeDrop <support@recipedrop.com>'

# TODO: put email bodies in templates

def send_comment(comment):
    subject = 'New comment on RecipeDrop'
    body = 'Hi, %s! %s commented on your recipe, %s: <br /><br />"%s"<br /><br />' % \
        (comment.recipe.author.profile.display_name,
         comment.author.profile.display_name,
         comment.recipe.title,
         comment.contents) + \
         '<a href="%s%s#%s">Click here to view it and reply.</a><br /><br />Best,<br />RecipeDrop' % \
         (host, reverse('recipe', args = [comment.recipe.id]), comment.id)

    send_mail(subject, body, from_addr, [comment.recipe.author.email])

def send_bookmark(bookmark):
    subject = 'New bookmark on RecipeDrop'
    body = 'Hi, %s! %s bookmarked your recipe, %s. ' % \
        (bookmark.recipe.author.profile.display_name,
         bookmark.user.profile.display_name, bookmark.recipe.title) + \
        '<a href="%s%s">Click here to view %s\'s profile.</a><br /><br />Best,<br />RecipeDrop' % \
        (host,
         reverse('user', args=[bookmark.user.id]),
         bookmark.user.profile.display_name)

    send_mail(subject, body, from_addr, [bookmark.recipe.author.email])

def send_comment_notification(comment, sub):
    subject = 'New comment on RecipeDrop'
    body = 'Hi, %s! There\'s a new comment on %s\'s recipe, %s. %s said,<br /><br />"%s"<br /><br /> ' % \
        (sub.subscriber.profile.display_name,
         comment.recipe.author.profile.display_name,
         comment.recipe.title,
         comment.author.profile.display_name,
         comment.contents
         ) + \
         '<a href="%s%s#%s">Click here to view it and reply.</a><br /><br />Best,<br />RecipeDrop' % \
         (host, reverse('recipe', args = [comment.recipe.id]), comment.id) + \
         '<br /><br /><small>' + \
         'You\'re receiving this email because you also commented on this recipe. ' + \
         '<a href="%s%s">Click here to unsubscribe.</a>' % \
         (host, reverse('recipe_comment_unsubscribe', args = [comment.recipe.id]))

    send_mail(subject, body, from_addr, [sub.subscriber.email])
        

def send_invite(invitee, message, inviter):
    inviter_url = reverse('user', args=[inviter.id])
    subject = 'You\'ve been invited to RecipeDrop!'
    body = 'Hello! %s has invited you to join <a href="%s">RecipeDrop</a>,' % (inviter.profile.display_name, host) + \
        ' a website to collect and share recipes.<br /><br />' + \
        '<a href="%s%s">View %s\'s profile</a> or <a href="%s">join now</a>.' % (host, inviter_url, inviter.profile.display_name, host) + \
        '<br /><br />'

    if message != '':
        body = body + 'Here\'s a message from %s:<br /><br />%s<br /><br />' % (inviter.profile.display_name, message)

    body = body + 'Best,<br />RecipeDrop'

    send_mail(subject, body, from_addr, [invitee])
