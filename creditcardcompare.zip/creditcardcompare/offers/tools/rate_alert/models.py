from django.db import models
from django.contrib.sites.models import Site
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from offers.helpers.lead.models import Lead


class Alert(models.Model):
    lead = models.ForeignKey(Lead)
    registered = models.DateField(auto_now_add=True)
    expiry = models.DateField(help_text='Balance Transfer Period expiry')
    duedate = models.DateField(help_text='Annual Fee due date')
    confirmed = models.BooleanField(default=True)
    site = models.ForeignKey(Site)
    # use ContentType to decouple from offers.core.models.Offer
    content_type = models.ForeignKey(ContentType)
    object_id = models.PositiveIntegerField()
    offer = GenericForeignKey('content_type', 'object_id')
    
    class Meta:
        ordering = ('expiry',)
    
    @property
    def email(self):
        return self.lead.email
    