import simplejson as json
import subprocess
import os
from roomhints.utils import make_unique
#from PIL import Image
import Image
from roomhints.crawler import crawl_hint, crawl_hint_clean
import re
import shutil

zoom = 1.8
def url2png(url,photo_seed):
    try:
        os.mkdir('/tmp/url2png')
    except Exception, e:
        # it probably exists already
        pass
    jsname = photo_seed + ".js"
    photoname = photo_seed + ".jpg"
    if url == None or url == "":
        ulr = "http://roomhints.com"
    contents = "var page = require('webpage').create();\n\
page.open('" + url + "', function () {\n\
    page.zoomFactor = " + str(zoom) + "\n\
    page.settings.userAgent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17';\n\
    //page.viewportSize = {width: document.body.clientWidth * " + str(zoom) + ", height: document.body.clientHeight * " + str(zoom) + "};\n\
    page.render('" + photoname + "');\n\
    phantom.exit();\n\
});\n\
"
    f = open(jsname, 'ab+')
    f.write(contents)
    f.close()
    p = subprocess.Popen('/home/roomhints/devel/RH/website/mysite/phantomjs-1.9.0-linux-i686/bin/phantomjs ' + str(jsname), shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    #results = json.loads(out)
    #return results
    return photoname

# PIL generates images in bad resolution
def crop(photoin,photoout,coordinates):
    imgin = Image.open(photoin)
    left = int(coordinates[0])
    top = int(coordinates[1])
    width = int(coordinates[2])
    height = int(coordinates[3])
    box = (left, top, left+width, top+height)
    area = imgin.crop(box)
    area.save(photoout)

def crop2(photoin,photoout,coordinates):
    left = int(coordinates[0])
    top = int(coordinates[1])
    width = int(coordinates[2])
    height = int(coordinates[3])
    p = subprocess.Popen("convert " + photoin + " " + str(width) + "x" + str(height) + "+" + str(left) + "+" + str(top) + " " + photoout, shell=True,
                         stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    response = p.communicate(input=the_input)[0]

def template2coordinates(template,fullimage):
    os.environ['DISPLAY'] = ':1'
    p = subprocess.Popen('export LD_LIBRARY_PATH=/usr/local/opencv-git/lib; /home/roomhints/devel/RH/imaging/test/templatematch_exit ' + str(template) + ' ' + str(fullimage), shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    out = out.strip('\n').split()
    coordinates = [ int(out[0]), int(out[1]), int(out[2]), int(out[3])]
    return coordinates
    #results = json.loads(out)
    #return results

def photo_zoom(photoin,photoout,zoom):
    increase_dpi = " -depth 300 -units pixelsperinch"
    increase_dpi = ""
    pixels = str(zoom*100) + "%"
    p = subprocess.Popen("convert " + photoin + increase_dpi + " -resize " + pixels + " " + photoout, shell=True,
                         stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    response = p.communicate(input=the_input)[0]

def sort_photos_by_size(all_imgs):
    return sorted(all_imgs, key=lambda entry: entry[0],reverse=True)

def url2price(url):
    data = dict()
    photo_seed = "/tmp/url2png/" + make_unique(36)
    f = open(photo_seed + '_url.txt','ab+')
    f.write(url + "\n")
    f.close()
    rendered_photo = url2png(url,photo_seed)
    crawl_price, crawl_name, crawl_source, crawl_photo_url, crawl_photo, crawl_all_imgs = crawl_hint(url)
    product_photo = crawl_photo
    product_photo_url = crawl_photo_url
    photo_cnt = 0
    photos_sorted = sort_photos_by_size(crawl_all_imgs)
    print ("photos_sorted are: " + str(photos_sorted) + "\n")
    was_ad = False
    is_ad = True
    while is_ad:
        shutil.copy(product_photo, photo_seed + "_template.jpg")
        zoom_photo = photo_seed + "_template_zoom.jpg"
        photo_zoom(product_photo, zoom_photo, zoom)

        # Check if the product image is an ad, ie that says 'super savings! 25% off your purchase Ends Wednesday Ender GAP25
        text = image2text(zoom_photo)
        is_ad = text_is_ad(text)
        if is_ad:
            print("This photo is an ad")
            photo_cnt += 1
            if photo_cnt < len(photos_sorted):
                product_photo = photos_sorted[photo_cnt][1]
                product_photo_url = photos_sorted[photo_cnt][2]
            else:
                is_ad = False # force break

            # HACK: Adds are shown right on top of the product to force you to see it. So move down a bit
            is_ad = False
            was_ad = True
        else:
            is_ad = False

    crawl_hint_clean(crawl_photo)
    coordinates = template2coordinates(rendered_photo,zoom_photo)
    # Start 10px inside the photo because some prices end up starting from further
    # inside where the photo is. It's as if photos are not placed on the screen correctly
    data['url'] = url
    data['photo'] = crawl_photo_url
    data['photo_coordinates'] = coordinates
    print str(coordinates) + "\n"
    if crawl_price == None:
        crawl_price = 0
    else:
        crawl_price = float(crawl_price)
    data['crawl_price'] = crawl_price
    data['crawl_source'] = crawl_source

    def lookat(direction, photo_url):
        print ("Looking for price at direction: " + direction + "\n")
        print (" of photo url " + photo_url + "\n")
        coordinates_direction = []
        photofix = 0
        if direction == "right":
            downfix = 0
            if was_ad == True:
                downfix = coordinates[3]/2 # Handle annoying ad by the GAP
            coordinates_direction = [ (coordinates[0] + coordinates[2]-photofix), coordinates[1] + downfix, coordinates[2] + photofix, coordinates[3]]
        elif direction == "bottom":
            photofix = 40
            coordinates_direction = [ coordinates[0]-photofix, coordinates[1]+coordinates[3], coordinates[2]+photofix, 100] #coordinates[3]]
        elif direction == "left":
            left = coordinates[0] - coordinates[2]
            if left <= 0:
                left = 0 
            coordinates_direction = [ left, coordinates[1], coordinates[2],coordinates[3]]
        strip_direction = photo_seed + "_strip_" + direction + ".jpg"
        crop(rendered_photo,strip_direction,coordinates_direction)
        text = image2text(strip_direction)
        f = open(photo_seed + "_ocr_" + direction + ".txt", 'ab+')
        f.write(text)
        f.close()
        print "Product OCR is:\n" + text
        return text2price(text)
    
    price = lookat("right", product_photo_url)
    if price == "":
        price = lookat("bottom", product_photo_url)
    if price == "":
        price = lookat("left", product_photo_url)
    data['price'] = price
    return data

def image2text(filename):
    p = subprocess.Popen('python /home/roomhints/devel/RH/imaging/pytesser/tes.py ' + str(filename), shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    return out

def text2price(text):
    price = None
    find_string = '(.*?)\$(.*)'
    field_match = re.findall(find_string, text)
    if field_match:
        field_match_string = field_match[0][1]
        price =  field_match_string.split()[0]
    else:
        price = ""

    # Sometimes the price comes out as 154_99 when it should be 154.99
    price = re.sub('_', '.', price)
    # And sometimes it comes out as $154-**** when it should be $154.99
    price = re.sub("-.*", '', price)
    print "price so far is " + str(price) + "\n"
    try:
        if price != "":
            price = float(price)
    except Exception, e:
        # the price came back as a string
        #print e
        price = None

    return price

def text_is_ad(text):
    print "Ad OCR IS:\n" + text
    matches = 0
    for word in ['off', 'purchase', 'sale', '%', 'ends', 'save', 'savings', 'super']:
        if word in text.lower():
            print "found AdWord: " + word + "\n"
            matches += 1
        #print (re.search(word,text))
        #print text.find(word)
    if matches >= 2:
        return True
    else:
        return False
