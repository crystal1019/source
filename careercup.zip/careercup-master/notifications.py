from google.appengine.api import users
import masterpage

import method_user
import method_notification

class Notifications(masterpage.MasterPage):
	def post(self):
		user = method_user.getLoggedInUser()
		if not user:
			self.redirectToLogin()
			return
		
		if self.request.get("delete"):
			method_notification.clearAllNotificationsForUser(user)
		elif self.request.get("readall"):
			method_notification.markAllNotificationsAsRead(user)
			
		self.redirect('/notifications')
		return
	
	def get(self):
		user = method_user.getLoggedInUser()
		if not user:
			self.redirectToLogin()
			return
			
		html = None # do not cache method_cache.getObjectForTypeAndKey(page_cache_key, user.user.email())
		if not html:
			if not user:
				self.redirect(users.create_login_url(self.request.uri))
				return
				
			notifications = method_notification.getNotificationsForUser(user)
			
			template_values = {
				'notifications': notifications
			}
			html = self.getBody(template_values, 'html/notifications.html')
			#method_cache.setObjectForTypeAndKey(page_cache_key, str(user.uid), html)			
						
		template_values = {}
		template_values['rendered_body'] = html
		template_values['title'] = 'Notifications'
		self.pushPage(template_values, 'Notifications', 'html/main.html')					