cd /home/chaol/projects/bellabustiere
python manage.py sync_vend > /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vend_sync_process
echo "---------------" >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vend_sync_process
cat  /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vend_sync_process >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vend_sync_allprocess
