from arktotalwealth.service.models import *
from django.contrib import admin

class ServicePageAdmin(admin.ModelAdmin):
	prepopulated_fields = {'slug':('title',)}
	list_display= ('__unicode__','parent','priority','active','landingpage',)
	list_editable = ('parent','priority','active','landingpage',)
	list_filter = ('parent','active','landingpage')
	filter_horizontal = ('action_links',)
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]

admin.site.register(ServicePage, ServicePageAdmin)