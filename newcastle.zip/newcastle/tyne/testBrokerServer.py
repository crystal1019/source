'''
Created on Dec 29, 2014

@author: apptworks
'''
import json
import unittest

import requests
from werkzeug import responder

SUT = 'AWDemo'
class Test(unittest.TestCase):

		BASE_URL = 'http://localhost:5000/%s/' % (SUT)

		
		def testGetUsers(self):
				testUrl = self.BASE_URL + 'users'
				resp = requests.request('GET', testUrl)
				jsonResp = resp.json()
				self.assertTrue('users' in jsonResp, 'users element missing from response')
				self.assertGreater(len(jsonResp['users']), 0, 'users list is empty')


		def testCreateReservation(self):
				testUrl = self.BASE_URL + 'reservations/?useExisting=true'
				testData = {'bookedId': 335}
				jsonData = json.dumps(testData)
				headers = {"Content-Type": "application/json"}
				resp = requests.request('POST', testUrl, headers=headers, data=jsonData )
				jsonResp = resp.json()
				self.assertTrue('existingFound' in jsonResp, 'useExisting was not used')


if __name__ == "__main__":
		#import sys;sys.argv = ['', 'Test.testGetUsers']
		unittest.main()