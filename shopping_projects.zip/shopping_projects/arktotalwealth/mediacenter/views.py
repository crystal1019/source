'''
@author: chaol
'''

from django.template import Context, loader, RequestContext
from django.http import HttpResponse, HttpResponseRedirect, HttpResponsePermanentRedirect
import datetime, time, math

from arktotalwealth.mediacenter.models import *

import pprint, hashlib

from tagging.models import *

from django.conf import settings

from django.core.paginator import Paginator

from arktotalwealth.mediacenter.forms import *
from arktotalwealth.website.models import SpammerList
from arktotalwealth import common

from haystack.views import SearchView, search_view_factory
from haystack.forms import SearchForm, HighlightedSearchForm
from haystack.query import SearchQuerySet

def home(request, category='all',offset=1):
    t = loader.get_template('blog_index.html')
    offset = int(offset)
    perpage = settings.BLOG_POSTS_PER_PAGE
    start = offset*perpage
    end = start+perpage
    
#    postcount = BlogPost.objects.select_related().filter(status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate").count()
    current_category = BlogCategory.objects.get(slug=category) if category != 'all' else ''
    
    
    blogposts = BlogPost.objects.select_related().filter(active=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate") if category == 'all' else BlogPost.objects.select_related().filter(category__slug=category,active=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate")
    
    p = Paginator(blogposts, perpage)
    
    pagecontent = p.page(offset)
    try:
        page = NewsPage.objects.get(title='index')
    except:
        page =''
    #return HttpResponse("")
    c = RequestContext(request,common.commondict({
        'blogposts': pagecontent.object_list,
        'blog_category':BlogCategory.objects.filter(is_active=True).order_by('-priority'),
        'current_category':current_category,
        "openpath": ["blog"],
        "pagecontent": pagecontent,
        "path":page,
        "page":page,
    }, request))
    return HttpResponse(t.render(c))

def post(request, code):
    t = loader.get_template('blogpost.html')
    #return HttpResponse(str(dir(Product.objects.get(code=code))))
    blogpost = BlogPost.objects.get(slug=code)
    rp = request.POST.copy()
    messages = []

    try:
        page = NewsPage.objects.get(title='index')
    except:
        page =''        
    if rp:
        form = CommentForm(rp)
    else:
        form = CommentForm()
    if form.is_valid(): # All validation rules pass
        try:
            ip = request.META["HTTP_CF_CONNECTING_IP"] 
        except:
            ip = request.META["REMOTE_ADDR"]

        check_spammer = SpammerList.objects.filter(ip=ip)
        if not check_spammer:
            c = Comment(post=blogpost, name=form.cleaned_data["name"], email=form.cleaned_data["email"], comment=form.cleaned_data["comment"],ip=ip)
            c.save()
            messages.append("Thanks for your comment")  
            form = CommentForm()
    

    c = RequestContext(request,common.commondict({
        'blogpost': blogpost,
        'blog_category':BlogCategory.objects.filter(is_active=True).order_by('-priority'),
        'form': form,
        'messages': messages,
        "openpath": ["blog"],
        "path":page,
        'page':page,

    }, request))
    return HttpResponse(t.render(c))

def tag(request,tag):
    t = loader.get_template('blog_index.html')
    
    blog_posts = TaggedItem.objects.get_by_model(BlogPost.objects.filter(active=True),[tag])
    
    try:
        page = NewsPage.objects.get(title='index')
    except:
        page =''         
    
    c = RequestContext(request,common.commondict({'blogposts':blog_posts,'tag':tag,"openpath": ["blog"],"path":page,'page':page,'blog_category':BlogCategory.objects.filter(is_active=True).order_by('-priority')},request))
    
    return HttpResponse(t.render(c))

class BlogSearchView(SearchView):
    def __name__(self):
        return "BlogSearchView"

    def extra_context(self):
        try:
            page = NewsPage.objects.get(title='index')
        except:
            page =''             
        extra = super(BlogSearchView, self).extra_context()

        extra['blog_category'] = BlogCategory.objects.filter(is_active=True).order_by('-priority')
        extra['path'] = page
        extra['uri'] = 'blog'
        
        extra = common.commondict(extra)

        return extra
    
def blogsearch(request):

    sqs = SearchQuerySet().models(BlogPost).highlight()

    return search_view_factory(view_class=BlogSearchView,form_class=SearchForm,template='blog-search.html',searchqueryset=sqs)(request) 
