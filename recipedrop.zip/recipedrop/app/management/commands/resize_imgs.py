from django.core.management.base import BaseCommand, CommandError
from django.conf import settings
from app.models import RecipeImage
import StringIO
import boto
from PIL import Image
import os
import sys
import math

class Command(BaseCommand):
    def handle(self, *args, **options):
        if not settings.LIVE:
            raise CommandError("Must be run on live site!")

        maxw = int(args[0])
        maxh = int(args[1])

        ris = RecipeImage.objects.all()
        s3 = boto.connect_s3()
        bucket = s3.create_bucket(settings.S3_BUCKET)
        for ri in ris:
            try:
                path = ri.upload
                print 'Resizing %s' % path
                _, ext = os.path.splitext(path)
                ext = ext[1:]
                if ext.upper() == u'JPG':
                    ext = 'JPEG'
                
                contents = bucket.get_key('%s_old' % path)
                if contents:
                    contents = contents.get_contents_as_string()
                else:
                    contents = bucket.get_key(path).get_contents_as_string()

                bucket.new_key('%s_old' % path).set_contents_from_string(contents)

                contents = StringIO.StringIO(contents)
                img = Image.open(contents)

                (w, h) = img.size
                if w > maxw:
                    img = img.resize((maxw,
                                      int(math.ceil(((maxw * 1.0) / w) * h))),
                                     Image.ANTIALIAS)
                (w, h) = img.size
                if h > maxh:
                    img = img.resize((int(math.ceil(((maxh * 1.0 / h) * w))),
                                      maxh),
                                      Image.ANTIALIAS)

                out_resized = StringIO.StringIO()
                img.save(out_resized, ext)
                key = bucket.new_key('%s' % path)
                key.set_contents_from_string(out_resized.getvalue())
            except:
                print "Unexpected error:", sys.exc_info()[0]
