# from models import CommentRating
# from forms import CommentRatingForm
# 
# def get_model():
#     return CommentRating
# 
# def get_form():
#     return CommentRatingForm