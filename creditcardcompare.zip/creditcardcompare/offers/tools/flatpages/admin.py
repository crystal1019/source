from django.contrib import admin
from django.contrib.flatpages.admin import FlatPageAdmin
from django.contrib.flatpages.models import FlatPage
from django.utils.translation import ugettext_lazy as _
from offers.tools.flatpages.models import PerSiteFlatPageOption, Media, FlatPageExtra, Video

   
class PerSiteFlatPageOptionInline(admin.StackedInline):
    model = PerSiteFlatPageOption
    verbose_name = _('per site seo option')
    plural_name = _('per site seo options')
    extra = 0
    
class FlatPageExtraInline(admin.StackedInline):
    model = FlatPageExtra
    extra = 0
    filter_horizontal = ('categories',)
    
class VideoInline(admin.StackedInline):
    model = Video
    extra = 0
    filter_horizontal = ('categories',)
    
class CustomFlatPageAdmin(FlatPageAdmin):
    inlines = (FlatPageExtraInline, VideoInline, PerSiteFlatPageOptionInline,)
    list_display = ('url', 'title', 'id', 'template_name')
    ordering = ('-id',)

class MediaAdmin(admin.ModelAdmin):
    search_fields = ['image']
    
class VideoAdmin(admin.ModelAdmin):
    model = Video
    filter_horizontal = ('categories',)
    
    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}


admin.site.unregister(FlatPage)
admin.site.register(FlatPage, CustomFlatPageAdmin)
admin.site.register(Media, MediaAdmin)
admin.site.register(Video, VideoAdmin)
