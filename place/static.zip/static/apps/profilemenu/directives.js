angular.module('menu.directives', [])
    .directive('initMenu', [

        function() {
            return {
                restrict: 'A',
                templateUrl: '/static/apps/profilemenu/partials/menu.html'
            };
        }
    ])
    .directive('buildNotification', [

        function() {
            return {
                restrict: 'A',
                link: function(scope, elem, attrs) {

                }
            };
        }
    ])
    .directive('menuOpen', [

        function() {
            return {
                restrict: 'A',
                link: function(scope, elem, attrs) {
                    scope.$watch(attrs.menuOpen, function(is_open) {
                        if (is_open) {
                            elem.prev().addClass('white-arrow');
                            elem.css('overflow', 'hidden')
                                .stop(true, true)
                                .delay(300)
                                .slideDown('fast', function() {
                                    ga_tracker('header menu', attrs.menuOpen + 'mouseenter');
                                    elem.css('overflow', 'visible');
                                });
                        } else {
                            elem.prev().removeClass('white-arrow');
                            elem.css('overflow', 'hidden')
                                .stop(true, true)
                                .delay(500)
                                .slideUp('fast');
                        }
                    });
                }
            };
        }
    ]);