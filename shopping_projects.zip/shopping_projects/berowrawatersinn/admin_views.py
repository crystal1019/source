import datetime
from django.template import loader, RequestContext
from django.http import HttpResponse
import calendar
from berowrawatersinn import common

def calendar_show(request):
    t = loader.get_template('admin/reservation/booking/calendar.html')
    rg = request.GET
    try:
        year = int(rg.get('year',''))
        month = int(rg.get('month',''))
    except:
        year = ''
        month = ''    

    now = datetime.date.today()
    alldates = calendar.Calendar(6).monthdatescalendar(now.year,now.month)

    if year and month:
        alldates = calendar.Calendar(6).monthdatescalendar(year,month)
    else:
        year = now.year
        month = now.month
        
    prev_month = common.getPreviousMonth(year, month)
    next_month = common.getNextMonth(year, month)
    
    current = datetime.date(year, month,1)
    
    c = RequestContext(request,{
            'alldates':alldates,
            'now':now,
            
            'current':current,            
            'prev_month':prev_month,
            'next_month':next_month,
    })
    
    return HttpResponse(t.render(c))