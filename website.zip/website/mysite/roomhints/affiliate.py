from django.db import connection, transaction
from datetime import datetime, timedelta
from django.utils.timezone import utc
from roomhints.models import AffiliateRedirection
from roomhints.models import Hint
from roomhints.utils import make_unique, url_encode

shareasale_id = 693902
viglink_api_key = "7cd976031e8e4c5be3c57c612c94cf29"

def affiliate_find(h):
    ar = AffiliateRedirection.objects.filter(hint_id=h.id)
    if len(ar) > 0:
        # There was an affiliate link, use it
        return h.affiliate_url
    else:
        if h.source_url == None:
            return ""
        else:
            return h.source_url

def affiliate_set(affurl,h):
    arall = AffiliateRedirection.objects.filter(hint_id=h.id).order_by('-seconds')
    ar = None
    if len(arall) == 0:
        ar = AffiliateRedirection()
        ar.reduniq = make_unique(36)
        ar.hint = h
        ar.seconds = datetime.utcnow().replace(tzinfo=utc)
    else:
        ar = arall[0]
        ar.seconds = datetime.utcnow().replace(tzinfo=utc)

    if affurl == "" or affurl == None:
        ar.target = h.source_url
    else:
        ar.target = affurl

    ar.save()
    h.affiliate_url = "http://roomhints.com/afred?reduniq=" + ar.reduniq
    h.save()
    return ar

def affiliate_data_from_sku(sku):
    ret = affiliate_data_shareasale(sku)
    return ret

def affiliate_data(h):
    ret = ""
    if affiliate_is_shareasale(h) == True:
        ret = affiliate_data_shareasale(h.sku)

    if ret == "":
        ret = dict()
        ret['price'] = h.price
        ret['price_listed'] = h.price
        ret['price_savings'] = 0
        ret['name'] = h.name
        ret['photo_url'] = h.photo_mob.name
        ret['url'] = affiliate_data_viglink(h)
    return ret

def affiliate_is_shareasale(h):
    name = h.source
    name = name.lower()
    # Wayfair and All Modern are the same company.
    # One Kings Lane is in the shareasale database
    if name == "wayfair" or name == "all modern" or name == "one kings lane":
        return True

    # possibly check urls
    return False

def affiliate_data_shareasale(sku):
    data = dict()
    cursor = connection.cursor()
    sql = "select url,price,price_listed,name,photo_url2,store from vendor_shareasale where sku like %s order by id desc"
    cursor.execute(sql,[ str(sku)+'%' ]) # match all prefixes
    data['url'] = ""
    for row in cursor.fetchall():
        data['url'] = row[0]
        data['price'] = row[1]
        data['price_listed'] = row[2]
        if data['price'] < data['price_listed']:
            data['price_savings'] = data['price_listed'] - data['price']
        else:
            data['price_savings'] = 0
        data['name'] = row[3]
        data['photo_url'] = row[4]
        data['source'] = row[5]
    data['url'] = data['url'].replace("YOURUSERID",str(shareasale_id))
    cursor.close()
    if 'name' not in data.keys():
        # This sku was not found
        return None
    return data

def affiliate_data_viglink(h):
    outurl = url_encode(h.source_url)
    url = 'http://redirect.viglink.com/?key=' + viglink_api_key + '&out=' + outurl
    return url
