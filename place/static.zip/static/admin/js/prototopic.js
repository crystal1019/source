var addUpdaterButtons = function() {

  // Get the rows for scraped fields.
  var rowSelector = "[class*='field-scraped_']";
  var $rows = $(rowSelector);

  // Go through the scraped fields.
  for (var i = 0; i < $rows.length; i++) {
    var row = $rows[i];
    var field = row.children[0];

    // Beside each field, add a button to update its non-scraped equivalent.
    $(field).css('float', 'left');
    var updater = '<button type="button" onclick="update(this);" ' +
      'style="margin-left:20px">Update associated field</button>';
    $(row).append(updater);
  }

}

var update = function(button) {

  // Get the scraped value;
  var scrapedFieldRow = button.parentElement;
  var scrapedField = scrapedFieldRow.children[0];
  var scrapedValue = $(scrapedField.children[1]).text();
  if (scrapedValue == '(None)') {
      scrapedValue = '';
  }

  // Find the field name.
  var fieldName = '';
  var rowClasses = scrapedFieldRow.className.split(/\s+/);
  var fieldPrefix = 'field-scraped_';
  for (var i = 0; i < rowClasses.length; i++) {
    var className = rowClasses[i];
    if (className.indexOf(fieldPrefix) > -1) {
      fieldName = className.replace(fieldPrefix, '');
    }
  }

  // Replace the appropriate field's value.
  var fieldSelector = '#id_' + fieldName;
  var $field = $(fieldSelector);
  $field.val(scrapedValue);

  // Hide the scraped field elements if necessary.
  var buttonModule = scrapedFieldRow.parentElement;
  var moduleHeader = buttonModule.children[0];
  var headerText = $(moduleHeader).text();
  if (headerText == 'Updated scraper data') {
      $(scrapedFieldRow).hide();
  }

}

$( document ).ready( addUpdaterButtons );
