# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):

        # Changing field 'UserAgent.identifier'
        db.alter_column('scraper_useragent', 'identifier', self.gf('django.db.models.fields.CharField')(unique=True, max_length=500))

    def backwards(self, orm):

        # Changing field 'UserAgent.identifier'
        db.alter_column('scraper_useragent', 'identifier', self.gf('django.db.models.fields.CharField')(max_length=255, unique=True))

    models = {
        'scraper.event': {
            'Meta': {'ordering': "('-created',)", 'object_name': 'Event'},
            'created': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'db_index': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'status': ('django.db.models.fields.PositiveSmallIntegerField', [], {'db_index': 'True'}),
            'target': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['scraper.Target']"}),
            'user_agent': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['scraper.UserAgent']"})
        },
        'scraper.target': {
            'Meta': {'object_name': 'Target'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'target_type': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200'})
        },
        'scraper.useragent': {
            'Meta': {'object_name': 'UserAgent'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'identifier': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '500'})
        }
    }

    complete_apps = ['scraper']