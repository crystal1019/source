import logging
import re
from bs4 import BeautifulSoup
from urlparse import urlsplit
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class EbayScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'ebay.com'

    def extract_sku(self, url):
        parts = url.split('/')
        if not len(parts):
            logger.critical('Was not able to extract sku')
            raise HukksterTooManyOptions(EbayScraper.get_domain(), self.url)
        return parts[-1]

    def extract_price(self):
        m = re.search(r'US \$(\d+\.\d+)', self.html)
        if m is not None:
            return float(m.group(1))

        logger.critical('Was not able to extract price')
        raise HukksterTooManyOptions(EbayScraper.get_domain(), self.url)

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        # Giving up, it doesn't look as a product
        if not 'title' in raw_data:
            raise HukksterTooManyOptions(EbayScraper.get_domain(), self.url)

        selections = []
        sizes = []

        sizes_container = soup.find('select', class_='msku-sel')
        if sizes_container is not None:
            sizes = [size.text for size in sizes_container.find_all('option') if not size['value'] == '-1']

        if len(sizes):
            for size in sizes:
                data = {
                    'title': raw_data['title'],
                    'current_price': {
                        'value': self.extract_price()
                    },
                    'selections': {
                        'size': size,
                    },
                    'url': raw_data['url'],
                    'store': raw_data['site_name'].lower(),
                    'image': raw_data['image'],
                    'local_id': self.extract_sku(raw_data['url'])
                }
                selections.append(data)
        else:
            data = {
                'title': raw_data['title'],
                'current_price': {
                    'value': self.extract_price()
                },
                'url': raw_data['url'],
                'store': raw_data['site_name'].lower(),
                'image': raw_data['image'],
                'local_id': self.extract_sku(raw_data['url'])
            }
            selections.append(data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(EbayScraper.get_domain(), self.url)

        return selections