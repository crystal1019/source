#coding=utf-8
import logging
import re
import lxml.html
from urlparse import urljoin
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class TheOutnetScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'theoutnet.com'

    def clean_string2(self, val):
        try:
            val = self.clean_string(val)
            return val.replace(u'\xa0', ' ')
        except AttributeError:
            return val

    def _extract_float(self, root, xpath_expr, text_pattern, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(root, xpath_expr, is_expected_to_be_found)
        if node is not None:
            float_text = self.clean_string(node.text_content())
            m = re.search(text_pattern, float_text.encode("utf8"))
            if m:
                float_text = m.group(1).replace(",", "")
                float_value = float(float_text)
                return float_value
            else:
                if is_expected_to_be_found:
                    logging.debug("Error: Found no float value using %r" % xpath_expr)
                return None
        else:
            if is_expected_to_be_found:
                logging.debug("Error: Found no node using %r" % xpath_expr)
            return None

    def _expect_and_extract_single_node(self, root, xpath_expr, is_expected_to_be_found=True):
        try:
            nodes = root.xpath(xpath_expr)
            if len(nodes) == 0:
                if is_expected_to_be_found:
                    logging.debug("Error: Unabled to find a node with xpath expression: %r" % xpath_expr)
                return None
            else:
                if len(nodes) > 1:
                    logging.debug("Error: Found more than one node using %r" % xpath_expr)
                return nodes[0]
        except:
            return None

    def _extract_img_url(self, root, xpath_expr):
        img_node = self._expect_and_extract_single_node(root, xpath_expr)
        if img_node is not None:
            return urljoin(self.url, img_node.attrib["src"])
        else:
            return ""

    def _extract_attr_value(self, root, xpath_expr):
        return self._expect_and_extract_single_node(root, xpath_expr)

    def _extract_sku_size_pairs(self, root, product_id):
        result = []
        sku = self._extract_attr_value(root, "//input[@id='productId']/@value")
        size_labels = root.xpath("//div[@id='sizes']//li//label")
        for size_label in size_labels:
            sold_out = "sold-out" in size_label.attrib["class"]
            size_text = self.clean_string(size_label.text_content())
            if not sold_out:
                result.append((sku, size_text))
        return result

    def _extract_colors(self, root):
        h3_text = self.clean_string2(root.xpath("//div[@id='colours']/h3")[0].text_content())
        m = re.match(r"Color\:\s+(?P<color>.*)", h3_text)
        if m:
            color = m.group('color')
            return color
        else:
            logging.debug("Error: failed to extract color")
            return ''

    def _extract_prices(self, root):
        price_text_pattern = r"([\d\,]+[\.\d]*)"
        current_price = self._extract_float(root,  "//span[@class='price-now']",
                                    price_text_pattern, is_expected_to_be_found=False)
        original_price = self._extract_float(root, "//span[@class='price-original']",
                                    price_text_pattern, is_expected_to_be_found=False)
        if original_price is not None and current_price is not None:
            return current_price, original_price
        elif original_price is None and current_price is None:
            current_price = original_price = self._extract_float(root, "//span[@class='price-outnet']", price_text_pattern)
            if current_price is None:
                logging.debug("Error: Failed to find any price under 'prices-all'")
            return current_price, original_price
        else:
            logging.debug("Error: Unexpected situation: current_price is %s and original_price is %s" % (current_price, original_price))
            if current_price is None:
                current_price = original_price
            else:
                original_price = current_price
            return current_price, original_price

    def parse_products(self, root, raw_data):
        product_id = self._extract_attr_value(root, "//form[@name='productForm']//input[@id='productId']/@value")
        # We treat the case of can not find a product_id as "no product found"
        if product_id is None:
            logging.debug("Error: failed to find a product (product_id not found)"
                          " on the page '%s'" % self.url)
            return None

        title = root.xpath("//div[@id='product-heading']/h1")[0].text_content()
        current_price, original_price = self._extract_prices(root)
        image = self._extract_img_url(root, "//img[@id='medium-image']")
        color = self._extract_colors(root)

        sku_size_pairs = self._extract_sku_size_pairs(root, product_id)

        if len(sku_size_pairs) == 0:
            sku = self._extract_attr_value(root, "//input[@id='sku']/@value")
            if not sku.startswith(product_id):
                logging.debug('Error: sku value found by "//input[@id=\'sku\']/@value" '
                              'does not start with productId.')
            sku_size_pairs = [(sku, None)]

        products = []
        #for sku, size, sold_out in sku_size_pairs:
        for sku, size in sku_size_pairs:
            product = {
                'title': title,
                'current_price': {
                    'value': current_price,
                },
                'original_price': {
                    'value': original_price,
                },
                'url': raw_data['url'],
                'store': 'theoutnet',
                'image': image,
                'local_id': sku,
                'selections': {
                    'color': color,
                },
                #'sold_out': sold_out,
                'promos': []
            }
            if size is not None:
                product["selections"]["size"] = size
            products.append(product)
        return products

    def parse(self):
        raw_data = self.parse_opengraph()

        # Parsing the HTML
        logging.debug('Parsing HTML data')
        encoding = "utf-8"
        root = lxml.html.fromstring(unicode(self.html, encoding))
        logging.debug('Finished parsing HTML data')

        products = self.parse_products(root, raw_data)

        # Giving up, it doesn't look as a product
        if products is None or not len(products):
            raise HukksterTooManyOptions(TheOutnetScraper.get_domain(), self.url)

        return products
