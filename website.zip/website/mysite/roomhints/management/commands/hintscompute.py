from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.models import Hint
from roomhints.models import HintSimilarity
from datetime import datetime, timedelta
from roomhints.utils import random_number, make_unique, make_unique_photo, search_profile_id, photo_convert
import shutil
from roomhints.color import get_color_stats, hex_to_color, color_to_hex, hex_to_complement
from roomhints.affiliate import affiliate_data, affiliate_set
from roomhints.imagematcher import find_image_match_from_list
from roomhints.utils import search_profile_id
from django.utils.timezone import utc

import os, sys

class Command(BaseCommand):
    help = 'Make sure all hints in search use small pictures'

    def hintcompute(self,one,two):
        hs_all = HintSimilarity.objects.filter(one_id=one.id,two_id=two.id)
        hs = None
        compute=False
        if len(hs_all) > 0:
            # There is an existing similarity entry. Ignore
            hs = hs_all[0]
        else:
            # There is no existing similarity entry. Create one
            hs = HintSimilarity()
            hs.one = one
            hs.two = two
            compute=True

        term = "Ignoring"
        if compute:
            term = "Computing"

            image_list = []
            image_data = dict()
            image_data['photo'] = two.photo_web.name
            image_data['dominant_hex'] = two.dominant_hex
            image_data['project_hex'] = one.dominant_hex
            image_data['project_color_complement'] = hex_to_complement(one.dominant_hex)
            image_data['project_hex_complement'] = color_to_hex(image_data['project_color_complement'])
            image_data['project_color'] = hex_to_color(one.dominant_hex)
            image_list = [ image_data ]
            max_score_image, max_score, scores = find_image_match_from_list(settings.MEDIA_ROOT + one.photo_web.name,
                                                                        image_list,
                                                                        "__ignoring_name__")
            print("Compared " + one.photo_web.name + " with " + two.photo_web.name)
            print(scores)
            for image in scores['by_image'].keys():
                value = scores['by_image'][image]
                hs.color_score = value['color_score']
                hs.feature_score = value['feature_score']
                hs.total_score = value['total_score']
                hs.save()

        print(term + " similarity of " + str(one.id) + " with " + str(two.id))


    def handle(self, *args, **options):
        projuniq = None
        if len(args) == 0:
            print("usage: hintscompute all       - or-\n       hintscompute 2         (for hints added over past 2 days)")
            sys.exit(0)

        kind = None
        for a in args:
            if kind == None:
                kind = a

        one_hall = None
        if kind == "all":
            one_hall = Hint.objects.filter(public=True,profile_id=search_profile_id()).order_by('-id').all()
        else:
            days = kind
            startdate = datetime.utcnow().replace(tzinfo=utc)
            enddate = startdate - timedelta(days=7)
            one_hall = Hint.objects.filter(public=True,profile_id=search_profile_id(),seconds__gt=enddate).order_by('-id').all()

        for one in one_hall:
            two_hall = Hint.objects.filter(public=True,profile_id=search_profile_id()).order_by('-id').all()
            for two in two_hall:
                self.hintcompute(one,two)
                self.hintcompute(two,one)

