import os
from google.appengine.ext.webapp import template

from google.appengine.api import users
from google.appengine.ext import webapp

import time

import objects
import method_user
import method_question
import method_comment
import method_salary
import method_forum
import method_cache
import method_db
import method_url
import method_notification

cache_key_attribute_menus = 'attribute-menus'

class MasterPage(webapp.RequestHandler):
	def getBody(self, template_values, filepath):
		path = os.path.join(os.path.dirname(__file__), filepath)
		return template.render(path, template_values)
	
	def getPageIndex(self):
		index = method_url.getIntParam(self, 'n')
		if not index:
			index = 0
		else:
			index = index - 1
		return index
		
	def pruneToPage(self, list, page_num, page_size):
		lst = []
		offset = page_size * page_num
		for i in range(offset, offset + page_size):
			if i >= len(list):
				break
			lst.append(list[i])
		return lst		
			
	def addActivity(self, name, url, image_url, type, subtype, title, subtitle):
		activity = objects.ActivityItem()
		activity.url = url
		activity.name = name
		activity.image_url = image_url
		activity.type = type
		activity.subtype = subtype
		activity.subtitle = subtitle
		activity.timestamp = int(time.time())
		method_db.putObject(activity)
		page_cache_key = 'activity-rendered'
		method_cache.clearObjectForTypeAndId(page_cache_key, None)		
		method_cache.setObjectForTypeAndKey('activity-rendered-last-time', None, activity.timestamp)

	def redirectToLogin(self):
		self.redirect(users.create_login_url(self.request.uri))
		
	def redirectToLoginWithUrl(self, url):
		self.redirect(users.create_login_url(url))		
		
	def displayError(self, error_title, error_message):
		template_values = {}
		template_values['rendered_body'] = '<strong>' + error_title + '</strong><br/><br/>' + error_message
		self.pushPage(template_values, error_title, 'html/main.html')
		
	def isSpammer(self):
		if self.request.get('username') != '':
			return True
		return False
		
	def hasBannedText(self, text):
		banned_text = ['onestopinterviewprep.blogspot', 'nobrainer.co.cc']
		for b in banned_text:
			if b in text:
				return True
		return False		
		
	def getSubscriptions(self, uid):
		qs = objects.Question.query(objects.Question.subscriptions_users == uid).order(-objects.Question.last_comment)
		fs = objects.ForumPost.query(objects.ForumPost.subscriptions_users == uid).order(-objects.Question.last_comment)
		ss = []
		q_index = 0
		f_index = 0
		while q_index < qs.count() or f_index < fs.count():
			if q_index < qs.count():
				q = qs[q_index]
			else:
				q = None
			if f_index < fs.count():
				f = fs[f_index]
			else:
				f = None
			if q is None and f is None:
				break
			if q is None or f is None:
				if f is None:
					q.type = 'question'
					ss.append(q)
					q_index = q_index + 1
				else:
					f.type = 'forum'
					ss.append(f)
					f_index = f_index + 1
			elif q.last_comment > f.last_comment:
				q.type = 'question'
				ss.append(q)
				q_index = q_index + 1
			else:
				f.type = 'forum'
				ss.append(f)
				f_index = f_index + 1			
		return ss		
	
	def setValueFromCheckbox(self, checkbox):
		val = self.request.get(checkbox)
		if val == 'on':
			return True
		else:
			return False		
		
	def pushLoginInfo(self, template_values):
		user = method_user.getLoggedInUserFromCache()
		if user:
			url = users.create_logout_url(self.request.uri)
			name = user['name']
			uid = user['uid']
			template_values['favorites'] = method_user.getFavoritesForUser(user)
			template_values['favorite_forums'] = method_user.getFavoriteForumsForUser(user)
			template_values['favorite_users'] = method_user.getFavoriteUsersForUser(user)			
			template_values['favorite_attributes'] = method_user.getFavoriteAttributesForUser(user)
			template_values['favorite_forum_all'] = method_user.getFavoriteForumAllForUser(user)
			template_values['notification_count'] = method_notification.getNotificationCountForUser(users.get_current_user(), uid)
			template_values['reputation'] = user['reputation']
		else:
			url = users.create_login_url(self.request.uri)
			uid = None
			name = ''
		is_admin = method_user.userIsAdmin()
		if is_admin:
			template_values['duplicate_count'] = method_question.getDuplicateCount()
			template_values['flagged_count'] = method_question.getFlaggedCount()
			template_values['flagged_comment_count'] = method_comment.getFlaggedCommentCount()
			template_values['flagged_salary_count'] = method_salary.getFlaggedSalaryCount()
			template_values['flagged_forum_count'] = method_forum.getFlaggedForumCount()
		template_values['admin'] = is_admin
		template_values['name'] = name
		template_values['url'] = url  
		template_values['uid'] = uid

	def isInt(self, i):
		try:
			int(i)
			return True
		except:
			return False
		return True
		
	def show404(self):
		self.error(404)
		self.response.out.write(self.getBody({}, 'html/404.html'))		
		
	def renderAttributeMenus(self):
		html = method_cache.getObjectForTypeAndKey(cache_key_attribute_menus, None)
		if not html:
			template_values = {}
			template_values['jobs'] = method_question.getTopAttributesInType('job')
			template_values['companies'] = method_question.getTopAttributesInType('company')
			template_values['topics'] = method_question.getTopAttributesInType('topic')
			html = self.getBody(template_values, 'html/control-attributesmenu.html')
			method_cache.setObjectForTypeAndKey(cache_key_attribute_menus, None, html)
		return html
		
	def pushPage(self, template_values, page_title, filepath):
		self.pushLoginInfo(template_values)	
		template_values['body'] = self.getBody(template_values, filepath)
		ref = method_url.getStringParam(self, 'ref')
		template_values['ref'] = ref
		template_values['attributes_menu'] = self.renderAttributeMenus()
		template_values['page_title'] = page_title
		template_values['country'] = self.getCountry()
		template_values['isMobile'] = self.isMobile()
		self.response.out.write(self.getBody(template_values, filepath))
		
	def isMobile(self):
		if "iPhone" in self.request.headers["User-Agent"]:
			return True
		else:
			return False
		
	def getCountry(self):
		if "X-AppEngine-country" in self.request.headers:
			return self.request.headers["X-AppEngine-country"]
		return "US"