import objects
import masterpage

import method_db
import method_question
import method_user
import method_cache
	
class ConfirmDuplicate(masterpage.MasterPage):				  
		
	def confirmDuplicate(self, primary, secondary):
		comments = objects.Comment.query(objects.Comment.ancestor_id == secondary)
		count = 0
		
		primary_question = method_question.getQuestionWithId(primary)
		secondary_question = method_question.getQuestionWithId(secondary)
		
		for comment in comments:
			if comment.parent_id == comment.ancestor_id:
				comment.parent_id = primary
			comment.ancestor_id = primary
			method_db.putObject(comment)
			count = count + 1
		
		has_ids = {}
		for i in secondary_question.companies_pretty:
			if not(i in primary_question.companies_pretty):
				primary_question.companies_pretty.append(i)
		for i in secondary_question.topics_pretty:
			if not(i in primary_question.topics_pretty):
				primary_question.topics_pretty.append(i)
		for i in secondary_question.jobs_pretty:
			if not(i in primary_question.jobs_pretty):
				primary_question.jobs_pretty.append(i)

		secondary_question.redirect_question = primary
		secondary_question.visible = False
		method_db.putObject(secondary_question)
		primary_question.comment_count = primary_question.comment_count + count
		method_db.putObject(primary_question)
		method_question.clearQuestionCache(primary_question, True)
		method_question.clearQuestionCache(secondary_question, True)
			
	def post(self):
		index = 1
		duplicates = method_question.getDuplicates()
		duplicate_hash = {}
		for dup in duplicates:
			duplicate_hash[dup.uid] = dup
			
		dupIds = []
			
		while index < 200:
			dup_text = self.request.get('dup' + str(index))
			if not dup_text:
				break
			parts = dup_text.split('-')
			action = parts[0]
			id = int(parts[1])
			dup = duplicate_hash[id]
			if action == 'yes':
				self.confirmDuplicate(dup.primary_question, dup.secondary_question)
				self.updateMoreDups(dup.uid, dup.primary_question, dup.secondary_question, duplicates)
				dup.key.delete()
				method_question.clearDuplicateReportCache(None)
			elif action == 'swap':
				self.confirmDuplicate(dup.secondary_question, dup.primary_question)
				self.updateMoreDups(dup.uid, dup.secondary_question, dup.primary_question, duplicates)
				dup.key.delete()
				method_question.clearDuplicateReportCache(None)
			elif action == 'no':
				dup.key.delete()
				method_question.clearDuplicateReportCache(None)
			index = index + 1
		
		method_cache.clearObjectForTypeAndId('mainpage', None)
		method_cache.clearObjectForTypeAndId('rss', None)		
		self.redirect('/confirmduplicate')
		
	def updateMoreDups(self, uid, p, s, dups):
		for d in dups:
			if d.uid == uid:
				pass
			if p == d.primary_question and s == d.secondary_question:
				d.key.delete()
			elif s == d.primary_question and p == d.secondary_question:
				d.key.delete()
			elif p == d.primary_question and p == d.secondary_question:
				d.key.delete()
			elif s == d.primary_question and s == d.secondary_question:
				d.key.delete()
			elif p == d.primary_question:
				pass
			elif s == d.primary_question:
				d.primary_question = p
				method_db.putObject(d)
			elif s == d.secondary_question:
				d.secondary_question = p
				method_db.putObject(d)				
			  
	def cleanDupList(self, dups):
		duplicate_hash = {}
		cleaned = []
		for dup in dups:
			if not(dup.primary_question in duplicate_hash or dup.secondary_question in duplicate_hash):
				duplicate_hash[dup.primary_question] = True
				duplicate_hash[dup.secondary_question] = True
				cleaned.append(dup)
		return cleaned
			
			
	def get(self):
		if not method_user.userIsAdmin():
			self.redirectToLogin()
			return	  
			
		original_list = method_question.getDuplicates()
		dups = self.cleanDupList(original_list)
		hidden_count = original_list.count() - len(dups)
		template_values = {'duplicates': dups, 'hidden_count': hidden_count}
		self.pushPage(template_values, 'Confirm Duplicates', 'html/confirmduplicate.html')   
		
