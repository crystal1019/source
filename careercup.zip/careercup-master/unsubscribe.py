import masterpage
from google.appengine.ext import ndb

import method_db
import method_user
import method_url
import objects

class Unsubscribe(masterpage.MasterPage):
	def getAuthenticatedEmail(self):
		key = method_url.getId(self)
		if key:
			user = method_user.getUserWithId(key)
		else:
			user = method_user.getLoggedInUser()
			if not(user):
				self.redirectToLogin()
				return None
			key = user.uid
		email = user.user.email()
		return email	
	
	def post(self):
		email = self.request.get('email')
		if not email:
			self.response.out.write('No email submitted')
			return
			
		# if the user is not an admin, then they must have the user id key OR be actually logged in
		if not method_user.userIsAdmin():
			authenticated_email = self.getAuthenticatedEmail()
			if authenticated_email != email:
				self.redirectToLogin()
				return
						
		questions = objects.Question.query(objects.Question.subscriptions == email)
		forums = objects.ForumPost.query(objects.ForumPost.subscriptions == email)
		
		lst = []
		count_q = 0
		count_f = 0
		for q in questions:
			q.subscriptions.remove(email)
			lst.append(q)
			count_q += 1
		for f in forums:
			f.subscriptions.remove(email)
			lst.append(f)
			count_f += 1
		
		ndb.put_multi(lst)
		
		self.response.out.write('Unsubscribed from ' + str(count_q) + ' questions and ' + str(count_f) + ' forum posts.')
					
		
	def get(self):
		email = self.getAuthenticatedEmail()			
			
		q_count = objects.Question.query(objects.Question.subscriptions == email).count()
		f_count = objects.ForumPost.query(objects.ForumPost.subscriptions == email).count()		

		template_values = {}
		template_values['question_count'] = q_count
		template_values['forum_count'] = f_count				
		template_values['email'] = email
		self.response.out.write(self.getBody(template_values, 'html/unsubscribe.html'))
		
		