import sys
from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.crawler import crawl_hint
from roomhints.models import DefaultHint
from roomhints.views import add_dhint_from_raw

class Command(BaseCommand):
    help = 'Crawls a url to retrieve the image, price, and source'

    def handle(self, *args, **options):
        command = None
        url = None
        for a in args:
            if command == None:
                command = a
            elif url == None:
                url = a

        if command != "crawl" and command != "dhload":
            print "Invalid crawl command. Try: crawl or dhload"
            sys.exit(1)
        else:
            if url == None:
                print "No url provided"
            else:
            
                output = ""
                price, source, image_url, imagepath, all_imgs = crawl_hint(url)
                output += "Price:    " + str(price) + "\n"
                output += "Source:   " + str(source) + "\n"
                output += "ImageURL: " + str(image_url) + "\n"
                output += "Image:    " + str(imagepath) + "\n"
                output += "AllImgs:  " + str(all_imgs) + "\n"
                if command == "dhload":
                    # Load this as a default hint
                    dh = add_dhint_from_raw(price,url,source,imagepath)

            print output
