'''
@author: chaol
'''

from django.template import Context, loader, RequestContext
from django.http import HttpResponse, HttpResponseRedirect
import datetime, time
from models import *
from django.db import connection

from django.core.cache import cache
from django.core.paginator import *
from django.contrib.auth import authenticate
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout
from bellabustiere.userprofile.models import *
from django.conf import settings

from ShopLogging import Log
import string
from bellabustiere import common
from forms import *
import random

from django.core.mail import send_mail

from django.db.models.signals import pre_save
from django.db.models.signals import post_save
from django.contrib.auth import authenticate as _authenticate

from bellabustiere import helpers

def userCreated(sender, **kwargs):
    usr = kwargs["instance"]
    if kwargs["created"]:
        p = Profile(user=usr)
        p.save()
post_save.connect(userCreated, sender=User)



def home(request):
    return HttpResponse("Wholesalers Home")
def registered(request):
    t = loader.get_template('wholesale_registered.html')
    c = RequestContext(request,common.commonDict({'path':'register','openpath':['wholesale'],}, request))
    return HttpResponse(t.render(c))
def forgotpassword(request):
    t = loader.get_template('wholesale_forgotpassword.html')
    data = {}
    if request.POST:
        rp = request.POST.copy()
        resetform = WholesaleForgotPasswordForm(rp)
        if resetform.is_valid():
            try:
                email = resetform.cleaned_data['email'].strip().lower()
                username = helpers.create_username(email,type='member')
                User.objects.get(username=username,is_active=True)
                exists = True
            except:
                exists = False
            if exists:
                characters = string.ascii_lowercase + string.digits
                characters = characters.replace("0", "").replace("1", "").replace("l", "")
                characters = [x for x in characters]
                random.shuffle(characters)
                user = User.objects.get(username=username)
                newpass = "".join(characters[:8])
                user.set_password(newpass)
                user.save()
                data["newpassword"] = newpass
                msg = """Hi,
    Your request to reset your password on Bella Bustiere has been completed.
    
    Your new password is: %s
    
    Please login at https://www.%s/members/
    
    You can change this password to one which is more memorable by logging on at https://www.%s/members/ and updating your profile. 
    
    ---------
    
    The IP address from which the password request was received was %s""" % (newpass, settings.SITE_DOMAIN, settings.SITE_DOMAIN,request.META.get('REMOTE_ADDR'))
                send_mail(settings.SITE_NAME + " Password Reset Request", msg, 'no-reply@'+settings.SITE_DOMAIN, [user.email], fail_silently=False)
                data["message"] = "We've sent a new password to your email address."
            else:
                data["message"] = "We were unable to find your email address."
        else:
            pass
    else:
        resetform = WholesaleForgotPasswordForm()
    data["form"] = resetform
    data["path"] = 'login'
    data["openpath"] = ['wholesale']
    c = RequestContext(request,common.commonDict(data, request))
    return HttpResponse(t.render(c))
def order(request, id):
    Order.objects.get(pk=int(id), user=request.user)
    t = loader.get_template('wholesale_order.html')
    c = RequestContext(request,common.commonDict({
        'theorder': Order.objects.get(pk=int(id), user=request.user),
        'path':'profile_orders',
        'openpath':['wholesale'],
    }, request))
    return HttpResponse(t.render(c))
def orders(request):
    t = loader.get_template('wholesale_orders.html')
    c = RequestContext(request,common.commonDict({
        'orders': Order.objects.filter(user=request.user).order_by("-started"),
        'path':'profile_orders',
        'openpath':['wholesale'],
    }, request))
    return HttpResponse(t.render(c))
def profile(request):
    u = request.user
    emailmsg = ''
    msg = ''
    tempurl = request.META.get('HTTP_REFERER', '')
    if '/shop/cart.html' in tempurl:
        request.session['gotocart'] = True
    elif '/members/profile.html' in tempurl:
        pass
    else:
        request.session['gotocart'] = False
    try:
        profile = u.get_profile()
    except:
        _logout(request)
        return HttpResponseRedirect("/members/")
    t = loader.get_template('wholesale_profile.html')
    if request.POST and request.POST.get("contactupdate"):
        rp = request.POST.copy()
        if rp.get("copydata"):
            rp["billfirstname"] = rp["shipfirstname"]
            rp["billlastname"]= rp["shiplastname"] 
            rp["billcompany"] = rp["shipcompany"]
            rp["billaddress"] = rp["shipaddress"] 
            rp["billaddress2"] = rp["shipaddress2"] 
            rp["billaddress3"] = rp["shipaddress3"] 
            rp["billsuburb"] = rp["shipsuburb"] 
            rp["billstate"] = rp["shipstate"] 
            rp["billpostcode"] = rp["shippostcode"] 
            rp["billcountry"] = rp["shipcountry"] 
            rp["billphone"] = rp["shipphone"] 
            rp["billemail"] = u.email
        addressform = CustomerWDetailsForm(rp)
        if addressform.is_valid():
            s = profile.shipping_set.all()
            if s:
                shipping = s[0]
            else:
                shipping = Shipping()
                shipping.profile = profile
            shipping.first_name = addressform.cleaned_data["shipfirstname"]
            shipping.last_name = addressform.cleaned_data["shiplastname"]
            shipping.company = addressform.cleaned_data["shipcompany"]
            shipping.address = addressform.cleaned_data["shipaddress"]
            shipping.address2 = addressform.cleaned_data["shipaddress2"]
            shipping.address3 = addressform.cleaned_data["shipaddress3"]
            shipping.suburb = addressform.cleaned_data["shipsuburb"]
            shipping.state = addressform.cleaned_data["shipstate"]
            shipping.postcode = addressform.cleaned_data["shippostcode"]
            shipping.country = addressform.cleaned_data["shipcountry"]
            shipping.phone = addressform.cleaned_data["shipphone"]
            request.session["shippingcountry"] = shipping.country.country
            request.session["shippingpostcode"] = shipping.postcode
            shipping.save()
            b = profile.billing_set.all()
            if len(list(b)):
                billing = b[0]
            else:
                billing = Billing()
                billing.profile = profile
            billing.first_name = addressform.cleaned_data["billfirstname"]
            billing.last_name = addressform.cleaned_data["billlastname"]
            billing.company = addressform.cleaned_data["billcompany"]
            billing.address = addressform.cleaned_data["billaddress"]
            billing.address2 = addressform.cleaned_data["billaddress2"]
            billing.address3 = addressform.cleaned_data["billaddress3"]
            billing.suburb = addressform.cleaned_data["billsuburb"]
            billing.state = addressform.cleaned_data["billstate"]
            billing.postcode = addressform.cleaned_data["billpostcode"]
            billing.country = addressform.cleaned_data["billcountry"]
            billing.phone = addressform.cleaned_data["billphone"]
            billing.email = addressform.cleaned_data["billemail"]
            billing.save()
            updated = True
            profile.subscribe = bool(int(rp.get("subscribe", 0)))
            try:
                ip = request.META["HTTP_CF_CONNECTING_IP"] 
            except:
                ip = request.META["REMOTE_ADDR"]
            profile.save(ip=ip)
            
            request.session["shippingcountry"] = shipping.country.country
            request.session["shippingpostcode"] = shipping.postcode
            request.session["shippingsuburb"] = shipping.suburb
            
            if request.session.get('gotocart', False):
                return HttpResponseRedirect('/shop/cart.html')
    else:
        try:
            shipping = u.get_profile().shipping_set.all()[0]
        except:
            shipping = Shipping()
        try:
            billing = u.get_profile().billing_set.all()[0]
        except:
            billing = Billing()
        rp = {
              "billfirstname": billing.first_name,
              "billlastname": billing.last_name,
              "billcompany": billing.company,
              "billaddress": billing.address,
              "billaddress2": billing.address2,
              "billaddress3": billing.address3,
              "billsuburb": billing.suburb,
              "billstate": billing.state,
              "billpostcode": billing.postcode,
              "billphone": billing.phone,
              "billemail": billing.email,
              
              "shipfirstname": shipping.first_name,
              "shiplastname": shipping.last_name,
              "shipcompany": shipping.company,
              "shipaddress": shipping.address,
              "shipaddress2": shipping.address2,
              "shipaddress3": shipping.address3,
              "shipsuburb": shipping.suburb,
              "shipstate": shipping.state,
              "shippostcode": shipping.postcode,
              "shipphone": shipping.phone,
              "subscribe": int(profile.subscribe),
              }
        try:
            rp["billcountry"] = billing.country.id
        except Exception, e:
           # return HttpResponse(str(e))
            pass
        try:
            rp["shipcountry"] = shipping.country.id
        except:
            pass
        addressform = CustomerWDetailsForm(rp)
        
    if request.POST and request.POST.get("emailupdate"):
        rp = request.POST.copy()
        emailform = WholesaleProfileEmailForm(rp, theuser=u)
        if emailform.is_valid():
            request.user.email = emailform.cleaned_data["email"]
            
            email = emailform.cleaned_data["email"].strip().lower()
            
            username = helpers.create_username(email) if isWholesale(u) else helpers.create_username(email, type='member')

            request.user.username = username
            
            request.user.save()
            try:
                tbilling = request.user.get_profile().billing_set.all()[0]
                tbilling.email =email
                tbilling.save()
            except:
                pass
            emailmsg = 'Your email address is successfully updated.'
            emailform = WholesaleProfileEmailForm(theuser=u)
    else:
        emailform = WholesaleProfileEmailForm(theuser=u)
        
    if request.POST and request.POST.get("passwordupdate"):
        rp = request.POST.copy()
        passwordform = WholesaleProfilePasswordForm(rp, theuser=u)
        if passwordform.is_valid():
            u.set_password(passwordform.cleaned_data["password"])
            u.save()
            msg = 'Your password is successfully updated. '
    else:
        passwordform = WholesaleProfilePasswordForm(theuser=u)
    c = RequestContext(request,common.commonDict({
        "contactform": addressform,
        "emailform": emailform,
        "passwordform": passwordform,
        "openpath": ["profile"],
        "path":"profile",
        'openpath':['wholesale'],
        'emailmsg':emailmsg,
        'msg':msg,
    }, request))
    return HttpResponse(t.render(c))

def payment_term(request):
    t = loader.get_template('wholesale_paymentterm.html')
    c = RequestContext(request,common.commonDict({'path':'profile_paymentterms','openpath':['wholesale'],},request))
    return HttpResponse(t.render(c))

def shipping(request):
    u = request.user
    t = loader.get_template('wholesale_shipping.html')
    updated = False
    profile = u.get_profile()
    test = ""
    
    if request.POST and request.POST.get("update"):
        rp = request.POST.copy()
        rp.setdefault("agree", True)
        test = rp.lists()
        if rp.get("copydata"):
            rp["billfirstname"] = rp["shipfirstname"]
            rp["billlastname"]= rp["shiplastname"] 
            rp["billcompany"] = rp["shipcompany"]
            rp["billaddress"] = rp["shipaddress"] 
            rp["billaddress2"] = rp["shipaddress2"] 
            rp["billaddress3"] = rp["shipaddress3"] 
            rp["billsuburb"] = rp["shipsuburb"] 
            rp["billstate"] = rp["shipstate"] 
            rp["billpostcode"] = rp["shippostcode"] 
            rp["billcountry"] = rp["shipcountry"] 
            rp["billphone"] = rp["shipphone"] 
            rp["billemail"] = u.email
        addressform = CustomerWDetailsForm(rp)
        if addressform.is_valid():
            s = profile.shipping_set.all()
            if s:
                shipping = s[0]
            else:
                shipping = Shipping()
                shipping.profile = profile
            shipping.first_name = addressform.cleaned_data["shipfirstname"]
            shipping.last_name = addressform.cleaned_data["shiplastname"]
            shipping.company = addressform.cleaned_data["shipcompany"]
            shipping.address = addressform.cleaned_data["shipaddress"]
            shipping.address2 = addressform.cleaned_data["shipaddress2"]
            shipping.address3 = addressform.cleaned_data["shipaddress3"]
            shipping.suburb = addressform.cleaned_data["shipsuburb"]
            shipping.state = addressform.cleaned_data["shipstate"]
            shipping.postcode = addressform.cleaned_data["shippostcode"]
            shipping.country = addressform.cleaned_data["shipcountry"]
            shipping.phone = addressform.cleaned_data["shipphone"]
            request.session["shippingcountry"] = shipping.country.country
            request.session["shippingpostcode"] = shipping.postcode
            shipping.save()
            b = profile.billing_set.all()
            if len(list(b)):
                billing = b[0]
            else:
                billing = Billing()
                billing.profile = profile
            billing.first_name = addressform.cleaned_data["billfirstname"]
            billing.last_name = addressform.cleaned_data["billlastname"]
            billing.company = addressform.cleaned_data["billcompany"]
            billing.address = addressform.cleaned_data["billaddress"]
            billing.address2 = addressform.cleaned_data["billaddress2"]
            billing.address3 = addressform.cleaned_data["billaddress3"]
            billing.suburb = addressform.cleaned_data["billsuburb"]
            billing.state = addressform.cleaned_data["billstate"]
            billing.postcode = addressform.cleaned_data["billpostcode"]
            billing.country = addressform.cleaned_data["billcountry"]
            billing.phone = addressform.cleaned_data["billphone"]
            billing.email = addressform.cleaned_data["billemail"]
            billing.save()
            updated = True
            profile.subscribe = bool(int(rp.get("subscribe", 0)))
            profile.save()
    else:
        try:
            shipping = u.get_profile().shipping_set.all()[0]
        except:
            shipping = Shipping()
        try:
            billing = u.get_profile().billing_set.all()[0]
        except:
            billing = Billing()
        rp = {
              "billfirstname": billing.first_name,
              "billlastname": billing.last_name,
              "billcompany": billing.company,
              "billaddress": billing.address,
              "billaddress2": billing.address2,
              "billaddress3": billing.address3,
              "billsuburb": billing.suburb,
              "billstate": billing.state,
              "billpostcode": billing.postcode,
              "billphone": billing.phone,
              "billemail": billing.email,
              
              "shipfirstname": shipping.first_name,
              "shiplastname": shipping.last_name,
              "shipcompany": shipping.company,
              "shipaddress": shipping.address,
              "shipaddress2": shipping.address2,
              "shipaddress3": shipping.address3,
              "shipsuburb": shipping.suburb,
              "shipstate": shipping.state,
              "shippostcode": shipping.postcode,
              "shipphone": shipping.phone,
              "subscribe": int(profile.subscribe),
              }
        try:
            rp["billcountry"] = billing.country.id
        except Exception, e:
           # return HttpResponse(str(e))
            pass
        try:
            rp["shipcountry"] = shipping.country.id
        except:
            pass
        addressform = CustomerWDetailsForm(initial=rp)
    
    c = RequestContext(request,common.commonDict({
        "test" : test,
        "addressform": addressform,
        "openpath": ["wholesale","profile"],
        "updated": updated,
        "path":"profile_info",
    }, request))
    return HttpResponse(t.render(c))
def logout(request):
    if not request.GET.get("success"):
        _logout(request)
        return HttpResponseRedirect("logout.html?success=1")
    else:
        t = loader.get_template('loggedout.html')
        c = RequestContext(request,common.commonDict({'path':'logout'}, request))
        return HttpResponse(t.render(c))
    
def login(request):
    if request.user.is_active:
        return HttpResponseRedirect("/")
    t = loader.get_template('wholesale_login.html')
    rp = request.POST.copy()
    
    if not rp:
        tempurl = request.META.get('HTTP_REFERER', '/')
        if 'members' not in tempurl and 'checkout' not in tempurl:
            request.session['beforeloginurl'] = request.META.get('HTTP_REFERER', '/')

    beforeloginurl = request.session.get('beforeloginurl', '/')
    
    if rp.get("register"):
        return HttpResponseRedirect("register.html")
    if rp.get("memberregister"):
        return HttpResponseRedirect("register-member.html")
    if rp.get("guestcheckout"):
        order, new = helpers.getCurrentOrder(request)
        try:
            if order and request.session["shippingcountry"] and request.session["shippingpostcode"] and request.session["shippingsuburb"]:
                return HttpResponseRedirect("/shop/checkout-billing.html")
            
            return HttpResponseRedirect("/shop/cart.html")    
        except:
            return HttpResponseRedirect("/shop/cart.html")
        
    if rp.get("memberlogin", ''):
        
        form = WholesaleLoginForm()
        memberloginform = MemberLoginForm(rp)
        if memberloginform.is_valid():
            _login(request, memberloginform.user)
            profile = request.user.get_profile()
            request.session["shippingcountry"] = profile.shipping_set.get().country.country
            request.session["shippingpostcode"] = profile.shipping_set.get().postcode
            request.session["shippingsuburb"] = profile.shipping_set.get().suburb
            
            order, new = helpers.getCurrentOrder(request)
            helpers.sync_productorder(order) if order else None
            beforeloginurl = '/shop/checkout-delivery.html' if ((order and order.productorder_set.all()) or (order and order.voucherorder_set.all())) and 'cart.html' in beforeloginurl else beforeloginurl
            return HttpResponseRedirect(beforeloginurl)
    else:
        memberloginform = MemberLoginForm()
    c = RequestContext(request,common.commonDict({
        'memberloginform':memberloginform,
        'path':'login',
        'openpath':['wholesale'],
    }, request))
    return HttpResponse(t.render(c))

#member will auto active
def memberregister(request):
    t = loader.get_template('member_register.html')
    rp = request.POST.copy()
    
    if rp:
        if rp.get("copydata"):
            rp["billfirstname"] = rp["shipfirstname"]
            rp["billlastname"]= rp["shiplastname"] 
            #rp["billcompany"] = rp["shipcompany"]
            rp["billaddress"] = rp["shipaddress"] 
            rp["billaddress2"] = rp["shipaddress2"] 
            rp["billaddress3"] = rp["shipaddress3"] 
            rp["billsuburb"] = rp["shipsuburb"] 
            rp["billstate"] = rp["shipstate"] 
            rp["billpostcode"] = rp["shippostcode"] 
            rp["billcountry"] = rp["shipcountry"] 
            rp["billphone"] = rp["shipphone"] 
        addressform = MemberDetailsForm(rp)
        if addressform.is_valid():
            try:
                
                email = addressform.cleaned_data["email"].strip().lower()
                if addressform.cleaned_data["subscribe"] == "1":
                    s, created = Subscription.objects.get_or_create(email=email, defaults={"is_wholesale": False, "ip": request.META["REMOTE_ADDR"]})
                
                username = helpers.create_username(email, 'member')
                try:
                    u, created = User.objects.get_or_create(username=username, defaults={"email": email, "first_name": addressform.cleaned_data["shipfirstname"], "last_name": addressform.cleaned_data["shiplastname"], "is_active": True})
                    u.set_password(addressform.cleaned_data["password"])
                    u.save()
                except Exception, e:
                    return HttpResponse("Error creating user: "+str(e))
                #request.user = u
            except Exception, e:
                return HttpResponse("Error creating user profile: "+str(e))
            try:
                profile = u.get_profile()
            except Exception, e:
                return HttpResponse("Error fetching profile: "+str(e))
            
            s = profile.shipping_set.all()
            if s:
                shipping = s[0]
            else:
                shipping = Shipping()
                shipping.profile = profile
            shipping.first_name = addressform.cleaned_data["shipfirstname"]
            shipping.last_name = addressform.cleaned_data["shiplastname"]
            shipping.company = addressform.cleaned_data["shipcompany"]
            shipping.address = addressform.cleaned_data["shipaddress"]
            shipping.address2 = addressform.cleaned_data["shipaddress2"]
            shipping.address3 = addressform.cleaned_data["shipaddress3"]
            shipping.suburb = addressform.cleaned_data["shipsuburb"]
            shipping.state = addressform.cleaned_data["shipstate"]
            shipping.postcode = addressform.cleaned_data["shippostcode"]
            shipping.country = addressform.cleaned_data["shipcountry"]
            shipping.phone = addressform.cleaned_data["shipphone"]
            request.session["shippingcountry"] = shipping.country.country
            request.session["shippingpostcode"] = shipping.postcode
            request.session["shippingsuburb"] = shipping.suburb
            shipping.save()
            b = profile.billing_set.all()
            if len(list(b)):
                billing = b[0]
            else:
                billing = Billing()
                billing.profile = profile
            billing.first_name = addressform.cleaned_data["billfirstname"]
            billing.last_name = addressform.cleaned_data["billlastname"]
            billing.company = addressform.cleaned_data["billcompany"]
            billing.address = addressform.cleaned_data["billaddress"]
            billing.address2 = addressform.cleaned_data["billaddress2"]
            billing.address3 = addressform.cleaned_data["billaddress3"]
            billing.suburb = addressform.cleaned_data["billsuburb"]
            billing.state = addressform.cleaned_data["billstate"]
            billing.postcode = addressform.cleaned_data["billpostcode"]
            billing.country = addressform.cleaned_data["billcountry"]
            billing.phone = addressform.cleaned_data["billphone"]
            billing.email = addressform.cleaned_data["email"]
            billing.save()
            updated = True
            profile.subscribe = bool(int(rp.get("subscribe", 0)))
            profile.member = True
            try:
                ip = request.META["HTTP_CF_CONNECTING_IP"] 
            except:
                ip = request.META["REMOTE_ADDR"]
            profile.save(ip=ip)
            try:
                msg = """Dear %s %s,
                
Welcome to Bella Bustiere. To log in when visiting our site just click Login or My Account at the top of every page, and then enter your e-mail address and password.

When you log in to your account, you will be able to do the following:

    1. Proceed through checkout faster when making a purchase
    2. Check the status of orders
    3. View past orders
    4. Make changes to your account information
    5. Change your password
    
If you have any questions about your account or any other matter, please feel free to contact us at customercare@bellabustiere.com

Thanks again and we look forward to welcoming you back to our website soon! 

    
    """ % (u.first_name, u.last_name)
                send_mail("Welcome to Bella Bustiere.com", msg, 'customercare@bellabustiere.com', [u.email], fail_silently=False)
                from bellabustiere.xeroapi import *
                xero = XeroAPI()
                xero.import_single_member(u)
            except:
                pass    
            try:
                email = addressform.cleaned_data["email"].strip().lower()
                username = helpers.create_username(email, 'member')
                password = addressform.cleaned_data["password"]
                u = _authenticate(username=username, password=password)
                _login(request,u)
                profile = request.user.get_profile()
                request.session["shippingcountry"] = profile.shipping_set.get().country.country
                request.session["shippingpostcode"] = profile.shipping_set.get().postcode
                request.session["shippingsuburb"] = profile.shipping_set.get().suburb
                
                order, new = helpers.getCurrentOrder(request)
                helpers.sync_productorder(order) if order else None
            except:
                pass
            return HttpResponseRedirect("registered.html")
        
        
    else:
        addressform = MemberDetailsForm()
    
    
    c = RequestContext(request,common.commonDict({
                            'form':addressform,      
                                                  
                                                  
                                                  
                            }, request))
    
    return HttpResponse(t.render(c))


def register(request):
    t = loader.get_template('wholesale_register.html')
    rp = request.POST.copy()
    if rp:
        form = WholesaleForm(rp)
        if form.is_valid():
            try:
                
                email = form.cleaned_data["email"].strip().lower()
                if form.cleaned_data["subscribe"] == "1":
                    s, created = Subscription.objects.get_or_create(email=email, defaults={"is_wholesale": True, "ip": request.META["REMOTE_ADDR"]})
                
                username = helpers.create_username(email)
                try:
                    u, created = User.objects.get_or_create(username=username, defaults={"email": email, "first_name": form.cleaned_data["firstname"], "last_name": form.cleaned_data["lastname"], "is_active": False})
                    u.set_password(form.cleaned_data["password"])
                    u.save()
                except Exception, e:
                    return HttpResponse("Error creating user: "+str(e))
                request.user = u
            except Exception, e:
                return HttpResponse("Error creating user profile: "+str(e))
            try:
                profile = u.get_profile()
            except Exception, e:
                return HttpResponse("Error fetching profile: "+str(e))
            try:
                profile.phone = form.cleaned_data["phone"]
                profile.phone2 = form.cleaned_data["phone2"]
                profile.fax = form.cleaned_data["fax"]
                profile.company = form.cleaned_data["company"]
                profile.tradingas = form.cleaned_data["tradingas"]
                profile.abn = form.cleaned_data["abn"]
                profile.wholesale = True
                profile.subscribe = False
                if form.cleaned_data["subscribe"] == "1":
                    profile.subscribe = True
                
                profile.payment_term = PaymentTerm.objects.filter(is_default=True)[0] if PaymentTerm.objects.filter(is_default=True) else None
                
                profile.save()
            
                if not len(profile.shipping_set.all()):
                    shipping = Shipping()
                else:
                    shipping = profile.shipping_set.get()
                shipping.profile = profile
                shipping.first_name = form.cleaned_data["firstname"]
                shipping.last_name = form.cleaned_data["lastname"]
                shipping.company = form.cleaned_data["company"]
                shipping.address = form.cleaned_data["address"]
                shipping.address2 = form.cleaned_data["address2"]
                shipping.address3 = form.cleaned_data["address3"]
                shipping.suburb = form.cleaned_data["suburb"]
                shipping.state = form.cleaned_data["state"]
                shipping.postcode = form.cleaned_data["postcode"]
                shipping.country = form.cleaned_data["country"]
                shipping.phone = form.cleaned_data["phone"]
                shipping.save()
                if not len(profile.billing_set.all()):
                    billing = Billing()
                else:
                    billing = profile.billing_set.get()
                    
                billing.profile = profile
                billing.first_name = form.cleaned_data["firstname"]
                billing.last_name = form.cleaned_data["lastname"]
                billing.company = form.cleaned_data["company"]
                billing.address = form.cleaned_data["address"]
                billing.address2 = form.cleaned_data["address2"]
                billing.address3 = form.cleaned_data["address3"]
                billing.suburb = form.cleaned_data["suburb"]
                billing.state = form.cleaned_data["state"]
                billing.postcode = form.cleaned_data["postcode"]
                billing.country = form.cleaned_data["country"]
                billing.phone = form.cleaned_data["phone"]
                billing.email = form.cleaned_data["email"].strip().lower()
                billing.save()
                #u.save()
            except Exception, e:
                return HttpResponse("Error saving extra profile information: "+str(e))
            return HttpResponseRedirect("registered.html")
    else:
        form = WholesaleForm()
    c = RequestContext(request,common.commonDict({
        'form': form,
        'path':'register',
        'openpath':['wholesale'],
    }, request))
    return HttpResponse(t.render(c))
