'''
@author: chaol
'''
import datetime
from django import forms
from django.forms.util import ErrorList
from bellabustiere.userprofile.models import *

from bellabustiere.shop import generateAmountHash

from django.contrib.auth.models import User

from django.contrib.auth import authenticate as _authenticate
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout

from bellabustiere.shop.models import Order, Voucher, shippingInfoValidation, ProductReview

from django.conf import settings

from bellabustiere import helpers

class ProductReviewForm(forms.ModelForm):
    star = forms.CharField(widget=forms.HiddenInput(),initial='5')
    class Meta:
        model = ProductReview
        
    def __init__(self,*args, **kwargs):
        super(ProductReviewForm,self).__init__(*args,**kwargs)
        self.fields['product'].required = False

def get_voucher_choices():
    choices = [30, 50, 100, 200, 300, 400, 600, 800, 1000]
    return [['','------']] + [[x,x] for x in choices]

class VoucherForm(forms.ModelForm):
    recipient = models.EmailField()
    recipient_name = forms.CharField(max_length=50, widget=forms.TextInput)
    recipient_title = forms.CharField(max_length=255, widget=forms.TextInput())
    recipient_message = forms.CharField(max_length=600, widget=forms.Textarea())
    send_now = forms.BooleanField(initial=True, required=False)
    class Meta:
        model = Voucher
        
    def __init__(self, *args, **kwargs):
        super(VoucherForm, self).__init__(*args, **kwargs)
        self.fields['value'] = forms.ChoiceField(choices=get_voucher_choices(), error_messages={'required':'Please select a Value'})
        self.fields['recipient'].required = True
        self.fields['recipient_name'].required = True
        self.fields['recipient_title'].required = True
        self.fields['recipient_message'].required = True
        self.fields['valid_from'].required = False
        self.fields['valid_to'].required = False
        self.fields['send_date'].widget = forms.TextInput(attrs={'readonly':'readonly'})
        


def get_retail_customer():
    return [['','---------']]+[[x.user.id, '%s %s' %(x.user.first_name, x.user.last_name)] for x in Profile.objects.filter(user__is_staff=False, wholesale=False)]

def get_wholesale_customer():
    return [['','---------']]+[[x.user.id,x.company] for x in Profile.objects.filter(user__is_active=True,user__is_staff=False, wholesale=True)]

class OrderForm(forms.ModelForm):
    retail_customer = forms.ChoiceField(required=False, choices=get_retail_customer())
    #wholesale_customer = forms.ChoiceField(required=False, choices=get_wholesale_customer())
    class Meta:
        model = Order
        fields = ('retail_customer','status','shipping_charged','tax_charged','total_charged','method','tracking_number','special_instruction','voucher','site','sync_order','paid_from_website','paid_from_otherway','ordered')
        
    def __init__(self,*args,**kwargs):
        super(OrderForm,self).__init__(*args,**kwargs)
        self.fields['retail_customer'] =  forms.ChoiceField(required=False, choices=get_retail_customer())
        #self.fields['wholesale_customer'] = forms.ChoiceField(required=False, choices=get_wholesale_customer())
        if kwargs.has_key('instance'):
            o = kwargs['instance']
            if o.user:
                u = o.user.id
    
                if o.is_wholesale:
                    self.fields['wholesale_customer'].initial = u
                    self.fields['wholesale_customer'].help_text = o.user.email
                else:
                    self.fields['retail_customer'].initial=u
                    self.fields['retail_customer'].help_text = o.user.email
                if o.status.status != 'Shipped':
                    self.fields['total_charged'].help_text = 'total paid:%s, total unpaid:%s' %(o.getTotalPaid(),o.getOwned())
        
        
    def clean(self):
        '''if (self.cleaned_data['retail_customer'] and self.cleaned_data['wholesale_customer']):
            raise forms.ValidationError("You must choose either one retail or one wholesale customer")
        elif (not self.cleaned_data['retail_customer'] and not self.cleaned_data['wholesale_customer']):
            raise forms.ValidationError("You must choose either one retail or one wholesale customer")'''
        return self.cleaned_data
        
        
        
    def save(self, force_insert=False, force_update=False, commit=True):
        m = super(OrderForm, self).save(commit=False)
        u = self.cleaned_data['retail_customer']
        if not u:
            u = self.cleaned_data['wholesale_customer']
            
        m.user = User.objects.get(id=u)
        if commit:
            m.save()
        return m

class BillingDetailForm(forms.ModelForm):
    profile = forms.ModelChoiceField(required=False,queryset=Profile.objects.all())
    country = forms.ModelChoiceField(queryset=Country.objects.filter(shipto=True), empty_label="Please Select your Country...")
    subscribe = forms.TypedChoiceField(required=True, coerce=bool, choices=[[1, "Yes please"], [0, "No thank you"]], widget=forms.RadioSelect(attrs={'class':'field-1'}))
    copydata = forms.BooleanField(required=False)
    agree = forms.BooleanField(required=True)
    email = forms.EmailField(required=True)
    class Meta:
        model = Billing
        
class ShippingDetailForm(forms.ModelForm):
    profile = forms.ModelChoiceField(required=False,queryset=Profile.objects.all())
    country = forms.ModelChoiceField(queryset=Country.objects.filter(shipto=True), empty_label="Please Select your Country...", widget=forms.Select(attrs={'disabled':'disabled'}))
    class Meta:
        model = Shipping
    
    def __init__(self,*args,**kwargs):
       super(ShippingDetailForm,self).__init__(*args,**kwargs)
       self.fields['postcode'].widget = forms.TextInput(attrs={'disabled':'disabled'})
       self.fields['suburb'].widget = forms.TextInput(attrs={'disabled':'disabled'})
       
class BackOrderForm(forms.Form):
    firstname = forms.CharField(max_length=100, error_messages={'required':'Please enter your First Name'}, widget=forms.TextInput())
    email = forms.EmailField( error_messages={'required':'Please enter Your Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    email2 = forms.EmailField( error_messages={'required':'Please confirm Your Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    
    def clean_firstname(self):
        if self.cleaned_data['firstname']:
            if not self.cleaned_data['firstname'].strip():
                raise forms.ValidationError('Please enter your First Name')
            
        return self.cleaned_data['firstname']
    
    def clean_email2(self):
        if self.cleaned_data.has_key("email"):
            if self.cleaned_data['email2'] == self.cleaned_data['email']:
                return self.cleaned_data['email2']
            else:
                raise forms.ValidationError("Email Addresses don't match")
        else:
            return ""    
        
class MemberDetailsForm(forms.Form):
    email = forms.EmailField( error_messages={'required':'Please enter Your Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    email2 = forms.EmailField( error_messages={'required':'Please confirm Your Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    password = forms.CharField( error_messages={'required':'Please enter Your Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    password2 = forms.CharField( error_messages={'required':'Please confirm Your Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    
    billfirstname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your First Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    billlastname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your Last Name'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billcompany = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress = forms.CharField(error_messages={'required':'Please enter Your Address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billsuburb = forms.CharField(error_messages={'required':'Please enter Your Suburb'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billstate = forms.CharField(error_messages={'required':'Please enter Your State'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billpostcode = forms.CharField(max_length=5, error_messages={'required':'Please enter Your Postcode'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billcountry = forms.ModelChoiceField(error_messages={'required':'Please select Your Country'},queryset=Country.objects.filter(shipto=True), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    billphone = forms.CharField(error_messages={'required':'Please enter Your Phone Number'} ,widget=forms.TextInput(attrs={'class':'field-1'}))
    
    shipfirstname = forms.CharField(error_messages={'required':'Please enter Your First Name'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shiplastname = forms.CharField(error_messages={'required':'Please enter Your Last Name'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipcompany = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress = forms.CharField(error_messages={'required':'Please enter Your Address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipsuburb = forms.CharField(error_messages={'required':'Please enter Your Suburb'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipstate = forms.CharField(error_messages={'required':'Please enter Your State'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shippostcode = forms.CharField(max_length=5, error_messages={'required':'Please enter Your Postcode'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipcountry = forms.ModelChoiceField(error_messages={'required':'Please select Your Country'},queryset=Country.objects.filter(shipto=True), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    shipphone = forms.CharField(error_messages={'required':'Please enter Your Phone Number'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    
    subscribe = forms.TypedChoiceField(required=True, error_messages={'required':'Please choose one'},coerce=bool, choices=[[1, "Yes please"], [0, "No thank you"]], widget=forms.RadioSelect(attrs={'class':'field-1'}))
    copydata = forms.BooleanField(required=False)
    agree = forms.BooleanField(required=True, error_messages={'required':'Please agree'}) 

    def clean_email(self):
        try:
            email = self.cleaned_data['email'].strip().lower()
            username = helpers.create_username(email, type='member')
            User.objects.get(username=username)
        except Exception, e:
            return self.cleaned_data['email']
        raise forms.ValidationError("This email address is already registered")
    def clean_email2(self):
        if self.cleaned_data.has_key("email"):
            if self.cleaned_data['email2'] == self.cleaned_data['email']:
                return self.cleaned_data['email2']
            else:
                raise forms.ValidationError("Email Addresses don't match")
        else:
            return ""
    def clean_password2(self):
        if self.cleaned_data['password2'] == self.cleaned_data['password']:
            return self.cleaned_data['password2']
        else:
            raise forms.ValidationError("Passwords don't match")  
        
    def clean(self):
        
        if self.data['shipsuburb'] and self.data['shippostcode'] and self.data['shipcountry']:
            country = Country.objects.get(id=self.data['shipcountry'])
            msg = shippingInfoValidation(self.data['shippostcode'],self.data['shipsuburb'],country.country)
            if msg:
                raise forms.ValidationError(msg)
        
        return self.cleaned_data
            
      
       
###################################
class CustomerDetailsForm(forms.Form):
    billfirstname = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class':'field-1'}))
    billlastname = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class':'field-1'}))
    billcompany = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billsuburb = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    billstate = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    billpostcode = forms.CharField(max_length=5, widget=forms.TextInput(attrs={'class':'field-1'}))
    billcountry = forms.ModelChoiceField(queryset=Country.objects.filter(shipto=True).order_by("country"), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    billphone = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billemail = forms.EmailField(widget=forms.TextInput(attrs={'class':'field-1'}))
    shipfirstname = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    shiplastname = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    shipcompany = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipsuburb = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    shipstate = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    shippostcode = forms.CharField(max_length=5, widget=forms.TextInput(attrs={'class':'field-3','disabled':'disabled'}))
    shipcountry = forms.ModelChoiceField(queryset=Country.objects.filter(shipto=True).order_by('country'), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-3','disabled':'disabled'}))
    shipphone = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    subscribe = forms.TypedChoiceField(required=True, coerce=bool, choices=[[1, "Yes please"], [0, "No thank you"]], widget=forms.RadioSelect(attrs={'class':'field-1'}))
    copydata = forms.BooleanField(required=False)
    agree = forms.BooleanField(required=True)
    
    
class CustomerWDetailsForm(forms.Form):
    billfirstname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your First Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    billlastname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your Last Name'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billcompany = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress = forms.CharField(error_messages={'required':'Please enter Your Address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billaddress3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billsuburb = forms.CharField(error_messages={'required':'Please enter Your Suburb'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billstate = forms.CharField(error_messages={'required':'Please enter Your State'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billpostcode = forms.CharField(max_length=5, error_messages={'required':'Please enter Your Postcode'},widget=forms.TextInput(attrs={'class':'field-1'}))
    billcountry = forms.ModelChoiceField(error_messages={'required':'Please select Your Country'},queryset=Country.objects.filter(shipto=True).order_by("country"), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    billphone = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    billemail = forms.EmailField(required=False,error_messages={'required':'Please enter Your Email Address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipfirstname = forms.CharField(error_messages={'required':'Please enter Your First Name'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shiplastname = forms.CharField(error_messages={'required':'Please enter Your Last Name'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipcompany = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress = forms.CharField(error_messages={'required':'Please enter Your Address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipaddress3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    shipsuburb = forms.CharField(error_messages={'required':'Please enter Your Suburb'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipstate = forms.CharField(error_messages={'required':'Please enter Your State'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shippostcode = forms.CharField(max_length=5, error_messages={'required':'Please enter Your Postcode'},widget=forms.TextInput(attrs={'class':'field-1'}))
    shipcountry = forms.ModelChoiceField(error_messages={'required':'Please select Your Country'},queryset=Country.objects.filter(shipto=True).order_by('country'), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    shipphone = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    subscribe = forms.TypedChoiceField(required=True, coerce=bool, choices=[[1, "Yes please"], [0, "No thank you"]], widget=forms.RadioSelect(attrs={'class':'field-1'}))
    
    def clean(self):
        
        if self.data['shipsuburb'] and self.data['shippostcode'] and self.data['shipcountry']:
            country = Country.objects.get(id=self.data['shipcountry'])
            msg = shippingInfoValidation(self.data['shippostcode'],self.data['shipsuburb'],country.country)
            if msg:
                raise forms.ValidationError(msg)
        
        return self.cleaned_data

class WholesaleLoginForm(forms.Form):
    email = forms.EmailField(required=True, error_messages={'required':'Please enter a valid email address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    password = forms.CharField(required=True, error_messages={'required':'The password you provided does not match our records'},widget=forms.PasswordInput(attrs={'class':'field-1'}))
    user = None
    def clean(self):
        email = self.cleaned_data.get("email", "").strip().lower()
        username = helpers.create_username(email)
        password = self.cleaned_data.get("password","")
        self.user = _authenticate(username=username, password=password)
        if self.user:
            if self.user.is_active:
                return self.cleaned_data
            else:
                raise forms.ValidationError("Your account is pending approval.")
        else:
            raise forms.ValidationError("Login Failed. Please enter your correct email address and password.")
        
class MemberLoginForm(forms.Form):
    memberemail = forms.EmailField(required=True, error_messages={'required':'Please enter a valid email address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    memberpassword = forms.CharField(required=True, error_messages={'required':'The password you provided does not match our records'},widget=forms.PasswordInput(attrs={'class':'field-1'}))
    user = None
    def clean(self):
        email = self.cleaned_data.get("memberemail", "").strip().lower()
        username = helpers.create_username(email, 'member')
        password = self.cleaned_data.get("memberpassword","")
        self.user = _authenticate(username=username, password=password)
        if self.user:
            if self.user.is_active:
                return self.cleaned_data
            else:
                raise forms.ValidationError("Your account is pending approval.")
        else:
            raise forms.ValidationError("Login Failed. Please enter your correct email address and password.")
 
class WholesaleProfilePrimaryContactForm(forms.Form):
    firstname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your First Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    lastname = forms.CharField(max_length=100,  error_messages={'required':'Please enter Your Last Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    phone = forms.CharField( error_messages={'required':'Please enter Your Phone Number'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    phone2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    fax = forms.CharField( error_messages={'required':'Please enter Your Fax Number'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    company = forms.CharField( error_messages={'required':'Please enter Your Company Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    tradingas = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    abn = forms.CharField( error_messages={'required':'Please enter Your ABN'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    subscribe = forms.TypedChoiceField(required=True,  error_messages={'required':'Please select'}, choices=[[1, "Yes please"], [0, "No thank you"]], widget=forms.RadioSelect(attrs={'class':'field-1'}))


class WholesaleProfileEmailForm(forms.Form):
    current = forms.EmailField( error_messages={'required':'Please enter Your Current Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    email = forms.EmailField( error_messages={'required':'Please enter Your New Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    email2 = forms.EmailField( error_messages={'required':'Please confirm Your New Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    user = None
    
    def __init__(self, *args, **kwargs):
        if 'theuser' in kwargs.keys():
            u = kwargs['theuser']
            
            del kwargs['theuser']
        super(WholesaleProfileEmailForm, self).__init__(*args, **kwargs)
        self.user = u
        
    def clean_current(self):
        if self.user:
            email = self.user.email
            if email != self.cleaned_data['current'].strip().lower():
                raise forms.ValidationError("This is not your current email address")
            
        return self.cleaned_data['current']
    
    def clean_email(self):
        try:
            email = self.cleaned_data['email'].strip().lower()
            username = helpers.create_username(email)
            User.objects.get(username=username)
        except:
            return self.cleaned_data['email']
        raise forms.ValidationError("This email address is already registered")
    
    def clean_email2(self):
        if self.cleaned_data.has_key("email"):
            if self.cleaned_data['email2'] == self.cleaned_data['email']:
                return self.cleaned_data['email2']
            else:
                raise forms.ValidationError("Email Addresses don't match")
        else:
            return ""    
    
           
class WholesaleProfilePasswordForm(forms.Form):
    passcurrent = forms.CharField( error_messages={'required':'Please enter Your Current Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    password = forms.CharField( error_messages={'required':'Please enter Your New Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    password2 = forms.CharField( error_messages={'required':'Please confirm Your New Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    user = None
    
    def __init__(self, *args, **kwargs):
        if "theuser" in kwargs:
            u = kwargs['theuser']
        
            del kwargs['theuser']
        super(WholesaleProfilePasswordForm,self).__init__(*args, **kwargs)
        self.user = u
        
    def clean_passcurrent(self):
        uu = _authenticate(username=self.user.username, password=self.cleaned_data['passcurrent'])
        if not uu:
            raise forms.ValidationError('This is not your current password')
        
        else:
            return self.cleaned_data['passcurrent']
            
        

    def clean_password2(self):
        if self.cleaned_data['password2'] == self.cleaned_data['password']:
            return self.cleaned_data['password2']
        else:
            raise forms.ValidationError("Passwords don't match")
        
class WholesaleProfileAddressForm(forms.Form):
    address = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    address2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    address3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    suburb = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    state = forms.CharField(widget=forms.TextInput(attrs={'class':'field-1'}))
    postcode = forms.CharField(max_length=5, widget=forms.TextInput(attrs={'class':'field-1'}))
    country = forms.ModelChoiceField(queryset=Country.objects.filter(shipto=True), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    
    def clean_email(self):
        try:
            username = self.cleaned_data['email'].strip().lower()
            username = username.replace("@", "_")
            username = username.replace(".", "_")
            User.objects.get(username=username)
        except Exception, e:
            return self.cleaned_data['email']
        raise forms.ValidationError("This email address is already registered")
    def clean_email2(self):
        if self.cleaned_data.has_key("email"):
            if self.cleaned_data['email2'] == self.cleaned_data['email']:
                return self.cleaned_data['email2']
            else:
                raise forms.ValidationError("Email Addresses don't match")
        else:
            return ""
    def clean_password2(self):
        if self.cleaned_data['password2'] == self.cleaned_data['password']:
            return self.cleaned_data['password2']
        else:
            raise forms.ValidationError("Passwords don't match")

class WholesaleForm(forms.Form):
    firstname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your First Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    lastname = forms.CharField(max_length=100, error_messages={'required':'Please enter Your Last Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    email = forms.EmailField( error_messages={'required':'Please enter Your Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    email2 = forms.EmailField( error_messages={'required':'Please confirm Your Email Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    phone = forms.CharField( error_messages={'required':'Please enter Your Phone Number'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    phone2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    fax = forms.CharField( error_messages={'required':'Please enter Your Fax Number'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    company = forms.CharField( error_messages={'required':'Please enter Your Company Name'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    tradingas = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    abn = forms.CharField( error_messages={'required':'Please enter Your ABN'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    address = forms.CharField( error_messages={'required':'Please enter Your Address'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    address2 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    address3 = forms.CharField(required=False, widget=forms.TextInput(attrs={'class':'field-1'}))
    suburb = forms.CharField( error_messages={'required':'Please enter Your Suburb'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    state = forms.CharField( error_messages={'required':'Please enter Your State'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    postcode = forms.CharField( error_messages={'required':'Please enter Your Postcode'}, max_length=5, widget=forms.TextInput(attrs={'class':'field-1'}))
    country = forms.ModelChoiceField( error_messages={'required':'Please select Your Country'}, queryset=Country.objects.filter(shipto=True).order_by("country"), empty_label="Select your Country...", widget=forms.Select(attrs={'class':'field-1'}))
    subscribe = forms.TypedChoiceField(required=True,  error_messages={'required':'Please choose one'}, coerce=str, choices=[["1", "Yes please"], ["0", "No thank you"]], widget=forms.RadioSelect(attrs={'class':'field-1'}))
    password = forms.CharField( error_messages={'required':'Please enter Your Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    password2 = forms.CharField( error_messages={'required':'Please confirm Your Password'}, widget=forms.PasswordInput(attrs={'class':'field-1'}))
    agree = forms.BooleanField(required=True, error_messages={'required':'Please agree'}, )
    def clean_email(self):
        try:
            email = self.cleaned_data['email'].strip().lower()
            username = helpers.create_username(email)
            User.objects.get(username=username)
        except Exception, e:
            return self.cleaned_data['email']
        raise forms.ValidationError("This email address is already registered")
    def clean_email2(self):
        if self.cleaned_data.has_key("email"):
            if self.cleaned_data['email2'] == self.cleaned_data['email']:
                return self.cleaned_data['email2']
            else:
                raise forms.ValidationError("Email Addresses don't match")
        else:
            return ""
    def clean_password2(self):
        if self.cleaned_data['password2'] == self.cleaned_data['password']:
            return self.cleaned_data['password2']
        else:
            raise forms.ValidationError("Passwords don't match")
class WholesaleForgotPasswordForm(forms.Form):
    email = forms.EmailField(error_messages={'required':'Please enter Your Email Address'},widget=forms.TextInput(attrs={'class':'field-1'}))
    def clean_email(self):
        try:
            return self.cleaned_data['email']
        except Exception, e:
            raise forms.ValidationError("We were unable to find this email address.")
def generateMonths():
    return [[str(x).zfill(2),str(x).zfill(2)] for x in range(1, 13)]
def generateYears():
    d = datetime.datetime.now()
    return [[str(x),str(x)] for x in range(d.year, d.year+11)]
class CreditCardForm(forms.Form):
    name = forms.CharField(max_length=80, error_messages={'required':'Please insert your Name on Card as: Firstname Lastname'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    type = forms.CharField(max_length=10, widget=forms.Select(attrs={'class':'field-1'}, choices=(("VISA", "VISA",), ("Mastercard", "Mastercard",), ('AMEX', 'AMEX'))))
    number = forms.CharField(max_length=100, error_messages={'required':'Credit Card Number failed verification.'}, widget=forms.TextInput(attrs={'class':'field-1'}))
    expiryMonth = forms.IntegerField(widget=forms.Select(attrs={'class':'expiryfield'}, choices=generateMonths()))
    expiryYear = forms.IntegerField(widget=forms.Select(attrs={'class':'expiryfield'}, choices=generateYears()))
    CVV = forms.CharField(widget=forms.TextInput(attrs={'maxlength': 4, 'size': 4, 'class':'smallfield-1'}))
    #amount = forms.FloatField(widget=forms.HiddenInput())
    #hash = forms.CharField(widget=forms.HiddenInput())
    errormessage = ""
    #
    # Next 2 methods are validation of the credit card number.
    #
    
    def clean_name(self):
        temp = self.cleaned_data['name'].strip().split(' ')
        if len(temp) not in [2,3]:
            raise forms.ValidationError("Please insert name as this: Firstname Lastname or Firstname Middlename Lastname")
        else:
            return self.cleaned_data['name']
    def clean_hash(self):
        if self.cleaned_data['hash'] == generateAmountHash(self.cleaned_data['amount']):
            return self.cleaned_data['hash']
        else:
            raise forms.ValidationError("Amount checksum mismatch")
    def check_number(self, number):
        """
        Luhn credit card number check
        """
        number = number.replace(" ", "")
        number = number.replace("-", "")
        try:
            number = int(number)
        except:
            return False
        digits = number
        _sum = 0
        alt = False
        ix = []
        for x in str(digits):
            ix.append(int(x))
        for d in reversed(ix):
            assert 0 <= d <= 9
            if alt:
                d *= 2
                if d > 9:
                    d -= 9
            _sum += d
            alt = not alt
        return (_sum % 10) == 0
    def processingError(self, msg):
        self.errormessage = msg
    def clean(self):
        return self.cleaned_data
    # do the forms validation for the ccnumber
    def clean_number(self):
        if self.check_number(self.cleaned_data['number']):
            return self.cleaned_data['number']
        else:
            raise forms.ValidationError("Credit Card Number failed verification")
    # check to make sure their credit card hasn't expired
    def clean_expiryYear(self):
        now = datetime.datetime.now()
	day = now.day if now.day <= 28 else 28
        exp = datetime.datetime(self.cleaned_data['expiryYear'], self.cleaned_data['expiryMonth'], day)
        if now <= exp or (now.month == exp.month and now.year == exp.year):
            return self.cleaned_data['expiryYear']
        else:
            raise forms.ValidationError("Your Card has expired")
