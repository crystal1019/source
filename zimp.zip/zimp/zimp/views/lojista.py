import random
import datetime
import json
from django.http import HttpResponseRedirect
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, Page
from django.contrib.auth.decorators import login_required
from django.utils.formats import mark_safe
from django.shortcuts import render
from django.db import transaction
from zimp.models import *
from .utils import *


def test(request):
    types = [0, 0, 0, 0, 1, 2, 2, 3, 3]
    from_list = ['1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', '5b54b89a-7cdb-11e3-8a1e-6cf049f765f5', '6e0a29cf-7cdb-11e3-8a1e-6cf049f765f5']
    to_list = ['ca141cae-7cd4-11e3-8a1e-6cf049f765f5', 'c49d5c94-7cd4-11e3-8a1e-6cf049f765f5', 'bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 'b524a81e-7cd4-11e3-8a1e-6cf049f765f5']
    cur = connection.cursor()
    for ct in range(1000):
        r = Transaction.objects.register(
            **{
                'from_id': from_list[random.randint(0, len(from_list) - 1)],
                'to_id': to_list[random.randint(0, len(to_list) - 1)],
                'value': random.randint(10, 1000),
                'promotion': '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5'
            }
        )
        t = Transaction.objects.get(id=r[1][2])
        d = datetime.datetime(year=2014, month=1, day=1)
        d += datetime.timedelta(days=random.randint(0, 364))
        d += datetime.timedelta(seconds=random.randint(0, 80000))
        cur.execute('''update transactions set created_at = %s, type = %s where id = %s''', (d, types[random.randint(0, len(types) - 1)], t.id))
        transaction.commit()
    return render(request, 'zimp/lojista/test.html', {
        'r': json.dumps(r),
    })
