from django import forms
from datetime import date
from offers.core.models import Offer
from offers.tools.smart_search.models import STATUS_CHOICES
from offers.helpers.lead.models import State
from offers.helpers.lead.helpers import get_age


    
class CardForm(forms.Form):
    title = forms.CharField(widget=forms.TextInput(attrs = {'placeholder': 'start typing the name of your card here'}))
    
    def clean_title(self):
        title = self.cleaned_data['title']
        try:
            Offer.objects.get(title=title)
        except Offer.DoesNotExist:
            raise forms.ValidationError(u'Please select your card from the dropdown list.')
        except Offer.MultipleObjectsReturned:
            pass
        return title

class BetterCardForm(forms.Form):
    year_now = date.today().year
    def create_choices(x,y,z):
        choice_range = range(x,y,z)
        return zip(choice_range, choice_range)
    title = forms.CharField(widget=forms.HiddenInput())
    monthly = forms.DecimalField(initial=1000, widget=forms.HiddenInput())
    transfered = forms.DecimalField(initial=0, widget=forms.HiddenInput())
    repayment = forms.DecimalField(initial=2, widget=forms.HiddenInput())
    first_name = forms.CharField(max_length=250)
    last_name = forms.CharField(max_length=250)
    birthday = forms.ChoiceField(choices=create_choices(1,31+1,1))
    birthmonth = forms.ChoiceField(choices=create_choices(1,12+1,1))
    birthyear = forms.ChoiceField(choices=create_choices(year_now-10,
                                                          year_now-100,
                                                          -1))
    work_status = forms.ChoiceField(choices=(('None', 'Please select'),)+STATUS_CHOICES)
    annual_income = forms.DecimalField()
    card_ownership_duration = forms.IntegerField(initial = 'How long have you had your current card?')
    state = forms.ChoiceField(choices=([('None', 'Please select'),]+[(s.id, s.name) for s in State.objects.all()]))
    email = forms.EmailField(initial='you@example.com', required=False)
    terms = forms.BooleanField(initial=True, required=True, error_messages={'required': 'You must agree to the terms and conditions.'})
    annual = forms.DecimalField(initial=0, widget=forms.HiddenInput())
    purchase = forms.DecimalField(initial=10, widget=forms.HiddenInput())
    
    exclude_inactive = forms.BooleanField(initial=True, required=False)
    
    def __init__(self, *args, **kwargs):
        super(BetterCardForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].error_messages['required'] = 'Please enter your first name'
        self.fields['last_name'].error_messages['required'] = 'Please enter your last name'
        self.fields['annual_income'].error_messages['required'] = 'Please enter your income'
        self.fields['card_ownership_duration'].error_messages['invalid'] = 'Please enter the number of months you have had your current card.'
        
    def clean_email(self):
        email = self.cleaned_data['email']
        if email == 'you@example.com':
            raise forms.ValidationError(u'Please enter a valid email address.')
        return email
    
    def clean_work_status(self):
        work_status = self.cleaned_data['work_status']
        if work_status == 'None':
            raise forms.ValidationError(u'Please select employment status.')
        return work_status
    
    def clean_state(self):
        state = self.cleaned_data['state']
        if state == 'None':
            raise forms.ValidationError(u'Please select a state.')
        return state
    
    def clean_birthyear(self):
        if get_age(self.cleaned_data) < 18:
            raise forms.ValidationError(u'You must be at least 18 years old' +
                                        ' to apply for a credit card.')
        return self.cleaned_data['birthyear']