# Create your views here.
from arkstart.userprofile.models import *
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader, RequestContext
from arkstart.userprofile.forms import *
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout
from django.core.mail import send_mail
from arkstart.website.models import *
from arkstart import common

def register(request):
    t = loader.get_template('register.html')
    rp = request.POST
    rg = request.GET
    msg = ''
    if rp:
        form = ProfileForm(rp)
        if form.is_valid():
            p = form.save()
            msg = 'Thank you, you are successfully registered.'
            form = ProfileForm()
            message = '''Congratulations on joining ArkStart. Our aim is to provide you with up to date and useful information to help you manage your finances.
 
Feel free to ask us a question to get started.
 
Regards,
Alex Lee
Founder ArkStart
            '''
            send_mail('Welcome to ArkStart',message ,'alex.lee@arktotalwealth.com.au', [p.user.email])
    else:
        if rg:
            form = ProfileForm(rg)
        else:
            form = ProfileForm()
        
    c = RequestContext(request,{
        'form':form,
        'msg':msg,
                                
    })
    
    return HttpResponse(t.render(c))

def login(request):
    t = loader.get_template('login.html')
    rp =request.POST
    rg = request.GET
    if rg.get('type','') == 'detailpage':
        t = loader.get_template('login-inside.html')
    msg = ''
    if rp:
        form = LoginForm(rp)
        if form.is_valid():
            _login(request, form.user)
            msg = 'You are successfully logged in'
            form = LoginForm()
    else:
        form = LoginForm()
        
    c = RequestContext(request,{
        'form':form,
        'msg':msg,
                                
    })
    return HttpResponse(t.render(c))

def logout(request):
    _logout(request)
    return HttpResponseRedirect('/')


def catchall(request, path):
    t = loader.get_template('page.html')
    document = MiscPage.objects.get(path=path)
    
    c = RequestContext(request, common.commonDict({
        'document':document,                              
    },request))
    return HttpResponse(t.render(c))