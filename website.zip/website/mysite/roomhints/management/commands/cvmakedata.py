from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.models import Hint
from datetime import datetime, timedelta
from roomhints.utils import random_number, make_unique, make_unique_photo, search_profile_id, photo_convert
import shutil
from roomhints.color import get_color_stats
from roomhints.affiliate import affiliate_data, affiliate_set
import os
import sys

from PIL import Image

class Command(BaseCommand):
    help = 'Make sure all hints in search use small pictures'

    def handle(self, *args, **options):
        cv = None
        ht = None
        parity = None
        for a in args:
            if cv == None:
                cv = a
            elif ht == None:
                ht = int(a)
            elif parity == None:
                parity = a

        if ht == None or parity == None or (parity != "pos" and parity != "neg"):
            print("usage: cvmakedata <opencv/ccv> <hinttype_id> <pos/neg>")
            sys.exit()
        #hall = Hint.objects.filter(profile_id=search_profile_id()).all()
        # ht-5 Lamp (Short), ht-6 Lamp (Tall
        # ht-2 Couch, ht-8 Couch sectional, ht-7 Sofa/Loveseat
        # ht-25 Chair plain, ht-15 chair loung, ht-24 chair office
        # ht-16 Dresser
        # ht-17 Nightstand
        # ht-30 Stool
        # ht-18 Bench
        # ht-29 Ottoman
        # ht-3 Desk
        parity_sql = ""
        if parity == "neg":
            if ht == 5:
                # A lamp is not a couch or a dresser or a nightstand or a stool or a chair, bench, ottoman, desk
                parity_sql = " and (ht.id=2 or ht.id=7 or ht.id=8 or ht.id=16 or ht.id=17 or ht.id=30 or ht.id=25 or ht.id=15 or ht.id=24 or ht.id=18 or ht.id=29 or ht.id=3)"
            elif ht == 2:
                # A couch is not a dresser or a lamp, or a chair, or a stool or a nightsand or a desk
                parity_sql = " and (ht.id=16 or ht.id=5 or ht.id=6 or ht.id=25 or ht.id=15 or ht.id=24 or ht.id=30 or ht.id=17 or ht.id=3)"
        elif parity == "pos":
            if ht == 2: # Couch
                parity_sql = " and (ht.id=2 or ht.id=8 or ht.id=7)"
            elif ht == 5: # Lamp
                parity_sql = " and (ht.id=5 or ht.id=6)"
            elif ht == 25: # chair
                parity_sql = " and (ht.id=25 or ht.id=15 or ht.id=24)"
            else:
                parity_sql = " and ht.id = " + str(ht)

        sql = "select h.id, h.photo_web, h.cx, h.cy, h.ch, h.cw from roomhints_hint h, roomhints_hinttype ht, roomhints_hinttypelist htl where h.public = true and htl.hinttype_id = ht.id and htl.hint_id = h.id and h.profile_id=" + str(search_profile_id()) + parity_sql
        cursor = connection.cursor()
        cursor.execute(sql)
        output = ""
        for row in cursor.fetchall():
            id = row[0]
            photo = row[1]
            cx = row[2]
            cy = row[3]
            ch = row[4]
            cw = row[5]
            image_file = settings.MEDIA_ROOT + photo
            # opencv_createsamples expects a relative path
            dst = "/home/roomhints/devel/RH/imaging/test/data/" + str(ht) + "/images/" + str(id)
            # if not os.path.islink(dst):
            #     print ("image_file is: " + image_file + "\ndst is" + dst)
            #     os.symlink(image_file, dst)
            try:
                with open(image_file):
                    if cw != None and cw != 0:
                        shutil.copy(image_file,dst)
                        output += "images/" + str(id)
                        if parity == "pos":
                            if cv == "opencv":
                                output += " 1" #one item
                            elif cv == "ccv":
                                #image = Image.open(image_file)
                                #width,height = image.size
                                output += "" # Do not enumerate items
                                output += " " + str(cx) + " " + str(cy) + " " + str(cx+cw) + " " + str(cy+ch) # Coordinates marked by user
                        output += "\n"
            except IOError:
                #print 'File ' + image_file + " does not exist\n"
                pass
        cursor.close()
        print output,
