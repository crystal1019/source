/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	JS Library.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
ieHover = function() {
	var ieEls = document.getElementById("page").getElementsByTagName("LI");
	for (var i=0; i<ieEls.length; i++) {
		ieEls[i].onmouseover=function() { this.className+=" hover"; }
		ieEls[i].onmouseout=function() { this.className=this.className.replace(new RegExp(" hover\\b"), ""); }
	}
};
if (window.attachEvent) window.attachEvent("onload", ieHover);
try{document.execCommand("BackgroundImageCache",false,true);}catch(err){}
function resetInput(){
	jQuery('input[value]').each(function(){
		if(this.type == 'text' || this.type == 'password') {
			jQuery(this).focus(function(){ if (this.value == this.defaultValue) { this.value = ''; }
			}).blur(function(){ if (!this.value.length) { this.value = this.defaultValue; }});
		}
	});
	jQuery('textarea').each(function(){
		jQuery(this).focus(function(){ if (this.value == this.defaultValue) { this.value = ''; }
		}).blur(function(){ if (!this.value.length) { this.value = this.defaultValue; }});
	});
};
$(document).ready(function() {
	resetInput();
	$('#signup-button').click(function(evt) {
		evt.stopPropagation();
		evt.preventDefault();
		if (validate('newsletter-form','email')){
			signup(evt, '#newsletter-form');
		};
	});
	$('.ebook-button').click(function(evt) {
		evt.stopPropagation();
		evt.preventDefault();
		if (validate('ebook-form','email')){
			signup(evt, '#ebook-form');
		};
	});
});
function signup(evt, form_id){
	jQuery.ajax({
		type: 'GET',
		url: $(form_id).attr('action'),
		data: $(form_id).serialize(),
		dataType: 'json',
		error: function() {
			$(form_id).html('failed to send email address');
		},
		success: function(data) {
			$(form_id).html(data.result);
		}
	});
};
function validate(form_id,email) {
   var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
   var address = document.forms[form_id].elements[email].value;
   if(reg.test(address) == false) {
      alert('Invalid Email Address');
      return false;
   }else{
   	  return true;
   };
};
