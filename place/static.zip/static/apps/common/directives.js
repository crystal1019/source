angular.module('common.directives', [])
    .directive("errorpopover", [

        function() {
            return {
                scope: true,
                link: function(scope, elem, attrs) {
                    $(elem).mouseenter(function() {
                        $(elem).popover({
                            html: true,
                            content: "<p>Information on this tab has not been filled out correctly, please correct information before saving.</p>"
                        }).popover('show')
                        $('.popover').addClass('valid-error');
                    });

                    $(elem).mouseout(function() {
                        $(elem).popover('hide');
                        $('.popover').removeClass('valid-error');
                    });
                }
            };
        }
    ])
    .directive("uploadDisabled", [

        function() {
            return {
                scope: true,
                link: function(scope, elem, attrs) {
                    console.log("!")
                    $(elem).mouseenter(function() {
                        console.log("!!")
                        $(elem).popover({
                            html: true,
                            content: "<p>KML and Shapefile uploads are available on Premium and Enterprise plans only.</p>"
                        }).popover('show')
                        $('.popover').addClass('valid-error');
                    });

                    $(elem).mouseout(function() {
                        console.log("-!")
                        $(elem).popover('hide');
                        $('.popover').removeClass('valid-error');
                    });
                }
            };
        }
    ])
    .directive('uniform', ["$timeout",
        function($timeout) {
            return {
                restrict: 'A',
                require: 'ngModel',
                link: function(scope, element, attr, ngModel) {
                    element.uniform({
                        useID: false
                    });
                    scope.$watch(function() {
                        return ngModel.$modelValue;
                    }, function() {
                        $timeout(jQuery.uniform.update, 0);
                    });
                }
            };
        }
    ])
    .filter("nl2br", [

        function() {
            return function(data) {
                if (!data) return data;
                return data.replace(/\n\r?/g, '<br/>');
            };
        }
    ])
    .directive("videourl", [

        function() {
            return {
                require: '?ngModel',
                link: function($scope, elem, attrs, ctrl) {
                    ctrl.$parsers.unshift(function(viewValue) {
                        console.log(getVideoID(viewValue))
                        if (getVideoID(viewValue)) {
                            ctrl.$setValidity('videourl', true);
                            return viewValue;
                        }
                        ctrl.$setValidity('videourl', false);
                        return undefined;
                    });
                }
            }
        }
    ])
    .directive('modalsize', [

        function() {
            return function(scope, elem, attrs) {
                $(elem).parent('div').addClass(attrs.modalsize);
                if (attrs.modalsize == 'fullscreen') {
                    var footer_h = $(elem).children('.modal-footer').outerHeight();
                    var window_h = $(window).outerHeight() * 0.9;
                    $(elem).children('.modal-body').height(window_h - footer_h);
                }
                if (attrs.modalsize == 'maximum') {
                    elem.parent().css('z-index', 9999);
                    elem.parent().height(window.innerHeight);
                    elem.parent().width(window.innerWidth);
                }
            };
        }
    ]).filter('videothumbnail', [

        function() {
            return function(input) {
                return getVideoID(input)
            };
        }
    ]).filter('thumbnailexists', [

        function() {
            return function(image) {
                if (angular.isDefined(image.thumbnails) && image.thumbnails !== null) {
                    return image.thumbnails.url;
                }
                if (image) {
                    if (image.url) {
                        return image.url;
                    }
                }
                return "";
            };
        }
    ]).filter('reverse', function() {
        return function(items) {
            if (angular.isArray(items)) {
                return items.slice().reverse();
            }
            return items;
        };
    })
    .directive("fadeOut", [

        function() {
            return {
                link: function(scope, elem, attrs) {
                    scope.$watch(function() {
                        return elem.is(':visible');
                    }, function(visible) {
                        if (visible) {
                            setTimeout(function() {
                                elem.fadeOut(function() {
                                    if (typeof scope[attrs['ngShow']] === "boolean") {
                                        scope.safeApply(function() {
                                            scope[attrs['ngShow']] = false;
                                        });
                                    }
                                });
                            }, 3000);
                        }
                    });
                }
            };
        }
    ])
    .directive('isotopeContainer', ["$timeout", function ($timeout) {
        return {
            restrict: 'A',
            scope: {
                topics: "=topics",
                current_tab: "=?currentTab",
                required_tab: "=?requiredTab",
                highlight_featured: "=?highlightFeatured",
                loadMetrics: "&?"
            },
            templateUrl: function(elem, attrs) {
                if(angular.isDefined(attrs.templateUrl)){
                    return attrs.templateUrl;
                }
                return "/static/apps/common/partials/topic_card.html";
            },
            replace: false,
            link: function (scope, elem, attrs) {
                var w = scope.$watchCollection('[topics, current_tab]', function(nv, ov){
                    if((scope.topics !== null && scope.current_tab == scope.required_tab) || (scope.topics !== null && _.isUndefined(scope.current_tab))) {
                        elem.addClass("topic_boxes");
                        console.log("starting isotope");
                        $timeout(function(){
                            console.log('in timeout')
                            elem.imagesLoaded(function(){
                                console.log('images loaded - starting layout');
                                elem.isotope({
                                    itemSelector: '.topic_box',
                                    resizable: false,
                                    containerStyle: {
                                        position: 'relative',
                                        overflow: 'visible',
                                        margin: '0px 0px 30px'
                                    },
                                    masonry: {
                                        columnWidth: 220,
                                        gutterWidth: 19
                                    }
                                });
                            });
                            w();
                        }, 0, false);
                    }
                });
            }
        };
    }])
    .filter('capitalize', function() {
        return function(input, all) {
          return (!!input) ? input.replace(/([^\W_]+[^\s-]*) */g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();}) : '';
        }
    })
    .directive('topicMetrics', [function () {
        return {
            link: function (scope, elem, attrs) {
                scope.$watch('topic.metrics', function(nv, ov){
                    if(nv){
                        elem.slideDown(function(){
                            $("#profile_topic_boxes_2").isotope('reLayout');
                        });
                    }
                });
            }
        };
    }]);