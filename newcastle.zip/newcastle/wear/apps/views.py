from django.shortcuts import render
from apps.forms import LoginForm
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponseRedirect
# Create your views here.
from django.shortcuts import render_to_response
from django.template import RequestContext

from subdomains.forms import SubdomainForm

def subdomainform(request):

	form = SubdomainForm()
	return render_to_response('sub/subdomainform.html', {'form':form}, \
		context_instance=RequestContext(request))

def index(request):

    context = {'results': 'Hello unathenticated World'}
    return render(request, 'index.html', context)

def login(request):

    if request.method == 'POST':

        form = LoginForm(request.POST)

        if form.is_valid():

            context = {'results':'Hello World from Sub app'}
            return render(request, 'base.html', context)

        else:
            context = {'form': form, 'results': 'Info is not valid. Please input again...'}
            return render(request, 'login.html', context)
    else:

        form = LoginForm(request.POST)
        context = {'form': form, 'results': 'Please enter a password!'}
        return render(request, 'login.html', context)

#the decorator
def myuser_login_required(f):
        def wrap(request, *args, **kwargs):
                #this check the session if userid key exist, if not it will redirect to login page
                if 'userid' not in request.session.keys():

                    return HttpResponseRedirect("/login")

                return f(request, *args, **kwargs)
        wrap.__doc__=f.__doc__
        wrap.__name__=f.__name__
        return wrap

# @myuser_login_required
@login_required(login_url='/login/')
def base(request):
    context = {'results': 'Hello World from Sub app'}
    return render(request, 'base.html')

