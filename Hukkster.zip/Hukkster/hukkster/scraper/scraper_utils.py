import re
import logging
import cgi
import urllib
from urlparse import urlparse
from urlparse import urlunparse
from urlparse import urljoin
import lxml.html
from bs4 import UnicodeDammit


class ParseFailedError(Exception):
    pass


class ScraperUtility:
    '''
    This mixin class contains utility functions to parse and extract html 
    which use lxml and regular expressions.
    '''
    def __init__(self, scraper, parse_open_graph_info=False):
        self.scraper = scraper

        if parse_open_graph_info:
            self.og_data = self.scraper.parse_opengraph()

        # Parsing the HTML
        logging.debug('Parsing HTML data')
        encoding = self._detect_encoding(self.scraper.html)
        self.root = lxml.html.fromstring(unicode(self.scraper.html, encoding))
        logging.debug('Finished parsing HTML data')

    def _detect_encoding(self, html_content):
        ud = UnicodeDammit(html_content, is_html=True)
        return ud.original_encoding

    @staticmethod
    def clean_string(val):
        try:
            return val.replace('\\', '').replace(u'\xa0', ' ').strip()
        except AttributeError:
            return val

    def _extract_float(self, xpath_expr, text_pattern, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(xpath_expr, is_expected_to_be_found)
        if node is not None:
            float_text = self.clean_string(node.text_content())
            m = re.search(text_pattern, float_text.encode("utf8"))
            if m:
                float_text = m.group(1).replace(",", "")
                float_value = float(float_text)
                return float_value
            else:
                if is_expected_to_be_found:
                    logging.debug("Error: Found no float value using %r" % xpath_expr)
                    raise ParseFailedError()
                else:
                    return 0
        else:
            return 0

    def _expect_and_extract_single_node(self, xpath_expr, is_expected_to_be_found=True):
        nodes = self.root.xpath(xpath_expr)
        if len(nodes) == 0:
            if is_expected_to_be_found:
                logging.debug("Error: Unabled to find a node with xpath expression: %r" % xpath_expr)
                raise ParseFailedError()
            else:
                return None
        else:
            if len(nodes) > 1:
                logging.debug("Error: Found more than one node using %r" % xpath_expr)
            return nodes[0]

    def _expect_and_extract_single_node_text_content(self, xpath_expr, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(xpath_expr, 
                        is_expected_to_be_found=is_expected_to_be_found)
        # NOTE: _expect_and_extract_single_node has already handled the unexpected node not found case.
        if node is not None:
            return node.text_content()
        else:
            return ""

    def _extract_attr_value(self, xpath_expr):
        return self._expect_and_extract_single_node(xpath_expr)

    def _extract_value_dict_using_regex(self, pattern, text, failure_msg=""):
        all_value_dicts = self._extract_all_value_dicts_using_regex(pattern, text, expect_at_least_one=False)
        if len(all_value_dicts) > 0:
            return all_value_dicts[0]
        else:
            logging.debug("Error: Failed to extract value using pattern '%s'. %s" % (pattern, failure_msg))
            raise ParseFailedError()

    def _extract_all_value_dicts_using_regex(self, pattern, text, expect_at_least_one=True, failure_msg=""):
        all_value_dicts = []
        for m in re.finditer(pattern, text):
            all_value_dicts.append(m.groupdict())
        if (not expect_at_least_one) or len(all_value_dicts) > 0:
            return all_value_dicts
        else:
            logging.debug("Error: No result found using pattern '%s'. %s" % (pattern, failure_msg))
            raise ParseFailedError()

    def _extract_value_using_regex(self, pattern, text, failure_msg=""):
        m = re.search(pattern ,text)
        if m:
            return m.group(1)
        else:
            logging.debug("Error: Failed to extract value using pattern '%s'. %s" % (pattern, failure_msg))
            raise ParseFailedError()


def _update_url_parameters(url, params_to_update):
    parse_result = urlparse(url)
    parsed_qs = cgi.parse_qs(parse_result.query)
    for param_key, param_val in params_to_update.items():
        parsed_qs[param_key] = [param_val]
    new_qs = dict([(key, val[0]) for key, val in parsed_qs.items()])
    url_parts_list = list(parse_result)
    new_query = urllib.urlencode(new_qs)
    url_parts_list[4] = new_query
    return urlunparse(url_parts_list)
