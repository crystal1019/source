angular.module('topic.services', [])
    .factory('TopicService', [

        function() {
            var store = {};
            var topic = data.topic;
            return {
                store: {},
                can_post: false,
                can_moderate: false,
                init: function() {
                    var self = this;
                    switch (default_tab_data.tab) {
                        case 'discussions':
                            self.discussions = default_tab_data.data;
                        case 'resources':
                            self.resources = default_tab_data.data;
                        case 'events':
                            self.events = default_tab_data.data;
                        case 'noticeboard':
                            self.noticeboard = default_tab_data.data;
                    }
                    this.can_post = data.can_post;
                    this.can_moderate = data.can_moderate;
                },
                getInitialData: function(tab) {
                    var self = this;
                    if (angular.isDefined(store[tab])) {
                        return self.store[tab];
                    }
                    return null;
                }
            };
        }
    ]);