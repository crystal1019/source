var $isoContainer = $('#topic_boxes, .topic_boxes');

function addButtonAnchors() {
    var buttonElements = $('.button, .hdr_usr_button, .edit_place, .side_link');
    buttonElements.each(function() {
        if ($(this).hasClass('normal') === false && $(this).find('span').length === 0) {
            $(this).wrapInner('<span></span>');
        }
    });
}

$(function() {

    /*******************************************************************
  * start image slider
  +******************************************************************/
    $('.flexslider').flexslider({
        controlNav: false,
        randomize: false
    });


    /*******************************************************************
  * prettyPhoto functionality
  +******************************************************************/
    $("a[rel^='prettyPhoto']").prettyPhoto({
        social_tools: false
    });


    /*******************************************************************
  * enable expandable comment functionality
  +******************************************************************/
    $.expander.defaults.expandText = '[Read More]';
    $.expander.defaults.userCollapseText = '[Less]';
    $.expander.defaults.moreClass = 'read_more';
    $.expander.defaults.lessClass = 'read_less';
    $.expander.defaults.preserveWords = 'false';
    $.expander.defaults.expandEffect = 'fadeIn';
    $.expander.defaults.collapseEffect = 'fadeOut';
    $.expander.defaults.expandSpeed = 500;
    $.expander.defaults.collapseSpeed = 500;
    $.expander.defaults.expandPrefix = '...';
    $.expander.defaults.detailClass = 'post-details';

    // $('div.forumpost-content:not(:has(img))').expander({ slicePoint: 220 });
    // $('div.forumpost-content:not(:has(img))')
    //   .expander({ slicePoint: 220 })
    //   .find('.post-details').hide();

    /**************************************************************
     * add span to anchor buttons for added styling
     **************************************************************/
    addButtonAnchors();


    /**************************************************************
     * attach PIE js for added IE compatibility
     **************************************************************/
    if (window.PIE) {
        $('.hdr_cta_button, .hdr_usr_button, .button, .shadow, .feature_logo img, .place_box span, #user_dd_list').each(function() {
            PIE.attach(this);
        });
    }


    /**************************************************************
     * toggle discussion posts/comments/replies functionality
     **************************************************************/
    // $(document).on('click', '.toggle_post_comment', function() {
    //     $(this).closest('.discussion_container').find('.discussion_post_comment').show().slideDown('fast');
    //     $(this).closest('.discussion_container').find('.discussion_comments').slideUp('fast');
    //     return false;
    // });
    // $(document).on('click', '.toggle_read_comment', function() {
    //     $(this).closest('.discussion_container').find('.discussion_comments').show().slideDown('fast');
    //     $(this).closest('.discussion_container').find('.discussion_post_comment').slideUp('fast');
    //     return false;


        // $(this).parents('.discussion_container').find('.discussion_post_comment').slideUp('fast');
        // var disc_com = $(this).parents('.discussion_container').find('.discussion_comments');
        // if (disc_com.css('display') == 'none') { // Toggle discussion comments
        //   disc_com.slideDown('fast');
        // }
        // else{
        //   disc_com.slideUp('fast');
        // }
        // return false;
    // });

    // $(document).on("click", ".toggle_post_reply", function() {
    //     $(this).parents('.comment_wrapper').find('.discussion_post_reply').slideDown('fast');
    //     $(this).parents('.comment_wrapper').find('.discussion_replies').slideUp('fast');
    //     return false;
    // });

    // $(document).on("click", ".toggle_read_reply", function() {
    //     $(this).parents('.comment_wrapper').find('.discussion_post_reply').slideUp('fast');
    //     var disc_reply = $(this).parents('.comment_wrapper').find('.discussion_replies');
    //     if (disc_reply.css('display') == 'none') { // Toggle discussion replies
    //         disc_reply.slideDown('fast');
    //     } else {
    //         disc_reply.slideUp('fast');
    //     }
    //     return false;
    // });

    /*$(".toggle_post_reply").click(function() {
    $(this).parents('.comment_wrapper').find('.discussion_post_reply').slideDown('fast');
    $(this).parents('.comment_wrapper').find('.discussion_replies').slideUp('fast');
    return false;
  });
  $(".toggle_read_reply").click(function() {
    $(this).parents('.comment_wrapper').find('.discussion_post_reply').slideUp('fast');
    var disc_reply = $(this).parents('.comment_wrapper').find('.discussion_replies');
    if (disc_reply.css('display') == 'none') { // Toggle discussion replies
      disc_reply.slideDown('fast');
    }
    else{
      disc_reply.slideUp('fast');
    }
    return false;
  });*/


    /**************************************************************
     * tab switching for profile pages and edittopic page
     **************************************************************/
    $('.placespeak_tabs li a').click(function() {
        if ($(this).parent().hasClass('active') === false) {
            var tabName = $(this).attr('rel');
            ga_tracker('tabs', tabName);
            $('.placespeak_tabs').find('li').removeClass('active');
            $('.tabpane.active').slideUp('fast', function() {
                $(this).removeClass('active');
            });

            $(this).parent().addClass('active');
            $('#' + tabName).slideDown('fast', function() {
                $(this).addClass('active');
                // $isoContainer.isotope('reloadItems');
            });
        }
        // return false;
    });



    /**************************************************************
     * user dropdown functionality
     **************************************************************/
    // $('.user_dropdown').mouseenter(function() {
    //     $('#user_dd_list')
    //         .stop(true, true)
    //         .slideDown('fast');
    //     ga_tracker('header menu', 'main menu mouseenter');
    // });
    // $('.user_dropdown').mouseleave(function() {
    //     $('#user_dd_list')
    //         .stop(true, true)
    //         .delay(500)
    //         .slideUp('fast');
    // });

    // $('.organization_dropdown').mouseenter(function() {
    //     $('#my-org').addClass("white-arrow");
    //     $('#user_organization_list')
    //         .stop(true, true)
    //         .delay(400)
    //         .slideDown('fast', function() {
    //             ga_tracker('header menu', 'organization_dropdown mouseenter');
    //         });
    // });
    // $('.organization_dropdown').mouseleave(function() {
    //     $('#my-org').removeClass("white-arrow");
    //     $('#user_organization_list')
    //         .stop(true, true)
    //         .delay(500)
    //         .slideUp('fast');
    // });

    // $('.notifications_dropdown').mouseenter(function() {
    //     console.log("mouseenter")
    //     $('#my-noti').addClass("white-arrow");
    //     $('#user_notifications_list')
    //         .stop(true, true)
    //         .delay(400)
    //         .slideDown('fast', function() {
    //             ga_tracker('header menu', 'notifications_dropdown mouseenter');
    //         });
    // });
    // $('.notifications_dropdown').mouseleave(function() {
    //     console.log("mouseleave")
    //     $('#my-noti').removeClass("white-arrow");
    //     $('#user_notifications_list')
    //         .stop(true, true)
    //         .delay(500)
    //         .slideUp('fast');
    // });
    /**************************************************************
     * profile and verification section toggling
     **************************************************************/
    $('.hidden_element').hide();

    $('.toggle_div').click(function() {
        var toggleDiv = $(this).attr('rel');
        $('#' + toggleDiv).slideToggle('fast');
        return false;
    });


    /**************************************************************
     * full brief toggling
     **************************************************************/
    $('.full_brief').hide();
    $('.toggle_brief').click(function() {
        $('.full_brief').slideToggle('fast');
        $(this).toggleClass('active');
        if ($(this).hasClass('active')) {
            $(this).html("Hide full brief");
        } else {
            $(this).html("Read full brief");
        }
        return false;
    });

    /**************************************************************
     * tooltips
     **************************************************************/
    $('.js_tooltip').tooltip();


    /*******************************************************************
  * Settings - toggle list
  +******************************************************************/

    $(document).on('click', '.toggle-list .header', function() {
        $('.toggle-list .header')
            .removeClass('active')
            .not(this)
            .siblings('.content')
            .slideUp('fast');

        $(this)
            .addClass('active')
            .siblings('.content')
            .slideDown('fast');

    });

    /*******************************************************************
  * EditTopic - toggle list
  +******************************************************************/

    $(document).on('click', '.toggle-list-edit-topic .header', function() {
        $('.toggle-list-edit-topic .header')
            .removeClass('active')
            .not(this)
            .siblings('.content')
            .slideUp('fast');

        $(this)
            .addClass('active')
            .siblings('.content')
            .slideDown('fast');

    });

    /**************************************************************
     * custom isotope layout mode, run isotope
     **************************************************************/
    $.Isotope.prototype._getMasonryGutterColumns = function() {
        var gutter = this.options.masonry && this.options.masonry.gutterWidth || 0;
        containerWidth = this.element.width();

        this.masonry.columnWidth = this.options.masonry &&
            this.options.masonry.columnWidth ||
        // or use the size of the first item
        this.$filteredAtoms.outerWidth(true) ||
        // if there's no items, use size of container
        containerWidth;
        this.masonry.columnWidth += gutter;
        this.masonry.cols = Math.floor((containerWidth + gutter) / this.masonry.columnWidth);
        this.masonry.cols = Math.max(this.masonry.cols, 1);
    };

    $.Isotope.prototype._masonryReset = function() {
        // layout-specific props
        this.masonry = {};
        // FIXME shouldn't have to call this again
        this._getMasonryGutterColumns();
        var i = this.masonry.cols;
        this.masonry.colYs = [];
        while (i--) {
            this.masonry.colYs.push(0);
        }
    };

    $.Isotope.prototype._masonryResizeChanged = function() {
        var prevSegments = this.masonry.cols;
        // update cols/rows
        this._getMasonryGutterColumns();
        // return if updated cols/rows is not equal to previous
        return (this.masonry.cols !== prevSegments);
    };

    if ($isoContainer.length) {
        $isoContainer.imagesLoaded(function() {
            $isoContainer.isotope({
                itemSelector: '.topic_box',
                resizable: false,
                containerStyle: {
                    position: 'relative',
                    overflow: 'visible',
                    margin: '0px 0px 30px'
                },
                masonry: {
                    columnWidth: 220,
                    gutterWidth: 19
                }
            }, function() {
                $('.tabpane').not(".v2 .tabpane").hide();
                $('.tabpane.active').not(".v2 .tabpane").show();
            });
        });
    } else {
       $('.tabpane').not(".v2 .tabpane").hide();
       $('.tabpane.active').not(".v2 .tabpane").show();
    }

    //Not editor select because this + Angular directive breaks them
    $('select').not("#editor select").uniform();


    $('#ftr_topics_search').keypress(function(e) {
        if (e.which == 13) {
            window.location.href = '/explore/?q=' + $(this).val();
        }
    });

    //Cookie alert
    $.ajax({
        type: "GET",
        url: "/cookiecheck/",
        success: function(data) {
            if (data.data.show_cookie_alert) {
                $("#cookie-msg").slideDown();
            }
        }
    });

    $("#accept-cookie").click(function() {

        $("#cookie-msg").slideUp();

        $.ajax({
            type: "POST",
            url: "/cookiecheck/",
            data: {
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
            },
            success: function() {}
        });
        return false;
    });

    //Maintenance banner
    //  $.ajax({
    //   type:"GET",
    //   url:"/maincheck/",
    //   success: function(data){
    //     if(data.data.show_banner){
    //       $("#main-msg").slideDown();
    //     }
    //   }
    // });

    // $("#accept-banner").click(function(){

    //   $("#main-msg").slideUp();

    //   $.ajax({
    //     type:"POST",
    //     url:"/maincheck/",
    //     data: {
    //       'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
    //     },
    //     success: function(){
    //     }
    //   })
    //   return false;
    // });

    angular.bootstrap(document.getElementById("ProfileMenuApp"), ["ProfileMenuApp"]);
});


// $('a.submit').click(function() {
//   $(this).closest("form").submit();
//   return false;
// });


/**
 * Show form errors.
 * @param  {object} obj JSON object returned from ajax call.
 */
function show_errors(element, obj) {
    // Dump error messages out to alert box.
    var err_msg = '';
    for (var i = 0, cnt = obj.message.length; i < cnt; i++) {
        err_msg += '<p>' + obj.message[i] + '</p>';
    }
    $(element).html(err_msg).show();
    return;
}