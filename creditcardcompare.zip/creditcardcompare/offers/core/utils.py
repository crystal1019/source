import re
from datetime import datetime, date
from django.conf import settings
from django.http import Http404
from offers.helpers.template import site_format_date
from offers.helpers.template.models import UserAgent
from offers.helpers.boyd import add_months


NON_DIGIT_RE = re.compile(r'[^\d.]+')
NON_DIGIT_RE_END = re.compile(r'[^\d]+$')


def timestamp(source):
    try:
        return source % {'timestamp': str(datetime.now()).split(' ')[1]}
    except KeyError:
        return source

def months_of_year(month_range=12):
    today = date.today()
    values = []
    for x in range(month_range):
        d = add_months(today, -x)
        values.append(d)
    return values
    
def metafield_value(offer, meta_key, with_prefix_suffix=True, show_expiry=False):
    meta = offer.meta_instances.filter(meta_field__key=meta_key)
    try:
        value = meta[0].value_or_default if with_prefix_suffix else meta[0].bare_value_or_default
    except IndexError:
        return ''
    if show_expiry:
        end_date = site_format_date(meta[0].expiry, settings.SITE_NAME)
    else:
        end_date = ''
    return (value + end_date) if ('-' not in value and 'income' not in value) else ''
        
def offer_object(offer_id):
    from models import Offer
    return Offer.objects.get(id=offer_id)

def active_offers():
    from models import Offer
    return Offer.on_site.filter(is_active=True).order_by('title')
    
def intro_rate_expiration(*args):
    today = date.today()
    meta = args[0].meta_instances.filter(meta_field__key='Intro Purchase Period')
    try:
        month = today.month + int(meta[0].value)
    except (IndexError,ValueError):
        return '-'
    year = today.year + (month/12 if month%12 else month/12-1)
    return date(year, month%12 or 12, 1)
    
def _get_traffic_source(request):
    ga_cookie = request.COOKIES.get('__utmz','not found')
    keyword = ga_cookie[ga_cookie.find('utmctr='):][7:]
    if 'clid=' in ga_cookie:
        source = 'google paid&keyword=%s'%keyword
    elif '=(organic)' in ga_cookie:
        engine = ga_cookie[ga_cookie.find('utmcsr='):]
        engine = engine[7:engine.find('|')]
        source = '%s organic&keyword=%s'%(engine,keyword)
    elif 'direct' in ga_cookie:
        source = 'direct'
    elif 'referral' in ga_cookie:
        engine = ga_cookie[ga_cookie.find('utmcsr='):]
        source = engine[7:engine.find('|')]
    elif '=edm' in ga_cookie:
        source = 'email'
    else:
        source = 'unknown'
    try:
        agent = UserAgent.objects.get(agent=request.META['HTTP_USER_AGENT'])
    except UserAgent.DoesNotExist:
        pass
    except KeyError:
        raise Http404
    else:
        source += '&agent=%s' % agent.__unicode__()
    return source

def find_sortable_meta_field(category, key):
    for meta in category.sortable_meta_fields.order_by('key'):
        if key == meta.key:
            return meta
    return None

def compare_meta_fields(a, b):
    a_val = NON_DIGIT_RE_END.sub('', NON_DIGIT_RE.sub('', a.value))
    b_val = NON_DIGIT_RE_END.sub('', NON_DIGIT_RE.sub('', b.value))

    try:
        return int(float(a_val) - float(b_val))
    except ValueError:
        return 0

def ping_all_search_engines(sitemap_url=None):
    """
    Pings the popular search engines, Google, Yahoo, ASK, and
    Windows Live, to let them know that you have updated your
    site's content. Returns successfully pinged servers.
    Example:
        >>> pinged = ping_all_search_engines()
        >>> pinged.len() >= 1
        True
    """
    from django.contrib.sitemaps import ping_google
    SEARCH_ENGINE_PING_URLS = (
        ('google', 'http://www.google.com/webmasters/tools/ping'),
        ('yahoo', 'http://search.yahooapis.com/SiteExplorerService/V1/ping'),
        ('ask', 'http://submissions.ask.com/ping'),
        ('live', 'http://webmaster.live.com/ping.aspx'),
    )
    successfully_pinged = []
    for (site, url) in SEARCH_ENGINE_PING_URLS:
        try:
            ping_google(sitemap_url=sitemap_url, ping_url=url)
            successfully_pinged.append(site)
        except:
            pass
    return successfully_pinged

def normalize_query(query_string, findterms=re.compile(r'"([^"]+)"|(\S+)').findall, normspace=re.compile(r'\s{2,}').sub):
    """
    Splits the query string in invidual keywords, getting rid of unecessary spaces
    and grouping quoted words together.
    Example:
        >>> normalize_query('  some+random  words "with   quotes  " and   spaces')
        ['some', 'random', 'words', 'with quotes', 'and', 'spaces']
    """
    return [normspace(' ', (t[0] or t[1]).strip()) for t in findterms(query_string)]

def get_search_query(query_string, search_fields):
    """
    Returns a query, that is a combination of Q objects. That combination
    aims to search keywords within a model by testing the given search fields.
    """
    from django.db.models import Q
    query = None
    terms = normalize_query(query_string)
    for term in terms:
        or_query = None
        for field_name in search_fields:
            q = Q(**{"%s__icontains" % field_name: term})
            if or_query is None:
                or_query = q
            else:
                or_query = or_query | q
        if query is None:
            query = or_query
        else:
            query = query & or_query
    return query

def markup(text):
    """
    Converts new-lines into hard breaks and cleans html.
    """
    from django.utils.html import linebreaks, clean_html, strip_spaces_between_tags
    return clean_html(linebreaks(strip_spaces_between_tags(text)))