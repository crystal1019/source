import os
import django.test
from django.db import connection


def setUpClass():
    print('Running scripts...')
    sql = open(os.path.join(os.path.dirname(__file__), 'sql', 'fullTable.sql'), 'r').read()
    d = connection.settings_dict
    import mysql.connector
    conn = mysql.connector.connect(host=d['HOST'], user=d['USER'], passwd=d['PASSWORD'], db=d['NAME'])
    c = conn.cursor()
    for r in c.execute(sql, multi=True):
        pass
    sql = open(os.path.join(os.path.dirname(__file__), 'sql', 'fakes.sql'), 'r').read()
    for r in c.execute(sql, multi=True):
        pass
    conn.commit()
    print('Database created')


class TestCase(django.test.TestCase):
    SCRIPT_INSTALLED = False

    def setUpClass():
        if not TestCase.SCRIPT_INSTALLED:
            TestCase.SCRIPT_INSTALLED = True
            setUpClass()
