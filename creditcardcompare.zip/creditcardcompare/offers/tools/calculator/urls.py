from django.conf.urls import *
from django.views.generic import TemplateView

urlpatterns = patterns('offers.tools.calculator.views',
    url(r'^balance-transfer/$', 'balance_transfer', name='balance-transfer-calculator'),
    url(r'^car-loan/$', 'car_loan', name='car-loan-calculator'),
    url(r'^credit-card-debt/$', TemplateView.as_view(template_name='calculator/credit_card_debt.html'), name='debt-calculator'),
    url(r'^minimum-repayment/$', 'minimum_repayment', name='minimum-repayment-calculator'),
    url(r'^savings-goal/$', 'savings_goal', name='savings-goal-calculator'),
)