from django.conf import settings
from django.http import Http404
from django.shortcuts import render_to_response
from django.template import RequestContext
from offers.helpers.boyd.decorators import cache_page


@cache_page
def show_lightbox(request):
    if not request.is_ajax():
        raise Http404
    try:
        template = request.GET['template']
    except KeyError:
        raise Http404
    templates = [
        '%s/lightbox/%s.html' % (settings.SITE_NAME, template),
        'lightbox/%s.html' % template,
    ]
    return render_to_response(templates, {}, RequestContext(request))