#!/bin/sh

FILE=$1

convert  $FILE -define histogram:unique-colors=true -format %c histogram:info:- | sort -r| grep -v '255,255,255' | head -1 |sed -e 's/.*#//' | awk '{ print $1 }'
