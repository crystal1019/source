from django.core.management.base import BaseCommand
from django.contrib.sites.models import Site
from offers.core.models import Offer, PerSiteOfferOption


class Command(BaseCommand):
    def handle(self, *args, **options):
        BC = Site.objects.get(domain='broadbandcompare.com.au')
        offers = Offer.objects.filter(sites=BC)
        for offer in offers:
            try:
                option, _newly_created = PerSiteOfferOption.objects.get_or_create(offer=offer, site=BC)
            except PerSiteOfferOption.MultipleObjectsReturned:
                option = PerSiteOfferOption.objects.filter(offer=offer, site=BC)[0]
                options = PerSiteOfferOption.objects.filter(offer=offer, site=BC)[1:]
                for o in options:
                    o.delete()
            option.noindex = True
            option.save()
            print option.offer.title
            