import time
from django.core.management.base import BaseCommand
from offers.helpers.boyd import GenericThread
from offers.core.models import Offer


class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        try:
            prop = args[0]
        except IndexError:
            prop = 'image'
        
        offers = Offer.objects.all()
        offer_count = offers.count()
        print 'Starting to scan offer.%s of %s offers' % (prop, offer_count)
        self.counter = 0
        self.sizes = {}
        x = offer_count/6
        GenericThread(self.scan_offers, offers[:x], prop).start()
        GenericThread(self.scan_offers, offers[x:x*2], prop).start()
        GenericThread(self.scan_offers, offers[x*2:x*3], prop).start()
        GenericThread(self.scan_offers, offers[x*3:x*4], prop).start()
        GenericThread(self.scan_offers, offers[x*4:x*5], prop).start()
        GenericThread(self.scan_offers, offers[x*5:], prop).start()
        
        while self.counter != offer_count:
            time.sleep(1)
            
        print
        for k, v in self.sizes.iteritems():
            print '%s: %s' % (k, v)
            
    def scan_offers(self, offers, prop):
        for offer in offers:
            try:
                new = getattr(offer, prop).width, getattr(offer, prop).height
            except (IOError, ValueError):
                self.counter += 1
                continue
            self.sizes[new] = self.sizes.get(new, []) + [int(offer.id)]
            self.counter += 1
            print self.counter,
