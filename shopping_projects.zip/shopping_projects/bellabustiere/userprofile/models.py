'''
@author: chaol
'''

from django.db import models
from django.contrib.auth.models import User
from bellabustiere.website.models import Subscription, SubscriptionGroup


def subscription_create(email, wholesale,member,ip=None, first_name=None, last_name=None):
    if wholesale:
        s, created = Subscription.objects.get_or_create(email=email, defaults={"is_wholesale": True,'ip':ip,"group": SubscriptionGroup.objects.get(name__iexact='wholesale'), "first_name":first_name, 'last_name':last_name})
        
    elif member:
        s, created = Subscription.objects.get_or_create(email=email, defaults={"is_wholesale": False,'ip':ip,"group": SubscriptionGroup.objects.get(name__iexact='member'), "first_name":first_name, 'last_name':last_name}) if ip else Subscription.objects.get_or_create(email=email, defaults={"is_wholesale": False,"group": SubscriptionGroup.objects.get(name__iexact='member'), "first_name":first_name, 'last_name':last_name})
    else:
        s, created = Subscription.objects.get_or_create(email=email, defaults={"is_wholesale": False,'ip':ip,"group": SubscriptionGroup.objects.get(name__iexact='retail'), "first_name":first_name, 'last_name':last_name})
    return s,created


class Country(models.Model):
    country = models.CharField(max_length=255, unique=True)
    shipto = models.BooleanField("Do we ship to this country?")
    def __unicode__(self):
        return self.country
    class Meta:
        verbose_name_plural = "Countries"
class State(models.Model):
    name = models.CharField(max_length=255)
    country = models.ForeignKey(Country)
    def __unicode__(self):
        return self.name
    
class PaymentTerm(models.Model):
    term = models.CharField(max_length=255, unique=True)
    deposite = models.FloatField(default=0.1,editable=False)
    is_default = models.BooleanField(default=False)
    
    def __unicode__(self):
        return self.term

class Profile(models.Model):
    user = models.ForeignKey(User, unique=True)
    phone = models.CharField(max_length=60, blank=True, null=True)
    phone2 = models.CharField(max_length=60, blank=True, null=True)
    fax = models.CharField(max_length=60, blank=True, null=True)
    company = models.CharField(max_length=60, blank=True, null=True)
    tradingas = models.CharField(max_length=60, blank=True, null=True)
    abn = models.CharField(max_length=60, blank=True, null=True)
    subscribe = models.BooleanField(default=False)
    wholesale = models.BooleanField(default=False, editable=False)
    member = models.BooleanField("Retail Member",default=False)
    payment_term = models.ForeignKey(PaymentTerm,blank=True,null=True, editable=False)
    
    def has_shipping_detail(self):
        return True if self.shipping_set.all() else False
    has_shipping_detail.boolean = True
    
    def has_billing_detail(self):
        return True if self.billing_set.all() else False
    has_billing_detail.boolean = True
    
    def isStaff(self):
        if self.user.is_staff:
            return True;
        return False
    
    def save(self, **kwargs):
        super(Profile, self).save()
        try:
            ip = kwargs['ip']
        except:
            ip = None
        if self.subscribe:
            s,created = subscription_create(self.user.email, self.wholesale, self.member, ip=ip, first_name=self.user.first_name, last_name=self.user.last_name)
        else:
            try:
                s = Subscription.objects.get(email=self.user.email)
                s.delete()
            except:
                pass
    def __unicode__(self):
        return self.user.username
    class Meta:
        permissions = (
            ("is_wholesaler", "Is a wholesaler"),
        )


class Billing(models.Model):
    profile = models.ForeignKey(Profile, null=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    company = models.CharField(max_length=255, blank=True, null=True)
    address = models.CharField(max_length=255)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    address3 = models.CharField(max_length=255, blank=True, null=True)
    suburb = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=60)
    postcode = models.CharField(max_length=60)
    country = models.ForeignKey(Country, null=True)
    phone = models.CharField(max_length=60, null=True)
    email = models.CharField(max_length=60, null=True)
    def __unicode__(self):
        try:
            return "Billing info for "+self.profile.user.username
        except:
            return "Orphaned Billing Data"
    class Meta:
        verbose_name = "Billing Detail"
class Shipping(models.Model):
    profile = models.ForeignKey(Profile, null=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    company = models.CharField(max_length=255, blank=True, null=True)
    address = models.CharField(max_length=255)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    address3 = models.CharField(max_length=255, blank=True, null=True)
    suburb = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=60)
    postcode = models.CharField(max_length=60)
    country = models.ForeignKey(Country,null=True)
    phone = models.CharField(max_length=60, null=True)
    def __unicode__(self):
        try:
            return "Shipping info for "+self.profile.user.username
        except:
            return "Orphaned Shipping Data"
    class Meta:
        verbose_name = "Shipping Detail"


class UserType(models.Model):
    type = models.CharField(max_length=60)
    def __unicode__(self):
        return self.type
class UserLog(models.Model):
    user = models.ForeignKey(User)
    details = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    def __unicode__(self):
        return self.user.username+" "+self.details[:50]+"..."
    def trimDetails(self):
        return self.details[:130]+"..."