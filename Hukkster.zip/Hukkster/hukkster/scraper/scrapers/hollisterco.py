import logging
import re
from base import BaseScraper
import leaf
from time import sleep
from ..exceptions import HukksterTooManyOptions



logger = logging.getLogger('scraper')

# bonobos
class HollistercoScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'hollisterco.com'

    #def fetch_url(self):
    #    with open('test_data/hollisterco/jeans.html', 'r') as f:
    #       self.html = f.read()

    def raise_not_item(self):
        raise HukksterTooManyOptions(self.get_domain(), self.url)

    def make_float(self, value):
        return float(re.sub(r'[^\d\.]', '', value.strip()))

    def make_absolute_link(self, href):
        return ''.join(['http://www.', self.get_domain(), href])

    def parse_single_item(self):
        # we don't use open graph, it's reduce code size
        # for multi-product items
        #og_data = self.parse_opengraph()

        # Getting missing parts
        item = dict()
        doc = leaf.parse(self.html)

        # Product Store Code
        item['store'] = 'hollisterco'

        # Item URL
        item['url'] = self.url

        # Product Title
        title = doc.get('div.product-title h2.name')
        if title:
            item['title'] = title.text
        else:
            # this is not an item
            self.raise_not_item()

        # get information from checkout hidden fields
        fields = dict([(field.element.attrib['name'],
                        field.element.attrib['value']) for field in doc(
                                            'form.add-to-bag div.data input')])
        # this is not an item
        if not fields:
            self.raise_not_item()

        # Product Unique ID (local_id in the json)
        if 'productId' in fields:
            item['local_id'] = fields['productId']

        #Product Current Price
        if 'price' in fields:
            item['current_price'] = {'value':
                                     self.make_float(fields['price'])}

        #Product "Original Price"
        original_price = doc.get('h4.list-price del').text

        if original_price:
            item['original_price'] = {'value':
                                      self.make_float(original_price)}

        # main image
        item_image = doc.get('img.prod-img')
        if item_image:
            item_image = 'http:' + item_image.element.attrib['src']
            item['image'] = re.sub('\$holProductImage500\$',
                                   '$holProductImageMagnify$',
                                   item_image)

        # Does Product Have a Promo
        promo = doc.get('div#shortPromo')
        if promo:
            item['promos'] = [{'text': promo.text.strip()}]

        # product color is fixed by item
        # product sizes
        items = list()
        sizes = doc('li.size.select')[0]('option')

        if sizes:
            for size in sizes:
                if 'Select Size' in size.text.strip():
                    continue
                if 'Will Ship' in size.text.strip():
                    continue
                newitem = item.copy()
                # clean parfum wrong color selector
                if 'FL OZ' in fields['color']:
                    newitem['selections'] = {'size': size.text.strip(),}
                else:
                    newitem['selections'] = {'size': size.text.strip(),
                                             'color': fields['color']}
                items.append(newitem)

        return items

    def parse_multi_item(self):
        items = list()
        doc = leaf.parse(self.html)
        for part in doc('div.product'): # product-form
            item = dict()
            dp = leaf.parse(part.html())

            # get title from html part
            title = dp.get('h2.name')
            if title:
                item['title'] = title.text

            self.html = part.html()

            # get url from html part
            url = part.get('div.full-product-details a')
            if url:
                url = self.make_absolute_link(
                                    url.element.attrib['href'])
                links = part('li.swatch a.swatch-link')
                if not links:
                    #item['links'] = 'False'
                    self.url = url
                    self.html = part.html()
                    items += self.parse_single_item()
                    continue
                else:
                    #item['links'] = 'True'
                    for item in links:
                        item_url = self.make_absolute_link(
                                               item.element.attrib['href'])
                        # retriving item (each color option, has other url)
                        self.url = item_url
                        self.fetch_url()
                        items += self.parse_single_item()
                        sleep(1)
                    # skip saving common case items
                    continue
            items.append(item)
        return items

    def parse(self):
        # get main items
        items = list()

        # get other items if exists (by color selectors)
        # it's loaded by ajax requests
        doc = leaf.parse(self.html)

        # detect multi-product page
        if len(doc('div.product-form')) > 1:
            return self.parse_multi_item()

        # single-item page
        links = doc('li.swatch a.swatch-link')
        if not links:
            items = self.parse_single_item()
        else:
            for item in links:
                item_url = self.make_absolute_link(
                                       item.element.attrib['href'])
                # retriving other item (each color option, has other url)
                self.url = item_url
                self.fetch_url()
                items += self.parse_single_item()
                sleep(1)

        return items






