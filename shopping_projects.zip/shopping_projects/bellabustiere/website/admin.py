'''
@author: chaol
'''

from django.contrib import admin
from django.contrib.contenttypes import generic
from django.http import HttpResponseRedirect
from models import *
from django.contrib.sites.models import Site
from django.contrib.sites.admin import SiteAdmin


class MiscPageAdmin(admin.ModelAdmin):
    list_display = ('title', 'status', 'created','in_site')
    list_filter = ('created', 'modified', 'status','sites')
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]
class StringsAdmin(admin.ModelAdmin):
    list_display = ('identifier', 'text',)
    search_fields = ('identifier', 'text')
    
class FlashImageAdmin(admin.ModelAdmin):
    list_display = ('__unicode__','in_site')
    list_filter = ('sites',)

class EmailStatusInline(admin.TabularInline):
    model = EmailStatus    

class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('email','first_name','company','subscribed','group','ip','email_not_read')
    list_filter = ('subscribed','group','sites')
    list_editable = ('group',)
    search_fields = ('email',)
   # inlines = [EmailStatusInline,]
    actions = ['send_mail']
    list_per_page = 2147483647
    def send_mail(self,request,queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        return HttpResponseRedirect('sendmail/?ids=%s' % ",".join(selected))
        

class PromoTileAdmin(admin.ModelAdmin):
    list_display = ('name', 'priority', 'active')
    list_editable = ('priority', 'active')
    
class MediaUploadAdmin(admin.ModelAdmin):
    list_display = ('name', 'publishdate')
    
class EmailAdmin(admin.ModelAdmin):
    list_display=('title','created','fromaddress','send_already','read_percentage','not_read_percentage')
    list_filter=('created','fromaddress')

    actions = ['duplicate_email']
    
    def duplicate_email(self,request,queryset):
        content = ''
        titles = []
        for x in queryset:
            titles.append(x.title)
            content += x.content
        e = Email()
        num = 0
        title = 'please_change_me'
        while title in titles:
            num += 1
            titlelist = title.split('_')[:3]
            titlelist.append(str(num))
            title = '_'.join(titlelist)
            
            
        e.title = title
        e.content = content
        e.save()
        return HttpResponseRedirect('/admin/website/email/')
        
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup_email.js',]
    
class SubscriptionGroupAdmin(admin.ModelAdmin):
    pass

        
class SpammerListAdmin(admin.ModelAdmin):
    list_display = ('ip', 'last_post')


class SiteMetaInline(admin.StackedInline):
    model = SiteMeta
    raw_id_fields = ('popular_product',)
    
admin.site.unregister(Site)


class MySiteAdmin(SiteAdmin):
    model = Site
    list_display = ('domain','name')
    inlines = [SiteMetaInline,]
    
admin.site.register(Site, MySiteAdmin)
    
admin.site.register(SpammerList, SpammerListAdmin)
admin.site.register(MiscPage, MiscPageAdmin)
admin.site.register(NewsItem)
admin.site.register(Subscription, SubscriptionAdmin)
#admin.site.register(Strings, StringsAdmin)
admin.site.register(SubscriptionGroup,SubscriptionGroupAdmin)
admin.site.register(Email,EmailAdmin)
admin.site.register(FlashImage, FlashImageAdmin)
admin.site.register(PromoTile, PromoTileAdmin)
admin.site.register(MediaUpload, MediaUploadAdmin)