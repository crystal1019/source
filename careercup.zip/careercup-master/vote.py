import masterpage

import method_db
import method_user
import method_comment
import method_url
import method_question
import method_notification
	
class Vote(masterpage.MasterPage):
	def post(self):
		#  Get logged in voter
		voter = method_user.getLoggedInUser()
		if not voter:
			#self.redirectToLoginWithUrl(self.request.get('redirection'))
			self.response.out.write('login');
			return
	
		voterId = voter.uid
		commentId = int(self.request.get('commentId'))
		val = int(self.request.get('val'))
		vote_type = self.request.get('vote_type')
		
		if vote_type == 'comment':
			item = method_comment.getCommentWithId(commentId)
			root_id = item.ancestor_id
			root_type = item.type
			root_item = method_db.getObjectWithTypeAndId(root_id, root_type)
		elif vote_type == 'question':	
			item = method_question.getQuestionWithId(commentId)
			root_id = item.uid
			root_type = 'question'
			root_item = item
		else:
			return

		skip = False
		
		prev_votes_up = len(item.votes_up_people)
		prev_votes_down = len(item.votes_down_people)
		
		author = None		

		if voterId != item.author_id:
			author = method_user.getUserWithId(item.author_id)
			if val == 1: # if click vote up
				if voterId in item.votes_down_people: # if already voted down
					item.votes_down_people.remove(voterId)
				elif voterId in item.votes_up_people: # if already voted up
					skip = True
				else: # if hasn't voted
					item.votes_up_people.append(voterId)		
					if item.author_id is not None:
						if vote_type == 'comment':
							method_notification.notifyUserOfCommentVote(item, voter, author)
						elif vote_type == 'question':		
							method_notification.notifyUserOfQuestionVote(item, voter, author)							
			elif val == -1: # if click vote down
				if voterId in item.votes_down_people: # if already voted down
					skip = False
				elif voterId in item.votes_up_people: # if already voted up
					item.votes_up_people.remove(voterId)
				else: # if hasn't voted
					item.votes_down_people.append(voterId)	

		item.votes_net = len(item.votes_up_people) - len(item.votes_down_people)
		item.votes_count = len(item.votes_up_people) + len(item.votes_down_people)	
		
		if author:
			old_impact = method_user.computeScoreImpactOfVote(prev_votes_up, prev_votes_down)
			new_impact = method_user.computeScoreImpactOfVote(len(item.votes_up_people), len(item.votes_down_people))
			method_user.incrementReputation(author, new_impact - old_impact)
			
		method_db.putObject(item)
		method_db.onObjectUpdated(root_item)
		
		if not skip:
			ancestor_url = '/' + method_url.getUrlWithType(root_type) + '?id=' + str(root_id) + "#comment" + str(root_id)
			if val == 1:
				self.addActivity(voter.name, ancestor_url, '/images/voted.png', 'vote', 'up', None, 'up-voted ' + item.author_name + '\'s ' + vote_type + ': ' + item.text)
			#elif val == -1:
			#	self.addActivity(voter.name, ancestor_url, '/images/voted.png', 'vote', 'down', None, 'down-voted ' + item.author_name + '\'s ' + vote_type + ': ' + item.text)		
			
			self.response.out.write(str(item.votes_net) + '#' + str(item.votes_count))			
		#self.redirect(self.request.get('redirection'))