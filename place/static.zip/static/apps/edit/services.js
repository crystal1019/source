angular.module('editor.services', []).factory("SaveData", ["$http", "$q", function($http, $q){
    var url = '/editor_v2/save/';
    var stack = [];
    return{
        push: function(type, data){
            stack.push({
                "type": type,
                "data": data
            });
        },
        contains: function(data){
            item = _.find(stack, function(obj) {
                return obj.data.data === data;
            });
            //If no entry is found obj == undefined, so true/false is returned
            return angular.isDefined(item);
        },
        remove: function(data){
            //Returns the stack minus any entries containing data obj
            stack = _.reject(stack, function(obj){
                return obj.data.data === data;
            });
        },
        save: function(topic, current_tab){
            var self = this;
            var defer = $q.defer();
            _.each(stack, function(item){
                if(item.type === "event"){
                    if(item.data.action !== 'delete'){
                        evt = item.data.data;
                        if(evt.start_with_tz){
                            evt.start_timestamp = moment(evt.start_with_tz).format('X');
                        }
                        if(evt.end_with_tz){
                            evt.end_timestamp = moment(evt.end_with_tz).format('X');
                        }
                        if(evt.event_date && evt.all_day_event){
                            evt.all_day_date = moment(evt.event_date).format('YYYY-MM-D');
                        }
                    }
                }
            });
            $http.post(
                url,
                {
                    'topic': topic,
                    'data': stack,
                    'current_tab': current_tab
                }
            ).success(function(obj) {
                defer.resolve({data_type:'topic', data:obj});
            }).error(function(data, status){
                defer.reject(data);
            });
            return defer.promise;
        },
        stackModified: function(){
            return !_.isEmpty(stack);
        },
        getStack: function(){
            //temporary
            return stack;
        },
        clear: function() {
            stack = [];
        }
    };
}]).factory("OverviewData", ["$http", "$q", function($http, $q){
    var url = '/editor_v2/overview/';
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        upload_error: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    if(obj.data.image === null){
                        obj.data.image = {
                            url: null,
                            id: null
                        };
                    }
                    self.store = obj.data;
                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("TeamData", ["$http", "$q", function($http, $q){
    var url = '/editor_v2/team/';
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("ContactData", ["$http", "$q", function($http, $q){
    var url = '/editor_v2/contacts/';
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        next_index: 1,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    index = 1;
                    _.each(obj.data.contacts, function(contact){
                        contact.index = index;
                        index++;
                    });
                    self.store = obj.data;
                    self.next_index = index;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("SocialData", ["$http", "$q", function($http, $q){
    var url = '/editor_v2/social/';
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        next_index: 1,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    var index = 1;
                    _.each(obj.data.twitterparams, function(tp){
                        tp.index = index;
                        index++;
                    });
                    self.store = obj.data;
                    self.next_index = index;
                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("FeaturesData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/features/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("WhoData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/who/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("SurveyData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/surveys/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        fs_defer: $q.defer(),
        topic: null,
        published_survey: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {
                        'topic': self.topic
                    }
                }).success(function(obj) {
                    self.store = obj.data;
                    self.defer.resolve(obj);
                    _.each(self.store.limesurvey_ts, function(v) {
                        if (v.is_published) {
                            self.published_survey = v;
                            return;
                        }
                    });
                    if (obj.data.has_fluidsurveys) {
                        self.loadFluidSurveys(topic);
                    }
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        },
        // Load separately b/c it needs to use
        // 3rd party api for data.
        loadFluidSurveys: function(topic){
            var self = this;
            $http({
                method: 'GET',
                url: url,
                params: {
                    'topic': self.topic,
                    'req': 'fluidsurveys'
                }
            }).success(function(obj) {
                _.extend(self.store, obj.data);
               self.fs_defer.resolve(obj);
               if (!self.published_survey) {
                   _.each(self.store.fluidsurveys_ts, function(v) {
                        if (v.is_published) {
                            self.published_survey = v;
                            return;
                        }
                    });
                }
            }).error(function(data, status){
               self.fs_defer.reject(data);
            });
            return self.fs_defer.promise;
        }
    };
}]).factory("EventData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/events/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        next_index: 1,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    var index = 1;
                    // Convert to Date objects for datepicker & add index for error msgs
                    _.each(obj.data, function(evt){
                        if(evt.start_with_tz){
                            evt.start_with_tz = moment(evt.start_with_tz);
                        }
                        if(evt.end_with_tz !== null){
                            evt.end_with_tz = moment(evt.end_with_tz);
                        }
                        if(evt.event_date){
                           evt.event_date = moment(evt.event_date, 'YYYY-MM-D');
                        }
                        evt.index = index;
                        index++;
                    });

                    self.store = obj.data;
                    self.next_index = index;
                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("DiscussionData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/discussions/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        next_index: 1,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    var index = 1;
                    _.each(obj.data, function(dis){
                        dis.index = index;
                        index++;
                    });
                    self.store = obj.data;
                    self.next_index = index;
                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("PollData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/polls/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("KeywordsData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/keywords/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("ParticipantData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/participants/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("ReportData", ["$http", "$q", function($http, $q){
    var url = "/editor_v2/reports/";
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    self.store = obj.data;

                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]).factory("ResourceData", ["$http", "$q", function($http, $q){
    var url = '/editor_v2/resources/';
    return {
        is_dirty: false,
        store: null,
        active: false,
        defer: $q.defer(),
        topic: null,
        load: function(topic){
            this.topic = topic;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'topic': topic}
                }).success(function(obj) {
                    var index = 1;
                    _.each(obj.data.videos, function(vid){
                        vid.index = index;
                        index++;
                    });

                    self.store = obj.data;
                    self.store.next_vid_index = index;
                    self.defer.resolve(obj);
                }).error(function(data, status){
                    self.defer.reject(data);
                });
                return self.defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        }
    };
}]);