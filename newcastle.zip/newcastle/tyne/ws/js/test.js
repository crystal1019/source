cow = 3;
alert("HEERER")