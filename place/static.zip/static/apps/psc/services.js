angular.module('psc.services', [])
.factory('TeamData',["$http", "$q",function($http, $q){
    var url = "/connect/admin/team/";
    var defer = $q.defer();
    return {
        is_valid: true,
        is_dirty: false,
        store: null,
        active: false,
        psc_client: null,
        defer: $q.defer(),
        save_stack:[],
        load: function (psc_client) {
            this.psc_client = psc_client;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'psc_client': psc_client}
                }).success(function(obj) {
                    self.store = obj.data;
                    defer.resolve(obj);
                }).error(function(data, status){
                    defer.reject(data);
                });
                return defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        },
        save: function(){
            var self = this;
            //No idea why $.param is needed but wasn't being read as a correct query string in Django without it
            var p = $q.defer();
            $http({
                url: url,
                method: "POST",
                data: {
                    data:self.save_stack,
                    psc_client: self.psc_client
                }
            }).success(function(obj) {
                if (obj.success) {
                    self.store = obj.data;
                    self.save_stack = []
                }
                else {
                }
                return p.resolve();
            }).error(function(data, status){
                console.log(status);
                return p.reject();
            });
            return p.promise;
        }
    }
}])
.factory("ClientData", ["$http", "$q", "$rootScope", function($http, $q, $rootScope){
    var url = "/connect/admin/settings/";
    var defer = $q.defer();
    return {
        is_valid: true,
        is_dirty: false,
        store: null,
        active: false,
        psc_client: null,
        defer: $q.defer(),
        ext_errors: {},
        models: {}, // Key is the form name, value is array of models
        load: function (psc_client) {
            this.psc_client = psc_client;
            var self = this;
            if(!this.active) {
                this.active = true;
                $http({
                    method: 'GET',
                    url: url,
                    params: {'psc_client': psc_client}
                }).success(function(obj) {
                    self.store = obj.data;
                    defer.resolve(obj);
                }).error(function(data, status){
                    defer.reject(data);
                });
                return defer.promise;
            }
            else{
                return this.defer.resolve(self.store);
            }
        },
        save: function () {
            var self = this;
            //No idea why $.param is needed but wasn't being read as a correct query string in Django without it
            var p = $q.defer();
            $http({
                url: url,
                method: "POST",
                data: $.param(_.extend({psc_client:self.psc_client},self.store))
            }).success(function(obj) {
                if (obj.success) {
                    self.save_stack = [];
                    self.ext_errors = [];
                }
                else {
                    self.ext_errors = obj.data.errors;
                }
                return p.resolve();
            }).error(function(data, status){
                return p.reject();
            });
            return p.promise;
        }
    }
}]);
