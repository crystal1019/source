from django.conf.urls import patterns, url
import views


urlpatterns = patterns('offers.tools.beatcard.views',
    url(r'^$', 'compare_start', name='compare-index'),
    url(r'^details/$', 'compare_start', name='compare-details'),
    url(r'^result/$', 'compare_result', name='compare-result'),
    url(r'^suggest/$', 'suggest_cards', name='compare-suggest'),
    url(r'^meta-urls/$', 'get_meta', name='meta-urls'),
    url(r'^record-switcher/$', 'record_switcher', name='record-switcher'),
    url(r'^calculate-savings/$', views.CalculateSavings.as_view(), name='calculate-savings'),
)