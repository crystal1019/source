import datetime
from django import template

register = template.Library()
from django.template import Variable, Library,Node,NodeList,resolve_variable
from bellabustiere.shop.models import Product, formatCurrency

@register.tag(name='get_left_url')
def do_get_left_url(parser, token):
    bits = token.contents.split()
    if len(bits) != 4:
        raise
    return GetLeftUrl(bits[1],bits[2],bits[3])

class GetLeftUrl(template.Node):
    def __init__(self, category, nav, designer):
        self.category, self.nav, self.designer = category, nav, designer
        
    def render(self,context):
        category = resolve_variable(self.category,context)
        nav = resolve_variable(self.nav, context)
        designer = resolve_variable(self.designer, context)
        
        return category.get_absolute_url(nav=nav, designer=designer)


@register.tag(name="display_current_price")
def do_display_current_price(parser,token):
    bits = token.contents.split()
    if len(bits) != 7:
        raise 
    return DisplayCurrentPrice(bits[1], bits[2], bits[3],bits[4],bits[5], bits[6])

class DisplayCurrentPrice(template.Node):
    def __init__(self,product,quantity,wholesale,coupon,ratio,display):
        self.product,self.quantity, self.wholesale, self.coupon, self.ratio,self.display = product,quantity,wholesale,coupon,ratio,display
    
    def render(self,context):
        product = resolve_variable(self.product, context)
        coupon = resolve_variable(self.coupon, context)
        wholesale = resolve_variable(self.wholesale, context)
        wholesale = True if wholesale else False
        quantity = resolve_variable(self.quantity,context)
        quantity = int(quantity)
        ratio, currency = resolve_variable(self.ratio, context)
        price, off, discountid = product.getCurrentRightPrice(quantity,wholesale,coupon)
    
        label = '$'
        if currency == 'GBP':
            label = u'\xa3'
        elif currency == 'EUR':
            label = u'\u20ac'
        elif currency == 'USD':
            label = 'USD $'
        
        price_ratio = formatCurrency(float(price) * float(ratio))
        
        if self.display == 'price':
            if price != product.getNormalPrice(wholesale):
                return '''<span>%s%s</span><span id='discounted_price' style='text-decoration:none !important;'>%s%s</span><span id='discounted_info' style='text-decoration:none !important;'>%.0f%% off</span>''' %(label, formatCurrency(product.price * float(ratio)), label,price_ratio, off)
            else:
                return '''%s%s''' % (label, price_ratio)
        elif self.display == 'comboprice':

            return '''<div class="price">%s%s</div>''' % (label,price_ratio)
            
        else:
            if product.getAllSizeSelect():
                
                if price != product.getNormalPrice(wholesale):
                    return '''<span>%s%s</span><span id='discounted_price' style='text-decoration:none !important;'>%s%s</span><span id='discounted_info' style='text-decoration:none !important;'>%.0f%% off</span>''' %(label, formatCurrency(product.price * float(ratio)), label,price_ratio, off)
                else:
                    return '''%s%s''' % (label, price_ratio)
                
            else:
                return '''<div id='out-of-stock' style='color:red'>Sold Out</div>'''

        
        
@register.tag(name="current_time")
def do_current_time(parser, token):
    try:
        # split_contents() knows not to split quoted strings.
        tag_name, format_string = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, "%r tag requires a single argument" % token.contents.split()[0]
    if not (format_string[0] == format_string[-1] and format_string[0] in ('"', "'")):
        raise template.TemplateSyntaxError, "%r tag's argument should be in quotes" % tag_name
    return CurrentTimeNode(format_string[1:-1])

class CurrentTimeNode(template.Node):
    def __init__(self, format_string):
        self.format_string = format_string
    def render(self, context):
        return str((context.dicts[1]))
        return datetime.datetime.now().strftime(self.format_string)

@register.tag(name="category_display_price")
def do_category_display_price(parser, args):
    return CategoryCurrentPriceNode()

class CategoryCurrentPriceNode(template.Node):
    def __init__(self):
        pass
    def render(self, context):
        if context.dicts[3].has_key("user"):
            price = str(((context.dicts[0]['x']).getTaxPrice(True)))
        else:
            price = str(((context.dicts[0]['x']).getTaxPrice(False)))
        if not context.dicts[0]['x'].isDiscounted(context.dicts[3].has_key("user")):
            return """<strong>$AU %s (inc.GST)</strong>""" % price
        else:
            normalPrice = str(((context.dicts[0]['x']).getNormalTaxPrice(context.dicts[3].has_key("user"))))
            return """<strike>$AU %s (inc.GST)</strike><br/><strong class="discounted">$AU %s (inc.GST)</strong>""" % (normalPrice, price)
@register.tag(name="product_display_price")
def do_product_display_price(parser, args):
    return ProductCurrentPriceNode()

class ProductCurrentPriceNode(template.Node):
    def __init__(self):
        pass
    def render(self, context):
        if context.dicts[3].has_key("user"):
            price = str(((context.dicts[0]['x']).getTaxPrice(True)))
        else:
            price = str(((context.dicts[0]['x']).getTaxPrice(False)))
        if not context.dicts[0]['x'].isDiscounted(context.dicts[3].has_key("user")):
            return """<strong>$AU %s (inc.GST)</strong>""" % price
        else:
            normalPrice = str(((context.dicts[0]['x']).getNormalTaxPrice(context.dicts[3].has_key("user"))))
            return """<strike>$AU %s (inc.GST)</strike><br/><strong class="discounted">$AU %s (inc.GST)</strong>""" % (normalPrice, price)
