from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.models import Hint
from datetime import datetime, timedelta
from roomhints.utils import random_number, make_unique, make_unique_photo, search_profile_id, photo_convert
import shutil
from roomhints.color import get_color_stats
from roomhints.affiliate import affiliate_data, affiliate_set
import os

class Command(BaseCommand):
    help = 'Make sure all hints in search use small pictures'

    def handle(self, *args, **options):
        projuniq = None
        for a in args:
            projuniq = a

        #hall = Hint.objects.filter(profile_id=search_profile_id()).all()
        hall = Hint.objects.filter(public=True).all()
        for h in hall:
            # The photos were rebuilt once when the defaulthints were copied into
            # hints. It is not needed any more
            # print("Rebuilding smaller photos for hint: " + h.name)
            # h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
            # h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
            # photo_convert(settings.MEDIA_ROOT + h.photo.name,
            #               settings.MEDIA_ROOT + h.photo_web.name, "480000")
            # photo_convert(settings.MEDIA_ROOT + h.photo.name,
            #               settings.MEDIA_ROOT + h.photo_mob.name, "147200")

            # Do not automatically add color; we manually reset it now and do
            # not want to lose the older manual values.

            # if os.path.exists(settings.MEDIA_ROOT + h.photo_mob.name):
            #     color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
            #     h.dominant_hex = color_hex
            # else:
            #     h.dominant_hex = "ffffff"
            print ("h is " + str(h))
            aff = affiliate_data(h)
            ar = affiliate_set(aff['url'],h)
            print ("set affiliate url " + h.affiliate_url)
            h.save()
