import objects
import method_db
import method_cache

flag_limit = 1

def getSalaryWithId(id, force=False):
	salary = objects.SalaryInfo.query(objects.SalaryInfo.uid == id).get()
	salary = method_db.addInfoToObject(salary)
	if force: # if forcing the comment to be visible
		return salary
	else:
		return method_db.ensureVisible(salary)
	
def getFlaggedSalaryCount():
	flagged_count = method_cache.getObjectForTypeAndKey('flagged_salary_count', None)
	if not flagged_count:
		flagged_count = objects.SalaryInfo.query(objects.SalaryInfo.under_review == True).count()
		method_cache.setObjectForTypeAndKey('flagged_salary_count', None, flagged_count)
	return flagged_count	
	
def clearCache(salary):
	method_cache.clearObjectForTypeAndId('flagged_salary_count', None)
	method_cache.clearObjectForTypeAndId('salaries', None)

def clearFlaggedSalaryCountCache():
	method_cache.clearObjectForTypeAndId('flagged_salary_count', None)
	
def deleteSalary(salary):
	salary.visible = False
	method_db.putObject(salary)
	
def undeleteSalary(salary):
	salary.visible = True
	method_db.putObject(salary)