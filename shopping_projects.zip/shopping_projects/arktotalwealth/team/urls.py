from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('arktotalwealth.team.views',
	(r'^$', 'home'),
	(r'^(?P<slug>.*).html$', 'home'),


)