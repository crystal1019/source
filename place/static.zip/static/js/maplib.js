function GMap(id, options) {

    // Tile server
    // this.TILE_SERVER_URL = MAP_URL;

    // Dataset types
    this.TOPIC_PINS         = 0;
    this.TOPIC_POLYS        = 1;
    this.USER_PINS          = 2;
    this.PLACE_PINS         = 3;
    this.NOTIFICATION_ZONES = 4;


    this.events = [];
    this.fill_colors = [
        '#D7191C',
        '#F4A582',
        '#92C5DE',
        '#0571B0',
        '#7B3294',
        '#C2A5CF',
        '#A6DBA0',
        '#008837',
        '#A6611A',
        '#DFC27D',
        '#4DAC26',
        '#FB9A99',
        '#FF7F00',
        '#E5D8BD',
        '#A65628',
        '#F781BF',
        '#D4D800',
        '#00689C',
        '#F781BF',
        '#C1073F',
        '#350050',
        '#4F250C',
        '#AD4900',
        '#FFF37A',
        '#82783D'
    ];

    this.colors = [
        "#27a4ba",  // teal
        "#C23387",  // purple
        "#CEDE4F",  // green
        "#FF9E69"   // orange
    ];

    this.default_feature_styles = {
        polygon: {
            strokeColor: "#000000",
            fillColor: "#D7191C",
            strokeWeight: 1,
            strokeOpacity: 0.75,
            fillOpacity: 0.5
        }
    };

    this.edit_style = {
        polygon: {
            strokeColor: "#007889",
            fillColor: "#27a4ba",
            strokeWeight: 2,
            strokeOpacity: 0.8,
            fillOpacity: 0.5
        }
    };

    this.drawingManager = null;

    // Element id
    this.id = id;
    this.topic_pins = [];
    this.topic_polys = TAFFY();
    this.topic_poly_edit_feature = null;
    this.user_pins = [];
    this.place_pins = [];
    this.notification_zones = [];
    this.user_icon = new google.maps.MarkerImage('/static/img/green_dot.png');
    this.topic_icons = {
        'government': new google.maps.MarkerImage('/static/img/marker_govt.png'),
        'private': new google.maps.MarkerImage('/static/img/marker_private.png'),
        'community': new google.maps.MarkerImage('/static/img/marker_community.png'),
        'agency': new google.maps.MarkerImage('/static/img/marker_agency.png'),
        'government-seed': new google.maps.MarkerImage('/static/img/marker_govt_seed.png')
    };
    this.topic_icon_shadow = new google.maps.MarkerImage("/static/img/marker_shadow.png",
        new google.maps.Size(38.0, 34.0),
        new google.maps.Point(0, 0),
        new google.maps.Point(10.0, 34.0)
    );

    // Default options
    this.default_options = {
        center: new google.maps.LatLng(49.277297, -123.147651),
        zoom: 8,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        mapTypeControl: false,
        panControl: false,
        draggable: true,
        zoomControl: true,
        streetViewControl: false,
        zoomControlOptions: {
            position: google.maps.ControlPosition.RIGHT_BOTTOM,
            style: google.maps.ZoomControlStyle.SMALL
        }
    };

    var opts = this.default_options;
    // Apply any options
    for(var option in options) {
        opts[option] = options[option];
    }
    this.map = new google.maps.Map(document.getElementById(this.id), opts);
    google.maps.event.addListener(
        this.map,
        'bounds_changed',
        this._restrictZoom
    );
}
GMap.prototype.constructor = GMap;

GMap.prototype.addPlace = function(num, lat, lng){
    // Sort out which color to use.
    var classes = [
        'teal-place',
        'purple-place',
        'green-place',
        'orange-place'
    ];
    var classes_length = 4;
    var idx = 0;
    var n = num - 1;
    while (n--) {
        if ( idx >= classes_length - 1 ) {
            idx = 0;
        }
        else{
            idx++;
        }
    }
    var place_marker = new RichMarker({
        position: new google.maps.LatLng(lat, lng),
        map     : this.map,
        shadow  : 'transparent',
        anchor  : RichMarkerPosition.MIDDLE,
        content : '<span class="place ' + classes[idx] + '">' + num + '</span>'
    });
    this.place_pins.push(place_marker);
};

GMap.prototype.addNotificationZone = function(radius, lat, lng, num) {
    // Sort out which color to use.
    var color_length = 4;
    var idx = 0;
    var n = num - 1;
    while (n--) {
        if ( idx >= color_length ) {
            idx = 0;
        }
        else{
            idx++;
        }
    }
    var buffer = new google.maps.Circle({
        "center"      : new google.maps.LatLng(lat, lng),
        "radius"      : radius,
        "fillColor"   : this.colors[idx],
        "fillOpacity" : 0.3,
        "strokeWeight": 0,
        "editable"    : false,
        "map"         : this.map
    });
    this.notification_zones.push(buffer);
    return buffer;
};

GMap.prototype.addTopic = function(id, category, lat, lng, plan_code) {
    var icon;
    if (plan_code === 'seed') {
        category = category + '-seed';
    }

    var topic_marker = new google.maps.Marker({
        position: new google.maps.LatLng(lat, lng),
        map     : this.map,
        icon: this.topic_icons.hasOwnProperty(category) ? this.topic_icons[category] : null,
        shadow  : this.topic_icon_shadow
    });

    topic_marker.setValues({'category': category});

    this.topic_pins.push(topic_marker);
    var self = this;
    google.maps.event.addListener(topic_marker, 'click', function(){

        // Close all info bubbles that are open.
        for (var n=0, tp_cnt=self.topic_pins.length; n < tp_cnt; n++){
            var tp = self.topic_pins[n];
            if (tp.info){
                tp.info.close();
            }
        }

        // Check if marker has an infobubble,
        // if not create one and then open it.
        if (!topic_marker.hasOwnProperty('info')){
            $.ajax({
                url: '/topics/topic_card/',
                type: 'get',
                data: {
                    topic: id,
                    is_map: true
                },
                dataType: 'html',
                success: function(html) {
                    var info = new InfoBubble({
                        maxWidth           : 220,
                        minHeight          : 230,
                        maxHeight          : 325,
                        content            : html,
                        padding            : 0,
                        shadowStyle        : 0,
                        closeButton        : '/static/img/infobubble-close-button.png',
                        backgroundClassName: 'infobubble-topic-box',
                        borderRadius       : 0
                    });
                    topic_marker.setOptions({
                        "info": info
                    });
                    topic_marker.info.open(self.map, topic_marker);
                },
                error: function(err){

                }
            });

        }
        else{
            if (!this.info.isOpen()) {
                topic_marker.info.open(self.map, topic_marker);
            }
        }
    });
};

GMap.prototype.clearTopics = function () {
    var pins = this.topic_pins;
    for (var i = 0, cnt = pins.length; i < cnt; i++) {
        pins[i].setMap(null);
    }
    this.topic_pins = [];
};

GMap.prototype.addUserPin = function(lat, lng){
    var user_marker = new google.maps.Marker({
        position : new google.maps.LatLng(lat, lng),
        map      : this.map,
        icon     : this.user_icon,
        clickable: false
    });
    this.user_pins.push(user_marker);
};

GMap.prototype.centerMapToUser = function(){
    var self = this;
    geolocate(function(obj){
        var coords = obj.coords;
        self.map.setCenter(
            new google.maps.LatLng(coords.latitude, coords.longitude)
        );
    },
    function(err){},
    {}
    );
};

GMap.prototype.addTopicPolys = function(geojson) {
    if (geojson.features.length > 0 && !geojson.features[0].hasOwnProperty('style')) {
        for (var i = geojson.features.length - 1; i >= 0; i--) {
            if (!geojson.features[i].properties.hasOwnProperty('style')) {
                geojson.features[i].properties['style'] = this._get_random_style('polygon');
            }
        }
        this.topic_polys().fromGeoJson(geojson);
    }
    else {
        this.topic_polys().fromGeoJson(geojson, null);
    }
    this.topic_polys().setMap(this.map);
};


GMap.prototype._getNormalizedCoord = function(coord, zoom) {
    // Normalizes the coords that tiles repeat across the x axis (horizontally)
    // like the standard Google map tiles.
    var y = coord.y;
    var x = coord.x;

    // tile range in one direction range is dependent on zoom level
    // 0 = 1 tile, 1 = 2 tiles, 2 = 4 tiles, 3 = 8 tiles, etc
    var tileRange = 1 << zoom;

    // don't repeat across y-axis (vertically)
    if (y < 0 || y >= tileRange) {
        // return null;
        y = (y % tileRange + tileRange) % tileRange;
    }

    // repeat across x-axis
    if (x < 0 || x >= tileRange) {
        x = (x % tileRange + tileRange) % tileRange;
    }

    return {
        x: x,
        y: y
    };
};

GMap.prototype.addTopicPolyTiles = function(topic) {
    var self = this;
    var topic_tiles =  new google.maps.ImageMapType({
        getTileUrl: function(coord, z) {
            var ncoords = self._getNormalizedCoord(coord, z);
            return self.TILE_SERVER_URL + '/topic/' + topic
                + '/' + z
                + '/' + ncoords.x
                + '/' + ncoords.y + '.png';
        },
        tileSize: new google.maps.Size(256, 256),
        isPng: true,
        minZoom: 0,
        maxZoom: 21
    });

    this.map.overlayMapTypes.insertAt(0, topic_tiles);
};

GMap.prototype.addPlaceTopicTiles = function(topic) {
    var self = this;
    var plc_topic_tiles =  new google.maps.ImageMapType({
        getTileUrl: function(coord, z) {
            var ncoords = self._getNormalizedCoord(coord, z);
            return self.TILE_SERVER_URL + '/place/' + topic
                + '/' + z
                + '/' + ncoords.x
                + '/' + ncoords.y + '.png';
        },
        tileSize: new google.maps.Size(256, 256),
        isPng: true,
        minZoom: 0,
        maxZoom: 21
    });

    this.map.overlayMapTypes.insertAt(0, plc_topic_tiles);
};

GMap.prototype.addPlaceTiles = function() {
    var self = this;
    var place_tiles =  new google.maps.ImageMapType({
        getTileUrl: function(coord, z) {
            var ncoords = self._getNormalizedCoord(coord, z);
            return self.TILE_SERVER_URL + '/place'
                + '/' + z
                + '/' + ncoords.x
                + '/' + ncoords.y + '.png';
        },
        tileSize: new google.maps.Size(256, 256),
        isPng: true,
        minZoom: 0,
        maxZoom: 21
    });

    this.map.overlayMapTypes.insertAt(0, place_tiles);
};

GMap.prototype.fitExtentToMapData = function(dataset){
    /*
        datasets: (Array) An array of datasets to include,
        if not defined all datasets are included.

        Datasets:
        -------
        this.TOPIC_PINS         = 0;
        this.TOPIC_POLYS        = 1;
        this.USER_PINS          = 2;
        this.PLACE_PINS         = 3;
        this.NOTIFICATION_ZONES = 4;

    */

    // this.notification_zones = [];
    var bounds = new google.maps.LatLngBounds();

    if (dataset === this.TOPIC_PINS) {
        // Topic Pins
        for (var i = 0, tp_cnt = this.topic_pins.length; i < tp_cnt; i++) {
            bounds.extend(this.topic_pins[i].getPosition());
        }
    }

    if (dataset === this.USER_PINS) {
        // User Pins
        for (var j = 0, up_cnt = this.user_pins.length; j < up_cnt; j++) {
            bounds.extend(this.user_pins[j].getPosition());
        }
    }

    if (dataset === this.PLACE_PINS) {
        // Place Pins
        for (var k = 0, pp_cnt=this.place_pins.length; k < pp_cnt; k++) {
            bounds.extend(this.place_pins[k].getPosition());
        }
    }

    if (dataset === this.TOPIC_POLYS) {
        // Topic Polys
        var gcol = TAFFY.geometry_column;
        this.topic_polys().each(function(rec, recnum){
            bounds.union(rec[gcol].getBounds());
        });
    }
    this.map.fitBounds(bounds);
};

GMap.prototype._create_feature = function(feature, fid, properties, style) {
    feature.set('fid', fid);
    feature.set('properties', properties);
    if (style) {
        feature.setOptions(style);
    }
    return feature;
};

GMap.prototype._get_style = function(feature) {
    return {
        strokeColor: feature.get('strokeColor'),
        fillColor: feature.get('fillColor'),
        strokeWeight: feature.get('strokeWeight'),
        strokeOpacity: feature.get('strokeOpacity'),
        fillOpacity: feature.get('fillOpacity')
    };
};

GMap.prototype.startEditingFeature = function(record) {
    var g = record[TAFFY.geometry_column];
    // If the same record is clicked stop
    // editing it.
    if (record == this.topic_poly_edit_feature) {
        this.stopEditingFeature(record);
        return;
    }

    g.setEditable(true);
    if (g instanceof google.maps.Polygon) {
        if (this.topic_poly_edit_feature) {
            this.stopEditingFeature(this.topic_poly_edit_feature);
        }
        g.set('original_style', this._get_style(g));
        g.setOptions(this.edit_style.polygon);
        this.topic_poly_edit_feature = record;
    }
};

GMap.prototype.stopEditingFeature = function(record) {
    if (!record) return;
    var g = record[TAFFY.geometry_column];
    g.setEditable(false);
    g.setOptions(
        g.get('original_style')
    );
    g.set('original_style', null);
    this.topic_poly_edit_feature = null;
    this.fire('stopeditingfeature', record);
};

GMap.prototype._create_click_handler = function(record) {
    var self = this;
    return function() {
        self.startEditingFeature(record);
        self.fire('feature_click', record);
    };
};

GMap.prototype._get_random_style = function(geometry_type){
    var idx = Math.floor(Math.random()*this.fill_colors.length);
    var color = this.fill_colors[idx];
    var style = {};
    for(var p in this.default_feature_styles[geometry_type]) {
        style[p] = this.default_feature_styles[geometry_type][p];
    }
    if (geometry_type === 'polygon') {
        style.fillColor = color;
    }
    return style;
},

GMap.prototype.startEditing = function() {
    var self = this;
    this.drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: null,
        drawingControl: true,
        drawingControlOptions: {
          // position: google.maps.ControlPosition.TOP_CENTER,
          position: google.maps.ControlPosition.LEFT_TOP,
          drawingModes: [google.maps.drawing.OverlayType.POLYGON]
        },
        polygonOptions: this.default_style
    });

    this.drawingManager.setMap(this.map);

    google.maps.event.addListener(this.drawingManager, 'polygoncomplete', function(polygon){
        var style = self._get_random_style('polygon');
        polygon.setOptions(style);
        var record = self.topic_polys.insert({
            overlay: polygon,
            style: style,
            label: 'No label'
        }).first();
        google.maps.event.addListener(polygon, 'click', self._create_click_handler(record));
        self.startEditingFeature(record);
        self.fire('featurecreated', record);
    });

    this.topic_polys().each(function (record, recordnumber) {
        var g = record[TAFFY.geometry_column];
        google.maps.event.addListener(
            g,
            'click',
            self._create_click_handler(record)
        );
    }); // alerts the value of the balance column
};

GMap.prototype.stopEditing = function() {
    this.stopEditingFeature(this.topic_poly_edit_feature);
    for (var i = this.topic_polys.length - 1; i >= 0; i--) {
        this.stopEditingFeature(this.topic_polys[i]);
    }
    google.maps.event.clearListeners(this.drawingManager, 'polygoncomplete');
    this.drawingManager.setMap(null);
    this.drawingManager = null;
};

GMap.prototype._restrictZoom = function() {
    // Things get wonky at zoom level 1 and
    // level 1 is a weird zoom level anyhow.
    if (this.map && this.map.getZoom() <= 1) {
        this.map.setZoom( 2 );
    }
};

GMap.prototype.deleteFeature = function(record, dataset_name) {
    if (dataset_name === this.TOPIC_POLYS) {
        var g = record[TAFFY.geometry_column];
        g.setMap(null);
        this.topic_polys().filter({
            ___id: record.___id
        }).remove();
        if (record == this.topic_poly_edit_feature) {
            this.topic_poly_edit_feature = null;
        }
        this.fire('delete_feature', record);

        // var g = record[TAFFY.geometry_column];
        // g.setMap(null);
        // var index = this.topic_polys.indexOf(feature);
        // if (index != -1) {
        //     var del_feature = this.topic_polys.splice(index, 1);
        //     if (del_feature == this.topic_poly_edit_feature) {
        //         this.topic_poly_edit_feature = null;
        //     }
        //     this.fire('delete_feature', del_feature);
        // }
    }
};

/* EVENTS*/
GMap.prototype.on =  function(event, callback) {
    var events = event.split(' ');
    var self = this;
    for (var i = events.length - 1; i >= 0; i--) {
        this.events[events[i]] = this.events[events[i]] || [];
        this.events[events[i]].push(callback);
    }
    return this;
};

GMap.prototype.off = function(event, callback, clear) {
    if (clear) {
        this.events[event] = [];
    }
    else{
        var e = this.events[event];
        for (var i = 0, fx_cnt=e.length; i < fx_cnt; i++) {
            if (e[i] === callback) {
                e.splice(i, 1);
            }
        }
    }
    return this;
};

GMap.prototype.fire = function(event) {
    this.events = this.events || {};
    if( event in this.events === false  )  return;
    var e = this.events[event];
    for (var i = 0, fx_cnt=e.length; i < fx_cnt; i++) {
        e[i].apply(this, Array.prototype.slice.call(arguments, 1));
    }
    return this;
};


var googleMapsToFeature = function(feature, is_multi){
    var wkt = '';
    var style = {};
    // Only does single polygons.
    var geometries = map_manager._prepGeometry(feature.overlay);
    if (geometries[0] instanceof google.maps.Polygon){
        var paths = geometries[0].getPaths();
        var polygon = [];
        paths.forEach(function(path){
            var ring = [];
            path.forEach(function(pnt){
                ring.push(pnt.lng() + ' ' + pnt.lat());
            });
            ring.push(ring[0]); // Close ring
            polygon.push('(' + ring.join(',') + ')');
        });
        if(is_multi){
            wkt = 'MULTIPOLYGON((' + polygon.join(',') + '))';
        }
        else{
            wkt = 'POLYGON' + polygon.join(',');
        }
        style = {
            'fillColor': geometries[0].fillColor,
            'fillOpacity': geometries[0].fillOpacity,
            'strokeColor': geometries[0].strokeColor,
            'strokeOpacity': geometries[0].strokeOpacity,
            'strokeWeight': geometries[0].strokeWeight
        };
    }
    return $.toJSON({
        'geometry': wkt,
        'style': style,
        'label': feature.label
    });
};

var geometryToGoogleMaps = function( geojsonGeometry, opts, geojsonProperties ){
    var googleObj;
    switch ( geojsonGeometry.type ){

        case "Point":
            opts.position = new google.maps.LatLng(geojsonGeometry.coordinates[1], geojsonGeometry.coordinates[0]);
            googleObj = new google.maps.Marker(opts);
            if (geojsonProperties) {
                googleObj.set("geojsonProperties", geojsonProperties);
            }
            break;

        case "MultiPoint":
            googleObj = [];
            for (var i = 0; i < geojsonGeometry.coordinates.length; i++){
                opts.position = new google.maps.LatLng(geojsonGeometry.coordinates[i][1], geojsonGeometry.coordinates[i][0]);
                googleObj.push(new google.maps.Marker(opts));
            }
            if (geojsonProperties) {
                for (var k = 0; k < googleObj.length; k++){
                    googleObj[k].set("geojsonProperties", geojsonProperties);
                }
            }
            break;

        case "LineString":
            var path = [];
            for (var i = 0; i < geojsonGeometry.coordinates.length; i++){
                var coord = geojsonGeometry.coordinates[i];
                var ll = new google.maps.LatLng(coord[1], coord[0]);
                path.push(ll);
            }
            opts.path = path;
            googleObj = new google.maps.Polyline(opts);
            if (geojsonProperties) {
                googleObj.set("geojsonProperties", geojsonProperties);
            }
            break;

        case "MultiLineString":
            googleObj = [];
            for (var i = 0; i < geojsonGeometry.coordinates.length; i++){
                var path = [];
                for (var j = 0; j < geojsonGeometry.coordinates[i].length; j++){
                    var coord = geojsonGeometry.coordinates[i][j];
                    var ll = new google.maps.LatLng(coord[1], coord[0]);
                    path.push(ll);
                }
                opts.path = path;
                googleObj.push(new google.maps.Polyline(opts));
            }
            if (geojsonProperties) {
                for (var k = 0; k < googleObj.length; k++){
                    googleObj[k].set("geojsonProperties", geojsonProperties);
                }
            }
            break;

        case "Polygon":
            var paths = [];
            for (var i = 0; i < geojsonGeometry.coordinates.length; i++){
                var path = [];
                for (var j = 0; j < geojsonGeometry.coordinates[i].length; j++){
                    var ll = new google.maps.LatLng(geojsonGeometry.coordinates[i][j][1], geojsonGeometry.coordinates[i][j][0]);
                    path.push(ll);
                }
                if(!i){
                    paths.push(path);
                }else{
                    paths.push(path.reverse());
                }
            }
            opts.paths = paths;
            googleObj = new google.maps.Polygon(opts);
            if (geojsonProperties) {
                googleObj.set("geojsonProperties", geojsonProperties);
            }
            break;

        case "MultiPolygon":
            googleObj = [];
            for (var i = 0; i < geojsonGeometry.coordinates.length; i++){
                var paths = [];
                for (var j = 0; j < geojsonGeometry.coordinates[i].length; j++){
                    var path = [];
                    for (var k = 0; k < geojsonGeometry.coordinates[i][j].length; k++){
                        var ll = new google.maps.LatLng(geojsonGeometry.coordinates[i][j][k][1], geojsonGeometry.coordinates[i][j][k][0]);
                        path.push(ll);
                    }
                    if(!j){
                        paths.push(path);
                    }else{
                        paths.push(path.reverse());
                    }
                }
                opts.paths = paths;
                googleObj.push(new google.maps.Polygon(opts));
            }
            if (geojsonProperties) {
                for (var k = 0; k < googleObj.length; k++){
                    googleObj[k].set("geojsonProperties", geojsonProperties);
                }
            }
            break;

        case "GeometryCollection":
            googleObj = [];
            if (!geojsonGeometry.geometries){
                googleObj = _error("Invalid GeoJSON object: GeometryCollection object missing \"geometries\" member.");
            }else{
                for (var i = 0; i < geojsonGeometry.geometries.length; i++){
                    googleObj.push(_geometryToGoogleMaps(geojsonGeometry.geometries[i], opts, geojsonProperties || null));
                }
            }
            break;

        default:
            googleObj = _error("Invalid GeoJSON object: Geometry object must be one of \"Point\", \"LineString\", \"Polygon\" or \"MultiPolygon\".");
    }

    return googleObj;
};


/*
    Add getBounds function to google maps Polygon instances
    (was removed in google maps API v3)
*/

if (!google.maps.Polygon.prototype.getBounds) {
    google.maps.Polygon.prototype.getBounds = function(latLng) {
        var bounds = new google.maps.LatLngBounds();
        var paths = this.getPaths();
        var path;

        for (var p = 0; p < paths.getLength(); p++) {
                path = paths.getAt(p);
                for (var i = 0; i < path.getLength(); i++) {
                        bounds.extend(path.getAt(i));
                }
        }
        return bounds;
    };
}
