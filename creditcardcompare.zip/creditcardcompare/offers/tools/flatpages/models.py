import json
from datetime import datetime
from urllib import urlopen

from django.conf import settings
from django.contrib.flatpages.models import FlatPage
from django.contrib.sites.models import Site
from django.db import models
from django.template.defaultfilters import urlencode
from django.utils.translation import ugettext_lazy as _

from offers.core.models import Category


class Video(models.Model):
    page = models.OneToOneField(FlatPage, null=True, blank=True, related_name='video')
    embed = models.TextField('Embed Code')
    lead_transcription = models.TextField(null=True, blank=True)
    transcription = models.TextField(null=True, blank=True)
    categories = models.ManyToManyField(Category, blank=True, verbose_name='show in', help_text=_('Show this video under comparison table in categories selected below.'))
    
    class Meta:
        db_table = 'flatpages_video'
    
    def __unicode__(self):
        return self.page.title

class PerSiteFlatPageOption(models.Model):
    page = models.ForeignKey(FlatPage, related_name='seo_options')
    page_title = models.CharField(_('page title'), max_length=256, blank=True, null=True, help_text=_('custom page title'))
    page_description = models.TextField(_('page description'), blank=True, null=True)
    noindex = models.BooleanField(_('don\'t index ?'), default=False, help_text=_(u'If checked, <<!---->meta name="Robots" content="noindex, follow"> will be added on the header of this page.'))
    short_url = models.URLField(null=True, blank=True, help_text='Shortened URL of this page (auto generated). Empty this field to regenerate a new one.')
    site = models.ForeignKey(Site)

    class Meta:
        ordering = ('-id',)
        db_table = 'flatpages_persiteflatpageoption'
        
    @property
    def name(self):
        return self.page.title
        
    def get_short_url(self):
        if not self.short_url:
            kwargs = {'token': settings.BITLY_TOKEN,
                      'domain': 'http://www.%s' % self.site.domain,
                      'url': urlencode(self.page.url)}
            response = urlopen('https://api-ssl.bitly.com/v3/shorten?access_token=%(token)s&longUrl=%(domain)s%(url)s' % kwargs)
            self.short_url = json.loads(response.readlines()[0])['data']['url']
            self.save()
        return self.short_url
        
class Media(models.Model):
    image = models.ImageField(upload_to='uploads/flatpages/', help_text=_('Embed code: <<!---->div class="main-image"><<!---->img src="images.creditcardcompare.com.au/uploads/flatpages/[file name]" alt="" /><<!---->/div>'))
    
    class Meta:
        verbose_name_plural = _('Media (Images)')
        ordering = ['image',]
        db_table = 'flatpages_media'
        
    def __unicode__(self):
        return self.image.name.replace('uploads/flatpages/','')

class FlatPageExtra(models.Model):
    page = models.OneToOneField(FlatPage, null=True, blank=True, related_name='extras')
    thumbnail = models.ForeignKey(Media, null=True, blank=True, related_name='thumbnails', help_text=_('Used in <a href="http://www.savingup.com.au" target="_blank">SavingUp.com.au<a>, <a href="http://www.creditcardcompare.com.au/learning-centre.php" target="_blank">Learning Centre<a>, Facebook thumbnails, and others.'))
    image = models.ForeignKey(Media, null=True, blank=True, related_name='images', help_text=_('Regular sized image (usually used by infographics, learning centre articles and Pinterest.)'))
    categories = models.ManyToManyField(Category, blank=True, verbose_name='show in', help_text=_('Show this as "Related Article" in categories below.'))
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    published = models.DateTimeField(default=datetime.now)
    # social sharing options
    hashtags = models.CharField(max_length=100, blank=True, null=True, help_text=_('Twitter hashtags (comma separated)'))
    
    class Meta:
        db_table = 'flatpages_flatpageextra'
    
    def __unicode__(self):
        return self.page.title
    
    @property
    def bitly_url(self):
        try:
            return self.page.seo_options.filter(site__id=settings.SITE_ID)[0].get_short_url()
        except IndexError:
            return ''
    