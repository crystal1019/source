import datetime
from haystack.indexes import *
from haystack import site
from arktotalwealth.overview.models import *

class OverviewPageIndex(SearchIndex):
    text = CharField(document=True, use_template=True)

site.register(OverviewPage, OverviewPageIndex)