function closeHeaderBar(speed){
	var query = $('.headerinfo');
	// animate and remove from view header ::
	query.animate({marginTop:'-'+query.css('height')},speed, function(){
		$('.headerinfo').hide();
	});
};
$( document ).ready( function(){
	$( ".message" ).each(function( index ) {
	  var message = $(this).closest('.message');
	  if ($.cookie(message.attr('id')) == message.attr('message')){
	  	closeHeaderBar(0);
	  };
	});
	// init cross btn::
	$('.headerclose-cookie').on('click',function(){
		closeHeaderBar(700);
		var message = $(this).closest('.message');
		$.cookie(message.attr('id'), message.attr('message'), { expires: 30, path: '/' });
	});
	try{
		$('.countdown').countdown($('.countdown').attr('enddate'), function(event) {
		    $(this).html(event.strftime(
		     	'<div class="span3 timebox"><strong>%d</strong><br />DAYS</div>' +
	        	'<div class="span3 timebox"><strong>%H</strong><br />HOURS</div>' +
	        	'<div class="span3 timebox"><strong>%M</strong><br />MINUTES</div>' +
	        	'<div class="span3 timebox"><strong>%S</strong><br />SECONDS</div>'
		    ));
		});
	}catch(e){};
});