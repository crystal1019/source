function MapPreviewWindow(map, options) {
    this._label = null;
    this._cp_marker = null;
    this._projection = null;
    this.preview_width = 260;
    this.preview_height = 260;
    this.preview_window = null;
    this.universal_poly = [
        new google.maps.LatLng(-87, 120),
        new google.maps.LatLng(-87, -87),
        new google.maps.LatLng(-87, 0)
    ];
    this.label_template =  "<span style='display: block; position: relative; text-align: left;'>{MESSAGE}</span>";

    this.default_label_message = "" +
        "Set the topic map view by moving the window to a new location." +
        "<br/><br/><img width='11px'src='/static/img/marker.png'></img> shows the center of your topic, " +
        "as it will appear on the front page, the search page, and on the inset map on the topic page.";

    this.map = map;
    options = options || {};
    for (var opt in options) {
        this[opt] = options[opt];
    }
}

// Add events capability
MicroEvent.mixin(MapPreviewWindow);

MapPreviewWindow.prototype.constructor = MapPreviewWindow;

MapPreviewWindow.prototype._create_preview_window = function() {
    this.preview_window = new google.maps.Polygon({
        map: this.map,
        fillOpacity: 0.6,
        fillColor: '#000',
        strokeOpacity: 1,
        strokeWeight: 4,
        strokeColor: '#fff',
        clickable: false,
        editable: false,
        geodesic: false,
        visible: false
    });

    this._cp_marker = this._create_center_marker();
    this._label = this._create_info_box();

    this.helper = new google.maps.OverlayView();
    this.helper.setMap(this.map);
    this.helper.draw = function () {
        if (!this.ready) {
            this.ready = true;
            google.maps.event.trigger(this, 'ready');
        }
    };
    var self = this;
    google.maps.event.addListenerOnce(
        this.helper,
        'ready',
        function(){
            self._projection = self.helper.getProjection();
            self.centerPreviewMask();
        }
    );
};

MapPreviewWindow.prototype._create_info_box = function(message) {
    if (!message) {
        message = this.default_label_message;
    }
    var label = new InfoBox({
        content: this.label_template.replace(/\{MESSAGE\}/g, message),
        boxStyle: {
          textAlign: "center",
          fontSize: "15px",
          // width: "200px",
          width: "150px",
          color: "#fff"
        },
        disableAutoPan: true,
        // pixelOffset: new google.maps.Size(160, -130),
        pixelOffset: new google.maps.Size(150, -130),
        closeBoxURL: "",
        enableEventPropagation: true
    });
    label.hide();
    label.setMap(this.map);
    return label;
};

MapPreviewWindow.prototype._create_center_marker = function() {
    var cp_marker_icon = new google.maps.MarkerImage('/static/img/marker.png');
    var cp_marker = new google.maps.Marker({
        "map": this.map,
        "clickable": false,
        "icon": cp_marker_icon
    });
    cp_marker.setMap(this.map);
    return cp_marker;
};

MapPreviewWindow.prototype.show = function() {
    // Create on preview window on first show
    if (!this.preview_window) {
        this._create_preview_window();
    }
    this.preview_window.setVisible(true);
    this._label.show();
    this._cp_marker.setMap(this.map);
    var self = this;
    
    this._previewCenterChangeHandler = google.maps.event.addListener(
        this.map,
        'drag',
        function(){
            self.centerPreviewMask();
        }
    );

    this._previewBoundsChangeHandler = google.maps.event.addListener(
        this.map,
        'bounds_changed',
        function(){
            // Things get wonky at zoom level 1 and
            // level 1 is a weird zoom level anyhow.
            if (self.map.getZoom() == 1) {
                self.map.setZoom(2);
            }
            self.centerPreviewMask();
        }
    );

    this._previewDragEndHandler = google.maps.event.addListener(
        this.map,
        'dragend',
        function(){
            self.trigger('previewchange', self._cp_marker.position, self.map.getZoom());
        }
    );

    this._previewZoomChangedHandler = google.maps.event.addListener(
        this.map,
        'zoom_changed',
        function(){
            self.trigger('previewchange', self._cp_marker.getPosition(), self.map.getZoom());
        }
    );
};

MapPreviewWindow.prototype.hide = function() {
    this.preview_window.setVisible(false);
    this._label.hide();
    this._cp_marker.setMap(null);

    google.maps.event.removeListener(this._previewCenterChangeHandler);
    google.maps.event.removeListener(this._previewDragEndHandler);
    google.maps.event.removeListener(this._previewZoomChangedHandler);
    google.maps.event.removeListener(this._previewBoundsChangeHandler);
};

MapPreviewWindow.prototype.toggle = function(options) {
    options = options || {};
    if (this.preview_window && this.preview_window.getVisible())  {
        this.hide();
    }
    else {
        if(options.hasOwnProperty('init_zoom')) {
            this.map.setZoom(options.init_zoom);
        }

        if(options.hasOwnProperty('init_center')) {
            this.map.panTo(options.init_center);
        }
        this.show();
    }
};

// Center preview mask and center marker and update label location.
MapPreviewWindow.prototype.centerPreviewMask = function() {
    if (!this._projection) return;

    var pt = this._projection.fromLatLngToDivPixel(this.map.getCenter());
    var dx = this.preview_width / 2;
    var dy = this.preview_height / 2;
    
    // Bottom Left Point
    var bl_pt = this._projection.fromDivPixelToLatLng(new google.maps.Point(
        pt.x - dx,
        pt.y - dy
    ));
    // Top Left Point
    var tl_pt = this._projection.fromDivPixelToLatLng(new google.maps.Point(
        pt.x - dx,
        pt.y + dy
    ));
    // Top Right Point
    var tr_pt = this._projection.fromDivPixelToLatLng(new google.maps.Point(
        pt.x + dx,
        pt.y + dy
    ));

    // Bottom Right Point
    var br_pt = this._projection.fromDivPixelToLatLng(new google.maps.Point(
        pt.x + dx,
        pt.y - dy
    ));
    var paths = [this.universal_poly, [
        bl_pt,
        br_pt,
        tr_pt,
        tl_pt
    ]];

    // Refresh preview window
    this.preview_window.setPaths(paths);
    var preview_cp = this._projection.fromDivPixelToLatLng(new google.maps.Point(
        pt.x,
        pt.y
    ));
    // Adjust location of label
    this._label.setPosition(preview_cp);

    // Adjust center point marker
    this._cp_marker.setPosition(preview_cp);

};

MapPreviewWindow.prototype.getPreviewInfo = function() {
    return {
        center: this.map.getCenter(),
        zoom: this.map.getZoom()
    };
};


