var url = document.URL;
var company = url.substring(8, url.indexOf("."));
var jsFile;

if(isNaN(parseFloat(company)) == false) {
	jsFile = "js/org_pcsvcs.js";
} else {
	jsFile = "js/org_"+company+".js";
}
//jsFile = "js/org_demo.js";
$.getScript(jsFile, function( data, textStatus, jqxhr ) {
	$.getScript("js/orginfo.js", function( data, textStatus, jqxhr ) {
		$.getScript("js/calendar.js", function( data, textStatus, jqxhr ) {
			$.getScript("js/script.js", function( data, textStatus, jqxhr ) {
			});
		});
	});
});
