import json

def json_data():

    json_data = open('apptworks.json')

    data = ""
    for line in json_data:
        rem_spa_line = line.strip()

        if rem_spa_line != "" and rem_spa_line[0] != '/':

            data = data + line

    data = json.loads(data)
    json_data.close()
    print data

    return data


def domain_url():
    data = json_data()

    return data

def __init__(self):
    print domain_url()