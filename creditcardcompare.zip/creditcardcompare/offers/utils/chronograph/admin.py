from django.contrib import admin
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from django.http import HttpResponseRedirect, Http404
from django.conf.urls import patterns, url
from offers.utils.chronograph.models import Job, Log

class JobAdmin(admin.ModelAdmin):
    list_display = ('name', 'next_run', 'last_run', 'frequency', 'params', 'get_timeuntil', 'is_running')
    list_filter = ('frequency', 'disabled',)
    
    fieldsets = (
        (None, {
            'fields': ('name', ('command', 'args',), 'disabled',)
        }),
        ('Frequency options', {
            'classes': ('wide',),
            'fields': ('frequency', 'next_run', 'params',)
        }),
    )
    
    def run_job_view(self, request, pk):
        """
        Runs the specified job.
        """
        try:
            job = Job.objects.get(pk=pk)
        except Job.DoesNotExist:
            raise Http404
        job.run(save=False)
        messages.add_message(request, messages.INFO, 'The job "%(job)s" was run successfully.'% {'job': job})
        return HttpResponseRedirect(request.path + "../")
    
    def get_urls(self):
        urls = super(JobAdmin, self).get_urls()
        my_urls = patterns('',
            url(r'^(.+)/run/$', self.admin_site.admin_view(self.run_job_view), name="chronograph_job_run")
        )
        return my_urls + urls

class LogAdmin(admin.ModelAdmin):
    list_display = ('job_name', 'run_date', 'output', 'errors')
    search_fields = ('stdout', 'stderr', 'job__name', 'job__command')
    date_hierarchy = 'run_date'
    
    def job_name(self, obj):
        return obj.job.name
    job_name.short_description = _(u'Name')
    
    def output(self, obj):
        return obj.stdout[:35]
    
    def errors(self, obj):
        return obj.stderr[:35]

admin.site.register(Job, JobAdmin)
admin.site.register(Log, LogAdmin)