from django.contrib.sites.models import Site
from offers.helpers.template import site_format_date, site_format_meta
from offers.core.models import Offer
# from models import get_cache_model

OFFER = 0
CATEGORY = 1
FFCC = Site.objects.get(id=3)

REMOVED_PHRASE = { # used for category pages
    'financechoices.co.uk':'',
}
PREFIX_SETTINGS = { # used for offer pages
    'financechoices.co.uk': False,
}

def cache_data():
    offers = Offer.objects.filter(is_active=True)
    sites = Site.objects.all()
    for offer in offers:
        for site in sites:
            create_data_cache(offer, site,)
            
def create_data_cache(offer, site=FFCC):
    '''
    Creates 1 record for this offer and site. This record have fields (or columns)
    for each metafield.
    '''
    offer_cached_data = {}
#     category_cached_data = _get_cached_data(CATEGORY)
    all_offermeta = offer.meta_instances.all()
    for meta in all_offermeta:
        meta_key = meta.meta_field.key
        offer_value = meta.value_or_default if PREFIX_SETTINGS.get(site.name, True)\
                                      else meta.bare_value_or_default
        value = _cleanup_value(meta.value_or_default)
        if value is None:
            offer_value = None
#             category_value = site_format_meta('-', {}, site.name, meta_key=meta_key)
        else:
            offer_value = _cleanup_value(offer_value) + \
                          site_format_date(meta.expiry, site.name)
            offer_value = site_format_meta(offer_value, {}, site.name, OFFER, meta_key=meta_key)
#             intro_value_dict = _get_intro_values(all_offermeta, meta_key, site.name)
#             category_value = site_format_meta(_remove_phrase(value, site.name), 
#                                               intro_value_dict, 
#                                               site.name,
#                                               meta_key=meta_key)
        offer_cached_data[get_field_name(meta_key)] = offer_value
#         setattr(category_cached_data, get_field_name(meta_key), category_value)
    return offer_cached_data
#     category_cached_data.save()

def get_field_name(meta_key):
    '''
    Convert meta key into field_name for use
    in the field names of the cached table
    '''
    field_name = meta_key.replace(' ',''
                        ).replace('/',''
                        ).replace('(',''
                        ).replace(')','')
    return {'IntroRate': 'IntroInterestRate',
            'IntroRatePeriod': 'IntroInterestPeriod'
            }.get(field_name, field_name)
    
def _remove_phrase(value, site_name):
    phrase = REMOVED_PHRASE.get(site_name, ' p.a.')
    return value.replace(phrase, '')
    
def _get_intro_values(all_offermeta, meta_key, site_name):
    if 'Rate' not in meta_key:
        return {}
    rate_key, period_key = _get_intro_keys(meta_key)
    try:
        intro_period = all_offermeta.filter(meta_field__key=period_key)[0]
        intro_rate = all_offermeta.filter(meta_field__key=rate_key)[0]
    except IndexError:
        return {}
    return {'rate': _remove_phrase(intro_rate.value_or_default, site_name),
            'period': intro_period.value_or_default} 

def _get_intro_keys(meta_key):
    '''
    Transforms the meta_key into its equivalent intro keys.
    '''
    return {
     'Interest Rate': ('Intro Rate', 'Intro Rate Period'),
     'Purchase Rate': ('Intro Purchase Rate', 'Intro Purchase Period'),
     }.get(meta_key, ('', ''))
    
def _cleanup_value(value):
    dummy_values = ('-', 'na', 'n.a.', 'n/a', 'none', 'None') 
    if value in dummy_values or 'income' in value:
        return None
    return value