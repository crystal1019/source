import os
import random
import datetime
import json
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, Page
from django.contrib.auth.decorators import login_required
from django.utils.formats import mark_safe
from django.shortcuts import render
from django.db.models.aggregates import Sum
from django.db import transaction
from zimp.models import *
from .utils import *


def pagination(page, index):
    n = index
    min_page = max(1, n - 4)
    max_page = min(n + 4, page.paginator.num_pages)
    return range(min_page, max_page + 1)


#@login_required(login_url='/login')
def index(request):
    c = connection.cursor()
    c.execute("""select extract(day from created_at), sum(case type when 1 then value else 0 end) as acumulo, sum(case type when 2 then value else 0 end) as resgate from vw_transactions as v where extract(month from created_at) = extract(month from current_date) group by date(created_at)""")
    rows = c.fetchall()[:]
    acumulos = []
    resgates = []
    days = []
    for r in rows:
        days.append(str(r[0]))
        acumulos.append(str(r[1]))
        resgates.append(str(r[2]))

    c = connection.cursor()
    c.execute("""select extract(month from created_at), sum(case type when 1 then value else 0 end) as acumulo, sum(case type when 2 then value else 0 end) as resgate from vw_transactions as v group by extract(month from created_at)""")
    rows = c.fetchall()[:]
    acumulos2 = []
    resgates2 = []
    months = []
    for r in rows:
        months.append(MONTHS[r[0] - 1])
        acumulos2.append(str(r[1]))
        resgates2.append(str(r[2]))

    template = 'zimp/%s/dashboard.html' % request.user.panel

    return render(request, 'zimp/marca/dashboard.html', {
        'active_page': 'dashboard',
        'days': mark_safe(json.dumps(days)),
        'acumulos': mark_safe(','.join(acumulos)),
        'resgates': mark_safe(','.join(resgates)),
        'months': mark_safe(json.dumps(months)),
        'acumulos2': mark_safe(','.join(acumulos2)),
        'resgates2': mark_safe(','.join(resgates2)),
    })


#@login_required(login_url='/login')
def extrato(request):
    errors = False
    rows = Transactions.objects.all()
    data1 = request.GET.get('data1')
    data2 = request.GET.get('data2')
    page = request.GET.get('p')
    fmt = request.GET.get('fmt', 'html')
    filter_url = ''
    try:
        if data1 and data2:
            print(data1, data2)
            data1 = datetime.datetime.strptime(data1, '%d/%m/%Y')
            data2 = datetime.datetime.strptime(data2, '%d/%m/%Y')
            data2 += datetime.timedelta(days=1)
            print(data1, data2)
            filter_url = '?data1=%s&data2=%s&' % (request.GET.get('data1'), request.GET.get('data2'))
            rows = rows.filter(created_at__gte=data1, created_at__lt=data2)
    except:
        messages.error(request, 'Não foi possível filtrar o período informado! O formato da data deve ser "DD/MM/AAAA".')

    acumulo = rows.filter(type=1).aggregate(total=Sum('value'))['total'] or 0
    resgate = rows.filter(type=2).aggregate(total=Sum('value'))['total'] or 0
    total = acumulo - resgate
    page_list = []
    if fmt == 'html':
        rows = Paginator(rows, 10)
        try:
            rows = rows.page(page)
            page = int(page)
        except PageNotAnInteger:
            page = 1
            rows = rows.page(page)
        except EmptyPage:
            page = 0
            rows = rows.page(rows.num_pages)
        page_list = pagination(rows, page)

    context = {
        'active_page': 'acumulos',
        'rows': rows,
        'total': total,
        'filter_url': filter_url,
        'page': page,
        'page_list': page_list,
        'acumulo': acumulo,
        'resgate': resgate,
    }

    if fmt == 'csv':
        r = render(request, 'zimp/marca/extrato.csv.html', context, content_type='text/csv')
        r['Content-Disposition'] = 'attachment; filename=extrato.csv'
    else:
        r = render(request, 'zimp/marca/extrato.html', context)

    return r


def alcance(request):
    c = connection.cursor()
    c.execute("""select mes, qt_checkin from vw_rep_movimento_grupo_mes""")
    rows = c.fetchall()[:]
    acumulos = []
    months = []
    for r in rows:
        months.append(MONTHS[r[0] - 1])
        acumulos.append(str(r[1]))

    return render(request, 'zimp/marca/alcance.html', {
        'months': mark_safe(json.dumps(months)),
        'active_page': 'alcance',
        'acumulos': mark_safe(','.join(acumulos)),
    })

MONTHS = [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
]


def fatura(request):
    mes = request.GET.get('mes')
    fmt = request.GET.get('fmt')
    c = connection.cursor()
    if mes:
        c.execute("""select created_at, sum(value) as value, case type when 1 then 'COMPRA' when 2 then 'CHECK-IN' end as type, count(*) as qt from vw_transactions as v where type in (1,2) and extract(month from created_at) = %s group by created_at, type""",
                  (mes,)
        )
        rows = c.fetchall()[:]
        context = {
            'rows': rows,
            'mes': MONTHS[int(mes) - 1],
            'ano': datetime.date.today().year,
        }

        if fmt == 'csv':
            r = render(request, 'zimp/marca/fatura_mes.csv.html', context, content_type='text/csv')
            r['Content-Disposition'] = 'attachment; filename=extrato.csv'
            return r
        return render(request, 'zimp/marca/fatura_mes.html', context)
    else:
        c.execute("""select extract(month from created_at) as mes, sum(case type when 1 then value else 0 end) as acumulo, count(*) as qt from vw_transactions as v group by extract(month from created_at)""")
        rows = []

        for r in c.fetchall()[:]:
            r = list(r)
            r[0] = MONTHS[r[0] - 1]
            rows.append(r)

        return render(request, 'zimp/marca/fatura.html', {
            'active_page': 'fatura',
            'rows': rows,
            'mes': datetime.date.today().month,
        })


def usuarios(request):
    q = request.GET.get('q')
    if q:
        rows = User.objects.filter(userinfo__name__icontains=q)
    else:
        rows = User.objects.all()
    return render(request, 'zimp/marca/usuarios.html', {
        'active_page': 'usuarios',
        'rows': rows,
    })


def login(request):
    if request.method == 'POST':
        pass
    return render(request, 'zimp/marca/login.html')


def reports(request):
    path = os.path.join(os.path.dirname(__file__), '..', 'reports', 'marca', 'reports')
    replist = []
    for f in os.listdir(path):
        if os.path.splitext(f)[1] == '.frx':
            replist.append({
                'href': '/reports/?report=marca/reports/%s&fmt=pdf' % f,
                'name': os.path.splitext(f)[0],
            })
    return render(request, 'zimp/marca/reports.html', {
        'active_page': 'reports',
        'replist': replist,
    })


def test(request):
    types = [1, 1, 2]
    from_list = ['1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', '5b54b89a-7cdb-11e3-8a1e-6cf049f765f5', '6e0a29cf-7cdb-11e3-8a1e-6cf049f765f5']
    to_list = ['ca141cae-7cd4-11e3-8a1e-6cf049f765f5', 'c49d5c94-7cd4-11e3-8a1e-6cf049f765f5', 'bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 'b524a81e-7cd4-11e3-8a1e-6cf049f765f5']
    cur = connection.cursor()
    for ct in range(1000):
        r = Transaction.objects.register(
            **{
                'from_id': from_list[random.randint(0, len(from_list) - 1)],
                'to_id': to_list[random.randint(0, len(to_list) - 1)],
                'value': random.randint(10, 1000),
                'promotion': '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5'
            }
        )
        t = Transaction.objects.get(id=r[1][2])
        d = datetime.datetime(year=2013, month=1, day=1)
        d += datetime.timedelta(days=random.randint(0, 364))
        d += datetime.timedelta(seconds=random.randint(0, 80000))
        print(d)
        cur.execute('''update transactions set created_at = %s, type = %s where id = %s''', (d, random.randint(0, len(types) - 1) or 1, t.id))
        transaction.commit()
    return render(request, 'zimp/marca/test.html', {
        'r': json.dumps(r),
    })
