'''Codes categorized in these items:
1. Does not affect user experience
2. Not needed to run the site
3. No business logic involved
4. Needed only for internal maintenance, monitoring or analysis
'''

from django.conf import settings
from django.http import Http404


def cache_result(origfunc):
    """This is usable only within classes, that is, for methods.
    Limited to 1 parameter. It means that functions that accept more than
    1 parameter will have same cache regardless of the value of 2nd parameter.
    """
    def resultfunc(self, *args, **kwargs):
        try:
            flag = (args or kwargs.values())[0]
        except IndexError:
            flag = ''
        cached_name = '_%s_%s' % (origfunc.__name__, flag)
        try:
            return getattr(self, cached_name)
        except AttributeError:
            pass
        result = origfunc(self, *args, **kwargs)
        setattr(self, cached_name, result)
        return result
    resultfunc.__doc__ = origfunc.__doc__
    return resultfunc


def disable_for_loaddata(signal_handler):
    """
    Decorator that turns off signal handlers when loading fixture data.
    """
    def wrapper(*args, **kwargs):
        if kwargs['raw']:
            return
        return signal_handler(*args, **kwargs)
    return wrapper


def f(s, default=0):
    try:
        return float(s or default)
    except ValueError, e:
        if 'invalid literal for float' in e.args[0]:
            raise Http404
        raise e