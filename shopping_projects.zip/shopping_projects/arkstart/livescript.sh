cd /home/chaol/projects/arkstart
python manage.py update_index > /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/process
echo "---------------" >> /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/process
cat  /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/process >> /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/allprocess
