from roomhints.models import RoomType
from roomhints.models import RoomSetting
from roomhints.models import Project
from roomhints.models import HintType
from roomhints.models import Hint
from roomhints.models import HintStyle
from roomhints.models import RoomHint
from roomhints.models import Feedback
from roomhints.models import Comment
from roomhints.models import Beta
from roomhints.models import Profile
from roomhints.models import RoomHintLike
from roomhints.models import ProjectImpression
from roomhints.models import RoomHintImpression
from roomhints.models import FrontPhoto
from roomhints.models import Category
from django.contrib import admin

admin.site.register(Category)
admin.site.register(RoomType)
admin.site.register(RoomSetting)
admin.site.register(Project)
admin.site.register(HintType)
admin.site.register(Hint)
admin.site.register(HintStyle)
admin.site.register(RoomHint)
admin.site.register(Feedback)
admin.site.register(Comment)
admin.site.register(Beta)
admin.site.register(Profile)
admin.site.register(RoomHintLike)
admin.site.register(ProjectImpression)
admin.site.register(RoomHintImpression)
admin.site.register(FrontPhoto)
