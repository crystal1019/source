from django import forms
from .models import SignUp, FileField

class SignUpForm(forms.ModelForm):
    class Meta:
        model = SignUp

class UploadFileForm(forms.Form):
    class Meta:
        model = FileField