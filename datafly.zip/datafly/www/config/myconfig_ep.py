from config import Default

class Development(Default):
    BASE_URL = 'http://datafly.dev'
    EMAIL = 'evgeny.petukhov@gmail.com'
    HOST = '127.0.0.1'
    PORT = 8092