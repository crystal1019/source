from uuid import uuid4
from django.conf import settings
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.shortcuts import render_to_response
from django.template.loader import render_to_string
from django.template.defaultfilters import urlencode
import json as simplejson
from django.template import RequestContext
from django.utils.decorators import method_decorator
from django.views.generic import TemplateView
from helpers import generate_post_click, update_sort_order
from offers.helpers.boyd.decorators import cache_page
from offers.helpers.lead.models import Conversion
from models import Category, Offer


class CategoryList(TemplateView):
    def get_template_names(self):
        return (self.template_name, 'offers/categories.html',)
    
    def get_context_data(self, *args, **kwargs):
        context = super(CategoryList, self).get_context_data(*args, **kwargs)
        try:
            context['breakout_offer'] = Offer.objects.filter(is_toplevel_offer=True).order_by('-last_modification_date')[0]
        except IndexError:
            pass
        context['issuers'] = Category.on_site.filter(parent__slug='credit-card-issuers')
        context['features'] = Category.on_site.filter(parent__slug='credit-card-features')
        return context
    
    @method_decorator(cache_page)
    def get(self, request, *args, **kwargs):
        return super(CategoryList, self).get(request, *args, **kwargs)


def offer_list_bare(request, category_slug='credit-cards', limit=10):
    if category_slug == 'credit-card-compare-home':
        category_slug = 'credit-cards'
    return offer_list_for_category(request, category_slug, limit,
                            template='offers/snippets/bare_offer_list.html')


def _build_meta(offers, page_url, request=None):
    try:
        category = Category.objects.get(id=request.GET.get('metadata_only', None))
    except (AttributeError, Category.DoesNotExist):
        pass
    else:
        offers = category.offers_published_on_site(active_only=request.GET.get('active_only', True),
                                                   is_mobile=request.session['is_mobile'],
                                                   extra_categories=request.POST.getlist('extra_cats'))
    offerMetaData = dict()
    for offer in offers:
        metaData = dict()
        for meta in offer.meta_instances.all():
            metaData[meta.key] = meta.value_or_default
        metaData['offer-image'] = 'http://images.creditcardcompare.com.au/media/' \
                                    + offer.image.name
        metaData['issuer'] = offer.issuer_category.slug if offer.issuer_category else ''
        offerMetaData['%s?src=%s' % (offer.get_apply_url(),
                                     page_url)] = metaData
    return offerMetaData

def _paginate(template, context, request, limit=10):
    try:  # Make sure page request is an int. If not, deliver first page.
        page = int(request.GET.get('page', '1'))
    except ValueError:
        page = 1
    
    # Show 10 offer_list per page
    paginator = Paginator(context['offer_list'], limit if limit > 0 else 1)

    try:  # If page request (9999) is out of range, deliver last page.
        offer_list = paginator.page(page)
    except (EmptyPage, InvalidPage):
        offer_list = paginator.page(paginator.num_pages)
    else:
        try:
            context['last_offer'] = [paginator.page(page+1).object_list[0]]
        except (EmptyPage, InvalidPage):
            pass
    
    context['page_object'] = offer_list
    context['position'] = (page - 1) * limit
    if not request.session['is_mobile']:
        context['offer_list'] = ((), (), offer_list.object_list)  # needed for backward compatibility of old templates

    if request.is_ajax() and ('feed' not in request.META['PATH_INFO'] and 'email' not in request.META['PATH_INFO']):
        if request.method == 'POST':
            context['page_class'] = 'paginate-filtered'
        template = 'offers/snippets/bare_offer_list.html'
        html = render_to_string(template, context, RequestContext(request))
        return HttpResponse(simplejson.dumps({'html': html, 'pages': paginator.num_pages}), content_type='text/plain')
    else:
        return render_to_response(template, context, RequestContext(request))


@cache_page
def offer_list_for_category(request, category_slug, limit=10, order_by='-publication_date', template='offers/category.html'):
    limit = getattr(settings, 'CATEGORY_LIMIT', limit)
    try:
        category = Category.on_site.get(slug=category_slug)
    except Category.DoesNotExist:
        raise Http404
    offers = category.offers_published_on_site(active_only=request.GET.get('active_only', True),
                                               is_mobile=request.session['is_mobile'],
                                               extra_categories=request.POST.getlist('extra_cats'))
    page_url = request.build_absolute_uri().replace('/bare/', '/')
    page_url = urlencode(page_url.split('?')[0])
    
    if request.GET.get('metadata_only', None) and request.is_ajax():
        return HttpResponse(simplejson.dumps({'offerMetaData': _build_meta(offers, page_url, request)}), content_type='text/plain')
    elif request.GET.get('sorted-cards', None) and request.user.is_authenticated():
        update_sort_order(category, request)
        return HttpResponse('')
    
    context = {
        'category': category,
        'page_url': page_url,
        'offer_list': offers,
        'breakout': category.get_breakout(),
        'last_offer': [],
        'position': 0,
    }
    Context = None
    try:
        exec('from offers.core.category_context.context%s import Context' % settings.SITE_ID)
    except ImportError:
        pass
    else:
        context.update(Context(request, context).context)

    if category.parent is None and category.children.count():
        context['page_object'] = {'object_list': Offer.sorted_offers.get_all_list(is_mobile=request.session['is_mobile'])}
        if request.session['is_mobile']:
            context['offer_list'] = context['page_object']['object_list']
        else:
            context['offer_list'] = ((), (), context['page_object']['object_list'])  # needed for backward compatibility of old templates
        return render_to_response(template, context, RequestContext(request))
    return _paginate(template, context, request, limit)


@cache_page
def offer_details(request, offer_slug, category_slug, template='offers/offer.html'):
    try:
        category = Category.on_site.get(slug=category_slug)
    except Category.DoesNotExist:
        raise Http404
    
    if request.is_ajax():
        kwargs = {}
        templates = ('template/detailstable.html',)
        page_url = request.META.get('HTTP_REFERER', '').replace('/bare/', '/')
    else:
        page_url = request.build_absolute_uri().replace('/bare/', '/')
        kwargs = {'is_active': True}
        templates = ('offers/details/%s.html' % category_slug,
                     'offers/details/%s.html' % category.get_top_level_parent().slug,
                     template,
                     'offers/offer.html')
    page_url = urlencode(page_url.split('?')[0])
    try:
        offer = Offer.on_site.get(slug=offer_slug, categories=category, **kwargs)
    except Offer.DoesNotExist:
        raise Http404
    else:
        if category != offer.primary_category:
            raise Http404

    if request.GET.get('metadata_only', False):
        return HttpResponse(simplejson.dumps({'offerMetaData': _build_meta([offer], page_url)}),
                            content_type='text/plain')

    return render_to_response(templates, {
        'category': category,
        'offer': offer,
        'page_url': page_url,
        'qna_sections': offer.persiteoption.get_qna_sections(),
        'slider_type': offer.slider,
    }, RequestContext(request))


def offer_search_list(request, search_query=None, template='offers/search_results.html'):
    return render_to_response(template, {}, RequestContext(request))


class OfferOutboundRedirect(TemplateView):
    template_name = 'offers/outbound_message.html'
    
    def get(self, request, *args, **kwargs):
        if 'uid' not in request.GET:
            return HttpResponseRedirect(request.build_absolute_uri() + '&uid=%s' % uuid4())
        Conversion.objects.create(uid=request.GET['uid'], cookies=request.COOKIES, meta=request.META, query=request.GET)
        return super(OfferOutboundRedirect, self).get(request, *args, **kwargs)
    
    def get_context_data(self, *args, **kwargs):
        context = super(OfferOutboundRedirect, self).get_context_data(*args, **kwargs)
        context['offer'] = self.get_offer(kwargs['offer_id'])
        context['outbound_url'] = context['offer'].get_outbound_url(self.request.session['is_mobile'], self.request.GET.get('location', '')=='breakout')
        return context
    
    def get_offer(self, offer_id):
        try:
            return Offer.on_site.get(id=offer_id, is_active=True)
        except Offer.DoesNotExist:
            offer = getattr(generate_post_click(offer_id=offer_id), 'offer', None)
            if offer is None:
                raise Http404
            return offer


def compare_cards(request, category_slug):
    try:
        category = Category.objects.get(slug=category_slug)
    except Category.DoesNotExist:
        slider_type = 0
    else:
        slider_type = category.slider
    try:
        ids = request.GET['cards'].split('-')
    except KeyError:
        ids = request.GET.get('offers', '0').split('-')
    offers = Offer.objects.filter(id__in=ids[:4]) if ids[0] else []
    if request.GET.get('metadata_only', None) and request.is_ajax():
        page_url = urlencode(request.build_absolute_uri().split('?')[0])
        return HttpResponse(simplejson.dumps({'offerMetaData': _build_meta(offers, page_url)}), content_type='text/plain')
    return render_to_response('offers/compare_cards.html', {'offers': offers, 'slider_type': slider_type}, RequestContext(request))
