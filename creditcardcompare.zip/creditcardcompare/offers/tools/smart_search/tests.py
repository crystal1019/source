from django.core.urlresolvers import reverse
from django.test import TestCase

from offers.helpers.lead.models import Lead
from models import Bank, SearchDetail


class TestSmartSearch(TestCase):
    fixtures = ['db.json']

    def setUp(self):
        pass

    def test_show_form(self):
        response = self.client.get(reverse('smart-search'))
        self.failUnlessEqual(response.status_code, 200)

    def test_submit_form(self):
        data = {u'birthyear': [u'1964'],
                u'form-INITIAL_FORMS': [u'0'],
                u'rewards': [u'cash-back-'],
                u'firstname': [u'Maryam'],
                u'frequent_flyer': [u'emirates-skywards-'],
                u'form-MAX_NUM_FORMS': [u''],
                u'workstatus': [u'6'],
                u'state': [u'2'],
                u'form-TOTAL_FORMS': [u'2'],
                u'birthmonth': [u'12'],
                u'cardtype': [u'248'],
                u'birthday': [u'22'],
                u'lastname': [u'Jaffri'],
                u'income': [u'16680'],
                u'balance_transfer': [u'Balance Transfer Rate'],
                u'email': [u'tellnoel+test@gmail.com'],
                u'form-0-bank': [u'151'],
                u'form-0-bank': [u'29']}
        response = self.client.post(reverse('smart-search'), data)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Compare checked")
        self.assertEqual(Lead.objects.count(), 1)
        self.assertEqual(SearchDetail.objects.count(), 1)
        self.assertEqual(Bank.objects.count(), 1)

    def test_click_step1_from_emailed_result_page(self):
        search_details = SearchDetail.objects.all()
        self.assertEqual(search_details.count(), 1)
