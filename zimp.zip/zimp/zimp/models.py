import re
import uuid
from django.db import models, connection
from . import auth


class NullCharField(models.CharField):
    """
    Store null on database char field when value is None.
    """
    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_length', 64)
        super(NullCharField, self).__init__(*args, **kwargs)

    def to_python(self, value):
        return value

    def get_db_prep_value(self, value, connection, prepared=False):
        """
        Return None if field value is an empty string.
        """
        return None if value == "" else value


class UUIDModel(models.Model):
    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if not self.id:
            self.id = str(uuid.uuid4())
        super(UUIDModel, self).save(*args, **kwargs)


class Entity(UUIDModel):
    id = NullCharField(max_length=128, primary_key=True)
    cnpj = NullCharField(max_length=14)
    razao_social = NullCharField(max_length=200)
    nome_fantasia = NullCharField(max_length=200)
    ddd = NullCharField(max_length=2)
    phone = NullCharField(max_length=9)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField()
    balance = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    factor = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    formula = models.TextField()

    class Meta:
        abstract = True

    def __str__(self):
        return '%s - %s' % (self.cnpj, self.razao_social)


class Brand(Entity):

    class Meta:
        db_table = 'brands'
        managed = False


class Mall(Entity):

    class Meta:
        db_table = 'malls'
        managed = False


class Retailer(Entity):
    mall = models.ForeignKey(Mall, null=True)
    brand = models.ForeignKey(Brand, null=False)

    class Meta:
        db_table = 'retailers'
        managed = False


class Promotion(UUIDModel):
    id = NullCharField(max_length=128, primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True)
    name = NullCharField(max_length=100)
    balance = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    owner_type = NullCharField(max_length=1)
    owner_id = NullCharField(max_length=128)
    end_at = models.DateTimeField(blank=True)
    active = models.BooleanField()

    class Meta:
        db_table = 'promotions'
        managed = False


class Card(models.Model):
    code = NullCharField(max_length=20, primary_key=True)
    userinfo = models.ForeignKey('UserInfo')
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    balance = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    class Meta:
        db_table = 'cards'
        managed = False

    def __str__(self):
        return self.code


class Rule(models.Model):
    name = NullCharField(max_length=50)
    opcode = NullCharField(max_length=1)
    model = NullCharField(max_length=50)
    message = models.TextField()

    class Meta:
        db_table = 'rules'
        managed = False


class TransactionManager(models.Manager):
    def register(self, from_id, to_id, value, promotion, type=1, parent=None, terminal=None):
        c = connection.cursor()
        c.callproc('create_transaction', (type, parent, from_id, to_id, value, terminal, promotion))
        r = c.fetchone()
        if r[0] > 0:
            print(r)
            return False, r
        else:
            return True, r


class Transaction(UUIDModel):
    id = NullCharField(max_length=128, primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True)
    parent_transaction = models.ForeignKey('self', db_column='parent', blank=True)
    type = models.PositiveSmallIntegerField(default=1)
    from_type = NullCharField(max_length=1)
    from_rel = NullCharField('RelList', db_column='from_id')
    to_type = NullCharField(max_length=1)
    to_rel = models.ForeignKey('RelList', db_column='to_id')
    value = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    points = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    terminal = NullCharField(max_length=128, blank=True, null=True)
    promotion = models.ForeignKey('Promotion', blank=True)

    objects = TransactionManager()

    class Meta:
        db_table = 'transactions'
        managed = False


class UserInfo(UUIDModel):
    id = NullCharField(max_length=128, primary_key=True)
    name = NullCharField(max_length=100)
    cpf = NullCharField(max_length=11)
    ddd = NullCharField(max_length=2)
    phone = NullCharField(max_length=9)
    mobile = NullCharField(max_length=9)
    gender = NullCharField(max_length=1, choices=(
        ('1', 'Male'),
        ('2', 'Female')),
    )
    birth_date = models.DateField(blank=True)
    street = NullCharField(max_length=200)
    number = NullCharField(max_length=5)
    complement = NullCharField(max_length=200)
    city = NullCharField(max_length=200)
    state = NullCharField(max_length=2)
    country = NullCharField(max_length=3)
    cep = NullCharField(max_length=8)
    balance = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    class Meta:
        db_table = 'userinfo'
        managed = False

    def __str__(self):
        return '%s - %s' % (self.cpf, self.name)

    def save(self, *args, **kwargs):
        self.cpf = re.sub(r'[^\d]+', '', self.cpf)
        super(UserInfo, self).save(*args, **kwargs)


class UserManager(models.Manager):
    def get_by_natural_key(self, *args, **kwargs):
        email = kwargs.get('email') or args[0]
        return self.get(email=email)

    def create_user(self, name, cpf, ddd, phone, mobile, gender, birth_date, number, email, country, complement, city,
                    state, street, cep, password, system, role):
        userinfo = UserInfo.objects.filter(cpf=cpf).only('id')
        if userinfo:
            userinfo = userinfo[0]
        else:
            userinfo = UserInfo.objects.create(
                name=name, cpf=cpf, ddd=ddd, phone=phone, mobile=mobile, gender=gender, birth_date=birth_date,
                street=street, number=number, complement=complement, city=city, state=state, country=country, cep=cep)
        u = self.model(email=email, userinfo=userinfo, system=system, role=role)
        u.set_password(password)
        u.save()


class User(UUIDModel):
    id = NullCharField(max_length=128, primary_key=True)
    email = models.EmailField(unique=True)
    password = NullCharField(max_length=32)
    userinfo = models.ForeignKey('UserInfo')
    system = NullCharField(max_length=1)
    role = NullCharField(max_length=1)
    admin_of = NullCharField(max_length=128)
    created_at = models.DateField(auto_now_add=True)
    active = models.PositiveSmallIntegerField(default=True)
    ### new last_login field
    last_login = models.DateTimeField()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ('password',)

    objects = UserManager()

    class Meta:
        db_table = 'users'
        managed = False

    def __init__(self, *args, **kwargs):
        super(User, self).__init__(*args, **kwargs)
        self.backend = 'django.contrib.auth.backends.ModelBackend'
        self._admin = None

    def __str__(self):
        return self.email

    def check_password(self):
        return True

    def inactive_user(self):
        self.active = 0
        self.save(update_fields=['active'])

    def set_password(self, pwd):
        self.password = auth.create_hash(self.email, pwd)

    def validate_hash(self, pwd):
        return auth.validate_hash(self.email, pwd, self.password)

    def is_authenticated(self):
        return True

    def is_active(self):
        return self.active

    def is_superuser(self):
        return self.active

    def is_staff(self):
        return self.active

    def has_module_perms(self, *args, **kwargs):
        return True

    def has_perm(self, *args, **kwargs):
        return True

    def admin(self):
        if not self._admin and self.admin_of:
            if self.role in [3, 6]:
                self._admin = Retailer.objects.get(id=self.admin_of)
            elif self.role == 5:
                self._admin = Brand.objects.get(id=self.admin_of)
        return self._admin

    @property
    def panel(self):
        if self.role in [3, 6]:
            return 'lojista'
        elif self.role == 5:
            return 'marca'
        else:
            return 'shopping'


class UserRule(models.Model):
    """
    Adicionar chave primária a esta tabela
    """
    role = NullCharField(max_length=1)
    rule = models.ForeignKey('Rule')

    class Meta:
        unique_together = (('role', 'rule'),)
        managed = False


class ValueLog(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    owner_type = NullCharField(max_length=1)
    owner_id = NullCharField(max_length=128)
    # owner = GenericForeignKey
    old_value = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    new_value = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    class Meta:
        db_table = 'value_log'
        managed = False


### INTEGRATION

class Nearbytes(models.Model):
    user = models.ForeignKey('User', primary_key=True)
    near_auth = models.BigIntegerField()

    class Meta:
        db_table = 'nearbytes'
        managed = False


### DATABASE VIEWS

class OwnerTypes(models.Model):
    class Meta:
        db_table = 'vw_owner_types'
        managed = False


class RelList(models.Model):
    id = models.CharField(max_length=128, primary_key=True)
    cpf = models.CharField(max_length=11)
    cnpj = models.CharField(max_length=14)
    name = models.CharField(max_length=200)
    balance = models.DecimalField(max_digits=18, decimal_places=2)
    factor = models.DecimalField(max_digits=18, decimal_places=2)

    class Meta:
        db_table = 'vw_rel_list'
        managed = False


class Transactions(models.Model):
    id = models.CharField(max_length=128, primary_key=True)
    created_at = models.DateTimeField()
    type = models.PositiveSmallIntegerField(choices=(
        (1, 'Acúmulo'),
        (2, 'Resgate'),
    ))
    terminal = models.CharField(max_length=128)
    value = models.DecimalField(max_digits=18, decimal_places=2)
    points = models.DecimalField(max_digits=18, decimal_places=2)
    from_name = models.CharField(max_length=200)
    to_name = models.CharField(max_length=200)
    parent = models.CharField(max_length=200)
    from_id = models.CharField(max_length=128)
    to_id = models.CharField(max_length=128)

    class Meta:
        db_table = 'vw_transactions'
        ordering = ('-created_at',)
        managed = False


# REPORTING

class TransactionType(models.Model):
    checkin = models.SmallIntegerField()
    buy = models.SmallIntegerField()
    share = models.SmallIntegerField()
    rescue = models.SmallIntegerField()
    cancel = models.SmallIntegerField()

    class Meta:
        db_table = 'vw_transactions_type'
        managed = False


class MovimentoGrupoDia(models.Model):
    data = models.DateTimeField(primary_key=True)
    checkin = models.DecimalField(max_digits=18, decimal_places=2)
    compra = models.DecimalField(max_digits=18, decimal_places=2)
    compartilhado = models.DecimalField(max_digits=18, decimal_places=2)
    resgate = models.DecimalField(max_digits=18, decimal_places=2)
    cancelado = models.DecimalField(max_digits=18, decimal_places=2)

    class Meta:
        db_table = 'vw_rep_movimento_grupo_dia'
        managed = False


class Movimento(models.Model):
    id = models.CharField(max_length=128, primary_key=True)
    created_at = models.DateTimeField()
    checkin = models.DecimalField(max_digits=18, decimal_places=2)
    compra = models.DecimalField(max_digits=18, decimal_places=2)
    compartilhado = models.DecimalField(max_digits=18, decimal_places=2)
    resgate = models.DecimalField(max_digits=18, decimal_places=2)
    cancelado = models.DecimalField(max_digits=18, decimal_places=2)

    class Meta:
        db_table = 'vw_rep_movimento'


class MovimentoGrupoMes(models.Model):
    id = models.CharField(max_length=128, primary_key=True)
    mes = models.SmallIntegerField()
    ano = models.SmallIntegerField()
    checkin = models.DecimalField(max_digits=18, decimal_places=2)
    compra = models.DecimalField(max_digits=18, decimal_places=2)
    compartilhado = models.DecimalField(max_digits=18, decimal_places=2)
    resgate = models.DecimalField(max_digits=18, decimal_places=2)
    cancelado = models.DecimalField(max_digits=18, decimal_places=2)

    class Meta:
        db_table = 'vw_rep_movimento_grupo_mes'

