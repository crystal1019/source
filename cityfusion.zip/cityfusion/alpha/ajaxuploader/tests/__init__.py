from ajaxuploader.tests.default_storage_backend import *
