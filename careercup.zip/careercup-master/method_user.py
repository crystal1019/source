from google.appengine.api import users

from datetime import datetime

import objects

import method_db
import method_cache
import method_question

import logging

cache_key_favorite_questions = 'user-favorite-questions'
cache_key_favorite_forums = 'user-favorite-forums'
cache_key_favorite_users = 'user-favorite-users'
cache_key_favorite_attributes = 'user-favorite-attributes'
cache_key_favorite_forum_all = 'user-favorite-forum-all'
cache_key_reputation = 'user-reputation'
cache_key_user_profile = 'user-profile'
cache_key_user_page_body = 'user-page-body'
cache_key_user_page_title = 'user-page-title'

comments_per_page = 50
vote_multiplier = 10
favorite_multiplier = 10
new_comment_multiplier = 0

def getUserWithId(userid):
	if userid:
		user = objects.UserInfo.query(objects.UserInfo.uid == userid).get()
		return method_db.ensureVisible(user)
	else:
		return None
	
def getQuestionsByUser(author_id):
	# Get questions.
	questions = objects.Question.query(objects.Question.author_id == author_id, objects.Question.visible == True).order(-objects.Question.date)
	question_list = method_question.mergeQuestionsWithAttributes(questions)		
	return question_list
	
def getForumsByUser(author_id):
	forum_list = objects.ForumPost.query(objects.ForumPost.author_id == author_id, objects.ForumPost.visible == True).order(-objects.ForumPost.date)	
	return forum_list
	
def getCommentsByUser(author_id, page):
	offset = comments_per_page * (page - 1)
	comments = objects.Comment.query(objects.Comment.author_id == author_id, objects.Comment.visible == True).order(-objects.Comment.date).fetch(comments_per_page, offset=offset)
	return comments	
	
def getCommentCountByUser(author_id):
	max_retrieved = 1000
	offset = 0
	comments = objects.Comment.query(objects.Comment.author_id == author_id, objects.Comment.visible == True).fetch(max_retrieved, offset=offset)
	comments_full = comments
	while len(comments) == max_retrieved:	
		offset = offset + max_retrieved
		comments = objects.Comment.query(objects.Comment.author_id == author_id, objects.Comment.visible == True).fetch(max_retrieved, offset=offset)
		comments_full.extend(comments) 				
	return len(comments_full)		
	
def clearCache(user):
	if user.user:
		key = user.user.email()
	else:
		key = user.name
	method_cache.clearObjectForTypeAndId('user', key)
	method_cache.clearObjectForTypeAndId('user_favorites_html', key)
	method_cache.clearObjectForTypeAndId(cache_key_favorite_questions, key)
	method_cache.clearObjectForTypeAndId(cache_key_favorite_users, key)	
	method_cache.clearObjectForTypeAndId(cache_key_favorite_forums, key)
	method_cache.clearObjectForTypeAndId(cache_key_favorite_attributes, key)
	method_cache.clearObjectForTypeAndId(cache_key_favorite_forum_all, key)
	method_cache.clearObjectForTypeAndId(cache_key_user_profile, str(user.uid))
	method_cache.clearObjectForTypeAndId(cache_key_user_page_body, str(user.uid))
	method_cache.clearObjectForTypeAndId(cache_key_user_page_title, str(user.uid))
	method_cache.clearObjectForTypeAndId('user-email-on-new-question', None)
	
	
def userCanEdit(obj):
	if userIsAdmin():
		return True
	user = getLoggedInUser()
	if user and user.uid == obj.author_id:
		return True
	return False
	
def getUsersToEmailOnNewQuestion():
	user_list = None #method_cache.getObjectForTypeAndKey('user-email-on-new-question', None)
	if not user_list:
		users = objects.UserInfo.query(objects.UserInfo.email_on_new_question == True)
		user_list = []
		for user in users:
			user_list.append(user)
		#method_cache.getObjectForTypeAndKey('email_on_new_question', user_list)
	return user_list	
	
def cacheLoggedInUser(user):
	if user and user.uid:
		user_str = user.name + '#' + str(user.uid) + '#' + user.image + '#' + str(user.visible) + '#' + str(user.admin) + '#' + user.user.email() + '#' + str(user.reputation)
		method_cache.setObjectForTypeAndKey('user', user.user.email(), user_str)

def getFavoriteForumsForUser(user):
	return getFavoriteForumsForEmailAndId(user['email'], user['uid'])

def getFavoriteForumsForEmailAndId(email, uid):
	favorites = method_cache.getObjectForTypeAndKey(cache_key_favorite_forums, email)
	if favorites == None:
		user_info = getUserWithId(uid)
		if not user_info:
			return None
		if user_info.favorite_forums:
			favs = []
			for f in user_info.favorite_forums:
				favs.append(int(f))
			method_cache.setObjectForTypeAndKey(cache_key_favorite_forums, email, favs)
		else:
			favs = []
			method_cache.setObjectForTypeAndKey(cache_key_favorite_forums, email, '')
		return favs
	elif favorites == '':
		return None
	else:
		return favorites
		
def getFavoriteUsersForUser(user):
	return getFavoriteUsersForEmailAndId(user['email'], user['uid'])

def getFavoriteUsersForEmailAndId(email, uid):
	favorites = method_cache.getObjectForTypeAndKey(cache_key_favorite_users, email)
	if favorites == None:
		user_info = getUserWithId(uid)
		if not user_info:
			return None
		if user_info.favorite_users:
			favs = []
			for f in user_info.favorite_users:
				favs.append(int(f))
			method_cache.setObjectForTypeAndKey(cache_key_favorite_users, email, favs)
		else:
			favs = []
			method_cache.setObjectForTypeAndKey(cache_key_favorite_users, email, '')
		return favs
	elif favorites == '':
		return None
	else:
		return favorites		

def getFavoritesForUser(user):
	return getFavoritesForEmailAndId(user['email'], user['uid'])

def getFavoritesForEmailAndId(email, uid):
	favorites = method_cache.getObjectForTypeAndKey(cache_key_favorite_questions, email)
	if favorites == None:
		user_info = getUserWithId(uid)
		if not user_info:
			return None
		if user_info.favorites:
			favs = []
			for f in user_info.favorites:
				favs.append(int(f))
			method_cache.setObjectForTypeAndKey(cache_key_favorite_questions, email, favs)
		else:
			favs = []
			method_cache.setObjectForTypeAndKey(cache_key_favorite_questions, email, '')
		return favs
	elif favorites == '':
		return None
	else:
		return favorites

def getFavoriteForumAllForEmailAndId(email, uid):
	favorite = method_cache.getObjectForTypeAndKey(cache_key_favorite_forum_all, email)
	if favorite == None:
		user_info = getUserWithId(uid)
		if not user_info:
			return None
		if user_info:
			method_cache.setObjectForTypeAndKey(cache_key_favorite_forum_all, email, user_info.favorite_forum_all)
			favorite = user_info.favorite_forum_all
		else:
			return False
	else:
		return favorite

def getFavoriteForumAllForUser(user):
	return getFavoriteForumAllForEmailAndId(user['email'], user['uid'])
	
def getFavoriteAttributesForUser(user):
	return getFavoriteAttributesForEmailAndId(user['email'], user['uid'])

def getFavoriteAttributesForEmailAndId(email, uid):
	favorites = method_cache.getObjectForTypeAndKey(cache_key_favorite_attributes, email)
	if favorites == None:
		user_info = getUserWithId(uid)
		if not user_info:
			return None
		if user_info.favorite_attributes:
			favs = []
			for f in user_info.favorite_attributes:
				favs.append(f.encode('utf-8'))
			method_cache.setObjectForTypeAndKey(cache_key_favorite_attributes, email, favs)
		else:
			favs = []
			method_cache.setObjectForTypeAndKey(cache_key_favorite_attributes, email, '')
		return favs
	elif favorites == '':
		return None
	else:
		return favorites	

def getFollowers(uid):
	followers = objects.UserInfo.query(objects.UserInfo.favorite_users == uid).fetch()
	return followers

def getUsersInList(lst):
	users = []
	if lst == None:
		return []
	for fav in lst:
		f = getUserWithId(fav)
		if f is not None:
			users.append(f)
	return users
	
def refreshUserReputation(userinfo):
	userid = userinfo.uid
	
	reputation = 0.0
	
	# get impact from comments	
	comments = objects.Comment.query(objects.Comment.author_id == userid, objects.Comment.visible == True, objects.Comment.votes_count > 0)
	for comment in comments:
		reputation = reputation + computeScoreImpactOfVote(len(comment.votes_up_people), len(comment.votes_down_people))
		
	if new_comment_multiplier > 0:
		num_comments = objects.Comment.query(objects.Comment.author_id == userid, objects.Comment.visible == True).count()
		reputation = reputation + num_comments * new_comment_multiplier
		
	questions = objects.Question.query(objects.Question.author_id == userid, objects.Comment.visible == True, objects.Comment.votes_count > 0)
	for question in questions:
		reputation = reputation + computeScoreImpactOfVote(len(question.votes_up_people), len(question.votes_down_people))
		
	if reputation != userinfo.reputation:
		userinfo.reputation = reputation
		method_db.putObject(userinfo)
	
	return reputation
	

def computeScoreImpactOfVote(votes_up, votes_down):
	return float(vote_multiplier * (float(votes_up) - float(votes_down) / 2))

def incrementReputation(userinfo, delta):
	userinfo.reputation = userinfo.reputation + delta
	method_db.putObject(userinfo)

def retrieveUser(user):
	user_str = method_cache.getObjectForTypeAndKey('user', user.email())
	if user_str and user_str.count('#') >= 5: # if the user is cached, retrieve from cache
		parts = user_str.split('#')
		user_info = {}
		user_info['name'] = parts[0]
		user_info['uid'] = int(parts[1])
		user_info['image'] = parts[2]
		user_info['visible'] = (parts[3] == "True")
		user_info['admin'] = (parts[4] == "True")
		user_info['reputation'] = int(float(parts[6]))
		user_info['email'] = user.email()
		return user_info
	else: # look it up in the database
		user_info = objects.UserInfo.query(objects.UserInfo.user == user).get()
		if not user_info: # if it's not there, add it
			user_info = objects.UserInfo()
			user_info.name = user.nickname()
			user_info.user = user
			method_db.putObject(user_info)
		#cacheLoggedInUser(user_info) # save to the cache
		ui = {}
		ui['name'] = user_info.name
		ui['uid'] = user_info.uid
		ui['image'] = user_info.image
		ui['visible'] = user_info.visible
		ui['admin'] = user_info.admin
		ui['reputation'] = user_info.reputation
		ui['email'] = user.email()		
		#return retrieveUser(user) # look it up in cache
		return ui

def getLoggedInUserFromCache():	
	user = users.get_current_user()
	if user:
		return retrieveUser(user)
	else:
		return None
	
def getLoggedInUser():
	user = users.get_current_user()
	userinfo = None
	if user:
		userinfo = objects.UserInfo.query(objects.UserInfo.user == user).get()
		if not userinfo:
			userinfo = objects.UserInfo()
			userinfo.name = user.nickname()
			userinfo.user = user
			method_db.putObject(userinfo)
			return userinfo					
	return userinfo
		
def userIsAdmin(): 
	if users.is_current_user_admin():
		return True
	userinfo = getLoggedInUserFromCache()
	if userinfo and userinfo['admin']:
		return True
	return False			 		 

def subscribe(user, item):
	item = subscribeWithDelay(user, item)
	method_db.putObject(item)
	return item
	
def subscribeWithDelay(user, item):
	subscriptions = item.subscriptions		
	if subscriptions is None:
		subscriptions = []
	email = user.user.email()	
	if email in subscriptions:
		return item
	subscriptions.append(user.user.email())
	subscriptions_users = item.subscriptions_users
	if subscriptions_users is None:
		subscriptions_users = []					
	subscriptions_users.append(user.uid)
	item.subscriptions = subscriptions
	item.subscriptions_users = subscriptions_users
	if item.last_comment is None:
		item.last_comment = datetime.now()
	return item	
	
def unsubscribe(user, item, s):
	subscriptions = item.subscriptions
	if subscriptions is None:
		subscriptions = []
	while user.user.email() in subscriptions:
		subscriptions.remove(user.user.email())
	subscriptions_users = item.subscriptions_users
	if subscriptions_users is None:
		subscriptions_users = []
	if user.uid in subscriptions_users:							
		subscriptions_users.remove(user.uid)
		item.subscriptions = subscriptions
		item.subscriptions_users = subscriptions_users
		if item.last_comment is None:
			item.last_comment = datetime.now()		
		method_db.putObject(item)