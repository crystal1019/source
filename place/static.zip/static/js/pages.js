function get_topics(lat, lng, callback, limit, only_featured){
    var params = {
        'lat': lat,
        'lng': lng
    };
    if (limit) {
        params['limit'] = limit;
    }
    if (only_featured) {
        params['only_featured'] = only_featured;
    }

    $.ajax({
        url: '/topics/topics_by_location/',
        type: 'get',
        data: params,
        success: function(obj) {
            if (callback){
                callback(obj);
            }
        }
    });
}

/**
 * HOME PAGE
 */
function home_init(options) {
    var lat = options.location.latitude;
    var lng = options.location.longitude;
    load_home_map(obj.topics, {
        "center": new google.maps.LatLng(lat, lng)
    });
}

/* END HOME PAGE */


//About page

/* INVITE PAGE */
function invite_init(options) {
    cloudsponge.init({
        domain_key    : cs_domain_key,
        cache_contacts: true,
        textarea_id   : 'id_emailList',
        include       : ['email'],
        skipSourceMenu: true,
        ignoreMultipleEmails: true
    });
    $('.invite-option').click(function() {
        return cloudsponge.launch($(this).data('addressbook'));
    });


}
/* END INVITE PAGE */