from django.http import Http404
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views.generic import TemplateView
from offers.core.models import Offer


class TestTemplateView(TemplateView):
    def get_template_names(self):
        if self.request.user.is_authenticated():
            return '%s.html' % self.kwargs['template_name']
        else:
            raise Http404


class TestMetaTagView(TemplateView):
    template_name = 'test/test_meta_tags.html'
    
    def get_context_data(self):
        if not self.request.user.is_authenticated():
            raise Http404
        return {'offers': Offer.objects.all(),}
        
    def post(self, request):
        if not request.user.is_authenticated():
            raise Http404
        context = self.get_context_data()
        try:
            context['offer_instance'] = context['offers'].get(id=self.request.POST.get('offer_id', '0'))
        except Offer.DoesNotExist:
            pass
        context['content'] = self.request.POST.get('content', '')
        return render_to_response(self.template_name, context, RequestContext(request))
