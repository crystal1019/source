from django.conf.urls import patterns, include, url
from django.contrib import admin

urlpatterns = patterns('',
    # Examples:
    url(r'^$', 'app.views.home', name='home'),
    # url(r'^schools/builder/', 'app.views.builder', name='builder'),
    url(r'^schools/', include('app.schools.urls')),
    url(r'^publishers/', 'app.views.publishers', name='publishers'),
    url(r'^members/', 'app.views.members', name='members'),
    url(r'^features/', 'app.views.features', name='features'),
    # url(r'^schools/browse/', 'app.views.browse', name='browse'),
    url(r'^registration/', 'app.views.registration', name='registration'),
    # url(r'^blog/', include('blog.urls')),
    url(r'^captcha/', include('captcha.urls')),
    url(r'^admin/', include(admin.site.urls)),
)
