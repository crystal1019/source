import objects
import masterpage

import method_db
import method_question
import method_forum
import method_user
import method_salary
import method_comment
	
class ReviewFlagged(masterpage.MasterPage):				  
		
	def confirmFlaggedQuestion(self, qid, response):
		question = method_question.getQuestionWithId(qid, True)
		question.visible = response
		question.under_review = False
		if response:
			question.flag_count = 0
		method_db.putObject(question)
		method_question.clearQuestionCache(question, True)
			
	def confirmFlaggedQuestions(self):
		index = 1						
		# Review Flagged Questions	
		while index < 100:
			question_text = self.request.get('question' + str(index))
			if not question_text:
				break
			parts = question_text.split('-')
			action = parts[0]
			id = int(parts[1])
			if action == 'yes':
				self.confirmFlaggedQuestion(id, True)
			elif action == 'no':
				self.confirmFlaggedQuestion(id, False)
			index = index + 1
		method_question.clearFlaggedCountCache()
		
	def confirmFlaggedForum(self, fid, response):
		forum = method_forum.getForumPostWithId(fid, True)
		forum.visible = response
		forum.under_review = False
		if response:
			method_forum.undeleteForumPost(forum)
		else:
			method_forum.deleteForumPost(forum)
		method_db.putObject(forum)
		method_forum.clearCache(forum)
			
	def confirmFlaggedForums(self):
		index = 1						
		# Review Flagged Questions	
		while index < 100:
			forum_text = self.request.get('forum' + str(index))
			if not forum_text:
				break
			parts = forum_text.split('-')
			action = parts[0]
			id = int(parts[1])
			if action == 'yes':
				self.confirmFlaggedForum(id, True)
			elif action == 'no':
				self.confirmFlaggedForum(id, False)
			index = index + 1
		method_forum.clearFlaggedCountCache()		
		
	def confirmFlaggedComment(self, cid, response):
		comment = method_comment.getCommentWithId(cid, True)
		if not comment:
			return
		comment.under_review = False
		if response:
			method_comment.undeleteComment(comment)
		else:
			method_comment.deleteComment(comment)			
		method_db.putObject(comment)		
	
	def confirmFlaggedComments(self):
		index = 1						
		# Review Flagged Comments	
		while index < 100:
			comment_text = self.request.get('comment' + str(index))
			if not comment_text:
				break
			parts = comment_text.split('-')
			action = parts[0]
			id = int(parts[1])
			if action == 'yes':
				self.confirmFlaggedComment(id, True)
			elif action == 'no':
				self.confirmFlaggedComment(id, False)
			index = index + 1
		method_comment.clearFlaggedCommentCountCache()	
		
	def confirmFlaggedSalary(self, sid, response):
		salary = method_salary.getSalaryWithId(sid, True)
		salary.under_review = False
		if response:
			method_salary.undeleteSalary(salary)
		else:
			method_salary.deleteSalary(salary)			
		method_db.putObject(salary)		
	
	def confirmFlaggedSalaries(self):
		index = 1						
		# Review Flagged Salarys	
		while index < 100:
			salary_text = self.request.get('salary' + str(index))
			if not salary_text:
				break
			parts = salary_text.split('-')
			action = parts[0]
			id = int(parts[1])
			if action == 'yes':
				self.confirmFlaggedSalary(id, True)
			elif action == 'no':
				self.confirmFlaggedSalary(id, False)
			index = index + 1
		method_salary.clearFlaggedSalaryCountCache()	
		
				
		
	def post(self):
		if not method_user.userIsAdmin():
			self.redirectToLogin()
			return

		self.confirmFlaggedQuestions()
		self.confirmFlaggedComments()
		self.confirmFlaggedSalaries()
		self.confirmFlaggedForums()
		
		self.redirect('/reviewflagged')

	def get(self):
		if not method_user.userIsAdmin():
			self.redirectToLogin()
			return	  
		flagged_questions = objects.Question.query(objects.Question.under_review == True)
		flagged_comments = objects.Comment.query(objects.Comment.under_review == True)
		flagged_salaries = objects.SalaryInfo.query(objects.SalaryInfo.under_review == True)
		flagged_forums = objects.ForumPost.query(objects.ForumPost.under_review == True)
		template_values = {'questions': flagged_questions, 'comments': flagged_comments, 'salaries': flagged_salaries, 'forums': flagged_forums}
		self.pushPage(template_values, 'Review Flagged Questions', 'html/reviewflagged.html')   
		
