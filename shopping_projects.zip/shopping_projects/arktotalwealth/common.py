from arktotalwealth.mediacenter.models import *
from django.template import loader, Context
from django.core.mail import EmailMultiAlternatives
from xml.dom.minidom import parseString
import base64
import httplib2
from arktotalwealth.website.models import *
from arktotalwealth.service.models import *
from arktotalwealth.overview.models import *
from arktotalwealth.team.models import *

def getLatestBlog():
	latest_article = BlogPost.objects.filter(active=True)
	latest_news = BlogPost.objects.filter(active=True)
	return latest_news, latest_article

def getTopNav(nav):
	topnav = ''
	if nav == 'overview':
		path = OverviewPage.objects.filter(parent__isnull=True, active=True)
		path = path[0] if path else ''
		if path:
			topnav = OverviewPage.objects.filter(parent=path, active=True)
	elif nav == 'service':
		path = ServicePage.objects.filter(parent__isnull=True, active=True)
		path = path[0] if path else ''
		if path:
			topnav = ServicePage.objects.filter(parent=path, active=True)		
	
	elif nav == 'team':
		path = TeamPage.objects.filter(parent__isnull=True, active=True)
		path = path[0] if path else ''
		if path:
			topnav = TeamPage.objects.filter(parent=path, active=True)		
			
	return topnav
	
	
def commondict(d,request=None):
	
	latest_news, latest_article = getLatestBlog()
	
	try:
		defaultmeta = MiscPage.objects.get(path='index')
	except:
		defaultmeta = ''
		
	overviewnav = getTopNav('overview')
	servicenav = getTopNav('service')
	teamnav = getTopNav('team')
	
	try:
		article_url = BlogCategory.objects.filter(is_article=True)
		article_url = article_url[0].get_absolute_url()
	except:
		article_url = '/mediacentre/'
	
	data = {
			'defaultmeta':defaultmeta,
		
			'latest_news':latest_news,
			'latest_article':latest_article,
			'article_url':article_url,
			
			'overviewnav':overviewnav,
			'servicenav':servicenav,
			'teamnav':teamnav,
		
			'blognavs': BlogCategory.objects.filter(is_active=True).order_by('-priority'),
		
		}
	
	data.update(d);
	
	return data

def sendEmail(e_from,e_to,title,template, context=None):
	t = loader.get_template(template)
	c = Context({'context':context})
	content = t.render(c)
	email = EmailMultiAlternatives(title , content, e_from, e_to)
	email.attach_alternative(content, "text/html")
	email.send()
	

def api_emarket(xmlstring, email):
	#membership id should be 132
	
	login_id = "GRz9K2YffQTf"
	key = "PNVew5O6wxZT1du3"
	base64string = base64.encodestring("%s:%s" %(login_id, key))
	
	http = httplib2.Http()
	url = "https://app.streamsend.com/audiences/2/people.xml"
	headers = {"Authorization":"Basic %s" % base64string,"Content-Type":"application/xml"}
	try:
	    response, content = http.request(url, 'POST', headers=headers, body=xmlstring)
	    if(response.has_key('location')):
	        location = response['location']
	        url1 = location + '/memberships'
	        listxml = "<membership><list-id>132</list-id></membership>"
	        response, content = http.request(url1, 'POST', headers=headers, body=listxml)
	        
	    else:
	        url2 = "https://app.streamsend.com/audiences/2/people?email_address="+email
	        response, content = http.request(url2, 'GET', headers=headers)
	        dom = parseString(content)
	        if(dom.getElementsByTagName('id')):
	            theid = dom.getElementsByTagName('id')[0].firstChild.nodeValue
	            url3 = "https://app.streamsend.com/audiences/2/people/%s/memberships" %theid
	            listxml = "<membership><list-id>132</list-id></membership>"
	            response, content = http.request(url3, 'POST', headers=headers, body=listxml)
	except:
	    pass
