class DateFilterMiddleware(object):
    def process_request(self, request):
        if 'date__lte' in request.GET:
            get_vars = request.GET.copy()
            end_date = get_vars.pop('date__lte')[0]
            get_vars.update({'date__lte': end_date.split(' ')[0] + " 23:59:59"})
            setattr(request, 'GET', get_vars)