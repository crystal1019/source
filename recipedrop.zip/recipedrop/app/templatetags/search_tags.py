from django import template

from app.models import Recipe, Profile, BlogPost

register = template.Library()

def model_objects(model):
    def objs(value):
        def is_mdl(result):
            return isinstance(result.object, model)

        def to_obj(result):
            return result.object

        return map(to_obj, filter(is_mdl, value))

    return objs

register.filter('profile_objects', model_objects(Profile))
register.filter('recipe_objects', model_objects(Recipe))
register.filter('blogpost_objects', model_objects(BlogPost))

def to_users(value):
    return map(lambda p: p.user, value)

register.filter('to_users', to_users)
