import method_question
import method_cache

from google.appengine.ext import webapp

class AttributeImage (webapp.RequestHandler):
	def get(self):
		url = self.request.url
		url = url.replace('%3F', '?')
		url = url.replace('%3D', '=')
		logging.info(url)
		pid = method_url.getStringParamFromUrl(url, 'pid')
		logging.info(pid)
		self.redirect('/attributeimages/' + pid + '.png')