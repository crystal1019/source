import re
import json as simplejson
from django.db.models import Q
from django.conf import settings
from django.http import HttpResponse, Http404
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.template.defaultfilters import urlencode
from django.views.generic import View
from offers.helpers.metafield import get_rewards_points_ratio
from offers.core.models import Offer, BalanceTransfer
from offers.core.views import _build_meta
from offers.utils import f
from helpers import extract_rates, get_better_cards, save_user_data, xor_crypt, Card
from models import SwitchedUser, UserData
from forms import BetterCardForm, CardForm

unknown_card = 'MY CARD IS NOT LISTED'


#===============================================================================
# Ajax requests
#===============================================================================

class CalculateSavings(View):
    def post(self, request, *args, **kwargs):
        self.user_data = {
            'Balance Transfer': request.POST.get('slide1'),
            'Purchase Rate': request.POST.get('slide2'),
            'Annual Fee': request.POST.get('slide3'),
            'Monthly Spend': request.POST.get('slide4'),
            'One-Time Purchase': request.POST.get('slide5'),
        }
        offers = Offer.objects.filter(id__in=request.POST.getlist('offers[]'))
        if self.user_data['Monthly Spend'] is not None:
            data = self.get_points(offers)
        else:
            data = self.get_savings(offers)
        return HttpResponse(simplejson.dumps(data), content_type='text/plain')
    
    def get_savings(self, offers):
        reference_card = Card(
                    f(self.user_data['Purchase Rate'], 100.0), # default a very high value
                    f(self.user_data['Annual Fee'], 100.0), # default a very high value
                    0, 0, # transfer rate has no effect on existing card
                    0, 0, # intro rate on user card doesnt matter
                    transfered=f(self.user_data['Balance Transfer']),
                    monthly_expense=0,
                    onetime_expense=f(self.user_data['One-Time Purchase']),)
        savings = {}
        for offer in offers:
            saved = offer.savings(reference_card, f(self.user_data['Balance Transfer']), f(self.user_data['One-Time Purchase']))
            savings['savings%s' % offer.id] = '$%s' % format(saved, ',.0f')
        return savings

    def get_points(self, offers):
        monthly_spend = f(self.user_data['Monthly Spend'])
        points = {}
        
        for offer in offers:
            # get earning rates
            re_mcvisa = self.get_meta_value(offer, 'Reward Points (MC/VISA)')
            re_amex = self.get_meta_value(offer, 'Reward Points (AmEx)')
            ff_mcvisa = self.get_meta_value(offer, 'Frequent Flyer Points (MC/VISA)')
            ff_amex = self.get_meta_value(offer, 'Frequent Flyer Points (AmEx)')
            
            cap_mcvisa = self.get_meta_value(offer, 'Points Cap Per Month (MC/VISA)') or ''
            cap_amex = self.get_meta_value(offer, 'Points Cap Per Month (AmEx)') or ''
            if re_mcvisa is not None and re_amex is not None:
                pts = self.calc_pts(re_mcvisa, monthly_spend/2, cap_mcvisa) + self.calc_pts(re_amex, monthly_spend/2, cap_amex)
            elif re_mcvisa is not None or re_amex is not None:
                pts = self.calc_pts(re_mcvisa or re_amex, monthly_spend, cap_amex if re_amex else cap_mcvisa)
            elif ff_mcvisa is not None and ff_amex is not None:
                pts = self.calc_pts(ff_mcvisa, monthly_spend/2, cap_mcvisa) + self.calc_pts(ff_amex, monthly_spend/2, cap_amex)
            elif ff_mcvisa is not None or ff_amex is not None:
                pts = self.calc_pts(ff_mcvisa or ff_amex, monthly_spend, cap_amex if ff_amex else cap_mcvisa)
            else:
                pts = 0
            points['savings%s' % offer.id] = '%s pts' % format(pts * 12 + self.get_bonus(offer), ',.0f')
        return points
    
    def get_meta_value(self, offer, key):
        meta = offer.metafield(key)
        if meta is not None and meta.value not in ('-', '', None):
            return meta.value
    
    def get_bonus(self, offer):
        bonus = self.get_meta_value(offer, 'Sign Up Bonus')
        if bonus is not None and re.sub('[^\d.]', '', bonus):
            try:
                return int(re.sub(',', '', re.match('(Up to )?([\d,]+).*', bonus).groups(0)[1]))
            except (AttributeError, ValueError), e:
                if settings.DEBUG:
                    print e
        return 0
    
    def calc_pts(self, meta_value, monthly_spent, monthly_cap):
        ''' Calculate monthly points'''
        ratio = get_rewards_points_ratio(meta_value)
        if ratio is None:
            return 0
        pts = monthly_spent * f(ratio)
        return min(int(re.sub('[^\d.]', '', monthly_cap) or pts), pts)
    
    def get_category_slug(self):
        try:
            return re.search('http://.*/([^/]*).php', self.request.META.get('HTTP_REFERER', '')).groups()[0]
        except IndexError:
            raise Http404

def record_switcher(request):
    '''Stores a record when apply button is clicked from the result page
    '''
    if not request.is_ajax():
        raise Http404
    switcher = SwitchedUser.objects.get_or_create(ip_address=request.META['REMOTE_ADDR'],
                                                  email=request.GET['email'])[0]
    switcher.credit_card = Offer.objects.get(id=request.GET['card'])
    switcher.new_card = Offer.objects.get(id=request.GET['new'])
    switcher.saved = request.GET['saved']
    switcher.save()
    return HttpResponse('')

def suggest_cards(request):
    '''Lists offers with a dropdown from page 1
    '''
    if not request.is_ajax():
        raise Http404
    offers = Offer.objects.filter(categories__name='Credit Cards').order_by('title')
    term = request.GET.get('term',unknown_card).replace('Credit','').replace('credit','').replace('Card','').replace('card','')
    filter1 = filter2 = Q(title__icontains=term.split(' ')[0]) # just to simplify the code
    for word in term.split(' '):
        filter1 &= Q(title__icontains=word)
        filter2 |= Q(title__icontains=word)
    
    cards = offers.filter(filter1)
    if not cards:
        offers = offers.filter(filter2)
        data = [{'label':offer.title, 'image':offer.image.name} for offer in offers[:15]]
        dummy_image = Offer.objects.get(title=unknown_card).image
        data.append({'label':unknown_card, 'image':dummy_image.name})
    else:
        data = [{'label':offer.title, 'image':offer.image.name} for offer in cards[:15]]
    return HttpResponse(simplejson.dumps(data), content_type='text/plain')

def get_meta(request):
    '''Fetches offer data for use in lightbox
    '''
    if not request.is_ajax():
        raise Http404
    offer_ids = request.GET['offers'] or '0'
    offers = Offer.on_site.filter(id__in=offer_ids.split('-'))
    page_url = request.META['HTTP_REFERER']
    page_url = page_url.split('?')[0]
    return HttpResponse(simplejson.dumps({
                            'offerMetaData': _build_meta(offers, urlencode(page_url)),
                        }), 
                        content_type='text/plain')

#===============================================================================
# Normal requests
#===============================================================================

def index(request):
    count = SwitchedUser.objects.count() or 1
    total = SwitchedUser.raw_sql.total_saved() or 0
    context = {'average':total/count}
    if request.GET.get('title', None):
        context['title'] = request.GET['title']
    return render_to_response('beatcard/index.html', context, RequestContext(request))

def compare_start(request):
    if 'details' in request.GET:
        ''' handles request when the "adjust your settings" is clicked from the results page (or from the email). carries form
        data back to adjust settings page
        '''
        try:
            data = UserData.objects.get(pk=xor_crypt(request.GET['details']) or 0)
        except UserData.DoesNotExist:
            return index(request)
        else:
            form = BetterCardForm(initial=data.get_as_dict(), auto_id=True)
    elif 'title' in request.GET:
        '''handles form submission from first page
        '''
        card_form = CardForm({'title':request.GET['title']})
        if card_form.is_valid():
            form = BetterCardForm(initial={'title': request.GET['title']},auto_id=True)
        else:
            return index(request)
    else: # show first page
        return index(request)
    
    context = {'form':form, 'not_found':request.GET.get('title', lambda: data.title.title)==unknown_card}
    return render_to_response('beatcard/form.html', context, RequestContext(request))


def compare_result(request):
    try:
        data = UserData.objects.get(pk=xor_crypt(request.GET['details']))
    except (KeyError, UserData.DoesNotExist):
        form = BetterCardForm(request.POST, auto_id=True)
        if not form.is_valid() and request.POST.get('title', ''):
            return render_to_response('beatcard/form.html', {'form':form, 'not_found':request.POST['title']==unknown_card}, RequestContext(request))
        if not form.is_valid() and not request.POST.get('title', ''):
            return index(request)
        cdata = form.cleaned_data
        if request.POST.get('email',None).strip():
            data = save_user_data(cdata, request)
        else:
            data = UserData(id='')
    else:
        cdata = data.get_as_dict()
    try:
        user_card = Offer.objects.get(title=cdata['title'])
    except Offer.MultipleObjectsReturned:
        user_card = Offer.objects.filter(title=cdata['title']).order_by('id')[0]    
    try:
        if user_card.title == unknown_card:
            for k,v in {'Annual Fee':'annual','Purchase Rate':'purchase'}.iteritems():
                meta = user_card.meta_instances.get(meta_field__key=k)
                meta.value = cdata[v]
                meta.save(new_revision=False)
    except:
        raise Http404
    all_meta = extract_rates(user_card, f(cdata['transfered']))
    card = Card(all_meta['interest_rate'], 
               all_meta['annual_fee'], 
               0, 0, # transfer rate has no effect on existing card
               0, 0, # intro rate on user card doesnt matter
               monthly_expense=f(cdata['monthly']), 
               repay_rate=f(cdata['repayment']),
               transfered=f(cdata['transfered']),)
    user_card_total = card.get_total_expense()
    user_card.total = user_card_total
    
    q_filter = Q(until=None) | Q(until__gt=cdata['card_ownership_duration'])
    excluded_banks = BalanceTransfer.objects.filter(q_filter, no_transfer_from=user_card.issuer_category).values('no_transfer_to')
    better_cards = get_better_cards(user_card_total, cdata, excluded_issuers=excluded_banks)        
    
    if request.GET.get('details', None):
        url = request.build_absolute_uri().replace('result/','details/')
    else:
        url = request.build_absolute_uri().replace('result/','details/?details=') + xor_crypt(data.id)
    context = {'user_card':user_card, 'offers':better_cards, 'email':request.POST.get('email',None), 'spend':cdata['monthly'],
               'repayment':cdata['repayment'], 'transfered':cdata['transfered'],
               'settings_url':url}
            
    return render_to_response('beatcard/result.html', context, RequestContext(request))
