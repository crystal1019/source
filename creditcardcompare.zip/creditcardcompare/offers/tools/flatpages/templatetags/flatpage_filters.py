"""This module is entended to replace learning_tags.py"""

from datetime import date
from django.conf import settings
from django.template import Library
from django import template

register = Library()

from django.contrib.flatpages.models import FlatPage
from offers.core.templatetags import varname_re

@register.filter
def previous_month(content):
    d = date.today()
    d = date(d.year, d.month-1, d.day)
    return d.strftime("%B")

def get_flatpages(url):
    return FlatPage.objects.filter(url__startswith=url, sites=settings.SITE_ID
                          ).exclude(url=url
                          ).order_by('title')

@register.filter
def split(content, part):
    mid = content.find('</p>')
    
    if part == '1':
        return content[:mid]
    else:
        return content[mid:]
    
@register.filter
def part(content, part):
    mid = content.find('<br />') if content.find('<br />')!=-1 else 0
    
    if part == '1':
        return content[:mid]
    else:
        return content[mid:]
    
@register.filter
def get_image(content):
    div = content.find('<div class="main-image">')
    if div>=0:
        start = content[div:]
        return start[:start.find('</div><br />')+12] if content.find('<br />')!=-1 else start[:start.find('</div>')+6]
    return ''

@register.filter
def strip_image(content):
    return content.replace(get_image(content),'')

class FilterFlatpagesNode(template.Node):
    def __init__(self, slug_filter, varname, sort_by_date):
        self.slug_filter = template.Variable(slug_filter)
        self.varname = varname
        self.sort_by_date = sort_by_date

    def render(self, context):
        flatpages = get_flatpages(self.slug_filter.resolve(context))
        flatpages = flatpages.order_by('-extras__published') if self.sort_by_date else flatpages
        context[self.varname] = self._paginate(context, flatpages)
        return ''
    
    def _paginate(self, context, flatpages):
        # do not paginate if not within another flatpage
        try:
            context['flatpage']
        except KeyError:
            return flatpages
        
        from django.core.paginator import Paginator, InvalidPage, EmptyPage
        for c in context:
            try:
                request = c['request']
            except KeyError:
                pass
        page = int(request.GET.get('page', 1))
        paginator = Paginator(flatpages, 10) # Show 10 flatpages per page
        try: # If page request (9999) is out of range, deliver last page of results.
            return paginator.page(page)
        except (EmptyPage, InvalidPage):
            return paginator.page(paginator.num_pages)

@register.tag(name='get_filtered_flatpages')
def do_get_filtered_flatpages(parser, token):
    '''Used to list flatpages on a flatpage.
    e.g. list of tools, list of guides, etc '''
    sort_by_date = False
    try:
        tag_name, slug_filter, _as, varname = token.split_contents()
    except ValueError:
        try:
            tag_name, slug_filter, _as, varname, sort_by_date = token.split_contents()
        except ValueError:
            raise template.TemplateSyntaxError, '%r tag requires exactly 3 arguments' % token.split_contents()[0]
    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)
    return FilterFlatpagesNode(slug_filter, varname, sort_by_date)

class CategoryFlatpagesNode(template.Node):
    def __init__(self, varname, category, base_url, sort_by_date):
        self.category = category
        self.base_url = base_url
        self.varname = varname
        self.sort_by_date = sort_by_date

    def render(self, context):
        self.category = template.Variable(self.category).resolve(context)
        if self.base_url[0]==self.base_url[-1] and self.base_url[0] in ('"',"'"):
            self.base_url = self.base_url[1:-1]
        flatpages = get_flatpages(self.base_url)
        if self.category:
            flatpages = flatpages.filter(extras__categories=self.category)
        context[self.varname] = flatpages.order_by('-extras__published') if self.sort_by_date else flatpages
        return ''
    
@register.tag(name='get_category_flatpages')
def do_get_category_flatpages(parser, token):
    '''Used to show blog snippets in category pages'''
    
    sort_by_date = False
    try:
        tag_name, _as, varname, _from, category, base_url = token.split_contents()
    except ValueError:
        try:
            tag_name, _as, varname, _from, category, base_url, sort_by_date = token.split_contents()
        except ValueError:
            raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments' % token.split_contents()[0]
    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)
    return CategoryFlatpagesNode(varname, category, base_url, sort_by_date)