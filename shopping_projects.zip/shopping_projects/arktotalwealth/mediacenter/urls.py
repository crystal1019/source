from django.conf.urls.defaults import patterns, include, url
from arktotalwealth.mediacenter.feeds import BlogFeed

urlpatterns = patterns('arktotalwealth.mediacenter.views',
	(r'^$', 'home'),
	(r'^tags/(?P<tag>.*).html$', 'tag'),
	(r'^search.html$','blogsearch'),	 
	(r'^(?P<category>.*)-archive(?P<offset>.*).html$', 'home'),
   
	(r'^(?P<code>.*).html$', 'post'),
	(r'^feed/',BlogFeed()),


)