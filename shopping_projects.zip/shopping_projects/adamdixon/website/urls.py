from django.conf.urls.defaults import patterns, url, include

urlpatterns = patterns('adamdixon.website.views',
        (r'^$','home'),
        (r'^(?P<slug>.*).html$', 'catchall'),
                       
                       
                       
)