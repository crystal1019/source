$(document).ready(function () {

    function init_typeahead() {
        var url = $('input[name=tags_url]').val();
        $.get(
            url,
            function (resp) {
                $('#new_tag input[name=tag]').typeahead({
                    'source': resp
                });
            }
        );
    }


    function delete_tag(resp) {
        $('.tag').each(function (i, elem) {
            if ($(elem).find('.tag_text').text() === resp) {
		$(elem).next('.circle').remove();
                $(elem).remove();
            }
        });
    }

    function init_delete() {
        var $delete_form = $('#delete_tag').find('form');
        $delete_form.ajaxify(util.ajax_form_opts($delete_form, delete_tag));

        $('.delete_tag').live('click', function () {
            var $del_tag = $('#delete_tag');

            // Standalone tag form
            $del_tag.find('input[name=tag]').val($(this).attr('data-tag'));
            $del_tag.find('form').trigger('submit');

            // Tag widget in other form
            delete_tag($(this).attr('data-tag'));
        });
    }

    function init_standalone() {
        // Standalone tag form
        var $new_form = $('#new_tag').find('form');
        // debugging       
        console.log('new_tag_form=',$('#new_tag').find('form').html());

        $new_form.ajaxify(util.ajax_form_opts($new_form, function (resp) {
            $('.tags').append(resp).show();
            $('#new_tag input[name=tag]').val('');
        }));
    }

    function init_widget() {
        // Tag widget in other form
        $('.new_tag_template').hide();
        $('.tag_list').show();
        $('#new_tag input[type=button]').click(function () {
            var tag = $('#new_tag input[name=tag]').val();
            var $new_elem;
            if ($.trim(tag) === '') {
                return;
            }

            $new_elem = $('.new_tag_template').clone();
            $('#new_tag input[name=tag]').val('');
        
            $new_elem.removeClass('new_tag_template').
                addClass('added_tag').addClass('tag');
            $new_elem.find('input[name=added_tag]').val(tag);
            $new_elem.find('.tag_text').text(tag)
            $new_elem.attr('data-tag', tag);
            $new_elem.find('.delete_tag').attr('data-tag', tag);
            $('.tags_controls .tag_list').prepend($new_elem).show();
            $new_elem.show();
        });

        $('#new_tag input[name=tag]').keypress(function (evt) {
            if (evt.which === 13) {
                if ($('#new_tag').find('form').length === 0) {
                    evt.preventDefault()
                    $('#new_tag input[type=button]').click();
                }
            }
        });
    }

    function init_tags_filter() {
        // TODO: add css class for selected tag
        function tag_anchor_selected($anch) {
            return ($anch.css('font-weight') === 'bold');
        }

        function toggle_tag_anchor($anch) {
            if (tag_anchor_selected($anch)) {
                $anch.css('font-weight', 'normal');
            } else {
                $anch.css('font-weight', 'bold');
            }
        }

        function any_tag_selected() {
            var found_selected = false;
            $('li.tag a').each(function (i, anch) {
                if (tag_anchor_selected($(anch))) {
                    found_selected = true;
                }
            });
            return found_selected;
        }

        function find_span($div) {
            for (var i = 1; i <= 12; i++) {
                if ($div.hasClass('span' + i)) {
                    return i;
                }
            }
            return 12;
        }

        function shuffle_recipe_thumbnails() {
            // First remove all visible recipes, then add them
            // back to each row until the row is filled up.
            var $visible = $('#recipe-list div.recipe-box:visible');
            var $rows = $('#recipe-list .row-fluid');
            var span, num_per_row, $curr_row;
	    $rows.find('div.recipe-box:visible').remove();

            if ($visible.length > 0) {
                span = find_span($($visible.get(0)));
                num_per_row = 12 / span;
                $curr_row = $($rows.get(0));

                $visible.each(function (i, thumbnail) {
                    var $vis = $curr_row.find('div.recipe-box:visible');
                    $curr_row.append($(thumbnail));
                    if ($vis.length === num_per_row) {
                        $curr_row = $curr_row.next();
                    }
                });
            }
        }

        function apply_tag_filters() {
            if (!any_tag_selected()) {
                $('#recipe-list div.recipe-box').show();
            } else {
                $('#recipe-list div.recipe-box').hide();

                $('li.tag a').each(function (i, elem) {
                    var $anch = $(elem);
                    var tag = $anch.text().replace(' ', '');
                    var show_tag = tag_anchor_selected($anch);

                    $('#recipe-list div.recipe-box').each(function (i, elem) {
                        var $recipe = $(elem);
                        var sel = 'input[name=tag][value=' + tag + ']';
                        var matches_tag = ($recipe.find(sel).length > 0);
                        if (show_tag && matches_tag) {
                            $recipe.show();
                        }
                    });
                });
            }

            // Make sure there are the right number of recipes in every row
            shuffle_recipe_thumbnails();
        }

        $('li.tag').click(function () {
            toggle_tag_anchor($(this).find('a'));
            apply_tag_filters();
        });
    }

    init_typeahead();
    init_delete();
    init_standalone();
    init_widget();
    init_tags_filter();
});