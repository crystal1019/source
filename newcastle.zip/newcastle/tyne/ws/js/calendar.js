//var PROXY_URL = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20html%20where%20url%3D%22";
var global = new Object();

var currentlyShown = 0;

var Calendar = new Class({
    initialize: function (container_id ) {
        var self = this;
        var today = new Date();
        self.outerdiv_class = "cl_outerdiv";
        self.calendarctrlarea_class = "cl_calendarctrlarea";
        self.calendarctrlbox_class = "cl_calendarctrlbox";
        self.calendarctrlprev_class = "cl_calendarctrlprev";
        self.calendarctrlnext_class = "cl_calendarctrlnext";
        self.calendarctrltext_class = "cl_calendarctrltext";
        self.weekheader_class = "cl_weekheader";
        self.weekitem_class = "cl_weekitem";
        self.weekname = new Array("sun", "mon", "tue", "wed", "thr", "fri", "sat");
        self.dayscontainer_class="cl_dayscontainer";
        self.daysrow_class = "cl_daysrow";
        self.daysbox_class = "cl_daysbox";
        self.daynumber_class = "cl_daynumber";
        self.daylabel_class = "cl_daylabel";
        self.dayavailable_class = "cl_dayavailable";
        self.emptybox_class = "cl_emptybox";
        self.availablebox_class = "cl_availablebox";
        self.noneavailablebox_class = "cl_noneavailable";
        self.popupwindow_class = "cl_popupwindow";
        self.popuploading_class = "cl_popuploading";
        self.fulllable_class = "cl_fulllabel";
        self.get_url = rest_url;

        self.year = today.getFullYear();
        self.month = today.getMonth() + 1;
        self.day = today.getDate();
        self.monthnames = new Array("January", "February", "March", "April", "May", "June", "July", 'August', "September", "October", "November", "December");

        self.detail = new ClDetail()

        self.container_id = "#" + container_id;
    },
    initialize_calender: function(){
        var self = this;
        self.reqid = 1;
        self.container = $(self.container_id);
        $(self.container).css("display", "block");
        var outerdiv_width = parseInt($(self.container_id ).width() / 7 ) * 7;
        self.outerdiv = $("<div>")
                .addClass(self.outerdiv_class )
                /*.css("width", outerdiv_width )*/
                .appendTo(self.container );

        // set the calendar control
        self.calendarctrl_area = $("<div>")
                        .addClass(self.calendarctrlarea_class )
                        .appendTo(self.outerdiv );
        
        self.calendarctrlresource = $("<div>")
            .text("Location:")
            .css("position", "relative")
            .css("float", "left")
            .css("margin-top", "5px")
            .appendTo(self.calendarctrl_area );
        self.resources = $("<select>")
            .change(function(e){
                e.stopPropagation();
                //lert($("option:selected", this).text());
                site = $("option:selected", this).text();
                self.setdays("","", $("option:selected", this).val());
            })
            .addClass(self.resourceopt_class )
            .appendTo(self.calendarctrlresource );
        for (var k in locationResourceMap) {
            $("<option>")
                .text(k)
                .attr("value", locationResourceMap[k])
                .appendTo(self.resources );
        }

        self.calendarctrlbox = $("<div>")
                        .addClass(self.calendarctrlbox_class)
                        .appendTo(self.calendarctrl_area );
        self.calendarctrlprev = $("<div>")
                        .addClass(self.calendarctrlprev_class )
                        .text("prev")
                        .click(function(e){
                            self.month = self.month - 1;
                            if (self.month < 1 ){
                                self.month = 12;
                                self.year = self.year - 1;
                            }
                            self.setdays(self.year, self.month, "" );
                        })
                        .appendTo(self.calendarctrlbox );
        
        self.calendarctrltext = $("<div>")
                        .addClass(self.calendarctrltext_class )
                        .text(self.monthnames[self.month - 1] + " " + self.year )
                        .appendTo(self.calendarctrlbox );
        self.calendarctrlnext = $("<div>")
                        .addClass(self.calendarctrlnext_class )
                        .text("next")
                        .click(function(e){
                            self.month = self.month + 1;
                            if (self.month > 12 ){
                                self.month = 1;
                                self.year = self.year + 1;
                            }
                            self.setdays(self.year, self.month, "" );
                        })
                        .appendTo(self.calendarctrlbox );


        // set the week header
        self.weekheader = $("<div>")
                .addClass(self.weekheader_class )
                .appendTo(self.outerdiv );
        for (var i = 0; i < self.weekname.length; i++ ){
            var weekitem = $("<div>")
                .addClass(self.weekitem_class )
                .text(self.weekname[i])
                .appendTo(self.weekheader );
        }

        //set days item
        self.days_container = $("<div>")    
                            .addClass(self.dayscontainer_class)
                            .appendTo(self.container );
        for (var i = 0; i < 6; i++){
            var daysrow = $("<div>")
                        .addClass(self.daysrow_class)
                        .appendTo(self.days_container );
            for (var j = 0; j < 7; j++ ){
                var daysbox = $("<div>")
                            .addClass(self.daysbox_class)
                            .attr("indexdata", "10")
                            .attr("datedata", "10")
                            .click(function(e){
                                var cls_name = $(this).attr("class");
                                var tmp_ind = parseInt($(this).attr("indexdata") );
                                var tmp_date = $(this).attr("datedata");

                                if (cls_name.indexOf(self.availablebox_class) > -1 ){
                                    self.detail.set_data(tmp_date, self.schedule_dates[tmp_ind].resources[0].slots, self.reqid );
                                    self.detail.show_detail();
                                }
                            })
                            .mouseleave(function(e){
                            	currentlyShown = 0;
                            	$( "#tempTime" ).remove();
                                $(self.popupwindow ).css("visibility", "hidden" );
                                $(self.popuploading ).css("visibility", "hidden" );
                            })
                            .mouseover (function(e){
                            	if(currentlyShown == 1)
    								return;
    		
                            	var cls_name = $(this).attr("class");
                                var tmp_ind = parseInt($(this).attr("indexdata") );
                                var tmp_date = $(this).attr("datedata");
                                
                                if (cls_name.indexOf(self.availablebox_class) > -1 ){
                                    
                                    var width = $(this).outerWidth();
    								var height = $(this).outerHeight();
    								
    								var locTop = $(this).offset().top;
    								var locLeft = $(this).offset().left;
    								
    								var newTop = locTop;
    								var newLeft = locLeft + (width-2);
                                    self.detail.set_Ttime(tmp_date, self.schedule_dates[tmp_ind].resources[0].slots, self.reqid,  newTop, newLeft);
                                }
                            }) 
                            .appendTo(daysrow );
            }
        }

        // set the popupwindow
        self.popupwindow = $("<div>")
                .addClass(self.popupwindow_class )
                .appendTo(self.container );
        self.popuploading = $("<div>")
                .addClass(self.popuploading_class )
                .appendTo(self.popupwindow );

        self.setdays(self.year, self.month, "" );
        tmp_dialog.initialize_dialog();
    },
    change_reqid: function(req_id ){
        var self = this;
        self.reqid =req_id;
        $(self.resources).val(req_id );

        self.setdays("", "", req_id );
    },
    updatepopupwindow_position: function(left, top){
        var self = this;
        var container_width = $("." + self.dayscontainer_class ).outerWidth();
        var container_height = $("." + self.dayscontainer_class ).outerHeight();

        var box_width = $("." + self.daysbox_class ).outerWidth();
        var box_height = $("." + self.daysbox_class).outerHeight();

        var popup_width = $(self.popupwindow).outerWidth();
        var popup_height = $(self.popupwindow).outerHeight();

        if (left > container_width / 2 ){
            left = left - box_width - popup_width;
        }
        if (top > container_height / 2 ){
            top = top - (popup_height - box_height );
        }
        var ret = new Object();
        ret.left= left;
        ret.top = top
        return ret;
    },
    clearcalendar: function(){
        var self = this;
        $("." + self.daysbox_class).attr("class", self.emptybox_class)
                            .addClass(self.daysbox_class )
                            .html("");
    },
    setdays: function(year, month, reqid ){
        var self = this;

        var today = new Date();
        var tmp_year = today.getFullYear();
        var tmp_month = today.getMonth();
        var tmp_day = today.getDate();

        if (year != "" )
            self.year = year;
        if (month != "" )
            self.month = month;
        if (reqid != "" )
            self.reqid = reqid;

        if (self.year > tmp_year){
            $(self.calendarctrlprev).css("display", "block" );
        }else if(self.year == tmp_year && self.month > (tmp_month + 1) ){
            $(self.calendarctrlprev).css("display", "block" );
        }else{
            $(self.calendarctrlprev).css("display", "none" );
        }

        selected_req_id = self.reqid;
        var day_obj = new Date(self.year, self.month - 1, 1 );
        var weeknumber = day_obj.getDay();
        var month_days = self.get_month_days(self.year, self.month );
        var daysrows = $(self.days_container).find("." + self.daysrow_class );
        
        self.calendarctrltext.text(self.monthnames[self.month - 1] + " " + self.year );
        self.clearcalendar();
        //alert(weeknumber + month_days);
        if (weeknumber + month_days < 29 ){
            $(daysrows[4]).css("display", "none");
            $(daysrows[5]).css("display", "none");
        }else if (weeknumber + month_days < 36  ){
            $(daysrows[4]).css("display", "block");
            $(daysrows[5]).css("display", "none");
        }else{
            $(daysrows[4]).css("display", "block");
            $(daysrows[5]).css("display", "block");
        }

        self.start_day = self.year + "-" + self.month + "-01";
        if (self.month == 12 ){
            var tmp_nyear = self.year + 1;
            var tmp_nmonth = 1;
            self.end_day = tmp_nyear + "-" + tmp_nmonth + "-01";
        }else{
            var tmp_nmonth = self.month + 1;
            self.end_day = self.year + "-" + tmp_nmonth + "-01";
        }

        self.get_data_url = self.get_url + "schedules/?resourceIds=" + selected_req_id + "&endDateTime=" + self.end_day + "&openOnly=true&startDateTime=" + self.start_day;
        //var url = "data.json";
        //$.getJSON(PROXY_URL + encodeURIComponent(self.get_data_url)+ "%22&format=xml'&callback=?", function(data){
        $.get(self.get_data_url , function(data){
            self.schedule_dates = data.schedules[selected_req_id].dates;
            self.schedule_links = data.schedules[selected_req_id].links;
            self.schedule_message = data.schedules[selected_req_id].message;
            self.schedule_scheduleId = data.schedules[selected_req_id].scheduleId;

            for (var i = 0; i < self.schedule_dates.length; i++ ){
                var tmp_data = self.schedule_dates[i];
                var tmp_date_obj = new Object();
                tmp_date_obj = self.separate_date(tmp_data.date );

                var tmp_row = parseInt((tmp_date_obj.day - 1 + weeknumber) / 7 );
                var tmp_col = parseInt((tmp_date_obj.day - 1 + weeknumber) % 7 );

                var tmp_days_cols = $(daysrows[tmp_row]).find("." + self.daysbox_class );
                var tmp_daysbox = tmp_days_cols[tmp_col ];  
                
                
                var daynumber = $("<div>")
                            .addClass(self.daynumber_class )
                            .text(tmp_date_obj.day )
                            .appendTo(tmp_daysbox ); 

                if (tmp_date_obj.year > tmp_year || 
                   (tmp_date_obj.year == tmp_year && tmp_date_obj.month > tmp_month ) ||
                   (tmp_date_obj.year == tmp_year && tmp_date_obj.month == tmp_month && tmp_date_obj.day > tmp_day) ){
                    if (tmp_data.resources[0].slots.length < 1 ){
                        $(tmp_daysbox ).addClass(self.noneavailablebox_class )
                        var daynoneavailable = $("<div>")
                                    .addClass(self.fulllable_class )
                                    .text("Not available")
                                    .appendTo(tmp_daysbox );

                    }else{
                        $(tmp_daysbox ).addClass(self.availablebox_class )
                                    .attr("indexdata", i )
                                    .attr("datedata", tmp_data.date );
                        var dayavailable = $("<div>")
                                    .addClass(self.dayavailable_class )
                                    .text("Available")
                                    .appendTo(tmp_daysbox );                            
                        var daylabel = $("<div>")
                                    .addClass(self.daylabel_class )
                                    .text("Book Now")
                                    .appendTo(tmp_daysbox );
                    }                    
                    $(tmp_daysbox ).removeClass(self.emptybox_class );
                }
            }   
        });
       
    },
    separate_date: function(date ){
        var ret = new Object();
        var tmp_arr = date.split("T");
        var tmp_time_arr = tmp_arr[1].split("-");
        var tmp_date = new Date(tmp_arr[0] + " " + tmp_time_arr[0] );
        var tmp_ymd = tmp_arr[0].split("-");
        var tmp_hms = tmp_time_arr[0].split(":");
        ret.year = parseInt(tmp_ymd[0]);//tmp_date.getFullYear();
        ret.month = parseInt(tmp_ymd[1]) - 1;//tmp_date.getMonth();
        ret.day = parseInt(tmp_ymd[2]);//tmp_date.getDate();
        ret.hour = parseInt(tmp_hms[0]);//tmp_date.getHours();
        ret.minute = parseInt(tmp_hms[1]);//tmp_date.getMinutes();
        ret.second = parseInt(tmp_hms[2]);//tmp_date.getSeconds();
        return ret;
    },
    get_month_days: function(year, month ){
        var ret_arr = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
        if (year % 4 == 0 ){
            if (year % 100 == 0 ){
                if (year % 400 == 0 ){
                    return 29;
                }
            }else{
                return 29;
            }
        }
        return ret_arr[month - 1];
    },
    exit_dialog: function(){
        if (self.container ){
            $(self.container).html("");
            $(self.container).css("display", "none");    
        }
    }
});

var ClDetail = new Class({
    initialize: function(){
        var self = this;
        self.container = $("body");
        self.blackscreen_class = "dt_blackscreen";
        self.boxcontainer_class = "dt_boxcontainer";
        self.dtrow_class = "dt_row";
        self.option_class = "dt_option";
        self.optionlabel_class = "dt_optionlabel";
        self.reservebtn_class = "dt_reservebtn";
        self.title_class = "dt_title";
        self.subtitle_class = "dt_subtitle";
        self.slotscontainer_class = "dt_slotscontainer";
        self.option_name = "dt_timeopt";
        self.input_row_class = "dt_input_row";
        self.col_half_class = "dt_col_half";
        self.input_label_class = "dt_inputlabel";
        self.input_content_class = "dt_inputcontent";
        self.firstname_class = "dt_firstname";
        self.lastname_class = "dt_lastname";
        self.firstnamelabel_class = "dt_firstnamelabel";
        self.lastnamelabel_class = "dt_lastnamelabel";
        self.phonenumber_class = "dt_phonenumber";
        self.soc_class = "dt_soc";
        self.url = rest_url + "reservations/";
        self.monthnames = new Array("January", "February", "March", "April", "May", "June", "July", 'August', "September", "October", "November", "December");
        self.initialize_detail();
    },
    initialize_detail: function(){
        
        var self = this;
        self.blackscreen = $("<div>")
                .addClass(self.blackscreen_class )
                .click(function(){
                	$(self.firstname).val("");
                    $(self.lastname).val("");
                    $(".dt_phonenumber").val("");
                    $(".dt_soc").val("");
                    self.hide_detail();
                })
                .appendTo(self.container);
                
                
            
                
        self.boxcontainer = $("<div>")
                .addClass(self.boxcontainer_class )
                .appendTo(self.container );
        	
		$("<img>").attr("src", "img/"+ org_string +"/logo.png")
				.css("display", "block")
				.css("margin-left", "auto")
				.css("margin-right", "auto")
				.css("margin-bottom", "20px")
                .appendTo(self.boxcontainer );
        
        $("<img>").attr("src", "img/close.png")
				.css("float", "right")
				.css("width", "20px")
				.css("height", "20px")
				.css("cursor", "pointer")
				.css("margin-top", "-60px")
				.click(function(e){
					$(self.firstname).val("");
                    $(self.lastname).val("");
                    $(".dt_phonenumber").val("");
                    $(".dt_soc").val("");
					self.hide_detail();
				})
                .appendTo(self.boxcontainer );
        
        
        $("<div>").text("Web Scheduler")
                .addClass(self.title_class)
                .appendTo(self.boxcontainer);
        self.subtitle = $("<div>").text("Available Times for " + locationResourceMap[selected_req_id] + " on ")
                .addClass(self.subtitle_class)
                .appendTo(self.boxcontainer );
        self.slotscontainer = $("<div>")
                .addClass(self.slotscontainer_class )
                .appendTo(self.boxcontainer );
		
		console.log('ward'); 
		
        var tmp_row = $("<div>")
                .addClass(self.input_row_class )
                .appendTo(self.boxcontainer );
                
        var tmp_col_half1 = $("<div>")                
                .addClass(self.col_half_class )
                .appendTo(tmp_row );
        $("<div>").text("First Name: ")
                .appendTo(tmp_col_half1 );
        self.firstname = $("<input>")
                .attr("type", "text")
                .addClass(self.firstname_class )
                .attr("placeholder", "First name")
                .appendTo(tmp_col_half1 );
        
        
        
        var tmp_col_half2 = $("<div>")                
                .addClass(self.col_half_class )
                .appendTo(tmp_row );
        $("<div>").text("Last Name: ")
                .appendTo(tmp_col_half2 );
        self.lastname = $("<input>")
                .attr("type", "text")
                .addClass(self.lastname_class )
                .attr("placeholder", "Last name")
                .appendTo(tmp_col_half2 );
		
		 
                
        var tmp_col_half3 = $("<div>")                
                .addClass(self.col_half_class )
                .appendTo(tmp_row );
        $("<div>").text("Phone #: ")
                .appendTo(tmp_col_half3 );
        self.phonenumber = $("<input>")
                .attr("type", "text")
                .attr("id", "phoNumber")
                .attr("placeholder", "(nnn) nnn-nnnn")
                .addClass(self.phonenumber_class )
                .appendTo(tmp_col_half3 );                

		var tmp_col_half4 = $("<div>")                
                .addClass(self.col_half_class )
                .appendTo(tmp_row );
        $("<div>").text("Email: ")
                .appendTo(tmp_col_half4 );
        self.phonenumber = $("<input>")
                .attr("type", "text")
                .attr("id", "email")
                .attr("placeholder", "email@example.com")
                .addClass("email")
                .appendTo(tmp_col_half4 );  
                
			
        // custome fields 
        generateCustomFields(tmp_row);
        
        
        
        var tmp_col = $("<div style='float: left;text-align: center;width: 100%;'>")                
                  .addClass('centerBtn')
                  .appendTo(self.boxcontainer);
                          
        self.reservebtn = $("<input>")
                .addClass(self.reservebtn_class )
                .attr("type", "button" )
                .attr("value", "Reserve")
                .click(function(e){
                    
                    // The standered fields
                    var firstname = $(self.firstname).val();
                    var lastname = $(self.lastname).val();
                    var phonenumber = $(".dt_phonenumber").val();
                    var email = $("#email").val();
                                         
                    
                    //var emailRegx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					//if(!email.match(emailRegx)) {  
					//  alert("Please input a valid email.");
                    //  return;  
					//} 
					
                                        
                    if (firstname == ''){
                        alert("input first name, please");
                        return;
                    }

                    if (lastname == ''){
                        alert("input last name, please");
                        return;
                    }
					if (phonenumber == "" ){
                        alert("input phonenumber, please");
                        return;
                    }

					var phoneno = /^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/;
					if(!phonenumber.match(phoneno)) {  
					  alert("Please input a valid phone number.");
                      return;  
					} 
					//-------------------- end of the standred fields
					
					
                    var startdate = $("input[name=" + self.option_name +  "]:checked", "." + self.slotscontainer_class + '' ).attr("startdate");
                    var enddate = $("input[name=" + self.option_name +  "]:checked", "." + self.slotscontainer_class + '' ).attr("enddate");
                    
                    if(!startdate) {
                    	alert("Choose time, please");
                        return;
                    }
                    
                    var simpDate1 = startdate.substring(0, startdate.lastIndexOf("T"));
                    var m = moment(simpDate1)
					var simpDate2 = m.format('Do MMMM, YYYY')
                    
                    var selected = $("input[name=" + self.option_name +  "]:checked").attr('id');
                    var simpTime1 = $("label[for="+selected+"]").text();
                    
                    
                    var r = confirm("Are you sure you want to choose this date ?\n"+simpDate2+" at "+simpTime1 +" at "+site);
					if (r != true) {
					    return;
					}

                    var description = company_name + " Web Scheduler";
                    var reqid = selected_req_id;
                    var resources = "{'" + reqid + "'}";
                    var title = company_name + " Web Appointment";

					
					// the standred data
                    var userData = {};
                    userData["firstName"] = firstname;
                    userData["lastName"] = lastname;
                    userData["phone"] = phonenumber.replace(/[^0-9]/g,''); 
  					//email should be set if it is filled out
                    //userData["emailAddress"] = email;
                    userData["timezone"] = timezone;

                    if (typeof [groupId[site]] !== 'undefined') {
                    	userData["groups"] = [groupId[site]];
                    }
                    //------------------
                    
                    // validate the custom fields
                   validateCustomFields();
                    //-----------------
                    
                    var customAttr = generateCustomData();
                    //console.log(JSON.stringify(customAttr));
                    
                    userData["customAttributes"] = customAttr;
                    
		    if (typeof [customAttributes["userName"]] !== 'undefined') {
			userData["userName"] = customAttributes["userName"];
		    }
                    data = JSON.stringify(userData)
                    console.log("D: "+data);
                     
                    //return;
                    
                    
                   
              
                    
                    //alert(data)
                    $.ajax({
                      url: rest_url + "users/",
                      contentType: "application/json; charset=utf-8",
                      async: false,
                      type: "POST",
                      dataType: "json",                      
                      data: data,
                      dataType: "json"
                    }).done(function(data) {
			console.log("HERE")
			console.log(data)
                        var userid = data['users'][0]['id'];

                        var resData = {};
                        resData['data'] = {}
                        resData['data']["startDateTime"] = startdate;
                        resData['data']["endDateTime"] = enddate;
                        resData['data']["description"] = description;
                        resData['data']["resourceId"] = reqid;
                        resData['data']["resources"] = resources;
                        resData['data']["userId"] = userid;
                        resData['data']["title"] = title;
                        data = JSON.stringify(resData)
                        
                        $.ajax({
                          url: rest_url + "reservations/",
                          contentType: "application/json; charset=utf-8",
                          async: false,
                          type: "POST",
                          dataType: "json",                      
                          data: data,
                          dataType: "json"
                        }).done(function(msg) {
                            if(msg.reservations) {
                            	alert("Thank you. Your appointment has been made");
                            	window.location = next_url;
                            } else {
                            	alert("We are Sorry. Your appointment could not be made. Please try again with a different time selected.");
                            	$('#container').html('');
                            	tmp_calendar.initialize_calender();
                            	tmp_dialog.exit_dialog();                            	
	                            	$(self.firstname).val("");
				                    $(self.lastname).val("");
				                    $(".dt_phonenumber").val("");
				                    $(".dt_soc").val("");
                            }
                        }).fail(function(msg){
                            alert("We are Sorry. Your appointment could not be made. Please try again with a different time selected.");
                            $('#container').html('');
                            tmp_calendar.initialize_calender();
                            tmp_dialog.exit_dialog();
                              	$(self.firstname).val("");
			                    $(self.lastname).val("");
			                    $(".dt_phonenumber").val("");
			                    $(".dt_soc").val("");                          
                        });


                    }).fail(function(msg){
                    	alert("We are Sorry. Your appointment could not be made. Please try again with a different time selected.");
                    	$('#container').html('');
                    	tmp_calendar.initialize_calender();
                    	tmp_dialog.exit_dialog();
                            	$(self.firstname).val("");
			                    $(self.lastname).val("");
			                    $(".dt_phonenumber").val("");
			                    $(".dt_soc").val("");                    	
                    });
                    self.hide_detail();
                })
                .appendTo(tmp_col);
				
				maskCustomFields();		
					
                $("#phoNumber").mask("(999) 999-9999");
                
                
    },
    get_string_from_reqid: function(reqid ){
        for (var tmp in locationResourceMap ){
            if (locationResourceMap[tmp] == reqid ){
                return tmp;
            }
        }
    },
    set_Ttime:function(day, slots, reqid, top, left ){
    	if(currentlyShown == 1)
    		return;
    		
    		
    	currentlyShown = 1;
    	var self  = this;
    	
        var tmp_row = $("<div>")
        			.text("Available Times")
        			.attr('id', 'tempTime')
                    .css('width', '204px')
                    //.css('height', '200px')
                    .css('color', '#fff')
                    .css('background-color', '#567bd2')
                    .css('position', 'absolute')
                    .css('top', top)
                    .css('left', left)    
                    .css('overflow', 'hidden')                 
                    .appendTo("body");
                    
        for (var i = 0; i < slots.length; i++ ){
            var tmp_slot = slots[i];
            var tmp_slot_startdate = self.separate_date(tmp_slot.startDateTime );
            var tmp_slot_enddate = self.separate_date(tmp_slot.endDateTime );
            
            var tmp_hour = tmp_slot_startdate.hour;
            var ampm = "";
            
            if (tmp_hour > 12 ){
            	tmp_hour -= 12;
            	ampm = " pm";
            } else {
            	ampm = " am";
            }
            if (tmp_hour< 10 ){
                tmp_hour = "0" + tmp_hour;
            }
            var tmp_minute = tmp_slot_startdate.minute;
            if (tmp_minute < 10 ){
                tmp_minute = "0" + tmp_minute;
            }
            var tmp_startdate_str = tmp_hour + ":" + tmp_minute + ampm;
            
            tmp_hour = tmp_slot_enddate.hour;
            if (tmp_hour > 12 ){
            	tmp_hour -= 12;
            	ampm = " pm";
            } else {
            	ampm = " am";
            }            
            if (tmp_hour < 10 ){
                tmp_hour = "0" + tmp_hour;
            }
            tmp_minute = tmp_slot_enddate.minute;
            if (tmp_minute < 10 ){
                tmp_minute = "0" + tmp_minute;
            }
            var tmp_enddate_str = tmp_hour + ":" + tmp_minute + ampm;
            
            var tmp_label_str = tmp_startdate_str + " - " + tmp_enddate_str; 
            
            $("<div>").text(tmp_label_str )
                            .appendTo(tmp_row );
            
            
            //console.log("S: "+tmp_label_str);
        }
    },
    set_data:function(day, slots, reqid ){
    	var self  = this;
        var day_obj = self.separate_date(day);
        var tmp_str = self.monthnames[day_obj.month ] + " " + day_obj.day;
        $(self.subtitle).html("Available Times for <b>" + self.get_string_from_reqid(reqid)  + "</b> on <b>" + tmp_str+"</b>" );
        $(self.slotscontainer).html("");
        for (var i = 0; i < slots.length; i++ ){
            var tmp_slot = slots[i];
            var tmp_slot_startdate = self.separate_date(tmp_slot.startDateTime );
            var tmp_slot_enddate = self.separate_date(tmp_slot.endDateTime );
            
            var tmp_hour = tmp_slot_startdate.hour;
            var ampm = "";
            
            if (tmp_hour > 12 ){
            	tmp_hour -= 12;
            	ampm = " pm";
            } else {
            	ampm = " am";
            }
            
            if (tmp_hour< 10 ){
                tmp_hour = "0" + tmp_hour;
            }
            
            
            var tmp_minute = tmp_slot_startdate.minute;
            if (tmp_minute < 10 ){
                tmp_minute = "0" + tmp_minute;
            }
            var tmp_startdate_str = tmp_hour + ":" + tmp_minute + ampm;


            tmp_hour = tmp_slot_enddate.hour;
            if (tmp_hour > 12 ){
            	tmp_hour -= 12;
            	ampm = " pm";
            } else {
            	ampm = " am";
            }            
            if (tmp_hour < 10 ){
                tmp_hour = "0" + tmp_hour;
            }
            tmp_minute = tmp_slot_enddate.minute;
            if (tmp_minute < 10 ){
                tmp_minute = "0" + tmp_minute;
            }
            var tmp_enddate_str = tmp_hour + ":" + tmp_minute + ampm;

            var tmp_label_str = tmp_startdate_str + " - " + tmp_enddate_str; 
            if (tmp_slot.isReservable ){
                var tmp_row = $("<div>")
                    .addClass(self.dtrow_class )
                    .appendTo(self.slotscontainer );
                $("<input>").addClass(self.option_class )
                            .attr("type", "radio")
                            .attr("startdate", tmp_slot.startDateTime )
                            .attr("enddate", tmp_slot.endDateTime )
                            .attr("name", self.option_name )
                            .attr("id", "dt_option_" + i)
                            .appendTo(tmp_row );
                $("<label>").addClass(self.optionlabel_class )
                            .attr("for", "dt_option_" + i)
                            .text(tmp_label_str )
                            .appendTo(tmp_row )
            }
            
        }
    },
    separate_date: function(date ){
        var ret = new Object();
        var tmp_arr = date.split("T");
        var tmp_time_arr = tmp_arr[1].split("-");
        var tmp_date = new Date(tmp_arr[0] + " " + tmp_time_arr[0] );
        var tmp_ymd = tmp_arr[0].split("-");
        var tmp_hms = tmp_time_arr[0].split(":");
        ret.year = parseInt(tmp_ymd[0]);//tmp_date.getFullYear();
        ret.month = parseInt(tmp_ymd[1]) - 1;//tmp_date.getMonth();
        ret.day = parseInt(tmp_ymd[2]);//tmp_date.getDate();
        ret.hour = parseInt(tmp_hms[0]);//tmp_date.getHours();
        ret.minute = parseInt(tmp_hms[1]);//tmp_date.getMinutes();
        ret.second = parseInt(tmp_hms[2]);//tmp_date.getSeconds();
        return ret;
    },
    show_detail: function(){
        var self = this;
        $(self.blackscreen).css("display", "block" );
        $(self.boxcontainer).css("display", "block" );
    },
    hide_detail: function(){
        var self = this;
        $(self.blackscreen).css("display", "none" );
        $(self.boxcontainer).css("display", "none" );  
    }
});
