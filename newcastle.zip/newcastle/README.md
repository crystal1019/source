# Overview

The project has two sub-dirs:
* tyne: flask app that includes broker server and web scheduler code
* wear: django app

# tyne
tyne has a rest server and a web scheduler UI

## rest server
The rest server is meant to be a middle layer going from any front end to any server.  Current front 
ends are:
* freeswitch servers
* web scheduler pages

Current back ends are:
* booked server

Ideally the the rest server will move into tyne at some point

## web scheduler
the web scheduler is very client heavy.  It needs to change but the exact ways to change are still
somewhat fuzzy.

# wear
wear is a new django project that will be the base for new apps.

