'''Codes categorized in these items:
1. No frontend
2. 
'''