$(document).ready(function(){
    var win_w = $(window).width();
    var src_url = $('#my_img').prop('src');
    var chunks = src_url.split("/");
    src_fol_url =  src_url.split(chunks[chunks.length-1]);
    $(window).resize(function(){
        win_w = $(window).width();
        var div_height = $('.col-md-12 .col-lg-4:first-child').height();
        console.log(div_height);
        $('.col-md-12 .col-lg-4').eq(1).height(div_height);
        $('.col-md-12 .col-lg-4').eq(1).find('img').css('position','absolute');
        $('.col-md-12 .col-lg-4').eq(1).find('img').css('bottom','0px');
        if (win_w < 976) {
            $('.col-md-12 .col-lg-4').eq(1).height(945);
        }
        if ((win_w < 1035) && (win_w > 640)){
            $('#my_img').attr('src', src_fol_url[0] + 'background1.png');
        }else if(win_w < 640) {
            $('#my_img').attr('src', src_fol_url[0] + 'background2.png');
            $('li#contact div').css('display', 'none');
        }else {
            $('#my_img').attr('src',src_fol_url[0] + 'background.png');
        };
        if(win_w< 360){
            $('.col-md-12 .col-lg-4').eq(1).height(570);
        }
    });
    $( "#btn" ).click(function() {
      alert( "Handler for .click() called." );
    });
    $(window).resize();

});

