__author__ = 'RJB'
from flask import Flask, redirect, url_for
from config import config
from flask.ext.bootstrap import Bootstrap
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.login import LoginManager, current_user
from flask.ext.moment import Moment
#from flask.ext.pagedown import PageDown
from flask.ext.admin import Admin, BaseView, expose
from flask.ext.admin.contrib.sqla import ModelView


class AdminView(BaseView):
    @expose('/')
    def index(self):
        return self.render('admin/index.html')

    def is_accessible(self):
        return current_user.is_authenticated() and current_user.is_admin

    def _handle_view(self, name, **kwargs):
        if not self.is_accessible():
            return redirect(url_for('login', next=request.url))

#pagedown = PageDown()

moment = Moment()

login_manager = LoginManager()
login_manager.login_view = 'auth.login'

db = SQLAlchemy()

bootstrap = Bootstrap()


def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    adn = Admin()

    #print app.config
    #from .api_1_0 import api as api_blueprint
    #app.register_blueprint(api_blueprint, url_prefix='/api/1.0')

    from .auctions import auctions as auctions_blueprint
    app.register_blueprint(auctions_blueprint)

    from .scraper import scraper as scraper_blueprint
    app.register_blueprint(scraper_blueprint, url_prefix='/scraper')

    from .auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint, url_prefix='/auth')


    bootstrap.init_app(app)
    db.init_app(app)
    login_manager.init_app(app)
    moment.init_app(app)
    #pagedown.init_app(app)
    adn.init_app(app)
    from models import User, Properties, TaxData, Comps, Reports
    adn.add_view(ModelView(User, db.session))
    adn.add_view(ModelView(Reports, db.session))
    adn.add_view(ModelView(Properties, db.session))
    adn.add_view(ModelView(TaxData, db.session))
    adn.add_view(ModelView(Comps, db.session))

    return app
