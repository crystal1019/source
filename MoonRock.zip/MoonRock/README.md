# MoonRock

This is the MoonRock project. It is awesome.


## Requirements

You'll need to have the following items installed before continuing.

  * [Node.js](http://nodejs.org): Use the installer provided on the NodeJS website. Or on Ubuntu use [sudo] apt-get install nodejs-legacy
  * [Grunt](http://gruntjs.com/): Run `[sudo] npm install -g grunt-cli`
  * [Bower](http://bower.io): Run `[sudo] npm install -g bower`


## Setup & Developing

To setup everything, run `./setup.sh`. This will install all necessary packages from Node and Bower.

Alternatively, install all the necessary packages for Node through NPM and for the webapp through Bower.

```bash
npm install
bower install
npm install grunt-sass
npm install grunt-contrib-watch
npm install grunt-contrib-connect
```


To compile and run the server, run `grunt`. This will run a server on localhost:9001.
You can also just build the app with `grunt build`.


## Directory Structure

  * `js`: Application Javascript goes here.
  * `scss/`: Application styles go here.
  * `css/`: Contains all compiled styles. Disregard it.
  * `bower_components/`: Contains all 3rd party modules. Disregard it.
  * `node_modules/`: Contains all node modules. Disregard it.
