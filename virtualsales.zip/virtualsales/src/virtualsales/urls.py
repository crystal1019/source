"""
copyright 2014 Seth Black
"""

from django.conf.urls import patterns, include, url
from django.views.generic import TemplateView

from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'virtualsales.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^root/admin/', include(admin.site.urls)),

    url(r'^$', TemplateView.as_view(template_name='coming_soon.html')),
    url(r'^home$', TemplateView.as_view(template_name='home.html'), name='home'),
    url(r'^faq$', TemplateView.as_view(template_name='faq.html'), name='faq'),
    url(r'^contact$', TemplateView.as_view(template_name='contact.html'), name='contact'),
    url(r'^how-it-works$', TemplateView.as_view(template_name='how_it_works.html'), name='how-it-works'),

    url(r'^legal/privacy-policy$', TemplateView.as_view(template_name='privacy.html'), name='privacy'),
    url(r'^legal/terms-of-service$', TemplateView.as_view(template_name='tos.html'), name='tos'),

    # sign up
    url(r'^signup/$', 'virtualsales.main.views.signup', name='signup'),

    # auth
    url(r'^accounts/login/$', 'django.contrib.auth.views.login', name='login-accounts'),
    url(r'^login/$', 'django.contrib.auth.views.login', name='login'),
    url(r'^logout/$', 'django.contrib.auth.views.logout', {'next_page': '/'}, name='logout'),
    url(r'^password-reset/$', 'django.contrib.auth.views.password_reset', name='password-reset'),
    url(r'^password-reset/done/$', 'django.contrib.auth.views.password_reset_done', name='password_reset_done'),
    url(r'^reset/(?P<uidb36>[0-9A-Za-z]+)-(?P<token>.+)/$', 'django.contrib.auth.views.password_reset_confirm'),
    url(r'^reset/done/$', 'django.contrib.auth.views.password_reset_complete'),

    # customer stuffs
    url(r'^dashboard/$', 'virtualsales.main.views.dashboard', name='dashboard'),
    url(r'^dashboard/create-campaign/$', TemplateView.as_view(template_name='create_campaign.html'), name='create-campaign'),

    # call center stuffs
    url(r'^cc/assigner/$', 'virtualsales.main.views.assigner', name='assigner'),
)
