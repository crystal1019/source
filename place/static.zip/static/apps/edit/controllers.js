angular.module('editor.controllers', []).controller('EditorCtrl', ["$scope", "$http", "$q", "$modal", "$location", '$window', "SaveData",
    function($scope, $http, $q, $modal, $location, $window, SaveData) {
        $scope.$location = $location;
        $scope.topic = data.topic;
        $scope.available_features = data.available_features;
        $scope.SaveData = SaveData;
        $scope.dirty_tabs = {};
        $scope.is_dirty = false;
        $scope.invalid_tabs = [];
        $scope.save_errors = [];
        $scope.image_sizes = {
            'org_logo': [220, 105],
            'hero': [700, 300]
        };
        $scope.crit_save_error = false;
        $scope.saving = false;
        $scope.save_success = false;
        $scope.save_fail = false;
        /***********************************************************
        EDITOR
        ***********************************************************/

        $scope.has_feature = function(ft) {
            return _.contains($scope.available_features, ft);
        };
        $scope.reloadPage = function() {
            $window.location.reload();
        };
        $scope.save = function() {
            if ($scope.saving) {
                return;
            }
            $scope.saving = true;
            $scope.crit_save_error = false;
            $scope.save_errors = [];
            if ($scope.invalid_tabs.length !== 0 && _.key($scope.dirty_tabs).length > 0) {
                $scope.save_fail = true;
            } else {
                // Determines wether to send back updated data for current tab or not
                var tab;
                if (angular.isDefined($scope.dirty_tabs[$scope.current_tab]) && $scope.current_tab !== "/map") {
                    tab = $scope.current_tab;
                } else {
                    tab = null;
                }
                var promises = [];
                // Checks for map tab and calls save on it seperately
                if (angular.isDefined($scope.dirty_tabs["/map"])) {
                    promises.push($scope.dirty_tabs["/map"].save());
                }
                if (angular.isDefined($scope.dirty_tabs["/place-it"])) {
                    $scope.dirty_tabs["/place-it"].addUpdatesToStack();
                }
                // Saves all tabs
                promises.push($scope.SaveData.save($scope.topic, tab))

                $q.all(promises).then(function(data) {
                    for(var i = 0, len = data.length; i < len; i++){
                        if(data[i].data_type === 'topic'){
                            var obj = data[i].data;
                            $scope.saving = false;
                            if (obj.success && !obj.error) {
                                $scope.save_success = true;
                                $scope.SaveData.clear();
                                $scope.$broadcast("saved");
                                if (angular.isDefined(obj.data[$scope.current_tab])) {
                                    $scope.$broadcast("dataupdate", $scope.current_tab, obj.data[$scope.current_tab]);
                                }
                                $scope.form_header.$setPristine();
                            } else {
                                $scope.save_fail = true;
                                errors = obj.data;
                                _.each(errors, function(val, key) {
                                    switch (key) {
                                        case "team":
                                            $scope.save_errors.push("/team");
                                            break;
                                        case "contact":
                                            $scope.save_errors.push("/contact");
                                            break;
                                        case "organization":
                                            $scope.save_errors.push("/contact");
                                            break;
                                        case "who":
                                            $scope.save_errors.push("/who");
                                            break;
                                        case "events":
                                            $scope.save_errors.push("/events");
                                            break;
                                        case "twitterparam":
                                            $scope.save_errors.push("/social");
                                            break;
                                        case "facebook":
                                            $scope.save_errors.push("/social");
                                            break;
                                        case "features":
                                            $scope.save_errors.push("/features");
                                            break;
                                        case "discussion":
                                            $scope.save_errors.push("/discussions");
                                            break;
                                        case "poll":
                                            $scope.save_errors.push("/polls");
                                            break;
                                        case "choice":
                                            $scope.save_errors.push("/polls");
                                            break;
                                        case "reports":
                                            $scope.save_errors.push("/reports");
                                            break;
                                        case "overview":
                                            $scope.save_errors.push("/overview");
                                            break;
                                        case "image":
                                            $scope.save_errors.push("/resources");
                                            break;
                                        case "link":
                                            $scope.save_errors.push("/resources");
                                            break;
                                        case "video":
                                            $scope.save_errors.push("/resources");
                                            break;
                                        case "document":
                                            $scope.save_errors.push("/resources");
                                            break;
                                        case "reports":
                                            $scope.save_errors.push("/reports");
                                            break;
                                    }
                                });
                                $scope.$broadcast("saveerrors", errors);
                                if (angular.isDefined(errors['header'])) {
                                    header_errors = errors['header'];
                                    $scope.header.ext_errors = {};
                                    _.each(header_errors, function(err) {
                                        _.each(err, function(v, k) {
                                            $scope.header.ext_errors[k] = v;
                                        });
                                    });
                                }
                            }
                        }
                    }
                }, function(reason) {
                    $scope.saving = false;
                    $scope.crit_save_error = true;
                });
            }
        };
        $scope.toggle = function(help_sec) {
            $scope.$broadcast('event:toggle', help_sec);
        };
        $scope.$on("tabchange", function(e, tab) {
            if (!_.has($scope.dirty_tabs, tab)) {
                $scope.dirty_tabs[tab] = e.targetScope;
            }
        });
        $scope.$on("tabvalid", function(e, tab, is_valid) {
            var idx = _.contains($scope.invalid_tabs, tab);
            if (!is_valid && !idx) {
                $scope.invalid_tabs.push(tab);
            } else if (is_valid && idx) {
                $scope.invalid_tabs.splice($scope.invalid_tabs.indexOf(tab));
            }
        });
        $scope.$on("tabreset", function(e, tab) {
            if (_.has($scope.dirty_tabs, tab)) {
                delete $scope.dirty_tabs[tab];
            }
        });
        // Track dirty and invalid tabs
        $scope.$watch(function() {
            return _.keys($scope.dirty_tabs).length + " " + $scope.invalid_tabs.length;
        }, function(n, o) {
            if (_.keys($scope.dirty_tabs).length > 0 && $scope.invalid_tabs.length === 0) {
                $scope.is_dirty = true;
            } else {
                $scope.is_dirty = false;
            }
        });
        /***********************************************************
        HEADER
        ***********************************************************/
        if (!angular.isDefined($scope.header)) {
            $scope.header = {
                title: data.topic_title,
                category: data.topic_category
            };
        }
        $scope.$watch('form_header.$dirty', function(new_val, old_val) {
            if (new_val) {
                if ($scope.form_header.$valid && !$scope.SaveData.contains($scope.header)) {
                    $scope.SaveData.push('header', {
                        "data": $scope.header
                    });
                    $scope.dirty_tabs['/'] = $scope;
                }
            } else {
                delete $scope.dirty_tabs['/'];
            }
        });
        $scope.$watch("$location.path()", function(new_val) {
            if (!new_val) {
                $location.path("/team");
            }
            $scope.current_tab = new_val;
        });
        $scope.hasError = function(path) {
            s = _.contains($scope.save_errors, path);
            i = _.contains($scope.invalid_tabs, path);
            if (s || i) {
                return true;
            }
            return false;
        };
        $scope.launchPublisherModal = function() {
            var modalPromise = $modal({
                template: '/static/apps/edit/partials/edit/publisher_modal.html',
                persist: true,
                show: false,
                backdrop: 'static',
                scope: $scope
            });
            $q.when(modalPromise).then(function(modalEl) {
                modalEl.modal('show');
            });
        };
        $scope.launchNotifyModal = function() {
            var modalPromise = $modal({
                template: '/static/apps/edit/partials/edit/notify_modal.html',
                persist: true,
                show: false,
                backdrop: 'static',
                scope: $scope
            });
            $q.when(modalPromise).then(function(modalEl) {
                modalEl.modal('show');
            });
        };
        //http://stackoverflow.com/a/18265285/2807539
        $scope.safeApply = function(fn) {
            var phase = this.$root.$$phase;
            if (phase == '$apply' || phase == '$digest') {
                if (fn) {
                    fn();
                }
            } else {
                this.$apply(fn);
            }
        };
        // Save on ctrl+s
        /*$(window).keypress(function(event) {
        if (!(event.which == 115 && event.ctrlKey) && !(event.which == 19)) return true;
        $scope.save();
        $scope.$apply($scope.edata.dirty);
        event.preventDefault();
        return false;
        });*/
    }
])
    .controller('NotifyCtrl', ["$scope", "$http",
        function($scope, $http) {
            $scope.messages = null;
            $scope.notification_message = "";
            $scope.sendNotifications = function() {
                $http.post('/editor_v2/notify/', {
                    "topic": $scope.topic,
                    "message": $scope.notification_message
                }).success(function(obj) {
                    $scope.messages = obj.message;
                }).error(function(err) {});
                $scope.$modal('hide');
            };
        }
    ])
    .controller('PublisherCtrl', ["$scope", "$http",
        function($scope, $http) {
            $scope.messages = null;
            $scope.state = null;
            $scope.confirm_archive = false;
            $scope.publish_data = {
                send_notifications: true,
                notify_distance: 500
            };
            $http({
                method: 'GET',
                url: '/editor_v2/check_topic_requirements/',
                params: {
                    topic: $scope.topic
                }
            }).success(function(obj) {
                $scope.state = obj.data;
                $scope.messages = obj.message;
            }).error(function(obj) {});
            $scope.toggleConfirmArchive = function() {
                $scope.confirm_archive = !$scope.confirm_archive;
            };
            $scope.togglePublish = function(unpublish) {
                $http.post('/editor_v2/toggle_publish_topic/', _.extend($scope.publish_data, {
                    topic: $scope.topic,
                    unpublish: unpublish
                })).success(function(obj) {
                    //do something
                    $scope.state = obj.data;
                    $scope.messages = obj.message;
                    $scope.publish_data.send_notifications = true;
                }).error(function(data, status) {
                    console.log(status);
                });
            };
        }
    ])
    .controller('OverviewCtrl', ["$scope", "$q", "$http", "$modal", "$timeout", "OverviewData",
        function($scope, $q, $http, $modal, $timeout, OverviewData) {
            $scope.OverviewData = OverviewData;
            $scope.image_crop_meta = {};
            // Need to defined the target image size,
            // used during cropping.
            $scope.target_image_size = {
                width: 700,
                height: 300
            };
            $scope.measurements = {};
            // Used during uploading and cropping
            // b/c of delay of filepicker upload
            // to Ink servers and download to PS servers.
            $scope.loading_image = false;
            var type = 'overview';
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/overview") {
                    if (!$scope.OverviewData.active) {
                        $scope.OverviewData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/overview");
                $scope.form_overview.$setPristine();
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['overview'])) {
                    o_errors = errors['overview'];
                    $scope.OverviewData.store.ext_errors = {};
                    _.each(o_errors, function(v, k) {
                        $scope.OverviewData.store.ext_errors[k] = v;
                    });
                }
            });
            $scope.edit = function() {
                $scope.$emit("tabvalid", "/overview", $scope.form_overview.$valid);
                if ($scope.form_overview.$valid && !$scope.SaveData.contains($scope.OverviewData.store)) {
                    $scope.SaveData.push(type, {
                        data: $scope.OverviewData.store
                    });
                    $scope.$emit('tabchange', "/overview");
                }
            };
            // Launch filepicker
            $scope.openImgManager = function() {
                filepicker.pick({
                        extensions: ['jpg', 'jpeg', 'png', 'pjpeg', 'xpng', 'tiff'],
                        container: 'modal',
                        services: ['BOX', 'COMPUTER', 'DROPBOX', 'FACEBOOK', 'FLICKR', 'GOOGLE_DRIVE', 'PICASA']
                    },
                    function(InkBlob) {
                        $scope.image_crop_meta = {};
                        // Add topic to post parameters
                        InkBlob['topic'] = $scope.topic;
                        InkBlob['cropping_size'] = $scope.target_image_size.width + "," + $scope.target_image_size.height;
                        $scope.loading_image = true;
                        $scope.showCropModal();
                        $scope.$apply(
                            $http.post(
                                '/assets/img_file_upload/',
                                $.param(InkBlob), {
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }
                                }
                            ).success(function(obj) {
                                $scope.cropping = false;
                                if (obj.success) {
                                    $scope.image_crop_meta.editing_image = obj.data.cropping_image;
                                    $scope.image_crop_meta.editing_image_id = obj.data.asset_id;
                                    $scope.image_crop_meta.original_image_size = obj.data.orig_img_size;
                                    $scope.loading_image = false;
                                } else {
                                    $scope.image_crop_meta = {};
                                    $scope.OverviewData.upload_error = obj.error;
                                }
                            }).error(function(data, status) {
                                $scope.image_crop_meta = {};
                                $scope.OverviewData.upload_errors = "Error during image upload.";
                            })
                        );
                    },
                    function(FPError) {
                        console.log(FPError.toString());
                    }
                );
            };
            $scope.showCropModal = function() {
                var modalPromise = $modal({
                    template: '/static/apps/edit/partials/edit/crop_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    modalClass: 'large',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };
            $scope.addImage = function(data) {
                data['url'] = data.media;
                delete data.media;
                $scope.OverviewData.store.cover_image = data;
                if (!$scope.SaveData.contains($scope.OverviewData.store)) {
                    obj = {
                        "data": $scope.OverviewData.store.organization
                    };
                    $scope.SaveData.push('overview', obj);
                }
                $scope.$emit('tabchange', "/overview");
            };
            $scope.removeCoverImage = function() {
                $scope.OverviewData.store.image.url = "";
                $scope.OverviewData.store.image.id = null;
                $scope.edit($scope.OverviewData.store);
            };
            $scope.crop = function(id, measurements, target_image_size, $modal) {
                if ($scope.cropping) {
                    return;
                }
                $scope.cropping = true;
                var self = this;
                var defer = $q.defer();
                $http.post(
                    "/editor_v2/crop/", {
                        topic: $scope.topic,
                        id: id,
                        measurements: measurements,
                        target_image_size: target_image_size
                    }
                ).success(function(obj) {
                    if (obj.success) {
                        $modal('hide');
                        $scope.OverviewData.store.image.url = obj.data.image;
                        $scope.OverviewData.store.image.id = obj.data.thumbnail_id;
                        $scope.edit($scope.OverviewData.store);
                    } else {
                        $scope.cropping = false;
                        $scope.crop_error = true;
                        $scope.crop_error_msg = obj.data.error
                        $timeout(function() {
                            $scope.crop_error = false;
                        }, 5000);
                    }
                }).error(function() {});
            };
        }
    ])
    .controller('TeamCtrl', ["$scope", "TeamData",
        function($scope, TeamData) {
            $scope.TeamData = TeamData;
            var type = 'team';
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/team") {
                    if (!$scope.TeamData.active) {
                        $scope.TeamData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/team") {
                    $scope.TeamData.store = data;
                    $scope.TeamData.active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/team");
                $scope.TeamData.active = false;
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['teaminvite'])) {
                    t_errors = errors['teaminvite'];
                    _.each(t_errors, function(val, key) {
                        var invite = _.find($scope.TeamData.store.team_invites, function(i) {
                            return i.index === Number(key);
                        });
                        if (angular.isDefined(invite)) {
                            $scope.SaveData.remove(invite);
                            $scope.TeamData.store.team_invites = _.reject($scope.TeamData.store.team_invites, function(inv) {
                                return inv === invite;
                            });
                            invite.ext_errors = {};
                            _.each(t_errors[key], function(v, k) {
                                invite.ext_errors[k] = v;
                            });
                            $scope.tminvite = invite;
                        }
                    });
                }
            });
            var invite_index = 1;
            tminvite_model = {
                role: 'Administrator',
                first_name: '',
                last_name: '',
                email: '',
                index: angular.copy(invite_index)
            };
            $scope.tminvite = angular.copy(tminvite_model);
            $scope.changeTeamMember = function(role, member, action) {
                var change = {
                    "old_role": role,
                    "action": action,
                    "member": angular.copy(member)
                };
                $scope.SaveData.push(type, change);
                if (role == "Moderator") {
                    if (action == "move") {
                        $scope.TeamData.store.administrators.push(member);
                    }
                    $scope.TeamData.store.moderators = _.reject($scope.TeamData.store.moderators, function(mod) {
                        return mod === member;
                    });
                }
                if (role == "Administrator") {
                    if (action == "move") {
                        $scope.TeamData.store.moderators.push(member);
                    }
                    $scope.TeamData.store.administrators = _.reject($scope.TeamData.store.administrators, function(admin) {
                        return admin === member;
                    });
                }
                $scope.$emit('tabchange', "/team");
            };
            $scope.cancelTeamInvite = function(invite) {
                $scope.SaveData.push(type, {
                    action: "cancel",
                    member: angular.copy(invite)
                });
                $scope.TeamData.store.team_invites = _.reject($scope.TeamData.store.team_invites, function(admin) {
                    return admin === invite;
                });
                $scope.$emit('tabchange', "/team");
            };
            $scope.inviteTeamMember = function() {
                //Should maybe check if an invite to the email already exists 1st
                $scope.TeamData.store.team_invites.push(angular.copy($scope.tminvite));
                var invite = {
                    'action': 'new',
                    'member': angular.copy($scope.tminvite)
                };
                $scope.SaveData.push(type, invite);
                $scope.invite_team_member_form.$setPristine();
                invite_index++;
                $scope.tminvite = angular.copy(tminvite_model);
                $scope.tminvite.index = invite_index;
                $scope.$emit('tabchange', "/team");
            };
        }
    ])
    .controller('FeaturesCtrl', ["$scope", "FeaturesData",
        function($scope, FeaturesData) {
            $scope.FeaturesData = FeaturesData;
            var type = 'features';
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/features") {
                    if (!$scope.FeaturesData.active) {
                        $scope.FeaturesData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("saved", function() {
                if ($scope.FeaturesData.active) {
                    if (angular.isDefined($scope.FeaturesData.store.ext_errors)) {
                        delete $scope.FeaturesData.store.ext_errors;
                    }
                    $scope.form_features.$setPristine();
                }
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['features'])) {
                    f_errors = errors.features;
                    $scope.FeaturesData.store.ext_errors = {};
                    _.each(f_errors, function(v, k) {
                        $scope.FeaturesData.store.ext_errors[k] = v;
                    });
                }
            });
            //Write some validation to check if tab is active before selecting from dropdown
            $scope.$watch('form_features.$dirty', function(new_val, old_val) {
                if (new_val != old_val && new_val) {
                    $scope.$emit("tabvalid", "/features", $scope.form_features.$valid);
                    if (!$scope.SaveData.contains($scope.FeaturesData.store) && $scope.form_features.$valid) {
                        $scope.SaveData.push(type, {
                            "data": $scope.FeaturesData.store
                        });
                        $scope.$emit('tabchange', "/features");
                    }
                } else if (!new_val) {
                    $scope.$emit("tabreset", "/features");
                }
            });
        }
    ])
    .controller('ContactCtrl', ["$scope", "$modal", "$q", "$http", "$timeout", "ContactData",
        function($scope, $modal, $q, $http, $timeout, ContactData) {
            $scope.ContactData = ContactData;
            $scope.measurements = {};
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/contact") {
                    if (!$scope.ContactData.active) {
                        $scope.ContactData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$watch("form_all_contact.$valid + ' ' + form_all_contact.$dirty", function(n, o) {
                if (n !== o) {
                    $scope.$emit("tabvalid", "/contact", $scope.form_all_contact.$valid);
                    if ($scope.form_all_contact.$dirty) {
                        $scope.$emit('tabchange', "/contact");
                    } else {
                        $scope.$emit("tabreset", "/contact");
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/contact") {
                    index = 1;
                    _.each(data.contacts, function(contact) {
                        contact.index = index;
                        index++;
                    });
                    $scope.ContactData.store = data;
                    $scope.ContactData.next_index = index;
                    $scope.ContactData.active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/contact");
                $scope.ContactData.active = false;
                $scope.form_all_contact.$setPristine();
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['contact'])) {
                    c_errors = errors['contact'];
                    _.each(c_errors, function(val, key) {
                        contact = _.find($scope.ContactData.store.contacts, function(c) {
                            return c.index === Number(key);
                        });
                        if (angular.isDefined(contact)) {
                            contact.ext_errors = {};
                            _.each(c_errors[key], function(v, k) {
                                contact.ext_errors[k] = v;
                            });
                        }
                    });
                } else if (angular.isDefined(errors['organization'])) {
                    o_errors = errors['organization'];
                    $scope.ContactData.store.organization.ext_errors = {};
                    _.each(o_errors, function(v, k) {
                        $scope.ContactData.store.organization.ext_errors[k] = v;
                    });
                }
            });
            $scope.addContact = function() {
                if ($scope.form_contacts.$valid) {
                    obj = {
                        "email": "",
                        "first_name": "",
                        "last_name": "",
                        "mobile": "",
                        "phone": "",
                        "title": "",
                        "description": "",
                        "index": angular.copy($scope.ContactData.store.next_index)
                    };
                    $scope.ContactData.snext_index++;
                    $scope.form_contacts.$setDirty();
                    $scope.ContactData.store.contacts.unshift(obj);
                }
            };
            $scope.removeContact = function(contact) {
                //removes any entries in stack relating to the contact
                //This will include contacts which have just been created but not yet saved to the server
                $scope.SaveData.remove(contact);
                if (angular.isDefined(contact.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(contact)
                    };
                    $scope.SaveData.push('contact', obj);
                }
                //lo-dash.js function that returns array minus entries that are the same as contact
                $scope.ContactData.store.contacts = _.reject($scope.ContactData.store.contacts, function(c) {
                    return c === contact;
                });
                $scope.form_contacts.$setDirty();
                // Setting dirty manually doesn't seem to trigger watch so $emit manually as well
                $scope.$emit("tabvalid", "/contact", $scope.form_all_contact.$valid);
                $scope.$emit('tabchange', "/contact");
            };
            $scope.editOrgInfo = function() {
                if ($scope.form_organization.$valid) {
                    if (!$scope.SaveData.contains($scope.ContactData.store.organization)) {
                        obj = {
                            "action": "edit",
                            "data": $scope.ContactData.store.organization
                        };
                        $scope.SaveData.push('organization', obj);
                    }
                }
            };
            $scope.editContact = function(contact) {
                if ($scope.form_contacts.$valid) {
                    if (!$scope.SaveData.contains(contact)) {
                        //Need to figure out what happens if removed after a save, as real entries won't have an id
                        if (angular.isDefined(contact.id)) {
                            obj = {
                                "action": "edit",
                                "data": contact
                            };
                        } else {
                            obj = {
                                "action": "new",
                                "data": contact
                            };
                        }
                        $scope.SaveData.push('contact', obj);
                    }
                }
            };
            $scope.target_image_size = {
                width: 220,
                height: 105
            };
            // Launch filepicker
            $scope.openImgManager = function() {
                filepicker.pick({
                        extensions: ['jpg', 'jpeg', 'png', 'pjpeg', 'xpng', 'tiff'],
                        container: 'modal',
                        services: ['BOX', 'COMPUTER', 'DROPBOX', 'FACEBOOK', 'FLICKR', 'GOOGLE_DRIVE', 'PICASA']
                    },
                    function(InkBlob) {
                        $scope.image_crop_meta = {};
                        // Add topic to post parameters
                        InkBlob['topic'] = $scope.topic;
                        InkBlob['cropping_size'] = $scope.target_image_size.width + "," + $scope.target_image_size.height;
                        $scope.loading_image = true;
                        $scope.showCropModal();
                        $scope.$apply(
                            $http.post(
                                '/assets/img_file_upload/',
                                $.param(InkBlob), {
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }
                                }
                            ).success(function(obj) {
                                $scope.cropping = false;
                                if (obj.success) {
                                    $scope.image_crop_meta.editing_image = obj.data.cropping_image;
                                    $scope.image_crop_meta.editing_image_id = obj.data.asset_id;
                                    $scope.image_crop_meta.original_image_size = obj.data.orig_img_size;
                                    $scope.loading_image = false;
                                } else {
                                    $scope.image_crop_meta = {};
                                    $scope.OverviewData.upload_error = obj.error;
                                }
                            }).error(function(data, status) {
                                $scope.image_crop_meta = {};
                                $scope.OverviewData.upload_errors = "Error during image upload.";
                            })
                        );
                    },
                    function(FPError) {
                        console.log(FPError.toString());
                    });
            };
            $scope.showCropModal = function() {
                var modalPromise = $modal({
                    template: '/static/apps/edit/partials/edit/crop_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    modalClass: 'large',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };
            $scope.addImage = function(data) {
                $scope.ContactData.store.organization['logo'] = {
                    url: data.image,
                    id: data.asset_id
                };
                if (!$scope.SaveData.contains($scope.ContactData.store.organization)) {
                    obj = {
                        "action": "edit",
                        "data": $scope.ContactData.store.organization
                    };
                    $scope.SaveData.push('organization', obj);
                }
                $scope.$emit("tabvalid", "/contact", $scope.form_all_contact.$valid);
                $scope.$emit('tabchange', "/contact");
            };
            $scope.removeLogo = function() {
                $scope.ContactData.store.organization.logo = null;
                $scope.$emit("tabvalid", "/contact", $scope.form_all_contact.$valid);
                $scope.$emit('tabchange', "/contact");
            };
            $scope.crop = function(id, measurements, target_image_size, $modal) {
                if ($scope.cropping) {
                    return;
                }
                $scope.cropping = true;
                var self = this;
                var defer = $q.defer();
                $http.post(
                    "/editor_v2/crop/", {
                        topic: $scope.topic,
                        id: id,
                        measurements: measurements,
                        target_image_size: target_image_size
                    }
                ).success(function(obj) {

                    if (obj.success) {
                        $modal('hide');
                        $scope.addImage(obj.data);
                        $scope.image_crop_meta = {
                            editing_image: null,
                            editing_image_id: null,
                            original_image_size: null
                        };
                    } else {
                        $scope.cropping = false;
                        $scope.crop_error = true;
                        $scope.crop_error_msg = obj.data.error
                        $timeout(function() {
                            $scope.crop_error = false;
                        }, 5000);
                    }
                }).error(function() {});
            };
        }
    ])
    .controller('WhoCtrl', ["$scope", "WhoData",
        function($scope, WhoData) {
            $scope.WhoData = WhoData;
            uinvite = {
                role: "User"
            };
            $scope.uinvite = angular.copy(uinvite);
            var type = 'who';
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/who") {
                    if (!$scope.WhoData.active) {
                        $scope.WhoData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/who");
                if ($scope.WhoData.active) {
                    if (angular.isDefined($scope.WhoData.store.ext_errors)) {
                        delete $scope.WhoData.store.ext_errors;
                    }
                    $scope.form_all_who.$setPristine();
                }
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['who'])) {
                    w_errors = errors['who'];
                    $scope.WhoData.store.ext_errors = {};
                    _.each(w_errors, function(v, k) {
                        $scope.WhoData.store.ext_errors[k] = v;
                    });
                }
            });
            $scope.$watch("form_all_who.$valid + ' ' + form_all_who.$dirty", function(n, o) {
                if (n !== o) {
                    $scope.$emit("tabvalid", "/who", $scope.form_all_who.$valid);
                    if ($scope.form_all_who.$dirty) {
                        $scope.$emit('tabchange', "/who");
                        if ($scope.form_all_who.$valid && !$scope.SaveData.contains($scope.WhoData.store)) {
                            $scope.SaveData.push(type, {
                                "data": $scope.WhoData.store
                            });
                        }
                    } else {
                        $scope.$emit("tabreset", "/who");
                    }
                }
            });
            $scope.contributeChange = function() {
                $scope.$emit("tabvalid", $scope.current_tab, $scope.form_contribute.$valid);
                if (!$scope.SaveData.contains($scope.WhoData.store)) {
                    $scope.SaveData.push(type, {
                        "data": $scope.WhoData.store
                    });
                    $scope.$emit('tabchange', $scope.current_tab);
                }
            };
            $scope.inviteUser = function() {
                if ($scope.uinvite.disabled) return;
                var data = {
                    data: angular.copy($scope.uinvite)
                };
                $scope.SaveData.push("uinvite", data);
                $scope.form_userinvite.$setPristine();
                $scope.uinvite = angular.copy(uinvite);
                $scope.$emit('tabchange', $scope.current_tab);
            };
        }
    ])
    .controller('KeywordsCtrl', ["$scope", "KeywordsData",
        function($scope, KeywordsData) {
            $scope.KeywordsData = KeywordsData;
            $scope.selected_keywords = [];
            $scope.max_number = false;
            $scope.typeaheadValue = "";
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/keywords") {
                    if (!$scope.KeywordsData.active) {
                        $scope.KeywordsData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/keywords") {
                    $scope.KeywordsData.store = data;
                    $scope.KeywordsData.active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/keywords");
                $scope.KeywordsData.active = false;
            });
            $scope.containsKeyword = function(keyword) {
                return _.contains($scope.selected_keywords, keyword);
            };
            $scope.clickKeyword = function(keyword) {
                if ($scope.containsKeyword(keyword)) {
                    $scope.selected_keywords = _.reject($scope.selected_keywords, function(k) {
                        return k === keyword;
                    });
                } else {
                    if (!$scope.isFull()) {
                        $scope.selected_keywords.push(keyword);
                    } else {
                        $scope.max_number = true;
                    }
                }
            };
            $scope.removeKeyword = function(keyword) {
                $scope.SaveData.remove(keyword);
                if (angular.isDefined(keyword.tkid)) {
                    $scope.SaveData.push('keyword', {
                        action: "delete",
                        data: keyword
                    });
                }
                $scope.KeywordsData.store.current_keywords = _.reject($scope.KeywordsData.store.current_keywords, function(k) {
                    return k === keyword;
                });
                $scope.KeywordsData.store.recommended_keywords.push(keyword);
                $scope.$emit('tabchange', $scope.current_tab);
            };
            $scope.moveKeywords = function() {
                _.each($scope.selected_keywords, function(sel) {
                    $scope.KeywordsData.store.recommended_keywords = _.reject($scope.KeywordsData.store.recommended_keywords, function(k) {
                        return k === sel;
                    });
                    $scope.SaveData.push('keyword', {
                        action: "add",
                        data: sel
                    });
                    $scope.KeywordsData.store.current_keywords.push(sel);
                });
                $scope.selected_keywords = [];
                $scope.$emit('tabchange', $scope.current_tab);
            };
            $scope.addKeyword = function() {
                if (!$scope.isFull()) {
                    duplicate = angular.isDefined(_.find($scope.KeywordsData.store.current_keywords, function(k) {
                        return k.word === $scope.typeaheadValue;
                    }));
                    if (duplicate) {
                        //Do something
                        return;
                    }
                    kw = _.find(_.extend($scope.KeywordsData.store.all_keywords, $scope.KeywordsData.store.recommended_keywords), function(k) {
                        return k.word === $scope.typeaheadValue;
                    });
                    if (angular.isDefined(kw)) {
                        $scope.SaveData.push('keyword', {
                            action: "add",
                            data: kw
                        });
                        $scope.KeywordsData.store.all_keywords = _.reject($scope.KeywordsData.store.all_keywords, function(k) {
                            return k === kw;
                        });
                    } else {
                        kw = {
                            word: $scope.typeaheadValue
                        };
                        $scope.SaveData.push('keyword', {
                            action: "new",
                            data: kw
                        });
                    }
                    $scope.KeywordsData.store.current_keywords.push(kw);
                    $scope.typeaheadValue = "";
                    $scope.$emit('tabchange', $scope.current_tab);
                } else {
                    $scope.max_number = true;
                }
            };
            $scope.typeahead = function(query) {
                return _.map($scope.KeywordsData.store.all_keywords, function(kw) {
                    return kw.word;
                });
            };
            $scope.isFull = function() {
                if (($scope.selected_keywords.length + $scope.KeywordsData.store.current_keywords.length) < 5) {
                    return false;
                } else {
                    return true;
                }
            };
        }
    ])
    .controller('FSSettingsCtrl', ["$scope", "$q", "$http", "SurveyData",
        function($scope, $q, $http, SurveyData) {
            $scope.connecting = false;
            $scope.saveFSSettings = function() {
                if ($scope.connecting) {
                    return;
                }
                $scope.connecting = true;
                var self = this;
                var defer = $q.defer();
                delete $scope.SurveyData.store.fluidsurveys_api.errors;
                $http.post(
                    "/editor_v2/surveys/fluidsurveys/connect/", {
                        topic: $scope.topic,
                        data: $scope.SurveyData.store.fluidsurveys_api
                    }
                ).success(function(obj) {
                    if (obj.success) {
                        $scope.SurveyData.loadFluidSurveys();
                        $scope.SurveyData.store.fluidsurveys_api.api.new_password = null;
                        $scope.SurveyData.store.fluidsurveys_api.id = obj.data.topicapikey_id;
                        delete $scope.SurveyData.store.fluidsurveys_ts;
                        $scope.$modal('hide');
                    } else {
                        if (obj.message.length == 0) {
                            $scope.SurveyData.store.fluidsurveys_api.errors = [
                              'Failed to connect to FluidSurveys account.'
                            ];
                        } else {
                            $scope.SurveyData.store.fluidsurveys_api.errors = _.values(obj.message);
                        }
                    }
                    $scope.connecting = false;
                }).error(function() {
                    $scope.connecting = false;
                });
            };
        }
    ])
    .controller('SurveysCtrl', ["$scope", "$q", "$http", "$modal", "SurveyData",
        function($scope, $q, $http, $modal, SurveyData) {
            $scope.topic = data.topic;
            var type = 'surveys';
            $scope.SurveyData = SurveyData;
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/surveys") {
                    if (!$scope.SurveyData.active) {
                        $scope.SurveyData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/surveys");
                $scope.SurveyData.active = false;
            });
            $scope.showFSConnect = function() {
                var modalPromise = $modal({
                    template: '/static/apps/edit/partials/edit/fs_connect_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };
            $scope.disconnectFS = function() {
                var self = this;
                var defer = $q.defer();
                $http.post(
                    "/editor_v2/surveys/fluidsurveys/disconnect/", {
                        topic: $scope.topic,
                        data: $scope.SurveyData.store.fluidsurveys_api
                    }
                ).success(function(obj) {
                    if (obj.success) {
                        $scope.SurveyData.store.fluidsurveys_api.api.api = null;
                        $scope.SurveyData.store.fluidsurveys_api.api.new_password = null;
                        $scope.SurveyData.store.fluidsurveys_api.id = null;
                        $scope.SurveyData.store.fluidsurveys_ts = [];
                    } else {}
                });
            };
            $scope.newLimesurvey = function() {
                $http({
                    method: 'POST',
                    url: '/editor_v2/surveys/limesurvey/add/',
                    data: $.param({
                        topic: $scope.topic,
                        ls_title: 'New Survey'
                    })
                }).success(function(obj) {
                    if (obj.success) {
                        $scope.SurveyData.store.limesurvey_ts.unshift(obj.data.limesurvey_ts);
                        // Doesn't need to save b/c it's automatic at this point
                    } else {
                        $scope.SurveyData.store.limesurvey.errors = obj.data['errors'];
                    }
                }).error(function() {});
            };
            $scope.confirmRemove = function(survey) {
                $scope.modal = {
                    'title': "Remove survey",
                    'content': "Are you sure you want to remove " + survey.title + "?",
                    'item': survey
                }
                $scope.modal.confirm = function(survey) {
                    var change = {
                        data: angular.copy(survey),
                        action: "delete",
                    };
                    $scope.SaveData.push(type, change);
                    $scope.$emit('tabchange', $scope.current_tab);
                    $scope.SurveyData.store.limesurvey_ts.pop($scope.SurveyData.store.limesurvey_ts.indexOf(survey));
                };
                var modal = $modal({
                    template: '/static/apps/edit/partials/edit/e_confirmation_modal.html',
                    show: true,
                    backdrop: 'static',
                    scope: $scope
                });
            };
            $scope.edit = function(survey) {
                if ($scope.form_ls_surveys.$valid) {
                    if (!$scope.SaveData.contains(survey)) {
                        $scope.SaveData.push(type, {
                            data: survey,
                            action: "edit"
                        });
                        $scope.$emit('tabchange', $scope.current_tab);
                    }
                }
            };
            $scope.setSurveyPublished = function(survey, is_published) {
                if (is_published === survey.is_published) {
                    return;
                };
                _.each($scope.SurveyData.store.limesurvey_ts, function(v) {
                    v.is_published = false;
                });
                if (_.has($scope.SurveyData.store, "fluidsurveys_ts")) {
                    _.each($scope.SurveyData.store.fluidsurveys_ts, function(v) {
                        v.is_published = false;
                    });
                };
                survey.is_published = is_published;
                if (is_published) {
                    $scope.SurveyData.published_survey = survey;
                }
                $scope.SaveData.push(type, {
                    data: survey,
                    action: "edit"
                });
                $scope.$emit('tabchange', $scope.current_tab);
            };
        }
    ])
    .controller('DiscussionsCtrl', ["$scope", "DiscussionData",
        function($scope, DiscussionData) {
            var type = 'discussion';
            new_discussion = {
                title: "",
                content: ""
            };
            $scope.DiscussionData = DiscussionData;
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/discussions") {
                    if (!$scope.DiscussionData.active) {
                        $scope.DiscussionData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/discussions") {
                    index = 1;
                    _.each(data, function(dis) {
                        dis.index = index;
                        index++;
                    });
                    $scope.DiscussionData.store = data;
                    $scope.DiscussionData.next_index = index;
                    $scope.DiscussionData.active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.DiscussionData.active = false;
                $scope.form_discussion.$setPristine();
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['discussions'])) {
                    d_errors = errors['discussions'];
                    _.each(d_errors, function(val, key) {
                        forum = _.find($scope.DiscussionData.store, function(d) {
                            return d.index === Number(key);
                        });
                        if (angular.isDefined(forum)) {
                            thread.ext_errors = {};
                            _.each(d_errors[key], function(v, k) {
                                thread.ext_errors[k] = v;
                            });
                        }
                    });
                }
            });
            $scope.$watch("form_discussion.$dirty + ' ' + form_discussion.$valid", function(n, o) {
                if (o !== n) {
                    if ($scope.form_discussion.$dirty) {
                        $scope.$emit("tabvalid", "/discussions", $scope.form_discussion.$valid);
                        $scope.$emit('tabchange', "/discussions");
                    } else {
                        $scope.$emit("tabreset", "/discussions");
                    }
                }
            });
            $scope.newDiscussion = function() {
                if ($scope.form_discussion.$valid) {
                    dis = angular.copy(new_discussion);
                    dis.index = angular.copy($scope.DiscussionData.store.next_index);
                    $scope.DiscussionData.store.next_index++;
                    $scope.DiscussionData.store.unshift(dis);
                }
            };
            $scope.edit = function(thread) {
                if ($scope.form_discussion.$valid) {
                    if (!$scope.SaveData.contains(thread)) {
                        if (angular.isDefined(thread.id)) {
                            action = "edit";
                        } else {
                            action = "new";
                        }
                        $scope.SaveData.push(type, {
                            data: thread,
                            action: action
                        });
                    }
                }
            };
            $scope.removeDiscussion = function(thread) {
                $scope.SaveData.remove(thread);
                if (angular.isDefined(thread.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(thread)
                    };
                    $scope.SaveData.push('discussion', obj);
                }
                $scope.$emit('tabchange', "/discussions");
                $scope.DiscussionData.store = _.reject($scope.DiscussionData.store, function(f) {
                    return f === thread;
                });
            };
        }
    ])
    .controller('EventsCtrl', ["$scope", "EventData",
        function($scope, EventData) {
            var type = 'event';
            new_event = {
                description: "",
                event_date: null,
                start_with_tz: null,
                end_with_tz: null,
                title: ""
            };
            $scope.EventData = EventData;
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/events") {
                    if (!$scope.EventData.active) {
                        $scope.EventData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$watch("form_events.$dirty + ' ' + form_events.$valid", function(n, o) {
                if (o !== n) {
                    if ($scope.form_events.$dirty) {
                        $scope.$emit("tabvalid", $scope.current_tab, $scope.form_events.$valid);
                        $scope.$emit('tabchange', $scope.current_tab);
                    } else {
                        $scope.$emit("tabreset", "/events");
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/events") {
                    var index = 1;
                    _.each(data, function(evt) {
                        if(evt.start_with_tz){
                            evt.start_with_tz = new Date(evt.start_with_tz);
                        }
                        if(evt.end_with_tz){
                            evt.end_with_tz = new Date(evt.end_with_tz);
                        }
                        if(evt.event_date){
                           evt.event_date = new Date(evt.event_date);
                        }
                        evt.index = index;
                        index++;
                    });
                    $scope.EventData.store = data;
                    $scope.EventData.next_index = index;
                    $scope.EventData.active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/events");
                $scope.EventData.active = false;
                $scope.form_events.$setPristine();
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['events'])) {
                    e_errors = errors['events'];
                    _.each(e_errors, function(val, key) {
                        evt = _.find($scope.EventData.store, function(e) {
                            return e.index === Number(key);
                        });
                        if (angular.isDefined(evt)) {
                            evt.ext_errors = {};
                            _.each(e_errors[key], function(v, k) {
                                evt.ext_errors[k] = v;
                            });
                        }
                    });
                }
            });
            $scope.edit = function(event) {
                if ($scope.form_events.$valid) {
                    if(!angular.isDefined($scope.dirty_tabs["/events"])){
                        $scope.$emit("tabvalid", $scope.current_tab, $scope.form_events.$valid);
                        $scope.$emit('tabchange', $scope.current_tab);
                    }
                    if (!$scope.SaveData.contains(event)) {
                        if (angular.isDefined(event.id)) {
                            action = "edit";
                        } else {
                            action = "new";
                        }
                        $scope.SaveData.push(type, {
                            data: event,
                            action: action
                        });
                    }
                }
            };
            $scope.newEvent = function() {
                if ($scope.form_events.$valid) {
                    evt = angular.copy(new_event);
                    evt.index = angular.copy($scope.EventData.next_index);
                    $scope.EventData.store.unshift(evt);
                    $scope.EventData.next_index++;
                }
            };
            $scope.removeEvent = function(evt) {
                $scope.SaveData.remove(evt);
                if (angular.isDefined(evt.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(evt)
                    };
                    $scope.SaveData.push('event', obj);
                }
                $scope.$emit('tabchange', "/events");
                $scope.EventData.store = _.reject($scope.EventData.store, function(e) {
                    return e === evt;
                });
            }
        }
    ])
    .controller('ResourcesCtrl', ["$scope", "ResourceData",
        function($scope, ResourceData) {
            $scope.ResourceData = ResourceData;
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/resources") {
                    if (!$scope.ResourceData.active) {
                        $scope.ResourceData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            $scope.$watch("form_all_resources.$dirty + ' ' + form_all_resources.$valid", function(n, o) {
                if (o !== n) {
                    $scope.$emit("tabvalid", "/resources", $scope.form_all_resources.$valid);
                    if ($scope.form_all_resources.$dirty) {
                        $scope.$emit("tabchange", "/resources", $scope);
                    } else {
                        $scope.$emit("tabreset", "/resources");
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/resources") {
                    var vindex = 1;
                    _.each(data.videos, function(vid) {
                        vid.index = vindex;
                        vindex++;
                    });
                    var lindex = 1;
                    _.each(data.links, function(link) {
                        link.index = lindex;
                        lindex++;
                    });
                    $scope.ResourceData.store = data;
                    $scope.ResourceData.store.next_vid_index = vindex;
                    $scope.ResourceData.store.next_link_index = lindex;
                    $scope.ResourceData.is_active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/resources");
                $scope.ResourceData.active = false;
                $scope.form_all_resources.$setPristine();
            });
        }
    ])
    .controller('ImgResourceCtrl', ["$scope", "$http", "ResourceData",
        function($scope, $http, ResourceData) {
            var new_img = {
                title: '',
                description: '',
                url: '/static/img/ajax-loader-ps.gif',
                id: null,
                name: null
            };
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['image'])) {
                    i_errors = errors['image'];
                    _.each(i_errors, function(val, key) {
                        img = _.find($scope.ResourceData.store.images, function(i) {
                            return i.id === Number(key);
                        });
                        if (angular.isDefined(img)) {
                            img.ext_errors = {};
                            _.each(i_errors[key], function(v, k) {
                                img.ext_errors[k] = v;
                            });
                        }
                    });
                }
            });
            // Launch filepicker
            $scope.openImgManager = function() {
                filepicker.pick({
                        extensions: ['jpg', 'jpeg', 'png', 'pjpeg', 'xpng', 'tiff', 'gif'],
                        container: 'modal',
                        services: ['BOX', 'COMPUTER', 'DROPBOX', 'FACEBOOK', 'FLICKR', 'GOOGLE_DRIVE', 'PICASA']
                    },
                    function(InkBlob) {
                        $scope.image_crop_meta = {};
                        // Add topic to post parameters
                        InkBlob['topic'] = $scope.topic;
                        $scope.addImage(angular.copy(new_img));
                        $scope.$emit("tabvalid", "/resources", false);
                        var img = $scope.ResourceData.store.images[0];
                        // Generate some thumbnails
                        InkBlob['thumbnails'] = "580x435,100x100"
                        $scope.loading_image = true;
                        $scope.$apply(
                            $http.post(
                                '/assets/img_file_upload/',
                                $.param(InkBlob), {
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }
                                }
                            ).success(function(obj) {
                                if (obj.success) {
                                    img.url = obj.data.thumbnails["100_100"].url;
                                    img.id = obj.data.asset_id;
                                    $scope.$emit("tabvalid", "/resources", $scope.form_all_resources.$valid);
                                } else {
                                    $scope.ResourceData.upload_error = obj.error;
                                }
                            }).error(function(data, status) {
                                $scope.ResourceData.upload_errors = "Error during image upload.";
                            })
                        );
                    },
                    function(FPError) {
                        console.log(FPError.toString());
                    }
                );
            };
            $scope.addImage = function(data) {
                $scope.ResourceData.store.images.unshift(data);
                $scope.SaveData.push('image', {
                    action: "new",
                    data: data
                });
                $scope.$emit('tabchange', "/resources");
            };
            $scope.removeImage = function(image) {
                $scope.SaveData.remove(image);
                obj = {
                    "action": "delete",
                    "data": angular.copy(image)
                };
                $scope.SaveData.push('image', obj);
                $scope.ResourceData.store.images = _.reject($scope.ResourceData.store.images, function(i) {
                    return i === image;
                });
                $scope.$emit('tabchange', "/resources");
            };
            $scope.editImage = function(image) {
                if ($scope.form_images.$valid) {
                    if (!$scope.SaveData.contains(image)) {
                        $scope.SaveData.push("image", {
                            data: image,
                            action: "edit"
                        });
                        $scope.$emit('tabchange', "/resources");
                    }
                }
            };
        }
    ])
    .controller('VideoResourceCtrl', ["$scope", "ResourceData",
        function($scope, ResourceData) {
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['video'])) {
                    v_errors = errors['video'];
                    _.each(v_errors, function(val, key) {
                        video = _.find($scope.ResourceData.store.videos, function(v) {
                            return v.index === Number(key);
                        });
                        if (angular.isDefined(video)) {
                            video.ext_errors = {};
                            _.each(v_errors[key], function(v, k) {
                                video.ext_errors[k] = v;
                            });
                        }
                    });
                }
            })
            $scope.addVideo = function() {
                if ($scope.form_video_url.$valid) {
                    var video = {
                        link: $scope.new_video,
                        title: "",
                        description: "",
                        index: angular.copy($scope.ResourceData.store.next_vid_index)
                    };
                    $scope.ResourceData.store.next_vid_index++;
                    $scope.ResourceData.store.videos.unshift(video);
                    $scope.new_video = "";
                    $scope.form_video_url.$setPristine();
                    $scope.form_videos.$setDirty();
                }
            };
            $scope.removeVideo = function(video) {
                $scope.SaveData.remove(video);
                if (angular.isDefined(video.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(video)
                    };
                    $scope.SaveData.push('video', obj);
                    $scope.$emit("tabchange", "/resources", $scope);
                }
                $scope.ResourceData.store.videos = _.reject($scope.ResourceData.store.videos, function(v) {
                    return v === video;
                });
            };
            $scope.editVideo = function(video) {
                if ($scope.form_videos.$valid) {
                    if (!$scope.SaveData.contains(video)) {
                        if (angular.isDefined(video.id)) {
                            action = "edit";
                        } else {
                            action = "new";
                        }
                        $scope.SaveData.push("video", {
                            data: video,
                            action: action
                        });
                    }
                }
            };
        }
    ])
    .controller('LinksResourceCtrl', ["$scope", "ResourceData",
        function($scope, ResourceData) {
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['link'])) {
                    l_errors = errors['link'];
                    _.each(l_errors, function(val, key) {
                        link = _.find($scope.ResourceData.store.links, function(l) {
                            return l.index === Number(key);
                        });
                        if (angular.isDefined(link)) {
                            link.ext_errors = {};
                            _.each(l_errors[key], function(v, k) {
                                link.ext_errors[k] = v;
                            });
                        }
                    });
                }
            });
            $scope.removeLink = function(link) {
                $scope.SaveData.remove(link);
                if (angular.isDefined(link.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(link)
                    };
                    $scope.SaveData.push('link', obj);
                    $scope.$emit("tabchange", "/resources", $scope);
                }
                $scope.ResourceData.store.links = _.reject($scope.ResourceData.store.links, function(l) {
                    return l === link;
                });
            };
            $scope.editLink = function(link) {
                if ($scope.form_links.$valid) {
                    if (!$scope.SaveData.contains(link)) {
                        if (angular.isDefined(link.id)) {
                            action = "edit";
                        } else {
                            action = "new";
                        }
                        $scope.SaveData.push("link", {
                            data: link,
                            action: action
                        });
                    }
                }
            };
            $scope.addLink = function() {
                if ($scope.form_links.$valid) {
                    $scope.ResourceData.store.links.unshift({
                        title: "",
                        url: "",
                        index: angular.copy($scope.ResourceData.store.next_link_index)
                    });
                    $scope.ResourceData.store.next_link_index++;
                    $scope.form_links.$setDirty();
                }
            };
        }
    ])
    .controller('DocumentsResourceCtrl', ["$scope", "$http", "ResourceData",
        function($scope, $http, ResourceData) {
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['document'])) {
                    d_errors = errors['document'];
                    _.each(d_errors, function(val, key) {
                        doc = _.find($scope.ResourceData.store.documents, function(d) {
                            return d.id === Number(key);
                        });
                        if (angular.isDefined(doc)) {
                            doc.ext_errors = {};
                            _.each(d_errors[key], function(v, k) {
                                doc.ext_errors[k] = v;
                            });
                        }
                    });
                }
            });
            $scope.openFilePicker = function() {
                filepicker.pick({
                        extensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'xml'],
                        container: 'modal',
                        services: ['BOX', 'COMPUTER', 'DROPBOX', 'GOOGLE_DRIVE']
                    },
                    function(InkBlob) {
                        InkBlob['topic'] = $scope.topic;
                        $scope.newDocument(InkBlob);
                        var doc = $scope.ResourceData.store.documents[0];
                        $scope.$apply(
                            $http.post(
                                '/assets/doc_file_upload/',
                                $.param(InkBlob), {
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }
                                }
                            ).success(function(obj) {
                                if (obj.success) {
                                    doc.url = obj.data.url;
                                    doc.id = obj.data.asset_id;
                                } else {
                                    $scope.ResourceData.upload_error = obj.error;
                                }
                            }).error(function(data, status) {
                                $scope.ResourceData.upload_errors = "Error during image upload.";
                            })
                        );
                    },
                    function(FPError) {
                        console.log(FPError.toString());
                    }
                );
            };
            $scope.newDocument = function(data) {
                var doc = {
                    url: null,
                    name: data.filename,
                    title: "",
                    id: null,
                    description: ""
                };
                $scope.SaveData.push('document', {
                    action: "new",
                    data: doc
                });
                $scope.ResourceData.store.documents.unshift(doc);
                $scope.$emit('tabchange', "/resources");
            };
            $scope.removeDocument = function(doc) {
                $scope.SaveData.remove(doc);
                //Need to figure out what happens if removed after a save, as real entries won't have an id
                if (angular.isDefined(doc.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(doc)
                    };
                    $scope.SaveData.push('document', obj);
                    $scope.$emit('tabchange', "/resources");
                }
                $scope.ResourceData.store.documents = _.reject($scope.ResourceData.store.documents, function(d) {
                    return d === doc;
                });
            };
            $scope.editDocument = function(doc) {
                if ($scope.form_documents.$valid) {
                    if (!$scope.SaveData.contains(doc)) {
                        if (angular.isDefined(doc.id)) {
                            action = "edit";
                        } else {
                            action = "new";
                        }
                        $scope.SaveData.push("document", {
                            data: doc,
                            action: action
                        });
                    }
                }
            };
        }
    ])
    .controller('SocialCtrl', ["$scope", "SocialData",
        function($scope, SocialData) {
            $scope.SocialData = SocialData;
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/social") {
                    if (!$scope.SocialData.active) {
                        $scope.SocialData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            //Parent form for all subforms
            $scope.$watch("form_all_social.$dirty + ' ' + form_all_social.$valid", function(n, o) {
                if (o !== n) {
                    $scope.$emit("tabvalid", "/social", $scope.form_all_social.$valid);
                    if ($scope.form_all_social.$dirty) {
                        $scope.$emit("tabchange", "/social");
                    } else {
                        $scope.$emit("tabreset", "/social");
                    }
                }
            });
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/social") {
                    var index = 1;
                    _.each(data.twitterparams, function(tp) {
                        tp.index = index;
                        index++;
                    });
                    $scope.SocialData.store = data;
                    $scope.SocialData.next_index = index;
                    $scope.SocialData.active = true;
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/social");
                if ($scope.SocialData.active) {
                    if (angular.isDefined($scope.SocialData.store.facebook.ext_errors)) {
                        delete $scope.SocialData.store.facebook.ext_errors;
                    }
                    $scope.form_all_social.$setPristine();
                }
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['twitterparam'])) {
                    tp_errors = errors['twitterparam'];
                    _.each(tp_errors, function(val, key) {
                        tp = _.find($scope.SocialData.store.twitterparams, function(param) {
                            return param.index === Number(key);
                        });
                        if (angular.isDefined(tp)) {
                            tp.ext_errors = {};
                            _.each(tp_errors[key], function(v, k) {
                                tp.ext_errors[k] = v;
                            });
                        }
                    });
                }
                if (angular.isDefined(errors['facebook'])) {
                    fb_errors = errors['facebook'];
                    fb = $scope.SocialData.store.facebook;
                    fb.ext_errors = {};
                    _.each(fb_errors, function(v, k) {
                        fb.ext_errors[k] = v;
                    });
                }
            });
            $scope.addTwitterParam = function() {
                if ($scope.form_twitter.$valid) {
                    $scope.SocialData.store.twitterparams.unshift({
                        parameter: "",
                        index: angular.copy($scope.SocialData.next_index)
                    });
                    $scope.SocialData.next_index++;
                    $scope.form_twitter.$setDirty();
                }
            };
            $scope.editParam = function(param) {
                if ($scope.form_twitter.$valid && !$scope.SaveData.contains(param)) {
                    var action;
                    if (angular.isDefined(param.id)) {
                        action = "edit";
                    } else {
                        action = "new";
                    }
                    var obj = {
                        "action": action,
                        "data": param
                    };
                    $scope.SaveData.push('twitterparam', obj);
                    $scope.form_twitter.$setPristine();
                }
            };
            $scope.removeTwitterParam = function(param) {
                $scope.SaveData.remove(param);
                if (angular.isDefined(param.id)) {
                    obj = {
                        "action": "delete",
                        "data": angular.copy(param)
                    };
                    $scope.SaveData.push('twitterparam', obj);
                }
                $scope.$emit("tabchange", "/social");
                $scope.SocialData.store.twitterparams = _.reject($scope.SocialData.store.twitterparams, function(p) {
                    return p === param;
                });
            };
            $scope.editFacebook = function() {
                if ($scope.form_facebook.$valid && !$scope.SaveData.contains($scope.SocialData.store.facebook)) {
                    $scope.SaveData.push('facebook', {
                        action: 'edit',
                        data: $scope.SocialData.store.facebook
                    });
                }
            };
        }
    ])
    .controller('PollsCtrl', ["$scope", "$modal", "$q", "PollData",
        function($scope, $modal, $q, PollData) {
            $scope.$on("dataupdate", function(e, tab, data) {
                if (tab === "/polls") {
                    $scope.PollData.store = data;
                    $scope.PollData.active = true;
                }
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['poll'])) {
                    $scope.new_poll.ext_errors = {};
                    p_errors = errors['poll'];
                    _.each(p_errors, function(err) {
                        _.each(err, function(v, k) {
                            $scope.new_poll.ext_errors[k] = v;
                        });
                    });
                }
                if (angular.isDefined(errors['choice'])) {
                    ch_errors = errors['choice'];
                    _.each(ch_errors, function(val, key) {
                        choice = _.find($scope.new_poll.choices, function(ch) {
                            return ch.index === Number(key);
                        });
                        if (angular.isDefined(choice)) {
                            choice.ext_errors = {};
                            _.each(ch_errors[key], function(v, k) {
                                choice.ext_errors[k] = v;
                            });
                        }
                    });
                }
            });
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/polls");
                $scope.PollData.active = false;
            });
            $scope.createNewPoll = function() {
                $scope.new_poll = angular.copy(new_poll);
            };
            $scope.addChoice = function() {
                if ($scope.form_new_poll.$valid || $scope.new_poll.choices.length === 0) {
                    $scope.new_poll.choices.push({
                        choice: "",
                        index: index
                    });
                    index++;
                }
            };
            $scope.removeChoice = function(choice) {
                $scope.new_poll.choices = _.reject($scope.new_poll.choices, function(c) {
                    return c === choice;
                });
            };
            $scope.publishPoll = function() {
                if ($scope.form_new_poll.$valid && $scope.new_poll.choices.length >= 2) {
                    if ($scope.PollData.store.live !== null) {
                        var modalPromise = $modal({
                            template: '/static/apps/edit/partials/edit/close_poll_modal.html',
                            persist: true,
                            show: false,
                            backdrop: 'static',
                            scope: $scope
                        });
                        $q.when(modalPromise).then(function(modalEl) {
                            modalEl.modal('show');
                        });
                    } else {
                        $scope.continuePublishPoll(null);
                    }
                }
            };
            $scope.continuePublishPoll = function(modal) {
                if (modal) {
                    modal('hide');
                }
                $scope.closePoll();
                $scope.PollData.store.live = angular.copy($scope.new_poll);
                $scope.SaveData.push(type, {
                    action: "new",
                    data: angular.copy($scope.PollData.store.live)
                });
                $scope.createNewPoll();
                $scope.form_new_poll.$setPristine();
                $scope.$emit('tabchange', "/polls");
            }
            $scope.closePoll = function() {
                if ($scope.PollData.store.live !== null) {
                    poll = angular.copy($scope.PollData.store.live);
                    $scope.PollData.store.closed.push(poll);
                    $scope.SaveData.push(type, {
                        action: "close",
                        data: poll
                    });
                    $scope.PollData.store.live = null;
                    $scope.$emit('tabchange', "/polls");
                }
            };
            var new_poll = {
                question: "",
                choices: [{
                    choice: "",
                    index: 1
                }, {
                    choice: "",
                    index: 2
                }]
            };
            var index = 3;
            var type = "poll";
            $scope.PollData = PollData;
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/polls") {
                    if (!$scope.PollData.active) {
                        $scope.PollData.load($scope.topic).then(function(obj) {
                            $scope.createNewPoll();
                        }, function(reason) {});
                    }
                }
            });
        }
    ])
    .controller('ParticipantsCtrl', ["$scope", "ParticipantData",
        function($scope, ParticipantData) {
            $scope.ParticipantData = ParticipantData;
            $scope.orderBy = "name";
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/participants") {
                    if (!$scope.ParticipantData.active) {
                        $scope.ParticipantData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            // dynamicSortMultiple() lives in helpers.js
            $scope.orderByName = function() {
                if ($scope.orderBy != "name") {
                    $scope.ParticipantData.store.participants.sort(dynamicSortMultiple("first_name", "last_name"));
                    $scope.orderBy = "name";
                }
            };
            $scope.orderByPolygon = function() {
                if ($scope.orderBy != "polygon") {
                    $scope.ParticipantData.store.participants.sort(dynamicSortMultiple("label", "first_name", "last_name"));
                    $scope.orderBy = "polygon";
                }
            };
        }
    ])
    .controller('WidgetsCtrl', ["$scope",
        function($scope) {
            //Need to figure out height
            $scope.widget = {
                width: 200,
                abstract: true,
                stats: true,
                map: true,
                help: 0,
                title: angular.copy($scope.header.title)
            };
            $scope.updateWidget = function() {
                $scope.url = "/ps_widgets/topic_widget/" + $scope.topic + "/" +
                    $scope.widget.width + "/?abstract=" + $scope.widget.abstract + "&map=" +
                    $scope.widget.map + "&stats=" + $scope.widget.stats + "&help=" + Number($scope.widget.help) + "&title=" +
                    encodeURIComponent($scope.widget.title);
                $scope.creationUrl = $scope.url + "&creation=true";
            };
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/widgets") {
                    $scope.updateWidget();
                }
            });
        }
    ])
    .controller('ReportsCtrl', ["$scope", "ReportData",
        function($scope, ReportData) {
            $scope.ReportData = ReportData;
            $scope.$on("saved", function() {
                $scope.$emit("tabreset", "/reports");
                $scope.form_analytics.$setPristine();
            });
            $scope.$on("saveerrors", function(e, errors) {
                if (angular.isDefined(errors['reports'])) {
                    reports_errors = errors['reports'];
                    reports = $scope.ReportData.store;
                    reports.ext_errors = {};
                    _.each(reports_errors, function(v, k) {
                        reports.ext_errors[k] = v;
                    });
                }
            });
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/reports") {
                    if (!$scope.ReportData.active) {
                        $scope.ReportData.load($scope.topic).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            //have to pass entire object to stack so .contains() can work - can maybe do something different
            $scope.updateAnalytics = function() {
                $scope.$emit("tabvalid", "/reports", $scope.form_analytics.$valid);
                if ($scope.form_analytics.$valid && !$scope.SaveData.contains($scope.ReportData.store)) {
                    $scope.SaveData.push("analytics", {
                        action: "edit",
                        data: $scope.ReportData.store
                    });
                    $scope.$emit('tabchange', "/reports");
                }
            };
        }
    ])
    .controller('InputMapCtrl', ["$scope", "$http", "$modal", "$q", "IMData", "$filter", "$window",
        function($scope, $http, $modal, $q, IMData, $filter, $window) {
            $scope.IMData = IMData;
            $scope.addSelect = false;
            $scope.addComment = false;
            $scope.map_tools = {
                draw: true,
                upload: true,
                delete_all: true,
                marker: true,
                fullscreen: true
            };
            $scope.selected_marker = null;
            $scope.selected_feature = null;
            $scope.fullscreen = false;
            $scope.fullscreen_map = {};
            $scope.fullscreen_dimensions = {
                width: window.innerWidth,
                height: window.innerHeight - 2
            };
            $scope.show_list_view = false;
            $scope.show_drop_down = false;
            $scope.current_map = null;
            $scope.$modal = null;
            //Used to flag
            $scope.fix_bounds_on_fullscreen_close = false;
            $scope.$on('saved', function() {
                if ($scope.IMData.active) {
                    $scope.IMData.active = false;
                    $scope.$emit("tabreset", "/place-it");
                }
            });
            $scope.$on('dataupdate', function(e, tab, data) {
                if (tab == '/place-it') {
                    $scope.IMData.reinit(data);
                }
            });
            $scope.toggleListView = function() {
                $scope.show_list_view = !$scope.show_list_view;
            };
            $scope.toggleDropDown = function() {
                $scope.show_drop_down = !$scope.show_drop_down;
            };
            $scope.toggleAddSelect = function() {
                $scope.form_schema.$setDirty();
                if (angular.isDefined($scope.IMData.store.inputmap.comment_schema.select_input)) {
                    delete $scope.IMData.store.inputmap.comment_schema.select_input;
                } else {
                    $scope.IMData.store.inputmap.comment_schema.select_input = {
                        "label": "Priority",
                        "options": [{
                            option: ""
                        }],
                        "value": null
                    };
                }
                $scope.$emit("tabchange", "/place-it");
                $scope.$emit("tabvalid", "/place-it", $scope.form_schema.$valid);
            };
            $scope.toggleAddComment = function() {
                $scope.form_schema.$setDirty();
                if (angular.isDefined($scope.IMData.store.inputmap.comment_schema.input)) {
                    delete $scope.IMData.store.inputmap.comment_schema.input;
                } else {
                    $scope.IMData.store.inputmap.comment_schema.input = {
                        label: "Comment",
                        value: null
                    };
                }
                $scope.$emit("tabchange", "/place-it");
                $scope.$emit("tabvalid", "/place-it", $scope.form_schema.$valid);
            };
            $scope.addSelectOption = function() {
                console.log($scope)
                $scope.form_schema.$setDirty();
                $scope.IMData.store.inputmap.comment_schema.select_input.options.push({
                    option: ""
                });
                $scope.$emit("tabchange", "/place-it");
                $scope.$emit("tabvalid", "/place-it", $scope.form_schema.$valid);
            };
            $scope.optionChanged = function() {
                $scope.$emit("tabchange", "/place-it");
                $scope.$emit("tabvalid", "/place-it", $scope.form_schema.$valid);
            };
            $scope.removeSelectOption = function(opt) {
                $scope.IMData.store.inputmap.comment_schema.select_input.options = _.reject($scope.IMData.store.inputmap.comment_schema.select_input.options, function(o) {
                    return opt === o;
                });
                $scope.form_schema.$setDirty();
                $scope.$emit("tabchange", "/place-it");
            };
            $scope.descriptionChanged = function() {
                $scope.IMData.dirty = true;
                $scope.$emit("tabchange", "/place-it");
            }
            $scope.addUpdatesToStack = function() {
                if ($scope.IMData.layer.edit_stack.length > 0) {
                    console.log($scope.IMData.layer.getUpdates())
                    $scope.SaveData.push("inputmap_basegeo", {
                        data: $scope.IMData.layer.getUpdates()
                    });
                }
                if ($scope.form_schema.$dirty || $scope.IMData.dirty) {
                    if ($scope.form_schema.$dirty) {
                        if (angular.isDefined($scope.IMData.store.inputmap.comment_schema.select_input)) {
                            for (var i = 0, len = $scope.IMData.store.inputmap.comment_schema.select_input.options.length; i < len; i++) {
                                if ($scope.IMData.store.inputmap.comment_schema.select_input.options[i].option.length == 0) {
                                    $scope.IMData.store.inputmap.comment_schema.select_input.options = _.reject($scope.IMData.store.inputmap.comment_schema.select_input.options, function(o) {
                                        return $scope.IMData.store.inputmap.comment_schema.select_input.options[i] === o;
                                    });
                                }
                            }
                        }
                    }
                    if (angular.isDefined($scope.IMData.store.inputmap.comment_schema.select_input)) {
                        $scope.IMData.store.inputmap.comment_schema.select_input.value = "";
                    }
                    if (angular.isDefined($scope.IMData.store.inputmap.comment_schema.input)) {
                        $scope.IMData.store.inputmap.comment_schema.input.value = "";
                    }
                    $scope.SaveData.push("inputmap", {
                        data: $scope.IMData.store.inputmap
                    });
                }
                var gmark_edits = $scope.IMData.gmarklayer.getUpdates();
                if (gmark_edits.length > 0) {
                    $scope.SaveData.push("inputmap_geomarks", {
                        data: gmark_edits
                    });
                }
            };
            $scope.uploadGeoFile = function() {
                filepicker.pick({
                        container: 'modal',
                        services: ['BOX', 'COMPUTER', 'DROPBOX']
                    },
                    function(InkBlob) {
                        $scope.IMData.error = null;
                        $scope.$apply(function() {
                            $http.post(
                                '/assets/geo_file_upload/',
                                $.param(InkBlob), {
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }
                                }
                            ).success(function(obj) {
                                if (obj.success) {
                                    $scope.IMData.layer.loadEncodedPolygons(obj.data, true, true);
                                    $scope.IMData.layer.fitLayer(); // To slow for big layers
                                    $scope.IMData.store.inputmap.center.lat = $scope.current_map.map.getCenter().lat();
                                    $scope.IMData.store.inputmap.center.lng = $scope.current_map.map.getCenter().lng();
                                    $scope.IMData.store.inputmap.zoom = $scope.current_map.map.getZoom();
                                    $scope.form_schema.$setDirty();
                                    $scope.$emit("tabchange", "/place-it", $scope);
                                } else {
                                    $scope.IMData.error = obj.error;
                                }
                            }).error(function(data, status) {});
                        });
                    },
                    function(FPError) {
                        //console.log(FPError.toString());
                    });
            };
            $scope.deleteAll = function() {
                $scope.IMData.layer.deleteAllFeatures();
                if (angular.isDefined($scope.$colorpicker)) {
                    $scope.$colorpicker.hide();
                }
                $scope.IMData.gmarklayer.deleteAllMarkers();
                $scope.IMData.infowindow.close();
                $scope.$emit("tabchange", "/place-it", $scope);
            };
            $scope.changeColor = function(hex) {
                $scope.IMData.layer.selected_feature.setOptions({
                    'fillColor': hex
                });
                $scope.IMData.layer.addToEditStack($scope.IMData.layer.selected_feature, GLayer.MODIFIED);
            };
            $scope.drawPolygon = function() {
                $scope.IMData.gmarklayer.disableMarking();
                if ($scope.IMData.layer.is_drawing) {
                    $scope.IMData.layer.disableDrawing();
                } else {
                    $scope.IMData.layer.enableDrawing();
                }
            };
            $scope.addMarker = function() {
                $scope.IMData.layer.disableDrawing();
                if ($scope.IMData.gmarklayer.is_adding_markers) {
                    $scope.current_map.map.setOptions({
                        draggableCursor: undefined
                    });
                    $scope.IMData.gmarklayer.disableMarking();
                    $scope.IMData.layer.setClickable(true);
                    $scope.IMData.gmarklayer.setClickable(true);
                } else {
                    $scope.current_map.map.setOptions({
                        draggableCursor: 'url(/static/img/marker.png) 10 30, auto'
                    });
                    $scope.IMData.layer.setClickable(false);
                    $scope.IMData.gmarklayer.setClickable(false);
                    $scope.IMData.gmarklayer.enableMarking();
                }
            };
            $scope.resetSelection = function() {
                $scope.$emit("resetselection");
            };
            $scope.$watch("current_tab", function(tab) {
                if (tab == "/place-it") {
                    if (!$scope.IMData.active && $scope.has_feature('place_it')) {
                        $scope.IMData.load($scope.topic, true).then(function(obj) {}, function(reason) {});
                    }
                }
            });
            var setup_schema = $scope.$watch("IMData.store.inputmap.comment_schema", function(nv, ov) {
                if (angular.isDefined(nv) && nv !== null) {
                    if (angular.isDefined(nv.input)) {
                        $scope.addComment = true;
                    }
                    if (angular.isDefined(nv.select_input)) {
                        $scope.addSelect = true;
                    }
                    setup_schema();
                }
            });
            $scope.showFullscreenMap = function() {
                $scope.fullscreen = true;
                $scope.selected_feature = null;
                $scope.IMData.layer.selected_feature = null;
                var modalPromise = $modal({
                    template: '/static/apps/edit/partials/edit/e_fullscreen_map_modal.html',
                    show: false,
                    backdrop: 'static',
                    scope: $scope,
                    persist: false
                });
                $q.when(modalPromise).then(function(modalEl) {
                    $scope.$modal = modalEl.modal;
                    modalEl.modal('show');
                });
            };
            $scope.setSelectedFeature = function(ft) {
                $scope.selected_feature = ft;
            };
            $scope.stopAllEditing = function() {
                $scope.IMData.layer.disableDrawing();
                $scope.IMData.gmarklayer.disableMarking();
            };
            $scope.fitToMap = function() {
                if ($scope.fullscreen) {
                    $scope.fix_bounds_on_fullscreen_close = true;
                } else {
                    var tmpcenter = $scope.current_map.map.getCenter();
                    var tmplat = tmpcenter.lat();
                    var tmplng = tmpcenter.lng();
                    var tmpzoom = $scope.current_map.map.getZoom();
                    var tmpcenter = {
                        lat: tmplat,
                        lng: tmplng
                    };
                    if ($scope.IMData.store.inputmap.center != tmpcenter || tmpzoom != $scope.IMData.store.inputmap.zoom) {
                        if ($scope.IMData.gmarklayer.marks.length != 0 && $scope.IMData.layer.features.length != 0) {
                            var bounds = $scope.IMData.layer.getBounds();
                            for (var i = 0, len = $scope.IMData.gmarklayer.marks.length; i < len; i++) {
                                var mark = $scope.IMData.gmarklayer.marks[i];
                                if (mark.action != GLayer.DELETED) {
                                    bounds.extend(mark.position);
                                }
                            }
                            $scope.current_map.map.fitBounds(bounds);
                            var map_center = $scope.current_map.map.getCenter()
                            $scope.IMData.store.inputmap.center = {
                                lat: map_center.lat(),
                                lng: map_center.lng()
                            };
                            $scope.IMData.store.inputmap.zoom = $scope.current_map.map.getZoom();
                            $scope.IMData.dirty = true;
                        }
                    }
                }
            };
            $scope.featureListUpdated = function(form) {
                if (form.$valid && form.$dirty) {
                    var filtered_polys = $filter('filterdeleted')($scope.IMData.layer.features);
                    var filtered_markers = $filter('filterdeleted')($scope.IMData.gmarklayer.marks);
                    var features = filtered_polys.concat(filtered_markers);
                    for (var i = 0, len = features.length; i < len; i++) {
                        if (features[i].ps_object != features[i].ps_object_clean) {
                            features[i].ps_object_clean = angular.copy(features[i].ps_object);
                            //Polygon
                            if (features[i].feature_type == 'polygon') {
                                $scope.IMData.layer.addToEditStack(features[i], GLayer.MODIFIED, false);
                            } else {
                                //Marker
                                if (angular.isDefined(features[i].ps_object.id)) {
                                    features[i].action = GLayer.MODIFIED;
                                } else {
                                    features[i].action = GLayer.ADD
                                }
                            }
                        }
                    }
                    form.$setPristine();
                    $scope.$emit("tabchange", "/place-it", $scope);
                    $scope.fitToMap();
                    $scope.show_list_view = false;
                }
            };
        }
    ])
    .controller('MarkerFormCtrl', ["$scope",
        function($scope) {
            $scope.deleteFeature = function() {
                $scope.selected_feature.setMap(null);
                $scope.IMData.infowindow.close();
                // Polygon
                if ($scope.selected_feature.feature_type == 'polygon') {
                    $scope.IMData.layer.addToEditStack($scope.selected_feature, GLayer.DELETED);
                } else {
                    // Marker
                    if ($scope.selected_feature.action != GLayer.ADD) {
                        $scope.selected_feature.action = GLayer.DELETED;
                    } else {
                        //Makes sure its not passed to the DB
                        $scope.selected_feature.state = GLayer.CLEAN;
                    }
                }
                $scope.fitToMap();
                $scope.resetSelection();
                $scope.$emit("tabchange", "/place-it", $scope);
            };
            $scope.cancelFeature = function() {
                $scope.IMData.infowindow.close();
                $scope.selected_marker.ps_object = angular.copy($scope.selected_marker.ps_object_clean);
                $scope.reset();
            };
            $scope.featureUpdated = function() {
                if ($scope.form_featureInfo.$valid || $scope.selected_feature.creation) {
                    $scope.selected_feature.ps_object_clean = angular.copy($scope.selected_feature.ps_object);
                    //Polygon
                    if ($scope.selected_feature.feature_type == 'polygon') {
                        $scope.IMData.layer.addToEditStack($scope.selected_feature, GLayer.MODIFIED);
                    } else {
                        //Marker
                        if (angular.isDefined($scope.selected_feature.ps_object.id)) {
                            $scope.selected_feature.action = GLayer.MODIFIED;
                        } else {
                            $scope.selected_feature.action = GLayer.ADD
                        }
                    }
                    $scope.IMData.gmarklayer.unsaved_marker = null;
                    if (angular.isDefined($scope.selected_feature.creation)) {
                        delete $scope.selected_feature.creation;
                    } else {
                        $scope.IMData.infowindow.close();
                    }
                    $scope.form_featureInfo.$setPristine();
                    $scope.$emit("tabchange", "/place-it", $scope);

                }
            };
            $scope.$on("resetselection", function() {
                $scope.reset();
            });
            $scope.reset = function() {
                $scope.selected_feature = null;
                $scope.original_data = null;
            };
            $scope.$watch("selected_feature", function(current_feat, prev_feat) {
                if (current_feat !== null && angular.isDefined(current_feat)) {
                    if (!angular.isDefined(current_feat.center_marker) && current_feat.feature_type == 'polygon') {
                        current_feat.center_marker = $scope.IMData.layer.getFeatureCenter(current_feat);
                    }
                    if (current_feat.feature_type == 'polygon') {
                        $scope.IMData.infowindow.open($scope.current_map.map, current_feat.center_marker);
                    } else {
                        $scope.IMData.infowindow.open($scope.current_map.map, current_feat);
                    }
                    if (_.isEqual($scope.selected_feature.ps_object, $scope.selected_feature.ps_object_clean)) {
                        $scope.form_featureInfo.$setPristine();
                    } else {
                        $scope.form_featureInfo.$setDirty();
                    }
                    if (current_feat.creation) {
                        $scope.fitToMap();
                        $scope.featureUpdated();
                    }
                } else {
                    $scope.IMData.infowindow.close();
                }
            });
        }
    ]);