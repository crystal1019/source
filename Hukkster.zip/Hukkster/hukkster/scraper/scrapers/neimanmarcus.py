import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class NeimanmarcusScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'neimanmarcus.com'

    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()

    def fetch_url(self):
        try:
            request = requests.request('get', self.url)
            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except BaseException, e:
            logging.error('Error %s for %s' % (e.msg, self.url))


    def generate_record(self, url, site, title, price, image,
                        sku, size, color, promos):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record

    def craw_html_data(self, soup, html, raw_data):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """
        # site_name & url
        site = raw_data['site_name']
        url = str(soup.find('link', attrs={'rel': 'canonical'})['href'])
        
        # check parse single or multi
        check = soup.find_all('div', attrs={'class': 'lineItem'})
        # color & size
        raw_color_size = self.get_colors_sizes(html)
        
        selections = []
        if check is None:
            raise HukksterTooManyOptions(NeimanmarcusScraper.get_domain(), self.url)
        if len(check) == 1:
            # parse single
            # title
            title = raw_data['title']
            # image
            image = raw_data['image']
            # price
            price = float(soup.find('span', attrs={'class': 'price'}).text[1:])
            # sku
            sku = soup.find('input', attrs={'name': 'isRelated0'})['value']
            sku_check = "'"+sku+"'"
            # promos
            promos = []
            for raw in raw_color_size:
                if raw[1] == sku_check:
                    record = self.generate_record(url, site, title, price, image,
                                              sku, raw[3], raw[4], promos)
                    selections.append(record)
            return selections
        else:
           # parse multi
           for i in check:
               # title
               title = i.find_all('h2')
               del title[0]
               title = title[0].text
               # image
               image = i.find('img', attrs={'class': 'zoomProductThumbnail'})['src']
               # promos
               promos = []
               # price
               price = float(i.find('span', attrs={'class': 'price'}).text[1:])
               # sku
               sku_data = i.find('select', attrs={'class': 'variationDD'})['onchange']
               sku_check = self.get_sku_check(sku_data)
               
               for raw in raw_color_size:
                   if raw[1] == sku_check[0]:
                       sku = self.get_sku(sku_check[0])
                       record = self.generate_record(url, site, title, price, image,
                                          sku, raw[3], raw[4], promos)
                       selections.append(record)
           return selections
               
               
    def get_colors_sizes(self, html):
        regex = r"new product\(([^,]*),([^,]*),([^,]*),([^,]*),([^,]*)"
        result = re.compile(regex, re.U).findall(html)
        return result
    
    def get_sku_check(self, sku_data):
        regex = r"\'[^']*'"
        result = re.compile(regex).findall(sku_data)
        return result
    
    def get_sku(self, sku_check):    
        sku = re.sub(r"\'", '', sku_check)
        return sku
        
    def parse(self):
        raw_data = self.parse_opengraph()
        
        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        selections = self.craw_html_data(soup, self.html, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(NeimanmarcusScraper.get_domain(), self.url)

        return selections
