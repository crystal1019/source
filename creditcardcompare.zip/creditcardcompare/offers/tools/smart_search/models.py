from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.db import models
from django.utils.translation import ugettext_lazy as _
from offers.helpers.lead.models import Lead


STATUS_CHOICES = (
    (1, 'Full time'),
    (2, 'Part time'),
    (3, 'Self Employed'),
    (4, 'Homemaker'),
    (5, 'Unemployed'),
    (6, 'Retired'),
    (7, 'Student'),
)


class SearchDetail(models.Model):
    lead = models.ForeignKey(Lead)
    when = models.DateTimeField(auto_now_add=True)
    balance_transfer = models.CharField(max_length=50, null=True, blank=True)
    frequent_flyer = models.CharField(max_length=50, null=True, blank=True)
    rewards = models.CharField(max_length=50, null=True, blank=True)
    insurance = models.CharField(max_length=50, null=True, blank=True)
    workstatus = models.SmallIntegerField(choices=STATUS_CHOICES)
    income = models.IntegerField()
    birthday = models.IntegerField()
    birthmonth = models.IntegerField()
    birthyear = models.IntegerField()
    content_type = models.ForeignKey(ContentType, editable=False)
    object_id = models.PositiveIntegerField(verbose_name='cardtype')
    cardtype = GenericForeignKey('content_type', 'object_id')

    def __unicode__(self):
        return ' ----- %s ----- %s' % (self.when, getattr(self.cardtype, 'name', None))
    
    def card_subtype(self):
        return self.balance_transfer or self.frequent_flyer or self.rewards or self.insurance or ''

    class Meta:
        ordering = ('-id',)


class Bank(models.Model):
    detail = models.ForeignKey(SearchDetail)
    content_type = models.ForeignKey(ContentType, editable=False)
    object_id = models.PositiveIntegerField(editable=False)
    bank = GenericForeignKey('content_type', 'object_id')

    def __unicode__(self):
        return self.bank.name

    class Meta:
        verbose_name_plural = _('Have a card with')
