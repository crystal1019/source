angular.module('TopicApp', [
    'ngRoute',
    'ngSanitize',
    '$strap.directives',
    'topic.controllers',
    'topic.directives',
    'common.directives',
    'common.services',
    'topic.services',
    'angularMoment',
]).config(["$httpProvider", "$routeProvider", "$locationProvider",
    function($httpProvider, $routeProvider, $locationProvider) {
        $httpProvider.defaults.headers.post['X-CSRFToken'] = $('input[name=csrfmiddlewaretoken]').val();
        $locationProvider.hashPrefix('!');
        var route_prefix = '/';
        for (var i = 0, len = available_tabs.length; i < len; i++) {
            var t = available_tabs[i];
            if (t === 'media') {
                $routeProvider.when('/resources', {});
            } else if (t === 'inputmap') {
                $routeProvider.when('/place-it', {});
            } else {
                $routeProvider.when(route_prefix.concat(t), {});
            }
        }
        $routeProvider.otherwise({
            redirectTo: '/' + (default_tab_data.tab != "" ? default_tab_data.tab : 'overview')
        });
    }
]);