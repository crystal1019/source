import masterpage    
class Robots(masterpage.MasterPage):
    def get(self):
        self.response.out.write(self.getBody({}, 'html/robots.txt')) 
        
