"""Please use flatpage_filters.py instead. This module will be faced out."""

from django import template
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.template import Library
from offers.core.templatetags import varname_re
from offers.tools.flatpages.models import FlatPageExtra


register = Library()


class LearningFlatpagesNode(template.Node):
    """replaced by CategoryFlatpagesNode in flatpage_filters.py"""
    def __init__(self, varname, category, base_url):
        self.category = category
        self.base_url = base_url
        self.varname = varname

    def render(self, context):
        self.category = template.Variable(self.category).resolve(context)
        if self.base_url[0]==self.base_url[-1] and self.base_url[0] in ('"',"'"):
            self.base_url = self.base_url[1:-1]
        flatpage_extra = FlatPageExtra.objects.filter(page__url__startswith=self.base_url,
                                                page__sites__id=settings.SITE_ID
                                               ).exclude(page__url=self.base_url, page=None
                                               ).order_by('page__title')
        if self.category:
            flatpage_extra = flatpage_extra.filter(categories=self.category)
        context[self.varname] = flatpage_extra
        return ''

class TileUrlNode(template.Node):
    def __init__(self, flatpage, varname):
        self.flatpage = flatpage
        self.varname = varname

    def render(self, context):
        flatpage = template.Variable(self.flatpage).resolve(context)
        content_type = ContentType.objects.get_for_model(flatpage)
        tiles = FlatPageExtra.objects.filter(content_type__pk=content_type.pk, content_id=flatpage.pk)
        context[self.varname] = tiles[0]
        return ''
    

@register.tag(name='get_learning_flatpages')
def do_get_learning_flatpages(parser, token):
    """replaced by get_category_flatpages in flatpage_filters.py"""
    try:
        tag_name, _as, varname, _from, category, base_url = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments' % token.split_contents()[0]
    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)
    return LearningFlatpagesNode(varname, category, base_url)

@register.tag(name='get_extra')
def do_get_tile_url(parser, token):
    try:
        _tag_name, flatpage, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 1 arguments' % token.split_contents()[0]

    return TileUrlNode(flatpage, varname)
    