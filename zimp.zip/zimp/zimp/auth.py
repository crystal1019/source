import hashlib
from django.conf import settings


def create_hash(email, pwd):
    salt = email.split('@')
    return hashlib.md5(('%s%s%s%s' % (pwd, salt[0], settings.SECRET_KEY, salt[1])).encode()).hexdigest()


def validate_hash(email, rawpwd, pwd):
    return create_hash(email, rawpwd) == pwd
