from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('arktotalwealth.overview.views',
    (r'^$', 'home'),
    (r'^(?P<slug>.*).html$', 'home'),

)