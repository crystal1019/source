# Create your views here.
from berowrawatersinn.kitchen.models import *
from django.template import loader, RequestContext
from django.http import HttpResponse
from berowrawatersinn.common import *

def home(request, slug=None):
    t = loader.get_template('mainpage.html')
    meta = KitchenPage.objects.get(slug=slug) if slug else KitchenPage.objects.filter(is_landing=True,is_active=True)[0]
    
    nav = KitchenPage.objects.filter(is_active=True)
    
    c = RequestContext(request, commondict({
        'current_meta':meta,
        'nav':nav,
        'path':'kitchen',
    },request))
    
    return HttpResponse(t.render(c))
    