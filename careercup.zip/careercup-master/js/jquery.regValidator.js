(function($){
    $.regValidator = {version:'1.0'};
    var methods = {
        init: function(options){
            return this.each(function(){
                var $this = $(this);
                if ($this.data('regValidator')) return; //If plugin is alread initiated abort                
                $this.data('regValidator', {settings:$.extend({}, $.regValidator.defaults, options)});
                $this.keyup(function(){
                    $this.regValidator('keyevent')
                });
            });
        },
        keyevent: function(){
            return this.each(function(){
                var $this = $(this);                              
                var settings = $this.data('regValidator').settings;                
                for( var i in settings.tooltips){
                    var pattern=new RegExp(i,'m');
                    if (pattern.test($this.val())) $this.regValidator('showTooltip',settings.tooltips[i]);
                }
            });
        },
        showTooltip: function(message){
            return this.each(function(){
                clearTimeout($.regValidator.timer);
                var $this = $(this).addClass('regValidator');
                $this.regValidator('hideTooltip');
                var toolTip = $('<div class="ui-widget-content ui-state-highlight" style="position:absolute;min-width:150px;max-width: 300px;z-index:1000"></div>');
                var header = $('<div></div>');
                var body = $('<div style="padding:20 5 5 5; border: 1px dotted #FF0000; font-size: .885em; padding: 5px;">'+message+'</div>');
                var buttonClose = $('<div class="ui-state-default" style="width:16px; float:right; margin-top:1px;margin-right:1px"><span class="ui-icon ui-icon-closethick"></span></div>');
                buttonClose.hover(
                    function(){
                        $(this).addClass('ui-state-hover');
                    },
                    function(){
                        $(this).removeClass('ui-state-hover');
                    }
                );
                buttonClose.click(function(){
                    $(this).parent().parent().fadeOut(function(){$(this).remove()});
                });
                toolTip.append(header.append(buttonClose)).append(body);                
                $this.parent().append(toolTip); 
                $this.data('tooltip', toolTip);
                toolTip.css({top:$this.position().top+$this.outerHeight(), left:($this.position().left+$this.outerWidth()-toolTip.width())});
                $.regValidator.timer = setTimeout(function(){
                    $this.regValidator('hideTooltip');
                },$this.data('regValidator').settings.duration*1000);
            });
        },
        hideTooltip: function(){
            
            $('.regValidator').each(function(){
                var $this = $(this);
                var tooltip = $this.data('tooltip');
                if (tooltip){
                    tooltip.fadeOut(function(){$(this).remove()});
                }
            });
        }
    };
    $.fn.regValidator = function(method){
        if (methods[method]){//call a method
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else {
            return methods.init.apply( this, arguments );
        }
    };
    $.regValidator.defaults = {
        duration:30,
        tooltips:null
    }
    $.regValidator.timer = null;
})(jQuery);