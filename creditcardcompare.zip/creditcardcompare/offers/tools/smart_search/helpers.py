from itertools import izip, cycle


get_val = lambda exfields, name: exfields.filter(name=name)[0].value

def xor_crypt(data):
        key = 'smart+search+secret+key'
        data = str(int(data)) if isinstance(data, long) else data
        return ''.join(chr(ord(x) ^ ord(y)) for (x, y) in izip(data, cycle(key)))
