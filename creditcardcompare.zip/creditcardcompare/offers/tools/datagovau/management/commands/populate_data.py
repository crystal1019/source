import os
from datetime import date
from django.core.management.base import BaseCommand
from offers.tools.datagovau.models import Location


class Command(BaseCommand):
    BATCH = 'personal tax'
    YEAR = 2005
    
    def handle(self, *args, **options):
        print 'populating map data'
        values = get_value_per_city()
        zip_codes = get_zip_per_city()
        
        for key, val in values.iteritems():
            print 'populating %s' % key
            val = val.replace(',','')
            for postcode in filter(None, zip_codes[key]):
                Location(date=date(self.YEAR, 4, 1),
                         address=postcode,
                         data=val,
                         batch=self.BATCH
                    ).save()
        
def get_value_per_city():
    f = open(os.path.join(os.path.dirname(__file__), 'data.csv'))
    cities = []
    values = []
    break_found = False
    for l in f.readlines():
        l = l.strip('\n').strip('\r').replace(' / ', ' ')
        if break_found:
            values.append(l)
        else:
            break_found = len(l) < 2
            cities.append(l)
    f.close()
    return dict(zip(cities, values))
        
def get_zip_per_city():
    f = open(os.path.join(os.path.dirname(__file__), 'zip.csv'))
    line_num = 0
    cities = []
    zip_codes = {}
    for l in f.readlines():
        line_num += 1
        if line_num > 4:
            for col, key in zip(l.strip('\n').strip('\r').split('\t'), cities):
                zip_codes[key].append(col)
        elif line_num == 3:  # cities
            prev_col = ''
            for col in l.strip('\n').strip('\r').replace(' / ', ' ').split('\t'):
                if col == '' or col.find('(continued)') != -1:
                    col = prev_col
                else:
                    prev_col = col
                cities.append(col)
                zip_codes.update({col: []})
    f.close()
    return zip_codes
    