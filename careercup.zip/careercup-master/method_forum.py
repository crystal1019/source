import math

import objects
import method_cache
import method_db
import method_url

per_page = 20
pages_cached = 100
flag_limit = 3
pages_per_set = 10

sorts = ['date', 'comments', 'recentcomments']

cache_key_forum_post = 'forum-post'
cache_key_forum_title = 'forum-title'

def getForumPostWithId(theid, force=False):
	if theid:
		forum = objects.ForumPost.query(objects.ForumPost.uid == theid).get()
		return method_db.addInfoToObject(forum, force)
	else:
		forum = objects.ForumPost()
		forum.is_admin = True
		return forum
		
def getForumPosts(page_num, sort):
	if sort is None or sort == '':
		sort = 'date'
			
	# Get sort order
	qry = objects.ForumPost.query(objects.ForumPost.visible == True)
	if sort == 'comments':
		qry = qry.order(-objects.ForumPost.comment_count)
	elif sort == 'date':
		qry = qry.order(-objects.ForumPost.date)
	elif sort == 'recentcomments':
		qry = qry.order(-objects.ForumPost.last_comment)	
	
	# Fetch results
	set_start = method_url.getFirstPageOfSet(pages_per_set, page_num)	
	offset = set_start * per_page
	result = qry.fetch_page(per_page * pages_per_set, offset=offset)
	forum_posts = result[0]
	return [method_db.addInfoToList(forum_posts), result[1], result[2]]
	
def deleteForumPost(forum):
	forum.visible = False
	method_db.putObject(forum)
	
def undeleteForumPost(forum):
	forum.visible = True
	method_db.putObject(forum)
	
def getFlaggedForumCount():
	flagged_count = method_cache.getObjectForTypeAndKey('flagged_forum_count', None)
	if not flagged_count:
		flagged_count = objects.ForumPost.query(objects.ForumPost.under_review == True).count()
		method_cache.setObjectForTypeAndKey('flagged_forum_count', None, flagged_count)
	return flagged_count
	
def clearCache(forum):
	sorts = ['date', 'recentcomments', 'comments', '']
	for p in range(0, pages_cached):
		for s in sorts:
			key = 'forum-' + s
			method_cache.clearObjectForTypeAndId(key, str(p))
	method_cache.clearObjectForTypeAndId('forum-size', None)
	if forum:
		method_cache.clearObjectForTypeAndId(cache_key_forum_post, forum.uid)
		method_cache.clearObjectForTypeAndId(cache_key_forum_title, forum.uid)
		if forum.author_id:
			method_cache.clearObjectForTypeAndId('user', forum.author_id)

def clearFlaggedCountCache():
	method_cache.clearObjectForTypeAndId('flagged_forum_count', None)

def getNumberForums():
	count = method_cache.getObjectForTypeAndKey('forum-size', None)
	if count:
		return count
		
	count = objects.ForumPost.query().count()
	method_cache.setObjectForTypeAndKey('forum-size', None, count)
	return count