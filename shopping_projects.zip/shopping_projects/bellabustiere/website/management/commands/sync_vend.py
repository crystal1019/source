from django.core.management.base import BaseCommand, CommandError
from bellabustiere.shop.models import *
import datetime


class Command(BaseCommand):
    help = 'Sync inventory from vend'
    
    def handle(self, **options):
        try:
            from bellabustiere.vendapi import *
            vend = VendAPI()
            msg = vend.sync_from_vend(schedule=True)
            now = datetime.datetime.now()
            print str(now)
            for x in msg:
                print x
                
        except Exception, e:
            print e
                
                