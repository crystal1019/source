from datetime import datetime

import objects
import masterpage

import method_user
import method_question
import method_db
import method_cache
import method_url

class ClearCache(masterpage.MasterPage):	
	def createLists(self, question):
		if question.companies_pretty is None:
			question.companies_pretty = []
		if question.jobs_pretty is None:
			question.jobs_pretty = []	
		if question.topics_pretty is None:
			question.topics_pretty = []	
			
	def replaceId(self, question, type, old_id, new_id):
		self.createLists(question)
		if type == 'company':
			question.companies.remove(old_id)
			if not(new_id in question.companies_pretty):
				question.companies_pretty.append(new_id)
		elif type == 'job':
			jobs = question.jobs
			question.jobs.remove(old_id)
			if not(new_id in question.jobs_pretty):					
				question.jobs_pretty.append(new_id)
		else:
			question.topics.remove(old_id)
			if not(new_id in question.topics_pretty):					
				question.topics_pretty.append(new_id)
		question.put()		
	
	def doRefresh(self, uid):			  	
		attributes = objects.Attribute.query(objects.Attribute.uid > uid).fetch(10)
		total = 0
		biggest = uid
		for attribute in attributes:
			text = attribute.text
			total = total + 1
			name = method_question.createCanonicalName(text)
			attribute.pretty_id = name
			refresh_time = attribute.last_refresh
			if refresh_time:
				s = refresh_time.strftime('%B %d, %Y')
			else:
				s = "never"
			# self.response.out.write('Refreshed ' + attribute.text + '. Last refresh at ' + s + '<br/>')				
			attribute.last_refresh = datetime.now()		
			count = 0
			type = attribute.type
			if type == 'company':
				filter_text = 'companies ='
			elif type == 'job':
				filter_text = 'jobs ='
			else:
				filter_text = 'topics ='
			questions = objects.Question.query.filter(filter_text, attribute.uid)
			for question in questions:
				count = count + 1
				total = total + 1
				self.replaceId(question, type, attribute.uid, name)
								
			method_db.putObject(attribute)
			if count >= 1:							
				self.response.out.write('<b>Updated ' + name + ' with ' + str(count) + '</b><br/>')
			else:
				self.response.out.write('<i>Updated ' + name + ' with ' + str(count) + '</i><br/>')
			biggest = attribute.uid
		return biggest
			
	def get(self):
		if method_user.userIsAdmin():
			type = method_url.getStringParam(self, 'type')
			key = method_url.getStringParam(self, 'key')
			if type is not None and type != '':
				if key == 'None' or key is None or key == '':
					key = None
				value = method_cache.getObjectForTypeAndKey(type, key)
				self.response.out.write(value)
			else:
				method_cache.clearAll()
				self.response.out.write('Cache Cleared')
		else:
			self.redirectToLogin()	
