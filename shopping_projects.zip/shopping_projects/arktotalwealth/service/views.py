# Create your views here.
from django.http import HttpResponse
from django.template import loader, RequestContext
from arktotalwealth.service.models import *
from arktotalwealth import common

def home(request,slug=None):
    path = ServicePage.objects.filter(parent__isnull=True, active=True)
    path = path[0] if path else ''
    if slug:
        t = loader.get_template('page.html')
        page = ServicePage.objects.get(slug=slug)

        
    else:
        t = loader.get_template('miscpage.html')
        page = path
        
    topnav = ServicePage.objects.filter(parent=path, active=True)
        
    c = RequestContext(request,common.commondict({'page':page, 'path':path, 'topnav':topnav}, request))
    return HttpResponse(t.render(c))
