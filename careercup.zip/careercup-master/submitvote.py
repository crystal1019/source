import masterpage

import method_url
import method_db
    
class SubmitVote(masterpage.MasterPage):
          
    def post(self):
        id = method_url.getId(self)
        type = method_url.getStringParam(self, 'type')
        vote = self.request.get('vote')
        obj = method_db.getObjectWithTypeAndId(id, type)
        #self.response.out.write(id)
        if not(obj):
            self.redirect(self.request.referer)
            return
        
        # Update total votes.
        votes_total = obj.votes_total
        if not(votes_total):
            votes_total = 0
        votes_total = votes_total + 1
        
        # Update net votes.
        votes_net = obj.votes_net
        if not(votes_net):
            votes_net = 0
        if vote == 'yes':
            votes_net = votes_net + 1
        elif vote == 'no':
            votes_net = votes_net - 1
        
        obj.votes_net = votes_net
        obj.votes_total = votes_total
        method_db.putObject(obj)
        self.redirect(self.request.referer)        
            
        
