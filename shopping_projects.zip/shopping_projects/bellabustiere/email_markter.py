from xml.dom.minidom import parseString

import base64, httplib2
import datetime
date = datetime.date(2010,8,8)
pw = 'StyleNews111'

login_id = "julie@bellabustiere.com"
token = "f536efc27cf9ed26063af7b21b703fbd1d54c4bb"

http = httplib2.Http()
url = "http://em2.velocityhost.com.au/xml.php"

xmlstring = '''<xmlrequest>
<username>%s</username>
<usertoken>%s</usertoken>
<requesttype>subscribers</requesttype>
<requestmethod>AddSubscriberToList</requestmethod>
<details>
    <emailaddress>%s</emailaddress>
    <mailinglist>3</mailinglist>
    <format>html</format>
    <confirmed>yes</confirmed>
    <customfields>
        <item>
            <fieldid>2</fieldid>
            <value>Chao</value>
        </item>
        <item>
            <fieldid>3</fieldid>
            <value>Liang</value>
        </item>
        <item>
            <fieldid>10</fieldid>
            <value></value>
        </item>
        <item>
            <fieldid>7</fieldid>
            <value>01/01/1923</value>
        </item>
    </customfields>
</details>
</xmlrequest>'''   %(login_id, token, 'chaol@1md.com.au',) 
response, content = http.request(url, 'POST', body=xmlstring)
print response
print content