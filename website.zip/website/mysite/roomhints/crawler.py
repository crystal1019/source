import urllib2
from urllib import urlretrieve
from BeautifulSoup import BeautifulSoup as Soup
from urlparse import urljoin
import cssutils
import os
import sys
import shutil
from roomhints.utils import make_unique
from roomhints.utils import make_unique_photo
#from django.conf import settings
import Image
import re

def crawl_full_url(src,baseurl):
    # If there is no baseurl, add one
    fullurl = None
    src_domain_and_rest = src.split('://')
        #print("src_domain_and_rest" + str(src_domain_and_rest))
    if len(src_domain_and_rest) == 1:
        fullurl = baseurl + "/" + src
    else:
        fullurl = src
    return fullurl

def crawl_hint(url,testing=False):
    try:
        os.mkdir('/tmp/crawl')
    except Exception, e:
        # it probably exists already
        pass
    f = open('/tmp/crawl/log', 'ab+')
    baseurl = ""
    domain = ""
    if testing == False:
        # When testing url is a file, not a url
        domain_and_rest = url.split('://')
        domain_list = domain_and_rest[1].split('/')
        domain = domain_list[0]
        baseurl = domain_and_rest[0] + "://" + domain
    #print "baseurl is " + baseurl
    f.write("domain is " + str(domain) + "\n")
    f.write("baseurl is " + baseurl + "\n")

    # Extract the source out of the domain
    source = ""
    source_list = domain.split('.')
    source = source_list[-2]
    f.write('source_list is ' + str(source_list))
    f.write('source is ' + str(source))
    source = source.title() # Capitalize first letter
    price = None
    name = None
    largest_img_url = None
    basepath = make_unique(16)
    imagepath = "/tmp/crawl/" + basepath + "/"
    try:
        os.mkdir('/tmp/crawl')
    except Exception, e:
        # it probably exists already
        pass
    os.mkdir(imagepath)
    #wget --user-agent="Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.3) Gecko/2008092416 Firefox/3.0.3"  url
    # This is the mobile agent for the iPhone: CFNetwork/548.1.4 Darwin/11.0.0
    data = None
    if testing:
        f = open(url) # It's a file, not a url
        data = f.read()
        f.close()
    else:
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', 'CFNetwork/548.1.4 Darwin/11.0.0')]
        urllib2.install_opener(opener)
        response = urllib2.urlopen(url)
        data = response.read()
    #print("data are " + data + "\n")
    d = open('/tmp/crawl/' + basepath + "/crawl.html", 'ab+')
    d.write(data)
    d.close()
    soup = Soup(data)
    largest_product = -1
    largest_dims = None
    largest_img = None
    largest_soup_img = None
    images = dict()
    f.write('crawl - 1 \n')
    #f.write("crawl - 1.soup.findAll('img') is: " + str(soup.findAll('img')) + "\n")
    all_imgs = []
    for img in soup.findAll('img'):
        f.write('crawl - 1.1\n')
        src = img.get('src')
        # It's possible to encounter an <img style="..." src="">
        if src != None:
            f.write('crawl - 1.1-src:' + str(src) + "\n")
            f.write('crawl - 1.1-baseurl:' + str(baseurl) + "\n")
            imgurl = crawl_full_url(src,baseurl)
            #print("imgurl to crawl is " + str(imgurl))
            outpath = imagepath + make_unique_photo()
            f.write('crawl - 1.2 - imgurl is ' + imgurl+ '\n')
            retrieved = False
            if testing == False:
                # Do not crawl if testing
                try:
                    urlretrieve(imgurl, outpath)
                    retrieved = True
                except IOError, e:
                    # Some files may be missing
                    pass
            f.write('crawl - 1.3 \n')

            if retrieved:
                try:
                    f.write('crawl - 1.4 - outpath is ' + str(outpath) + '\n')
                    im = Image.open(outpath)
                    f.write('crawl - 1.5\n')
                    print src + str(im.size) + " " + str(im.format)
                    f.write('crawl - 2 - ' + src + str(im.size) + " " + str(im.format) + ' \n')
                    images['photo'] = outpath
                    images['width'] = im.size[0]
                    images['height'] = im.size[1]

                    # Ignore images that are unusually disproportionate, like a header banner
                    if im.size[0] / im.size[1] > 4 or im.size[1] / im.size[0] > 4:
                        pass
                    else:
                        this_product = im.size[0] * im.size[1]
                        all_imgs.append([this_product,outpath,imgurl])
                        if this_product > largest_product:
                            largest_product = this_product
                            largest_img = outpath
                            largest_soup_img = img
                            largest_dims = im.size
                            largest_img_url = imgurl
                except IOError, e:
                    pass # not an image file, yikes

    # The first price found is the price we are going with
    def find_price(el):
        # Remove all Javascript
        for script in el.findAll('script'):
            script.extract()

        for d in el.findAll(['div','p']):
            #for t in d.findAll(text=True):
            match = re.findall('\$(\d*)',d.text)
            #print d
            if match:
                f.write(str(match) + "\n")
                for mi in match:
                    if mi != '' and str(mi) != '0':
                        price = str(mi)
                        f.write("found price " + price + "\n")
                        return price

    price = find_price(soup)

        # for img in d.findAll('img'):
        #     src = img.get('src')
        #     full_src = crawl_full_url(src,baseurl)
        #     if full_src == largest_img_url:
        #         #print("Found img within div " + str(d))
        #         print("Comparing: " + full_src + " " + largest_img_url + "\n")

    for d in soup.findAll('title'):
        if name == None:
            titles = d.text.split('\n')
            title1 = titles[0]
            # Strip out a trailing | too
            title2 = title1.split(' |')
            name = title2[0]

    f.write('crawl - 3 ' + "largest image is " + str(largest_img) + " with dims " + str(largest_dims) + " from " + str(largest_img_url)  + ' with price ' + str(price) + ' \n')
    return price, name, source, largest_img_url, largest_img, all_imgs

def crawl_hint_clean(img):
    # remove the /tmp/xyz directory this image was stored in
    if img[1:4] == "/tmp":
        dirname = os.path.dirname(img)
        shutil.rmtree(dirname)
