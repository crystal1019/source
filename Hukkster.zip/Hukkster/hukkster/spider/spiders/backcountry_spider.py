from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from ..items import Product

class BackcountrySpider(CrawlSpider):
    name = 'backcountry'
    allowed_domains = ['www.backcountry.com',]
    start_urls = [
        'http://www.backcountry.com/',
        ]

    rules = (
        Rule(SgmlLinkExtractor(deny=('\/profile\/', )), callback='parse_item'),
        Rule(SgmlLinkExtractor(deny=('\/profile\/', ))),  # Continue following all URLs
    )

    def parse_item(self, response):
        hxs = HtmlXPathSelector(response)

        sku = hxs.select('//b[@itemprop="productID"]/text()').extract()
        if len(sku):
            product = Product()
            product['name'] = sku[0].strip()
            product['sku'] = sku[0]
            product['url'] = response.url
            return product
