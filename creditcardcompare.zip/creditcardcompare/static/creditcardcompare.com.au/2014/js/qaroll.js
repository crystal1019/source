$(document).ready(function(){

	var qaroll = {current:null};

	$('.qaitem').each(function(){
		$(this).on('click',function(e){
			var query = $(this).parent().find('.qaitemcontent');
			// close others ::
			if(qaroll.current){
				qaroll.current.parent().find('.qaitemiconopen').attr('class','qaitemicon');
				if(qaroll.current[0] == query[0]){// same element
					query.stop();
					query.hide(100);
					query.parent().stop().animate({height:19},200);
					qaroll.current = null;
					return;
				}
				// close old
				query.stop();
				qaroll.current.hide(100);
				qaroll.current.parent().stop().animate({height:19},200);
			}
			// display new
			// console.log('1',query.height());
			var max = query.height();
			query.show();
			max = Math.max(max,query.height());
			query.css({opacity:0});
			$(this).parent().stop().animate({height:max + 25},200,'swing',function(){
				query.animate({opacity:1});
			});
			$(this).parent().find('.qaitemicon').attr('class','qaitemiconopen');
			qaroll.current = query;
		});
	});
});