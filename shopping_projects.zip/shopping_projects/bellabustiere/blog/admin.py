'''
@author: chaol
'''

from django.contrib import admin
from django.contrib.contenttypes import generic
from django import forms
from django.core.urlresolvers import reverse

from models import *
from django.http import HttpResponseRedirect

class BlogCategoryAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug": ("name",)}
    list_filter = ('sites',)

class BlogPostAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug": ("title",)}
    list_display = ('title', 'status', 'publishdate',)
    list_filter = ('created', 'modified', 'status','sites')
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js?version=2',]

class CommentAdmin(admin.ModelAdmin):
    list_display = ('name', 'status', 'email', 'created','comment', 'ip')
    list_filter = ('created', 'status', 'created','sites')
    
    actions = ['set_as_spammers',]
    
    def set_as_spammers(self,request,queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        return HttpResponseRedirect('addtospammerslist/?ids=%s' % ",".join(selected))

#admin.site.unregister(BlogPost)
admin.site.register(BlogPost, BlogPostAdmin)
admin.site.register(Comment, CommentAdmin)
admin.site.register(PublishStatus)
admin.site.register(CommentStatus)
admin.site.register(BlogCategory,BlogCategoryAdmin)