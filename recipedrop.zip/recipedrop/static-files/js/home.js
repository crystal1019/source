$(document).ready(function () {

    var signup = $('#signup_url').val(),
    login = $('#login_url').val();

    function load_content(sel) {
        return function (resp) {
            var $form;
            $(sel).html(resp);
            $(sel).find('.alert').hide();
            $form = $(sel).find('form');
            $form.ajaxify(util.ajax_form_opts($form));
            $form.append($('#next').clone());
        };
    }

    $.get(signup, load_content('#signup'));
    $.get(login, load_content('#login'));

    if ($("input[name=next]").length) {
        $("#login_button").click();
    }

//    $('div.gradient').remove();

});