from google.appengine.ext import ndb
from google.appengine.ext import db

import objects
import method_db
import method_url
import method_cache

import re
import unidecode

import logging

per_page = 30
pages_per_set = 10
max_retrieved = 1000
flag_limit = 3
sorts = ['date', 'comments', 'recentcomments', 'votes']

cache_key_attributes_list = 'attributes'

def getAttributeWithId(id):
	attribute = method_cache.getObjectForTypeAndKey('attribute', id)
	if not attribute:
		attribute = objects.Attribute.query(objects.Attribute.uid == id).get()
		method_cache.setObjectForTypeAndKey('attribute', id, attribute)
	return method_db.ensureVisible(attribute)	
	
def getAttributeWithPid(pid):
	attribute_str = method_cache.getObjectForTypeAndKey('attribute', pid)
	if attribute_str:
		attribute = deserializeAttribute(attribute_str)
	else:
		attribute = objects.Attribute.query(objects.Attribute.pretty_id == pid).get()
		if attribute:
			method_cache.setObjectForTypeAndKey('attribute', attribute.pretty_id, serializeAttribute(attribute))
	return method_db.ensureVisible(attribute)
		
def getAttributeNameWithPid(pid):
	attribute = getAttributeWithPid(pid)
	return attribute.text	
	
def getQuestionWithId(id, force=False):
	k = ndb.Key(objects.Question, int(id))
	q = objects.Question.query(objects.Question._key == k).get()
	if not q:
		q = objects.Question.query(objects.Question.uid == id).get()
		
	if not q:
		return None
		
	if q:
		q = mergeQuestionWithAttributes(q)		
	else:
		return None
	return method_db.addInfoToObject(q, force)	
	
def getQuestionsWithThreadId(thread_id):
	questions = objects.Question.query(objects.Question.thread_id == thread_id, objects.Question.visible == True)
	question_list = mergeQuestionsWithAttributes(questions)
	return method_db.addInfoToList(question_list)	
	
def getQuestionHistoryWithId(question_id):
	lst = []
	original = getQuestionWithId(question_id)
	if not original:
		return
	
	lst.append(original)
	questions = objects.DeadQuestion.query(objects.DeadQuestion.question_id == question_id).order(-objects.DeadQuestion.date_edited)
	for question in questions:
		revert_id = question.uid
		question.uid = original.uid # hack - override the uid
		question.revert_id = revert_id
		question.author_id = original.author_id
		question.author_name = original.author_name
		question.author_image = original.author_image
		question.date = original.date
		question.comment_count = original.comment_count
		question.votes_total = original.votes_total
		question.votes_net = original.votes_net	
		question.thread_id = original.thread_id	
		question.redirect_question = original.redirect_question
		lst.append(question)		
		
	lst = mergeQuestionsWithAttributes(lst)								
	
	return method_db.addInfoToList(lst)			
	
def renderQuestion(me, qid, question):
	cache_key = 'question-rendered'
	body = method_cache.getObjectForTypeAndKey(cache_key, qid)
	if not body:
		if question is None:
			question = getQuestionWithId(qid)
		template_values = {'item' : question}
		body = me.getBody(template_values, 'html/control-question.html')
		method_cache.setObjectForTypeAndKey(cache_key, qid, body)	
	return body	
	
# Inserts attribute into database
def addAttribute(attribute_value, attribute_type):
	pretty_id = getExistingAttribute(attribute_value, attribute_type)
	if pretty_id != '':
		return pretty_id
	attribute = objects.Attribute()
	attribute.type = attribute_type
	attribute.text = attribute_value
	attribute.pretty_id = createCanonicalName(attribute_value)
	method_db.putObject(attribute)
	return attribute.pretty_id
	
def slugify(str):
    str = unidecode.unidecode(str).lower()
    return re.sub(r'\W+','-',str)	
	
def createCanonicalName(value):
	value = value.replace('#', '-sharp')
	value = value.replace('+', '-plus')
	v = slugify(value) + '-interview-questions'
	return v

def getExistingAttribute(attribute_value, attribute_type):
	v = createCanonicalName(attribute_value)
	# Look for the id first
	attributes = objects.Attribute.query(objects.Attribute.pretty_id == v)
	for attribute in attributes:
		if attribute.type == attribute_type:
			return attribute.pretty_id

	# No id found -> look for something with that name
	attributes = objects.Attribute.query(objects.Attribute.text == attribute_value)
	for attribute in attributes:
		if attribute.type == attribute_type:
			return attribute.pretty_id			

	return ''

def clearDuplicateReportCache(dup):
	method_cache.clearObjectForTypeAndId('question-duplicates', None)
	method_cache.clearObjectForTypeAndId('attribute-menus', None)
	
def clearFlaggedCountCache():
	method_cache.clearObjectForTypeAndId('flagged_question_count', None)

def clearPagesForAttribute(attribute_id):
	for s in sorts:
		cache_key = 'question-' + str(attribute_id) + s
		method_cache.clearObjectForTypeAndId(cache_key, None)	
		method_cache.clearObjectForTypeAndId('page-' + str(attribute_id) + '-' + s, None)
		
def appendArrayCombos(arrnew, arrold):
	arrfinal = []
	for ao in arrold:
		for an in arrnew:
			arrfinal.append(an + '-' + ao)
	for an in arrnew:
		arrfinal.append(an)
	for ao in arrold:
		arrfinal.append(ao)
	return arrfinal
		
def clearQuestionAttributeCache(q):
	ids = appendArrayCombos(q.jobs_pretty, q.topics_pretty)
	ids = appendArrayCombos(q.companies_pretty, ids)
	ids_final = []
	for s in sorts:
		ids_final.append('page-' + s)
		for id in ids:
			ids_final.append('page-' + s + '-' + id)
	for id in ids_final:
		method_cache.clearObjectForTypeAndId(id, None)
	method_cache.clearObjectForTypeAndId('attribute-map-text', None)
	method_cache.clearObjectForTypeAndId('attribute-grouped', None) 
	method_cache.clearObjectForTypeAndId('categories', None) 	
	types = ['company', 'topic', 'job']
	method_cache.clearObjectForTypeAndId('attribute-menus', None)		
	for t in types:
		method_cache.clearObjectForTypeAndId('attribute-topbytype', t)
		method_cache.clearObjectForTypeAndId('attribute-allintype', t)	
		method_cache.clearObjectForTypeAndId('attributes', t)
		method_cache.clearObjectForTypeAndId('attribute-menus', t)	
				
def clearQuestionCache(question, clear_cache_for_attributes=False):
	method_cache.clearObjectForTypeAndId('user', str(question.author_id))
	method_cache.clearObjectForTypeAndId('question', question.uid)
	method_cache.clearObjectForTypeAndId('question-questionhtml', question.uid)	
	method_cache.clearObjectForTypeAndId('question-questionhtmltitle', question.uid)	
	method_cache.clearObjectForTypeAndId('question-rendered', question.uid)		
	if clear_cache_for_attributes:
		clearQuestionAttributeCache(question)
	if question.author_id:
		method_cache.clearObjectForTypeAndId('questions-byuser', question.author_id)
	if question.thread_id:
		method_cache.clearObjectForTypeAndId('question-questionthread', question.thread_id)
				
def clearAttributeCache(attribute):
	if attribute:
		clearAttributeCacheWithPid(attribute.pretty_id)	
	else:
		clearAttributeCache(None)
		
def clearAttributeCacheWithPid(pretty_id):
	if pretty_id:
		method_cache.clearObjectForTypeAndId('attribute', pretty_id) 
		method_cache.clearObjectForTypeAndId('image', pretty_id) 
	method_cache.clearObjectForTypeAndId('attribute-map-text', None)
	method_cache.clearObjectForTypeAndId('attribute-grouped', None) 
	method_cache.clearObjectForTypeAndId('categories', None) 	
	types = ['company', 'topic', 'job']
	method_cache.clearObjectForTypeAndId('attribute-menus', None)		
	for t in types:
		method_cache.clearObjectForTypeAndId('attribute-topbytype', t)
		method_cache.clearObjectForTypeAndId('attribute-allintype', t)
		method_cache.clearObjectForTypeAndId('attributes', t)				

def getDuplicateCount():
	dup_count = method_cache.getObjectForTypeAndKey('question-duplicates', None)
	if not dup_count:
		dup_count = objects.DuplicateReport.query().count()
		method_cache.setObjectForTypeAndKey('question-duplicates', None, dup_count)
	return dup_count
	
def getFlaggedCount():
	flagged_count = method_cache.getObjectForTypeAndKey('flagged_question_count', None)
	if not flagged_count:
		flagged_count = objects.Question.query(objects.Question.under_review == True).count()
		method_cache.setObjectForTypeAndKey('flagged_question_count', None, flagged_count)
	return flagged_count		
	
def getDuplicates():
	dups = objects.DuplicateReport.query()
	return dups
	
def refreshQuestionItemData(question, user, item): 
	item.user_id = user.uid
	item.user_name = user.name
	item.author_id = question.author_id
	item.author_name = question.author_name
	item.author_image = question.author_image
	item.text = question.text	
	item.date = question.date
	item.companies_pretty = question.companies_pretty			  
	item.topics_pretty = question.topics_pretty	 
	item.jobs_pretty = question.jobs_pretty	 		   
	item.question_id = question.uid		
	item.comment_count = question.comment_count		
	item.visible = question.visible				
	item.votes_total = question.votes_total
	item.votes_net = question.votes_net
	method_cache.clearObjectForTypeAndId('question', question.uid)

def insertDeadQuestion(question): 
	item = objects.DeadQuestion()
	item.question_id = question.uid
	item.text = question.text
	item.date = question.date	
	item.companies_pretty = question.companies_pretty
	item.topics_pretty = question.topics_pretty
	item.jobs_pretty = question.jobs_pretty	
	method_db.putObject(item)		

def mergeQuestionsWithAttributes(questions):
	question_list = map(lambda q: 
		mergeQuestionWithAttributes(method_db.addInfoToObject(q)), 
		questions)
	return question_list

def mergeQuestionWithAttributes(question):
	question.companies2 = getAttributesInList(question.companies_pretty)
	question.jobs2 = getAttributesInList(question.jobs_pretty)	
	question.topics2 = getAttributesInList(question.topics_pretty)
	return question  
	
def getTopAttributesInType(type):
	attributes = getAttributesByTypeSorted(type, 'questions')
	return attributes[:10]

def getAllAttributes():
	attributes = {}
	attributes['company'] = getAttributesByTypeSorted('company', 'alpha')
	attributes['topic'] = getAttributesByTypeSorted('topic', 'alpha')
	attributes['job'] = getAttributesByTypeSorted('job', 'alpha')
	return attributes
	
def getAttributeIdsByType(type):
	attribute_ids_str = method_cache.getObjectForTypeAndKey(cache_key_attributes_list, type)
	if not attribute_ids_str:			
		attributes = objects.Attribute.query(objects.Attribute.type == type, objects.Attribute.question_count > 0).fetch()
		attribute_ids = []
		for attribute in attributes:
			attribute_ids.append(attribute.pretty_id)
		method_cache.setObjectForTypeAndKey(cache_key_attributes_list, type, ','.join(attribute_ids))
	else:
		attribute_ids = attribute_ids_str.split(',')
	return attribute_ids	

def getMulti(prefix, list):
	lst = {}
	for li in list:
		key = prefix + li
		item = method_cache.getObjectForTypeAndKey(key, None)
		if item is not None:
			lst[li] = item
		logging.info('pulled: ' + key)
	return lst

def deserializeAttribute(attr_str):
	attr = attr_str.split('###')
	a = objects.Attribute(text = attr[0],
					type = attr[1],
					uid = int(attr[2]),
					pretty_id = attr[3],
					question_count = int(attr[4]),
					visible = True)
	return a
	
def serializeAttribute(attr):
	attr_arr = [attr.text, attr.type, str(attr.uid), attr.pretty_id, str(attr.question_count)]
	s = '###'.join(attr_arr)
	return s
	
def getAttributesInList(attribute_ids):
	cached_attributes_strs = method_cache.getMultiObjects('attribute-', attribute_ids)
	not_found_attribute_ids = []
	found_attributes = []
	for att_id in attribute_ids:
		if att_id not in cached_attributes_strs:
			not_found_attribute_ids.append(att_id)
		else:
			found_attributes.append(deserializeAttribute(cached_attributes_strs[att_id]))
	not_found_attributes = []
	if len(not_found_attribute_ids) > 0:
		not_found_attributes = objects.Attribute.query(objects.Attribute.pretty_id.IN(not_found_attribute_ids)).fetch()

	for att in not_found_attributes:
		method_cache.setObjectForTypeAndKey('attribute', att.pretty_id, serializeAttribute(att))
	all_attributes = found_attributes + not_found_attributes
	return all_attributes

def getAttributesByType(type):
	attribute_ids = getAttributeIdsByType(type)
	all_attributes = getAttributesInList(attribute_ids)
	return all_attributes
	
def getAttributesByTypeSorted(type, sort):
	attributes = getAttributesByType(type)
	if sort == 'alpha':
		return sorted(attributes, key=lambda attribute: attribute.text.lower())
	elif sort == 'questions':
		return sorted(attributes, key=lambda attribute: -1 * attribute.question_count)
	return attributes
	
def getQuestionIds(sort, subattributes, set_start):
	return getQuestions(sort, subattributes, set_start, True)	
	
def getQuestions(sort, subattributes, set_start, only_keys=False):	
	qry = objects.Question.query(objects.Question.visible == True)
	
	# Apply attribute filters
	if subattributes['job']:
		qry = qry.filter(objects.Question.jobs_pretty == subattributes['job'])
	if subattributes['company']:
		qry = qry.filter(objects.Question.companies_pretty == subattributes['company'])
	if subattributes['topic']:
		qry = qry.filter(objects.Question.topics_pretty == subattributes['topic'])

	# Get sort order
	if sort == 'comments':
		qry = qry.order(-objects.Question.comment_count).order(-objects.Question.date)		
	elif sort == 'date' or sort is None or sort == '':
		qry = qry.order(-objects.Question.date)
	elif sort == 'recentcomments':
		qry = qry.order(-objects.Question.last_comment).order(-objects.Question.date)
	elif sort == 'votes':
		qry = qry.order(-objects.Question.votes_net).order(-objects.Question.votes_count).order(-objects.Question.comment_count).order(-objects.Question.date)

	# Fetch results
	offset = set_start * per_page
	result = qry.fetch_page(per_page * pages_per_set, offset=offset, keys_only = only_keys)
	return result
	
def getFilterTextFromAttributeType(attribute):
	filter_text = None
	if attribute:
		if attribute['type'] == 'company':
			filter_text = 'companies_pretty ='
		elif attribute['type'] == 'job':
			filter_text = 'jobs_pretty ='
		else:
			filter_text = 'topics_pretty ='	
	return filter_text

def getQuestionCountInPage(attribute, attributes, offset):
	query = objects.Question.query(objects.Question.visible == True)
	
	for attribute in attributes:
		if attribute:
			filter_text = getFilterTextFromAttributeType(attribute)
			query = query.filter(filter_text, attribute['pretty_id'])
	items = query.fetch(per_page * (pages_per_set + 1), offset)

	return len(items)	
	
def getRecentQuestions():
	question_list = method_cache.getObjectForTypeAndKey('question-recent', None)
	if not question_list:
		# Get questions.
		questions = objects.Question.query(objects.Question.visible == True).order(-objects.Question.date).fetch(20)
		question_list = mergeQuestionsWithAttributes(questions)
		method_cache.setObjectForTypeAndKey('question-recent', None, question_list)
	return question_list
	
	