from django.http import HttpResponseRedirect


class MobileRedirectMiddleware(object):
    MOBILE_PREFIX = '/mobile/'

    def process_request(self, request):

        ua = u'%s' % request.META['HTTP_USER_AGENT']
        path = request.path_info
        print path
        mobile_ua = False
        for i in ('Opera Mobi', 'iPod', 'iPad', 'iPhone', 'AvantGo', 'BOLT', 'Android', 'BlackBerry', 'IEMobile'):
            if i in ua:
                mobile_ua = True
                break
        if mobile_ua:
            if not path.startswith(self.MOBILE_PREFIX):
                    # need to redirect to mobile version
                    try:
                       path.index('images') or path.index('files')
                    except:
                        return HttpResponseRedirect('/mobile')
        elif path.startswith(self.MOBILE_PREFIX):
                # need to redirect to normal version
                return HttpResponseRedirect(path[7:])
