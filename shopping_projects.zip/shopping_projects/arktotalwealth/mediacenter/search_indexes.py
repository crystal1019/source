import datetime
from haystack.indexes import *
from haystack import site
from arktotalwealth.mediacenter.models import *

class BlogPostIndex(SearchIndex):
    text = CharField(document=True, use_template=True)
    pub_date = DateTimeField(model_attr='publishdate')

    def index_queryset(self):
        """Used when the entire index for model is updated."""
        return BlogPost.objects.filter(publishdate__lte=datetime.datetime.now(),active=True)    

site.register(BlogPost, BlogPostIndex)