/usr/bin/python /home/chaol/projects/bellabustiere/manage.py update_index > /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/process
echo "---------------" >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/process
cat  /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/process >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/allprocess