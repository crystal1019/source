from django.db import models
from django.contrib.sites.admin import Site

class SiteMeta(models.Model):
    site = models.OneToOneField(Site)
    title = models.CharField(max_length=255, null=True, help_text='default page title on each page of the site')
    meta_keywords = models.TextField(help_text='default keywords on each page of the site', default='')
    meta_description = models.TextField(help_text='default description on each page of the site',default='')


    def __unicode__(self):
        return self.site.domain
    
class MiscPageManager(models.Manager):
    def get_landing_url(self,landing):
        l = MiscPage.objects.filter(is_landing=landing,is_active=True)
        try:
            return l[0].get_absolute_url()
        except:
            return '#'

class MiscPage(models.Model):
    MISC_NAV_CHOICES = [['collections', 'The Collections'],['contact', 'Contact'], ['bio', 'Bio']]
    name = models.CharField(max_length=255)
    slug = models.SlugField(unique=True)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=False)
    is_landing = models.CharField(max_length=100, choices=MISC_NAV_CHOICES, blank=True, null=True)
    priority = models.IntegerField(default=0)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    objects = MiscPageManager()
    
    def __unicode__(self):
        return self.name
    
    
    def get_absolute_url(self):
        return '/%s.html' % self.slug
    
    class Meta:
        ordering = ['-priority',]
        
        
class Collection(models.Model):
    name = models.CharField(max_length=60)
    subtitle = models.CharField(max_length=120)
    image = models.ImageField(upload_to='images')
    priority = models.IntegerField(default=0)
    is_active = models.BooleanField(default=False)
    
    def __unicode__(self):
        return self.name
    
    class Meta:
        ordering = ['-priority']
        

    
class FlashImage(models.Model):
    image = models.FileField(upload_to="images/",help_text='size:')
    in_flash = models.BooleanField(default=False, editable=False)
    in_js = models.BooleanField(default=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True,null=True)
    link = models.URLField(blank=True,null=True)
    priority = models.IntegerField(default=0)
    def __unicode__(self):
        return self.image.name
    
    class Meta:
        ordering = ['-priority',]