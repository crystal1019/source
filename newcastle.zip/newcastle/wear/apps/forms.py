__author__ = 'jacob'
from django import forms
from django.contrib.auth.models import User


class LoginForm(forms.Form):

    first_name = forms.CharField(max_length=254, required=False)
    last_name = forms.CharField(max_length=254, required=False)
    email = forms.EmailField(max_length=254, required=False)
    is_staff = forms.BooleanField(initial=True, required=False)

    def clean(self):
        first_name = self.cleaned_data.get('first_name', '')
        last_name = self.cleaned_data.get('last_name', '')
        email = self.cleaned_data.get('email', '')
        is_staff = self.cleaned_data.get('is_staff', '')
        self.user = None
        users = User.objects.filter(first_name = first_name, last_name = last_name, email= email, is_staff = is_staff)

        for user in users:
          if user.is_active:
            self.user = user

        if self.user is None:
          raise forms.ValidationError('Invalid username or password')
        # We are setting the backend here so you may (and should) remove the line setting it in myauth.views
        self.user.backend = 'django.contrib.auth.backends.ModelBackend'

        return self.cleaned_data
