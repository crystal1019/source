import datetime
from haystack.indexes import *
from haystack import site
from arktotalwealth.service.models import *

class ServicePageIndex(SearchIndex):
    text = CharField(document=True, use_template=True)

site.register(ServicePage, ServicePageIndex)