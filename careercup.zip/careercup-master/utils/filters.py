import re
from google.appengine.ext import webapp

import cgi

def replace ( string, args ):
	search  = args.split(args[0])[1]
	replace = args.split(args[0])[2]
	return re.sub( search, replace, string )

def fixcompilablecode ( string ):
	string = string.replace('<', '&lt;')
	string = string.replace('&lt;pre', '<pre')
	string = string.replace('&lt;/pre', '</pre')
	return string

def csvlist ( thelist ):
	string = ''
	for a in thelist:
		string = string + str(a) + ','
	return string

def csvify ( string ):
	if not string:
		return ''
	string = string.replace('"', '""')
	return string.replace('"', '\"')

def rightStrip(s, end):
	while s.endswith(end):
		invlen = -1 * len(end)
		s = s[:invlen]
	return s

def leftStrip(s, end):
	while s.endswith(end):
		invlen = -1 * len(end)
		s = s[invlen:]
	return s

def codify ( string ):
	string = cgi.escape(string)
	string = string.strip()
	pieces = []
	chunks = string.split('{{{')
	index = 0
	for chunk in chunks:
		if index == 0:
			if len(chunk.strip()) > 0:
				pieces.append('<p>')
				pieces.append(chunk.strip().replace('\n', '<br />'))
				pieces.append('</p>')
		else:
			if '}}}' not in chunk:
				return string
			parts = chunk.split('}}}')
			code_part = parts[0]
			text_part = parts[1]
			pieces.append('<p><code><pre class="language-java">')	
			pieces.append(code_part.strip())
			pieces.append('</pre></code></p>')
			if len(text_part.strip()) > 0:
				pieces.append('<p>')
				pieces.append(text_part.strip().replace('\n', '<br />'))
				pieces.append('</p>')
		index = index + 1
	return ''.join(pieces)

def codifystrip ( string ):
	c1 = string.count('{{{')
	if (c1 > 0 and c1 == string.count('}}}')):
		string = string.replace('{{{', '')
		string = string.replace('}}}', '')
	return string
	
def abbreviatenum ( val ):
	if val >= -999 and val < 1000:
		return int(val)
	elif val >= 1000 and val < 10000:
		# 5232 -> 5.2k
		return str(round(val / 1000.0, 1)) + "k"
	elif val >= 10000 and val < 1000000:
		#23232 -> 23k
		#123456 -> 123k
		return str(int(val / 1000.0)) + "k"
	elif val >= 1000000 and val < 10000000:
		#1234567 -> 1.2m
		return str(round(val / 1000000.0, 1)) + "m"
	elif val >= 10000000 and val < 100000000:
		#12345678 -> 1m
		return str(int(val / 1000000)) + "m"
	elif val <= -1000:
		#-1234 -> -1k
		return str(int(val / 1000.0)) + "k"
	
# get registry, we need it to register our filter later.
register = webapp.template.create_template_register()
register.filter(replace)
register.filter(codify)
register.filter(codifystrip)
register.filter(fixcompilablecode)
register.filter(csvlist)
register.filter(csvify)
register.filter(abbreviatenum)