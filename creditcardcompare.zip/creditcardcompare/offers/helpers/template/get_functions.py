from datetime import date
from offers.helpers.lead.models import Lead
from offers.core.models import Category, Offer
from offers.utils.data_cache.helpers import get_cached_meta_fields
from offers.helpers.boyd import add_months


def lead(lead_id):
    lead = Lead.objects.get(id=lead_id)
    return '%s %s' % (lead.first_name, lead.last_name)
    
def category(category_id):
    return Category.objects.get(id=category_id).name

def has_category(categories, category_slug):
    for category in categories:
        if category.slug == category_slug:
            return True
    return ''

def months_of_year(month_range=12):
    today = date.today()
    values = []
    for x in range(month_range):
        d = add_months(today, -x)
        values.append(d)
    return values

def meta_value(offer, meta):
    try:
        meta = offer.meta_instances.filter(meta_field=meta)[0]
        return meta.intro_value_or_default
    except IndexError:
        return '-'

def offer_meta_list(offer, sortable_meta_fields):
    OFFER = 0
    return get_cached_meta_fields(offer, sortable_meta_fields, OFFER)

def meta_fields(offer, sortable_meta_fields, show_intro_value=False):
    return get_cached_meta_fields(offer, sortable_meta_fields)

def bank_issuers():
    return Category.on_site.filter(parent__slug='credit-card-issuers'
                                      ).exclude(slug='mastercard-credit-cards'
                                      ).exclude(slug='visa-credit-cards')

def offer_object(offer_id):
    try:
        return Offer.objects.get(id=offer_id)
    except Offer.DoesNotExist:
        return 'deleted'

def intro_rate_expiration(*args):
    today = date.today()
    meta = args[0].meta_instances.filter(meta_field__key='Intro Purchase Period')
    try:
        month = today.month + int(meta[0].value)
    except (IndexError,ValueError):
        return '-'
    year = today.year + (month/12 if month%12 else month/12-1)
    return date(year, month%12 or 12, 1)
