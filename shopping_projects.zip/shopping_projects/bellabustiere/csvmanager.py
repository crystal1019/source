import csv
from django.template.defaultfilters import slugify
from django.contrib.sites.models import Site
from bellabustiere.shop.models import *
from django.contrib.sites.models import Site
import os
from bellabustiere.userprofile.models import *

class ColorManager():
    def __init__(self):
        self.path = 'color_upload.csv'
        self.downloadpath = 'color_download.csv'
        self.records = self.readFile()
        self.title = ['name', 'brand', 'hex', 'image']
    
    def readFile(self):
        f = csv.reader(open(self.path,'rb'),delimiter=',')
        records = []
        for x in f:
            records.append(x)
            
        records = records[1:]
        print records
        return records        
    
    def upload(self):
        for x in self.records:
            if x[0]:
                name = x[0].strip().title()
                brand = x[1].strip()
                code = brand + ' ' + name if brand else name
                style,created = Style.objects.get_or_create(code=code)
                style.name = name
                if brand:
                    br, created = Brand.objects.get_or_create(slug=slugify(brand))
                    br.name = brand
                    br.save()
                    style.brand = br
                
                if x[2].strip():
                    style.color = x[2].strip()
                
                if x[3].strip():
                    style.image = 'images/%s' %x[3].strip()
    
                style.save()
                
        return 1
                
class ProductManager:
#Title    SKU    Description 1 (Short Description)    Description 2 (Additional Description)    Meta Keywords    Meta Description    Price    Minimum Quantity    Maximum Quantity    Tax Rate (%)    Category    Designer    Activity(s)    Status (Available/Featured/Out of Stock)    Weight(grams)    Length(cm)    Width(cm)    Height(cm)    Priority(where it appears on the page)    Best Sellers (SKU, seperated by ',')    Shop The Look(sku, seperated by ',')    Size/Colour/Inventory combination (size,color,inventory, please make sure the color part using the same word from the color spreadsheet)    Size & Fit    Images (imagename, color)
    def __init__(self):
        self.path = 'product_upload.csv'
        self.downloadpath = 'product_download.csv'
        self.records = self.readFile()
        self.title = ['Title','SKU','Description 1 (Short Description)','Description 2 (Additional Description)', 'Meta Keywords', 'Meta Description', 'Price', 'Minimum Quantity', 'Maximum Quantity',  'Tax Rate (%)', 'Category', 'Designer', 'Activity(s)',  'Status (Available/Featured/Out of Stock)', 'Weight(grams)', 'Length(cm)', 'Width(cm)', 'Height(cm)',  'Priority(where it appears on the page)',  "Best Sellers (SKU, seperated by ',')", "Shop The Look(sku, seperated by ',')", "Size/Colour/Inventory combination (size,color,inventory, please make sure the color part using the same word from the color spreadsheet)", "Size & Fit", "Images (imagename, color)"]
    def readFile(self):
        f = csv.reader(open(self.path,'rb'),delimiter=',')
        records = []
        for x in f:
            records.append(x)
            
        records = records[1:]
        print records
        return records
    
    def convertToP(self, origin):
        p = ''
        if origin:
            if '<p>' in origin and '</p>' in origin:
                p = origin
            else:
                l = origin.split('\n')
                
                for x in l:
                    p += "<p>%s</p>" %x
        return p    
    
    def upload(self):
        aurate = TaxRate.objects.get(rate=1.1)
        site = Site.objects.get(id=1)
        for x in self.records:
            if x[1]:
                code = x[1].strip()
                obj,created = Product.objects.get_or_create(code=code)
                obj.title = x[0].strip()
                obj.meta_keywords = x[4].strip()
                obj.meta_description = x[5].strip()
                obj.tax_rate = aurate
                
                try:
                    obj.price = float(x[6].strip().replace('$',''))
                except:
                    pass
                
                try:
                    obj.minimum_quantity = int(x[7].strip())
                except:
                    pass
                try:
                    obj.maximum_quantity = int(x[8].strip())
                except:
                    pass
                
                obj.description = x[2].strip()

                    
                try:
                    status, created = ProductStatus.objects.get_or_create(status=x[13].strip())
                    obj.status = status
                    
                except:
                    obj.status = ProductStatus.objects.get_or_create(status='Available')
                try:
                    obj.weight = int(x[14])
                except:
                    pass
                try:
                    obj.length = int(x[15])
                except:
                    pass
                try:
                    obj.width = int(x[16])
                except:
                    pass
                try:
                    obj.height = int(x[17])
                except:
                    pass
                try:
                    obj.priority = int(x[18])
                except:
                    pass
                
                try:
                    obj.size_fit = self.convertToP(x[22].strip())    
                except:
                    pass
                
                obj.save()
                obj.sites.add(site)
                
                try:
                    obj.details = self.convertToP(x[3].strip())    
                    obj.save()
                except:
                    pass
                
                #category
                if x[10].strip():
                    
                    obj.category_now.clear()
                    cats = x[10].strip().split(',')
                    for xx in cats:
                        if xx.strip():
                            slug = slugify(xx.strip())
                            thecat, created = Categories.objects.get_or_create(slug=slug)
                            thecat.name = xx.strip().title()
                            thecat.is_active = True
                            thecat.save()
                            thecat.sites.add(site)
                            obj.category_now.add(thecat)
                
                #designer
                if x[11].strip():
                    
                    obj.brand.clear()
                    cats = x[11].strip().split(',')
                    for xx in cats:
                        if xx.strip():
                            slug = slugify(xx.strip())
                            thecat, created = Brand.objects.get_or_create(slug=slug)
                            thecat.name = xx.strip().title()
                            thecat.is_active = True
                            thecat.save()
                            thecat.sites.add(site)
                            obj.brand.add(thecat)                    
                
                #activity
                if x[12].strip():
                    obj.activity.clear()
                    cats = x[12].strip().split(',')
                    for xx in cats:
                        if xx.strip():
                            slug = slugify(xx.strip())
                            thecat, created = Activity.objects.get_or_create(slug=slug)
                            thecat.name = xx.strip().title()
                            thecat.is_active = True
                            thecat.save()
                            thecat.sites.add(site)
                            obj.activity.add(thecat)                       
                
                #related_products:
                if x[19].strip():
                    obj.related_products.clear()
                    cats = x[19].strip().split(',')
                    
                    for xx in cats:
                        if xx.strip():
                            p, created = Product.objects.get_or_create(code=xx.strip())
                            
                            obj.related_products.add(p)    
                            obj.related_look.all()
                #shop the look
                if x[20].strip():
                    obj.related_look.clear()

                    cats = x[20].strip().split(',')
                    for xx in cats:
                        if xx.strip() and '(' not in xx.strip():
                            p, created = Product.objects.get_or_create(code=xx.strip())
                            obj.related_look.add(p)          
                            obj.related_look.all()
                #size color, color uploaded already
                if x[21].strip():

                    rows = x[21].strip().split('|')
                    for xx in rows:
                        try:
                            xxx = xx.split(',')
                            size, color, inventory = xxx[0].strip(),xxx[1].strip().title(),int(xxx[2].strip())
                            s, created = Size.objects.get_or_create(code='#'+size+'#')
                            s.name = size
                            s.save()
                            c = Style.objects.filter(name=color)
                            if c.count() > 1:
                                c = c.filter(brand__name__iexact = x[11].strip())
                            try:
                                c = c[0]
                            except:
                                ccc = x[11].strip() + ' ' + color
                                c,created = Style.objects.get_or_create(code=ccc)
                                c.name = color
                                c.save()
                            
                            try:
                                psc = obj.productsizecolor_set.filter(size=s,style=c)
                                if psc:
                                    psc = psc[0]
                                    
                                psc.inventory = inventory
                                psc.save()
                            
                            except:
                                psc = ProductSizeColor()
                                psc.product = obj
                                psc.size = s
                                psc.style = c
                                psc.inventory = inventory
                                psc.save()
                        except:
                            pass
                
                #images
                if x[23].strip():
                    currentimages = obj.productimage_set.all()
                    for xx in currentimages:
                        xx.image = 'images/a'
                        xx.save()
                    currentimages.delete()
                    rows = x[23].strip().split('|')
                    for xx in rows:
                        try:
                            xxx = xx.split(',')
                            name, color = xxx[0].strip(), ' '.join(xxx[1].strip().split(' ')[1:])
                            c = Style.objects.filter(name__iexact=color)
                            if c.count() > 1:
                                c = c.filter(brand__name__iexact = x[11].strip())
                            c = c[0]                            
                            
                            pi = ProductImage()
                            pi.product = obj
                            pi.image = "images/%s" %(name)
                            pi.style = c
                            pi.save()
                            
                        except:
                            pass
                
                