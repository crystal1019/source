from django.conf.urls.defaults import *

urlpatterns = patterns('berowrawatersinn.location.views',
        (r'^$', 'home'),
        (r'^(?P<slug>.*).html$', 'home'),
                       
)