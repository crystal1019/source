from django.conf.urls import patterns, include, url
from django.conf import settings
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'liox_on_demand.views.home', name='home'),
    # url(r'^liox_on_demand/', include('liox_on_demand.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    #Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
    url(r'^accounts/login/$', 'django.contrib.auth.views.login', {'template_name': 'od_login.html'}, name='login'),
    url(r'^accounts/logout/$', 'django.contrib.auth.views.logout', {'next_page': '/'}, name='logout')   ,
    url(r'^accounts/', include('registration.backends.default.urls')),
    url(r'^accounts/password_reset/$', 'django.contrib.auth.views.password_reset',{'template_name': 'forgotten.html','email_template_name':'registration/password_reset_email.html',"post_reset_redirect" : '/accounts/password_reset_done'}, name='password_reset'),
    url(r'^accounts/password_reset_done/$', 'django.contrib.auth.views.password_reset_done',{'template_name': 'registration/password_reset_done.html'}),
    url(r'^accounts/reset/(?P<uidb36>[-\w]+)/(?P<token>[-\w]+)/$', 'django.contrib.auth.views.password_reset_confirm',{'template_name': 'registration/password_reset_confirm.html'}),
    url(r'^accounts/reset/done/$', 'django.contrib.auth.views.password_reset_complete',{'template_name': 'registration/password_reset_complete.html'}),
)
urlpatterns += staticfiles_urlpatterns()

urlpatterns = urlpatterns + patterns('', url(r'^', include('liox_on_demand.od_app.urls')))
