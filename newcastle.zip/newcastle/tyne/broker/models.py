from flask.ext.sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Organizations(db.Model):
	'''
	For organization info
	'''
	
	'''
	CREATE TABLE organizations (
	  orgId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	  name VARCHAR(255) NOT NULL,
	  url VARCHAR(255),
	  dbPrefix VARCHAR(20),
	  description VARCHAR(255)
	);
	'''
	__tablename__ = 'organizations'
	orgId = db.Column(db.Integer, primary_key = True)
	name = db.Column(db.String(255))
	url = db.Column(db.String(255))
	dbPrefix = db.Column(db.String(255))
	description = db.Column(db.String(255))


	def __init__(self, name, dbPrefix, url = None, description = None):
		self.name = name
		self.dbPrefix = dbPrefix
		self.url = url
		self.description = description
		

class AWDemoUsers(db.Model):
	'''
	For org demo.appointment.works 
	This table stores user data for the demo.appointment.works org
	'''
	
	'''
	CREATE TABLE awdemoUsers (
	  awId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	  bookedId INT NOT NULL,
	  phoneNum VARCHAR(10)
	);
	'''
	__tablename__ = 'awdemoUsers'
	awId = db.Column(db.Integer, primary_key = True)
	bookedId = db.Column(db.Integer)
	phoneNum = db.Column(db.String(10))


	def __init__(self, phoneNum, bookedId=None):
		self.phoneNum = phoneNum
		self.bookedId = int(bookedId)
