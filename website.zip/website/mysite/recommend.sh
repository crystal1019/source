#!/bin/sh

# the recommender needs an X display for opencv (are you kidding me?)
# Use vncserver and export the display there.
# the vncserver password is: aoeusnth
# the server runs on: li510-191:1

# Needy man's cron
#export DISPLAY=li510-191:1
#export DISPLAY=:1
while [ 1 ]; do
    sleep 30;
    python manage.py recommend >> /tmp/recommend 2>&1
done
