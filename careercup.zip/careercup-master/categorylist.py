import masterpage
import method_question
import method_cache

class ViewCategoryList(masterpage.MasterPage):
	def get(self):
		page_cache_key = 'categories'
		body = method_cache.getObjectForTypeAndKey(page_cache_key, None)
		if body:
			template_values = {}
			template_values['rendered_body'] = body
			self.pushPage(template_values, 'Technical Interview Questions', 'html/main.html')
			return		
		
		attributes = method_question.getAllAttributes()
		companies = attributes['company']
		jobtitles = attributes['job']
		topics = attributes['topic']
		
		template_values = {
			'companies': companies,
			'jobtitles': jobtitles,
			'topics': topics,
			'parent_tab': 'interviews',	
		}		 
		
		body = self.getBody(template_values, 'html/categorylist.html')
		method_cache.setObjectForTypeAndKey(page_cache_key, None, body)
		template_values = {}
		template_values['rendered_body'] = body
		self.pushPage(template_values, 'Interview Question Categories', 'html/main.html')			  

		

