from django.db import models
from django.utils.translation import ugettext_lazy as _

from offers.core.models import Offer

RATING_CHOICES = (
    (1, ''),
    (2, ''),
    (3, ''),
    (4, ''),
    (5, ''),
)
USAGE_LENGTH = (
    (1, '12 months or less'),
    (2, '1-5 years'),
    (3, 'More than 5 years'),
)

class Survey(models.Model):
    title = models.CharField(max_length=100, unique=True)
    question = models.TextField()
    is_visible = models.BooleanField(_('is visible'), default=True)
    
    def __unicode__(self):
        return self.title
    
class CardSurvey(models.Model):
    survey = models.ForeignKey(Survey)
    review = models.ForeignKey('CardReview')
    rating = models.DecimalField(_('star rating'), max_digits=3, decimal_places=2, default=0)
    
class CardReviewManager(models.Manager):    
    def public_all(self):
        return super(CardReviewManager, self).all().filter(is_public=True)
        
    def surveys(self):
        try:
            review = self.get_queryset()[0]
        except IndexError:
            return []
        return Survey.objects.filter(cardreview__card=review.card, cardreview__is_public=True).annotate(average=models.Avg('cardsurvey__rating'))
    
    def average(self):
        try:
            review = self.get_queryset()[0]
        except IndexError:
            return []
        return CardReview.objects.filter(card=review.card, is_public=True).aggregate(average=models.Avg('cardsurvey__rating'))['average']
    
class CardReview(models.Model):
    title = models.CharField(max_length=50)
    card = models.ForeignKey(Offer)
    ratings = models.ManyToManyField(Survey, through=CardSurvey)
    comment = models.TextField()
    pros = models.CharField(max_length=100)
    cons = models.CharField(max_length=100)
    recommend = models.BooleanField()
    name = models.CharField(max_length=20)
    email = models.EmailField()
    submitted = models.DateField(auto_now_add=True)
    is_public = models.BooleanField()
    voucher = models.BooleanField(default=True)
    
    objects = CardReviewManager()
    
    class Meta:
        ordering = ('-submitted',)
    
    def __unicode__(self):
        return '%s (by %s)' % (self.title, self.name)
    
    @property
    def average(self):
        return self.ratings.all().aggregate(avg=models.Avg('cardsurvey__rating'))['avg']
    
    def hint(self):
        '''Copied from template "boyd_apps\reviews\templates\reviews\reviews-step-1.html".
        This is the hint list specified for jquery raty.
        '''
        return ['Terrible', 'Bad', 'Okay', 'Good', 'Excellent'][int(self.average-1)]
