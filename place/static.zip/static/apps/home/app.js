angular.module('HomeApp',
    [
        'home.controllers',
        'home.directives',
        'common.directives',
        'common.services'
    ]
).config(["$httpProvider",
    function($httpProvider) {
        $httpProvider.defaults.headers.post['X-CSRFToken'] = $('input[name=csrfmiddlewaretoken]').val();
    }
]);