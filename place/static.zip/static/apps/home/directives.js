angular.module('home.directives', [])
    .directive('homeGmap', ["$http", function ($http) {
        return {
            link: function (scope, elem, attrs) {
                scope.safeApply(function(){
                    scope.gmap = new GMap2(elem.attr('id'), {
                        zoom: 13,
                        center: new google.maps.LatLng(user_location.lat, user_location.lng)
                    });
                    scope.glayer = new GLayer(scope.gmap);
                    $http.post('/maps/places/')
                    .success(function(places) {
                        scope.glayer.loadParticipants(places);
                    });

                    $http.get('/maps/homepage_topics/')
                    .success(function(data){
                        scope.topics = data.data;
                        scope.glayer.addTopics(scope.topics.map_topics);
                        scope.addCategoryIcons(scope.topics.card_topics);
                    });
                });
            }
        };
    }])
    .directive('homeOrganizations', ["$timeout", function($timeout){
        return {
            link: function(scope, elem, attrs){
                elem.carousel({
                    interval: 5000
                });
            }
        }
    }]);
