from django.db import models
from django.contrib.sites.models import Site


class ExtendedSite(models.Model):
    ga_code = models.CharField(u'GA Code', max_length=20, blank=True, null=True, help_text=u'Google Analytics ID (e.g. UA-28389611-1)')
    slug_trailer = models.CharField(max_length=15, blank=True, null=True)
    site = models.OneToOneField(Site)

    class Meta:
        verbose_name_plural = 'Site Settings'
        db_table = 'sites_extendedsite'

    def __unicode__(self):
        return self.site.name