# from datetime import datetime
# # from constans import DEFAULT_DATA_FORMAT
#
# def datafmt(data_string):
#     return datetime.strftime(data_string)
#
# s = Student('Mary', '1981-7-23')
