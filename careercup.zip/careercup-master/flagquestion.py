import masterpage

import method_db
import method_email
import method_question
import method_url
import method_cache
import method_user
	
class FlagQuestion(masterpage.MasterPage):	
	def post(self):		
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return

		id = method_url.getId(self)
		question = method_question.getQuestionWithId(id, True)		
			
		# Add user to question
		users = question.flag_users
		if users == None:
			users = []
		elif user.uid in users: # User has already flagged the question
			return
		users.append(user.uid)			
		question.flag_users = users
		
		# Add reason to question
		reason = self.request.get('flagReason')
		reasons = question.flag_reasons
		if reasons == None:
			reasons = []
		reasons.append(reason)
		question.flag_reasons = reasons		

		# Delete question if necessary
		question.flag_count = question.flag_count + 1
		if question.flag_count >= method_question.flag_limit or method_user.userIsAdmin():
			question.visible = False
		question.under_review = True
		method_db.putObject(question)
		
		method_cache.clearObjectForTypeAndId('mainpage', None)
		method_cache.clearObjectForTypeAndId('rss', None)	
		method_question.clearFlaggedCountCache()
		method_question.clearQuestionCache(question, True)	
		method_email.sendMeEmail('', 'Flagged Question Reported', 'Flagged Question Reported') 	
		self.displayError('Thank You!', 'Thank you!  This flag will be looked at shortly by a moderator. <br/><br/> Wanna be a moderator?  Email gayle@careercup.com.')		
 
	def get(self):		  
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return	
		id = method_url.getId(self)
		question = method_question.getQuestionWithId(id, True)
		if user.uid in question.flag_users:
			already_flagged = True
		else:
			already_flagged = False
		
		template_values = {'question_id': id, 'parent_tab': 'interviews', 'already_flagged' : already_flagged}
		self.pushPage(template_values, 'Flag Question', 'html/flagquestion.html')   
		
