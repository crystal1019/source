$(function() {
    var $form = $('#select_campaign_form');
     $('select', $form).change(function() {
        $form.submit();
     });
});
