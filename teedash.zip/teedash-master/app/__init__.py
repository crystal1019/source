from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
# DB Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
db = SQLAlchemy(app)

#db URL: postgres://aqkkcnrdsfygwj:MBpRClFha8-Ioz9qrv_JawvKrA@ec2-54-204-41-249.compute-1.amazonaws.com:5432/d9ijhsbtmid78o

from app import views, models