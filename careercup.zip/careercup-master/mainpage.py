import masterpage

import method_question
import method_cache
import objects
	
class MainPage(masterpage.MasterPage):		
	def getQuestions(self):
		questions = objects.Question.query(objects.Question.visible == True).order(-objects.Question.date).fetch(5)
		question_list = method_question.mergeQuestionsWithAttributes(questions)
		return question_list

	def get(self):	
		question_ids = method_cache.getObjectForTypeAndKey('mainpage', None)
		
		if not question_ids:
			questions = self.getQuestions()
			rendered_questions = []
			question_ids = []
			for q in questions:
				rendered = method_question.renderQuestion(self, q.uid, q)
				question_ids.append(q.uid)
				rendered_questions.append(rendered)
			question_ids = method_cache.setObjectForTypeAndKey('mainpage', None, question_ids)				
		else:					
			rendered_questions = []
			for quid in question_ids:
				rendered = method_question.renderQuestion(self, quid, None)
				rendered_questions.append(rendered)
		
		template_values = {
			'rendered_question_list': rendered_questions,
			'parent_tab': 'interviews',	
			'is_home': True,
		}
		
		body = self.getBody(template_values, 'html/index.html')

		template_values = {'parent_tab': 'interviews', 'is_home': True, 'rendered_body' : body}
		self.pushPage(template_values, '', 'html/main.html')