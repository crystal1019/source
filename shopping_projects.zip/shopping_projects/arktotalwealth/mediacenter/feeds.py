from django.contrib.syndication.views import Feed
from arktotalwealth.mediacenter.models import BlogPost
import datetime

from django.conf import settings

class BlogFeed(Feed):
    title = 'Ark Total Wealth News & Events'
    link = 'http://%s%s' %(settings.DOMAIN, '/news/')
    description = 'Ark Total Wealth News & Events rss feed '
    
    def items(self):
        temp = list(BlogPost.objects.filter(active=True, publishdate__lte=datetime.datetime.now()).order_by("publishdate"))
        return temp[-20:]
    
    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.content
    
    def item_link(self,item):
        return 'http://%s%s' % (settings.DOMAIN, item.get_absolute_url() )
    
    def item_pubdate(self,item):
        return item.publishdate