angular.module('map.controllers', []).controller('MapEditCtrl', ["$scope", "$http", "$route", "$routeParams", "MapData",
    function($scope, $http, $route, $routeParams, MapData) {

        $scope.$route = $route;
        $scope.$routeParams = $routeParams;
        $scope.MapData = MapData;
        if (!angular.isDefined($scope.map_url)) {
            $scope.map_url = '/mapedit/';
        }

        $scope.type = "map";

        $scope.MapData.url = $scope.map_url;

        $scope.map = null;
        $scope.polys = [];
        $scope.map_preview = null;
        $scope.error = null;

        $scope.is_valid = true;

        $scope.map_tools = {
            label: true,
            draw: true,
            color: true,
            map_view: true,
            upload: true,
            delete_single: true,
            delete_all: true
        };
        if (angular.isDefined($scope.map_tools_view)) {
            $scope.map_tools.map_view = $scope.map_tools_view;
        }

        // Load data
        $scope.$watch("current_tab", function(tab) {
            if (tab == "/map") {
                if (!MapData.active) {
                    $scope.MapData.load($scope.topic || $scope.psc_client).then(function(obj) {}, function(reason) {});
                }
            }
        });

        $scope.drawPolygon = function() {
            if ($scope.MapData.layer.is_drawing) {
                $scope.MapData.layer.disableDrawing();
            } else {
                $scope.MapData.layer.enableDrawing();
            }
        };

        $scope.deleteFeature = function() {
            $scope.MapData.layer.deleteFeature($scope.MapData.layer.selected_feature);
            $scope.MapData.infowindow.close();
            if (angular.isDefined($scope.psc_client)) {
                $scope.MapData.layer.fitLayer(true);
            }
            $scope.$emit("tabchange", "/map", $scope);
        };

        $scope.save = function() {
            var edits = {
                // Get additions, deletes and modifications.
                'geo': $scope.MapData.layer.getUpdates(),
                'map_center': $scope.MapData.store.map_center,
                'map_zoom': $scope.MapData.store.map_zoom
            };
            var p = $scope.MapData.save(edits);
            if ($scope.map_preview) {
                $scope.map_preview.hide();
            }

            $scope.MapData.layer.clearStack();
            $scope.$emit("tabreset", "/map");
            return p;
        };

        $scope.deleteAll = function() {
            $scope.MapData.layer.deleteAllFeatures();
            if (angular.isDefined($scope.$colorpicker)) {
                $scope.$colorpicker.hide();
            }
            $scope.$emit("tabchange", "/map", $scope);
        };

        $scope.mapView = function() {
            if (!$scope.map_preview) {
                $scope.map_preview = new MapPreviewWindow($scope.MapData.gmap.map);
                $scope.map_preview.bind('previewchange', function(map_center, zoom) {
                    $scope.MapData.store.map_center = [map_center.lat(), map_center.lng()];
                    $scope.MapData.store.map_zoom = zoom;
                    $scope.$emit('tabchange', '/map', $scope);
                });
            }
            // These options shift the map so the stored map center and zoom
            // are used for the map preview.
            var opts = {
                init_center: new google.maps.LatLng($scope.MapData.store.map_center[0], $scope.MapData.store.map_center[1]),
                init_zoom: $scope.MapData.store.map_zoom || $scope.MapData.store.zoom
            };
            $scope.map_preview.toggle(opts);
        };

        $scope.changeColor = function(hex) {
            $scope.MapData.layer.selected_feature.setOptions({
                'fillColor': hex
            });
            $scope.MapData.layer.addToEditStack($scope.MapData.layer.selected_feature, GLayer.MODIFIED);
        };

        $scope.uploadGeoFile = function() {
            if ($scope.has_feature('kml')) {
                filepicker.pick({
                        container: 'modal',
                        services: ['BOX', 'COMPUTER', 'DROPBOX']
                    },
                    function(InkBlob) {
                        $scope.MapData.error = null;
                        $scope.$apply(
                            $http.post(
                                '/assets/geo_file_upload/',
                                $.param(InkBlob), {
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }
                                }
                            ).success(function(obj) {
                                if (obj.success) {
                                    $scope.MapData.layer.loadEncodedPolygons(obj.data, true, true);
                                    //$scope.MapData.layer.fitLayer();  // To slow for big layers
                                } else {
                                    $scope.MapData.error = obj.error;
                                }
                            }).error(function(data, status) {
                                //   console.log(status);
                            })
                        );
                    },
                    function(FPError) {
                        //console.log(FPError.toString());
                    }
                );
            }
        };

        $scope.labelChanged = function() {
            $scope.MapData.layer.addToEditStack(MapData.layer.selected_feature, 2);
        };

        $scope.$watch("MapData.layer.selected_feature", function(current_feat, prev_feat) {
            if (current_feat !== null && angular.isDefined(current_feat)) {
                if (!angular.isDefined(current_feat.center_marker) && current_feat.feature_type == 'polygon') {
                    current_feat.center_marker = $scope.MapData.layer.getFeatureCenter(current_feat);
                }
                if (current_feat.feature_type == 'polygon') {
                    var infowindowMarker = new google.maps.Marker({
                        position: current_feat.center_marker.position,
                        map: $scope.MapData.gmap.map
                    });
                    infowindowMarker.setVisible(false);
                    $scope.MapData.infowindow.open(
                        $scope.MapData.gmap.map,
                        infowindowMarker
                    );
                }
            } else {
                if (angular.isDefined($scope.MapData.infowindow) && $scope.MapData.infowindow !== null) {
                    $scope.MapData.infowindow.close();
                }
            }
        });
    }
]).controller('MapViewCtrl', ["$scope", "$http", "$route", "$routeParams", "MapData",
    function($scope, $http, $route, $routeParams, MapData) {

        $scope.id = data.id;

        $scope.$route = $route;
        $scope.$routeParams = $routeParams;
        $scope.MapData = MapData;
        $scope.map = null;
        $scope.polys = [];

        // Load data
        if (!MapData.active) {
            $scope.MapData.load($scope.id).then(function(obj) {}, function(reason) {});
        }
    }
]);