from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.context_processors import csrf
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseServerError, \
    HttpResponseForbidden

from models import Profile, Recipe, RecipeManual, BlogPost, \
    UserFeed

from friends import anon
from users import notifications

UPDATES_COUNT = 16

def home(request):
    c = RequestContext(request)
    c.update(csrf(request))

    if not anon(request.user):

        events = UserFeed.objects.filter(
            user = request.user,
            user_own_evt = False
            ).order_by('-created')[:UPDATES_COUNT]

        num_cols = 4
        columns = [[evt for (j, evt) in enumerate(events)
                    if j % num_cols == i] for i in range(num_cols)]

        c.update({
                'notifications': notifications(request.user),
                'recipes': request.user.recipe_set.all(),
                'friends': request.user.profile.friends(),
                'event_columns': columns
                })

    if 'next' in request.GET:
        c.update({'next': request.GET['next']})

    if 'msg' in request.GET:
        c.update({'msg': request.GET['msg']})

    return render_to_response('home.html', c)


def access_control(request):
    if request.method == 'POST':
        obj = None

        if 'recipe' in request.POST:
            obj = Recipe.objects.get(id = request.POST['recipe'])
            if obj.author != request.user:
                return HttpResponseForbidden()
        elif 'user' in request.POST:
            obj = request.user.profile

        obj.access = request.POST['access']
        obj.save()
        return HttpResponse()

    return HttpResponseServerError()

def bookmarklet(request):
    c = RequestContext(request)
    return render_to_response('bookmarklet.html', c)

def welcome(request):
    c = RequestContext(request)
    return render_to_response('welcome.html', c)
