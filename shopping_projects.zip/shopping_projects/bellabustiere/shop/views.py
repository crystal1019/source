'''
@author: chaol
'''

from django.template import Context, loader, RequestContext
from django.http import HttpResponse, HttpResponseRedirect, Http404
import datetime, time
from models import *
from django.db import connection
import httplib, urllib
from django.db.models import Q

import pprint, hashlib

from django.core.mail import send_mail

from django.core.cache import cache
from django.core.paginator import *
from django.contrib.auth import authenticate
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout

from django.contrib.auth.models import AnonymousUser

from django.conf import settings

from bellabustiere import common

from bellabustiere.userprofile.models import *

from ShopLogging import Log

from django.core.mail import EmailMultiAlternatives

from forms import *

from bellabustiere.shop.forms import *

from bellabustiere.shop import generateAmountHash
from bellabustiere import helpers

from django.utils import simplejson
from django.contrib.sites.models import Site
from django.template.defaultfilters import slugify

def home(request):
    
    
    return HttpResponseRedirect("/")

def voucher(request):
    t = loader.get_template('voucher.html')
    rp = request.POST
    msg = ''
    if rp:
        form = VoucherForm(rp)
        if form.is_valid():
            v = form.save()
            order, sync = helpers.getCurrentOrder(request)
            if order:
                request.session["order_id"] = order.id
            try:
                vo = VoucherOrder()
                vo.order = order
                vo.voucher = v
                vo.quantity = 1
                vo.price = v.value
                vo.save()
                msg = 'Added to bag'
                order.save()
            except:
                msg = 'Sorry, please try again later'
            form = VoucherForm()
    else:
        form = VoucherForm()
        
    alsolike = Product.objects.filter(price__gt=0, status__display_to_user=True, sites__id=settings.SITE_ID)[:8]
    
    c = RequestContext(request,common.commonDict({
        'form':form,
        'msg':msg,
        'alsolike':alsolike,
    },request))
    
    return HttpResponse(t.render(c))

def product(request, code, slug=None, type=None):
    referer = request.META.get('HTTP_REFERER', '')
    if 'product' not in referer and 'checkout' not in referer:
        request.session['referer'] = referer
    
    order = ''

    
    t = loader.get_template('product.html') if type == 'pop' else loader.get_template('productlanding.html')
    product = Product.objects.get(code=code)
    

    prev, next = helpers.findNeibougher(product)
    if 'catalogue' in request.session.get('referer', '') or 'activity' in request.session.get('referer', '') or 'designer' in request.session.get('referer', '') or 'sale' in request.session.get('referer', '') or 'just-in' in request.session.get('referer', ''):
        allproducts = request.session.get('latest_products','')
        if allproducts:
            allproducts = Product.objects.filter(id__in=allproducts)
            prev, next = helpers.findNeibougher(product, products=allproducts)

    
    if (not type and not slug) or (not type and slug != slugify(product.title)):
        return HttpResponseRedirect(product.get_absolute_url())
    
    referer = request.session.get('referer', '')
    p_check = ''
    rp = request.POST.copy()
    msg = ''
    if rp.get('addtobag',''):
        size = rp.get('size-select','')
        style = rp.get('style-select', '')
        quantity = rp.get('quantity-select',0)

        if not size or not int(quantity):

            msg = 'Please select your Size and Quantity'
        else:
            if size:
                size = Size.objects.get(code=size)
                p_check = product.productsizecolor_set.filter(size=size)
            if style:
                style = Style.objects.get(code=style)
                p_check = product.productsizecolor_set.filter(size=size, style=style)
    
            if p_check:
                order, sync = helpers.getCurrentOrder(request)
                if order:
                    request.session["order_id"] = order.id 
                coupon = request.session.get('coupon', '')
                
                try:
                    op = order.productorder_set.filter(product__pk=product.id)
                    if size:
                        op = op.filter(size=size)
                    if style:
                        op = op.filter(style=style)
                    productorder = op[0]
                    productorder.quantity += int(quantity)
                   
                    quan = ProductOrder.objects.get_total_quantity(order,product) + int(quantity)
                    
                    #this is the step to insert the correct price to a productorder
                    productorder.price = product.getTaxFreePrice(quan,isWholesale(request.user),coupon)[0]
                    
                    cp = Coupon.objects.filter(codes=coupon)
                    use_coupon = helpers.check_productcoupon(product,cp,isWholesale(request.user))
            
                    productorder.coupon = coupon if use_coupon else None
                    productorder.save()
                    
                except:
                    productorder = ProductOrder()
                    productorder.product = product
                    if size:
                        productorder.size = size
                    if style:
                        productorder.style = style
                    productorder.quantity = int(quantity)
                    
                    quan = ProductOrder.objects.get_total_quantity(order,product) + int(quantity)
                    productorder.price = product.getTaxFreePrice(quan,isWholesale(request.user),coupon)[0]
                    
                    cp = Coupon.objects.filter(codes=coupon)
                    use_coupon = helpers.check_productcoupon(product,cp,isWholesale(request.user))
            
                    productorder.coupon = coupon if use_coupon else None
                    
                    productorder.order = order
                    productorder.save()
                    
                msg = 'Your item has been added to your Shopping Bag!'
            else:
                msg = 'Sorry, we can not find the product you added.'
    helpers.sync_productorder(order) if order and sync else None
    
    can_addtocart = helpers.check_product_by_ip(request, product)
    default_review = False
    if rp.get('submit-review',''):
        rp['product'] = product.id
        form = ProductReviewForm(rp)
        default_review = True
        if form.is_valid():
            try:
                ip = request.META["HTTP_CF_CONNECTING_IP"] 
            except:
                ip = request.META["REMOTE_ADDR"]
    
            check_spammer = SpammerList.objects.filter(ip=ip)
            if not check_spammer:
                form.save()
                review_msg = 'Thank you for your comment. It will be displayed after approval.'
                form = ProductReviewForm()
    else:
        form = ProductReviewForm()
    
    c = RequestContext(request,common.commonDict({
        'product': product,
        'msg':msg,
        'alsolike':product.related_products.filter(price__gt=0, status__display_to_user=True),
        'referer':referer,
        'domain':settings.DOMAIN,
        'prev':prev,
        'next':next,
        
        'can_addtocart':can_addtocart,
        
        'form':form,
        'review_msg':review_msg,
        'default_review':default_review,
    }, request))

    
    return HttpResponse(t.render(c))

def collections(request, slug=None, datatype=None):
    
    if datatype == 'json':
        rp = request.POST
        slug = rp.get('code','')
        cc = rp.get('collection','')
        collection = Brand.objects.get(slug=slug)
        products = collection.product_set.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True,).distinct()
        thecollection = Collection.objects.get(slug=cc)
        t = loader.get_template('onelook.html')
        c = Context(common.commonDict({'collection':collection, 'products':products[:6], 'thecollection':thecollection},request ))
        html = t.render(c)
        return HttpResponse(simplejson.dumps({'html':html}), mimetype='application/javascript')
    
    t = loader.get_template('lookbook.html')
    if not slug:
        atc = Collection.objects.filter(is_active=True)
        thecollection = atc[0]
    else:    
        thecollection = Collection.objects.get(slug=slug)

    allc = thecollection.pages.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False)
    collection = allc[0]
        
    products = collection.product_set.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True,).distinct()
    c = RequestContext(request, common.commonDict({
        'thecollection':thecollection,                  
        'collection':collection,
        'products': products[:6],
        'current_meta':collection,
        'nav':'collection',
        
    }, request))    
    
    return HttpResponse(t.render(c))

def category(request, nav, code=None, slug=None):
    request.session["lastpage"] = request.get_full_path()
    now = datetime.datetime.now()
    t = loader.get_template('category.html')
    designer = ''
    category = ''
    products = ''
    leftnav = ''
    navdisplay = ''

    if nav == 'catalogue':
        navdisplay = 'Shop'
        landing = Categories.objects.filter(sites__id=settings.SITE_ID, is_landing=True)[0] if Categories.objects.filter(sites__id=settings.SITE_ID, is_landing=True) else ''
        leftnav = Categories.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False, parent__isnull=True).order_by('-priority')
        if not code:

            category = landing
            products = Product.objects.filter(price__gt=0, status__is_featured=True, sites__id=settings.SITE_ID).distinct()
        else:
            if code == 'all':
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()
            else:
                category = Categories.objects.get(slug=code)
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, category_now__id=category.id, status__display_to_user=True).distinct()
        
    elif nav == 'activity':
        navdisplay = 'Activity'
        landing = Activity.objects.filter(sites__id=settings.SITE_ID, is_landing=True)[0] if Activity.objects.filter(sites__id=settings.SITE_ID, is_landing=True) else ''
        leftnav = Activity.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False)
        if not code:

            category = landing
            products = Product.objects.filter(price__gt=0, status__is_featured=True, sites__id=settings.SITE_ID).distinct()
        else:
            if code == 'all':
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()
            else:
                category = Activity.objects.get(slug=code)
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, activity__id=category.id, status__display_to_user=True).distinct()
            
    elif nav == 'designer':
        navdisplay = 'Designers'
        landing = Brand.objects.filter(sites__id=settings.SITE_ID, is_landing=True)[0] if Brand.objects.filter(sites__id=settings.SITE_ID, is_landing=True) else ''
        leftnav = Brand.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False) 
        if not code:

            category = landing
            products = Product.objects.filter(price__gt=0, status__is_featured=True, sites__id=settings.SITE_ID).distinct()
        elif code and not slug:
            designer = Brand.objects.get(slug=code)
            products = Product.objects.filter(price__gt=0, brand__id=designer.id, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()
            leftnav = designer.getTopCategory()
            category = designer
        elif code and slug:
            designer = Brand.objects.get(slug=code)
            leftnav = designer.getTopCategory()
            if slug == 'all':
                products = Product.objects.filter(price__gt=0, brand__id=designer.id, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()
            else:
                category = Categories.objects.get(slug=slug)
                products = Product.objects.filter(price__gt=0, brand__id=designer.id, sites__id=settings.SITE_ID, category_now__id=category.id, status__display_to_user=True).distinct()
               
    elif nav == 'sale':
        leftnav = DiscountPrice.objects.getTopCategory()
        landing = False
        category = Categories.objects.filter(sites__id=settings.SITE_ID, is_landing=True)[0] if Categories.objects.filter(sites__id=settings.SITE_ID, is_landing=True) else ''
        products = DiscountPrice.objects.filter(start__lte=now, end__gt=now,coupon=None, product__status__display_to_user=True,price__gt=0).distinct('product')
        pids = [x.product.id for x in products]
        products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True, id__in=pids).distinct()
        if code:
            if code == 'all':
                products = DiscountPrice.objects.filter(start__lte=now, end__gt=now,coupon=None, product__status__display_to_user=True,price__gt=0).distinct('product').distinct()
                pids = [x.product.id for x in products]
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True, id__in=pids).distinct()
            else:
                category = Categories.objects.get(slug=code)
                products = DiscountPrice.objects.filter(start__lte=now, end__gt=now,coupon=None, product__category_now__id=category.id, product__status__display_to_user=True,price__gt=0).distinct('product').distinct()
                pids = [x.product.id for x in products]
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True, id__in=pids).distinct()
    elif nav == 'just-in':
        delta = datetime.timedelta(days=90)
        now = datetime.datetime.now()
        end_date = now-delta
        landing = False
        navdisplay = 'Just-In'
        leftnav = Categories.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False, parent__isnull=True).order_by('-priority')
        products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True, created__gte=end_date).distinct()
        if not products:
            products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()[:18]
            
            products = Product.objects.filter(id__in=[x.id for x in products]).distinct()
        allactivity, allbrand, allclothes = helpers.getAllRelated(products)
        leftnav = allclothes
        if code:
            if code == 'all':
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True, created__gte=end_date).distinct()
                if not products:
                    products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()[:18]
                    products = Product.objects.filter(id__in=[x.id for x in products]).distinct()
            else:
                category = Categories.objects.get(slug=code)
                products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, category_now__id=category.id, status__display_to_user=True,  created__gte=end_date).distinct()
                if not products:
                    products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, category_now__id=category.id, status__display_to_user=True).distinct()[:18]
                    products = Product.objects.filter(id__in=[x.id for x in products]).distinct()
    #request.session['latest_products'] = [x.id for x in products]
    allactivity, allbrand, allclothes = helpers.getAllRelated(products)
    
    rg = request.GET
    
    #sort
    sort = rg.get('sort','')
    products = helpers.sortProduct(products, sort)
    
    #filter
    filter_size = rg.get('size','')
    filter_color = rg.get('color','')
    filter_price = rg.get('price','')
    
    filter_clothes = rg.get('clothes','')
    filter_activity = rg.get('activity','')
    filter_designer = rg.get('designer','')
    
    products = helpers.filterProducts(products, filter_size, filter_color, filter_price, filter_clothes, filter_activity, filter_designer)
    request.session['latest_products'] = [x.id for x in products]
    #pagination
    offset = rg.get('page',1)
    showtype = rg.get('limit','')
    numberofshow = helpers.getPerPage(showtype)
    pg = int(offset)
    p = Paginator(products, numberofshow)
    page = p.page(pg)

    designers_nav = Brand.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False).order_by('name')
        
    c = RequestContext(request,common.commonDict({
        'landing':landing,                                         
        'category': category,
        'categories':leftnav,
        'products': products[:18],
        'current_meta':category,
        'nav':nav,
        'leftnav':leftnav,
        'designer':designer,
        'navdisplay':navdisplay,
        'code':code,
        'slug':slug,
        'page':p,
        'pagenumber':pg,
        'currentpage':page,
        
        'allsizes': SizeGroup.objects.all(),
        'allstyles': StyleGroup.objects.all(),
        'allprices': sorted(settings.PRICE_FILTER_DICT.items(), key=lambda x:int(x[0])),
        'allactivity':allactivity,
        'allbrand':allbrand,
        'allclothes':allclothes,
        
        'designers_index_nav':designers_nav,
        
        'filter_size':filter_size,
        'filter_color':filter_color,
        'filter_price':filter_price,
        'filter_clothes': filter_clothes,
        'filter_activity':filter_activity,
        'filter_designer':filter_designer,
        'filter_sort':sort,
        'filter_page':offset,
        'filter_limit':showtype,
        }, request))
    return HttpResponse(t.render(c))
def featuredxml(request):
    t = loader.get_template('featured.xml')
    # Lets select products based on the type of customer we're working with
    c = RequestContext(request,common.commonDict({"openpath": ["home"],}, request))
    return HttpResponse(t.render(c), mimetype="application/xml")

def cartsummary(request):
    if request.session.get("order_id", None):
        order = Order.objects.get(pk=request.session.get("order_id", 0))
        return HttpResponse(simplejson.dumps({"items": order.getTotalItems(), "price": common.formatCurrency(float(order.getTotalTaxFreePrice()))}),mimetype='application/javascript')
    else:
        return HttpResponse(simplejson.dumps({"items": "0", "price": "0.00"}),mimetype='application/javascript')


def shoppingbag(request):
    html = ''
    try:
        currency = request.session.get('currency', 'AUD')
        
        ratio_error = False
        ratio,currency = common.getCurrencyRatio(currency)
        
        label = '$'
        if currency == 'GBP':
            label = u'\xa3'
        elif currency == 'EUR':
            label = u'\u20ac'

    except:
        ratio = 1
        currency = 'AUD'
        label = '$'
    try:
        order = Order.objects.get(pk=request.session.get("order_id", 0))
        
    
        po = order.productorder_set.all()
        vo = order.voucherorder_set.all()
        if po or vo:
            for i,x in enumerate(po):
                html += '''<div class="%s">
                        <div class="left"><img src="%s"></div>
                        <div class="middle">
                            <div class="brand-drop">%s</div>
                            <div class="desc-drop">%s</div>
                            <div class="price-drop">Qty: %s   </div><span class="drop-size">Size:  %s</span>
                        </div>
                        <div class="right">%s %s%s</div>
                    </div>'''%('drop-prod-holder drop-no-border' if not vo and po.count()-1 ==i else 'drop-prod-holder', '/shop/i/42/65/'+str(x.product.getFeaturedImage()) if x.product.getFeaturedImage() else '', x.product.getBrand().name, x.product.title, x.quantity, x.size,currency,label,formatCurrency(float(x.getTotalPrice())*float(ratio)) )
           
                

                    
            for i,x in enumerate(vo):
                html += '''<div class="%s">
                        <div class="left"><img src="%s"></div>
                        <div class="middle">
                            <div class="brand-drop">%s</div>
                            <div class="desc-drop">%s</div>
                            <div class="price-drop">Qty: %s   </div>
                        </div>
                        <div class="right">AUD $%s</div>
                    </div>'''%('drop-prod-holder drop-no-border' if vo.count()-1 ==i else 'drop-prod-holder', '/shop/i/42/65/'+str(x.voucher.getFeaturedImage()) if x.voucher.getFeaturedImage() else '', 'Gift Voucher', 'Worth AUD $'+x.getUnitPrice(), x.quantity, x.getUnitPrice() )
           
                               
                
            html +=  '''<div class="drop-total-holder">
                    
                    <a href='/shop/cart.html'><div class="drop-check" ><img src='/media/assets/images/drop-checkout-btn.jpg'></div></a>
                    
                    <div class="drop-sub-total">Subtotal<span>AUD $%s</span>''' %(order.getTotalTaxFreePrice())   
                    
            if currency != 'AUD':
                html += '''<br>       <span style='float:right'>%s %s%s</span>'''%(currency, label, formatCurrency(float(order.getTotalTaxFreePrice())*float(ratio)))
            html +=  '''</div></div>''' 
                                 
        else:
            html += '''<div class="drop-total-holder">
                        <div class="drop-sub-total">You have 0 items in your Shopping Bag</div></div>
                             '''                
    except:
        html += '''<div class="drop-total-holder">
                    <div class="drop-sub-total">You have 0 items in your Shopping Bag</div></div>
                         '''
            
    return HttpResponse(simplejson.dumps({'html':html}),mimetype='application/javascript')
#-----------------------shopping gateway-----------------------------------

#add to cart
def addtocart(request):
    rp = request.GET
    product = Product.objects.get(pk=rp["id"])
    try:
        order = Order.objects.get(pk=request.session.get("order_id", 0), status=OrderStatus.objects.get(status=settings.TXT_SHOP_ORDER_STATUS_IN_PROGRESS))
    except:
        order = Order()
        order.status = OrderStatus.objects.get(status=settings.TXT_SHOP_ORDER_STATUS_IN_PROGRESS)
        order.site = Site.objects.get(id=settings.SITE_ID)
        order.save()
        
    if (request.user and request.user.is_active and not order.user) or (request.user and request.user.is_active and order.user and order.user != request.user):
        order.user = request.user
        order.save()
        
    request.session["order_id"] = order.id
    coupon = request.session.get('coupon', '')
    
    style = rp.get("style", "")
    if style:
        style = Style.objects.get(code=style)
    size = rp.get("size", "")
    if size:
        size = Size.objects.get(code=size)
        
    try:
        op = order.productorder_set.filter(product__pk=product.id)
        if style:
            op = op.filter(style__code=style.code)
        if size:
            op = op.filter(size__code=size.code)
            
        productorder = op[0]
        productorder.quantity += int(rp.get("quantity", 0))
       
        quan = ProductOrder.objects.get_total_quantity(order,product) + int(rp.get("quantity", 0))
        
        #this is the step to insert the correct price to a productorder
        productorder.price = product.getTaxFreePrice(quan,request.user.is_active,coupon)
        
        cp = Coupon.objects.filter(codes=coupon)
        use_coupon = helpers.check_productcoupon(product,cp,request.user.is_active)

        productorder.coupon = coupon if use_coupon else None
        productorder.save()
        helpers.sync_productorder(order,product)
    except Exception, e:
        productorder = ProductOrder()
        if style:
            productorder.style = style
        if size:
            productorder.size = size
        productorder.product = product
        productorder.quantity = int(rp.get("quantity", 0))
        
        quan = ProductOrder.objects.get_total_quantity(order,product) + int(rp.get("quantity", 0))
        productorder.price = product.getTaxFreePrice(quan,request.user.is_active,coupon)
        
        cp = Coupon.objects.filter(codes=coupon)
        use_coupon = helpers.check_productcoupon(product,cp,request.user.is_active)

        productorder.coupon = coupon if use_coupon else None
        
        productorder.order = order
        productorder.save()
        helpers.sync_productorder(order,product)
    return HttpResponse(simplejson.dumps({"items": order.getTotalItems(), "price": common.formatCurrency(float(order.getTotalTaxFreePrice()) )}), mimetype='application/javascript')


#show cart
"""
this is the controller to show the content of  the shopping cart.
if order exists:
    it will check the order items and return a list of all the related product ranges as a list.
    it will also save the country and postcode user entered in session to calculate and keep track of the shipping fee
    it will update the order if user updated their cart. it updates the order from the form user posted
    it will redirect to the last category page user at if user want to continue shopping. last page url will be get from session.
    if the user have entered billing and shipping details and then come back to this page, if they changed ship country and postcode here, it will automatically update the user's shipping country and postcode.
    if it is the user's first time want to checkout, it will lead the user to billing information page. however, if the user is wholesale, it will redirect to delivery page because we already know wholesale customers billing and shipping info.
    it will also check coupon when the coupon code is entered. if the coupon is valid, it will save the coupon in session so the coupon can be applied in later shopping before checkout. if user want to remove coupon, the coupon will be removed from session
    shipping price will be calculated if user already set country and postcode. 
    tax will also be calculcated if user already country and postcode.
    total will also be calculcated if user already country and postcode.
    it will also get remove order item from post request, and it will remove the product order when the productorder remove request is in post request.
else:
    it will just showing a page without all the submit buttons so user can only see the nothing in order message
"""
def cart(request):
    t = loader.get_template('cart.html')
    msg = ''
    fail_items = []
    if request.session.get("order_id", None):
        order = Order.objects.get(pk=request.session.get("order_id", 0))
    else:
        order = None
    if order:
        helpers.sync_productorder(order)
        alsolike = helpers.getOrderRelated(order,isWholesale(request.user))   
        
        country = request.session.get("shippingcountry", None)
        postcode = request.session.get("shippingpostcode", '') 
        suburb = request.session.get("shippingsuburb", '') 
        if request.POST:
            if request.POST.get("changequantity", None):
                helpers.update_cart(request,order)
                return HttpResponseRedirect("/shop/cart.html")
            elif request.POST.get("continueshopping", None):
                return HttpResponseRedirect(request.session.get("lastpage", "/"))
            elif request.POST.get("completemyorder", None):
                
                if not request.user.is_active and order.getProfileShipping():
                    pro = order.getProfileShipping()
                    pro.postcode = postcode
                    pro.suburb = suburb
                    pro.country = Country.objects.get(country__iexact=country) 
                    pro.save()
                
                inventorycheck = order.checkProductOrder()
                if not inventorycheck:
                    return HttpResponseRedirect('/shop/cart.html')
                if request.user and request.user.is_active:
                    return HttpResponseRedirect("checkout-delivery.html")
                else:
                    return HttpResponseRedirect("/members/")
                return HttpResponseRedirect("checkout-billing.html")
            elif request.POST.get("coupon", None):
                validate = False
                coupon = request.POST.get("coupon", None)
                coupons = Coupon.objects.get_coupon(coupon)
                validate = True if coupons else False
                if validate:
                    if order:
                        po = order.productorder_set.all()
                        cp = Coupon.objects.filter(codes=coupon)
                        for x in po:
                            use_coupon = helpers.check_productcoupon(x.product,cp,isWholesale(request.user))
                            x.coupon = coupon if use_coupon else None
                            x.save()
                    helpers.sync_productorder(order)
                    request.session['coupon'] = coupon
                else:
                    try:
                        voucher = Voucher.objects.get(code=coupon)
                        if voucher.is_valid():
                            if order:
                                order.voucher = voucher
                                order.save()
                            #request.session['coupon'] = coupon
                        else:
                            msg = 'The coupon you entered is not valid or already expired. Please check.'
                    except:
                        msg = 'The coupon you entered is not valid or already expired. Please check.'
                    
            elif request.POST.get('removecoupon',''):
                request.session['coupon'] = ''
                if order:
                    for x in order.productorder_set.all():
                        x.coupon = None
                        x.save()
                    order.voucher = None
                    order.save()
                helpers.sync_productorder(order) 
            else:
                for x in request.POST.keys():
                    ids = x.split('removepo')
                    try:
                   
                        id = ids[1]
                        po = ProductOrder.objects.get(id=id)
                        helpers.remove_po(order,po)
                        
                    except:
                        pass
                    
                for x in request.POST.keys():
                    ids = x.split('removevo')
                    try:
                        id = ids[1]
                        vo = VoucherOrder.objects.get(id=id)
                        vo.voucher.delete()
                        order.save()
                    except:
                        pass

        try:
            if order.user and order.user.get_profile():
                profile = order.user.get_profile()
                shipping_price = postInternational(order, getBoxes(order),getBoxWeight(order),postcode,country,suburb,order.getTotalTaxFreePrice(),isWholesale(request.user),type='term', term=profile.payment_term, service=order.getShippingWay())
            else:
                shipping_price = postInternational(order, getBoxes(order),getBoxWeight(order),postcode,country,suburb,order.getTotalTaxFreePrice(),isWholesale(request.user), service=order.getShippingWay())
            shipping_price = 0.00 if shipping_price == 'free' else shipping_price   
        except:
            shipping_price = '?'
        
        fail_items = order.get_unavailable_shipping_items(country)
        if fail_items:
            shipping_price = '?' 
            if not order.user or order.user and not order.user.is_active:
                request.session['shippingpostcode'] = ''
                request.session["shippingsuburb"] = ''
        
        tax,retailtax = helpers.tax_display(order,country)
        if float(retailtax) and shipping_price and shipping_price != '?' and not order.special_instruction: 
            retailtax = float(retailtax) + shipping_price/11.0
        
        total = float(order.getTotalTaxFreePrice()) + tax + shipping_price if shipping_price != '?' and not order.is_wholesale or shipping_price != '?' and order.is_wholesale and settings.WHOLESALE_SHIPPING != 'manual' else float(order.getTotalTaxFreePrice()) + tax        
        if order and order.voucher and order.voucher.is_valid():
            total = total - order.voucher.current_value()
            total = 0.00 if total < 0 else total
            
        #exclusive = order.get_shipping_only_countries()
        #if exclusive:
        #    countries = Country.objects.filter(shipto=True, country__in=exclusive)
        #else:
        countries = Country.objects.filter(shipto=True)

        d = {'order':order,
             'alsolike':alsolike,
             'tax':common.formatCurrency(tax),
             'retailtax':common.formatCurrency(retailtax),
             'shipping_price':common.formatCurrency(shipping_price),
             'total':common.formatCurrency(total),
             'countries':countries,
             'shippingcountry':country,
             'shippingpostcode':postcode,
             'shippingsuburb':suburb,
             'msg':msg,
             'fail_items':fail_items,
             }
    else:
        d = {}
    
    c = RequestContext(request,common.commonDict(d,request))
    return HttpResponse(t.render(c))


#step 1
"""this is the first checkout step
    it will redirect to members' billing account management page if user is a member.
    it will redirect to the cart page if ship country or ship postcode not set in there.
    it will save the order user's billing info and assign the order to this user.
"""
def checkoutbilling(request):
    
    if request.user.is_active:
        return HttpResponseRedirect('/members/profile.html')
    
    if not request.session.get("shippingcountry", None) or not request.session.get("shippingpostcode", '')  or not request.session.get("shippingsuburb", '') :
        return HttpResponseRedirect('/shop/cart.html')
    
    t = loader.get_template('checkout.html')
    order = Order.objects.get(pk=request.session.get("order_id", 0))    
    rp = request.POST.copy()
    try:
        order.save()
    except:
        pass
    if rp:
        if helpers.checkout_switch(request,rp):
            return HttpResponseRedirect(helpers.checkout_switch(request,rp))
        form = BillingDetailForm(rp)
        
        if form.is_valid():
            
            email = rp.get("email", "").strip().lower()
            username = helpers.create_username(email,type='retail')
            u, created = User.objects.get_or_create(username=username)
            u.is_active = False
            if created:
                u.set_unusable_password()
            u.email = email
            u.first_name = rp.get("first_name", "?")
            u.last_name = rp.get("last_name", "?")
            u.save()
            if u:
                order.user = u
                order.save()
            try:
                profile = u.get_profile()
            except:
                profile = Profile()
                u.profile_set.add(profile)
                Log(u, "Creating New Profile")
            profile.phone = rp.get("phone", "")
            profile.company = rp.get("company", "")
            profile.subscribe = bool(int(rp.get("subscribe", "")))
            try:
                ip = request.META["HTTP_CF_CONNECTING_IP"] 
            except:
                ip = request.META["REMOTE_ADDR"]
            profile.save(ip=ip)
            try:
                billing = profile.billing_set.all()[0]
                
            except:
                billing = Billing()
                billing.profile = profile
                billing.save()
           
            rp["profile"] = profile.id
            
            form = BillingDetailForm(rp,instance=billing)
            form.save()
            Log(u, "Saved billing Information", billing)
            request.session["billing_data"] = rp
            if form.cleaned_data['copydata'] == True:
                request.session['shipping_data'] = rp
            return HttpResponseRedirect('/shop/checkout-shipping.html')
    else:
        if request.session.has_key("billing_data"): 
            
            form = BillingDetailForm(request.session["billing_data"])
        else:
            form = BillingDetailForm()
        
    c = RequestContext(request,common.commonDict({'form':form, 'step':'billing','order':order},request))
    return HttpResponse(t.render(c))
    
#step 2
"""this is the second checkout step
    it will redirect to members' shipping account management page if user is a member.
    it will redirect to the cart page if ship country or ship postcode not set in there.
    it will redirect to the billing page if the order user has no billing info.
    it will save the order user's shipping info.
"""
def checkoutshipping(request):
    if request.user.is_active:
        return HttpResponseRedirect('/members/profile.html')
    
    
    if not request.session.get("shippingcountry", None) or not request.session.get("shippingpostcode", '') or not request.session.get("shippingsuburb", '') :
        return HttpResponseRedirect('/shop/cart.html')
    
    t = loader.get_template('checkout.html')
    order = Order.objects.get(pk=request.session.get("order_id", 0))
    
    if not order.getProfileBilling():
        return HttpResponseRedirect('/shop/checkout-billing.html')
    
    rp = request.POST.copy()
    if rp:
        if helpers.checkout_switch(request,rp):
            return HttpResponseRedirect(helpers.checkout_switch(request,rp))        
        
        rp["postcode"] = request.session["shippingpostcode"]
        rp["suburb"] = request.session['shippingsuburb']
        rp["country"] = Country.objects.get(country__iexact=request.session["shippingcountry"]).id 
        form = ShippingDetailForm(rp)
        if form.is_valid():
            u = order.user
            profile = u.get_profile()
            try:
                shipping = profile.shipping_set.all()[0]
            except:
                shipping = Shipping()
                shipping.profile = profile
                shipping.save()
            
            rp['profile'] = profile.id    
                
            form = ShippingDetailForm(rp,instance=shipping)
            form.save()
            Log(u, "Saved Shipping Information", shipping)
            request.session["shipping_data"] = rp
            return HttpResponseRedirect('/shop/checkout-delivery.html')
    else:
        if request.session.has_key("shipping_data"):
            request.session["shipping_data"]["postcode"] = request.session["shippingpostcode"]
            request.session["shipping_data"]["suburb"] = request.session["shippingsuburb"]
            request.session["shipping_data"]["country"] = Country.objects.get(country__iexact=request.session["shippingcountry"]).id 
            form = ShippingDetailForm(request.session["shipping_data"])
        else:
            rp = {}
            if request.session.get("shippingcountry"):
                sc = Country.objects.filter(country=request.session.get("shippingcountry"))
                rp['country'] = sc[0].id if sc else None
                rp['postcode'] = request.session["shippingpostcode"]
                rp['suburb'] = request.session['shippingsuburb']
            form = ShippingDetailForm(initial=rp)
            
    c = RequestContext(request,common.commonDict({'form':form, 'step':'shipping','order':order},request))
    return HttpResponse(t.render(c))
            
#step 3 
#TODO methods in order used in this section should be implemented
"""this is the third checkout step
    it will redirect to the cart page if ship country or ship postcode not set in there.
    it will redirect to the billing page if the order user has no billing info.
    it will redirect to the shipping page if the order user has no shipping info.
    it will save the order user's delivery info.
"""
def checkoutdelivery(request):
    t = loader.get_template('checkout.html')
    order = Order.objects.get(pk=request.session.get("order_id", 0))
    
    if not request.session.get("shippingcountry", None) or not request.session.get("shippingpostcode", '')  or not request.session.get("shippingsuburb", '') : 
        return HttpResponseRedirect('/shop/cart.html')
    
    if not order.getProfileBilling():
        return HttpResponseRedirect('/shop/checkout-billing.html')
    
    if not order.user.is_active and not request.session.get("shipping_data",''):
        return HttpResponseRedirect('/shop/checkout-shipping.html')
    
    scountry = request.session.get("shippingcountry", None)
    fail_items = order.get_unavailable_shipping_items(scountry)
    if fail_items:
        return HttpResponseRedirect('/shop/cart.html')
    
    try:    
        normalprice = postInternational(order, getBoxes(order),getBoxWeight(order),order.getProfileShipping().postcode,order.getProfileShipping().country.country,order.getProfileShipping().suburb,order.getTotalTaxFreePrice(),isWholesale(request.user), service='STANDARD')
        #expressprice = postInternational(getBoxes(order),getBoxWeight(order),order.getProfileShipping().postcode,order.getProfileShipping().country.country,order.getProfileShipping().suburb,order.getTotalTaxFreePrice(),isWholesale(request.user), service='EXPRESS')
        normalprice = 0.00 if normalprice == 'free' else normalprice
    except:
        return HttpResponseRedirect('/shop/cart.html?error=shippingdetails')

    rp = request.POST
    #may need to re-implement this method
    method = order.getShippingMethod()
    
    #update order
    order.save()
    if request.POST:
        if helpers.checkout_switch(request,rp):
            return HttpResponseRedirect(helpers.checkout_switch(request,rp))        

        order.special_instruction = request.POST['instructions'] if request.POST['instructions'] else 'None'
        order.shipping = request.POST.get('shipping_method', None)
        order.save()
        return HttpResponseRedirect('/shop/checkout-payment.html')
    
    if order.getProfileShipping().country.country != 'AUSTRALIA' or order.is_wholesale:
        order.shipping = None
        order.save()
    
    c = RequestContext(request,common.commonDict({'order':order,'method':method,'step':'delivery', 'normalprice': helpers.formatCurrency(normalprice), 'expressprice': ''},request))
    return HttpResponse(t.render(c))

#step 4 -- this step have payment and order review
"""this is the forth checkout step
    it will redirect to the cart page if ship country or ship postcode not set in there.
    it will redirect to the billing page if the order user has no billing info.
    it will redirect to the shipping page if the order user has no shipping info.
    it will redirect to the delivery page if use been there before.
    it will save the order user's payment method and info.then showing an order review page.
    it will talk to eway or paypal to process the payment, and change the order status to complete type and send confirmation email to both user and admin.
"""
def checkoutpayment(request):
    t = loader.get_template('checkout.html')
    rp = request.POST.copy()
    
    step = 'payment'
    msg = ''
    form = CreditCardForm()
   
    order = Order.objects.get(pk=request.session.get("order_id", 0))
    
    helpers.sync_productorder(order)
    

            
    
    if not request.session.get("shippingcountry", None) or not request.session.get("shippingpostcode", '')  or not request.session.get("shippingsuburb", '') :
        return HttpResponseRedirect('/shop/cart.html')
    
    if not order.getProfileBilling():
        return HttpResponseRedirect('/shop/checkout-billing.html')

    
    if not order.user.is_active and not request.session.get("shipping_data",''):
        return HttpResponseRedirect('/shop/checkout-shipping.html')
    
    if not order.special_instruction:
        return HttpResponseRedirect('/shop/checkout-delivery.html')
    
    scountry = request.session.get("shippingcountry", None)
    fail_items = order.get_unavailable_shipping_items(scountry)
    if fail_items:
        return HttpResponseRedirect('/shop/cart.html')
    
    try:    
        normalprice = postInternational(order, getBoxes(order),getBoxWeight(order),order.getProfileShipping().postcode,order.getProfileShipping().country.country,order.getProfileShipping().suburb,order.getTotalTaxFreePrice(),isWholesale(request.user), service='STANDARD')
        #expressprice = postInternational(getBoxes(order),getBoxWeight(order),order.getProfileShipping().postcode,order.getProfileShipping().country.country,order.getProfileShipping().suburb,order.getTotalTaxFreePrice(),isWholesale(request.user), service='EXPRESS')
    except:
        return HttpResponseRedirect('/shop/cart.html?error=shippingdetails')
    
    if rp and helpers.checkout_switch(request,rp):
        return HttpResponseRedirect(helpers.checkout_switch(request,rp))
    if rp.get('orderreview'):
        if rp.get('paymethod',''):
            order.method = rp.get('paymethod','')        
            order.save()
            if order.method == 'creditcard':
                form = CreditCardForm(rp)
               
                if form.is_valid():
                    request.session['payment_form'] = form
                    step = 'review'


            else:
               step = 'review'
               
            inventorycheck = order.checkProductOrder()
            
            if not inventorycheck:
                return HttpResponseRedirect('/shop/cart.html')
        else:
            msg = 'Please choose one payment method'
    elif rp.get('submitorder',''):
        
        if order.method == 'creditcard':
            form = request.session['payment_form']

            customer, credit_card = helpers.create_creditcard_info(request,order,form)
            
            msg = helpers.payment_creditcard(request,order,customer,credit_card)
            request.session['payment_form'] = ''
            if msg == 'success':
                helpers.finalize_order(order)
                helpers.send_confirm_email(order)
                helpers.checkInventory(order)
                request.session["order_id"] = None
                request.session['coupon'] = ''               
                return HttpResponseRedirect('/shop/checkout-final%s.html' %order.id)

                
        elif order.method == 'paypal':
            try:
                msgg = helpers.getResponse(order)
            except:
                msgg ={'ACK':'Error'}
            if msgg['ACK'] == 'Success':
                        
                return HttpResponseRedirect("https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=%s&useraction=commit" % msgg['TOKEN'])
            else:
                msg = 'Your PayPal Account may have a problem. Please choose another Payment Method'
        
        elif order.method == 'voucher':
            if order.voucher and order.voucher.is_valid() and order.total_charged == 0:
                helpers.finalize_order(order)
                helpers.send_confirm_email(order)
                helpers.checkInventory(order)  
                request.session["order_id"] = None
                request.session['coupon'] = ''            
                return HttpResponseRedirect('/shop/checkout-final%s.html' %order.id)
            else:
                order.voucher = None
                order.method = ''
                order.save()
                return HttpResponseRedirect('/shop/cart.html')    
        
        else:
            raise Http404

    else:
        form = CreditCardForm()
    
    c = RequestContext(request,common.commonDict({'form':form,'msg':msg,'order':order,'step':step},request))
    return HttpResponse(t.render(c))

#step 5
"""this is the thank you for order page
    paypal will checkout in previous step and return status here. if successful, it will show the normal thank you page. if problems, it will show the paypal error.
"""
def checkoutsuccess(request,orderid):
    t = loader.get_template('success.html')
    msg = ''
    
    referer = request.META.get('HTTP_REFERER', '')
    push_analytic = True if '/shop/checkout-payment.html' in referer else False
    if request.GET:
        try:
            order = Order.objects.get(id = orderid)
            msg = helpers.payment_paypal_end(request,order)
            if msg == 'success':
                helpers.finalize_order(order)
                helpers.send_confirm_email(order)
                helpers.checkInventory(order)
                request.session["order_id"] = None
                request.session['coupon'] = ''     
                push_analytic = True
        except:
            msg = 'Error'


    
    try:
        order = Order.objects.get(id=orderid)
    except:
        order = ''
        
    if not(order.ordered and push_analytic):
        msg = 'Error'
        

    c = RequestContext(request,common.commonDict({'msg':msg,'orderid':orderid,'step':'final','push_analytic':push_analytic, 'order':order},request))
    
    return HttpResponse(t.render(c))

"""
this is to handle the iframe popup page when an product is unavailable and the back order button clicked.
"""
def backorder(request,code):
    product = Product.objects.get(code=code)
    rp = request.POST
    msg = ''
    if rp:
        form = BackOrderForm(rp)
        if form.is_valid():
            name = form.cleaned_data['firstname']
            email = form.cleaned_data['email']
            product.add_to_enquiry(name,email)
            msg = 'Thank you, we will let you know when this product is in stock.'
            form = BackOrderForm()
    else:
        form = BackOrderForm()
    
    t = loader.get_template('backorder.html')
    c = RequestContext(request,{'product':product, 'form':form, 'msg':msg})
    
    return HttpResponse(t.render(c))


"""
this is the ajax return for calculate shipping price in cart page.
when shipping country and postcode entered, here will calculate the shipping price based on the shippingmanagement method and return the shipping, tax and order total price in json

"""
def calculateshipping(request):
    rp = request.POST
    if rp.get("postcode") and rp.get('suburb'):
        request.session["shippingcountry"] = rp.get("country")
        request.session["shippingpostcode"] = rp.get("postcode")
        request.session["shippingsuburb"] = rp.get("suburb")
    else:
        return HttpResponse(simplejson.dumps({"error": "Postcode and suburb are required"}), mimetype='application/javascript')
    country = request.session.get("shippingcountry", None)
    postcode = request.session.get("shippingpostcode", None)
    suburb = request.session.get("shippingsuburb", None)
    weight = int(rp.get("weight", 0))
    price = 0
    order = Order.objects.get(pk=request.session.get("order_id", 0), status=OrderStatus.objects.get(status=settings.TXT_SHOP_ORDER_STATUS_IN_PROGRESS))

    fail_items = order.get_unavailable_shipping_items(country)
    if fail_items:
        request.session['shippingpostcode'] = ''
        request.session["shippingsuburb"] = ''
        return HttpResponse(simplejson.dumps({"error": 'Sorry, %s in your cart can not be shipped to %s, please remove them and continue.' %(', '.join([x.title for x in fail_items]),country)}), mimetype='application/javascript')
    
    service = rp.get('service', '') 
    if not service:
        service = order.getShippingWay()
    try:

        price = postInternational(order, getBoxes(order),getBoxWeight(order),postcode,country, suburb,order.getTotalTaxFreePrice(),isWholesale(request.user), service=service)
        if not price:
            return HttpResponse(simplejson.dumps({"error": settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE}), mimetype='application/javascript')
        price = 0.00 if price == 'free' else price
    except Exception, e:
        request.session['shippingpostcode'] = ''
        request.session["shippingsuburb"] = ''
        return HttpResponse(simplejson.dumps({"error": str(e)}), mimetype='application/javascript')
    
    
    tax,retailtax = helpers.tax_display(order,country)
    if float(retailtax) and price and not order.special_instruction:
        retailtax = float(retailtax) + price/11.0
    
    totalprice = float(order.getTotalTaxFreePrice())+tax+price if price else float(order.getTotalTaxFreePrice())+tax
    if order.voucher and order.voucher.is_valid():
        totalprice = totalprice - order.voucher.current_value()
        totalprice = 0.00 if totalprice < 0 else totalprice
    
    try:
        currency = request.session.get('currency', 'AUD')
        
        ratio_error = False
        ratio,currency = common.getCurrencyRatio(currency)
        totalcurrency = totalprice * float(ratio)
    except:
        totalcurrency = totalprice

    return HttpResponse(simplejson.dumps({"shippingprice": common.formatCurrency(price), "tax": common.formatCurrency(tax), "retailtax":common.formatCurrency(retailtax), "totalprice": common.formatCurrency(totalprice), 'totalcurrency':common.formatCurrency(totalcurrency)}), mimetype='application/javascript')

def quantitysummury(request):
    rp = request.GET
    size = Size.objects.get(code=rp.get('size',''))
    color = Style.objects.get(code=rp.get('color',''))
    product = Product.objects.get(code=rp.get('product',''))
    range = product.getRange(size=size, color=color)
    html = '''<option value='0'>Please select your quantity</option>''' if range else '''<option value='0'>Out of Stock</option>'''
    for x in range:
        html += '''<option value=%s>%s</option> ''' %(x,x)
        
    return HttpResponse(simplejson.dumps({'html':html}), mimetype='application/javascript')
    
        