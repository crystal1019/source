'''
Created on Sep 7, 2014

@author: apptworks
'''

import json
import random
import string
import sys

from tyne.connectors.booked import BookedConnector


class OrgCommon():
	def __init__(self, url, orgName, user, pwd):
		self.url = url
		self.orgName = orgName
		self.user = user
		self.bookedConn = BookedConnector.BookedConnector(self.url, self.orgName, self.user, pwd)
		self.bookedConn.setSessionAuthHeaders()

	
	def getGroups(self, **kwargs):
		users =	self.bookedConn.getGroups(**kwargs)
		return users
	

	def getUsers(self, **kwargs):
		users =	self.bookedConn.getUsers(**kwargs)
		return users
	
	
	def createUser(self, args, data):
		#make sure there is data
		if not len(data):
			err = json.loads('{"error":"no data; did you set content-type?"}')
			return err

		try:
			userInfo = json.loads(data)
		except ValueError:
			err = json.loads('{"error":"unable to read json -- %s"}' % (sys.exc_info()[1] ))
			return err

		if not 'userName' in userInfo:
			err = json.loads('{"error":"no username set"}')
			return err

		userName = userInfo['userName']
		user = self.getUsers(username=userName)
		if ('users' in user) and (len(user['users'])):
			return user

		#username = ''.join(random.choice(string.ascii_uppercase) for i in range(8))
		
		defaultValues = {"password":userName + '_',
										"language":"en_us",
										"firstName":"New",
										"lastName": "User",
										"emailAddress": userName + "@example.com",
										"userName": userName,
										"timezone":"America\/Chicago"
}

		for dvKey in defaultValues:
			if dvKey not in userInfo:
				userInfo[dvKey] = defaultValues[dvKey]

		#TODO: fix this; in current spot emailAddr is always set
		#set emailAddress to username since both should be unique
		#if "emailAddress" not in userInfo:
		#	userInfo["emailAddress"] = userInfo["userName"] + "@example.com"


		#newUser = '{"userName":"%s","password":"%s","emailAddress":"%s","firstName":"%s","lastName":"%s", "phone":"%s", "timezone":"America/Chicago", "language":"en_us"}' % (username, password, email, firstName, lastName, phoneNum)
		bookedUser = self.bookedConn.createUser(str(userInfo).replace("'", '"'))
		
		return bookedUser
		

	def getSchedules(self, **kwargs):
		schedules = self.bookedConn.getSchedules(**kwargs)
		return schedules


	def getAvailableTimes(self, **kwargs):
		schedules = self.bookedConn.getAvailableTimes(**kwargs)
		return schedules


	def getResources(self, **kwargs):
		resources = self.bookedConn.getResources(**kwargs)
		return resources
	
	
	def getReservations(self, **kwargs):
		reservations = self.bookedConn.getReservations(**kwargs)
		
		return reservations


	
	def createReservation(self, args, data):
		"""
		Creates a reservation.  
		@param args: arguments from url.  Possibilities:
			nextOnly: find the next available, based on fitlers in data
		   Otherwise it uses all of the specified params for date/time
		  useExisting: one reservation per user.  Returns previous reservation if it existed
		"""

		useExisting = args.get('useExisting')
		nextOnly = args.get('nextOnly')
		reservationInfo = json.loads(data)


		filters = None
		
		resData =None
		if 'data' in reservationInfo:
			resData = reservationInfo['data']
		if 'filters' in reservationInfo:
			filters = reservationInfo['filters']
			
		reservation = None

		# if useExisting is set and userAlready has reservation, return
		if useExisting and (useExisting.lower() in ['true', '1', 't', 'y', 'yes', 'yeah', 'yup', 'certainly', 'uh-huh']):
			bookedId = reservationInfo['bookedId']
			reservation = self.bookedConn.getReservations(userId=bookedId, nextOnly=True)
			
		if reservation and ('reservations' in reservation):
			if reservation['reservations']:
				reservation['existing'] = True
		else:
			if nextOnly and (nextOnly.lower() == 'true'):
				bookedId = reservationInfo['bookedId']
				resourceIds = reservationInfo['resourceIds'].split(',')
				
				reservation = self.bookedConn.createReservationNextAvailable(bookedId, resourceIds, resData, filters)
			else:
				reservation = self.bookedConn.createReservation(resData)
				
		return reservation
	
	
	def deleteReservation(self, refNumber):
		result = self.bookedConn.deleteReservation(refNumber)
		
		return result
