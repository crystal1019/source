from django.conf import settings
from django.contrib.redirects.models import Redirect
from django.contrib.sites.models import Site
from django.test import TestCase
from offers.core.models import Offer, PerSiteOfferOption


class RedirectTests(TestCase):
    def test_all_redirects(self):
        counter = 1
        redirects = Redirect.objects.filter(site__id=settings.SITE_ID).order_by('old_path')[counter-1:]
        for redirect in redirects:
            counter += 1
            response = self.client.get(redirect.old_path)
            self.assertRedirects(response, redirect.new_path, status_code=301)
            

class OutboundURLTests(TestCase):
    fixtures = ('core/sites.json',)
    
    def setUp(self):
        self.offer = Offer.objects.create()
        site = Site.objects.get(id=settings.SITE_ID)
        self.option = PerSiteOfferOption.objects.create(site=site, offer=self.offer)
        self.www = 'http://www.creditcardcompare.com.au'
        self.www_option = 'http://www.creditcardcompare.com.au/option'
        self.m = 'http://m.creditcardcompare.com.au'
        self.m_option = 'http://m.creditcardcompare.com.au/option'
    
    def test_desktop_option0(self):
        self.offer.outbound_link = None
        self.assertEqual(self.offer.outbound_url, None)
        self.offer.outbound_link = ''
        self.assertEqual(self.offer.outbound_url, '')
        self.offer.outbound_link = self.www
        self.assertEqual(self.offer.outbound_url, self.www)
    
    def test_desktop_option1(self):
        self.option.outbound_url = self.www_option
        self.option.save()
        self.offer.outbound_link = None
        self.assertEqual(self.offer.outbound_url, self.www_option)
        self.offer.outbound_link = ''
        self.assertEqual(self.offer.outbound_url, self.www_option)
        self.offer.outbound_link = self.www
        self.assertEqual(self.offer.outbound_url, self.www_option)
        
        self.offer.outbound_link = self.www
        self.assertEqual(self.offer.outbound_url, self.www_option)
     
    def test_mobile_option0_desktop0_doption0(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = None
        self.offer.outbound_link = None
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, None)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = None
        self.offer.outbound_link = None
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m)
        
    def test_mobile_option0_desktop0_doption1(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = None
        self.offer.outbound_link = None
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.www_option)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = None
        self.offer.outbound_link = None
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m)
        
    def test_mobile_option0_desktop1_doption0(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = None
        self.offer.outbound_link = self.www
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.www)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = None
        self.offer.outbound_link = self.www
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m)
        
    def test_mobile_option0_desktop1_doption1(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = None
        self.offer.outbound_link = self.www
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.www_option)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = None
        self.offer.outbound_link = self.www
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m)
     
    def test_mobile_option1_desktop0_doption0(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = None
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = None
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
    def test_mobile_option1_desktop0_doption1(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = None
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = None
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
    def test_mobile_option1_desktop1_doption0(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = self.www
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = self.www
        self.option.outbound_url = None
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
    def test_mobile_option1_desktop1_doption1(self):
        self.offer.outbound_link_m = None
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = self.www
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
        
        self.offer.outbound_link_m = self.m
        self.option.outbound_url_m = self.m_option
        self.offer.outbound_link = self.www
        self.option.outbound_url = self.www_option
        self.option.save()
        self.assertEqual(self.offer.outbound_url_m, self.m_option)
