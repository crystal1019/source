__author__ = 'RJB'
from flask import Blueprint
auctions = Blueprint('auctions', __name__)
from . import routes