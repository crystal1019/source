
var htmlItemTemplate = [
  '<tr class="<%= is_unseen %>">',
      '<td class="tiny-column">',
          '<div class="icheckbox_square-grey" style="position: relative;"><input type="checkbox" class="selected-checkbox" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div>',
      '</td>',
      '<td class="tiny-column unseen-mark"><% if (is_unseen == "unread"){ %><span class="starred"><i class="fa fa-star color-orange"></i></span><% } %></td>',
      '<td class="name hidden-xs"><%= fromTo %></td>',
      '<td class="subject"><a data-toggle="modal" data-id="<%= id %>" class="subject-a" href="#"> <%= content %></a></td>',
      '<td class="tiny-column"></td>',
      '<td class="date"><%= date %></td>',
  '</tr>'
  ];
var htmlDialogTemplate = [
    '<h3>Campaign: </h3>',
    '<p><strong>From: </strong> <%= fromTo %><br><strong>On: </strong> <%= date %><br><strong>Message: </strong><%= content %></p>'
]
var template = _.template(htmlItemTemplate.join(""));
var _mailCollection = {};
$(document).ready(function(){

    var ajax_call = function(url, method, data, callback){
                    method = method || 'get'
                    data = data || {}
                    $.ajax({
                        async: true,
                        cache: method === 'get' || false,
                        type: method.toUpperCase(),
                        url: url,
                        data: data,
                        complete: function(jqXHR, textStatus){
                            jqXHR.done(function(data){
                                callback(data)
                            });
                        },
                        error: function(jqXHR, textStatus, errorThrown){
                             callback(false)
                            console.log(errorThrown)
                        }
                    });
                }
    var load_item = function(page){
        page = page || 1;
        _url = "/account/inboxview/list/"+ page +"/";
        ajax_call(_url, 'get', null, function(response){
            if(!response){
                console.log('Empty Result')
                return false;
            }
            var content = $('#bc-inbox-mail-content');
            _.each(response.objects, function(item){
                var tm = template({
                        id: item.id,
                        fromTo: item.fromTo,
                        content: item.content,
                        date: item.date,
                        is_unseen : (item.is_shown_by_campaign_owner ? "read" : "unread"),
                });
                content.append(tm)
                // Now Update Mail Dictionary
                _mailCollection[item.id] = item
            });
            // Now populate trigger
            $("a.subject-a ").on('click', function(e){
                me = $(this);
                e.preventDefault();
                _modal = $("#fldMailDetail");
                _modal.find('.modal-body').eq(0).html(_.template(htmlDialogTemplate.join("'"), _mailCollection[me.data('id')]))
                _modal.modal('toggle');
                if(_mailCollection[me.data('id')].is_shown_by_campaign_owner) return;
                 ajax_call('/account/inboxview/seen/' + me.data('id') + '/', 'get', null, function(response){
                    if(response.success === 1){
                        me.parent().siblings('.unseen-mark').eq(0).children().empty();
                        //update _mailCollection
                        _mailCollection[me.data('id')].is_shown_by_campaign_owner = true;
                    }
                 });
            });
        });
    }
    load_item();
});
