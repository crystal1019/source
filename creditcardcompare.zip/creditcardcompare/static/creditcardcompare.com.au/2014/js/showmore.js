function renderCategoryOffers(){
	getMetaData();
	$("img.lazy").show().lazyload();
	try{
		$('.popover-trigger').popover();
	}catch(e){}
};

var offerMetaData = {};
function getMetaData(){
    try{
        category = category_id;
    }catch(e){
        category = 0;
    }
	jQuery.ajax({
		data: {'metadata_only': category},
		dataType: 'json',
		success: function(data) {
			offerMetaData = data.offerMetaData;
		}
	});
};
var _ccc_animdot = {at:2,intv:null,items:null};
var page = 1;
function showMoreCards(evt){

	if(isNaN(_ccc_animdot.intv)){// return if loading in progress
		return;
	}

	jQuery.ajax({
		data: $('.category-page #category-filter-form').serialize(),
		type: 'POST',
		url: $('.category-page .category1showmore').attr('url') + '?page=' + (page + 1),
		dataType: 'json',
		success: function(data) {
		    $('#sortable-offer-list .lastcard').remove();
		    $('#sortable-offer-list').append(data.html);
			page += 1;
			toggleShowMoreButton(data.pages);
		}
	}).always(function(){// hide preloader
			$('.category1showmoredots').hide();
			$('.category1showmoretext').show();
			if(!isNaN(_ccc_animdot.intv)){
				clearInterval(_ccc_animdot.intv);
				_ccc_animdot.intv = null;
			}
		});
	$('.category1showmoretext').hide();
	$('.category1showmoredots').css('display','inline-block');
	// animate dots ::
	_ccc_animdot.intv = setInterval(function(){
		var l = _ccc_animdot.items;
		l.eq(_ccc_animdot.at).animate({opacity:1},100);
		_ccc_animdot.at ++;
		if(_ccc_animdot.at >2){
			_ccc_animdot.at = 0;
		}
		l.eq(_ccc_animdot.at).animate({opacity:0},200);
	},500);

};
function toggleShowMoreButton(totalPages){
	if (page >= totalPages){
		$('.category1showmore').hide();
	}else{
		$('.category1showmore').show();
	};
};
function initQnA(){
	$('.question').click(function(){
		var a = $(this).children('.answer');
		var i = $(this).children('img').attr('src');
		if (a.css('display') == 'none'){
			a.show(400);
			$(this).children('img').attr('src', i.replace('plus', 'minus'));
		}else{
			a.hide(400);
			$(this).children('img').attr('src', i.replace('minus', 'plus'));
		}
	});
};
function initDetails(){
	$('.detail-block').click(function(){
		var a = $(this).children('.detail-content');
		var i = $(this).children('img').attr('src');
		if (a.css('display') == 'none'){
			a.show(400);
			$(this).children('img').attr('src', i.replace('plus', 'minus'));
		}else{
			a.hide(400);
			$(this).children('img').attr('src', i.replace('minus', 'plus'));
		}
	});
};
function isPagination(event, xhr, settings){
	if (settings.url.indexOf('?page=') != -1 && settings.url.indexOf('metadata_only=') == -1){
		return true;
	};
	return false;
};
$(document).ready(function() {
	// dots anim :
	_ccc_animdot.items = $('.category1showmoredots').children();
	$('.category-page .category1showmore').click(showMoreCards);
	
	renderCategoryOffers();
	$(document).ajaxComplete(function(event, xhr, settings){
		if (isPagination(event, xhr, settings)){
			renderCategoryOffers();
		}
	});
	initQnA();
	initDetails();
});
