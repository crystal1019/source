// STANDARIZE THE INFO WITHOUT COMMAS
/*$('.spy-data').each(function(){
	var value = parseFloat(String($(this).data('value')).replace(/([,])/g, ""), 10);
	$(this).attr('data-value', value);
});*/
function minIsBetter(selector) {
	var min = null,
		max = null;
	$(selector).each(function() {
		var value = parseFloat(String($(this).data('value')).replace(/([,])/g, ""), 10);
		$(this).attr('data-value', value);
		if (isNaN(value)) {
			return;
		}
		if ((min === null) || (value < min)) {
			min = value;
		}
		if ((max === null) || (value > max)) {
			max = value;
		}
	});
	if (max != min) {
		$(selector).each(function() {
			var value = $(this).attr("data-value");
			if (isNaN(value)) {
				$(this).addClass('field-wrong');
			}
			if ((value > min) && (value < max)) {
				$(this).addClass('field-medium');
			}
		});
		$(selector + "[data-value='" + min + "']").addClass('field-good');
		$(selector + "[data-value='" + max + "']").addClass('field-bad');
	} else {
		$(selector).each(function() {
			var value = $(this).attr("data-value");
			if (isNaN(value)) {
				$(this).addClass('field-wrong');
				return;
			}
			$(this).addClass('field-same');
		});
	}
}

function maxIsBetter(selector) {
	var min = null,
		max = null;
	$(selector).each(function() {
		var value = parseFloat(String($(this).data('value')).replace(/([,])/g, ""), 10);
		$(this).attr('data-value', value);
		if (isNaN(value)) {
			return;
		}
		if ((min === null) || (value < min)) {
			min = value;
		}
		if ((max === null) || (value > max)) {
			max = value;
		}
	});
	if (max != min) {
		$(selector).each(function() {
			var value = $(this).attr("data-value");
			if (isNaN(value)) {
				$(this).addClass('field-none');
			}
			if ((value > min) && (value < max)) {
				$(this).addClass('field-medium');
			}
		});
		$(selector + "[data-value='" + min + "']").addClass('field-bad');
		$(selector + "[data-value='" + max + "']").addClass('field-good');
	} else {
		$(selector).each(function() {
			var value = $(this).attr("data-value");
			if (isNaN(value)) {
				$(this).addClass('field-wrong');
				return;
			}
			$(this).addClass('field-same');
		});
	}
}

function yesIsBetter(selector) {
	$(selector).each(function() {
		var value = $(this).attr("data-value");
		if (value === "Yes") {
			$(this).addClass('field-good');
		} else if (value === "No") {
			$(this).addClass('field-bad');
		} else if (value.indexOf("Yes") != -1) {
			$(this).addClass('field-good');
		} else {
			$(this).addClass('field-none');
		}
	});
}

function noIsBetter(selector) {
	$(selector).each(function() {
		var value = $(this).attr("data-value");
		if (value == "No") {
			$(this).addClass('field-good');
		} else {
			$(this).addClass('field-bad');
		}
	});
}

function noneIsBetter(selector) {
	$(selector).each(function() {
		var value = $(this).attr("data-value");
		if ((value == "None") || (value == "0")) {
			$(this).addClass('field-good');
		} else {
			$(this).addClass('field-bad');
		}
	});
}

function maxPointsIsBetter(selector) {
	var min = null,
		max = null;
	$(selector).each(function() {
		var originalValue = $(this).data('value');
		var checkValueForNumber = parseFloat(String($(this).data('value')).replace(/([,])/g, ""), 10);
		if (!isNaN(checkValueForNumber)) {
			var newValue = checkValueForNumber;
		} else {
			var textForComparison = originalValue;
			if (textForComparison == 'Unlimited') {
				var newValue = 99999999999;
			} else if (textForComparison == '-') {
			} else {
				var newValue = 99999999998;
			}
		}
		$(this).attr('data-value', newValue);
		if ((min === null) || (newValue < min)) {
			min = newValue;
		}
		
		if ((max === null) || (newValue > max)) {
			max = newValue;
		}
	});
	if (max != min) {
		$(selector).each(function() {
			var value = $(this).attr("data-value");
			if ( value == "-") {
				$(this).addClass('field-none');
			}
			if ((value > min) && (value < max)) {
				$(this).addClass('field-medium');
			}
		});
		$(selector + "[data-value='" + min + "']").addClass('field-bad');
		$(selector + "[data-value='" + max + "']").addClass('field-good');
	} else {
		$(selector).each(function() {
			var value = $(this).attr("data-value");
			if (isNaN(value)) {
				$(this).addClass('field-wrong');
				return;
			}
			$(this).addClass('field-same');
		});
	}
}

//Basic Rates & Fees
//field_card_type
minIsBetter("li[data-field='field_annual_fee']");
minIsBetter("li[data-field='field_annual_fee_2nd_year']");
minIsBetter("li[data-field='field_purchase_rate']");
noneIsBetter("li[data-field='field_balance_transfer_fee']");
minIsBetter("li[data-field='field_balance_transfer_rate']");
minIsBetter("li[data-field='field_balance_transfer_revert_rate']");
maxIsBetter("li[data-field='field_balance_transfer_period']");
minIsBetter("li[data-field='field_cash_advance_fee']");
minIsBetter("li[data-field='field_cash_advance_rate']");
//field_interest_charged_from
maxIsBetter("li[data-field='field_interest_free_period']");
maxIsBetter("li[data-field='field_intro_purchase_period']");
minIsBetter("li[data-field='field_intro_purchase_rate']");
minIsBetter("li[data-field='field_dishonour_fee']");
//field_gambling_tansactions_allowed

//Other Fees & Limits
minIsBetter("li[data-field='field_additional_card_fee']");
maxIsBetter("li[data-field='field_additional_cardholders']");
minIsBetter("li[data-field='field_duplicate_statement_fee']");
minIsBetter("li[data-field='field_late_payment_fee']");
minIsBetter("li[data-field='field_over_limit_fee']");
minIsBetter("li[data-field='field_overseas_atm_balance_fee']");
minIsBetter("li[data-field='field_overseas_atm_withdrawal_fee']");
minIsBetter("li[data-field='field_transaction_verification_fee']");
maxIsBetter("li[data-field='field_minimum_credit_limit']");
maxIsBetter("li[data-field='field_maximum_credit_limit']");
maxIsBetter("li[data-field='field_minimum_repayment']");
minIsBetter("li[data-field='field_foreign_exchange_fee']");

//Rewards & Points
yesIsBetter("li[data-field='field_airport_lounge_access']");
yesIsBetter("li[data-field='field_complimentary_flight_voucher']");
maxIsBetter("li[data-field='field_first_purchase_bonus']");
maxIsBetter("li[data-field='field_frequent_flyer_points_amex']");
maxIsBetter("li[data-field='field_frequent_flyer_points_mcvisa']");
maxIsBetter("li[data-field='field_reward_points_amex']");
maxIsBetter("li[data-field='field_reward_points_mcvisa']");
//field_rewards_program
maxIsBetter("li[data-field='field_sign_up_bonus']");
maxIsBetter("li[data-field='field_spend_return']");
maxPointsIsBetter("li[data-field='field_overseas_earn_rate_amex']");
maxPointsIsBetter("li[data-field='field_overseas_earn_rate_mcvisa']");
maxPointsIsBetter("li[data-field='field_points_cap_per_month_amex']");
maxPointsIsBetter("li[data-field='field_points_cap_per_month_mcvisa']");
maxPointsIsBetter("li[data-field='field_points_cap_per_year_amex']");
maxPointsIsBetter("li[data-field='field_points_cap_per_year_mcvisa']");
noIsBetter("li[data-field='field_rewards_points_cap']");

//Insurances
yesIsBetter("li[data-field='field_extended_warranty_insurance']");
yesIsBetter("li[data-field='field_international_travel_insurance']");
yesIsBetter("li[data-field='field_interstate_flight_inconvenience']");
yesIsBetter("li[data-field='field_personal_item_theft_cover']");
yesIsBetter("li[data-field='field_price_protection_insurance']");
yesIsBetter("li[data-field='field_purchase_protection_insurance']");
yesIsBetter("li[data-field='field_transport_accident_insurance']");

//Elegibility
minIsBetter("li[data-field='field_minimum_age']");
minIsBetter("li[data-field='field_minimum_income']");
//field_citizen_resident
yesIsBetter("li[data-field='field_joint_application']");