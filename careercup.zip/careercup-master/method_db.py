import method_date
import method_user
import method_comment
import method_question
import method_salary
import method_forum
import method_notification

def addInfoToObject(obj, force=False):
	if not(obj):
		return None
	if not(force) and not(ensureVisible(obj)):
		return None
	
	# Set date
	if obj.date:
		obj.date_string = method_date.getDateString(obj.date)
		obj.w3cdate = method_date.getW3CTime(obj.date)
		
	current_user = method_user.getLoggedInUserFromCache()
	if current_user and obj.author_id == current_user['uid']:
		obj.is_admin = True
	else:
		obj.is_admin = method_user.userIsAdmin()
	
	return obj
	
def addInfoToList(list):
	lst = []
	for obj in list:
		o = addInfoToObject(obj)
		if o:
			lst.append(o)
	return lst
	
def onObjectUpdated(obj):
	class_name = obj.__class__.__name__
	if class_name == 'Comment':
		method_comment.clearCache(obj)
	elif class_name == 'ForumPost':
		method_forum.clearCache(obj)
	elif class_name == 'Attribute':
		method_question.clearAttributeCache(obj)	
	elif class_name == 'DuplicateReport':
		method_question.clearDuplicateReportCache(obj)
	elif class_name == 'Question':
		method_question.clearQuestionCache(obj)
	elif class_name == 'UserInfo':
		method_user.clearCache(obj)
	elif class_name == 'SalaryInfo':
		method_salary.clearCache(obj)		
	elif class_name == 'Notification':
		method_notification.clearCache(obj)	
	
def putObject(obj, refresh_cache=True):
	# TODO(gayle): Ensure that nothing else has this id
	if obj.uid:
		obj.put()
		if refresh_cache:
			onObjectUpdated(obj)
		return obj.uid
	else:
		obj.put()
		uid = long(obj.key.id())
		obj.uid = uid			
		obj.put()
		if refresh_cache:
			onObjectUpdated(obj)
		return long(uid)
	
def ensureVisible(obj):
	if obj and obj.visible:
		return obj
	else:
		return None
		
def getObjectWithTypeAndId(obj_id, obj_type):
	if obj_type == 'question':
		obj = method_question.getQuestionWithId(obj_id)
	elif obj_type == 'attribute':
		obj = method_question.getAttributeWithId(obj_id)
	elif obj_type == 'forum':
		obj = method_forum.getForumPostWithId(obj_id)
	elif obj_type == 'comment':
		obj = method_comment.getCommentWithId(obj_id)				
	elif obj_type == 'user':
		obj = method_user.getUserWithId(obj_id)
	else: 
		obj = method_question.getQuestionWithId(obj_id) # Default
	return obj
	
def refreshCommentCountByUser(user):
	if user is None:
		return
	count = method_user.getCommentCountByUser(user.uid)
	obj = getObjectWithTypeAndId(user.uid, 'user')
	obj.comment_count = count
	putObject(obj)	
	return count
	
def refreshCommentCount(id, type):
	comments = method_comment.getCommentsWithAncestor(id)
	count = len(comments)
	obj = getObjectWithTypeAndId(id, type)
	obj.comment_count = count
	putObject(obj)
	return count