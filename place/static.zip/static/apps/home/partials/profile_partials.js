angular.module('ProfileMenuApp').run(['$templateCache', function($templateCache) {

  $templateCache.put('/static/apps/common/partials/topic_card.html',
    "<figure ng-repeat=\"topic in topics\" class=\"topic_box\" ng-class=\"topic.featured && highlight_featured ? 'featured':''\"><header ng-if=\"topic.featured && highlight_featured\">Featured topic</header><div class=\"inner\"><a ng-if=\"topic.image\" href=\"/topic/{{topic.id}}\"><img ng-src=\"{{topic.image}}\" alt=\"{{topic.title}}\"><h4>{{topic.title}}</h4></a><h4 ng-if=\"!topic.image\"><a href=\"/topic/{{topic.id}}\">{{topic.title}}</a></h4><figcaption>By <a href=\"/explore/?q='{{ topic.organization }}'&amp;type=organization\">{{ topic.organization }}</a></figcaption><summary><p>{{topic.abstract}}</p></summary><section ng-if=\"topic.is_archived\"><p class=\"ftr_pin archived\">Archived</p></section><section><p class=\"ftr_pin {{topic.category}}\">{{topic.category | capitalize:true}}</p></section><section ng-if=\"topic.keywords\"><p class=\"ftr_tag\"><a ng-repeat=\"keyword in topic.keywords\" href=\"/explore/?q=\\\"{{ keyword }}\\\"&amp;type=tag\">{{keyword}}<span ng-if=\"!$last\">,</span></a></p></section></div></figure>"
  );

}]);
