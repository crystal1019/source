import json
import logging
from django.conf import settings
from django.http import HttpResponse, HttpResponseBadRequest
from .exceptions import HukksterNotSupported, HukksterTechnicalDifficulties, HukksterTooManyOptions
from .helpers import select_scraper


logger = logging.getLogger('scraper')


def scrape(request):
    url = request.GET.get('url', None)

    try:
        scraper = select_scraper(url)
        if scraper is None:
            return HttpResponseBadRequest('Wrong format')
        status = 200
        content = scraper.parse()
    except HukksterNotSupported, e:
        logger.debug('Failed to find a scraper for %s' % url)
        status = 404
        content = e.message
    except HukksterTooManyOptions, e:
        status = 404  # TODO: it should be really 400, Bad Request
        content = e.message
    except HukksterTechnicalDifficulties, e:
        logger.critical('Got critical error for %s' % url)
        status = 500
        content = e.message
    except:  # TODO: improve it later because it's ugly
        if not settings.DEBUG:
            e = HukksterTechnicalDifficulties()
            logger.critical('Got critical error for %s' % url)
            status = 500
            content = e.message
        else:
            raise

    data = dict(status=status, content=content, legacy=False)
    response = json.dumps(data)

    # Return JSONP if required
    callback = request.GET.get('callback', None)
    if callback is not None:
        response = '%s(%s);' % (callback, response)

    return HttpResponse(response, content_type='application/json')
