cd /home/chaol/projects/bellabustiere
python manage.py send_email > /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vouchercheck_process
echo "---------------" >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vouchercheck_process
cat  /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vouchercheck_process >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/vouchercheck_allprocess
