from django.db import models
from django.contrib.sites.models import *
from django.conf import settings

# Create your models here.
class SiteMeta(models.Model):
    site = models.OneToOneField(Site)
    title = models.CharField(max_length=255, null=True, help_text='default page title on each page of the site')
    meta_keywords = models.TextField(help_text='default keywords on each page of the site', default='')
    meta_description = models.TextField(help_text='default description on each page of the site',default='')
    footer_text = models.TextField(null=True, blank=True)

    def __unicode__(self):
        return self.site.domain
    
class ArkGroup(models.Model):
    name = models.CharField(max_length=200)
    link = models.URLField(blank=True,null=True)
    image = models.ImageField(upload_to='images/ark/')
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name
    
    class Meta:
        ordering = ['-priority',]


class MiscPage(models.Model):
    title = models.CharField(max_length=255)
    path = models.CharField(max_length=255,help_text="eg. about.html", unique=True)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    status = models.ForeignKey("blog.PublishStatus")
    priority = models.IntegerField(default=0)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    sites = models.ManyToManyField(Site)
    
    def __unicode__(self):
        return self.title
    
    def get_absolute_url(self):
        return '/' + self.path
    
    
    def in_site(self):
        return ','.join([x.name for x in self.sites.all()])
        
    class Meta:
        ordering = ['-priority',]