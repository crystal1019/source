from django import forms as django_forms
from django.forms import ModelForm

from models import Profile, Recipe, RecipeComment, BlogPost, BlogPostComment, \
    ACCESS_PRIVATE, ACCESS_FRIENDS, ACCESS_PUBLIC, \
    default_user_settings

class SignupForm(django_forms.Form):
    email = django_forms.CharField()
    name = django_forms.CharField()
    password = django_forms.CharField(widget = django_forms.PasswordInput)

class LoginForm(django_forms.Form):
    email = django_forms.CharField()
    password = django_forms.CharField(widget = django_forms.PasswordInput)

class ProfileForm(ModelForm):
    class Meta:
        model = Profile
        exclude = ('user', 'photo', 'access',)
        widgets = {
            'about': django_forms.Textarea(
                attrs={'cols': 80, 'rows': 5, 'class': 'input-xlarge'}
                )
            }

class SettingsForm(django_forms.Form):

    yes_no_choices = (['yes', 'Yes'],
                      ['no', 'No'])

    new_recipes_privacy = django_forms.ChoiceField(
        label = 'Default privacy setting on new recipes',
        choices = ([ACCESS_PUBLIC, 'Public'],
                   [ACCESS_FRIENDS, 'Friends only'],
                   [ACCESS_PRIVATE, 'Private']),
        initial = default_user_settings['new_recipes_privacy']
        )
    
    new_comments_email = django_forms.ChoiceField(
        label = 'Email me when someone comments on one of my recipes',
        choices = yes_no_choices,
        initial = default_user_settings['new_comments_email']
        )

    new_bookmarks_email = django_forms.ChoiceField(
        label = 'Email me when someone bookmarks one of my recipes',
        choices = yes_no_choices,
        initial = default_user_settings['new_bookmarks_email']
        )

    digest_email = django_forms.ChoiceField(
        label = "Email me a weekly digest of my friends' activity",
        choices = yes_no_choices,
        initial = default_user_settings['digest_email']
        )

class ChangePasswordForm(django_forms.Form):
    current_password = django_forms.CharField(
        widget = django_forms.PasswordInput()
        )
    new_password = django_forms.CharField(
        widget = django_forms.PasswordInput()
        )

class BlogPostForm(ModelForm):
    class Meta:
        model = BlogPost
        exclude = ('created_at', 'updated_at', )
        widgets = {
            'contents': django_forms.Textarea(
                attrs={'cols': 80, 'rows': 5, 'class': 'input-xlarge'}
                ),

            'title': django_forms.TextInput(),

            'author': django_forms.HiddenInput(),
            'access': django_forms.HiddenInput(),
            }

class BlogPostCommentForm(ModelForm):
    class Meta:
        model = BlogPostComment
        exclude = ('author', 'post',)

class RecipeCommentForm(ModelForm):
    class Meta:
        model = RecipeComment
        exclude = ('author', 'recipe',)

class RecipeForm(django_forms.Form):
    title = django_forms.CharField()
    description = django_forms.CharField(
        widget = django_forms.Textarea(
            attrs={'cols': 80, 'rows': 5, 'class': 'input-xlarge'}
            ),
        required = False)
    photos = django_forms.FileField(required = False)
    typ = django_forms.CharField(widget = django_forms.HiddenInput())    

    link = django_forms.CharField(
        widget = django_forms.TextInput(attrs={
                'class': 'data_field',
                'placeholder': 'Recipe URL...'
                }),
        required = False,
        )

    recipe_file = django_forms.FileField(
        required = False,
        widget = django_forms.FileInput(attrs={'class': 'data_field'})
        )
    contents = django_forms.CharField(
        widget = django_forms.Textarea(
            attrs={
                'cols': 80, 'rows': 15, 'class': 'data_field',
                'placeholder': 'Type your recipe here.' + \
                    ' Don\'t forget to mention your sources...'
                }
            ),
        required = False
        )

    def __init__(self, *args, **kwargs):
        if 'recipe' in kwargs and 'rdata' in kwargs:
            r = kwargs['recipe']
            data = kwargs['rdata']

            initial = {
                field.name: getattr(r, field.name) for field in r._meta.fields
                }

            data_init = {field.name: getattr(data, field.name) \
                             for field in data._meta.fields}
            initial.update(data_init)

            kwargs['initial'] = initial
            del kwargs['recipe']
            del kwargs['rdata']

        return super(django_forms.Form, self).__init__(*args, **kwargs)

class InviteForm(django_forms.Form):
    invitee = django_forms.CharField(label='Your friend\'s email address')
    message = django_forms.CharField(
        widget = django_forms.Textarea(
            attrs={'class': 'input-xlarge'}
            ),
        required = False,
        label = 'A message to include with the invitation'
        )
