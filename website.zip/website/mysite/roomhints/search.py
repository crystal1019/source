from roomhints.search_indexes import Hint
from haystack.query import SearchQuerySet
import math
from roomhints.utils import make_unique, search_profile_id

def search(query):
    sprofile_id = search_profile_id()
    all = SearchQuerySet().filter(content=query).models(Hint).filter(profile_id=sprofile_id,public=True).all()

    data = dict()
    data['search'] = []
    for hint in all:
        data_item = dict()
        data_item['query'] = query
        data_item['name'] = hint.name
        data_item['price'] = math.ceil(hint.price)
        data_item['source'] = hint.source
        data_item['source_url'] = hint.source_url
        data_item['sku'] = hint.sku
        data_item['photo'] = hint.photo
        data_item['dominant_hex'] = hint.dominant_hex
        data['search'].append(data_item)
    return data
