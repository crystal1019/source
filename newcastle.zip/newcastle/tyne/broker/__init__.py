import tyne

SQLALCHEMY_BROKER_DB_URI = 'mysql+mysqlconnector://root:mysql@localhost/broker_db'

# flask web server stuff
from flask import Flask
app = Flask(__name__)
import tyne.broker.routes

#web server db stuff
app.config['SQLALCHEMY_DATABASE_URI'] = SQLALCHEMY_BROKER_DB_URI
from tyne.broker.models import db
db.init_app(app)

