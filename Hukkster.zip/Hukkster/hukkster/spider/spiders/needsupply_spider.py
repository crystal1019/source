from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from ..items import Product

class NeedSupplySpider(CrawlSpider):
    name = 'needsupply'
    allowed_domains = ['needsupply.com',]
    start_urls = [
        'http://needsupply.com/',
        ]

    rules = (
        Rule(SgmlLinkExtractor(allow=('\.html', )), callback='parse_item'),  # We collect products only
        Rule(SgmlLinkExtractor(deny=('\/directory\/'))),  # Continue following all URLs
    )

    def parse_item(self, response):
        hxs = HtmlXPathSelector(response)

        product = Product()
        product['name'] = hxs.select('//div[@class="details"]/h1/text()').extract()[0].strip()
        product['sku'] = hxs.select('//input[@name="product"]/@value').extract()[0].strip()
        product['url'] = response.url
        return product
