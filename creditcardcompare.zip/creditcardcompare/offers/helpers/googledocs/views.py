from django.http import HttpResponse
from googledocs import importers

def sync_with_google(request, importer_name):
    result = getattr(importers, importer_name)()
    return HttpResponse(result)