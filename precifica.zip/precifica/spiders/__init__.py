from scrapy import Spider
from scrapy.contrib.spiders import SitemapSpider


class PrecificaSpider(Spider):
    """Base spider."""


class ExtraURLsSitemapSpider(SitemapSpider):
    """

    Sitemap spider with support for start URLs other than sitemaps as well.

    """

    def start_requests(self):
        for r in super(ExtraURLsSitemapSpider, self).start_requests():
            yield r

        for r in Spider.start_requests(self):
            yield r
