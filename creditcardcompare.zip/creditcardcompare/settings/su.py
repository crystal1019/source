import os, sys
from settings import *


EMAIL_SUBJECT_PREFIX = '[SU AWS ALERT 2]'

SITE_ID = 9
SITE_NAME = 'savingup.com.au'
INTERNAL_LINK = 'www.savingup.com.au'
ALLOWED_HOSTS = [SITE_NAME, 'www.savingup.com.au']
IMAGE_URL = 'http://images.savingup.com.au/media'

MOBILE_TEMPLATE_DIR = ''
DEVICES = {'smartphone': 0, 'desktop': 1}
DEFAULT_TEMPLATE = DEVICES['desktop']
TEMPLATE_DIRS = (
    os.path.join(PROJECT_DIR, 'templates', SITE_NAME),
    os.path.join(PROJECT_DIR, 'templates', 'all_sites'),
)
#===============================================================================
# Application settings
#===============================================================================

AWS_S3_CUSTOM_DOMAIN = 'media.' + SITE_NAME
STATIC_URL = 'http://%s/static/' % AWS_S3_CUSTOM_DOMAIN
MEDIA_URL = 'http://%s/media/' % AWS_S3_CUSTOM_DOMAIN
COMPRESS_OUTPUT_DIR = 'compressed/' + SITE_NAME

# MC_APPS = [
#     'lead', # also used by CCC
# ]
# INSTALLED_APPS += MC_APPS

try:
    from settings.dev import *
except ImportError:
    pass
else:
    INSTALLED_APPS += DEV_APPS
