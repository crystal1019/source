import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions, HukksterTechnicalDifficulties


logger = logging.getLogger('scraper')


class LoftScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'loft.com'

    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()

    def fetch_url(self):
        try:
            print 'request', self.url
            request = requests.request('get', self.url)

            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except BaseException, e:
            logging.error('Error %s for %s' % (e.msg, self.url))
            raise HukksterTechnicalDifficulties(LoftScraper.getDomain(), self.url)


    def generate_record(self, url, site, title, price, image,
                        sku, size='', color='', promos=[]):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record
        
    def between(self, left, right, s):
        before,_,a = s.partition(left)
        a,_,after = a.partition(right)
        return before,a,after

    def craw_html_data(self, soup, html, raw_data):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """
        
        # site_name
        site_name = soup.find('meta', attrs={'property': 'og:site_name'})['content']
        
        #image
        image = soup.find('meta', attrs={'property': 'og:image'})['content']
        
        #url
        url = soup.find('meta', attrs={'property': 'og:url'})['content']
                
        # title
        title = soup.find('meta', attrs={'property': 'og:title'})['content']
        
        # description
        description = soup.find('div', attrs={'class': 'description'}).find('p').text
       
        # price
        pricetemp = soup.find('div', attrs={'class': 'price'}).find('p', attrs={'class': 'sale'}).text
        price = float(pricetemp[2:])

        # sizes
        sizeslist = soup.find('fieldset', attrs={'id': 'fs-size'}).find_all('li')
        sizes = []
        for size in sizeslist:
            sizes.append(size['id'])
        
        # colors
        colorlist = soup.find_all('input', attrs={'id': 'colorName'})
        colors = []
        for color in colorlist:
            colors.append(color['value'])
        
        # product id
        sku = soup.find('input', attrs={'id': 'productId'})['value']
        
        selections = []

        for color in colors:
            for size in sizes:
                record = self.generate_record(url, site_name, title,
                                              price, image, sku, size, color)
                selections.append(record)

        return selections
        
    def parse_single_product(self, soup, html, raw_data):
        # site_name
        site_name = soup.find('meta', attrs={'property': 'og:site_name'})['content']
        
        #image
        image = soup.find('meta', attrs={'property': 'og:image'})['content']
        
        #url
        url = soup.find('meta', attrs={'property': 'og:url'})['content']
                
        # title
        title = soup.find('meta', attrs={'property': 'og:title'})['content']
        
        # description
        description = soup.find('div', attrs={'class': 'description'}).find('p').text
       
        # price
        pricetemp = soup.find('div', attrs={'class': 'price'}).find('p', attrs={'class': 'sale'}).text
        price = float(pricetemp[2:])

        # sizes
        sizeslist = soup.find('fieldset', attrs={'id': 'fs-size'}).find_all('li')
        sizes = []
        for size in sizeslist:
            sizes.append(size['id'])
        
        # colors
        colorlist = soup.find_all('input', attrs={'id': 'colorName'})
        colors = []
        for color in colorlist:
            colors.append(color['value'])
        
        # product id
        sku = soup.find('input', attrs={'id': 'productId'})['value']
        
        selections = []

        for color in colors:
            for size in sizes:
                record = self.generate_record(url, site_name, title,
                                              price, image, sku, size, color)
                selections.append(record)

        return selections
        
        
    def parse_multi_products(self, soup, html, raw_data):
        # site_name
        site_name = soup.find('meta', attrs={'property': 'og:site_name'})['content']
                
        # title
        title = soup.find('meta', attrs={'property': 'og:title'})['content']
        
        products = soup.findAll('div', attrs={'class':'product'})
        selections=[]
        for p in products:
            img_tag = p.find('img')
            
            # image
            image = img_tag['src']
            
            # Description
            description = img_tag['alt']
            
            # url 
            url = p.findAll('a')[1]['href']
            url = LoftScraper.getDomain() + '/' +url
            
            # sku
            quick_url = p.find('div', attrs={'id':'quick-lookUrl'}).text
            sku = self.between('prodId', '&', quick_url)
        
            # price
            price = p.find('p', attrs={'class':'sale'}).text.replace('$', '').replace(' ', '')
            price = float(price)
            
            # colors
            colors = p.findAll('a', attrs={'class':"text-replace"})
            if colors:
                for row in colors:
                    color = row.text
                    record = self.generate_record(site=site_name, url=url, sku=sku, title=title, price=price, image=image, color=color)
                    selections.append(record)    
            else:
                record = self.generate_record(site=site_name, url=url, sku=sku, title=title, price=price, image=image)
                selections.append(record)
            
        return selections

    def parse(self):
        raw_data = self.parse_opengraph()
        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        #selections = self.craw_html_data(soup, self.html, raw_data)
        
        try: 
            selections = self.parse_single_product(soup, self.html, raw_data)
        except:
            selections = self.parse_multi_products(soup, self.html, raw_data)


        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(NeedSupplyScraper.get_domain(), self.url)

        return selections
