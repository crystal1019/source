from django.db import models
from arktotalwealth.component.models import *
import urllib
from tagging.fields import TagField
from tagging.models import Tag
from django.conf import settings
# Create your models here.
class NewsPage(models.Model):
	PAGE_CHOICES = [['index','Financial Advice Blog'],]
	title = models.CharField(max_length=255, choices=PAGE_CHOICES, unique=True)
	image = models.ImageField(upload_to='images/',blank=True,null=True,help_text='section header image, width:764')
	content = models.TextField(blank=True,null=True, editable=False)
	link = models.URLField(blank=True,null=True, editable=False)
	meta_keywords = models.CharField(max_length=255, blank=True,null=True ,help_text="max length 255 characters, please separate it by ','")
	meta_description = models.TextField(blank=True,null=True)  
	action_links = models.ManyToManyField(ActionLink, blank=True,null=True)
	def __unicode__(self):
   
	   return self.get_title_display()

	def get_absolute_url(self):
	   return '/news/%s.html' %self.title

	class Meta:
	   verbose_name = 'Media center pages'

class BlogCategory(models.Model):
	name = models.CharField(max_length=50)
	slug = models.SlugField(unique=True,null=True)
	image = models.ImageField(upload_to="images/",blank=True,null=True, editable=False)
	priority = models.IntegerField(default=0, help_text="Used to control ordering of categories, higher numbers show higher in the list")
	is_active = models.BooleanField(default=False)
	is_article = models.BooleanField('is this an article category ?',default=False)

	def __unicode__(self):
	    return self.name

	def get_absolute_url(self):
	    return '/financial-advice/%s-archive1.html' % (self.slug)

	class Meta:
	    verbose_name = "News category"
	    verbose_name_plural = "News categories"

class BlogPost(models.Model):
	title = models.CharField(max_length=75)
	slug = models.SlugField("Unique ID", help_text="This should be automatically generated", unique=True)
	category = models.ManyToManyField(BlogCategory)
	content = models.TextField()
	priority = models.IntegerField(default=0)
	tags = TagField()
	publishdate = models.DateTimeField()
	created = models.DateTimeField(auto_now_add=True)
	modified = models.DateTimeField(auto_now=True)
	active = models.BooleanField(default=False)
	allow_comment = models.BooleanField(default=True)
	homepage_image = models.ImageField(upload_to="images/", blank=True, null=True, editable=False)

	def get_absolute_url(self):
	    return "/financial-advice/%s.html" % (self.slug)

	def get_facebook_like_url(self):
	    return urllib.quote('%s' %('http://'+settings.DOMAIN+self.get_absolute_url()),'')

	def getCommentsCount(self):
	    return self.getComments().count()
	def getComments(self):
	    return self.comment_set.filter(active=True).order_by("created")
	def get_previous_entry(self):
	    try:
	        return self.get_previous_by_publishdate(active=True)
	    except:
	        return None
	def get_next_entry(self):
	    try:
	        return self.get_next_by_publishdate(active=True)
	    except:
	        return None

	def get_tags(self):
	    return Tag.objects.get_for_object(self)

	def list_category(self):
	    return ','.join([x.name for x in self.category.all()])

	def __unicode__(self):
	    return self.title

	class Meta:
	    verbose_name = "News Post"
	    ordering = ['-publishdate',]

class Comment(models.Model):
	post = models.ForeignKey(BlogPost)
	name = models.CharField(max_length=50)
	email = models.EmailField()
	website = models.URLField(blank=True, null=True)
	comment = models.TextField()
	created = models.DateTimeField("Date Posted", auto_now_add=True)
	active = models.BooleanField(default=True)
	ip = models.CharField(max_length=50, blank=True, null=True)

	def __unicode__(self):
	    return "Comment by "+self.name+" on "+self.post.title

