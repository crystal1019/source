from django.conf import settings
from boto.s3.connection import S3Connection


connection = S3Connection(settings.AWS_ACCESS_KEY_ID, settings.AWS_SECRET_ACCESS_KEY)
bucket = connection.get_all_buckets()[0]

missing_types = []
types = {
        'jpeg': 'image/jpeg',
        'jpg': 'image/jpeg',
        'JPG': 'image/jpeg',
        'png': 'image/png',
        'gif': 'image/gif',
    }

for key in bucket.list():
    if not key.name.startswith('media/'):
        continue
    ext = key.name.split('.')[-1]
    content_type = types.get(ext, None)
    if content_type is None:
        if ext not in missing_types:
            missing_types.append(ext)
        continue
    print ext, key.name
        
    key.metadata.update({
        'Content-Type': content_type,
        'Cache-Control': 'max-age=2592000'
    })
    key.copy(
        key.bucket.name, 
        key.name, 
        key.metadata, 
        preserve_acl=True
    )
    
print missing_types