from scrapy.contrib.djangoitem import DjangoItem
from scrapy.item import Item, Field
from .models import Category


class CategoryItem(DjangoItem):
    django_model = Category


class Product(Item):
    name = Field()
    sku = Field()
    url = Field()
