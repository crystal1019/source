#!/bin/sh

cd /home/roomhints/devel/RH/website/mysite; pkill python; ./v.sh; screen python manage.py runserver 0.0.0.0:18000
