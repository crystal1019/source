import re
import logging
from lxml.html import fromstring
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


def get_all_text(t):
    tl = t.xpath('.//text()')
    if isinstance(tl, list):
        return "".join(tl).strip()
    return tl


class BcbgScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'bcbg.com'

    # def fetch_url(self):
    #     with open('data.html', 'r') as f:
    #         self.html = f.read()

    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ""
        t = lxml.xpath('.//span[@itemprop="productID"]/text()')
        if len(t) > 0:
            sku = t[0].strip()
        else:
            logger.debug('SKU nof found')
            return

        # title
        title = ""
        t = lxml.xpath('.//h1[@class="product-name"]/text()')
        if len(t) > 0:
            title = t[0]
        else:
            logger.debug('Title nof found')

        # Product price
        t = lxml.xpath('.//div[@class="product-price"]')
        product_current_price = None
        product_standard_price = None

        if t:
            te = t[0]
            tprice = None
            tsales = None

            tpl = te.xpath('.//span[@class="original-price"]/text()')
            if tpl:
                tprice = "".join(tpl)
            else:
                tpl = te.xpath('.//span[@class="price-sales"]/text()')
                tsales = "".join(tpl).strip()

                tpl = te.xpath('.//span[@class="price-standard"]/text()')
                tprice = "".join(tpl).strip()

            prices = re.findall(r'\$(\d+\.\d+)', tprice)
            if len(prices):
                product_current_price = float(prices[-1])
                if tsales:
                    product_standard_price = product_current_price
                    sales = re.findall(r'\$(\d+\.\d+)', tsales)
                    product_current_price = float(sales[-1])
        else:
            logger.debug('Price nof found')

        # Product sizes
        product_sizes = []
        tl = lxml.xpath('.//select[@class="variation-select"]/option/text()')
        if tl:
            for te in tl:
                te = te.strip()
                product_sizes.append(te)

        # Product colours
        product_colours = {}
        tl = lxml.xpath('.//ul[@class="swatches Color"]/li/div[@class="colorname"]')
        for te in tl:
            til = te.xpath('.//img/@src')
            if til:
                img = til[0]
                name = te.text_content().strip()
                product_colours[name] = img

        for te in tl:
            name = te.get('title')
            img = te.get('img')
            colour_image = ""
            cl = te.xpath('.//img/@src')
            if cl:
                colour_image = cl[0]
            product_colours[name] = colour_image

        # Product images
        images = []
        tl = lxml.xpath('.//a[@class="product-image main-image"]/@href')
        picmain = ""
        if tl:
            picmain = tl[0]

        images.append(picmain)

        tl = lxml.xpath('.//li[@class="prodThumbnailImage"]/div[@class="thumb"]/a/@href')
        for te in tl:
            if not te in images:
                images.append(te)

        selections = []
        #---
        # self.url = "UBRAT TYT URL"

        data_store = ""
        tl = lxml.xpath('.//meta[@name="description"]/@content')
        if tl:
            data_store = tl[0]

        data_image = raw_data.get('image', '')
        if data_image == '':
            images.reverse()
            data_image = images.pop()
            images.reverse()
        for table_size in product_sizes:
            if not table_size:
                continue
            for table_colour in product_colours:
                if not table_colour:
                    continue
                data = {'title': title,
                        'current_price': {
                            'value': product_current_price
                            },
                        'url': self.url,
                        'store': data_store.lower(),
                        'image': data_image,
                        'images': images,
                        'local_id': sku,
                        'selections': {
                            'size': table_size,
                            'color': table_colour,
                            },
                        'promos': []
                    }
                if product_standard_price:
                    data['original_price'] = {'value': product_standard_price}
                    #data['sold_out'] = True

                selections.append(data)
        return selections

    def parse(self):
        logger.debug('Bcbg parse started')
        # No opengraph data
        #og = opengraph.OpenGraph(html=self.html)
        #raw_data = dict([(k, v) for k, v in og.items()])
        raw_data = {}
        lxml = fromstring(self.html)
        selections = self.parse_single_product(lxml, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(BcbgScraper.get_domain(), self.url)

        return selections
