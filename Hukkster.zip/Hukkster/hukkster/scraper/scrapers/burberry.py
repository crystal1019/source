import logging
import re
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class BurberryScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'burberry.com'

    # def fetch_url(self):
    #      with open('test_data/burberry/products.html', 'r') as f:
    #          self.html = f.read()

    def removeNonAscii(self, s):
        return "".join(filter(lambda x: ord(x) < 128, s))

    def parse_products(self, soup, raw_data):
        products = soup.find_all("li", class_="-overlay-product");
        result = []
        for product in products:
            image = product.find("img").get("data-src")
            title = product.find("h2", class_="-overlay-title")
            url = product.find("a")
            price = product.find("span", class_="-overlay-price-amount")

            if image is None or price is None or title is None:
                continue

            image = re.sub("\?\$cell_width1\$", "", image)
            title = self.removeNonAscii(title.string)
            price = re.sub("[\s\$\,]", "", price.string)
            url = self.removeNonAscii("http://us.burberry.com" + url.get("href"))
            result.append({
                "image": image,
                "title": title,
                "current_price": price,
                "url": url
            })

        return result

    def parse(self):
        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        # Try to parse a single-product variant first
        selections = self.parse_products(soup, self.html)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(BurberryScraper.get_domain(), self.url)

        return selections
