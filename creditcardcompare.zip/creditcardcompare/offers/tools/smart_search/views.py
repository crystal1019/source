from django.core.urlresolvers import reverse
from django.db import IntegrityError
from django.forms import ValidationError
from django.forms.formsets import formset_factory
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.sites.models import Site
from offers.helpers.lead.helpers import get_age, save_lead, EmailThread
from offers.helpers.lead.models import Lead
from offers.core.models import BalanceTransfer, Category, Offer, OfferCategory
from offers.core.views import offer_list_for_category
from offers.core.utils import NON_DIGIT_RE, NON_DIGIT_RE_END
from forms import BankForm, SmartSearch, SmartSearch1
from helpers import xor_crypt
from models import Bank, SearchDetail


def _filter_by_meta(offers, meta_key, filter_val, keep_null=False, higher_is_better=False):
    matched_offers = []
    for offer in offers:
        try:
            meta_value = offer.meta_instances.get(meta_field__key=meta_key).value_or_default
            val = float(NON_DIGIT_RE_END.sub('', NON_DIGIT_RE.sub('', meta_value)))
        except (ValueError, offer.meta_instances.model.DoesNotExist):
            if keep_null:  # "no value" means "doesn't matter"(Ex: Minimum Age)
                matched_offers.append(offer)
            continue
        included = val >= filter_val if higher_is_better else val <= filter_val
        if included and offer not in matched_offers:
            matched_offers.append(offer)
    return matched_offers


def smart_search(request, template_name=None):
    template = 'smart-search/step2.html'
    context = {}
    BankFormSet = formset_factory(BankForm, extra=1)
    if request.GET and 'source' not in request.GET:
        '''Handles requests from users clicking the link from email
        '''
        try:
            search_id = xor_crypt(request.GET['details'])
            try:
                search_detail = SearchDetail.objects.get(id=search_id)
            except (ValueError, SearchDetail.DoesNotExist):
                try:
                    search_detail = SearchDetail.objects.get(id=request.GET['details'])
                except ValueError:  # SearchDetail.DoesNotExist
                    return HttpResponseRedirect(reverse(smart_search))
            category_slug = _create_result_category(search_detail)
        except KeyError:  # when lightbox request
            try:
                category_slug = Category.objects.get(
                                id=request.GET['metadata_only']).slug
            except KeyError:  # old URL (/tools/smart-search.php?email=[email])
                try:
                    lead = Lead.objects.get(email=request.GET['email'])
                    search_detail = lead.searchdetail_set.order_by('-pk')[0]
                except (IndexError, KeyError):
                    return HttpResponseRedirect(reverse(smart_search))
                category_slug = _create_result_category(search_detail)
        if request.is_ajax():
            request.POST = request.GET
        return offer_list_for_category(request, category_slug)
    elif request.POST.get('category_slug', None):
        '''Handles requests from clicking "1 enter your details"
        from progress indicator at the top of the page
        '''
        searchdetail_id = request.POST['category_slug'].split('-')[-1]
        try:
            search_detail = SearchDetail.objects.get(pk=searchdetail_id)
        except SearchDetail.DoesNotExist:  # when result list is empty
            lead = Lead.objects.filter(ip=request.META['REMOTE_ADDR']
                              ).order_by('-pk')[0]
            search_detail = lead.searchdetail_set.order_by('-pk')[0]
        form = SmartSearch({
                    'cardtype': search_detail.cardtype.id,
                    'balance_transfer': search_detail.balance_transfer,
                    'frequent_flyer': search_detail.frequent_flyer,
                    'rewards': search_detail.rewards,
                    'insurance': search_detail.insurance,
                    'firstname': search_detail.lead.first_name,
                    'lastname': search_detail.lead.last_name,
                    'birthday': search_detail.birthday,
                    'birthmonth': search_detail.birthmonth,
                    'birthyear': search_detail.birthyear,
                    'workstatus': search_detail.workstatus,
                    'income': search_detail.income,
                    'email': search_detail.lead.email,
                    'state': search_detail.lead.state.id,
                    'term': True,
                    'voucher': True,
                })
        banks = []
        for  bank in search_detail.bank_set.all():
            banks.append({'bank': bank.bank.id})
        BankFormSet = formset_factory(BankForm, extra=0)
        formset = BankFormSet(initial=banks)
    elif request.POST:
        '''Handles form submission requests
        '''
        if request.POST.has_key('email'):
            try:
                form = SmartSearch(request.POST)
                formset = BankFormSet(request.POST, request.FILES)
            except ValidationError:
                # data is tampered, return empty form
                return HttpResponseRedirect(reverse(smart_search))
            if form.is_valid() and formset.is_valid():
                search_detail = _save_lead_info(form.cleaned_data,
                                                formset.cleaned_data,
                                                request)
                try:
                    form._errors["email"] = form.error_class(search_detail['email'].errors)
                except TypeError:  # means search_detail is not a LeadForm instance
                    category_slug = _create_result_category(search_detail, form.cleaned_data)
                    return HttpResponseRedirect(reverse(smart_search_result) + '?details=' + xor_crypt(search_detail.id))
        else:
            form = SmartSearch(initial=request.POST)
            formset = BankFormSet()
                
    else:
        '''Renders the forms when user enters Smart Search the first time
        '''
        template = template_name or 'smart-search/form.html'
        form = SmartSearch1(initial=_get_referer_category(request))
        formset = None
    context.update({'form': form, 'formset': formset})
    return render_to_response(template, context, RequestContext(request))
    
    
def smart_search_result(request):
    return smart_search(request)


def _get_referer_category(request):
    '''Ticket #484 comment #27
    Prefill card category
    '''
    try:
        referer = request.META['HTTP_REFERER']
        referer = referer.split('/')[3].replace('.php', '')
    except (KeyError, IndexError):
        return {}
    try:
        category = Category.objects.get(slug=referer)
    except Category.DoesNotExist:
        return {}
    data = {'cardtype': category.id}
    if referer == 'frequent-flyer-credit-cards':
        data.update({'frequent_flyer': 'qantas-frequent-flyer-'})
    return data


def _search_offers(details):
    bt_set = BalanceTransfer.objects.filter(no_transfer_to__in=[bank.bank.id for bank in details.bank_set.all()])
    excluded_banks = [bt.no_transfer_from.id for bt in bt_set]
    offers = Offer.objects.filter(
                categories__issuer_profile__available_in=details.lead.state
              ).filter(categories__id=details.cardtype.id
              ).exclude(categories__in=excluded_banks
              ).distinct()
    if details.workstatus == 7:  # if student
        offers = offers.filter(categories__slug='student-credit-cards')
    offers = _filter_by_cardtype(offers, details)
    offers = _filter_by_meta(offers, 'Minimum Income',
                             int(details.income), keep_null=True)
    offers = _filter_by_meta(offers, 'Minimum Age', get_age(details),
                             keep_null=True)
    return offers


def _filter_by_cardtype(offers, details):
    _choices = {
            'frequent-flyer-credit-cards': 'frequent_flyer',
            'rewards-credit-cards': 'rewards',
            'balance-transfer-credit-cards': 'balance_transfer',
            'insurance-credit-cards': 'insurance',
        }
    if details.cardtype.slug != 'business-credit-cards':
        offers = offers.exclude(categories__slug='business-credit-cards')

    if details.cardtype.slug in ['frequent-flyer-credit-cards', 'rewards-credit-cards']:
        offers = offers.filter(categories__slug=details.cardtype.slug)
    elif details.cardtype.slug == 'balance-transfer-credit-cards':
        meta_key = details.balance_transfer
        if meta_key == 'Balance Transfer Rate':
            offers = _filter_by_meta(offers, meta_key, 1)  # up to 1%
        elif meta_key == 'Balance Transfer Period':
            offers = _filter_by_meta(offers, meta_key, 12, higher_is_better=True)  # @ least 12 months
        elif meta_key == 'No Interest':
            offers = _filter_by_meta(offers, 'Balance Transfer Rate', 0)  # up to 0%
    elif details.cardtype.slug == 'insurance-credit-cards':
        ithas = lambda o,k: getattr(o.metafield(k), 'bare_value_or_default', '') == 'Yes'
        offers = [o for o in offers if ithas(o, details.insurance)]
    _clear_subcategory(_choices.get(details.cardtype.slug, ''), details)
    details.save()
    return offers

def _clear_subcategory(but_not, details):
    for f in SmartSearch1().fields.keys():
        if f not in ['cardtype', but_not]:
            setattr(details, f, '')

EARNINGS = 1
def _create_result_category(detail, data=None):
    # try to get existing category
    result_cat_slug = 'smart-search-result-%s' % detail.id
    try:
        Category.objects.get(slug=result_cat_slug)
    except Category.DoesNotExist:
        pass  # execute the code below
    else:
        return result_cat_slug
    
    # create new category by copying Smart Search Result
    category = Category.objects.get(slug='smart-search-result')
    old_persite = category.sites.through.objects.get(category=category, site=Site.objects.get_current())
    category.id = None
    category.slug = result_cat_slug
    category.slider = detail.cardtype.slider or EARNINGS
    category.save()
    
    # create persiteoption
    option = category.sites.through(category=category, site=Site.objects.get_current())
    option.category_lead_description = ((detail.lead.first_name or '').title() + old_persite.category_lead_description)
    option.page_title = old_persite.page_title
    option.page_description = old_persite.page_description
    if data is not None and data.get('voucher'):
        option.category_lead_description += "And we've sent you an email with your $50 wine voucher."
    option.save()
    
    # copy metafields
    for persitecategorymeta in detail.cardtype.sorted_meta_fields:
        persitecategorymeta.id = None
        persitecategorymeta.persite = option
        persitecategorymeta.save()
    offers = _search_offers(detail)
    _add_to_category(category, offers, detail.cardtype.id)
    return result_cat_slug


def _save_lead_info(data, data_set, request):
    try:
        referrer = request.META['HTTP_REFERER']
    except KeyError:
        referrer = request.build_absolute_uri()
    lead = save_lead({
            'first_name': data['firstname'],
            'last_name': data['lastname'],
            'ip':        request.META['REMOTE_ADDR'],
            'email':     data['email'],
            'state':     data['state'],
            'source':    referrer})
    try:
        lead.errors
        return lead  # returns LeadForm instance to correct the error
    except AttributeError:
        pass
    search_detail = SearchDetail.objects.create(
                lead=lead,
                balance_transfer=data.get('balance_transfer', ''),
                frequent_flyer=data.get('frequent_flyer', ''),
                rewards=data.get('rewards', ''),
                insurance=data.get('insurance', ''),
                workstatus=data['workstatus'],
                income=data['income'],
                birthday=data['birthday'],
                birthmonth=data['birthmonth'],
                birthyear=data['birthyear'],
                cardtype=Category.objects.get(pk=data['cardtype']),
            )
    # send email containing link to result page
    context = {'details_id': xor_crypt(search_detail.id), 'name': lead.first_name, 'voucher': data.get('voucher')}
    EmailThread(**{'email': lead.email,
                   'subject': 'Your Credit Card Smart Search Results',
                   'template': 'smart-search/email.html',
                   'context': context,
                }).start()
    if data.get('voucher'):
        EmailThread(**{'email': lead.email,
                       'subject': 'Claim your $50 wine voucher now',
                       'template': 'reviews/email.html',
                       'context': context,
                    }).start()
    for bank_data in data_set:
        try:
            category = Category.objects.get(pk=bank_data['bank'])
        except (Category.DoesNotExist, KeyError):
            # no filtering needed for "Other bank"
            # or when bank_data is {} (to replicate, add bank, submit, delete)
            continue
        Bank.objects.create(detail=search_detail, bank=category)
    return search_detail


def _add_to_category(result_category, offer_list, feature_category_id):
    '''Adds offers to the existing "result category", copying
    the sort_order of each offer from the selected Feature Category
    '''
    for offer in offer_list:
        sort_order = offer.offercategory_set.get(
                                category__id=feature_category_id
                         ).sort_order
        try:
            OfferCategory.objects.create(category=result_category,
                                         offer=offer,
                                         sort_order=sort_order)
        except IntegrityError:  # duplicate entry
            pass
