from haystack.indexes import *
from haystack import site

from django.contrib.auth.models import User
from models import Recipe, RecipeManual, Profile, BlogPost

class RecipeIndex(SearchIndex):
    text = CharField(document = True,
                     use_template = True)

class ProfileIndex(SearchIndex):
    text = CharField(document = True,
                     use_template = True)

class BlogPostIndex(SearchIndex):
    text = CharField(document = True,
                     use_template = True)

site.register(Recipe, RecipeIndex)
site.register(Profile, ProfileIndex)
site.register(BlogPost, BlogPostIndex)
