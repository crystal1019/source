import sys
from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.crawler import crawl_hint
from roomhints.models import DefaultHint
from roomhints.views import add_dhint_from_raw
from roomhints.url2png import url2png, url2price
from roomhints.utils import url_encode

class Command(BaseCommand):
    help = 'Crawls a url to retrieve the image, price, and source using visual information (screenshot)'

    def handle(self, *args, **options):
        command = None
        url = None
        for a in args:
            if url == None:
                url = a
        if url == None:
            url = 'http://www.gap.com/browse/product.do?pid=364575&locale=en_US&kwid=1&sem=false&sdReferer=http%3A%2F%2Fwww.google.com%2Furl%3Fsa%3Dt%26rct%3Dj%26q%3Dwide-stripe%2520popover%2520shirt%2520gap%26source%3Dweb%26cd%3D1%26ved%3D0CDIQFjAA%26url%3Dhttp%253A%252F%252Fwww.gap.com%252Fproducts%252Fwide-stripe-popover-shirt-P364575.jsp%26ei%3Df1RaUYaqDrfJ4AOe34DQDw%26usg%3DAFQjCNEl5zYoL_k42ZcLQ7sl6i5OutuOzw%26bvm%3Dbv.44442042%2Cd.dmg'
            url = 'http://www.shopbop.com/studded-mouse-flats-marc-by/vp/v=1/845524441958814.htm'
            url = 'http://m.shopbop.com/studded-mouse-flats-marc-by/vp/v=1/845524441958814.htm'
            url = 'http://www.wayfair.com/Adesso-Eclipse-Floor-Lamp-in-Black-Chrome-6431-01-AE1659.html'
            url = 'http://bananarepublic.gap.com/browse/product.do?vid=1&pid=23311407'
            url = 'http://www.overstock.com/Home-Garden/Mansfield-Beige-Club-Chair/6002296/product.html'
        print(url2price(url))
        print(url_encode(url))

