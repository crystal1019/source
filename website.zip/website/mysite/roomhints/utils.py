import hashlib
from datetime import datetime,timedelta
from django.utils.timezone import utc
import time
import calendar
import random
import subprocess
import urllib
from iospush.models import Device
from django.conf import settings
from django.db import connection, transaction

push_comment_pre = "Designer: "
push_comment_pre = ""
paid_days = 31 # Give them some slack

def push_max():
    # 256 is max size in bytes of a push notification
    return 189 + len(push_comment_pre) # could be 190?

def search_profile_id():
    return 793 # That's Tiff's designer account

def make_unique(length=36):
    seed = "$8$2Mep"
    the_input = ""
    return hashlib.sha512(seed.encode() + "IdG3".encode() + str(datetime.utcnow()).encode() + the_input.encode()).hexdigest()[0:length]

def make_unique_photo():
    return make_unique(36) + ".jpg"

def photo_convert(big,small,pixels):
    increase_dpi = " -depth 300 -units pixelsperinch"
    p = subprocess.Popen("convert " + big + increase_dpi + " -resize " + pixels + "@ -auto-orient " + small, shell=True,
                         stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    response = p.communicate(input=the_input)[0]

def plural(value, text):
    ret = str(value) + " " + text
    if value != 1:
        ret += "s"
    return ret

def seconds_to_age_core(seconds):
    import math
    age = ""
    if seconds >= 1440 * 60:
        age = plural(int(math.ceil(seconds / 1440 / 60)), "day")
        age += " ago"
    elif seconds >= 60 * 60:
        age = plural(int(math.ceil(seconds / 60 / 60)), "hour")
        age += " ago"
    elif seconds >= 1 * 60:
        age = plural(int(math.ceil(seconds / 60)), "minute")
        age += " ago"
    elif seconds > 0:
        age = plural(int(math.ceil(seconds)), "second")
        age += " ago"
    elif seconds > - 1 * 60:
        age = plural(int(math.ceil(-seconds)), "second")
        age += " from now"
    elif seconds > - 60 * 60:
        age = plural(int(math.ceil(-seconds / 60)), "minute")
        age += " from now"
    elif seconds > - 1440 * 60:
        age = plural(int(math.ceil(-seconds / 60 / 60)), "hour")
        age += " from now"
    else:
        age = plural(int(math.ceil(-seconds / 1440 / 60)), "day")
        age += " from now"

    return age

def seconds_to_age(input_datetime):
    #offset = time.timezone if (time.daylight == 0) else time.altzone
    offset = 0
    seconds_now = calendar.timegm(datetime.utcnow().replace(tzinfo=utc).timetuple())
    seconds_old = calendar.timegm(input_datetime.timetuple())
    seconds_diff = seconds_now - seconds_old + offset
    return seconds_to_age_core(seconds_diff)

def minutes_to_age(seconds):
    return seconds_to_age_core(seconds/60)

def random_number(range_min,range_max):
    r = random.random()
    range_diff = range_max - range_min
    number = int(range_min + range_diff * r)
    return number

def random_seconds(range_min,range_max):
    t = datetime.now().replace(tzinfo=utc)
    range_extra = 0
    if t.hour <= 2:
        range_extra += 60 * 60 * 7
    if t.hour <= 3:
        range_extra += 60 * 60 * 6
    elif t.hour <= 6:
        range_extra += 60 * 60 * 5
    elif t.hour <= 7:
        range_extra += 60 * 45 * 1
    elif t.hour <= 9:
        range_extra += 60 * 10 * 1
    elif t.hour <= 18:
        range_extra += 0
    elif t.hour <= 19:
        range_extra += 60 * 10 * 1
    elif t.hour <= 21:
        range_extra += 60 * 20 * 1
    elif t.hour <= 22:
        range_extra += 60 * 60 * 9
    elif t.hour <= 23:
        range_extra += 60 * 60 * 8
    elif t.hour <= 24:
        range_extra += 60 * 60 * 7

    range_extra = 0 # disconnect this for now
    f = open('/tmp/random_seconds', 'ab+')
    f.write(str(datetime.now()) + ' range_extra for ' + str(t.hour ) +' is ' + str(range_extra) + "\n")
    f.close()
    range_min += range_extra
    range_max += range_extra
    return random_number(range_min,range_max)

def random_name():
    names = ["Alex", "Jen", "Sam", "Sarah", "Max", "Jac"]
    rname = random_number(0,len(names))
    return names[rname]

def random_home_quote():
    # [0] is the height in pixels that the quote consumes; [1] is the quote
    home_quotes = [ [ 75, "\"Your surroundings create who you are.\"\n - RoomHints" ],
                    [ 75, "\"The home should be the treasure chest of living.\"\n - Le Corbusier" ],
                    [ 75, "\"Simplicity is the ultimate sophistication.\"\n - Leonardo da Vinci" ],
                    [ 100, "\"Always design a thing by considering it in its next larger context.\"\n - Eero Saarinen" ],
                    [ 75, "\"Pictures deface walls oftener than they decorate them.\"\n - Frank Loyd Wright" ],
                    [ 75, "\"Space and light and order are the things that men need.\"\n - Le Corbusier" ],
                    [ 75, "\"I don't want to be interesting. I want to be good.\"\n - Mies van der Rohe"],
                    #[ 100, "\"I deeply believe that a beautiful decor can have a beneficial influence on our lives\"\n - Albert Hadley"]
                    [ 100, "\"Forget the floor plans. Arrange the furniture where it is the most comfortable and will look best.\"\n - Albert Hadley"],
                    [ 125, "\"Nothing can more quickly reveal aspect of personality and character than the choice - or absence - of color.\"\n - Van Day Truex"],
                    [ 100, "\"Furnish your room for conversation and the chairs will take care of themselves.\"\n - Lady Sibyl Colefax"],
                    [ 100, "\"The most beautiful rooms are those that retain a feeling of not being quite finished.\"\n - Michael Taylor"]
                    ]
    quote = random_number(0,len(home_quotes))
    return home_quotes[quote]
    #return home_quotes[10]

def random_response(custom):
    name = random_name()
    number = random_number(0,7) # It's always up to the last number - 1
    res = ""
    if number == 0:
        res = "Hey! I am " + name + ", a designer with RoomHints. Feel free to ask me any questions just click your room photo and \"chat with designer\" button."
    elif number == 1:
        res = "Hi! I am " + name + ", a designer with RoomHints. Can I help you style this room? Just click your room photo and \"chat with designer\" button. Thanks!"
    elif number == 2:
        res = "Hey! Just wanted to touch base -  is there's anything I can do to help with this room? This is " + name + ", I am a designer on RoomHints."
    elif number == 3:
        res = "Hi! I am here if you need a second opinion picking decor, ideas for your room, or an eye for furniture placement. This is " + name + " from RoomHints."
    elif number == 4:
        res = "Hi, I can offer a second opinion or help find furniture for your room wherever you need me - even at dinner parties! This is " + name + ", a designer on RoomHints. Thanks!"
    elif number == 5:
        res = "I am in your pocket if you need me. I can help find furniture or suggest a new layout  - " + name
    elif number == 6:
        res = "Can I help you find some cool items for your room?"

    return res

def url_encode(url):
    return urllib.quote_plus(url)

def compute_badge_count_core(kind,item_id):
    cursor = connection.cursor()
    sql = "select sum(count) from (select count(*) as count from roomhints_comment c, roomhints_project p where c.project_id = p.id and c.received_seconds is null and c.seconds < now() and c.public = true and c.profile_id != p.profile_id and p.public = true and p." + kind + " = " + str(item_id) + " union select count(*) from roomhints_roomhint rh, roomhints_project p where rh.project_id = p.id and rh.received_seconds is null and rh.seconds < now() and rh.public = true and rh.profile_id != p.profile_id and p.public = true and p." + kind + " = " + str(item_id) + ") comments_and_roomhints"
    f = open('/tmp/badge_count','ab+')
    f.write(sql + "\n")
    cursor.execute(sql)
    count = 0
    for row in cursor.fetchall():
        count = int(row[0])
    cursor.close()
    return count

def compute_badge_count_for_project(project_id):
    return compute_badge_count_core("id",project_id)

def compute_badge_count_for_profile(profile_id):
    return compute_badge_count_core("profile_id",profile_id)

def compute_badge_count_for_comments(project_id):
    cursor = connection.cursor()
    sql = "select count(*) as count from roomhints_comment c, roomhints_project p where c.project_id = p.id and c.received_seconds is null and c.seconds < now() and c.profile_id != p.profile_id and c.public = true and p.public = true and p.id=" + str(project_id)
    cursor.execute(sql)
    count = 0
    for row in cursor.fetchall():
        count = int(row[0])
    cursor.close()
    return count

def push_comments(projuniq):
    # Changed so that push notifications to deleted projects are still sent
    sql = "select up.id,i.device_token,c.content from iospush_device i, roomhints_project p, roomhints_profile up, roomhints_profile upd, roomhints_comment c where up.device_id = i.id and p.profile_id = up.id " #and p.public = true 
    if projuniq != None:
        sql += "and p.projuniq=%s"
    sql += "and c.project_id = p.id and c.profile_id = upd.id and upd.designer = true and i.last_notified_at < c.seconds and c.public = true order by up.id, c.seconds desc"
    cursor = connection.cursor()
    if projuniq != None:
        cursor.execute(sql,[projuniq])
    else:
        cursor.execute(sql)
    for row in cursor.fetchall():
        up_id = row[0]
        d_token = row[1]
        content = row[2]
        msg = push_comment_pre + content
        badge_count = compute_badge_count_for_profile(up_id)
        device_send(d_token,msg,badge_count)
    cursor.close()

def device_send(device_token,msg,badge=None):
    d = Device.objects.filter(device_token=device_token).get()
    d.last_notified_at = datetime.utcnow().replace(tzinfo=utc)
    print (msg + " (badge " + str(badge) + ")")
    if badge != None:
        d.send_message(msg,badge=badge)
    else:
        d.send_message(msg)
    d.save()

def custom_core(custom,index):
    if custom != None:
        all = custom.split(", ")
        if len(all) > 1:
            return all[index]
        else:
            return custom
    else:
        return ""

def custom_last(custom):
    return custom_core(custom,-1)

def custom_first(custom):
    return custom_core(custom,0)
