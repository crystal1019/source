Datafly = {}

Datafly.slider = function() {
    var active = $('.slider li.active'),
        next = active.next('li');
    if (!next.length) next = $('.slider li:first-child');
    active.removeClass('active').css('opacity', 0);
    next.addClass('active').css('opacity', 1);
    setTimeout(Datafly.slider, 5000)
}

$(document).ready(function() {

    setTimeout(Datafly.slider, 5000);

    $('.nav-collapse').click(function(event){
        event.preventDefault();
        $('.top-nav').slideToggle();
    })

    $('#contactForm').submit(function(event) {
        event.preventDefault();
        $('html, body').animate({scrollTop:'140px'}, 'slow');
        $.post('/send', $(this).serialize())
        $('.headline h2, .headline p').hide('slow');
        setTimeout(function(){
            $('.headline h2').text('Thank you');
            $('.headline p').text('Your message has been sent.');
            $('.headline h2, .headline p').show('fast');
        }, 500)
        this.reset();
    });

});