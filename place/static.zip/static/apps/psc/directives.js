angular.module('psc.directives', [])
    .directive('uniqueemail', ["$http", "$timeout",
        function($http, $timeout) {
            var toId;
            return {
                restrict: 'A',
                require: 'ngModel',
                link: function(scope, elem, attr, ctrl) {
                    //when the scope changes, check the email.
                    scope.$watch(attr.ngModel, function(value, old_v) {
                        if (value && !ctrl.$error.email) {
                            // if there was a previous attempt, stop it.
                            if (toId) clearTimeout(toId);

                            // start a new attempt with a delay to keep it from
                            // getting too "chatty".
                            toId = $timeout(function() {
                                $http({
                                    method: 'GET',
                                    url: '/psc/admin/team/validate_invite/',
                                    params: {
                                        'id': scope.TeamData.psc_client,
                                        'email': value
                                    },
                                    cache: false
                                }).success(function(obj) {
                                    ctrl.$setValidity('uniqueemail', obj.success);
                                    if (!scope.$$phase) {
                                        scope.$apply(ctrl.$error);
                                    }
                                }).error(function(data, status) {
                                    ctrl.$setValidity('uniqueemail', false);
                                });
                            }, 200);
                        } else {
                            ctrl.$setValidity('uniqueemail', true);
                        }
                    });
                }
            }
        }
    ])
    .directive('toggle', [

        function() {
            return function(scope, elem, attrs) {
                scope.$on('event:toggle', function(env, elem_uid) {
                    if (attrs.toggle === elem_uid) {
                        elem.collapse('toggle');
                    }
                });
            };
        }
    ]);