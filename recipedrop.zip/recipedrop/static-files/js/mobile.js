
var swipe_tags = function () {
    $( document ).on( "swipeleft swiperight", $.mobile.activePage, function( e ) {
        if ( $.mobile.activePage.jqmData( "panel" ) !== "open" ) {
            if ( e.type === "swiperight" ) {
                $.mobile.activePage.find("#tags-panel" ).panel( "open" );
            }
        }
    });
};

var load_more = function() {
    var serviceURL = "/mobile/recipes/loadmore/";
    var offset = 12;
    var csrfmiddlewaretoken = $('input[name=csrfmiddlewaretoken]').val();


    $.mobile.activePage.find(".loadmore").on("click", function() {
        $.ajax({
          type: "post",
          beforeSend: function() { $.mobile.loading( 'show' ) },
          complete: function() { $.mobile.loading( 'hide' ) },
          async: "true",
          dataType: 'json',
          url: serviceURL,
          data: {offset: offset, csrfmiddlewaretoken: csrfmiddlewaretoken},
          success: function(data) {
            if (data) {
                var list = '';
                console.log(data);
                offset+=12;
                $.each(data, function(key, value) {
                  list += '<li><a href="/mobile/recipe/'+value.id+'" class="preview">'+
                                  '<div class="img" style="background-image: url('+value.one_photo+')"></div>'+
                              '</a>'+
                              '<h3><a href="/mobile/recipe/'+value.id+'">'+value.title+'</a></h3>'+
                          '</li>';
                });

                $.mobile.activePage.find("[data-loadmore='true']").append(list);
                console.log($.mobile.activePage.find("[data-loadmore='true']"));
            }
          }
        });
    });
};

$(document).on( "pageshow", function() {
    load_more();
});

$( document ).on( "pageinit", function() {
    swipe_tags();
});
