

function ImageManagerCtrl($scope, $http) {
    $scope.topic = data.topic;
    $scope.images = [];
    $scope.uploader = null;
    $scope.multifile = false;
    $scope.topic = data.topic; // data is a global variable
    $scope.type = 'view';  // view or editor
    $scope.jcrop_api = null;
    $scope.crop_size = null;
    $scope.viewports = {
        'org_logo': [220, 105],
        'hero': [700, 300]
    };

    $http({
        method: 'GET',
        url: '/assets/topic_images/',
        params: {'topic': $scope.topic}
    }).success(function(obj) {
        $scope.images = obj.data.images;
    });

    $scope.select = function(image) {
        if ($scope.multifile) {
            image.is_selected = !image.is_selected;
        }
        else {
            $scope.type = 'editor';
            $scope.selected_image = image;
        }
    };

    $scope.back = function () {
        $scope.type = 'view';
        $scope.selected_image = null;
        $scope.crop_size = null;
        $scope.jcrop_api.destroy();
    };

    $scope.crop = function() {
        post_params = {
            'topic': data.topic,
            'id': $scope.selected_image['id'],
            'output_width': $scope.image_sizes.org_logo[0],
            'output_height': $scope.image_sizes.org_logo[1]
        };
        utils.apply(post_params, $scope.crop_size);
        $http({
            method: 'POST',
            url: '/assets/crop/',
            data: $.param(post_params)
        }).success(function(obj) {
            if(obj.success) {
                $scope.edata.store.contact_info.org_logo = obj.data.image;
                $scope.hide();
            }
            else {

            }
        }).error(function(jqXHR, textStatus, errorThrown) {
        });
    };
}