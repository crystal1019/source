import json
import opengraph
import re
import pprint
import logging

from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions
from lxml.html import fromstring, tostring

logger = logging.getLogger('scraper')


def get_all_text(t):
    tl = t.xpath('.//text()')
    if isinstance(tl, list):
        return "".join(tl).strip()
    return tl

class SperryScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'sperrytopsider.com'

    # def fetch_url(self):
    #     with open('data.html', 'r') as f:
    #         self.html = f.read()

    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ""
        tl = lxml.getroottree().xpath('.//script[contains(.,"var skuId")]/text()')
        prog = re.compile(r'var skuId = \'(.*)\';\s+var productId', re.M + re.S + re.I)
        skus = prog.findall("".join(tl))
        if skus:
                sku = unicode(skus[0])

        title = raw_data['title']

        # Product price
        # 1st - special price
        product_current_price = None
        product_standard_price = None
        strike_price = lxml.xpath('.//div[@id="pricing"]/strike/del/text()')
        strong_price = lxml.xpath('.//div[@id="pricing"]/span[@class="sale"]/text()')

        if strike_price and strong_price:
            text_price = "".join(strike_price).strip()
            prices = re.findall(r'\$(\d+)', text_price)
            product_standard_price = float(prices[len(prices) - 1])

            text_price = "".join(strong_price).strip()
            prices = re.findall(r'\$(\d+)', text_price)
            product_current_price = float(prices[len(prices) - 1])

        else:
            product_current_price = ""
            price = ""
            t = lxml.xpath('.//div[@id="pricing"]/text()')
            if len(t) > 0:
                text_price = "".join(t).strip()
                prices = re.findall(r'\$(\d+)', text_price)
                product_current_price = float(prices[len(prices) - 1])
            else:
                logger.debug('Price nof found')
        #print "price curr=",product_current_price,"standard=",product_standard_price

        promo = lxml.xpath('.//div[@id="sku_promotional_message_id"]/p[@id="promotional-message"]/text()')
        promo = [x.strip() for x in promo]

        colors =[]
        colors = lxml.xpath('.//select[@id="colors"]/option/text()')

        sizes = []
        sizes = lxml.xpath('.//select[@id="size"]/option/text()')
        sizes = [x for x in sizes if not x=="Size"]

        widths = lxml.xpath('.//select[@id="width"]/option/text()')
        widths = [x for x in widths if not x=="Width"]

        image = lxml.xpath('.//a[@class="MagicZoom"]/@href')

        images = []
        images = lxml.xpath('.//div[@id="alternate-view"]/ul/li/a/@href')
        #print images

        selections = []
        data_url = raw_data.get('url', '')
        data_store = raw_data.get('site_name', '')
        #data_image = raw_data.get('image', '')
        data_image = image

        if data_image == '':
            images.reverse()
            data_image = images.pop()
            images.reverse()
        for color in colors:
            for size in sizes:
                if not widths:
                    data = {'title': title,
                            'current_price': {
                                'value': product_current_price
                                },
                            'url': data_url,
                            'store': data_store,
                            'image': data_image,
                            'images': images,
                            'local_id': sku,
                            'selections': {
                                 'size': size,
                                 'color': color,
                                 },
                            'promos': promo
                        }
                    if product_standard_price:
                        data['original_price'] = {'value': product_standard_price}
                    selections.append(data)

                for width in widths:
                    data = {'title': title,
                            'current_price': {
                                'value': product_current_price
                                },
                            'url': data_url,
                            'store': data_store,
                            'image': data_image,
                            'images': images,
                            'local_id': sku,
                            'selections': {
                                 'size': size,
                                 'color': color,
                                 'width': width,
                                 },
                            'promos': []
                        }
                    if product_standard_price:
                        data['original_price'] = {'value': product_standard_price}
                        #data['sold_out'] = True
                    selections.append(data)
        return selections

    def parse_multi_product(self, lxml, raw_data):
        tl = lxml.xpath('.//div[@id="body"]')
        #print "multi=",len(tl)
        selections = []
        for te in tl:
            sel = self.parse_single_product(te, raw_data)
            selections.extend(sel)
        return selections

    def parse(self):
        logger.debug('%s parse started' % SperryScraper.get_domain())
        og = opengraph.OpenGraph(html=self.html)
        raw_data = dict([(k, v) for k, v in og.items()])

        lxml = fromstring(self.html)
        selections = self.parse_multi_product(lxml, raw_data)
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(SperryScraper.get_domain(), self.url)

        return selections

if __name__ == '__main__':
    s = SperryScraper()
    s.fetch_url()
    pprint.pprint(s.parse())
