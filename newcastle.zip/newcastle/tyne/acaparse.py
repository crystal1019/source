'''
Created on Sep 18, 2014

@author: norm
'''

import sys

def getNextLine(infile):
	l = ''
	prevTell = -1
	while not len(l) and not infile.tell() == prevTell:
		prevTell = infile.tell()
		l = infile.readline()
		l = l.replace('map and directions', '')
		l = l.replace('Show details', '')
		l = l.replace('Phone:','')
		l = l.strip()

	
	#print(infile.tell())
	return l


if __name__ == '__main__':

	if len(sys.argv) < 3:
		print("Usage: python acaparse [input file] [output file]")
		print(
	'''
Before using this script:
	* scrape the data to a file
	* delete all occurrences of "map and directions"
	* replace "Label:[line end]" with just "Label:" where label is Phone:, Address:, Location:, Web:, Email:
'''
				)
		sys.exit(1)
		
	inFilename = sys.argv[1]
	outFilename = sys.argv[2]
	infile = open(inFilename)
	outfile = open(outFilename, 'w')

	outfile.write('name' +'\t' + 'location'  + '\t' + 'address' +'\t' + 'email'  +'\t' + 'web'+'\t' + 'main' +'\t' + 'tollfree' +'\t' + 'espanol' + '\n')
	
	record = {}
	record['address'] = ''
	record['email'] = ''
	record['web'] = ''
	record['location'] = ''
	record['main'] = ''
	record['tollfree'] = ''
	record['espanol'] = ''
	record['name'] = ''

	line = 'START'
	while line:
		line = getNextLine(infile)
		
		if line.startswith('Address:'):
			line = line.replace('Address:','')
			line = getNextLine(infile)
			record['address'] = line
		elif line.startswith('Email:'):
			line = line.replace('Email:','')
			line = getNextLine(infile)
			record['email'] = line
		elif line.startswith('Web:'):
			line = line.replace('Web:','')
			line = getNextLine(infile)
			record['web'] = line
		elif line.startswith('Location:'):
			line = line.replace('Location:','')
			line = getNextLine(infile)
			record['location'] = line
		elif line.lower().endswith('(main)'):
			line = line.replace('(main)','')
			line = line.replace('(MAIN)','')
			record['main'] = line
		elif line.lower().endswith('(toll-free)'):
			line = line.replace('(toll-free)','')
			record['tollfree'] = line
		elif line.lower().endswith('(español)'):
			line = line.replace('(Español)','')
			record['espanol'] = line
		else:
			ll = record['name']	+'\t' + record['location']  +'\t' + record['address'] +'\t' + record['email']  +'\t' + record['web'] +'\t' + record['main'] +'\t' + record['tollfree'] +'\t' + record['espanol']
			if len(ll.strip()):
				outfile.write(ll + '\n')
			record = {}
			record['address'] = ''
			record['email'] = ''
			record['web'] = ''
			record['location'] = ''
			record['main'] = ''
			record['tollfree'] = ''
			record['espanol'] = ''
			record['name'] = line
			#print(line)
	
	ll = record['address'] +'\t' + record['email']  +'\t' + record['web'] +'\t' +  record['location'] +'\t' + record['main'] +'\t' + record['tollfree'] +'\t' + record['espanol'] +'\t' + record['name']

	outfile.write(ll + '\n')
