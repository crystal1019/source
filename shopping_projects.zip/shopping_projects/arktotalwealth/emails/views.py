from django.template import loader, RequestContext
from django.http import HttpResponse, HttpResponseRedirect
from arktotalwealth.emails.models import *
from django.core.validators import email_re
from arktotalwealth import common

def is_valid_email(email):
    return True if email_re.match(email) else False


def sendmail(request):
    t = loader.get_template('admin/emails/subscription/sendmail.html')
    ids = request.GET.get('ids',None)
    ids = ids.split(',')
    selected = Subscription.objects.filter(id__in = ids)
    result_headers = ['email name','send already']
    results = Email.objects.all()
    select_headers = ['email address', 'wholesale']
    emails = []
    rp = request.POST.copy()
    message = ''
    if rp:
        emails = rp.getlist('emails')
        emails = Email.objects.filter(id__in=emails)
        for x in emails:
            x.sendmail(subscribe=selected)
            x.send=True
            x.save()

        message = 'You have sent %s mails to %s email addresses' %(len(emails), len(ids))
        
    c = RequestContext(request,{'result_headers':result_headers, 'results':results,'selected':selected,'select_headers':select_headers,'message':message})
    return HttpResponse(t.render(c))


def viewemail(request,id):
    t = loader.get_template('admin/emails/email/viewemail.html')
    
    email = Email.objects.get(id=id)
    
    c = RequestContext(request,{'email':email})
    return HttpResponse(t.render(c))

def readnotification(request):
    rp = request.GET.copy()
    id = rp.get('id',0)
    email = rp.get('email',0)
    es = EmailStatus.objects.filter(subscribe__id=id, email__id=email)
    if es:
        es = es[0]
        es.read = True
        es.save()
    return HttpResponseRedirect('/media/assets/right.png')

def unsubscribe(request):

    rp = request.GET.copy()
    email = rp.get('email',0)
    csrf = rp.get('csrf','')
    public_key = encrypt_key(email)
    if csrf == public_key:
        
        s = Subscription.objects.filter(id=email)
        if s:
            s = s[0]
            s.delete()

        return HttpResponse(str('Thank you! You have been unsubscribed. '))
    
    return HttpResponse(str('Sorry, your unsubscribe is unsuccessful. Please try again later'))

def subscribe(request):
    data = {}
    if is_valid_email(request.GET.get("email")):
        created = Subscription.objects.filter(email=request.GET.get("email"))
        if not created:
            data["error"] = 0
            data["message"] = ""
            receivers = EmailReceiver.objects.exclude(type='enquiry')
            receivers = [x.email for x in receivers]
            common.sendEmail(settings.EMAIL_FROM,receivers,'New Subscriber', 'email_subscribe.html', context=request.GET.get("email"))
                           
        else:
            data["error"] = 1
            data["message"] = "There was an error, perhaps you're already subscribed?"
    else:
        data["error"] = 1
        data["message"] = "Please use a valid email address"
    return HttpResponse(str(data))

