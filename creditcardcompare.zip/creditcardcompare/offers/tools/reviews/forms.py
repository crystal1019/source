from django import forms
from django.forms.models import inlineformset_factory
from django.template.defaultfilters import wordcount
from recaptcha.client import captcha

from offers.core.models import Offer
from models import CardReview, CardSurvey, Survey
from widgets import HorizRadioSelect


class CardReviewForm(forms.ModelForm):
    card = forms.CharField(max_length=256, widget=forms.TextInput(attrs = {'class': 'smartrowinput fn1semibold fsmenu input-xxlarge', 'placeholder': 'Start typing the name of your card here'}))
    
    class Meta:
        model = CardReview
        exclude = ('ratings', 'voucher')
        
    def __init__(self, *args, **kwargs):
        super(CardReviewForm, self).__init__(*args, **kwargs)
        self.fields['title'].widget.attrs = {'class': 'input span7'}
        self.fields['title'].error_messages['max_length'] = 'Please shorten your title to under %(limit_value)d characters (it has %(show_value)d).'
        self.fields['pros'].widget.attrs = {'class': 'input span7'}
        self.fields['cons'].widget.attrs = {'class': 'input span7'}
        self.fields['name'].widget.attrs = {'class': 'input span4'}
        self.fields['email'].widget.attrs = {'class': 'input span4'}
        self.fields['comment'].widget.attrs = {'cols': '30', 'rows': '3', 'class': 'span7'}
        self.fields['recommend'].widget = HorizRadioSelect(choices=(('yes','Yes'),('no','No')))
    
    def clean_comment(self):
        if wordcount(self.cleaned_data['comment']) < 50:
            raise forms.ValidationError("You entered less than 50 words.")
        return self.cleaned_data['comment']
    
    def clean_card(self):
        card = self.cleaned_data['card']
        try:
            card = Offer.objects.get(title=card)
        except Offer.DoesNotExist:
            raise forms.ValidationError(u'Please select your card from the dropdown list.')
        except Offer.MultipleObjectsReturned:
            pass
        return card
    
    def clean_recommend(self):
        value = {'no': False, 'yes': True}.get(self.data.get('recommend'), None)
        if value is None:
            raise forms.ValidationError(u'Please select your choice.')
        return value
    
class BaseRatingFormset(forms.models.BaseInlineFormSet):
    def clean(self):
        for rate in self.cleaned_data:
            non_zero = rate.get('rating', 0)!=0
            if non_zero:
                return self.cleaned_data
        raise forms.ValidationError("Please click stars to add your rating!")
        
RatingFormSet = inlineformset_factory(CardReview, CardSurvey, exclude=(), can_delete=False, extra=Survey.objects.count(), formset=BaseRatingFormset)
