import logging
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class IkeaScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'ikea.com'

    def clean_title(self, title):
        return title.replace('\t', '').replace('\n', '').replace('\r', '')

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        selections = []

        title = soup.find('div', class_='productName')
        if title is None:
            logger.critical('Was not able to extract title')
            raise HukksterTooManyOptions(IkeaScraper.get_domain(), self.url)
        title = self.clean_title(title.text)

        sku = soup.find('div', attrs={'id': 'itemNumber'})
        if sku is None:
            logger.critical('Was not able to extract SKU')
            raise HukksterTooManyOptions(IkeaScraper.get_domain(), self.url)
        sku = sku.text.strip()

        price = soup.find('span', class_='packagePrice')
        if price is None:
            logger.critical('Was not able to extract price')
            raise HukksterTooManyOptions(IkeaScraper.get_domain(), self.url)
        price = float(price.text.replace('$', ''))

        data = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': raw_data['url'],
            'store': raw_data['site_name'].lower(),
            'image': raw_data['image'],
            'local_id': sku,
            'promos':[]
        }
        selections.append(data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(IkeaScraper.get_domain(), self.url)

        return selections

