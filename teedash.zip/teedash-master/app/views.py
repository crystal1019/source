from app import app
from app import db
import mechanize_boilerplate
import urllib
import os
from flask import Flask, render_template, request
from BeautifulSoup import BeautifulSoup
from flask.ext.basicauth import BasicAuth
from datetime import date, timedelta

app.config['BASIC_AUTH_USERNAME'] = 'amalbe'
app.config['BASIC_AUTH_PASSWORD'] = 'baguette'

basic_auth = BasicAuth(app)

class Campaign(db.Model):
    id = db.Column(db.Integer, autoincrement=True)
    key = db.Column(db.String(80), primary_key=True)
    name = db.Column(db.String(100))
    spent = db.Column(db.Float)
    sold = db.Column(db.Integer)
    margin = db.Column(db.Float)
    CPA = db.Column(db.Float)
    URL = db.Column(db.String(120))
    enddate = db.Column(db.DateTime)
    status = db.Column(db.String(80))

    def __init__(self, key, name, spent, sold, margin, CPA, URL, enddate, status):
        self.key = key
        self.name = name
        self.spent = spent
        self.sold = sold
        self.margin = margin
        self.CPA = CPA
        self.URL = URL
        self.enddate = enddate
        self.status = status

    def __repr__(self):
        return '<Name %r>' % self.name

br = mechanize_boilerplate.br

@app.route('/')
def hello():
    return 'Hello World!'

@app.route('/home')
@basic_auth.required
def home():
    return render_template('index.html')

@app.route('/db')
def dbtest():
    
    try:
        db.create_all()
    except Exception as e:
        f = open('/tmp/error.log', 'w')
        print e.message
        f.write(e.message)
        f.close()
    return 'done'


@app.route('/sales')
def sales():
    ### PULL FACEBOOK DATA

    adDashURL = 'https://www.facebook.com/ads/manage/home/?account_id=1380050932281716'

    #open FB admin dash
    admin_url = 'https://www.facebook.com/advertising'
    br.open(admin_url)

    #Check if logged in
    checker = None
    for form in br.forms():
        if form.attrs['id'] == 'login_form':
            br.form = form
            checker = True
            print 'checker = True'
            break

    #If only one form -> Login
    if checker:
        print 'logging in...'
        USERNAME = 'jayspring85@gmail.com'
        PASSWORD = 'springmonies'
        br.form['email'] = USERNAME
        br.form['pass'] = PASSWORD
        br.submit()
    print 'submiting...'

    print 'Logged in'

    br.open(adDashURL)

    html = br.response().read()
    print 'launching soup'
    soup = BeautifulSoup(html)
    
    table = soup.find("table", { "class" : "uiDataTable _15j9" })

    fb_dicts = []

    #SELECT RELEVANT COLUMNS ONLY
    for row in table.tbody.findAll('tr'):

        #print row
        status = row.findAll('td')[3].find('div').find('div').find('span').find('span').string
        status = str(status)

        if status == 'Inactive':
            continue

        camp_id = row.findAll('td')[2].find('div').find('div').find('div').find('a').find('span').string

        # Handle if user is using vendor tags. E.g.: [TS] for Teespring
        if camp_id[0] == '[' and camp_id[3] == ']':
            vendor = camp_id[1:3]
            print vendor
            # Get campaign ID past vendor tag
            camp_id = camp_id[4:].replace(" ", "")
            print camp_id
        else:
            # Default to TeeSpring
            vendor = 'TS'

        # Handle Ongoing campaigns vs. timed campaigns
        try:
            spent = row.findAll('td')[8].find('div').find("span", { "class" : "fsm" }).string
            spent = float(str(spent).replace("$", ""))
            print spent
        except:
            spent = row.findAll('td')[8].find('div').findAll('div')[0].find('span').findAll('span')[0].find('div').findAll('div')[0].findAll('span')[0].string
            spent = float(str(spent).replace("$", ""))
        
        # Get campaign data from vendor
        if vendor == 'TS':
            camp_url = 'http://teespring.com/' + camp_id
        
            print ('opening campaign URL')
            print camp_url
    
            br.open(camp_url)
            html = br.response().read()
            soup = BeautifulSoup(html)
            try:
                sales = soup.findAll("span", { "class" : "amount-ordered" })[0].string
            except:
                print 'cant find sales'
                sales = '0'

            try:
                name = soup.findAll("h1", { "class" : "clean" })[0].string
            except:
                print 'name error'
                name = '0'

            try:
                enddate = soup.find("div", { "class" : "time-left" })
                enddate = enddate['title'][:10]
            except:
                print 'cant find enddate'
                enddate = '0'

        elif vendor == 'VS':
            camp_url = 'https://viralstyle.com/public21/' + camp_id
            print ('opening campaign URL')
            print camp_url
    
            br.open(camp_url)
            html = br.response().read()
            soup = BeautifulSoup(html)
            try:
                sales = soup.find("span", { "class" : "inside-count hidden-xs" }).string
                sales = sales[:2]
            except:
                print 'cant find sales'
                sales = '0'

            try:
                name = soup.find("h1").string
            except:
                print 'name error'
                name = '0'

            try:
                enddate = soup.find("section", { "class" : "desc" }).string
                enddate = enddate[:2].replace(" ", "")
                enddate = int(enddate)
                enddate = date.today()+timedelta(days=enddate)
            except:
                print 'cant find enddate'
                enddate = '0'


        fb_dict = {}

        #Name
        fb_dict['ID'] = camp_id
        
        #Spent
        fb_dict['spent'] = spent

        #Sales
        fb_dict['sales'] = sales
        fb_dict['name'] = name
        fb_dict['enddate'] = enddate
        fb_dict['URL'] = camp_url

        #Calculate CPA
        sold_int = int(str(sales))
        if sold_int > 0 and spent > 0:
            cpa_int = float('%.2f'%(spent/sold_int))
        else:
            cpa_int = '0'

        try:
            campaign = Campaign(camp_id, name, spent, sales, '9', cpa_int, camp_url, enddate, 'Active')
            # Schema: key, name, spent, sold, margin, CPA, URL, enddate, status
            db.session.merge(campaign)
            db.session.commit()
        except Exception as e:
            #db.session.rollback()
            print 'DB error'
            print 'error is:' + e.message
        # finally:
        #     db.session.close()

        fb_dicts.append(fb_dict)
        #print first_column, second_column, third_column, fourth_column, fifth_column, link
    print fb_dicts

    ### CREATE HTML TABLE

    final_table = "<table id='salestable' class='table table-hover table-bordered'><thead><tr><th>Name</th><th>URL</th><th>Spent</th><th>Sold</th><th>CPA</th><th>Status</th><th>End Date</th></tr></thead><tbody>"

    for x in fb_dicts:

        endrow = "</td><td>"

        row = "<tr><td>"
        # if x.has_key('ID'):
        #     row += str(x['ID'])
        # row += endrow
        if x.has_key('name'):
            row += str(x['name'])
        row += endrow
        if x.has_key('URL'):
            row += "<a href='" + str(x['URL']) + "' target='_blank'>" + str(x['URL']) + "</a>"
        row += endrow
        if x.has_key('spent'):
            spent_int = float(str(x['spent']).replace("$", ""))
            row += str(x['spent'])
        row += endrow
        if x.has_key('sales'):
            row += str(x['sales'])
            #Calculate CPA
            sold_int = int(str(x['sales']))
        row += endrow
        if sold_int > 0 and spent_int > 0:
            cpa_int = float('%.2f'%(spent_int/sold_int))
            cpa_class = ''
            if cpa_int > 8:
                cpa_class = '<div class="icon-alert" style="color: #F7483B; margin: 0 8px;line-height: normal;">' + str(cpa_int) + '<span class="hide">High CPA</span></div>'
            else:
                cpa_class = str(cpa_int)
            row += cpa_class
        row += endrow
        row += "<span class='hide'>Pause</span></a><a class='icon-edit status-edit' href='https://www.facebook.com/ads/manage/home/' target='_blank'>Edit</a><a href='#' class='icon-play status-pause'>"
        row += endrow
        if x.has_key('enddate'):
            row += str(x['enddate'])
        row += "</td></tr>"


        final_table += row
    final_table += "</tbody></table>"


    return render_template("dash.html",
        table = final_table)
