var map
var dot = new google.maps.MarkerImage('/static/img/green_dot.png', new google.maps.Size(9, 9), new google.maps.Point(0,0), new google.maps.Point(5, 5));
var bounds = new google.maps.LatLngBounds()
var numUsers = 0
var currentTimestamp
var RUNNING
var users


function LL(lat, lng) {
    return new google.maps.LatLng(lat, lng);
}


function debug(msg) {
    document.getElementById('messages').innerHTML += msg + "<br>";
}


function go(){
    var latlng = new google.maps.LatLng(49.2,-122.85);
    var myOptions = {
        zoom: 11,
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById("map"), myOptions);
    //google.maps.event.addListenerOnce(map, "tilesloaded", userCount());
    userCount()
    
}


function userCount(){
    url = "/user-json/"
    
    $.ajax({
        type:"GET",
        url: url,
        dataType:"JSON",
        crossDomain:true,
        success: function(data){
            users = data.data.users
            var g = 0
            for(var j=0; j<=users.length-1; j++){   
                if (users[j].created == 1317939581000){
                    users[j].created = users[j].created + (60*60*1000*g);
                    g++;
                }
                users[j].point = new google.maps.LatLng(users[j].lat, users[j].long);
                users[j].radius = 2000;
                users[j].dot = new google.maps.Marker({position: users[j].point, icon: dot, map: null});
                users[j].circle = new google.maps.Circle({radius: 2000, center: users[j].point, fillColor: "#ADDDB0", strokeWeight: 0, fillOpacity: 0.6, strokeOpacity: 1.0, zIndex: j, map: null});
                
            }
            $("#play").toggleClass('disabled', false)
            $("#loading").toggle()
        }
    })
} 


function getStartTime() {
    return users[0].created;
}


function startAnimation(zoom) {
    if (RUNNING){
        RUNNING = false;
        return;
    };
    currentTimestamp = getStartTime();
    STARTTIMESTAMP = currentTimestamp;
    ENDTIMESTAMP = Math.round(new Date().getTime());
    numUsers = 0
    for(var i=0;i<users.length;i++) {
        document.getElementById('users').innerHTML = numUsers;
        users[i].dot.setMap(null)
        users[i].opacity = 1;
        users[i].displayed = false;
        users[i].skipped = false;
    }
    play();

}

function play(){
    RUNNING = true
    currentTimestamp+=8640000;
    for(var i=0;i<users.length;i++) {
        if(users[i].created < currentTimestamp) {
            if(!users[i].displayed) {
                users[i].displayed=true;
                numUsers++;
                document.getElementById('users').innerHTML = numUsers;
                users[i].dot.setMap(map);
                users[i].circle.setRadius(users[i].radius*(Math.pow(2,10-map.getZoom())));
                users[i].circle.setMap(map);
                window.setTimeout('fadeCircle('+i+')',100);
            }
        }
    }
    if(RUNNING) {
        if(currentTimestamp < ENDTIMESTAMP) {
            window.setTimeout(play, 0.5);
        } else {
            COMPLETE = true;
            RUNNING = false;
        }
    }
}

function fadeCircle(i) {
    if(!RUNNING) return;
    users[i].opacity -= 0.1;
    if(users[i].opacity <= 0.2) {
        users[i].circle.setMap(null);
    } else {
        users[i].circle.setOptions({fillOpacity: users[i].opacity*0.6, strokeOpacity: users[i].opacity});
        window.setTimeout('fadeCircle('+i+')',100);
    }
}
