import json
import opengraph
import re
import pprint
import logging
from urlparse import urljoin

from lxml.html import fromstring, tostring
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions

logger = logging.getLogger('scraper')


def get_all_text(t):
    tl = t.xpath('.//text()')
    if isinstance(tl, list):
        return "".join(tl).strip()
    return tl


class BhldnScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'bhldn.com'

    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ''
        skus = lxml.xpath('.//p[@class="fsid"]/text()')
        if skus:
                sku = skus[0]
        sku = sku.replace('Style:', '')
        if sku == '':
                return []

        title = lxml.xpath('.//h2[@class="productname"]/text()')
        if title:
            title = title[0]
        title = raw_data.get('title', '')

        product_current_price = None
        product_original_price = None

        pl = lxml.xpath('.//div[@class="prices"]/div[@class="price"]/span/text()')
        if pl:
            ptext = pl[0]
            if ptext:
                ptext = ptext.strip()
                prices = re.findall(r'\$(\d+,\d+)', ptext)
                if not prices:
                    prices = re.findall(r'\$(\d+)', ptext)

                ptext = prices[len(prices) - 1]
                ptext = ptext.replace(",", "")
                #print "ptext=",ptext
                product_current_price = float(ptext)
        else:
            pl = lxml.xpath('.//div[@class="prices"]/div[@class="price price-sale"]/span/text()')
            ptext = pl[0].strip()
            prices = re.findall(r'\$(\d+,\d+)', ptext)
            if not prices:
                prices = re.findall(r'\$(\d+)', ptext)

            ptext = prices[len(prices) - 1]
            ptext = ptext.replace(",", "")
            product_current_price = float(ptext)

            po = lxml.xpath('.//div[@class="prices"]/div[@class="price price-original"]/del/text()')
            ptext = po[0].strip()
            prices = re.findall(r'\$(\d+,\d+)', ptext)
            if not prices:
                prices = re.findall(r'\$(\d+)', ptext)

            ptext = prices[len(prices) - 1]
            ptext = ptext.replace(",", "")
            product_original_price = float(ptext)

        colors = lxml.xpath('.//li[contains(@class,"color-options")]/div/div/select/option/text()')
        colors = [x.strip() for x in colors if not x == "Select Color"]

        sizes = lxml.xpath('.//li[contains(@class,"size-options")]/div/div/select/option/text()')
        sizes = [x.strip() for x in sizes if not x == "Select Size"]

        images = lxml.getroottree().xpath('.//div[@class="alternates"]/ul/li/a/@href')
        if images:
            images.reverse()
            image = images.pop()
            images.reverse()

        selections = []
        data_url = raw_data.get('url', '')
        data_store = raw_data.get('site_name', '')

        if not colors:
            colors = ['Empty']
        if not sizes:
            sizes = ['Empty']

        for color in colors:
            for size in sizes:
                data = {'title': title,
                        'current_price': {
                            'value': product_current_price
                            },
                        'url': data_url,
                        'store': data_store,
                        'image': image,
                        'images': images,
                        'local_id': sku,
                        'selections': {
                            'size': size,
                            'color': color,
                            },
                        'promos': []
                        }
                if color == 'Empty':
                    data['selections'] = {'size': size}
                if size == 'Empty':
                    data['selections'] = {'color': color}

                if product_original_price:
                    data['original_price'] = {'value': product_original_price}
                selections.append(data)
        return selections

    def parse_multi_product(self, lxml, raw_data):
        tl = lxml.xpath('.//div[@id="content"]')
        if len(tl) == 1:
            return(self.parse_single_product(tl[0], raw_data))

        tl = lxml.xpath('.//div[@class="productsetdetail"]/div[@class="productdetailcolumn productinfo"]')
        selections = []
        for te in tl:
            sel = self.parse_single_product(te, raw_data)
            selections.extend(sel)
        return selections

    def parse(self):
        logger.debug('%s parse started' % BhldnScraper.get_domain())
        og = opengraph.OpenGraph(html=self.html)
        raw_data = dict([(k, v) for k, v in og.items()])
        #pprint.pprint(raw_data)
        if not self.html:
            raise HukksterTooManyOptions(BhldnScraper.get_domain(), self.url)

        lxml = fromstring(self.html)
        selections = self.parse_multi_product(lxml, raw_data)
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(BhldnScraper.get_domain(), self.url)
        return selections

if __name__ == '__main__':
    s = BhldnScraper()
    s.fetch_url()
    print "Result=",
    pprint.pprint(s.parse())
