/**
 * Created by Gerard Sławiński on 26.02.14.
 * @milosolutions
 */

var menuTop = 64; // mainmenu's original height is hardcoded to 64 because with display: none, it returns 0
var messageHeight = $('div.headerinfo').outerHeight()||0;
var navBarHeight = 0;
//var navBarHeight = $('.menucontent').outerHeight();
var slidersBarHeight = $('div#slidersbar').outerHeight()||0;
var tableHeadersHeight = $('div.category1firstrow').outerHeight();
var heroHeight = $('.category1imgshift').outerHeight();
var heroNavMessageHeight = heroHeight - navBarHeight + messageHeight;
var navSliderHeight = navBarHeight + slidersBarHeight;
var navSliderHeaderHeight = navSliderHeight + slidersBarHeight;
var bottomMargin = messageHeight + navSliderHeight + tableHeadersHeight;
var navBarPosition = $('.menucontent').offset();

$(window).scroll(function(){    
	var navBarPosition = $('.menucontent').offset();
});

function getTableBottom(){
	try{
		return $('.card1rowseparator').eq(-2).offset().top;
	}catch(e){}
};

/*$(window).scroll(function(){    
    if ($(this).scrollTop() > messageHeight){ 
        $('.menucontent').css({position: 'fixed', top: '0'});
        $('.menucontent').css('background-color', 'rgba(255,255,255,0.98)');
        $('.menuheadlogo').addClass('menuheadlogo-scrolling');
        $('.menusearch').addClass('menusearch-scrolling');
        $('.menuicon').addClass('menuicon-scrolling');
    }
    else{
        $('.menucontent').css({position: 'absolute', top: messageHeight + 'px'});
        $('.menucontent').css('background-color', 'rgba(255,255,255,0)');
        $('.menuheadlogo').removeClass('menuheadlogo-scrolling');
        $('.menusearch').removeClass('menusearch-scrolling');
        $('.menuicon').removeClass('menuicon-scrolling');
        setTimeout(function() {
        },1000);
    }
});*/
/*
function floatSlidersBar(top, is_table){
	if (slidersBarHeight != 0){
		if (is_table){
			$('div#slidersbar').css({position: 'fixed', top: navBarHeight + 'px'});
        	$('div#slidersbar').css('background-color', 'rgba(255,255,255,0.98)');
		}else{
			$('div#slidersbar').css({position: 'relative', top: '0'});
        	$('div#slidersbar').css('background-color', '#F7F7F7');
		}
	}
};

function floatTableHeaders(top, is_table){
	if (is_table){
		$('div.category1firstrow').css({position: 'fixed', top: navSliderHeight + 'px'});
	}else{
		$('div.category1firstrow').css({position: 'relative', top: '0'});
	}
};
*/
function initMessageBar(){
	if (messageHeight > 0){
		function adjustPositions(offset){
			//$('.mainmenu').css('top', (menuTop + messageHeight) + 'px');
			//$('.searchmenu').css('top', (menuTop + messageHeight) + 'px');
			$('.menucontent').css('top', ($('.menucontent').position().top + offset) + 'px');
			try{
				$('.category1imgshift').css('top', ($('.category1imgshift').position().top + offset) + 'px');
				$('.category1position').css('margin-top', ($('.category1position').offset().top + offset) + 'px');
			}catch(e){
				try{
					$('.ctx1start').css('margin-top', ($('.ctx1start').offset().top + offset) + 'px');
				}catch(e){}
			};
		};
		adjustPositions(messageHeight);
		$('#message-1 div.headerclose').click(function(){
			$('.headerinfo').css('opacity','0');
			var offset = messageHeight * -1;
			bottomMargin -= messageHeight;
			messageHeight = 0; // reset first before adjusting
			adjustPositions(offset);
		});
	};
};

$(document).ready(function(){
	/*initMessageBar();*/
	var visible = false;
	var searchvisible = false;
	$('.menuicon').on('click',function(e){
		e.stopPropagation();
		if(visible){
			$('#menucontent').stop().animate({opacity:0},150 , function(){
				$('#menucontent').css({display:'none'});
				$('.background-overlay').css({display:'none'});
			});
			visible = false;
		} else {
			if(searchvisible){ 
				$('#searchcontent').stop().animate({opacity:0},150 , function(){
					$('#searchcontent').css({display:'none'});
					searchvisible = false;
				});
			}
			$('#menucontent').css({display:'block'}).animate({opacity:1},150);
			$('#menucontent').css('top', ( $('.menucontent').position().top + 70 ) + 'px');
			$('.background-overlay').css({display:'block'}).animate({opacity:1},150);
			visible = true;
		}
	});

	$('.menusearch').on('click',function(e){
		e.stopPropagation();
		if(searchvisible){
			$('#searchcontent').stop().animate({opacity:0},150 , function(){
				$('#searchcontent').css({display:'none'});
				$('.background-overlay').css({display:'none'});
			});
			searchvisible = false;
		} else {
			if(visible){ 
				$('#menucontent').stop().animate({opacity:0},150 , function(){
					$('#menucontent').css({display:'none'});
					visible = false;
				});
			}
			$('#searchcontent').css({display:'block'}).animate({opacity:1},150);
			$('#searchcontent').css('top', ( $('.menucontent').position().top + 70 ) + 'px');
			$('.background-overlay').css({display:'block'}).animate({opacity:1},150);
			searchvisible = true;
		}
	});

	$(window).scroll(function(){
		if(visible){
			$('#menucontent').stop().animate({opacity:0},150 , function(){
				$('#menucontent').css({display:'none'});
				$('.background-overlay').css({display:'none'});
			});
			visible = false;
		}

		if(searchvisible){
			$('#searchcontent').stop().animate({opacity:0},150 , function(){
				$('#searchcontent').css({display:'none'});
				$('.background-overlay').css({display:'none'});
			});
			searchvisible = false;
		}
	});

	$(document).click(function(event) { 
	    if(!$(event.target).closest('#searchcontent').length) {
	        if(searchvisible == true) {
				$('#searchcontent').stop().animate({opacity:0},150 , function(){
					$('#searchcontent').css({display:'none'});
					$('.background-overlay').css({display:'none'});
				});
				searchvisible = false;
	        }
	    }        
	})

	/*$(window).scroll(function(evt){
		var tableBottom = getTableBottom();
		var top = $(window).scrollTop();
		if (tableBottom < (top - messageHeight + bottomMargin)){
			$('div#slidersbar').css({position: 'absolute', top: tableBottom - tableHeadersHeight - slidersBarHeight + 'px'});
			$('div.category1firstrow').css({position: 'absolute', top: tableBottom - tableHeadersHeight + 'px'});
		}else{
			var is_table = top >= heroNavMessageHeight;
			floatSlidersBar(top, is_table);
			floatTableHeaders(top, is_table);
			if (is_table){
				$('.category1imgbox').css('margin-bottom', bottomMargin + 'px');  // offset the lost height of floating elements
				$('.category1position').css('opacity', '0');
			}else{
				$('.category1imgbox').css('margin-bottom', '0px');  // offset the lost height of floating elements
				$('.category1position').css('opacity', '1');
			};
		};
	});*/

	// tooltip::
	$('.card2savingstext').hover(function(e){
		$(e.target).find('.card2savingtooltipcont').show(200);
	},function(e){
		if($(e.target).parents('.card2savingstext').length == 0){
			$(e.target).find('.card2savingtooltipcont').hide(400);
		}
	});

	$('.card2savingtooltipctx').mouseout(function(e){
		$(e.currentTarget).parent().hide(400);
	});

	// search ::
	$('.menusearch').on('click',function(){
		var t = $('.menusearchinput');
		if(t.css('width') != '270px'){
			t.focus();
			t.animate({width:270 , paddingLeft:5 , opacity:1},1000);
		} else {
			$(this).closest('form').submit();
		}
	});

	// homepage drop down ::
	var selectDropdown = {
		open:false,
		selected:null,
		value:null
	};
	$('.ctx1dropdowntop').click(function(){
		//console.log('clicked dd:',selectDropdown.open);
		if(selectDropdown.open){
			$('.ctx1dropdownlist').hide(100);
			selectDropdown.open=false;
		} else {
			$('.ctx1dropdownlist').show(100);
			selectDropdown.open=true;
		}
	});

	$('.ctx1dropdownswrapper').click(function(e){
		// console.log('slot:',selectDropdown.open);
		selectDropdown.selected = $(this).find(".ctx1dropdownbigtext").text();
		selectDropdown.value = $(this).find(".ctx1dropdownslot").attr('value');
		$('.ctx1dropdowntext').text(selectDropdown.selected);
		$('.ctx1dropdownlist').hide(100);
		selectDropdown.open=false;
	});

	$('.ctx1btn').click(function(){
		if(selectDropdown.value && selectDropdown.selected){
			window.location=selectDropdown.value;
		}
	});

	var rotateangle = 180;    

	$('.ctx1dropdowntop').click(function() {
	    $('.ctx1dropdownarrow').css ({
	        '-webkit-transform': 'rotate(' + rotateangle + 'deg)',
	           '-moz-transform': 'rotate(' + rotateangle + 'deg)',
	             '-o-transform': 'rotate(' + rotateangle + 'deg)',
	            '-ms-transform': 'rotate(' + rotateangle + 'deg)'
	    });
	    rotateangle += 180;
	});

	$('.ctx1dropdownswrapper').click(function() {
	    $('.ctx1dropdownarrow').css ({
	        '-webkit-transform': 'rotate(' + rotateangle + 'deg)',
	           '-moz-transform': 'rotate(' + rotateangle + 'deg)',
	             '-o-transform': 'rotate(' + rotateangle + 'deg)',
	            '-ms-transform': 'rotate(' + rotateangle + 'deg)'
	    });
	    rotateangle += 180;
	});

	// article ::
	$('.category1link').click(function(evt){
		evt.stopPropagation();
		evt.preventDefault();
		var q = $('.category1article');
		if(q.is(":visible")){
			q.hide(300, function(){$('div.category1link').show();});
		} else {
			$('div.category1link').hide();
			q.show(500);
		}

	});
	
	// focus out ::
	$(document).on('click',function(e){
		if(visible == true && ($(e.target).parents("#menucontent").size() == 0 && e.target != $('#menucontent')[0])){
			$('#menucontent').stop().animate({opacity:0},150 , function(){
				$('#menucontent').css({display:'none'});
				$('.background-overlay').css({display:'none'});
			});
			visible = false;
		}
		if(selectDropdown.open && ($(e.target).parents(".ctx1dropdown").size() == 0 && e.target != $('.ctx1dropdown')[0])){
			$('.ctx1dropdownlist').hide(100);
			selectDropdown.open = false;
		}
	});
});

$('.smartdropdowntop').each(function(){
	var selectDropdown = {
		open:false,
		selected:null,
		value:null
	};
	var q = $(this);
	var p = q.parent();
	q.click(function(){
		if(selectDropdown.open){
			p.find('.smartdropdownlist').hide(100);
			selectDropdown.open=false;
		} else {
			p.find('.smartdropdownlist').show(100);
			selectDropdown.open=true;
		}
	});

	p.find('.smartdropdownslot1,.smartdropdownslot2').click(function(e){
		selectDropdown.selected = e.currentTarget.innerText || e.currentTarget.textContent;
		selectDropdown.value = e.currentTarget.getAttribute('value');
		// console.log(p.find('.smartdropdowntext'));
		p.find('.smartdropdowntext1,.smartdropdowntext2').text(selectDropdown.selected);
		p.find('.smartdropdownlist').hide(100);
		selectDropdown.open=false;

		// apply to local input
		p.find('input').attr('value',selectDropdown.value);
	});
});

$(document).ready(function(){
	var $window = $(window);
	$('div[data-type="background"]').each(function(){
		var $bgobj = $(this);
		$(window).scroll(function() {
		var yPos = -($window.scrollTop() / $bgobj.data('speed'));
		var coords = '50% '+ yPos + 'px';
		$bgobj.css({ backgroundPosition: coords });
		});
	});
});