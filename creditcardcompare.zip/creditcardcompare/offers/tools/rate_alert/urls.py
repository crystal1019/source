from django.conf.urls import *
from views import RegisterView


urlpatterns = patterns('offers.tools.rate_alert.views',
    url(r'^register/$', RegisterView.as_view(), name='register_alert'),
    url(r'^deactivate/(\w+)/$', 'deactivate', name='activate_alert'),
)
