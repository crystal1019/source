from django.conf.urls.defaults import patterns, include, url
from django.conf import settings
# from accounts.forms import ProfileForm
from validate.forms import HomeTelForm, MobileTelForm
# from registration.forms import RegistrationForm
from django.views.generic.simple import direct_to_template, redirect_to
from profiles.views import edit_profile
from registration.views import activate
from registration.views import register
# from accounts.forms import UserRegistrationForm

from place.libs import views as libs_views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

from django.contrib.sitemaps import *

from django.contrib import admin
admin.autodiscover()
from place.sitemap import *
import robots
from platform import node

from place.base.models import (
    CaseStudy,
    Event,
    Job,
    NewsArticle,
    Partner,
    PressRelease,
    QuestionSection,
    Supporter,
    TeamMember,
    Testimonial,
    Video,
)

server = node()

try:
    delete_url = settings.MULTI_FILE_DELETE_URL
except AttributeError:
    delete_url = 'multi_delete'

try:
    image_url = settings.MULTI_IMAGE_URL
except AttributeError:
    image_url = 'multi_image'

# handler404 = 'place.libs.views.place_404'
handler500 = 'place.libs.views.place_500'

urlpatterns = patterns('',

    # Seed Topics
    url(r'^claim/(?P<verif_code>\w+)/$', 'place.seedscrape.views.accept',
        {'topic_type': 'election-seed', 'plan_code': 'premium'}),
    url(r'^elections/canada/bc/2014/faq/$', direct_to_template,
        {'template': 'elections/faq.html'}),
    url(r'^email/$', 'place.seedtopic.views.log_seed_email'),

    url(r'^user_growth/(?P<region>\w+)/$', 'place.base.views.growth_map'),
    url(r'^user-json/$', 'place.base.views.get_user_json'),

    url(r'^admin_tools/', include('admin_tools.urls')),
    url(r'^admin/ps_analytics/', 'libs.views.load_analytics_page'),
    url(r'^admin/ps_tools/create_topic/(?P<topic_type>ps_topic|oauth2_topic)/', 'libs.views.create_topic'),

    url(r'^admin/ps_tools/participants_per_topic/$', 'libs.views.participants_per_topic'),
    url(r'^admin/ps_tools/places_by_city/$', 'libs.views.places_by_city'),
    url(r'^admin/ps_tools/survey_users/$', 'libs.views.get_incomplete_surveys'),
    url(r'^admin/ps_tools/download_topic_list/$', 'libs.views.download_topic_list'),
    url(r'^admin/ps_tools/newsletter_emails/$', 'libs.views.newsletter_email_list'),
    url(r'^admin/ps_tools/create_psc/$', 'libs.views.create_psc'),
    url(r'^admin/ps_tools/$', 'libs.views.load_tools_page'),

    # STATIC PAGES
    url(r'^fbchannel/$', direct_to_template, {'template': 'base/channel.html'}),
    url(r'^terms/$', direct_to_template, {'template': 'base/terms_of_use.html'}),
    url(r'^terms/(?P<tab>proponents|participants|moderation)/$', direct_to_template, {'template': 'base/terms_of_use.html'}),
    url(r'^privacy/$', direct_to_template, {'template': 'base/privacy.html'}),
    url(r'^contact/$', 'place.base.views.contact_us'),
    url(r'^jobs/$', direct_to_template, {
        'template': 'base/jobs.html',
        'extra_context': {'jobs': Job.objects.all()}
    }),
    url(r'^thanks/$', direct_to_template, {'template': 'base/contact_thankyou.html'}),
    url(r'^about/$', direct_to_template, {
        'template': 'base/about.html',
        'extra_context': {
            'case_studies': CaseStudy.objects.all(),
            'members': TeamMember.objects.all(),
            'partners': Partner.objects.all(),
            'supporters': Supporter.objects.all(),
            'testimonials': Testimonial.objects.all()
        }
    }),
    url(r'^about/(?P<tab>placespeak|team|partners|supporters|case-studies|testimonials)/$', direct_to_template, {
        'template': 'base/about.html',
        'extra_context': {
            'case_studies': CaseStudy.objects.all(),
            'members': TeamMember.objects.all(),
            'partners': Partner.objects.all(),
            'supporters': Supporter.objects.all(),
            'testimonials': Testimonial.objects.all()
        }
    }),
    url(r'^alacart/$', direct_to_template, {'template': 'base/ala_cart.html'}),
    url(r'^faq/$', direct_to_template, {
        'template': 'base/faq.html',
        'extra_context': {
            'question_sections': QuestionSection.objects.all()
        }
    }),
    url(r'^faq/(?P<tab>participants|proponents)/$', direct_to_template, {
        'template': 'base/faq.html',
        'extra_context': {
            'question_sections': QuestionSection.objects.all()
        }
    }),
    url(r'^how_it_works/$', direct_to_template, {'template': 'base/how_it_works.html'}),
    url(r'^how_it_works/(?P<tab>participants|proponents)/$',
        redirect_to,
        {'url': '/faq/%(tab)s/'},
        name='faq'
    ),  # Redirect to FAQ in case someone has this old URL bookmarked.
    url(r'^media/$', direct_to_template, {
        'template': 'base/media.html',
        'extra_context': {
            'events': Event.objects.all(),
            'news_articles': NewsArticle.objects.all(),
            'press_releases': PressRelease.objects.all(),
            'videos': Video.objects.all()
        }
    }),
    url(r'^media/(?P<tab>press|kit|videos|events)/$', direct_to_template, {
        'template': 'base/media.html',
        'extra_context': {
            'events': Event.objects.all(),
            'news_articles': NewsArticle.objects.all(),
            'press_releases': PressRelease.objects.all(),
            'videos': Video.objects.all()
        }
    }),
    url(r'^loaderio-a171ca9b58a83b46d44224d781955cf9/$', direct_to_template, {'template': 'load_test.html'}),

    #Create a consultation
    url(r'^pricing/$', 'proponents.views.pricing'),
    url(r'^orgsignup/$', 'proponents.views.register'),
    url(r'^create-consultation/$', 'proponents.views.organizationChannel'),
    url(r'^pricingdetail/$', 'proponents.views.pricingdetail'),
    url(r'^create-trial/$', 'proponents.views.b2bdemo'),

    #Recurly related
    url(r'^purchase/$', 'recurly.views.payment'),
    url(r'^subscribe/confirmation/$', 'recurly.views.confirmation'),
    url(r'^payment/', include('django_recurly.urls')),
    # END STATIC PAGES

    # Confirmation Dialog
    url(r'^confirmation_dialog/$', 'place.base.views.confirmation'),

    # Tracking
    url(r'^jserr/', include('place.jserr.urls')),
    url(r'^browser/$', 'place.libs.views.browser'),


    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),

    (r'^robots.txt$', include('robots.urls')),

    # Facebook canvas app URL
    url(r'^fb-canvas-app/$', 'place.base.views.fb'),

    # Invitation response needs to be here. ( For outstanding legacy (PlaceSpeak v2))
    url(r'^topic/invitation_response/$', 'topics.editor.invitation_response'),
    # New Invite
    url(r'^invitation_response/$', 'topics.editor.invitation_response'),


    # Admin/Moderator response
    url(r'^topic/admin-invite/(?P<response>accept|decline)/$', 'topics.editor.invitation_response'),

    # TOPICS

    url(r'^topic/json/', include('topics.json_urls')),

    # Topic polygons
    url(r'^maps/aois/', 'topics.views.load_topicpolys'),

    # Connect to a list of topics
    url(r'^topics/connect_all/', 'topics.views.connect_all'),

    # Social Media
    url(r'^topics/social/tweets/(?P<id>\d+)/$', 'topics.views.tweets'),

    # Noticeboard
    url(r'^topics/noticeboard/text_post/$', 'topics.views.nb_post_text'),
    url(r'^topics/noticeboard/video_post/$', 'topics.views.nb_post_video'),
    url(r'^topics/noticeboard/image_post/$', 'topics.views.nb_post_image'),
    url(r'^topics/noticeboard/replies/add/$', 'topics.views.nb_reply'),
    url(r'^topics/noticeboard/replies/$', 'topics.views.get_nb_replies'),
    url(r'^topics/noticeboard/follow/$', 'topics.views.follow_noticeboard'),
    # End Noticeboard

    # Survey
    url(r'^survey/(?P<id>\d+)/$', 'topics.views.survey_connect'),
    #   url(r'^survey/(?P<id>\d+)/$', 'topics.views.survey_window'),
    # End Survey

    # Discussions
    url(r'^topics/discussion/view_counter/$', 'topics.views.view_counter'),
    url(r'^topics/discussion/follow_all/$', 'topics.views.follow_all_discussions'),
    url(r'^topics/discussion/follow/$', 'topics.views.follow_discussion'),
    url(r'^topics/discussion/delete/$', 'topics.views.delete_post'),
    url(r'^topics/discussion/abuse/$', 'topics.views.report_post'),
    url(r'^topics/discussion/moderate/$', 'topics.views.block_post'),
    url(r'^topics/discussion/replies/add/$', 'topics.views.add_reply'),
    url(r'^topics/discussion/replies/$', 'topics.views.get_replies'),
    url(r'^topics/discussion/posts/add/$', 'topics.views.add_post'),
    url(r'^topics/discussion/posts/$', 'topics.views.get_posts'),
    url(r'^topics/discussion/vote/$', 'topics.views.discussion_vote'),
    # url(r'^topics/edit/add_discussion/$', 'topics.views.add_discussion'),
    # url(r'^topics/edit/delete_discussion/$', 'topics.views.delete_discussion'),
    # url(r'^topics/edit/discussions/$', 'topics.views.edit_discussions'),
    # End Discussions

    # Input Map
    url(r'^topics/im/', include('topics.im_urls')),
    # End Input Map

    # url(r'^topics/edit/overview/$', 'topics.views.edit_overview'),
    url(r'^topics/topic_map/$', 'topics.views.topic_map'),
    # url(r'^topics/topic_edit_map/$', 'topics.views.topic_edit_map'),
    # url(r'^topics/image/delete/$', 'topics.views.delete_topic_image'),
    # url(r'^topics/image/$', 'topics.views.topic_image'),

    url(r'^topics/topic_card/$', 'topics.views.topic_card'),

    # Poll
    url(r'^topics/poll/vote/$', 'topics.views.poll_vote'),
    # End Poll

    # END TOPIC


    url(r'^explore/$', 'topics.explore.explore'),
    url(r'^explore/search/$', 'topics.explore.search'),

    url(r'^ps_widgets/', include('topics.urls')),

    # url(r'^$', 'base.views.home'),
    url(r'^', include('base.urls')),

    # PROFILE
    url(r'^profile/notifications', 'accounts.views.notifications'),
    url(r'^profile/notification/mark_read/', 'accounts.views.mark_notification_read'),
    url(r'^profile/settings/(?P<tab>\w+)/$', 'accounts.views.settings'),
    url(r'^profile/settings/(?P<tab>\w+)/(?P<section>mobile|home|geo)/$', 'accounts.views.settings'),
    url(r'^profile/settings', 'accounts.views.settings'),
    url(r'^profiles/place/delete/(?P<id>\d+)/$', 'accounts.views.delete_place'),  # Delete Place
    url(r'^profile/place/(?P<id>\d+)/$', 'accounts.views.edit_place'),  # Edit Place
    url(r'^profile/place/$', 'accounts.views.edit_place'),  # Edit Place
    url(r'^profile/keywords/$', 'accounts.views.keywords'),  # Add Place
    url(r'^profile/place_stats/$', 'accounts.views.place_stats'),
    url(r'^profile/connected_topics/$', 'accounts.views.connected_topics'),
    url(r'^profile/my_organizations/$', 'accounts.views.my_organizations'),
    url(r'^profile/my_topics/$', 'accounts.views.my_topics'),
    url(r'^profile/', 'accounts.views.profile', name='profile'),
    url(r'^accounts/profile/', redirect_to, {'url': '/profile/'}, name='profile'),

    # Validation
    url(r'^validate/hometel/add/$', 'validate.views.add_homeTel', {}, 'validate_hometel_add'),
    url(r'^validate/hometel/confirm/', 'validate.views.confirm_homeTel', {}, 'validate_hometel_confirm'),
    url(r'^validate/hometel/talk/(?P<username>[\w\.]+)/$', 'validate.views.publishPin',),
    url(r'^validate/mobiletel/add/$', 'validate.views.add_mobileTel', {}, 'validate_mobiletel_add'),
    url(r'^validate/mobiletel/confirm/', 'validate.views.confirm_mobileTel', {}, 'validate_mobiletel_confirm'),
	url(r'^validate/geolocation/', 'validate.views.geolocation'),

    url(r'^accounts/change_password/$', 'accounts.views.change_password'),  # Change Password
    url(r'^accounts/change_avatar/$', 'accounts.views.change_avatar'),  # Change Avatar

    # Forgot password
    url(r'^accounts/password/reset/complete/$', direct_to_template, {'template': 'index.html'}),
    url(r'^accounts/', include('registration.backends.default.urls')),

    # END PROFILE

    # REPORTS
    url(r'^report/', include('reporter.urls')),
    # END REPORTS

    # TOPIC
    url(r'^topic/topic_metrics/$', 'topics.views.topic_metrics'),
    url(r'^topic/topic_metrics_json/$', 'topics.views.topic_metrics_json'),
    url(r'^topic/connect/(?P<id>\d+)/$', 'topics.views.connect_to_topic'),
    url(r'^topic/archive/(?P<topic_id>\d+)/$', 'topics.views.topic_archive'),
    url(r'^topic/disconnect/$', 'topics.views.disconnect'),
    url(r'^topic/(?P<id>\w+)/(?P<tab>\w+)/$', 'topics.views.topic'),
    url(r'^topic/(?P<id>[-\w]+)/$', 'topics.views.topic'),
    url(r'^topic/(?P<id>[-\w]+)/(?P<tab>[-\w]+)/$', 'topics.views.topic'),


    # TOPIC EDIT
    url(r'^editor_v2/', include('place.topics.editor_urls')),

    url(r'^editor/notify/', 'topics.editor.notify_participants'),
    url(r'^editor/check_topic_requirements/', 'topics.editor.check_topic_requirements'),
    url(r'^editor/toggle_publish_topic/', 'topics.editor.toggle_publish_topic'),
    url(r'^editor/polls/publish/$', 'place.topics.editor.publish_poll'),
    url(r'^editor/polls/unpublish/$', 'place.topics.editor.unpublish_poll'),
    url(r'^editor/polls/published_poll/$', 'place.topics.editor.published_poll'),
    url(r'^editor/polls/closed_polls/$', 'place.topics.editor.closed_polls'),
    url(r'^editor/surveys/fluidsurveys/connect/$', 'place.topics.editor.fluidsurveys_connect'),
    url(r'^editor/surveys/limesurvey/add/$', 'place.topics.editor.limesurvey_add'),
    url(r'^editor/reports/load/$', 'place.topics.editor.load_reports'),

    url(r"^mapedit/$", 'place.topics.maps.vw_map'),
    url(r'^topicedit/(?P<id>\w+)/(?P<tab>[-\w]+)/$', 'topics.editor.topic_edit'),
    url(r'^topicedit/(?P<id>[-\w]+)/$', 'topics.editor.topic_edit'),
    url(r'^topicedit/(?P<id>[-\w]+)/(?P<tab>[-\w]+)/$', 'topics.editor.topic_edit'),
    url(r'^topicedit_v2/(?P<id>\w+)/(?P<tab>[-\w]+)/$', 'topics.editor_v2.topic_edit'),
    url(r'^topicedit_v2/(?P<id>[-\w]+)/$', 'topics.editor_v2.topic_edit'),
    url(r'^topicedit_v2/(?P<id>[-\w]+)/(?P<tab>[-\w]+)/$', 'topics.editor_v2.topic_edit'),
    url(r'^editor/fluidsurveys_surveys/$', 'place.topics.editor.fluidsurveys_surveys'),
    url(r'^editor/invite/$', 'place.topics.editor.member_invite'),
    url(r'^editor/proponent/logo/$', 'place.topics.editor.topic_logo'),
    url(r'^editor/overview/image/delete/$', 'topics.editor.delete_topic_image'),
    url(r'^editor/overview/image/$', 'topics.editor.topic_image'),

    # END TOPIC EDIT

    #
    # url(r'^topic/(?P<id>\d+)/(?P<slug>[-\w]+)/$', 'topics.views.load_topic'),
    # END TOPIC

    # LOGIN
    url(r'^login/$', 'place.accounts.views.mylogin'),
    url(r'^logout/$', 'place.accounts.views.mylogout'),
    # END LOGIN

    #registration urls
    url(r'^signup/', include('registration.backends.place_regbackend.urls')),
    url(r'^maps/places/', 'accounts.views.places'),
    url(r'^maps/topic_places/', 'topics.views.topic_places'),
    url(r'^maps/homepage_topics/', 'base.views.homepage_topics'),


    url(r'^assets/', include('assets.urls')),

    url(r'^plans/verify/', 'libs.views.verify'),
    url(r'^alert/', 'libs.views.alert'),
    url(r'^delete_asset', 'assets.views.deleteAsset'),
    url(r'^geoip/$', 'libs.views.geoip'),

    url(r'^social/', include('socialregistration.urls', namespace='socialregistration')),
    url(r'^ps_widgets/', include('topics.urls')),

    url(r'^spatial/geocode/$', 'libs.views.geocode'),
    url(r'^spatial/geocode_mq/$', 'libs.views.geocode_mq'),

    url(r'^survey/launch_ls_admin/', 'survey.views.launch_ls_admin'),
    url(r'^survey/survey_info/', 'survey.views.survey_info'),

    url(r'^accept/(?P<verif_code>\w+)/$', 'proponents.views.acceptManager'),
    url(r'^seedscrape/accept/(?P<verif_code>\w+)/$', 'seedscrape.views.accept'),
    # url(r'^decline/(?P<verif_code>\w+)/$', 'proponents.views.decline_team'),

    # ORGANIZATION
    url(r'^channel/(?P<org_id>\d+)/$', 'proponents.views.orgChannel'),
    url(r'^dashboard/', include('proponents.urls')),
    # END ORGRANIZATION

    #EU Cookie Policy
    url(r'^cookiecheck/', 'base.views.eucookies'),
    url(r'^cookie-policy/', direct_to_template, {'template': 'base/cookie_policy.html'}),

    url(r'^profile-menu/', 'base.views.profile_menu'),

    #maintenance banner
    # url(r'^maincheck/', 'base.views.banner'),

    #redirect for old vanity urls
    url(r'^(?i)(?P<vanity>backyardcompost|gibsonsharbour|hamiltonareaplan|HamiltonAreaPlan|KPRA|oakridgecentre|ourfuture.vsb|OurFuture.VSB|rcbc|tofinotsunamisiren|streetcarcity2050|urbanfuturessurvey|vancouverhousing|vancouvertransportation|VCRP|VFRS|VMM|ubchousingplan|UBCHousingPlan|NewWestMTP|newwestmtp|urbanfuturessurvey-cn|housingtaskforce|northdelta|LetsTalkSiteC|aldergroveregionalpark|fahrlands|translinkbaseplan)/$', 'place.base.views.vanity'),
    #redirect for old vanity urls
    url(r'^(?i)(?P<vanity>[-\w]+)/$', 'place.base.views.vanity'),

    url(r'^connect/', include('place.psc.urls')),
    url(r'^connect/api/', include('place.psc_api.urls')),
)


sitemaps = {
    'topic': Topicsitemap,
    'index': Indexsitemap,
    'about': Aboutsitemap,
    'contact': Contactsitemap,
    'howitworks': HowItWorkssitemap,
    'pricing': Pricingsitemap,
    'pricingdetail': Pricingsitemap,
    'register': Registersitemap,
    'topicslist': Topicssitemap,
    'privpolicy': Privacysitemap,
}

urlpatterns += patterns('',
    (r'^sitemap\.xml', 'django.contrib.sitemaps.views.sitemap', {'sitemaps': sitemaps}),
)

if not settings.CURRENT_SERVER in ['prod', 'dev']:
        urlpatterns += patterns('',
            url(r'^uploads/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT}),
            url(r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.STATIC_ROOT}),
        )
