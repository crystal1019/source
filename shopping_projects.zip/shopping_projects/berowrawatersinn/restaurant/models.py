from django.db import models
from berowrawatersinn.website.models import CommonPage
# Create your models here.
class RestaurantPage(CommonPage):
    nav = '/restaurant/'
    is_landing = models.BooleanField(default=False)
    
    def save(self,*args, **kwargs):
        if self.is_landing:
            try:
                landing = RestaurantPage.objects.get(is_landing=True)
                if landing.id != self.id:
                    landing.is_landing = False
                    landing.save()
            except:
                pass
            
        super(RestaurantPage, self).save(*args, **kwargs)