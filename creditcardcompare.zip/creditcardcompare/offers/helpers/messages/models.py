from datetime import date
from django.db import models
from django.utils.text import slugify


class MessageManager(models.Manager):
    def get_by_name(self, name, request=None):
        try:
            m = self.get(name=name, is_public=True)
        except self.model.DoesNotExist:
            pass
        else:
            if request is not None and request.COOKIES.get("message-%s" % m.id) == slugify(m.text):
                pass
            elif m.expiry >= date.today():
                return m

class Message(models.Model):
    name = models.CharField(max_length=30, unique=True, help_text='Identifier for this message (must be unique).')
    text = models.TextField(help_text='The message to show on page.')
    url = models.URLField(null=True, blank=True, help_text='The page where the message is linked to.')
    is_public = models.BooleanField()
    expiry = models.DateField()
    description = models.TextField(null=True, blank=True)
    
    objects = MessageManager()
    
    def __unicode__(self):
        return self.text