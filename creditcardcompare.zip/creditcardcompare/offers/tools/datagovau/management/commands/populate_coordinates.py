import os
from datetime import date
from pygeocoder import Geocoder, GeocoderError
from django.core.management.base import BaseCommand
from offers.tools.datagovau.models import Location


class Command(BaseCommand):
    
    def handle(self, *args, **options):
        locations = Location.objects.filter(lat=None, lon=None).values('address').distinct()
        print 'Trying to populate %s locations' % locations.count()
        counter = 0
        for location in locations:
            feedback = self.populate_coordinates(location['address'])
            if feedback:
                print feedback
                return
            
            print 'Processed %s locations' % counter
            counter += 1
            
    def populate_coordinates(self, address):
        try:
            results = Geocoder.geocode(address)
        except GeocoderError, e:
            if 'OVER_QUERY_LIMIT' in e.message:
                return e.message
            elif 'ZERO_RESULTS' in e.message:
                print 'Not an Australian address, self deleting %s...' % address
                Location.objects.filter(address=address).delete()
            else:
                raise e
        else:
            found_in_au = False
            for result in results:
                if 'Australia' in result.formatted_address:
                    if found_in_au:
                        print 'Warning! Found multiple coordinates using %s' % address
                    lat, lon = result.coordinates
                    locations = Location.objects.filter(lat=None, lon=None, address=address)
                    locations.update(lat=lat, lon=lon)
                    found_in_au = True
            if not found_in_au:
                print 'Not an Australian address, self deleting %s...' % address
                Location.objects.filter(address=address).delete()