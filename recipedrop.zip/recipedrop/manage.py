#!/usr/bin/env python
# -*- coding: utf-8 -*-
from os import path, environ
import sys
import subprocess

PROJECT_ROOT = path.abspath(path.dirname(__file__))
PROD_REQUIREMENTS = path.join(PROJECT_ROOT, 'requirements/prod.txt')
TEST_REQUIREMENTS = path.join(PROJECT_ROOT, 'requirements/test.txt')

VE_ROOT = environ.get('VIRTUAL_ENV')
if not VE_ROOT:
    VE_ROOT = path.join(PROJECT_ROOT, 'env')
VE_ROOT = path.abspath(VE_ROOT)

PIP_CACHE_DIR = environ.get('PIP_DOWNLOAD_CACHE')
if not PIP_CACHE_DIR:
    PIP_CACHE_DIR = path.expanduser(path.join('~', '.pip_download_cache'))
    environ['PIP_DOWNLOAD_CACHE'] = PIP_CACHE_DIR


def go_to_ve():
    sys.stderr.write('Going into ve\n')
    if sys.prefix != VE_ROOT:
        if sys.platform == 'win32':
            python = path.join(VE_ROOT, 'Scripts', 'python.exe')
        else:
            python = path.join(VE_ROOT, 'bin', 'python')

        retcode = subprocess.call([python, __file__] + sys.argv[1:])
        sys.exit(retcode)

update_ve = 'update_ve' in sys.argv
if update_ve:
    sys.stderr.write('Updating Virtual ENV\n')
    # install ve
    if not path.exists(VE_ROOT):
        import virtualenv
        sys.stderr.write('Creating virtualenv... ')
        virtualenv.logger = virtualenv.Logger(consumers=[])
        virtualenv.create_environment(VE_ROOT, site_packages=False)
        sys.stderr.write('Done.\n')

    go_to_ve()
    # check requirements
    if 'test' in sys.argv:
        REQUIREMENTS = TEST_REQUIREMENTS
    else:
        REQUIREMENTS = PROD_REQUIREMENTS
    import pip
    pip.main(initial_args=['install', '-r', REQUIREMENTS])
    sys.exit(0)

if path.exists(VE_ROOT):
    go_to_ve()
    sys.stderr.write('Found virtualenv. Entering...\n')

# run django
if __name__ == "__main__":
    environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
