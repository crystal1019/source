var gmaps = {};
var default_location = new google.maps.LatLng(49.2505, -123.1119);
var lat = null;
var lng = null;

function initCategoryToolbar(map) {
    // Toolbar events
    $('#topic-categories-toolbar .selectable').click(function(){
        $('#topic-categories-toolbar .selectable').removeClass('selected');
        $(this).addClass('selected');

        var category = $(this).data('category');
        var topic_pins = map.topic_pins;
        for (var i = 0, cnt=topic_pins.length; i < cnt; i++) {
            var pin = topic_pins[i];
            pin.setVisible((category === undefined || category === 'all' || pin.category === category));
        }
    });
}


/**
 * Load the map for the profile page.
 * @param  {Array} places Users's places. {"index": 2, "coords": [-120.4, 48.9]}
 * @param  {Integer} notification_distance Notification distance for user (in meters);
 * @return {null}
 */
function load_profile_map(places, topics, notification_distance) {
    var map_opts = {
        zoom: 11
    };
    var place_cnt = places.length;
    var topic_cnt = topics.length;
    if (place_cnt > 0) {
        var init_place = places[0];
        map_opts['center'] = new google.maps.LatLng(init_place.coords[0], init_place.coords[1]);
    }
    var map = new GMap('map_canvas', map_opts);
    gmaps['profile'] = map;

    // Add places
    for (var i=0; i < place_cnt; i++){
        var place = places[i];
        map.addPlace(place.index, place.coords[0], place.coords[1]);

        // Add notification zone (based on notification distance in settings)
        b = map.addNotificationZone(notification_distance, place.coords[0], place.coords[1], place.index);
        if (i === 0) {
            map.map.fitBounds(b.getBounds());
        }
    }

    // Add connected topics
    for (var j=0; j < topic_cnt; j++){
        var topic = topics[j];
        map.addTopic(topic.id, topic.category, topic.coords[0], topic.coords[1], topic.plan_code);
    }
}


/**
 * Load the home page map
 * @param  {Array} topics Array of topic id's and topic center coordinates.
 * [{"id": 1, "coords": [-121, 51],...}]
 * @return {null}
 */
function load_home_map(places, options) {
    var map_opts = {
        zoom: 13
    };
    utils.apply(map_opts, options);
    var map = new GMap('map_canvas', map_opts);
    gmaps['home'] = map;


    // Init topic toolbar
    initCategoryToolbar(map);

    // Load users
    $.ajax({
        url: '/maps/places/',
        type: 'post',
        data: {
            'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
        },
        success: function(places) {
            for (var i = 0, plc_cnt=places.length; i < plc_cnt; i++) {
                var place = places[i];
                map.addUserPin(place.coords[0], place.coords[1]);
            }
        }
    });

    // Load place pins
    for (var i = 0; i < places.length; i++) {
        map.addPlace(i+1, places[i].coords[0], places[i].coords[1]);
    }
}


function load_editplace_map(place) {

    var map_opts = {
        zoom: 15,
        center: (place.coords) ? new google.maps.LatLng(place.coords[0], place.coords[1]) : default_location
    };
    var map = new GMap('map_canvas', map_opts);
    gmaps['edit_place'] = map;

    if (place.coords) {
        // Add place marker
        map.addPlace(place.num, place.coords[0], place.coords[1]);
    }
    else {  // Assume new place
        var gcode = function(address) {
            geocode_mq(address, function(obj) {
                if (obj.hasOwnProperty('displayLatLng')) {
                    var pnt = new google.maps.LatLng(obj.displayLatLng.lat, obj.displayLatLng.lng);
                    map.map.panTo(pnt);
                    if (map.place_pins.length === 0) {
                        map.addPlace(place.num, obj.displayLatLng.lat, obj.displayLatLng.lng);
                    }
                    else{
                        map.place_pins[0].setPosition(new google.maps.LatLng(obj.displayLatLng.lat, obj.displayLatLng.lng));
                    }
                }
            });
        };

        var update_pos = function() {
            var address = '';
            $.each($('.watch input').add('.watch select'), function(k, v){
                address += ' ' + $(v).val();
            });
            gcode(address);
        };

        // Update place marker on the map when the address values change
        $('.watch input').add('.watch select').blur(function() {
            if ($(this).val() === '') return;
            update_pos();
        });
        update_pos();
    }
}

function load_topic_map(options) {
    var map_opts = {
        zoom: data.map_zoom ? data.map_zoom : 13,
        center: new google.maps.LatLng(data.map_center[0], data.map_center[1]),
        zoomControlOptions: {
            position: google.maps.ControlPosition.RIGHT_BOTTOM,
            style: google.maps.ZoomControlStyle.SMALL
        }
    };
    utils.apply(map_opts, options);
    var map = new GMap('map_canvas', map_opts);
    gmaps['topic'] = map;

    // Load polys
    $.ajax({
        url: '/maps/aois/',
        type: 'get',
        data: {
            'topic': data.topic
        },
        success: function(obj) {
            if (obj.success) {
                for (var i = 0, ft_cnt=obj.data.mapdata.features.length; i < ft_cnt; i++) {
                    obj.data.mapdata.features[i].properties['style']['clickable'] = false;
                }
                map.addTopicPolys(obj.data.mapdata);
            }
        }
    });


    // Load places
    $.ajax({
        url: '/maps/topic_places/',
        type: 'get',
        data: {
            'topic': data.topic
        },
        success: function(places) {
            for (var i = 0, plc_cnt=places.length; i < plc_cnt; i++) {
                var coords = places[i];
                map.addUserPin(coords[0], coords[1]);
            }
        }
    });

    // for (var n = map_data.features.length - 1; n >= 0; n--) {
    //     map_data.features[n].properties['style']['clickable'] = false;
    // }

    // map.addTopicPolys(map_data);
    // map.addTopic(
    //     data.topic,
    //     data.category,
    //     data.map_center[0],
    //     data.map_center[1]
    // );
    // if (map.topic_pins.length > 0) {
    //     // Remove ability to view infobubble
    //     map.topic_pins[0].setOptions({'clickable': false});
    // }
}

/**
 * Load the home page map
 * @param  {Array} topics Array of topic id's and topic center coordinates.
 * [{"id": 1, "coords": [-121, 51],...}]
 * @return {null}
 */
function load_explore_map(topics, options) {
    var map_opts = {
        zoom: 13
    };
    utils.apply(map_opts, options);
    var map = new GMap('map_canvas', map_opts);
    gmaps['explore'] = map;
    // Init topic toolbar
    initCategoryToolbar(map);

    // Load topic pins
    for (var n=0, cnt=topics.length; n < cnt; n++){
        var topic = topics[n];
        map.addTopic(topic.id, topic.category, topic.coords[1], topic.coords[0], topic.plan_code);
    }

    var tiles_loaded_event = google.maps.event.addListener(map.map, 'tilesloaded', function(){
        map.fitExtentToMapData(map.TOPIC_PINS);
        google.maps.event.removeListener(tiles_loaded_event);
    });
}

function load_edit_map(options) {
    var map_opts = {
        zoom: data.map_zoom ? data.map_zoom : 13,
        center: new google.maps.LatLng(data.map_center[0], data.map_center[1]),
        zoomControlOptions: {
            style: google.maps.ZoomControlStyle.SMALL,
            position: google.maps.ControlPosition.RIGHT_BOTTOM,
        }
    };
    utils.apply(map_opts, options);
    var map = new GMap('map_canvas', map_opts);
    gmaps['editor'] = map;
    // Load places
    $.ajax({
        url: '/maps/topic_places/',
        type: 'get',
        data: {
            'topic': data.topic
        },
        success: function(places) {
            for (var i = 0, plc_cnt=places.length; i < plc_cnt; i++) {
                var coords = places[i];
                map.addUserPin(coords[0], coords[1]);
            }
        }
    });
    map.addTopicPolys(map_data);
}

function load_widgets_map(options) {
    var map_opts = {
        zoom: data.map_zoom ? data.map_zoom : 13,
        center: new google.maps.LatLng(data.map_center[0], data.map_center[1]),
        zoomControlOptions: {
            position: google.maps.ControlPosition.RIGHT_BOTTOM,
            style: google.maps.ZoomControlStyle.SMALL
        }
    };
    utils.apply(map_opts, options);
    var map = new GMap('map_canvas', map_opts);
    gmaps['editor'] = map;
    map.addTopicPolys(topic_geojson);
    // Load places
    $.ajax({
        url: '/maps/topic_places/',
        type: 'get',
        data: {
            'topic': data.topic
        },
        success: function(places) {
            for (var i = 0, plc_cnt=places.length; i < plc_cnt; i++) {
                var coords = places[i];
                map.addUserPin(coords[0], coords[1]);
            }
        }
    });
}