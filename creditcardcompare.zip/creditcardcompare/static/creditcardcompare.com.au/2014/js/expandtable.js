var selected_tab = false;
var _ccc_expandable = {
	tabs:[],
	parse:function(){
		$('div[expandtable]').each(this.initializer);
		$('.expandable-trigger').click(function(){
			selected_tab = '#reviews-tab';
			$(this).closest('.card1row').find('.card2optionsmore').trigger('click');
		});
	},
	initializer:function(){
		var tabs = _ccc_expandable.tabs;
		if(this.getAttribute('expandable') == 'enabled'){
			return;
		}
		this.setAttribute('expandable','enabled');
		var target = $(this);
		var c = target.children();
		var height = 0;

		//c.eq(2).children();
		//console.log(tabs);
		/*
		for(var i = 1 ; i<tabs.length; i++){
			height = Math.max(height,parseInt(tabs.eq(i).css('height')));
			//console.log(height,tabs.eq(i).height());
		}*/


		var op = {
			show:c.eq(0),
			hide:c.eq(1),
			content: c.closest('.card1columnwrapper').next(),
			visible:false,
			loaded:false,
			height:height
		};
		tabs.push(op);
		$(op.show).on('click',function(e){

			// hide others
			for(var i = 0 ; i<tabs.length ; i++){
				var o = tabs[i];
				if(o.visible){
					o.show.removeClass('hidden');
					o.hide.addClass('hidden');
					o.content.addClass('hidden');
					o.content.removeAttr('style');
					o.visible = false;
				}
			}
			// load if not loaded ::
			if(op.loaded == false){
				op.show.children().addClass('card2optionsanimation');
				op.hide.children().addClass('card2optionsanimation');
				op.content.load($(this).attr('offer'),null,function(){
					op.hide.children().delay(1000).queue(function() {
						op.show.children().removeClass('card2optionsanimation');
						op.hide.children().removeClass('card2optionsanimation');
						$(this).dequeue();
						afterLoad(this);
					});
					_ccc_table.parse();
					_ccc_stars.parse();
					// display table
					op.height = op.content.height();
					op.visible = true;
					op.show.addClass('hidden');
					op.hide.removeClass('hidden');
					op.content.removeClass('hidden');

					op.content.css('height',0);
					op.content.animate({height:op.height},1000,null,function(){
						op.content.removeAttr('style');
					});
				});
				op.loaded = true;
			} else {
				op.visible = true;
				op.show.addClass('hidden');
				op.hide.removeClass('hidden');
				op.content.removeClass('hidden');
				op.height = op.content.height();
				op.content.css('height',0);
				op.content.animate({height:op.height},1000,null,function(){
					op.content.removeAttr('style');
					afterLoad(this);
				});
			}


			//



			//$("html, body").animate({scrollTop:target.offset().top - navBarHeight - slidersBarHeight - tableHeadersHeight - 200}, '1500');
			$("html, body").animate({scrollTop:target.closest(".topofthecard").offset().top - 10}, '1500', function(){
				setTimeout(function(){ $("#magicnavbar").addClass("unpinned"); }, 1);
				setTimeout(function(){ $("#magicnavbar").removeClass("navbarScrolling"); }, 1);				
			});

			//$(document).scrollTop(target.offset().top - 10);

			// roll animation

			//op.content.css('height',0);
			//op.content.animate({height:op.height},1000);
		});

		$(op.hide).on('click',function(e){
			op.show.removeClass('hidden');
			op.hide.addClass('hidden');
			//op.content.addClass('hidden');
			//op.visible = false;
			op.content.animate({height:0},1000,null,function(){
				op.content.removeAttr('style');
				op.content.addClass('hidden');
				op.visible = false;
			});
		});
	}
};
function loadedDetails(event, xhr, settings){
	if (settings.url.indexOf('/bare/credit-cards/') != -1 && settings.type == 'GET'){
		return true;
	};
	return false;
};
function afterLoad(caller){
	if (selected_tab!=false){
		$(caller).closest('.card1row').find(selected_tab).trigger('click');
		selected_tab = false;
	};
};
$(function(){
	_ccc_expandable.parse();
	$(document).ajaxComplete(function(event, xhr, settings){
		try{
			if (isPagination(event, xhr, settings)){
				_ccc_expandable.parse();
			}
		}catch(e){}
	});
});
