from django.core.management.base import BaseCommand
from offers.core.models import Offer


CREDITCARDCOMPARE = 8

class Command(BaseCommand):
    def handle(self, *args, **options):
        amex_offers = Offer.objects.filter(is_active=True, category__slug='american-express-credit-cards')
        for offer in amex_offers:
            if offer.outbound_link and not offer.outbound_link_m:
                offer.outbound_link_m = offer.outbound_link
                offer.save()
            option = offer.site_options.filter(site__id=CREDITCARDCOMPARE)[0]
            if option.outbound_url and not option.outbound_url_m:
                option.outbound_url_m = option.outbound_url
                option.save()
            