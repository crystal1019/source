$(document).ready(function(){

	$("#id_account").ajaxForm(function(data){

		if(data.data.errors){
			$("#tab_account .help-block").empty();
			if(data.data.errors.postal_code){
				$("#tab_account input[name='postal_code']").siblings(".help-block").text(data.data.errors.postal_code[0]);
			}
			if(data.data.errors.address1){
				$("#tab_account input[name='address1']").siblings(".help-block").text(data.data.errors.address1[0]);
			}
			if(data.data.errors.city){
				$("#tab_account input[name='city']").siblings(".help-block").text(data.data.errors.city[0]);
			}
			if(data.data.errors.province){
				$("#tab_account .province-errors").text(data.data.errors.province[0]);
			}
			if(data.data.errors.country){
				$("#tab_account .country-errors").text(data.data.errors.country[0]);
			}
			if(data.data.errors.email){
				$("#tab_account input[name='email']").siblings(".help-block").text(data.data.errors.email[0]);
			}
		}else{
			$("#tab_account .help-block").empty();
			$("#details-alert").text(data.data.success);
			$("#details-alert").fadeIn();
		}
	});

	$("#manager-form").ajaxForm(function(data){
		var errors = data.data.errors;
		var err = '';

		if(errors){
			for (var field in errors) {
	            err += '<p>' + errors[field] + '</p>';
	        }
        $("#required-error").html(err).show();

		}else{
            $('#required-error')
                .removeClass('alert-error')
                .addClass('alert-info')
                .html('<h5>Invitation sent.</h5>')
                .show()
                .delay(3000)
                .slideUp('fast', function(){
                    $(this).hide();
            });
			$("#manager-add-alert").text(data.data.success);
			$("#manager-add-alert").fadeIn();
			$("#manager-form .control-group input").val('');

		}
	});

	$(".remove-manager").click(function(){
		$ele = $(this);
		$.ajax({
			type: "POST",
			url: $ele.data("url")+"remove-manager/",
			data: {
				manager: $ele.data("manager"),
				csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
			},
			success: function(data){
				$("#manager-remove-alert").text(data.data.response);
				$("#manager-remove-alert").fadeIn();
				$ele.parent().siblings(".span10").parent().fadeOut();
			}
		});
		return false;
	});



	$(".archive-topic").click(function(){
		$ele = $(this);
		dialog = new Dialog();

		dialog.setHeader("Archive Topic");
		dialog.static_content = $("<p style='padding:20px;padding-bottom:0px;'>This will archive your topic, putting it in a read only state.  This means that your participants can no longer contribute, and you can no longer edit.</p>\
			<p style='padding:20px;'>Are you sure?</p>\
			");
		dialog.show();
		$("#dialog-ok").click(function(){
			$.ajax({
				url: "/topic/archive/"+$ele.data("topic")+"/",
				type: "POST",
				data: {
					csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
				},
				success: function(data){
					dialog.close();
					dialog.reset();
					$ele.parent().parent().parent().parent().fadeOut();
				}
			});
		});

	});
	$("#create_psc").click(function(){
		$.ajax({
			url: '/dashboard/create_psc/',
			type: 'POST',
			data: {
				csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value,
				org_id: org_id
			},
			success: function(data){
				var $client = ich.ich_psc_client(data.data);
				$("#psc .toggle-list").prepend($client);
			}
		});
	});
	    /*

		return false;
	});
/*	FIX UP -  add URLs
	$("#change-plan").click(function(){

		return false;
	});
*/
});