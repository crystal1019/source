from django.conf.urls import patterns, url
from views import JSErrorView, Conversion

urlpatterns = patterns('',
    url(r'^error/$', JSErrorView.as_view(), name='email-error-notice'),
    url(r'^conversion/$', Conversion.as_view(), name='email-conversion-notice'),
)