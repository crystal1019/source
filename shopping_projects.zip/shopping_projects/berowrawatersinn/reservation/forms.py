from berowrawatersinn.reservation.models import *
from django import forms

def get_all_time(date=None):
    return  [[x.strftime("%H:%M"),x.strftime("%H:%M")] for x in MealType.objects.get_available_booking_times()] if not date else [[x.strftime("%H:%M"),x.strftime("%H:%M")] for x in MealType.objects.get_available_booking_times(date=date)]

def get_all_quantity(date=None,time=None):
    normal = range(1,7)
    if not date and not time:
        return [[str(x),str(x) if x != 6 else '6 and over'] for x in normal]
    
    return []

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
    
    def __init__(self, *args, **kwargs):
        super(BookingForm,self).__init__(*args, **kwargs)
        self.fields['date'].widget.attrs = {'readonly':'readonly'}
        self.fields['time'] = forms.ChoiceField(choices=get_all_time(), widget=forms.Select(attrs={'disabled':'disabled'}))
        self.fields['quantity'] = forms.ChoiceField(choices=get_all_quantity(), widget=forms.Select())
        self.fields['arrive_by'].empty_label ='- Please Select -'
        if args and args[0].get('date',''):
            date = args[0].get('date','')
            try:
                year,month,day = date.split('-')
                thedate = datetime.date(int(year),int(month),int(day))
                self.fields['time'].choices=get_all_time(date=thedate)
                self.fields['time'].widget.attrs = {}
            except:
                pass

    def clean_date(self):
       date = self.cleaned_data['date']
       if date:
           alltimes = MealType.objects.get_available_booking_times(date=date)
           if not alltimes:
               raise forms.ValidationError('This date is not available now, please choose another date.')
       return self.cleaned_data['date']      
    
    def clean_time(self):
        date = self.cleaned_data.get('date','')
        time = self.cleaned_data['time']
        if date and time:
            alltimes = MealType.objects.get_available_booking_times(date=date)
            alltimes = [x.strftime('%H:%M') for x in alltimes]
            if time not in alltimes:
                raise forms.ValidationError('This time is not available at that date now, please choose another time.')
        return self.cleaned_data['time']
    
    def clean_quantity(self):
        date = self.cleaned_data.get('date','')
        time = self.cleaned_data.get('time','')
        quantity = self.cleaned_data.get('quantity','')
        if date and time and quantity:
            mealtype = MealType.objects.get_mealtype(date,time)
            booked,total = SeatsByDate.objects.get_book_info(date,mealtype)
            if total != None:
                left = total - booked
                if quantity > left:
                    if left > 0:
                        raise forms.ValidationError('Sorry, only %s seats left on the day and time you chose.' %left)
                    else:
                        raise forms.ValidationError('Sorry, no seats left on the day and time you chose.' %left)
            
        return self.cleaned_data.get('quantity','')
                
            
