# Example usage:
# from PIL import Image

# print '#%02x%02x%02x' % get_dominant_color(Image.open('logo.jpg'))
#from PIL import Image
import Image
import colorsys

def hex_to_complement(h):
    c = hex_to_color(h)
    comp = []
    for col in c:
        new = 255-col
        comp = comp + [ new ]
    return comp

def hex_to_color(h):
    if h != None and len(h) == 6:
        r = h[0:2]
        g = h[2:4]
        b = h[4:6]
        r = int(r,16)
        g = int(g,16)
        b = int(b,16)
        return [ r, g, b ]
    else:
        return [ 255, 255, 255 ]

def color_to_hex(c):
    ret = None
    if c != None:
        ret = ""
        for col in c:
            ret+= '%02x' % col
    if ret == None or len(ret) != 6: # Something failed, pretend it was a white image
        ret = "ffffff"
    return ret

def get_color_stats(image_file):
    c  = get_dominant_color(image_file)
    ret = None
    if c != None:
        ret = '%02x%02x%02x' % c
    if ret == None or len(ret) != 6: # Something failed, pretend it was a white image
        ret = "ffffff"
        c = [255,255,255]
    return ret, c

def get_dominant_color(image_file):
    """
    Find a PIL image's dominant color, returning an (r, g, b) tuple.
    """
    image = Image.open(image_file)
    image = image.convert('RGBA')
    
    # Shrink the image, so we don't spend too long analysing color
    # frequencies. We're not interpolating so should be quick.
    image.thumbnail((200, 200))
    
    max_score = None
    dominant_color = None

    for count, (r, g, b, a) in image.getcolors(image.size[0] * image.size[1]):
        # Skip 100% transparent pixels
        if a == 0:
            continue
        
        # Get color saturation, 0-1
        saturation = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)[1]
        
        # Calculate luminance - integer YUV conversion from
        # http://en.wikipedia.org/wiki/YUV
        y = min(abs(r * 2104 + g * 4130 + b * 802 + 4096 + 131072) >> 13, 235)
        
        # Rescale luminance from 16-235 to 0-1
        y = (y - 16.0) / (235 - 16)
        
        # Ignore the brightest colors
        if y > 0.9:
            continue
        
        # Calculate the score, preferring highly saturated colors.
        # Add 0.1 to the saturation so we don't completely ignore grayscale
        # colors by multiplying the count by zero, but still give them a low
        # weight.
        score = (saturation + 0.1) * count
        
        if score > max_score:
            max_score = score
            dominant_color = (r, g, b)

    return dominant_color
