from google.appengine.ext import db
from google.appengine.api import images

from google.appengine.ext import blobstore
from google.appengine.ext.webapp import blobstore_handlers

from google.appengine.api import users

import objects
import masterpage

import method_user
import method_url
import method_notification
import method_db

import os

from google.appengine.api import images
from google.appengine.ext.webapp import template

class EditAvatar(blobstore_handlers.BlobstoreUploadHandler):
	def post(self):
		userinfo = method_user.getLoggedInUser()
		if not userinfo:
			self.redirectToLogin()
			return
		
		upload = self.get_uploads()[0]
		url = images.get_serving_url(upload.key())
		user_photo = UserPhoto(	userid = userinfo.uid,
								blob_key = upload.key(),
								image_url = url)
		method_db.put(user_photo)
		userinfo.image_url = url
		method_db.put(userinfo)

	def pushLoginInfo(self, template_values):
		user = method_user.getLoggedInUserFromCache()
		if user:
			url = users.create_logout_url(self.request.uri)
			name = user['name']
			uid = user['uid']
			template_values['favorites'] = method_user.getFavoritesForUser(user)
			template_values['favorite_forums'] = method_user.getFavoriteForumsForUser(user)
			template_values['favorite_users'] = method_user.getFavoriteUsersForUser(user)			
			template_values['favorite_attributes'] = method_user.getFavoriteAttributesForUser(user)
			template_values['favorite_forum_all'] = method_user.getFavoriteForumAllForUser(user)
			template_values['notification_count'] = method_notification.getNotificationCountForUser(users.get_current_user(), uid)
			template_values['reputation'] = user['reputation']
		else:
			url = users.create_login_url(self.request.uri)
			uid = None
			name = ''
		is_admin = method_user.userIsAdmin()
		template_values['admin'] = is_admin
		template_values['name'] = name
		template_values['url'] = url  
		template_values['uid'] = uid

	def pushPage(self, template_values, page_title, filepath):
		self.pushLoginInfo(template_values)	
		template_values['body'] = self.getBody(template_values, filepath)
		ref = method_url.getStringParam(self, 'ref')
		template_values['ref'] = ref
		#template_values['attributes_menu'] = masterpage.renderAttributeMenus(self)
		template_values['page_title'] = page_title
		#template_values['country'] = self.getCountry()
		#template_values['isMobile'] = self.isMobile()
		self.response.out.write(self.getBody(template_values, filepath))

	def getBody(self, template_values, filepath):
		path = os.path.join(os.path.dirname(__file__), filepath)
		return template.render(path, template_values)

	def get(self):
		user = method_user.getLoggedInUser()
		if not user:
			self.redirectToLogin()
			return	
			
		upload_url = blobstore.create_upload_url('/editavatar')	
		
		template_values = {
			'upload_url': upload_url,
			'image_url': user.image_url,
		}		 
		
		self.pushPage(template_values, 'Edit Avatar', 'html/editavatar.html')   
		
