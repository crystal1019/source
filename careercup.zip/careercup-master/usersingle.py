from google.appengine.api import users
import masterpage
import math

import method_user
import method_url
import method_cache
import method_db
import method_notification
import method_user

class ViewUserSingle(masterpage.MasterPage):
	def getQuestions(self, author_id):
		return method_user.getQuestionsByUser(author_id)
		
	def getForumPosts(self, author_id):
		# Get questions.
		query = method_db.addInfoToList(method_user.getForumsByUser(author_id))
		forum_list = []
		for forum in query:
			forum.read_url = 'forumpost'
			forum.edit_url = 'addforum'
			forum.vote_type = 'forum'
			forum_list.append(forum)
		return forum_list

	def getComments(self, author_id, page):
		# Get questions.
		query = method_db.addInfoToList(method_user.getCommentsByUser(author_id, page))
		comment_list = []
		for comment in query:
			if method_url.getUrlWithType(comment.type) and comment.ancestor_id:
				comment.url = '/' + method_url.getUrlWithType(comment.type) + '?id=' + str(comment.ancestor_id)
				comment.vote_type = 'comment'
				comment.independent = True				 
				comment_list.append(comment)
		return comment_list

	def getFollows(self, user):
		follows_userids = method_user.getFavoriteUsersForEmailAndId(user.user.email(), user.uid)			
		follows = method_user.getUsersInList(follows_userids)
		return follows

	def get(self):
		key_string = method_url.getId(self)
		logged_in_user = method_user.getLoggedInUser()
		if key_string: # if you have an id specified
			key = method_url.getId(self)
			if not key or key == 0:
				self.displayError('Error: User Does Not Exist', 'There is no user with this id.  Please hit the BACK key.  <br/><br/> If you think this is in error, please report this bug <a href="https://careercup.wufoo.com/forms/careercup-bug-report/">here</a>.')
				return
			# Get user.
			user = method_user.getUserWithId(key)
			if not user:
				self.displayError('Error: User Does Not Exist', 'There is no user with this id.  Please hit the BACK key.  <br/><br/> If you think this is in error, please report this bug <a href="https://careercup.wufoo.com/forms/careercup-bug-report/">here</a>.')
				return				
		else:
			user = logged_in_user
			if not user:
				self.redirectToLogin()
				return
			
		page = method_url.getIntParam(self, 'n') 
		if page is None:
			page = 1
		user_html = method_cache.getObjectForTypeAndKey(method_user.cache_key_user_page_body, str(user.uid))	
		user_title = method_cache.getObjectForTypeAndKey(method_user.cache_key_user_page_title, str(user.uid))
		if not user_html or not user_title:
			if not user:
				self.redirect(users.create_login_url(self.request.uri))
				return
				
			please_contact = None
			name = user.name
			uid = user.uid
			about_me = user.blurb
			resume = user.resume_text
			if about_me == '':
				about_me = None
			if not(resume):
				resume = ''
				
			if user.please_contact:
				please_contact = "yes"
			labels = user.link_labels
			urls = user.link_urls
			count = len(labels)
			if len(urls) < count:
				count = len(urls)
			links = []
			for i in range(0, count):
				link = {'url': urls[i], 'label': labels[i]}
				links.append(link)
			
			loggedin_user = method_user.getLoggedInUser()
			if loggedin_user:
				loggedin_username = loggedin_user.name
			else:
				loggedin_username = ''
				
			questions = self.getQuestions(uid)
			forums = self.getForumPosts(uid)
			comments = self.getComments(uid, page)
			followers = method_user.getFollowers(user.uid)		
			follows = self.getFollows(user)
			
			user.comment_count = method_db.refreshCommentCountByUser(user)
				
			template_values = {
				'username': name,
				'userid': uid,
				'links': links,
				'about_me': about_me,
				'resume': resume,
				'please_contact': please_contact,
				'job_id': user.job_id_pretty,
				'job_name': user.job_name,			  
				'company_id': user.company_id_pretty,
				'company_name': user.company_name,	
				'avatar': user.image,
				'reputation': int(round(user.reputation)),
				'comments': comments,
				'loggedin_username': loggedin_username,
				'questions': questions,
				'followers': followers,
				'follows': follows,
				'forums': forums,
				'comments': comments,
				'is_admin': user.admin,
				'next_page' : page + 1,
				'current_page' : page,
				'prev_page' : page - 1,
				'pages_all' : range(1, int(math.ceil(user.comment_count / method_user.comments_per_page)) + 2),				
			}
			user_html = self.getBody(template_values, 'html/user.html')
			#user_html = name.encode('utf-8') + '###TITLE###' + user_html
			method_cache.setObjectForTypeAndKey(method_user.cache_key_user_page_body, str(user.uid), user_html)
			method_cache.setObjectForTypeAndKey(method_user.cache_key_user_page_title, str(user.uid), name.encode('utf-8'))			

		if method_url.getIntParam(self, "mark") and user != None:
			method_notification.markUserAsRead(logged_in_user, user.uid)			
			
		template_values = {}
		template_values['rendered_body'] = user_html
		self.pushPage(template_values, user_title, 'html/usersingle.html')				