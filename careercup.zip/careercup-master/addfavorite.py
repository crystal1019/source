import masterpage

import method_db
import method_user
import method_question
import method_notification
import method_forum
import logging
	
class AddFavorite(masterpage.MasterPage):
	def post(self):
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if not user:
			self.response.out.write('login');
			return

		val = int(self.request.get('val'))
		item_type = self.request.get('item_type')
		
		if item_type == 'forum-all':
			if val == 1:
				user.favorite_forum_all = True
			else:
				user.favorite_forum_all = False
			result = val			
		else:
			if item_type == 'question':	
				item_id = int(self.request.get('itemId'))
				item = method_question.getQuestionWithId(item_id)
				favorites = user.favorites
				if item == None:
					return
			elif item_type == 'forumpost':	
				item_id = int(self.request.get('itemId'))
				item = method_forum.getForumPostWithId(item_id)
				favorites = user.favorite_forums 
				if item == None:
					return	
			elif item_type == 'user':	
				item_id = int(self.request.get('itemId'))
				item = method_user.getUserWithId(item_id)
				favorites = user.favorite_users
				if item == None:
					return								
			elif item_type == 'attribute':
				item_id = self.request.get('itemId')
				item = method_question.getAttributeWithPid(item_id)
				favorites = user.favorite_attributes
				if item == None:
					return
			else:
				return
		
			# notify user of follow and give reputation points
		
			if val == 1: 
				if item_id in favorites:
					pass
				else:
					favorites.append(item_id)
					if (item_type == 'question' or item_type == 'forumpost') and item.author_id is not None:
						author = method_user.getUserWithId(item.author_id)
						method_notification.notifyUserOfFavorite(user, author, item, item_type)
						method_user.incrementReputation(author, method_user.favorite_multiplier)
					elif item_type == 'user':
						method_notification.notifyUserOfFavorite(user, item, item, item_type)
						method_user.incrementReputation(item, method_user.favorite_multiplier)
							
			elif val == -1:
				if item_id in favorites:
					favorites.remove(item_id)
					if (item_type == 'question' or item_type == 'forumpost') and item.author_id is not None:
						author = method_user.getUserWithId(item.author_id)
						method_user.incrementReputation(author, -1 * method_user.favorite_multiplier)
					elif item_type == 'user':
						method_user.incrementReputation(item, -1 * method_user.favorite_multiplier)
				else:
					pass	
			if item_id in favorites:
				result = 1
			else:
				result = -1
			if item_type == 'question':
				user.favorites = favorites
			elif item_type == 'attribute':
				user.favorite_attributes = favorites
			elif item_type == 'forumpost':
				user.favorite_forums = favorites
			elif item_type == 'user':
				user.favorite_users = favorites				
		method_db.putObject(user)
		self.response.out.write(result)			