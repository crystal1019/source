from google.appengine.api import users

import objects
import masterpage

import method_forum
import method_db
import method_url
import method_user
import method_comment
import method_notification
	
class AddForum(masterpage.MasterPage):
	def post(self):				  
		if self.isSpammer():
			return
			
		message_thread = method_forum.getForumPostWithId(method_url.getId(self))
		user = method_user.getLoggedInUser()	
		
		method_forum.clearCache(message_thread)	
			
		if self.request.get('MoveToQuestion'):
			question = objects.Question()
			question.author_id = message_thread.author_id
			question.author_name = message_thread.author_name
			question.author_image = message_thread.author_image	
			question.text = message_thread.text
			question.date = message_thread.date
			question.comment_count = message_thread.comment_count
			question.votes_total = message_thread.votes_total
			question.votes_net = message_thread.votes_net
			question_id = method_db.putObject(question)
			comments = method_comment.getCommentsWithAncestor(message_thread.uid)
			for comment in comments:
				self.response.out.write('Changed to question ' + str(question_id))
				comment.type = 'question'
				comment.ancestor_id = question_id
				if comment.parent_id == message_thread.uid:
					comment.parent_id = question_id
				method_db.putObject(comment)
				
			message_thread.visible = False
			method_db.putObject(question)	
			
		# Get forum post.
		if not message_thread or not(message_thread.is_admin):
			self.redirect('/forumpost?id=' + str(id))
			return
				
		delete_action = self.request.get('Delete')
		if delete_action:
			method_forum.deleteForumPost(message_thread)
			self.displayError('Forum Post Deleted', 'Thank you.  Your forum post has been deleted.')
		else:
			# Set user, but don't override the current one
			if not(message_thread.author_id) and not(message_thread.author_name):
				if user:
					message_thread.author_id = user.uid
					message_thread.author_name = user.name
					message_thread.author_image = user.image
				else:
					name = self.request.get('name')
					if not(name):
						name = 'Anonymous'
					message_thread.author_name = name
			
			subject = self.request.get('subject')
			message = self.request.get('message')
			if self.hasBannedText(message):
				self.response.out.write('Hey, please stop spamming us. I don\'t do that to your site, do I? Then don\'t do it to mine.')
				return			
			if subject == '' or message == '' or subject is None or message is None:
				self.putErrorMessage('Please fill out all required fields.')		
				return
		
			message_thread.subject = subject
			message_thread.text = message
			
			if user:
				message_thread = method_user.subscribeWithDelay(user, message_thread)
			
			# TODO(gayle): HTML encoding
			method_db.putObject(message_thread)
			method_notification.notifyUsersOfForum(message_thread)
			self.addActivity(message_thread.author_name, '/forumpost?id=' + str(id), '/images/forum_activity.png', 'forum', None, None, message_thread.text)				
			
			self.redirect('/forumpost?id=' + str(id))
		
	def putErrorMessage(self, error_message):		
		self.request.get('lblError')
		error_message		  
		#self.response.out.write('<script>control = document.getElementById("lblError"); control.value = error_message; </script>')
	
		#path = os.path.join(os.path.dirname(__file__), 'html/addquestion.html')
		#self.response.out.write(template.render(path, template_values)) 
	
	def get(self):
		error_message = ''
		
		method_url.getId(self)
		forum_id = method_url.getId(self)
		
		if method_user.getLoggedInUser() is None:
			self.redirectToLogin()	
			return			
		
		name = None
		if users.get_current_user():
			name = users.get_current_user().nickname()
		subject_text = None
		message_text = None
		author_name = None
		
		if forum_id:
			message_thread = method_forum.getForumPostWithId(forum_id)
			if not(message_thread.is_admin) and not(method_user.userIsAdmin()):
				self.redirect('/forumpost?id=' + str(forum_id))
				return
			
			subject_text = message_thread.subject
			message_text = message_thread.text
			author_name = message_thread.author_name
		
		template_values = {
			'name': name,
			'parent_tab': 'forum',	
			'author_name': author_name,
			'subject_text': subject_text,
			'message_text': message_text,
			'error_message': error_message,
		}		 
		
		self.pushPage(template_values, 'Post to Forum', 'html/addforum.html')	
		
