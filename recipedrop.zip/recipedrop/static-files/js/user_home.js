$(document).ready(function () {
    var visible_notifications = [];

    function send_visible_notifications() {
        $('input[name=viewed_notifications]').val(
            JSON.stringify(visible_notifications)
        );
        $('#viewed_notifications').find('form').
            find('input[type=submit]').click();
    }

    function viewed_notifications_sent() {
        visible_notifications = [];
    }

    function init_notifications() {
        var $noti_form;

        $('.notification_view').each(function (i, elem) {
            if ($(elem).hasClass('dismiss_on_view')) {
                var id = $(elem).val();
                visible_notifications.push(id);
            }
        });

        $('.dismiss_notification').click(function () {
            var nid = $(this).attr('data-notification');
            visible_notifications.push(nid);
            send_visible_notifications();
            $(this).parents('div.alert').remove();
        });

        $noti_form = $('#viewed_notifications').find('form');
        $noti_form.ajaxify(util.ajax_form_opts($noti_form,
                                               viewed_notifications_sent));

        send_visible_notifications();
    }

    function init_friend_req() {
        // friend request approval

        function friend_form_submitted($form) {
            return function (resp) {
                $form.parents('.approve_container').find('h4').html(resp);
            };
        }

        var $friend_form = $('.friend_approve_form').find('form');
        $('.approve').click(function () {
            $(this).parents('.approve_container').
                find('form').find('input[type=submit]').click();
        });

        $friend_form.each(function (i, form) {
            var $form = $(form);
            $form.ajaxify(util.ajax_form_opts($form,
                                              friend_form_submitted($form)));
        });
    }

    function init_bookmarklet_alert() {
	var $close = $(".bookmarklet-alert .close");
	var hide = localStorage["hide_bookmarklet_alert"];

	$close.click(function () {
	    localStorage["hide_bookmarklet_alert"] = true;
	});

	if (hide) {
	    $close.click();
	}
    }

    init_notifications();
    init_friend_req();
    init_bookmarklet_alert();
});