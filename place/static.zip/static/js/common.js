// Source: http://www.quirksmode.org/js/detect.html
var BrowserDetect = {
    init: function() {
        this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
        this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "an unknown version";
        this.OS = this.searchString(this.dataOS) || "an unknown OS";
    },
    searchString: function(data) {
        for (var i = 0; i < data.length; i++) {
            var dataString = data[i].string;
            var dataProp = data[i].prop;
            this.versionSearchString = data[i].versionSearch || data[i].identity;
            if (dataString) {
                if (dataString.indexOf(data[i].subString) != -1)
                    return data[i].identity;
            } else if (dataProp)
                return data[i].identity;
        }
    },
    searchVersion: function(dataString) {
        var index = dataString.indexOf(this.versionSearchString);
        if (index == -1) return;
        return parseFloat(dataString.substring(index + this.versionSearchString.length + 1));
    },
    dataBrowser: [{
        string: navigator.userAgent,
        subString: "Chrome",
        identity: "Chrome"
    }, {
        string: navigator.userAgent,
        subString: "OmniWeb",
        versionSearch: "OmniWeb/",
        identity: "OmniWeb"
    }, {
        string: navigator.vendor,
        subString: "Apple",
        identity: "Safari",
        versionSearch: "Version"
    }, {
        prop: window.opera,
        identity: "Opera",
        versionSearch: "Version"
    }, {
        string: navigator.vendor,
        subString: "iCab",
        identity: "iCab"
    }, {
        string: navigator.vendor,
        subString: "KDE",
        identity: "Konqueror"
    }, {
        string: navigator.userAgent,
        subString: "Firefox",
        identity: "Firefox"
    }, {
        string: navigator.vendor,
        subString: "Camino",
        identity: "Camino"
    }, { // for newer Netscapes (6+)
        string: navigator.userAgent,
        subString: "Netscape",
        identity: "Netscape"
    }, {
        string: navigator.userAgent,
        subString: "MSIE",
        identity: "Explorer",
        versionSearch: "MSIE"
    }, {
        string: navigator.userAgent,
        subString: "Gecko",
        identity: "Mozilla",
        versionSearch: "rv"
    }, { // for older Netscapes (4-)
        string: navigator.userAgent,
        subString: "Mozilla",
        identity: "Netscape",
        versionSearch: "Mozilla"
    }],
    dataOS: [{
        string: navigator.platform,
        subString: "Win",
        identity: "Windows"
    }, {
        string: navigator.platform,
        subString: "Mac",
        identity: "Mac"
    }, {
        string: navigator.userAgent,
        subString: "iPhone",
        identity: "iPhone/iPod"
    }, {
        string: navigator.platform,
        subString: "Linux",
        identity: "Linux"
    }]

};
BrowserDetect.init();

// Send javascript errors to server.
window.onerror = function(message, url, lineNumber) {
    var beacon = new Image();
    var q = 'm=' + message + '&u=' + url + '&l=' + lineNumber;    
    beacon.src = '/jserr/log/?' + q;
    return false; // Allows default handler to happen
};

// Collect browser info.
window.onload = function() {
    var beacon = new Image();
    var q = 'b=' + BrowserDetect.browser + '&v=' + BrowserDetect.version + '&os=' + BrowserDetect.OS;    
    beacon.src = '/browser/?' + q;
    return false; // Allows default handler to happen
};


function debug(msg) {
    console.log(msg);
}

var utils = {
    _increment: -1,
    createId: function() {
        this._increment++;
        return "placespeak_" + this._increment;
    },
    // Apply only options to an object if they
    // already exist in the object.
    applyIf: function(object, options) {
        if (!options) return;
        for (var key in options) {
            if (key in object) {
                object[key] = options[key];
            }
        }
    },
    apply: function(object, options) {
        if (!options) return;
        for (var key in options) {
            object[key] = options[key];
        }
    },
    inArray: function(val, arr) {
        for (var i = 0, cnt = arr.length; i < cnt; i++) {
            if (val === arr[i]) {
                return true;
            }
        }
        return false;
    },
    join: function(object, delimiter) {
        var arr = [];
        for (var k in object) {
            arr.push(k + '=' + object[k]);
        }
        return arr.join(delimiter);
    },
    current_date: function() {
        var d = new Date();
        var curr_date = d.getDate();
        var curr_month = d.getMonth() + 1; //Months are zero based
        var curr_year = d.getFullYear();
        return curr_month + "/" + curr_date + "/" + curr_year;
    },
    current_time: function() {
        var d = new Date();
        var curr_hour = d.getHours();
        if (curr_hour >= 0 && curr_hour < 10) {
            curr_hour = '0' + curr_hour;
        } else if (curr_hour > 12) {
            curr_hour = curr_hour - 12;
        }

        var curr_min = d.getMinutes() + 1; //Months are zero based
        var suffix = 'PM';
        if (curr_hour >= 0 && curr_hour < 12) {
            suffix = 'AM';
        }

        return curr_hour + ":" + curr_min + ' ' + suffix;
    },
    parseUri: function(url) {
        var result = {};
        var anchor = document.createElement('a');
        anchor.href = url;
        var keys = 'protocol hostname host pathname port search hash href'.split(' ');
        for (var keyIndex in keys) {
            var currentKey = keys[keyIndex];
            result[currentKey] = anchor[currentKey];
        }
        result.toString = function() {
            return anchor.href;
        };
        result.requestUri = result.pathname + result.search;
        return result;
    },
    getQueryVariable: function(query, variable) {
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        return;
    },
    pluralize: function(num, singular_suffix, plural_suffix) {
        if (num === 0) {
            if (arguments.length === 2) {
                return '';
            } else {
                return singular_suffix;
            }
        } else {
            if (arguments.length === 3) {
                return plural_suffix;
            } else {
                return arguments[1];
            }
        }
    },
    imgNaturalSize: function(img, callback) {
        if (!img) return null;
        if (img.hasOwnProperty('naturalWidth')) {
            return {
                width: img.naturalWidth,
                height: img.naturalHeight
            };
        } else {
            var i = new Image();
            i.onload = function() {
                callback({
                    width: i.width,
                    height: i.height
                });
            };
            i.src = img;
        }
    }
};


/**
 * Add extra event tracking to google analytics.
 * @param  {string} category Category describes a group of objects you want to track
 * @param  {string} action The action is uniquely paired with each category, and
 * commonly used to define the type of user interaction for the object.
 * @param  {string} label label is optional parameters and provide additional dimensions and numerical data about the event
 * @param  {string} value value is optional parameters and provide additional dimensions and numerical data about the event
 * @return N/A
 */
function ga_tracker(category, action) {

    // Comment out for now until performance
    // tests can be done in older IE versions.

    /*
    _gaq.push([
        '_trackEvent',
        category,
        action,
        'url',
        window.location.pathname,
        true
    ]);
    */
}

// Scroll to an element.  Element needs an id.
function scrollToElement(element) {
    var top = $(element).offset().top;
    var padding = 50;
    if ((top - padding) > 0) {
        top -= padding;
    }
    $('html, body').animate({
        scrollTop: top
    }, 1000);
}

function redirect_to_login(next) {
    var path = next || window.location.pathname;
    window.location.href = '/login/?next=' + path;
}

/**
 * MicroEvent - to make any js object an event emitter (server or browser)
 *
 * - pure javascript - server compatible, browser compatible
 * - dont rely on the browser doms
 * - super simple - you get it immediatly, no mistery, no magic involved
 *
 * - create a MicroEventDebug with goodies to debug
 *   - make it safer to use
 */

var MicroEvent = function() {};
MicroEvent.prototype = {
    bind: function(event, fct) {
        this._events = this._events || {};
        this._events[event] = this._events[event] || [];
        this._events[event].push(fct);
    },
    unbind: function(event, fct) {
        this._events = this._events || {};
        if (event in this._events === false) return;
        this._events[event].splice(this._events[event].indexOf(fct), 1);
    },
    trigger: function(event /* , args... */ ) {
        this._events = this._events || {};
        if (event in this._events === false) return;
        for (var i = 0; i < this._events[event].length; i++) {
            this._events[event][i].apply(this, Array.prototype.slice.call(arguments, 1));
        }
    }
};

/**
 * mixin will delegate all MicroEvent.js function in the destination object
 *
 * - require('MicroEvent').mixin(Foobar) will make Foobar able to use MicroEvent
 *
 * @param {Object} the object which will support MicroEvent
 */
MicroEvent.mixin = function(destObject) {
    var props = ['bind', 'unbind', 'trigger'];
    for (var i = 0; i < props.length; i++) {
        if (typeof destObject === 'function') {
            destObject.prototype[props[i]] = MicroEvent.prototype[props[i]];
        } else {
            destObject[props[i]] = MicroEvent.prototype[props[i]];
        }
    }
}

// export in common js
if (typeof module !== "undefined" && ('exports' in module)) {
    module.exports = MicroEvent;
}


function Dialog(src, parameters, options, static_content) {

    // PROPERTIES
    this.src = src;
    this.parameters = parameters;
    this.size = 'normal'; // small, normal, large, fullscreen
    this.src_data = null;
    this.static_content = static_content;

    this.events = {
        'beforeshow': [],
        'aftershow': [],
        'show': [],
        'close': [],
        'error': [],
        'ok': []
    };

    this._current_scroll = 0;
    this._dg = $('#dialog');
    this._original_content = $('#dialog').html();
    this._dg_body = this._dg.find('.modal-body');
    this._dg_btn_1 = this._dg.find('#dialog-cancel');
    this._dg_btn_2 = this._dg.find('#dialog-ok');

    utils.applyIf(this, options);
    this._dg_btn_2.removeClass('disabled');
}
Dialog.prototype.constructor = Dialog;

/**
 * Add event listener.
 * @param  {string}   event    Event name.
 * @param  {Function} callback Callback to assign to event.
 * @return {object}            Return form editor instance back.
 */
Dialog.prototype.on = function(event, callback) {
    this.events[event] = this.events[event] || [];
    this.events[event].push(callback);
    return this;
};

/**
 * Remove event listener.
 * @param  {string}    event    Event name.
 * @param  {Function}  callback Callback assigned to event.
 * @param  {boolean}   clear   Optional, Clear all callbacks assigned to event.
 * @return {object}            Return form editor instance back.
 */
Dialog.prototype.off = function(event, callback, clear) {
    if (clear) {
        this.events[event] = [];
    } else {
        var e = this.events[event];
        for (var i = 0, fx_cnt = e.length; i < fx_cnt; i++) {
            if (e[i] === callback) {
                e.splice(i, 1);
            }
        }
    }
    return this;
};

/**
 * Execute all functions assigned to an event.
 * @param  {string} event Name of event.
 * @return {null}
 */
Dialog.prototype.fire = function(event) {
    var e = this.events[event];
    for (var i = 0, fx_cnt = e.length; i < fx_cnt; i++) {
        var args = Array.prototype.slice.call(arguments, 1);
        e[i].apply(e[i], args);
    }
    return null;
};


/**
 * Set the button label for the ok button.
 * @param {string/html} label Button label.
 */
Dialog.prototype.setButton1Label = function(label) {
    this._dg_btn_1.html(label);
};


/**
 * Set the button label for the cancel button.
 * @param {string/html} label Button label.
 */
Dialog.prototype.setButton2Label = function(label) {
    this._dg_btn_2.html(label);
};

/**
 * Set the content for the dialog
 * @param {string} html HTML markup to add to the dialog.
 */
Dialog.prototype.setContent = function(html) {
    this._dg_body.html(html);
};

// Bind events for Dialog
Dialog.prototype._bindEvents = function() {
    var self = this;

    // Ok button click
    // setup this way so it can be overridden
    this._dg_btn_2.on('click', function() {
        self.fire('ok');
    });

    // Dialog shown
    this._dg.on('shown', function() {
        self.fire('show');
    });

    // Dialog closed
    this._dg.on('hidden', function() {
        self._unbindEvents();
        // Timeout to compensate for bootstrap close transition
        setTimeout(function() {
            self.fire('close');
        }, 525);

        // Unlock window scrollbars
        self._toggle_scroll();
        $('.modal-backdrop').remove();
    });
};

// Unbind events for Dialog
Dialog.prototype._unbindEvents = function() {
    this._dg_btn_2.off('click');
    this._dg.off('shown');
    this._dg.off('hidden');
};

Dialog.prototype._toggle_scroll = function() {
    var self = this;
    if ($('#dialog').is(":visible")) { // Lock
        self._current_scroll = $(window).scrollTop();
        $(window).unbind('scroll', function() {
            $(window).scrollTop(self._current_scroll);
        });
    } else { // Unlock
        self._current_scroll = $(window).scrollTop();
        $(window).bind('scroll');
    }
};

/**
 * [show description]
 * @return {[type]} [description]
 */
Dialog.prototype.show = function() {
    // Lock window scrollbars
    this._toggle_scroll();

    this._bindEvents();
    this.fire('beforeshow');
    // Clear existing size classes
    this._dg.removeClass('small').removeClass('large');
    // Apply dialog size.
    if (this.size != 'normal') {
        this._dg.addClass(this.size);
    }
    var self = this;

    if (self.src) {

        $.ajax({
            url: self.src,
            type: 'GET',
            data: self.parameters,
            dataType: 'json',
            success: function(obj) {
                if (obj.success) {
                    if (self.size == 'fullscreen') {
                        self._adjust_height();
                    }
                    if (obj.hasOwnProperty('html')) {
                        self.src_data = obj.data;
                        self.setContent(obj.html);
                        self._dg.modal({
                            show: true,
                            backdrop: 'static'
                        });
                    } else {
                        self.setContent('');
                    }
                } else {
                    if (obj.reason && obj.reason === 'login_required') {
                        redirect_to_login();
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                self.fire('error', errorThrown);
            },
            complete: function() {
                self.fire('aftershow');
            }
        });
    } else if (self.static_content) {
        self.setContent(self.static_content);
        self._dg.modal({
            show: true,
            backdrop: 'static'
        });
    }
};

// Adjust height is for size="fullscreen"
Dialog.prototype._adjust_height = function() {
    var header_h = $('#dialog header').outerHeight();
    var footer_h = $('#dialog .modal-footer').outerHeight();
    var window_h = $(window).outerHeight() * 0.9;
    this._dg_body.height(window_h - footer_h - header_h);
};

Dialog.prototype.close = function() {
    this._dg.modal('hide');
};

//Resets dialog back to default if any layout has been changed
Dialog.prototype.reset = function() {
    $("#dialog").html(this._original_content);
};

//Adds title div
Dialog.prototype.setHeader = function(content) {
    $("#dialog").prepend('<div class="modal-header" />');
    $(".modal-header").append('<h3>' + content + '</h3>');
};


/*

    FORM EDITOR

 */

function FormEditor(form, src, parameters, options) {

    Dialog.call(this, src, null, options);

    // PROPERTIES
    this.form = form;
    this.parameters = parameters;
    this.size = 'normal'; // small, normal, large
    this.include_submit = true;
    this.response_type = 'json';


    this.events = {
        'beforeshow': [],
        'show': [],
        'close': [],
        'error': [],
        'ok': [],
        'success': []
    };

    this._dg = $('#dialog');
    this._dg_body = this._dg.find('.modal-body');
    this._dg_btn_1 = this._dg.find('#dialog-cancel');
    this._dg_btn_2 = this._dg.find('#dialog-ok');

    utils.applyIf(this, options);
}
FormEditor.prototype.constructor = FormEditor;
FormEditor.prototype = new Dialog();

/**
 * Submit the defined form in the dialog.
 * @return {boolean} Always returns false.
 */
FormEditor.prototype.submit = function() {
    var self = this;
    $('#' + this.form).ajaxSubmit({
        type: 'POST',
        clearForm: false,
        resetForm: false,
        dataType: self.response_type,
        success: function(obj, statusText, xhr, $form) {
            if (self.response_type !== 'json') {
                if (obj.slice(0, 4).toLowerCase() == '<pre' && obj.slice(-6).toLowerCase() == '</pre>') {
                    obj = $(obj).html(); // Get contents of pre.
                } else if (obj.slice(0, 9).toLowerCase() == '<textarea' && obj.slice(-11).toLowerCase() == '</textarea>') {
                    obj = $(obj).val(); // Get contents of textarea.
                }
                obj = JSON.parse(obj);
            }
            if (obj.success) {
                self.fire('success', obj);
                self.close();
            } else {
                self.setContent(obj.html);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            self.fire('error', jqXHR, textStatus, errorThrown);
        }
    });
    return false;
};

// Bind events for FormEditor
FormEditor.prototype._bindEvents = function() {
    Dialog.prototype._bindEvents.call(this);
    var self = this;
    // Ok button click
    // setup this way so it can be overridden
    this.on('ok', function() {
        self.submit();
    });

    // On Enter key for inputs
    this._dg.find('input').keypress(function(e) {
        if (e.which == 13) {
            self.submit();
        }
    });
};

// Unbind events for FormEditor
FormEditor.prototype._unbindEvents = function() {
    Dialog.prototype._unbindEvents.call(this);
    this._dg.find('input').off('keypress');
};


// Google Translate init.
function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en',
        gaTrack: true,
        gaId: 'UA-20187821-1',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, 'google_translate_element');
    $('.goog-te-menu-value :first').text('Translate');
}


function close_dialog(title, msg, aftershow_callback) {

    var opts = {
        button1: '',
        button2: 'Close'
    };

    var dg = new Dialog('/confirmation_dialog/', {
        'title': title,
        'message': msg
    });

    dg.setButton1Label(opts.button1);
    dg.setButton2Label(opts.button2);

    dg.on('ok', function() {
        dg.close();
    });

    if (aftershow_callback) {
        dg.on('aftershow', function() {
            aftershow_callback();
        });
    }


    dg.show();
}

function publisher_dialog(title, msg, aftershow_callback) {

    var opts = {
        button1: '',
        button2: 'Close'
    };

    var dg = new Dialog('/confirmation_dialog/', {
        'title': title,
        'message': msg
    });

    dg.setButton1Label(opts.button1);
    dg.setButton2Label(opts.button2);

    dg.on('ok', function() {
        dg.close();
    });

    if (aftershow_callback) {
        dg.on('aftershow', function() {
            aftershow_callback();
        });
    }

    dg.size = 'large';

    dg.show();
}

//
function confirmation_dialog(title, msg, yes_callback, no_callback, options) {

    var default_options = {
        button1: 'No',
        button2: 'Yes'
    };

    var opts = default_options;
    if (options) {
        utils.apply(opts, options);
    }
    var dg = new Dialog('/confirmation_dialog/', {
        'title': title,
        'message': msg
    });
    dg.setButton1Label(opts.button1);
    dg.setButton2Label(opts.button2);
    dg.on('ok', function() {
        if (yes_callback) {
            yes_callback();
        }
        dg.close();
    });

    dg.on('close', function() {
        if (no_callback) {
            no_callback();
        }
    });
    dg.show();
}
//A-la-Cart in pricing page
function alacart_dialog(title, msg, yes_callback) {
    //src, parameters, options, static_content
    var dg = new Dialog('/confirmation_dialog/', {
        'title': title,
        'message': msg
    });
    dg.size = 'large';
    dg.setButton1Label('');
    dg.setButton2Label('Ok');
    dg.on('ok', function() {
        yes_callback();
        dg.close();
    });
    dg.show();
}

function admin_invite(elem, invite, role, topic, response) {
    if (response === 'd' || response === 'a') {
        $.ajax({
            url: '/invitation_response/',
            type: 'POST',
            dataType: 'json',
            data: {
                'invite': invite,
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
                'role': role,
                'topic_id': topic,
                'response': response
            },
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    window.location.href = '/topic/' + topic + '/';
                } else {
                    if (obj.reason === 'login_required') {
                        window.location.href = obj.data.url;
                    }
                }
            }
        });
    } else {
        return;
    }
}

function psc_invite(elem, invite, response) {
    if (response === 'd' || response === 'a') {
        $.ajax({
            url: '/psc/invitation_response/',
            type: 'POST',
            dataType: 'json',
            data: {
                'invite': invite,
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
                'response': response
            },
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    if (obj.message.length == 0) {
                        window.location.href = '/psc/admin/' + obj.data.client_id + '/';
                    } else {
                        //do something with message
                    }
                } else {
                    if (obj.reason === 'login_required') {
                        window.location.href = obj.data.url;
                    }
                }
            }
        });
    } else {
        return;
    }
}