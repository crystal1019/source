from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseServerError, HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout
from django.template.loader import render_to_string
from django.contrib.auth.decorators import login_required
from models import Tag, Recipe, UserFeed, RecipeManual, RecipeImage, get_setting
from users import profile_context
from recipes import get_recipe, upload
from users import notifications, get_next
from mobile_forms import LoginForm, RecipeForm
import haystack.views
import json

UPDATES_COUNT = 16
MOBILE_LOGIN_URL = '/mobile/login'


def login_page(request):
    c = RequestContext(request)

    if request.method == 'POST':
        next_url = get_next(request.POST)
        form = LoginForm(request.POST)
        if form.is_valid():
            u = authenticate(
                username = form.cleaned_data['email'],
                password = form.cleaned_data['password']
                )

            if u is not None:
                login(request, u)
                return HttpResponseRedirect(next_url or '/mobile/')

            else:
                form.errors['__all__'] = form.error_class(["Invalid username or password."])
        else:
            form.errors['__all__'] = form.error_class(["Invalid username or password."])
    else:
        form = LoginForm()

    c.update({'form': form})

    return render_to_response('mobile/login.html', c)


def tags():
    tags = Tag.objects.all()
    tags = map(lambda t: t.tag, tags)

    return tags

@login_required(login_url=MOBILE_LOGIN_URL)
def recipes_my(request):
    c = RequestContext(request)
    u = User.objects.get(id=request.user.id)
    c.update(profile_context(request, u))
    c.update({'all_tags': tags()})

    return render_to_response('mobile/recipes-my.html', c)

@login_required(login_url=MOBILE_LOGIN_URL)
def recipes_by_tag(request, tag):
    c = RequestContext(request)
    r = Recipe.objects.filter(recipetag__tag=tag)
    c.update({'recipes': r})
    c.update({'all_tags': tags()})
    c.update({'tag': tag})

    return render_to_response('mobile/recipes-by-tag.html', c)

@login_required(login_url=MOBILE_LOGIN_URL)
def recipes_all(request):
    c = RequestContext(request)
    r = Recipe.objects.all()[0:12]
    c.update({'recipes': r})
    c.update({'all_tags': tags()})

    return render_to_response('mobile/recipes-all.html', c)


def recipes_loadmore(request):
    offset = int(request.POST['offset'])
    recipes = Recipe.objects.all()[offset:offset+12]
    recipes = map(lambda r: {'id': r.id,
                             'title': r.title,
                             'one_photo': r.one_photo()}, recipes)
    return HttpResponse(json.dumps(recipes),
                        content_type = 'application/json')


@login_required(login_url=MOBILE_LOGIN_URL)
def recipe(request, rid):
    c = RequestContext(request)
    try:
        (recipe, data) = get_recipe(rid, request.user)
        c.update({
            'recipe': recipe,
            'tags': recipe.sorted_tags(),
            'recipe_data': data,
            'photos': recipe.all_but_first_photos(),
            'all_tags': tags(),
            'is_mine': recipe.author == request.user if recipe else False,
            'bookmarked': recipe.is_bookmarked(request.user)
        })
        print recipe
    except Exception, e:
        print e
    return render_to_response('mobile/recipe.html', c)

@login_required(login_url=MOBILE_LOGIN_URL)
def calendar(request, uid):
    return render_to_response('mobile/calendar.html')

@login_required(login_url=MOBILE_LOGIN_URL)
def new_recipe(request):
    c = RequestContext(request)
    if request.method == 'POST':
        form = RecipeForm(request.POST)

        if form.is_valid():
            recipe = Recipe.objects.create(
                author = request.user,
                access = get_setting(request.user, 'new_recipes_privacy')
            )
            recipe.save_fields(form.cleaned_data)
            image = json.loads(upload(request).content)

            img = RecipeImage.objects.get(id = image['id'])
            img.recipe = recipe
            img.save()

            rms = RecipeManual.objects.filter(recipe = recipe)

            if len(rms) > 0:
                rm = rms[0]
            else:
                rm = RecipeManual(recipe = recipe)

            try:
                rm.contents = request.POST['contents']
                rm.save()
            except:
                pass
    else:
        form = RecipeForm()

    c.update({'form': form})
    return render_to_response('mobile/new-recipe.html', c)

@login_required(login_url=MOBILE_LOGIN_URL)
def updates(request):
    c = RequestContext(request)
    events = UserFeed.objects.filter(
        user = request.user,
        user_own_evt = False
        ).order_by('-created')[:UPDATES_COUNT]

    c.update({
        'notifications': notifications(request.user),
        'events': events
        })
    return render_to_response('mobile/updates.html', c)


class SearchView(haystack.views.SearchView):

    def extra_context(self):
        return {
            'all_tags': tags(),
        }
