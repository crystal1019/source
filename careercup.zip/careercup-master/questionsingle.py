import objects
import masterpage

import method_question
import method_user
import method_comment
import method_url
import method_cache
import method_notification

DEFAULT_CHARSET = 'utf-8'

class ViewQuestionSingle(masterpage.MasterPage):			   
		
	def get(self):
		key = method_url.getId(self)
		if key is None or key == '' or not self.isInt(key):
			self.displayError('Error: Question Does Not Exist', 'There is no question with this id.  Please hit the BACK key to click a new question')
			return

		force = method_url.getBooleanParam(self, 'force')
		question = method_question.getQuestionWithId(key, force)	
		if not question:
			self.displayError('Error: Question Does Not Exist', 'There is no question with this id.  Please hit the BACK key to click a new question')
			return		
		
		user = method_user.getLoggedInUser()
		if user and user.user.email() in question.subscriptions:
			is_subscribed = True
		else:
			is_subscribed = False
			
		if method_url.getIntParam(self, "mark") and user != None:
			method_notification.markQuestionAsRead(user, question.uid)
			
		can_edit = False
		if user:
			if method_user.userIsAdmin() or user.uid == question.author_id:
				can_edit = True 
		page_cache_key = 'question-questionhtml'
		question_html = method_cache.getObjectForTypeAndKey(page_cache_key, key)
		title = method_cache.getObjectForTypeAndKey(page_cache_key + 'title', key)		
		if not question_html:	    
			if not question:
				# Check to see if there's a redirect question
				questions = objects.Question.query(objects.Question.uid == key)
				for q in questions:
					if q.redirect_question and q.redirect_question != 0:
						self.redirect('/question?id=' + str(q.redirect_question))
						return
				self.displayError('Error: Question Does Not Exist', 'There is no question with this id.  Please hit the BACK key to click a new question')
				return
			length = len(question.text)
			if (length < 30):
				t = question.text
			else:
				t = question.text[:30] + '...'
			title = t.encode('utf-8')
			question.independent = 'yes'
			template_values = {}
			template_values['item'] = question
			template_values['comments'] = method_comment.getCommentsWithAncestor(key)
			question_html = self.getBody(template_values, 'html/control-questionsingle.html')
			method_cache.setObjectForTypeAndKey(page_cache_key, key, question_html, 604800)
			method_cache.setObjectForTypeAndKey(page_cache_key + 'title', key, title, 604800)			

		template_values = {
			'rendered_question': question_html,
			'item': question,
			'comment_form_type': 'question',
			'is_subscribed': is_subscribed,
			'can_edit': can_edit,
			'comment_parent_id': key,
			'comment_ancestor_id': key,	
			'parent_tab': 'interviews',			   
		}
		
		self.pushPage(template_values, title, 'html/questionsingle.html')