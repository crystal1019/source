import json
import logging
import opengraph
import re
from base import BaseScraper
import leaf
from ..exceptions import HukksterTooManyOptions


class ShoprucheScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'shopruche.com'

    #def fetch_url(self):
    #   with open('test_data/shopruche/dress.html', 'r') as f:
    #      self.html = f.read()

    def make_float(self, value):
        '''convert prices to float'''
        if value and value.strip():
                return float(re.sub(r'[^\d\.]', '', value.strip()))
        else:
            return None

    def leaf_get_text(self, parser, selector):
        '''Get tag text or return None'''
        tag = parser.get(selector)
        if tag and tag.text:
            return tag.text.strip()
        else:
            return None

    def leaf_get_attrib(self, parser, selector, attrib):
        '''Get attrib value from selector or return None'''
        tag = parser.get(selector)
        if tag and tag.element.attrib[attrib]:
                return tag.element.attrib[attrib].strip()
        else:
            return None

    def raise_not_item(self):
        raise HukksterTooManyOptions(self.get_domain(), self.url)

    def parse(self):
        items = list()
        common_data = dict()
        og_data = self.parse_opengraph()

        try:
            if og_data['type'] != 'product':
                self.raise_not_item()
        except KeyError:
            self.raise_not_item()

        common_data['store'] = 'shopruche'
        common_data['url'] = og_data['url']

        doc = leaf.parse(self.html)

        # get title from html body
        common_data['title'] = self.leaf_get_text(doc, 'div.product-name h1')
        if not common_data['title']:
            self.raise_not_item()

        # Get images
        common_data['images'] = list()
        for img in doc('li a.cloud-zoom-gallery'):
            if img.element:
                common_data['images'].append(img.element.attrib['href'])

        # Local id
        # item has "productId" and "product-ids", and product_id by sizes(!)

        local_id = self.leaf_get_attrib(doc,
                                       'input[name="product"][type="hidden"]',
                                       'value')
        if local_id:
            common_data['local_id'] = local_id

        #local_id = self.leaf_get_text(doc, 'p.product-ids')
        #if local_id:
        #    local_id = re.search(r'Model: (\d+)', local_id)
        #    if local_id:
        #        common_data['local_id'] = local_id.group(1)

        # prices
        current_price = self.leaf_get_text(doc,
                                           'span.regular-price span.price')
        current_price = self.make_float(current_price)

        # maybe the item has 2 prices?
        if not current_price:
            current_price = self.leaf_get_text(doc,
                                               'p.special-price span.price')
            current_price = self.make_float(current_price)

            original_price = self.leaf_get_text(doc, 'p.old-price span.price')
            original_price = self.make_float(original_price)

            if original_price:
                common_data['original_price'] = {'value': original_price}

        if current_price:
            common_data['current_price'] = {'value': current_price}
        else:
            self.raise_not_item()

        # sizes
        # get js array id
        js_id = self.leaf_get_attrib(doc,
                                     'select.super-attribute-select',
                                     'id')
        if js_id:
            js_id = re.search('attribute(\d+)', js_id)
            if js_id:
                js_id = js_id.group(1)

        #sizes json array
        sizes = re.search(r'Product.Config\(([^\)]+)', doc.html())
        if sizes:
            sizes = sizes.group(1)
            sizes = json.loads(sizes)
            sizes = sizes['attributes'][js_id]['options']

        #availability json array
        avail = re.search(r'StockStatus\(([^\)]+)', doc.html())
        if avail:
            avail = avail.group(1)
            avail = json.loads(avail)

        #common_data['sizes'] = sizes
        #common_data['avail'] = avail

        if not sizes:
            return common_data
        else:
            # there are a local_id for each size, remove common local_id
            if local_id:
                del common_data['local_id']

        # walk trough sizes and avail dicts to recombine data
        for size in sizes:
            item = dict()
            item['selections'] = {'size': size['label']}
            item['local_id'] = avail[size['id']]['product_id']

            # skip out of stock items
            #item['is_in_stock'] = avail[size['id']]['is_in_stock']
            if not avail[size['id']]['is_in_stock']:
                continue
            item.update(common_data)
            items.append(item)

        return items
