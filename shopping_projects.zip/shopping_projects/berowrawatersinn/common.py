from berowrawatersinn.website.models import *
from django.conf import settings
import datetime

def commondict(d,request):
    
    try:
        sitemeta = SiteMeta.objects.get(site__id=settings.SITE_ID)
    except:
        sitemeta = ''
    
    url_intro = MiscPage.objects.get_nav_url('Introduction')
    url_stay = MiscPage.objects.get_nav_url('Stay')
        
    
    data = {
        'site_meta':sitemeta,
            
        'url_intro':url_intro,
        'url_stay':url_stay,
            
    }
    
    data.update(d)
    return data

def getPreviousMonth(year, month):
    if month != 1:
        return datetime.date(year, month-1, 1)
    else:
        return datetime.date(year-1, 12, 1)
    
def getNextMonth(year, month):
    if month != 12:
        return datetime.date(year, month+1, 1)
    else:
        return datetime.date(year+1, 1,1)