-- MySQL dump 10.11
--
-- Host: localhost    Database: arkstart
-- ------------------------------------------------------
-- Server version	5.0.95

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_425ae3c4` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`),
  CONSTRAINT `group_id_refs_id_3cea63fe` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `permission_id_refs_id_5886d21f` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_message`
--

DROP TABLE IF EXISTS `auth_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `auth_message_403f60f` (`user_id`),
  CONSTRAINT `user_id_refs_id_650f49a6` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_message`
--

LOCK TABLES `auth_message` WRITE;
/*!40000 ALTER TABLE `auth_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_1bb8f392` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_728de91f` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add message',4,'add_message'),(11,'Can change message',4,'change_message'),(12,'Can delete message',4,'delete_message'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add blog category',8,'add_blogcategory'),(23,'Can change blog category',8,'change_blogcategory'),(24,'Can delete blog category',8,'delete_blogcategory'),(25,'Can add publish status',9,'add_publishstatus'),(26,'Can change publish status',9,'change_publishstatus'),(27,'Can delete publish status',9,'delete_publishstatus'),(28,'Can add comment status',10,'add_commentstatus'),(29,'Can change comment status',10,'change_commentstatus'),(30,'Can delete comment status',10,'delete_commentstatus'),(31,'Can add author',11,'add_author'),(32,'Can change author',11,'change_author'),(33,'Can delete author',11,'delete_author'),(34,'Can add blog post',12,'add_blogpost'),(35,'Can change blog post',12,'change_blogpost'),(36,'Can delete blog post',12,'delete_blogpost'),(37,'Can add comment',13,'add_comment'),(38,'Can change comment',13,'change_comment'),(39,'Can delete comment',13,'delete_comment'),(40,'Can add interest',14,'add_interest'),(41,'Can change interest',14,'change_interest'),(42,'Can delete interest',14,'delete_interest'),(43,'Can add member type',15,'add_membertype'),(44,'Can change member type',15,'change_membertype'),(45,'Can delete member type',15,'delete_membertype'),(46,'Can add profile',16,'add_profile'),(47,'Can change profile',16,'change_profile'),(48,'Can delete profile',16,'delete_profile'),(49,'Can add site meta',17,'add_sitemeta'),(50,'Can change site meta',17,'change_sitemeta'),(51,'Can delete site meta',17,'delete_sitemeta'),(52,'Can add ark group',18,'add_arkgroup'),(53,'Can change ark group',18,'change_arkgroup'),(54,'Can delete ark group',18,'delete_arkgroup'),(55,'Can add misc page',19,'add_miscpage'),(56,'Can change misc page',19,'change_miscpage'),(57,'Can delete misc page',19,'delete_miscpage'),(58,'Can add captcha store',20,'add_captchastore'),(59,'Can change captcha store',20,'change_captchastore'),(60,'Can delete captcha store',20,'delete_captchastore'),(61,'Can add tag',21,'add_tag'),(62,'Can change tag',21,'change_tag'),(63,'Can delete tag',21,'delete_tag'),(64,'Can add tagged item',22,'add_taggeditem'),(65,'Can change tagged item',22,'change_taggeditem'),(66,'Can delete tagged item',22,'delete_taggeditem'),(67,'Can add log entry',23,'add_logentry'),(68,'Can change log entry',23,'change_logentry'),(69,'Can delete log entry',23,'delete_logentry');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'chaol','','','chaol@1md.com.au','sha1$e167e$d9b7df7cd007605922550bfe6dda6a4cdf19f395',1,1,1,'2012-10-19 12:14:10','2012-10-02 12:00:15'),(2,'arkstart','','','','sha1$91515$71dfd8326a1ad18cfe5f2b470b9f8eb109933780',1,1,1,'2012-10-25 12:49:29','2012-10-09 15:10:30');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_403f60f` (`user_id`),
  KEY `auth_user_groups_425ae3c4` (`group_id`),
  CONSTRAINT `group_id_refs_id_f116770` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `user_id_refs_id_7ceef80f` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_403f60f` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`),
  CONSTRAINT `permission_id_refs_id_67e79cb` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `user_id_refs_id_dfbab7d` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` VALUES (70,2,1),(71,2,2),(72,2,3),(73,2,4),(74,2,5),(75,2,6),(76,2,7),(77,2,8),(78,2,9),(79,2,10),(80,2,11),(81,2,12),(82,2,13),(83,2,14),(84,2,15),(85,2,16),(86,2,17),(87,2,18),(88,2,19),(89,2,20),(90,2,21),(91,2,22),(92,2,23),(93,2,24),(94,2,25),(95,2,26),(96,2,27),(97,2,28),(98,2,29),(99,2,30),(100,2,31),(101,2,32),(102,2,33),(103,2,34),(104,2,35),(105,2,36),(106,2,37),(107,2,38),(108,2,39),(109,2,40),(110,2,41),(111,2,42),(112,2,43),(113,2,44),(114,2,45),(115,2,46),(116,2,47),(117,2,48),(118,2,49),(119,2,50),(120,2,51),(121,2,52),(122,2,53),(123,2,54),(124,2,55),(125,2,56),(126,2,57),(127,2,58),(128,2,59),(129,2,60),(130,2,61),(131,2,62),(132,2,63),(133,2,64),(134,2,65),(135,2,66),(136,2,67),(137,2,68),(138,2,69);
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_author`
--

DROP TABLE IF EXISTS `blog_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_author` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `email` varchar(75) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_author`
--

LOCK TABLES `blog_author` WRITE;
/*!40000 ALTER TABLE `blog_author` DISABLE KEYS */;
INSERT INTO `blog_author` VALUES (1,'Alex Lee','alee@arktotalwealth.com.au');
/*!40000 ALTER TABLE `blog_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogcategory`
--

DROP TABLE IF EXISTS `blog_blogcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogcategory` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `slug` varchar(50) default NULL,
  `image` varchar(100) default NULL,
  `priority` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogcategory`
--

LOCK TABLES `blog_blogcategory` WRITE;
/*!40000 ALTER TABLE `blog_blogcategory` DISABLE KEYS */;
INSERT INTO `blog_blogcategory` VALUES (1,'Cash Flow','cash-flow','',0,1,'Cash flow,',''),(2,'Loan Advice','loan-advice','',0,1,'Loan Advice',''),(3,'Super Advice','super-advice','',0,1,'super-advice',''),(4,'Property ','property','',0,1,'',''),(5,'Tax','tax','',0,1,'',''),(6,'Insurance','insurance','',0,1,'','');
/*!40000 ALTER TABLE `blog_blogcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogcategory_sites`
--

DROP TABLE IF EXISTS `blog_blogcategory_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogcategory_sites` (
  `id` int(11) NOT NULL auto_increment,
  `blogcategory_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `blogcategory_id` (`blogcategory_id`,`site_id`),
  KEY `blog_blogcategory_sites_10df31a4` (`blogcategory_id`),
  KEY `blog_blogcategory_sites_6223029` (`site_id`),
  CONSTRAINT `blogcategory_id_refs_id_3dd38274` FOREIGN KEY (`blogcategory_id`) REFERENCES `blog_blogcategory` (`id`),
  CONSTRAINT `site_id_refs_id_11ad4c68` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogcategory_sites`
--

LOCK TABLES `blog_blogcategory_sites` WRITE;
/*!40000 ALTER TABLE `blog_blogcategory_sites` DISABLE KEYS */;
INSERT INTO `blog_blogcategory_sites` VALUES (3,1,1),(2,2,1),(5,3,1),(6,4,1),(7,5,1),(8,6,1);
/*!40000 ALTER TABLE `blog_blogcategory_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost`
--

DROP TABLE IF EXISTS `blog_blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(40) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `tags` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `publishdate` datetime NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status_id` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `author_id` int(11) default NULL,
  `top_image` varchar(100) default NULL,
  `homepage_image` varchar(100) default NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `blog_blogpost_44224078` (`status_id`),
  KEY `blog_blogpost_337b96ff` (`author_id`),
  CONSTRAINT `author_id_refs_id_78820cb4` FOREIGN KEY (`author_id`) REFERENCES `blog_author` (`id`),
  CONSTRAINT `status_id_refs_id_4b74ae3d` FOREIGN KEY (`status_id`) REFERENCES `blog_publishstatus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost`
--

LOCK TABLES `blog_blogpost` WRITE;
/*!40000 ALTER TABLE `blog_blogpost` DISABLE KEYS */;
INSERT INTO `blog_blogpost` VALUES (1,'Should I fix my interest rate?','should-i-fix-my-interest-rate','<p>At the moment, there is a price war (or interest rate war) going on between the banks in relation to fixed interest rates for investment and home loans. Currently, you can get 2 and 3 year fixed rates for less than the discounted variable rate.&nbsp;</p>\r\n<p><strong style=\"font-size: 16px;\">Does this mean now is a good time to fix your loan?</strong></p>\r\n<p>This answer for this is different for everyone and it is better to look at it from your individual situation rather than trying to pick where we are in the interest rate cycle.</p>\r\n<p>If you are a first home owner and your monthly loan repayments are pretty tight, then fixing could be the option for you. It locks in certainty and allows you to get in a routine of making regular repayments. The cost you pay for certainty is that the variable rates may decrease lower than the fixed rates.&nbsp;</p>\r\n<p>If you are an SMSF investor, and you are looking at approaching retirement then a variable interest rate might be more suitable as it gives you the flexibility.</p>\r\n<p>If you are an investor and you are looking to re-finance or sell, then once again a variable may be the preferred option.</p>\r\n<p>A good strategy at the moment is to fix a portion of your loan (as an example 50%) as it allows you to basically hedge your strategy.&nbsp;</p>\r\n<p>Whatever your situation, you should look at how the loan suits you as opposed to chasing the best interest rate.&nbsp;</p>','interest rates, Loan Advice',0,'2012-10-01 13:43:00','2012-10-09 13:49:49','2012-11-13 14:24:54',1,4,1,'','','Loan Advice, interest rates,',''),(2,'Can I borrow in my Super?','can-i-borrow-my-super','<p>As of 2007, you can now effectively borrow within your superannuation. There is a minefield of rules and regulations that need to be adhered to but in essence it is possible and if done correctly, it can extremely beneficial.&nbsp;</p>\r\n<p>Technically, you can borrow to purchase any asset within your super fund but the most common asset recently has been commercial or residential property.&nbsp;</p>\r\n<p>The main differences between a super loan and a normal residential or home loan are;</p>\r\n<ul>\r\n<li>The interest rate is typically higher by approximately 1% (although this does change constantly)</li>\r\n<li>The loan is non-recourse which means the lender only has recourse over the one asset that is secured</li>\r\n</ul>\r\n<p>You can still choose between interest only and P and I depending on which structure suits you best within you super fund.</p>\r\n<p>An alternative strategy at the moment which gives you the most flexibility and reduces the interest rates and costs are a related party loan. This is where you, the member lends money as the bank to your superannuation fund. If you borrowed the money, this allows you to charge a lower interest rate than a super loan, or if you are using cash you can potentially not charge an interest cost at all. This area needs to be navigated very carefully to ensure you don&rsquo;t breach any of the rules that govern your superannuation fund.&nbsp;</p>\r\n<p>As with getting any loan, &nbsp;it is important that you get the right advice on the structure and costs to ensure it is the right strategy for you.&nbsp;</p>','Loan Advice, SMSF, Superanutation',0,'2012-10-05 13:46:00','2012-10-09 13:52:46','2012-10-09 18:13:36',1,2,1,'','images/MEMBERSHIP12.jpg','Superanutation, SMSF, Loan Advice ',''),(3,'5 tips for increasing your savings','5-tips-increasing-your-savings','<p>I see a lot of lists about increasing your savings and the majority of them basically tell you to spend less on your lifestyle and going out. &nbsp;</p>\r\n<p>We have put together a list that doesn&rsquo;t influence your lifestyle, but may help you increase your monthly savings;</p>\r\n<ol>\r\n<li><strong>Maximise your tax returns</strong> &ndash; This is the best area to increase your savings as you are effectively clawing back money you have already paid out. Get your tax professionally done to ensure you maximise your deductions. You should also do some forward planning and look at your tax situation for the coming year so you can strategically plan your finances to maximise your return.</li>\r\n<li><strong>Move your Income Protection and Life Insurance inside super </strong>&ndash; If you currently pay your personal insurances outside of super, you can look at the option of replacing them within your superannuation fund. This means your insurances are effectively funded with your super contributions.</li>\r\n<li><strong>Consolidate debt/Re-finance your loans</strong> &ndash; If you have credit cards, personal loans or even car loans you can look at the option of consolidating your debt. This may reduce your interest payments which can free up some additional money to repay the loan. In addition, you should look to see if you can get a better interest rate on your loan. Although interest rates aren&rsquo;t the only factor when considering a loan, you can look at the option of possibly fixing to free up some cash flow.&nbsp;</li>\r\n<li><strong>Setup Direct Debits</strong> &ndash; This tip won&rsquo;t drastically change your cash flow but every little bit helps. Every time you miss a bill or credit card repayment you get hit with penalty interest or late fees. Over a year, if you continually miss payments this amount can become material.&nbsp;</li>\r\n<li><strong>Maximise the use of your savings</strong> &ndash; Once again this strategy takes some time but once you get momentum it can significantly add to your savings. This could be as simple as putting your hard earned money into a high interest account or investing it in the share market into high dividend yielding stocks with strong franking credits. This additional income you earn can be re-invested to create the compounding effect.&nbsp;</li>\r\n</ol>\r\n<p>&nbsp;</p>\r\n<p>The key with increasing your savings is that there isn&rsquo;t one magic solution. It is about making multiple changes that individually don&rsquo;t make too much difference, but when combined together it can make a significant change your savings.&nbsp;</p>\r\n<p><strong style=\"font-size: 14px;\">Happy savings!</strong></p>\r\n<p><strong style=\"font-size: 14px;\"><br /></strong></p>','Savings, Wealth Creation',0,'2012-10-09 13:52:00','2012-10-09 13:58:03','2012-11-13 14:24:45',1,17,1,'','','',''),(4,'When do I have to pay HECS?','when-do-i-have-pay-hecs','<p>A HECS or HELP debt as it is now known is a loan program supported by the Common wealth to help fund your education.</p>\r\n<p>Once you start earning more than $49,095 you will need to start making loan repayments. The amount of payments you make a dependent on what threshold you fall into.&nbsp;</p>\r\n<p>The table below shows the various thresholds;</p>','',0,'2012-10-06 03:00:00','2012-10-09 14:01:09','2012-10-25 14:25:44',1,3,1,'','','',''),(5,'Trouble with your tax?','trouble-your-tax','<p>Do you constantly get frustrated with having to find all of your paperwork for your tax return? Does this mean you leave your return until the last minute or after it is due?</p>\r\n<p>It is time you turn your tax return into something you look forward to, rather than leave till the last minuite. The key to do this is the following;</p>\r\n<p>Maximise the amount you get back - One way to motiviate yourself is to make sure you get the most of out your tax return so you get money back instead of owing the ATO. This comes from careful planning and some thinking before it is too late</p>\r\n<p>Know what you need and don\'t need - If you understand what you need for tax time, just put everything you need into a shoe box (if you are still old school and you want everything in paper form) or get an app like Genuis Scan where you can upload everything into your email or cloud. This means when it comes time to do your tax you just email everythign you have off to your advisor and they do the rest.</p>\r\n<p>If you want some more handy tips on how to maximise your tax return and make it streamlined, drop us a line.</p>','Tax',0,'2012-10-09 18:00:00','2012-10-09 18:08:19','2012-10-25 14:25:52',2,9,1,'','','','');
/*!40000 ALTER TABLE `blog_blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_category`
--

DROP TABLE IF EXISTS `blog_blogpost_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_category` (
  `id` int(11) NOT NULL auto_increment,
  `blogpost_id` int(11) NOT NULL,
  `blogcategory_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `blogpost_id` (`blogpost_id`,`blogcategory_id`),
  KEY `blog_blogpost_category_3b7e3252` (`blogpost_id`),
  KEY `blog_blogpost_category_10df31a4` (`blogcategory_id`),
  CONSTRAINT `blogcategory_id_refs_id_268aea5b` FOREIGN KEY (`blogcategory_id`) REFERENCES `blog_blogcategory` (`id`),
  CONSTRAINT `blogpost_id_refs_id_75899d7d` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_category`
--

LOCK TABLES `blog_blogpost_category` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_category` DISABLE KEYS */;
INSERT INTO `blog_blogpost_category` VALUES (1,1,2),(8,2,2),(9,2,3),(6,3,1),(5,4,1),(7,5,5);
/*!40000 ALTER TABLE `blog_blogpost_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_membertype`
--

DROP TABLE IF EXISTS `blog_blogpost_membertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_membertype` (
  `id` int(11) NOT NULL auto_increment,
  `blogpost_id` int(11) NOT NULL,
  `membertype_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `blogpost_id` (`blogpost_id`,`membertype_id`),
  KEY `blog_blogpost_membertype_3b7e3252` (`blogpost_id`),
  KEY `blog_blogpost_membertype_49ffccb4` (`membertype_id`),
  CONSTRAINT `blogpost_id_refs_id_75952fc3` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`),
  CONSTRAINT `membertype_id_refs_id_79c51048` FOREIGN KEY (`membertype_id`) REFERENCES `userprofile_membertype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_membertype`
--

LOCK TABLES `blog_blogpost_membertype` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_membertype` DISABLE KEYS */;
INSERT INTO `blog_blogpost_membertype` VALUES (1,1,2),(7,2,2),(5,3,1),(4,4,2),(6,5,2);
/*!40000 ALTER TABLE `blog_blogpost_membertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_sites`
--

DROP TABLE IF EXISTS `blog_blogpost_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_sites` (
  `id` int(11) NOT NULL auto_increment,
  `blogpost_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `blogpost_id` (`blogpost_id`,`site_id`),
  KEY `blog_blogpost_sites_3b7e3252` (`blogpost_id`),
  KEY `blog_blogpost_sites_6223029` (`site_id`),
  CONSTRAINT `blogpost_id_refs_id_37ecd288` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`),
  CONSTRAINT `site_id_refs_id_2d93f89e` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_sites`
--

LOCK TABLES `blog_blogpost_sites` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_sites` DISABLE KEYS */;
INSERT INTO `blog_blogpost_sites` VALUES (1,1,1),(7,2,1),(5,3,1),(4,4,1),(6,5,1);
/*!40000 ALTER TABLE `blog_blogpost_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_comment`
--

DROP TABLE IF EXISTS `blog_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_comment` (
  `id` int(11) NOT NULL auto_increment,
  `post_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(75) NOT NULL,
  `website` varchar(200) default NULL,
  `comment` longtext NOT NULL,
  `created` datetime NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `blog_comment_699ae8ca` (`post_id`),
  KEY `blog_comment_44224078` (`status_id`),
  CONSTRAINT `post_id_refs_id_149801a9` FOREIGN KEY (`post_id`) REFERENCES `blog_blogpost` (`id`),
  CONSTRAINT `status_id_refs_id_280fec0b` FOREIGN KEY (`status_id`) REFERENCES `blog_commentstatus` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_comment`
--

LOCK TABLES `blog_comment` WRITE;
/*!40000 ALTER TABLE `blog_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_comment_sites`
--

DROP TABLE IF EXISTS `blog_comment_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_comment_sites` (
  `id` int(11) NOT NULL auto_increment,
  `comment_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `comment_id` (`comment_id`,`site_id`),
  KEY `blog_comment_sites_64c238ac` (`comment_id`),
  KEY `blog_comment_sites_6223029` (`site_id`),
  CONSTRAINT `comment_id_refs_id_13a9beac` FOREIGN KEY (`comment_id`) REFERENCES `blog_comment` (`id`),
  CONSTRAINT `site_id_refs_id_48aa6ed8` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_comment_sites`
--

LOCK TABLES `blog_comment_sites` WRITE;
/*!40000 ALTER TABLE `blog_comment_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_comment_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_commentstatus`
--

DROP TABLE IF EXISTS `blog_commentstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_commentstatus` (
  `id` int(11) NOT NULL auto_increment,
  `status` varchar(60) NOT NULL,
  `display_to_user` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_commentstatus`
--

LOCK TABLES `blog_commentstatus` WRITE;
/*!40000 ALTER TABLE `blog_commentstatus` DISABLE KEYS */;
INSERT INTO `blog_commentstatus` VALUES (1,'Published',1),(2,'Not Published',0);
/*!40000 ALTER TABLE `blog_commentstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_publishstatus`
--

DROP TABLE IF EXISTS `blog_publishstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_publishstatus` (
  `id` int(11) NOT NULL auto_increment,
  `status` varchar(60) NOT NULL,
  `display_to_user` tinyint(1) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_publishstatus`
--

LOCK TABLES `blog_publishstatus` WRITE;
/*!40000 ALTER TABLE `blog_publishstatus` DISABLE KEYS */;
INSERT INTO `blog_publishstatus` VALUES (1,'Published',1,0),(2,'Featured',1,1),(3,'Not Published',0,0);
/*!40000 ALTER TABLE `blog_publishstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captcha_captchastore`
--

DROP TABLE IF EXISTS `captcha_captchastore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_captchastore` (
  `id` int(11) NOT NULL auto_increment,
  `challenge` varchar(32) NOT NULL,
  `response` varchar(32) NOT NULL,
  `hashkey` varchar(40) NOT NULL,
  `expiration` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `hashkey` (`hashkey`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_captchastore`
--

LOCK TABLES `captcha_captchastore` WRITE;
/*!40000 ALTER TABLE `captcha_captchastore` DISABLE KEYS */;
INSERT INTO `captcha_captchastore` VALUES (1,'YADF','yadf','70075859facf31e981582cbcfabf12672ce665b5','2012-10-09 13:55:14'),(2,'VNBL','vnbl','dac08b7cc80b76bdf6bd5bb84ab9303478b88ec1','2012-10-09 13:59:02'),(3,'MNAN','mnan','bd96d2892cd9d1e54f9c260d2757930b0650ee73','2012-10-09 13:59:05'),(4,'SQBL','sqbl','241828e3726542d68c021f3bb4067144ace9d8af','2012-10-09 15:12:23'),(5,'IDOA','idoa','44a1eaab6644fcb2f491185b34523ca2d2dda2e4','2012-10-09 18:18:36'),(6,'VCBD','vcbd','b8c5d6e537612d1f42514dce4fc4a72c7355f378','2012-10-19 11:40:03'),(7,'WKKV','wkkv','75248c49373dd48e8c8147b7d72656dfe3fa8f62','2012-10-19 11:40:04'),(8,'DIUH','diuh','07ab5dc80eb6300bcaaf7b16f89597f1f4523672','2012-10-19 12:44:58'),(9,'FFFT','ffft','4ea6ecb75747c7d1457f02becafff4d4b8fbb0ac','2012-10-22 09:33:28'),(10,'JSGG','jsgg','0a7c9de1bf5277c78264b81d6186370e675f782e','2012-10-22 09:34:04'),(11,'NNAC','nnac','f4d956d2e62bf4bbcbe277b245a31578e592e1cc','2012-10-25 12:53:52'),(12,'AECJ','aecj','c8fff0931b95dbdb097ee24b8dec966604008812','2012-10-25 12:56:51'),(13,'PPBL','ppbl','b5fac613bc0c1eccd14f81bcb781bf0a07839c9c','2012-10-25 13:20:39'),(14,'EJLN','ejln','ba423be9313d3230d49ce572ff687c33db904a3f','2012-10-25 14:30:41'),(15,'ZPNU','zpnu','6c5abac736f20937b0ebf8ce363f0ed9224612fd','2012-10-25 14:30:44'),(16,'TJNA','tjna','83a0897f582ad1f1300dda6e5afa96fd1b2d6872','2012-10-25 14:30:47'),(17,'FWTF','fwtf','bffa469d16d409b32911c2ab363b0f160c7739a8','2012-10-25 14:30:52'),(18,'ULMH','ulmh','ccf9f45d9798e0354178b9e8dd92cfe6723b09ad','2012-11-13 14:29:54');
/*!40000 ALTER TABLE `captcha_captchastore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL auto_increment,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) default NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `django_admin_log_403f60f` (`user_id`),
  KEY `django_admin_log_1bb8f392` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_288599e6` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `user_id_refs_id_c8665aa` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2012-10-02 12:08:31',1,7,'1','arkstart.1md.com.au',2,'Changed domain and name. Added site meta \"arkstart.1md.com.au\".'),(2,'2012-10-02 12:28:38',1,10,'1','Published',1,''),(3,'2012-10-02 12:28:46',1,10,'2','Not Published',1,''),(4,'2012-10-02 12:28:55',1,9,'1','Published',1,''),(5,'2012-10-02 12:29:00',1,9,'2','Featured',1,''),(6,'2012-10-02 12:29:09',1,9,'3','Not Published',1,''),(7,'2012-10-02 12:29:29',1,15,'1','Member',1,''),(8,'2012-10-02 12:29:36',1,15,'2','None Member',1,''),(9,'2012-10-09 13:44:18',1,11,'1','Alex Lee -- alee@arktotalwealth.com.au',1,''),(10,'2012-10-09 13:45:02',1,8,'1','Cash Flow',1,''),(11,'2012-10-09 13:45:21',1,8,'2','Loan Advice',1,''),(12,'2012-10-09 13:45:26',1,8,'1','Cash Flow',2,'Changed is_active.'),(13,'2012-10-09 13:49:50',1,12,'1','Should I fix my interest rate?',1,''),(14,'2012-10-09 13:52:37',1,8,'3','super-advice',1,''),(15,'2012-10-09 13:52:46',1,12,'2','Can I borrow in my Super?',1,''),(16,'2012-10-09 13:53:30',1,8,'3','Super Advice',2,'Changed name.'),(17,'2012-10-09 13:58:03',1,12,'3','Top 5 tips for increasing your savings..',1,''),(18,'2012-10-09 14:01:09',1,12,'4','When do I have to pay HECS?',1,''),(19,'2012-10-09 15:10:30',1,3,'2','arkstart',1,''),(20,'2012-10-09 15:23:30',1,3,'2','arkstart',2,'Changed is_staff, is_superuser and user_permissions.'),(21,'2012-10-09 15:23:38',1,3,'2','arkstart',2,'No fields changed.'),(22,'2012-10-09 17:56:12',2,7,'1','arkstart.1md.com.au',2,'Changed meta_keywords for site meta \"arkstart.1md.com.au\".'),(23,'2012-10-09 17:56:46',2,7,'1','arkstart.1md.com.au',2,'Changed footer_text for site meta \"arkstart.1md.com.au\".'),(24,'2012-10-09 17:57:14',2,7,'1','arkstart.1md.com.au',2,'No fields changed.'),(25,'2012-10-09 17:57:59',2,7,'1','arkstart.1md.com.au',2,'Changed meta_keywords for site meta \"arkstart.1md.com.au\".'),(26,'2012-10-09 17:58:41',2,7,'1','arkstart.1md.com.au',2,'Changed meta_keywords for site meta \"arkstart.1md.com.au\".'),(27,'2012-10-09 17:59:33',2,8,'4','Property ',1,''),(28,'2012-10-09 18:00:15',2,8,'5','Tax',1,''),(29,'2012-10-09 18:00:29',2,8,'6','Insurance',1,''),(30,'2012-10-09 18:02:08',2,12,'3','5 tips for increasing your savings',2,'Changed title, slug, content and status.'),(31,'2012-10-09 18:08:19',2,12,'5','Trouble with your tax?',1,''),(32,'2012-10-09 18:13:12',2,12,'2','Can I borrow in my Super?',2,'Changed homepage_image.');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'permission','auth','permission'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'message','auth','message'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(7,'site','sites','site'),(8,'blog category','blog','blogcategory'),(9,'publish status','blog','publishstatus'),(10,'comment status','blog','commentstatus'),(11,'author','blog','author'),(12,'blog post','blog','blogpost'),(13,'comment','blog','comment'),(14,'interest','userprofile','interest'),(15,'member type','userprofile','membertype'),(16,'profile','userprofile','profile'),(17,'site meta','website','sitemeta'),(18,'ark group','website','arkgroup'),(19,'misc page','website','miscpage'),(20,'captcha store','captcha','captchastore'),(21,'tag','tagging','tag'),(22,'tagged item','tagging','taggeditem'),(23,'log entry','admin','logentry');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY  (`session_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('7095417047457fde826ae40f440d778e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5k\ncy5Nb2RlbEJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEBdS5jYzY2NTI1ZGY5ZjM2ZmMxNzBj\nYWQzZmZiYTc0ZjQ4Zg==\n','2012-10-23 13:43:53'),('9fb70caa6377540a82ef1e46d1c0cb87','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5k\ncy5Nb2RlbEJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS5kYzk4MWIxZDBjMzcwNDg2OGE2\nMmM1NDVhYzcyMWFkOA==\n','2012-10-23 15:23:53'),('de83ec4b11e28d9fe9e8132ab051f370','gAJ9cQEuMzg3NDYzMDU2OTZkZDJkNzQwN2I2ZWE4NDM0MTI1MTU=\n','2012-10-16 12:30:04'),('f4eab77446f7dfa1a8615f0f686949a9','gAJ9cQEuMzg3NDYzMDU2OTZkZDJkNzQwN2I2ZWE4NDM0MTI1MTU=\n','2012-11-02 12:14:41'),('f77b822102c8e068aa5c58067238456d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5k\ncy5Nb2RlbEJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS5kYzk4MWIxZDBjMzcwNDg2OGE2\nMmM1NDVhYzcyMWFkOA==\n','2012-11-08 12:49:29');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL auto_increment,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'arkstart.1md.com.au','arkstart.1md.com.au');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagging_tag`
--

DROP TABLE IF EXISTS `tagging_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagging_tag` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagging_tag`
--

LOCK TABLES `tagging_tag` WRITE;
/*!40000 ALTER TABLE `tagging_tag` DISABLE KEYS */;
INSERT INTO `tagging_tag` VALUES (2,'interest rates'),(1,'Loan Advice'),(5,'Savings'),(3,'SMSF'),(4,'Superanutation'),(7,'Tax'),(6,'Wealth Creation');
/*!40000 ALTER TABLE `tagging_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagging_taggeditem`
--

DROP TABLE IF EXISTS `tagging_taggeditem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagging_taggeditem` (
  `id` int(11) NOT NULL auto_increment,
  `tag_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `tag_id` (`tag_id`,`content_type_id`,`object_id`),
  KEY `tagging_taggeditem_3747b463` (`tag_id`),
  KEY `tagging_taggeditem_1bb8f392` (`content_type_id`),
  KEY `tagging_taggeditem_7d61c803` (`object_id`),
  CONSTRAINT `content_type_id_refs_id_e07b113` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `tag_id_refs_id_60aefff3` FOREIGN KEY (`tag_id`) REFERENCES `tagging_tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagging_taggeditem`
--

LOCK TABLES `tagging_taggeditem` WRITE;
/*!40000 ALTER TABLE `tagging_taggeditem` DISABLE KEYS */;
INSERT INTO `tagging_taggeditem` VALUES (1,1,12,1),(3,1,12,2),(2,2,12,1),(4,3,12,2),(5,4,12,2),(6,5,12,3),(7,6,12,3),(8,7,12,5);
/*!40000 ALTER TABLE `tagging_taggeditem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_interest`
--

DROP TABLE IF EXISTS `userprofile_interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_interest` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_interest`
--

LOCK TABLES `userprofile_interest` WRITE;
/*!40000 ALTER TABLE `userprofile_interest` DISABLE KEYS */;
/*!40000 ALTER TABLE `userprofile_interest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_membertype`
--

DROP TABLE IF EXISTS `userprofile_membertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_membertype` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `super_member` tinyint(1) NOT NULL,
  `member` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_membertype`
--

LOCK TABLES `userprofile_membertype` WRITE;
/*!40000 ALTER TABLE `userprofile_membertype` DISABLE KEYS */;
INSERT INTO `userprofile_membertype` VALUES (1,'Member',0,1),(2,'None Member',0,0);
/*!40000 ALTER TABLE `userprofile_membertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_profile`
--

DROP TABLE IF EXISTS `userprofile_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_profile` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `membertype_id` int(11) default NULL,
  `mobile` varchar(20) NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `comments` longtext NOT NULL,
  `subscribe` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `userprofile_profile_49ffccb4` (`membertype_id`),
  CONSTRAINT `membertype_id_refs_id_129e2f69` FOREIGN KEY (`membertype_id`) REFERENCES `userprofile_membertype` (`id`),
  CONSTRAINT `user_id_refs_id_3d5a6137` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_profile`
--

LOCK TABLES `userprofile_profile` WRITE;
/*!40000 ALTER TABLE `userprofile_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `userprofile_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_profile_interests`
--

DROP TABLE IF EXISTS `userprofile_profile_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_profile_interests` (
  `id` int(11) NOT NULL auto_increment,
  `profile_id` int(11) NOT NULL,
  `interest_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `profile_id` (`profile_id`,`interest_id`),
  KEY `userprofile_profile_interests_141c6eec` (`profile_id`),
  KEY `userprofile_profile_interests_7a42e836` (`interest_id`),
  CONSTRAINT `interest_id_refs_id_42f7525f` FOREIGN KEY (`interest_id`) REFERENCES `userprofile_interest` (`id`),
  CONSTRAINT `profile_id_refs_id_10f02dad` FOREIGN KEY (`profile_id`) REFERENCES `userprofile_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_profile_interests`
--

LOCK TABLES `userprofile_profile_interests` WRITE;
/*!40000 ALTER TABLE `userprofile_profile_interests` DISABLE KEYS */;
/*!40000 ALTER TABLE `userprofile_profile_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_arkgroup`
--

DROP TABLE IF EXISTS `website_arkgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_arkgroup` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `link` varchar(200) default NULL,
  `image` varchar(100) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_arkgroup`
--

LOCK TABLES `website_arkgroup` WRITE;
/*!40000 ALTER TABLE `website_arkgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_arkgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_miscpage`
--

DROP TABLE IF EXISTS `website_miscpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_miscpage` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` longtext NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `path` (`path`),
  KEY `website_miscpage_44224078` (`status_id`),
  CONSTRAINT `status_id_refs_id_355670bc` FOREIGN KEY (`status_id`) REFERENCES `blog_publishstatus` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_miscpage`
--

LOCK TABLES `website_miscpage` WRITE;
/*!40000 ALTER TABLE `website_miscpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_miscpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_miscpage_sites`
--

DROP TABLE IF EXISTS `website_miscpage_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_miscpage_sites` (
  `id` int(11) NOT NULL auto_increment,
  `miscpage_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `miscpage_id` (`miscpage_id`,`site_id`),
  KEY `website_miscpage_sites_5358b0bb` (`miscpage_id`),
  KEY `website_miscpage_sites_6223029` (`site_id`),
  CONSTRAINT `miscpage_id_refs_id_6337e48a` FOREIGN KEY (`miscpage_id`) REFERENCES `website_miscpage` (`id`),
  CONSTRAINT `site_id_refs_id_112f9c77` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_miscpage_sites`
--

LOCK TABLES `website_miscpage_sites` WRITE;
/*!40000 ALTER TABLE `website_miscpage_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_miscpage_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_sitemeta`
--

DROP TABLE IF EXISTS `website_sitemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_sitemeta` (
  `id` int(11) NOT NULL auto_increment,
  `site_id` int(11) NOT NULL,
  `title` varchar(255) default NULL,
  `meta_keywords` longtext NOT NULL,
  `meta_description` longtext NOT NULL,
  `footer_text` longtext,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `site_id` (`site_id`),
  CONSTRAINT `site_id_refs_id_1a45c1d1` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_sitemeta`
--

LOCK TABLES `website_sitemeta` WRITE;
/*!40000 ALTER TABLE `website_sitemeta` DISABLE KEYS */;
INSERT INTO `website_sitemeta` VALUES (1,1,'Arkstart','<p>ArkStart. A revolutionary service that provides advice and education to individuals who are looking to build their wealth.</p>\r\n<p>Building Wealth is not just about making more money.</p>\r\n<p>ArkStart offers the complete education and solution for anything finance related. This&nbsp;could include any of the following;</p>\r\n<ul>\r\n<li>&nbsp;Setting up bank accounts correctly and which account is the best for you</li>\r\n<li>Consolidating current credit card and personal loan debt</li>\r\n<li>Discovering how to buy a home and what you can afford</li>\r\n<li>Understanding the different investment options available to you - property, shares, cash</li>\r\n<li>Finding that lost super and understanding how it works</li>\r\n<li>Calculating the best method to buy a car&nbsp;- Personal loan, novated lease</li>\r\n<li>Maximising your tax returns and getting all the paperwork sorted effortlessly </li>\r\n</ul>\r\n<p>We believe financial advice and education should be unbiased and available&nbsp;to everyone, regardless of what position you think you might be in.</p>','<p>Arkstart</p>','<p>ArkStart. A revolutionary service that provides advice and education to individuals who are looking to build their wealth.</p>\r\n<p>Building Wealth is not just about making more money.</p>\r\n<p>ArkStart offers the complete education and solution for anything finance related. This&nbsp;could include any of the following;</p>\r\n<ul>\r\n<li>Setting up bank accounts correctly and which account is the best for you</li>\r\n<li>Consolidating current credit card and personal loan debt</li>\r\n<li>Discovering how to buy a home and what you can afford</li>\r\n<li>Understanding the different investment options available to you - property, shares, cash</li>\r\n<li>Finding that lost super and understanding how it works</li>\r\n<li>Calculating the best method to buy a car&nbsp;- Personal loan, novated lease</li>\r\n<li>Maximising your tax returns and getting all the paperwork sorted effortlessly </li>\r\n</ul>\r\n<p>We believe financial advice and education should be unbiased and available&nbsp;to everyone, regardless of what position you think you might be in.</p>');
/*!40000 ALTER TABLE `website_sitemeta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-11-30 12:35:56
