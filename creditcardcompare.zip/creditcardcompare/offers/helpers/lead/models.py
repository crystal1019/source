from datetime import datetime, timedelta
from os import path
from random import random
from pygeoip import GeoIP
from django.conf import settings
from django.db import models
from hashlib import sha1 as sha_constructor
from offers.helpers.django_fields import fields as encrypted


GEODATA = path.join(path.dirname(__file__), 'GeoLiteCity.dat')


class Conversion(models.Model):
    uid = models.CharField(max_length=50)
    query = models.CharField(max_length=300)
    cookies = models.TextField()
    meta = models.TextField()
    
    def __unicode__(self):
        return self.uid


class State(models.Model):
    region = models.CharField(max_length=2)
    code = models.CharField(max_length=5)
    name = models.CharField(max_length=30)

    def __unicode__(self):
        return self.code

    class Meta:
        ordering = ['region']


class Lead(models.Model):
    first_name = encrypted.EncryptedCharField(max_length=250, blank=True, null=True)
    last_name = encrypted.EncryptedCharField(max_length=250, blank=True, null=True)
    email = encrypted.EncryptedEmailField()
    phone = encrypted.EncryptedCharField(max_length=15, blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)
    state = models.ForeignKey(State, blank=True, null=True)
    ip = encrypted.EncryptedCharField(max_length=15, null=True, blank=True)
    country = encrypted.EncryptedCharField(max_length=50, null=True, blank=True)
    source = encrypted.EncryptedCharField(max_length=250)
    date = models.DateTimeField(verbose_name='date captured', auto_now_add=True)

    def __unicode__(self):
        return ' '.join([self.first_name or '', self.last_name or ''])
    
    def get_state(self, geoip):
        try:
            self.state
        except State.DoesNotExist:
            self.state = None
        if not self.state:
            try:
                region = geoip.region_by_addr(self.ip or '127.0.0.1')['region_name']
                self.state =  State.objects.get(region=region)
            except (State.DoesNotExist, TypeError):
                pass
    
    def get_country(self, geoip):
        if not self.country:
            try:
                self.country = geoip.country_code_by_addr(self.ip or '127.0.0.1')
            except TypeError:
                self.country = ''
                
    def save(self, *args, **kwargs):
        geoip = GeoIP(GEODATA)  # don't make this a model variable to avoid multiple open files
        self.get_state(geoip)
        self.get_country(geoip)
        super(Lead, self).save(*args, **kwargs)


class ExtraField(models.Model):
    lead = models.ForeignKey(Lead)
    name = models.CharField(max_length=50)
    value = models.CharField(max_length=250)

    def __unicode__(self):
        return self.name
    
    
class EmailConfirmationManager(models.Manager):

    def confirm_email(self, confirmation_key):
        try:
            confirmation = self.get(confirmation_key=confirmation_key)
        except self.model.DoesNotExist:
            return
        if not confirmation.key_expired():
            email = confirmation.email_address
            confirmation.delete()
            return email


class EmailConfirmation(models.Model):
    email_address = models.EmailField(max_length=40)
    sent = models.DateTimeField(auto_now_add=True)
    confirmation_key = models.CharField(max_length=40)
    
    objects = EmailConfirmationManager()

    def key_expired(self):
        expiration_date = self.sent + timedelta(
            days=settings.EMAIL_CONFIRMATION_DAYS)
        return expiration_date <= datetime.now()

    def __unicode__(self):
        return u"confirmation for %s" % self.email_address
        
    def save(self, *args, **kwargs):
        if not self.pk:
            salt = sha_constructor(str(random())).hexdigest()[:5]
            self.confirmation_key = sha_constructor(
                                salt + self.email_address).hexdigest()
        super(EmailConfirmation, self).save(*args, **kwargs)
