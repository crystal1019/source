from main import datafmt

class Student:
    UNIVERSITY = 'MIT'
    def __init__(self, name, data_string, *args):
        self.name = name
        self.birthdate = datafmt(data_string)