from django.db import models
from arktotalwealth.component.models import *
# Create your models here.
class ImagePlayer(models.Model):
	image = models.ImageField(upload_to='images/', help_text='size:729 X 274')
	in_flash = models.BooleanField(default=False, editable=False)
	in_js = models.BooleanField("is acitve ?",default=False)
	title = models.CharField(max_length=255, blank=True, null=True)
	description = models.TextField(blank=True,null=True)
	link = models.URLField(blank=True,null=True)
	priority = models.IntegerField(default=0)
	
	def __unicode__(self):
		return self.image.url

class MiscPage(models.Model):
	MISC_PATH = [['index','Introductory copy in index page'],['overview.html','Overview'],['legal_disclaimer.html','Legal Disclaimer'],['privacy_policy.html','Privacy Policy'],['contact.html','Contact Details'],['email_enquiry.html', 'Email Enquiry']]
	title = models.CharField(max_length=255)
	path = models.CharField(max_length=255, unique=True, choices=MISC_PATH)
	in_contact = models.BooleanField(default=False)
	link = models.URLField(blank=True,null=True, help_text='the link of introductory copy in home page')
	content = models.TextField()
	created = models.DateTimeField(auto_now_add=True)
	modified = models.DateTimeField(auto_now=True)
	active = models.BooleanField(default=False)
	header = models.ImageField(upload_to="images/", blank=True, null=True, help_text='width:764')
	page_title = models.CharField(max_length=255,blank=True,null=True, help_text='this is the page title on page')
	meta_keywords = models.CharField(max_length=255, blank=True,null=True ,help_text="max length 255 characters, please separate it by ','")
	meta_description = models.TextField(blank=True,null=True)  
	action_links = models.ManyToManyField(ActionLink, blank=True,null=True)
	components = models.ManyToManyField(GenericComponent,blank=True, null=True)

	def __unicode__(self):
		return self.title

	def get_absolute_url(self):
		return self.link if self.link else '/' if self.path == 'index' else '/'+ self.path
	
	def get_current_nav(self):
		if self.in_contact:
			return 'contact'
		
		return ''

class Interest(models.Model):
	PLACE_CHOICES = [['enquiry', 'Enquiry Form'],]
	name = models.CharField(max_length=150)
	place = models.CharField(max_length=150, choices=PLACE_CHOICES)
	priority = models.IntegerField(default=0)

	def __unicode__(self):
		return self.name
	
class Enquiry(models.Model):
	#INTEREST_CHOICES = [['','Please select an interest'],['fhb','First Home Buyer'],['rf','Re-finance'],['bh','Buying a Home'],['investment','Investment'],['carl','Car Loan'],['cl','Commercial Loan'],['ge','General Enquiry']]
	first_name = models.CharField(max_length=100)
	surname = models.CharField(max_length=100)
	email = models.EmailField()
	phone = models.CharField(max_length=20, null=True)
	interest = models.ForeignKey(Interest,null=True)
	comments = models.TextField(null=True)
	submitdate = models.DateTimeField(auto_now_add=True)
	is_answered = models.BooleanField(default=False)
	subscribed = models.BooleanField(default=False)
	ip = models.CharField(max_length=50, blank=True, null=True)

	def __unicode__(self):
		return self.email

	def get_xmlstring(self):
		return '''<person>
					<email-address>%s</email-address>
					<first-name>%s</first-name>
					<last-name>%s</last-name>
					<phone-number>%s</phone-number>
				</person>'''%(self.email, self.first_name, self.surname,self.phone)
				
	class Meta:
		verbose_name_plural='Enquires'
				

class EmailReceiver(models.Model):
	TYPE_CHOICES = [['enquiry','Enquiry'],]
	email = models.EmailField(unique=True)
	type = models.CharField(max_length=200, choices=TYPE_CHOICES)

	def __unicode__(self):
		return self.email
	
class SpammerList(models.Model):
    ip = models.CharField(max_length=50, unique=True)
    last_post = models.TextField()
    
    def __unicode__(self):
        return self.ip