from django import forms
from arkstart.userprofile.models import *
from django.contrib.auth.models import *
from django.contrib.auth import authenticate as _authenticate
class ProfileForm(forms.ModelForm):
    first_name = forms.CharField(max_length=30,required=True, error_messages={'required':'Please insert your First Name'})
    email = forms.EmailField(max_length=30,required=True,error_messages={'required':'Please insert your Email Address'})
    password = forms.CharField(max_length=30,required=True, widget=forms.PasswordInput(), error_messages={'required':'Please insert your Password'})
    password2 = forms.CharField(max_length=30,required=True, widget=forms.PasswordInput(), error_messages={'required':'Please confirm your Password'})    
    class Meta:
        model = Profile
        
    def __init__(self,*args, **kwargs):
        super(ProfileForm,self).__init__(*args,**kwargs)
        self.fields['user'].required = False
        self.fields['membertype'].required = False
        self.fields['interests'] = forms.ModelMultipleChoiceField(widget=forms.CheckboxSelectMultiple(),queryset=Interest.objects.all(), required=False, error_messages={'required':'Please select your Interests'})
        self.fields['mobile'].error_messages = {'required':'Please insert your Mobile Number'}
        self.fields['postcode'].error_messages = {'required':'Please insert your Postcode'}
        self.fields['comments'].error_messages = {'required':'Please insert your Comments'}
        
    def clean_password2(self):
        if self.cleaned_data['password'] != self.cleaned_data['password2']:
            raise forms.ValidationError('Passwords not match')
        return self.cleaned_data['password2']
        
    def clean_email(self):
        theemail = self.cleaned_data.get('email','')
        try:
            u = User.objects.get(username=theemail)
            
        except:
            u = ''
            
        if u:
            raise forms.ValidationError('This email address has been registered.')
        
        
        return self.cleaned_data
        
    def save(self, force_insert=False, force_update=False, commit=True):
        m = super(ProfileForm, self).save(commit=True)
        theemail = self.data['email']
        u = User.objects.create(username=theemail)
        u.set_password(self.data['password'])
        u.first_name = self.data['first_name']
        u.email = theemail
        u.save()
        
        m.user = u
        m.membertype = MemberType.objects.filter(super_member=False, member=True)[:1].get()

        m.save()
        
        
        return m

class LoginForm(forms.Form):
    email = forms.EmailField(max_length=30,required=True)
    password = forms.CharField(max_length=30,required=True, widget=forms.PasswordInput())
    user = None
    
    def clean(self):
        email = self.cleaned_data.get("email", "").strip().lower()
        username = email
        password = self.cleaned_data.get("password","")
        self.user = _authenticate(username=username, password=password)
        if self.user:
            if self.user.is_active:
                return self.cleaned_data
            else:
                raise forms.ValidationError("Your account is pending approval.")
        else:
            raise forms.ValidationError("Login Failed. Please enter your correct email address and password.")
        