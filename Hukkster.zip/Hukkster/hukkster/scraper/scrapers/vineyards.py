import json
import opengraph
import re
import pprint
import logging
from urlparse import urljoin

from lxml.html import fromstring, tostring
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions

logger = logging.getLogger('scraper')


def get_all_text(t):
    tl = t.xpath('.//text()')
    if isinstance(tl, list):
        return "".join(tl).strip()
    return tl


class VineyardsScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'vineyardvines.com'

    # def fetch_url(self):
    #     with open('mdata.html', 'r') as f:
    #         self.html = f.read()
    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ''
        skus = lxml.xpath('.//div[@class="itemNo productid"]/text()')
        if not skus:
            skus = lxml.xpath('.//div[@class="itemNo productID"]/text()')

        if skus:
                sku = skus[0]
        sku = sku.replace('Style # ', '')
        if sku == '':
                return []

        title = lxml.xpath('.//h2[@class="productname"]/text()')
        if title:
            title = title[0]

        product_standard_price = None
        product_original_price = None

        pl = lxml.xpath('.//div[@class="pricing"]/div[@class="price"]/div[@class="discountprice"]')
        if pl:
            pd = pl[0]
            price_standard = pd.xpath('.//div[@class="standardprice"]/text()')
            price_sales = pd.xpath('.//div[@class="salesprice"]/text()')

            if price_standard and price_sales:
                ps = price_standard[0].strip()
                prices = re.findall(r'\$(\d+\.\d+)', ps)
                product_original_price = float(prices[len(prices) - 1])
                ps = price_sales[0].strip()
                prices = re.findall(r'\$(\d+\.\d+)', ps)
                product_standard_price = float(prices[len(prices) - 1])

        pl = lxml.xpath('.//div[@class="pricing"]/div[@class="price"]')
        if pl and not product_standard_price:
            ptext = pl[0].xpath('.//div/text()')
            if ptext:
                ptext = ptext[0].strip()
                prices = re.findall(r'\$(\d+)', ptext)
                product_standard_price = float(prices[len(prices) - 1])

        colors = lxml.xpath('.//div[@class="swatches color"]/ul/li/a/@title')
        sizes = lxml.xpath('.//div[@class="swatches size"]/ul/li/a/@title')
        image = lxml.getroottree().xpath('.//div[@class="productdetailcolumn productimages"]/div[@class="productimage"]/img/@src')
        images = lxml.getroottree().xpath('.//div[@class="productthumbnails"]/img/@src')

        selections = []
        data_url = raw_data.get('url', '')

        data_store = lxml.getroottree().xpath('.//h1/a/@href')
        if data_store:
            data_store = data_store[0]
        data_url = urljoin(data_store, data_url)

        data_image = image

        if not colors:
            colors = ['Empty']
        if not sizes:
            sizes = ['Empty']

        for color in colors:
            for size in sizes:
                data = {'title': title,
                        'current_price': {
                            'value': product_standard_price
                            },
                        'url': data_url,
                        'store': data_store,
                        'image': data_image,
                        'images': images,
                        'local_id': sku,
                        'selections': {
                            'size': size,
                            'color': color,
                            },
                        'promos': []
                    }
                if color == 'Empty':
                    data['selections'] = {'size': size}
                if size == 'Empty':
                    data['selections'] = {'color': color}

                if product_standard_price and product_original_price:
                    data['original_price'] = {'value': product_original_price}
                    data['current_price'] = {'value': product_standard_price}
                selections.append(data)

        return selections

    def parse_multi_product(self, lxml, raw_data):
        tl = lxml.xpath('.//div[@class="productdetailcolumn productinfo"]')
        if len(tl) == 1:
            return(self.parse_single_product(tl[0], raw_data))

        tl = lxml.xpath('.//div[@class="productsetdetail"]/div[@class="productdetailcolumn productinfo"]')
        selections = []
        for te in tl:
            sel = self.parse_single_product(te, raw_data)
            selections.extend(sel)
        return selections

    def parse(self):
        logger.debug('%s parse started' % VineyardsScraper.get_domain())

        og = opengraph.OpenGraph(html=self.html)
        raw_data = dict([(k, v) for k, v in og.items()])
        if not self.html:
            raise HukksterTooManyOptions(VineyardsScraper.get_domain(), self.url)

        lxml = fromstring(self.html)
        selections = self.parse_multi_product(lxml, raw_data)
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(VineyardsScraper.get_domain(), self.url)
        return selections

if __name__ == '__main__':
    s = VineyardsScraper()
    s.fetch_url()
    print "Result=",
    pprint.pprint(s.parse())
