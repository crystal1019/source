
# all of your evolution scripts, mapping the from_version and to_version to a list if sql commands
_evolutions = [
    [('fv1:-4718295630184109050','fv1:-3163896399185255112'), # generated 2012-09-26 16:49:41.129837
        "ALTER TABLE `userprofile_profile` MODIFY COLUMN `user_id` integer NULL UNIQUE;",
        "ALTER TABLE `userprofile_profile` MODIFY COLUMN `membertype_id` integer NULL;",
    ],
    [('fv1:-1298390693144920934','fv1:8869771205959779764'), # generated 2013-01-16 11:20:20.357260
        "ALTER TABLE `userprofile_profile` MODIFY COLUMN `mobile` varchar(20) NULL;",
        "ALTER TABLE `userprofile_profile` MODIFY COLUMN `comments` longtext NULL;",
    ],
] # don't delete this comment! ## _evolutions_end ##
