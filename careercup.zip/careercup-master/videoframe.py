import masterpage

import method_url

class VideoFrame(masterpage.MasterPage):
	def get(self):	
		u = method_url.getStringParam(self, 'u')
		self.response.out.write(self.getBody({'url' : u}, 'html/videoframe.html')) 
