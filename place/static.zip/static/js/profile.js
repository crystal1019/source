/* PROFILE PAGE
 */


function profile_init(options) {

    // Connect to facebook
    $('a.connect_facebook').click(function(event) {
        $('#social-connect .facebook_connect_button form').submit();
    });

    // Connect to linkedin
    $('a.connect_linkedin').click(function(event) {
        $('#social-connect .linkedin_connect_button form').submit();
    });

    // Connect to twitter
    $('a.connect_twitter').click(function(event) {
        $('#social-connect .twitter_connect_button form').submit();
    });

}


/**
 * SETTINGS PAGE
 */
function avatar_upload_setup() {
    /*
        AVATAR UPLOAD
    */

    // Elements that will have lots of updates.
    var x_input = $('#id_x');
    var y_input = $('#id_y');
    var x2_input = $('#id_x2');
    var y2_input = $('#id_y2');
    var w_input = $('#id_w');
    var h_input = $('#id_h');
    var uploading_msg_span = $('.upload-status .message');

    // Add jcrop to image.
    function addCropping(img) {

        // Update the image crop inputs
        function updateForm(c) {
            x_input.val(c.x);
            y_input.val(c.y);
            x2_input.val(c.x2);
            y2_input.val(c.y2);
            w_input.val(c.w);
            h_input.val(c.h);
        }

        // Add jcrop tool to image.
        img.Jcrop({
            bgColor: '#fff',
            aspectRatio: 1,
            boxWidth: 560,
            boxHeight: 400,
            setSelect: [100, 100, 10, 10],
            bgOpacity: 0.30,
            onSelect: updateForm,
            onChange: updateForm
        });

    }

    // Add uploader functionality to Upload Button
    var uploader = new qq.FileUploader({
        // button: document.getElementById('profile-image-upload'),
        element: document.getElementById('profile-image-upload'),
        action: '/assets/avatar_upload/',
        debug: false,
        uploadButtonText: '<div>Add new profile image by clicking here.</div>',
        allowedExtensions: ['jpeg', 'jpg', 'gif', 'png'],
        onSubmit: function() {
            $('.upload-status').show();
        },
        onProgress: function(id, fileName, loaded, total) {
            // Messaging while the file is uploaded
            if (loaded < total) {
                var progress = Math.round(loaded / total * 100) + '% of ' + Math.round(total / 1024) + ' kB';
                uploading_msg_span.html('Uploading ' + progress);
            } else {
                uploading_msg_span.html('Saving');
            }
        },
        onComplete: function(id, fileName, responseJSON) {
            //$('.upload-status').hide();  // Hide upload status messaging
            $('#upload-section .qq-upload-list li').delay(3000).slideUp('fast');
            if (responseJSON.hasOwnProperty('success') && responseJSON.success === true) {
                $('#upload-section .error-msg').html(''); // Clear error message

                var img = $('#new-profile-image img');
                // Wait for image to load before collecting size.
                img.on('load', function() {
                    $('#id_scale_width').val(img.width());
                    $('#id_scale_height').val(img.height());
                    setTimeout(function() {
                        addCropping(img); // Add image crop functionality
                    }, 100);
                    // addCropping(img);  // Add image crop functionality
                });

                img.attr('src', responseJSON.url); // Assign new image to preview img.
                $('#new-profile-image').show(); // Show uploaded image

                $('#id_avatar').val(responseJSON.url); // Add image source to input
                // Set the avatar option to be PlaceSpeak
                $('#avatar-options .placespeak-image').click();
            } else {
                $('#upload-section error-msg').html(responseText.error);
            }
        },
        onError: function(id, fileName, reason) {
            $('#upload-section error-msg').html(reason);
        },
        showMessage: function(message) {
            $('#upload-section .error-msg').html(message);
        },
        template: '<div class="qq-uploader">' +
            '<div class="qq-upload-button" style="width: auto;">{uploadButtonText}</div>' +
            '<div class="qq-upload-drop-area">{dragText}</div>' +
            '<div class="list"><ul class="qq-upload-list" style="margin-top: 10px; text-align: center;"></ul></div>' +
            '</div>',
        fileTemplate: '<li>' +
            '<span class="qq-upload-finished"></span>' +
            '<span class="qq-upload-file"></span>' +
            '<span class="qq-upload-size"></span>' +
            '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
            '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
            '<span class="qq-upload-spinner"></span>' +
            '<div class="qq-progress-bar"></div>' +
            '<div class="clear_both"></div>' +
            '</li>'
    });
}

function keywords($ele, type) {
    $.ajax({
        url: '/profile/keywords/',
        type: 'post',
        data: {
            type: type,
            keyword_id: $ele.data("keyword"),
            csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
        },
        success: function(data) {}
    });
}

function settings_init(options) {

    $("#recommended-keywords").sortable({
        connectWith: ".keywords_box",
        receive: function(event, ui) {
            keywords($(ui.item), "unfollow");
        }
    }).disableSelection();

    $("#current-keywords").sortable({
        connectWith: ".keywords_box",
        receive: function(event, ui) {
            keywords($(ui.item), "follow");
        }
    }).disableSelection();

    $(document).on('click', '.delete_keyword span', function() {
        keywords($(this).closest('a'), "unfollow");
        $(this).closest('a').fadeOut();
    });

    $('#tab_account .change-picture').click(function() {
        var frm = new FormEditor('avatar_change', '/accounts/change_avatar/', {}, {
            response_type: 'html'
        });
        frm.setButton2Label('Save');
        frm.on('show', function() {
            // Toggle avatars
            $('#avatar-options .thumbnail').not('.disabled').click(function() {
                $('#avatar-options .thumbnail').removeClass('selected');
                $(this).addClass('selected');
                $('#id_avatar_type').val($(this).data('avatar-type'));
            });
            // Add Upload
            avatar_upload_setup();

            // Add Social connect ability.
            $('#avatar-options .disabled.facebook-image').click(function() {
                $('#avatar-social-connect .facebook_connect_button form').submit();
            });

            $('#avatar-options .disabled.twitter-image').click(function() {
                $('#avatar-social-connect .twitter_connect_button form').submit();
            });
        });

        frm.on('close', function() {
            $('#facebook-connect').off('click');
            $('#twitter-connect').off('click');
        });

        // TODO: make this more ajaxy....instead of page reload.
        frm.on('success', function() {
            window.location.reload();
        });
        frm.show();
    });


    /*
        PASSWORD CHANGE
    */
    $('#tab_account .change-password').click(function() {
        var frm = new FormEditor('password_change', '/accounts/change_password/', {});
        frm.show();
    });

    /*
        SOCIAL CONNECTIONS
    */

    // Add Social connect ability.
    $('.social-connections .facebook a').click(function() {
        $('#account-social-connect .facebook_connect_button form').submit();
    });
    $('.social-connections .linkedin a').click(function() {
        $('#account-social-connect .linkedin_connect_button form').submit();
    });

    $('.social-connections .twitter a').click(function() {
        $('#account-social-connect .twitter_connect_button form').submit();
    });


    $('a.submit').click(function() {
        $(this).closest("form").submit();
        return false;
    });

    $('.topic-disconnect').click(function() {
        var self = this;
        confirmation_dialog(
            'Disconnect From Topic',
            '<p>Are you sure you want to disconnect from this topic?</p>',
            function() {
                $.ajax({
                    url: '/topic/disconnect/',
                    type: 'post',
                    data: {
                        topic: $(self).data('topic'),
                        csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
                    },
                    success: function(obj) {
                        if (obj.success) {
                            $(self).closest('li').slideUp('fast').remove();
                        } else {
                            if (obj.reason === 'login_required') {
                                redirect_to_login();
                            }
                        }

                    }
                });
            }
        );
    });

    $("#form-privacy .submit").click(function() {
        var self = this;
        if ($(self).hasClass('disabled')) return;
        $(self).addClass('disabled');
        $('#form-privacy').ajaxSubmit({
            type: 'POST',
            clearForm: false,
            resetForm: false,
            dataType: 'json',
            success: function(obj, statusText, xhr, $form) {
                if (obj.success) {
                    $('#privacy-messages')
                        .removeClass('alert-error')
                        .addClass('alert-info')
                        .html('<h5>Saved</h5>')
                        .show()
                        .delay(3000)
                        .slideUp('fast', function() {
                            $(this).hide();
                        });
                } else {
                    if (obj.reason === 'login_required') {
                        redirect_to_login();
                    } else {
                        $('#privacy-messages')
                            .removeClass('alert-info')
                            .addClass('alert-error')
                            .html('<p>' + obj.messages.join('</p><p>') + '</p>')
                            .show();
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {

            },
            complete: function() {
                $(self).removeClass('disabled');
            }
        });
        return;
    });

    $('.validation-form .button').click(function() {
        var self = this;

        if ($(self).hasClass('disabled')) return;

        $(self).addClass('disabled');
        var form = $(this).closest('.validation-form');
        $(form).ajaxSubmit({
            type: 'POST',
            clearForm: true,
            resetForm: false,
            dataType: 'json',
            success: function(obj, statusText, xhr, $form) {
                if (obj.success) {
                    $(form)
                        .find('.alert')
                        .removeClass('alert-error')
                        .addClass('alert-info')
                        .html('<p>' + obj.message.join('</p><p>') + '</p>')
                        .show()
                        .delay(5000)
                        .slideUp('fast', function() {
                            $(this).hide();
                        });

                    if (obj.data.hasOwnProperty('confirmed') && obj.data.confirmed) {
                        $(self)
                            .closest('li')
                            .find('.verified')
                            .removeClass('hidden');
                    }
                } else {
                    $(form)
                        .find('.alert')
                        .removeClass('alert-info')
                        .addClass('alert-error')
                        .html('<p>' + obj.message.join('</p><p>') + '</p>')
                        .show()
                        .delay(10000).slideUp('fast', function() {
                            $(this).hide();
                        });
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {},
            complete: function() {
                $(self).removeClass('disabled');
            }
        });
    });

    $("#form-notifications .submit").click(function() {
        var self = this;
        if ($(self).hasClass('disabled')) return;
        $(self).addClass('disabled');
        $('#form-notifications').ajaxSubmit({
            type: 'POST',
            clearForm: false,
            resetForm: false,
            dataType: 'json',
            success: function(obj, statusText, xhr, $form) {
                if (obj.success) {
                    $('#notifications-messages')
                        .removeClass('alert-error')
                        .addClass('alert-info')
                        .html('<h5>Saved</h5>')
                        .show()
                        .delay(3000)
                        .slideUp('fast', function() {
                            $(this).hide();
                        });
                } else {
                    if (obj.reason === 'login_required') {
                        redirect_to_login();
                    } else {
                        $('#notifications-messages')
                            .removeClass('alert-info')
                            .addClass('alert-error')
                            .html('<p>' + obj.messages.join('</p><p>') + '</p>')
                            .show();
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {

            },
            complete: function() {
                $(self).removeClass('disabled');
            }
        });

    });

    // $('select').uniform();

    //Jump to specific topic setting
    if (from_topic != false) {
        $('#topic-priv-' + from_topic)
            .addClass('active')
            .siblings('.content')
            .slideDown('fast');
        $('html,body').animate({
            scrollTop: $('#topic-priv-' + from_topic).offset().top - 50
        }, 1000);
    }
}

function editplace_init() {

    // $('select').uniform();
    $('#edit-place .submit').click(function(e) {
        $(this).closest("form").submit();
    });
    load_editplace_map(place);
}

/* Keywords */

//TODO
/* END SETTINGS PAGE */

$('#geoloc-learnmore').click(function() {
    var title = "Geolocation Verification Details";
    var msg = "<p>Verification provides the assurance that users are indeed \
     residing at the address they provide, ensuring a secure and trusted environment.</p> \
    <p>You must be currently located at the address you are trying to verify.</p> \
    <p>When verifying, your browser will prompt you to temporarily share your location, \
    the sharing of location will be used solely and only by PlaceSpeak for the purpose of verification. </p> \
    <p>Your shared location is not stored by PlaceSpeak or used for any \
    other purpose or at any other time other than for the purpose of geolocation verification of your address.</p>";

    close_dialog(title, msg, function() {});
});