$(document).ready(function() {
    var videopromoplayer = $("#videopromoplayer");
    var videopromothumbnails = $("#videopromothumbnails");
    videopromoplayer.owlCarousel({
        singleItem: true,
        slideSpeed: 1000,
        navigation: false,
        pagination: false,
        afterAction: syncPosition,
        responsiveRefreshRate: 200,
        transitionStyle: "fade"
    });
    videopromothumbnails.owlCarousel({
        items: 4,
        pagination: false,
        responsiveRefreshRate: 100,
        afterInit: function(el) {
            el.find(".owl-item").eq(0).addClass("synced");
        }
    });

    function syncPosition(el) {
        var current = this.currentItem;
        $("#videopromothumbnails").find(".owl-item").removeClass("synced").eq(current).addClass("synced");
        if ($("#videopromothumbnails").data("owlCarousel") !== undefined) {
            center(current);
        }
    }
    $("#videopromothumbnails").on("click", ".owl-item", function(e) {
        e.preventDefault();
        var number = $(this).data("owlItem");
        videopromoplayer.trigger("owl.goTo", number);
    });

    function center(number) {
        var videopromothumbnailsvisible = videopromothumbnails.data("owlCarousel").owl.visibleItems;
        var num = number;
        var found = false;
        for (var i in videopromothumbnailsvisible) {
            if (num === videopromothumbnailsvisible[i]) {
                var found = true;
            }
        }
        if (found === false) {
            if (num > videopromothumbnailsvisible[videopromothumbnailsvisible.length - 1]) {
                videopromothumbnails.trigger("owl.goTo", num - videopromothumbnailsvisible.length + 2);
            }
            else {
                if (num - 1 === -1) {
                    num = 0;
                }
                videopromothumbnails.trigger("owl.goTo", num);
            }
        }
        else if (num === videopromothumbnailsvisible[videopromothumbnailsvisible.length - 1]) {
            videopromothumbnails.trigger("owl.goTo", videopromothumbnailsvisible[1]);
        }
        else if (num === videopromothumbnailsvisible[0]) {
            videopromothumbnails.trigger("owl.goTo", num - 1);
        }
    }
});