from scrapy import log


class ProductValidatorPipeline(object):
    def open_spider(self, spider):
        self.invalid_items = 0
        self.incomplete_items = 0

    def process_item(self, item, spider):
        invalid = 0
        incomplete = 0
        
        url = item.get('url')
        
        if item.get('sku') is None:
            spider.log("Product from {} has no SKU.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('name') is None:
            spider.log("Product from {} has no name.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('available') is None:
            spider.log("Product from {} has no availability.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('available') and item.get('price') is None:
            spider.log(("Product from {} is available but has no price."
                        ).format(url), level=log.ERROR)
            invalid = 1
        if item.get('image_url') is None:
            spider.log("Product from {} has no image URL.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('instalments') is None:
            spider.log("Product from {} has no instalment count.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('instalment_value') is None:
            spider.log("Product from {} has no instalment value.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('special_price') is None:
            spider.log("Product from {} has no sale price.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('brand') is None:
            spider.log("Product from {} has no brand.".format(url),
                       level=log.ERROR)
            invalid = 1
        if item.get('categories') is None:
            spider.log("Product from {} has no categories.".format(url),
                       level=log.ERROR)
            invalid = 1

        if item.get('product_identification') is None:
            spider.log(("Product from {} has no identification code."
                        ).format(url), level=log.WARNING)
            incomplete = 1
        if item.get('part_number') is None:
            spider.log(("Product from {} has no manufacturer part number."
                        ).format(url), level=log.WARNING)
            incomplete = 1
        
        self.invalid_items += invalid
        self.incomplete_items += incomplete
        
        return item

    def close_spider(self, spider):
        if self.invalid_items:
            spider.log("{} likely invalid items.".format(self.invalid_items),
                       level=log.ERROR)
        if self.incomplete_items:
            spider.log("{} incomplete items.".format(self.incomplete_items),
                       level=log.WARNING)
