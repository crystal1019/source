from django.db import models
from django.contrib.sites.models import Site
from offers.core.models import Offer

class PostClick(models.Model):
    offer = models.ForeignKey(Offer)
    site = models.ForeignKey(Site)
    features = models.TextField(blank=True, null=True, help_text='Separate entries using new line (simply press "Enter")')
        
    @property
    def offer_features(self):
        try:
            return self._features
        except AttributeError:
            pass
        self._features = (self.features or '').split('\n')
        return self._features