import re
from datetime import date
from django.db.models import Q
from django import forms
from django.utils.html import strip_tags
from offers.helpers.lead.helpers import get_age
from offers.helpers.lead.models import State
from offers.core.models import Category
from models import STATUS_CHOICES


extract = lambda x: [(c.id, strip_tags(c.name.replace('Credit Cards', ''))) for c in x]
_get_choice_widget = lambda: forms.widgets.Select(attrs={'class':'smartdropdowntext2 fn1semibold smartdropdowntop input-xxlarge'})
INPUT_CLASS = 'smartrowinput fn1semibold fsmenu input-xxlarge'


class BankForm(forms.Form):
    bank = forms.ChoiceField()
    
    def __init__(self, *args, **kwargs):
        super(BankForm, self).__init__(*args, **kwargs)
        _filter = Q(parent__slug = 'credit-card-issuers') | \
                  Q(parent__slug = 'other-credit-card-issuers')
        banks = Category.on_site.filter(_filter, is_visible=True
                               ).exclude(slug='mastercard-credit-cards'
                               ).exclude(slug='visa-credit-cards')
        banks = extract(banks) + [(0, "Don't have one"), (0, "Other bank")]
        self.fields['bank'].choices = banks


class SmartSearch1(forms.Form):
    BALANCE_TRANSFER_CHOICES = (
        ('Balance Transfer Rate', 'Low Interest'),
        ('Balance Transfer Period', 'Longer Deal'),
        ('No Interest', 'No Interest On Balance Transfers and Purchases'),
        ('Don\'t Know', 'I Don\'t Know'),
    )
    AIRLINE_CHOICES = (
        ('emirates-skywards-', 'Emirates'),
        ('qantas-frequent-flyer-', 'Qantas'),
        ('virgin-australia-', 'Virgin Australia'),
        ('amex-frequent-flyer-', 'American Express Membership Rewards'),
    )
    REWARD_CHOICES = (
        ('cash-back-', 'Cash Back'),
        ('retail-rewards-', 'Retail Rewards'),
        ('petrol-', 'Petrol'),
        ('sign-up-bonus-', 'Sign Up Bonus'),
    )
    INSURANCE_CHOICES = (
        ('Extended Warranty Insurance', 'Extended Warranty Insurance'),
        ('International Travel Insurance', 'International Travel Insurance'),
        ('Interstate Flight Inconvenience', 'Interstate Flight Inconvenience'),
        ('Personal Item Theft Cover', 'Personal Item Theft Cover'),
        ('Price Protection Insurance', 'Price Protection Insurance'),
        ('Purchase Protection Insurance', 'Purchase Protection Insurance'),
        ('Transport Accident Insurance', 'Transport Accident Insurance'),
    )
    cardtype = forms.ChoiceField(widget=_get_choice_widget())
    balance_transfer = forms.ChoiceField(choices=BALANCE_TRANSFER_CHOICES, widget=_get_choice_widget())
    frequent_flyer = forms.ChoiceField(choices=AIRLINE_CHOICES, widget=_get_choice_widget())
    rewards = forms.ChoiceField(choices=REWARD_CHOICES, widget=_get_choice_widget())
    insurance = forms.ChoiceField(choices=INSURANCE_CHOICES, widget=_get_choice_widget())
    
    def __init__(self, *args, **kwargs):
        super(SmartSearch1, self).__init__(*args, **kwargs)
        _filter = Q(parent__slug='credit-card-features') | \
                  Q(slug='debit-cards')
        features = Category.on_site.filter(_filter
                                  ).exclude(slug='bad-credit-cards'
                                  ).exclude(slug='best-credit-cards'
                                  ).exclude(slug='cash-back-credit-cards'
                                  ).exclude(slug='gold-credit-cards'
                                  ).exclude(slug='platinum-credit-cards'
                                  ).order_by('name')
        cardtypes = [(1,'All Credit Cards')] + extract(features)
        self.fields['cardtype'].choices = cardtypes
    
class SmartSearch(forms.Form):
    cardtype = forms.IntegerField(widget=forms.widgets.HiddenInput())
    balance_transfer = forms.CharField(max_length=50, required=False, widget=forms.widgets.HiddenInput())
    frequent_flyer = forms.CharField(max_length=50, required=False, widget=forms.widgets.HiddenInput())
    rewards = forms.CharField(max_length=50, required=False, widget=forms.widgets.HiddenInput())
    insurance = forms.CharField(max_length=50, required=False, widget=forms.widgets.HiddenInput())
    firstname = forms.CharField(max_length=30, label='first name', widget=forms.TextInput(attrs = {'class': INPUT_CLASS, 'placeholder': 'First name'}))
    lastname = forms.CharField(max_length=30, label='last name', widget=forms.widgets.TextInput(attrs={'class': INPUT_CLASS, 'placeholder': 'Last name'}))
    birthday = forms.ChoiceField()
    birthmonth = forms.ChoiceField()
    birthyear = forms.ChoiceField()
    workstatus = forms.ChoiceField(choices=STATUS_CHOICES, widget=_get_choice_widget())
    income = forms.CharField(label='annual income', widget=forms.widgets.TextInput(attrs={'class': INPUT_CLASS, 'placeholder': 'Enter your annual income. e.g. 50000'}))
    email = forms.EmailField(label='email', widget=forms.widgets.TextInput(attrs={'class': INPUT_CLASS, 'placeholder': 'john@citizen.com.au'}))
    state = forms.ChoiceField()
    term = forms.BooleanField(error_messages={'required': 'You must agree to our Privacy Policy.'}, initial=True)
    voucher = forms.BooleanField(required=False, initial=True)
    
    def __init__(self, *args, **kwargs):
        def create_choices(*args):
            choice_range = range(*args)
            return zip(choice_range, choice_range)
        
        super(SmartSearch, self).__init__(*args, **kwargs)
        
        self.fields['state'].choices = extract(State.objects.order_by('name'))
        self.fields['birthday'].choices = create_choices(1, 31+1)
        self.fields['birthmonth'].choices = create_choices(1, 12+1)
        year_now = date.today().year
        self.fields['birthyear'].choices = create_choices(year_now-18,
                                                          year_now-100,
                                                          -1)
        
    def clean_birthyear(self):
        if get_age(self.cleaned_data) < 18:
            raise forms.ValidationError(u'You must be at least 18 years old' +
                                        ' to apply for a credit card.')
        return self.cleaned_data['birthyear']
        
    def _clean_initial(self, name):
        data = self.cleaned_data[name]
        if data == self.fields[name].initial:
            raise forms.ValidationError(u'Please enter your %s.' % self[name].label)
        return data
        
    def clean_firstname(self):
        return self._clean_initial('firstname')
        
    def clean_lastname(self):
        return self._clean_initial('lastname')
        
    def clean_income(self):
        data = self._clean_initial('income')
        try:
            return float(re.sub("[^\d\.]", "", data))
        except ValueError:
            raise forms.ValidationError(u'Please enter a number.')
        
    def clean_email(self):
        return self._clean_initial('email')
