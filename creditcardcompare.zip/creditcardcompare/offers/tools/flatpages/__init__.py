from django.apps import AppConfig

class FlatPageConfig(AppConfig):
    name = 'offers.tools.flatpages'
    label = 'custom_flatpages'

default_app_config = 'offers.tools.flatpages.FlatPageConfig'