from django.conf.urls import patterns, include, url

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
from oscar.app import application
from accounts.dashboard.app import application as accounts_app
from accounts.views import AccountBalanceView
from gap.views import product_options, get_quote

admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'geniusautoparts.views.welcome', name='welcome'),
    # url(r'^geniusautoparts/', include('geniusautoparts.foo.urls')),


    # Uncomment the admin/doc line below to enable admin documentation:
    url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),

    url(r'^admin_tools/', include('admin_tools.urls')),
    
    url(r'^giftcard-balance/', AccountBalanceView.as_view(),
        name="account-balance"),
    (r'^dashboard/accounts/', include(accounts_app.urls)),
    url(r'^product-options/(?P<p_class>\d+)/(?P<id>\d+)/(?P<step>\d+)/$', product_options, name='product_options'),
    url(r'^get-quote/(?P<id>\d+)/$', get_quote, name='get_quote'),
    (r'', include(application.urls))
)
