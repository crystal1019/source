#!/bin/bash

PROJNAME="recipedrop"
RUNDIR="/var/run/uwsgi"
LOGDIR="/var/log/uwsgi"
USER="vadik"
GROUP="vadik"

WORKERS=2

PARENTDIR=$(dirname $(dirname $(readlink -f $0)))
PROJDIR=${PARENTDIR}/${PROJNAME}
PYTHONPATH="${PARENTDIR}"
ENVDIR="${PROJDIR}/env"
UWSGIEXEC="${ENVDIR}/bin/uwsgi"
NEWRELIC="${ENVDIR}/bin/newrelic-admin"
PIDFILE="${RUNDIR}/recipedrop.pid"
SOCKFILE="${RUNDIR}/recipedrop.sock"
LOGFILE="${LOGDIR}/recipedrop.log"
WSGIFILE="${PROJDIR}/wsgi.py"
# Touch-reload for Git
TOUCHFILE="${PROJDIR}/.git/index"
# Touch-reload for HG
#TOUCHFILE="${PROJDIR}/.hg/dirstate"

start() {

    echo start

    NEW_RELIC_CONFIG_FILE=newrelic.ini ${NEWRELIC} run-program ${UWSGIEXEC} \
        --master --workers ${WORKERS} \
        --uid ${USER} --gid ${GROUP} --pidfile ${PIDFILE} \
        --socket ${SOCKFILE} \
        --daemonize ${LOGFILE} \
        --wsgi-file ${WSGIFILE} \
        --virtualenv ${ENVDIR} --chdir ${PROJDIR} \
        --pythonpath ${PYTHONPATH} --env DJANGO_SETTINGS_MODULE=settings \
        --enable-threads --single-interpreter --log-date \
        --touch-reload ${TOUCHFILE}
# --chmod-socket 660 \

}
stop() {
    echo "stop"
    kill -INT `cat ${PIDFILE}`
}

restart() {
    echo "restart"
    kill -TERM `cat ${PIDFILE}`
}

forcerestart() {
    echo "restart"
    kill -INT `cat ${PIDFILE}`
    sleep 2
    kill -KILL `cat ${PIDFILE}`
    killall -INT -u ${USER} uwsgi
    sleep 2
    killall -KILL -u ${USER} uwsgi
    start
}

reload() {
    echo "reload"
    kill -HUP `cat ${PIDFILE}`
}

status() {
    echo "status check"
    ${UWSGIEXEC} --socket ${SOCKFILE} --nagios && exit 0 || exit 1
}

case $1 in
    start)
        start
        exit
    ;;
    stop)
        stop
        exit
    ;;
    restart)
        restart
        exit
    ;;
    forcerestart)
        forcerestart
        exit
    ;;
    reload)
        reload
        exit
    ;;
    status)
        status
        exit
    ;;
esac
echo "Unknown option"

