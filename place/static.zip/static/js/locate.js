var lat, lng;
var coords = [];
var watchId;
var button;
var userlng;
var userlat;
var spherical;
var img = '/static/img/geo_icons/success_confirm.png';
var located = false;
var timeout = false;
var distance;
var accuracy;
var placeid;
var finalDistance;
$(document).ready(function() {
	if(navigator.geolocation){
	init();		
	}else{
	notSupportedError("Your browser does not support this method of verification");
	}
});

function init() {
	$("#mobileedit").click(mobiletel_swap);
	$("#homeedit").click(hometel_swap);
	$(".locate_btn").click(function() {
		located = false;
		timeout = false;
		$("#loading").show();
		$("#geo1").hide();
		$("#info").hide();
		button = $(this);
		placeid = $(this).data("place-id");
		var coords = ($(this).data("place-coords"));
		lat = coords[0];
		lng = coords[1];
		
		
		if (navigator.geolocation) {
			opts = {
				enableHighAccuracy: true,
				maximumAge: 0
			};
			watchId = navigator.geolocation.watchPosition(showPosition, handleError, opts), setTimeout(function() {
				timeout = true;
				if (!located) {
					navigator.geolocation.clearWatch(watchId);
					if (typeof distance !== 'undefined') {
						var distString = distance.toString().split(".");
						var distanceM = distString[0];
						if (distance > 100) {
							if (distanceM > 999) {
								var fd = (distanceM / 1000).toString().split(".");
								finalDistance = fd[0] + " km's";
							} else {
								finalDistance = distanceM + " m's";
							}
							handleError2("You have been located " + finalDistance + " from this address");
						} else {
							handleError2("Your location can't be accessed at this time");
						}
					} else {
						handleError2("Your browser has denied access to your location");
					}
				}
			}, 10000);
		}
	});
	$("#geo_back1").click(swapout);
	$("#geo_back2").click(swapout);
}

function showPosition(position) {
	var spherical = google.maps.geometry.spherical;
	userlng = position.coords.longitude;
	userlat = position.coords.latitude;
	accuracy = position.coords.accuracy;
	var user_point = new google.maps.LatLng(userlat, userlng);
	var new_point = new google.maps.LatLng(lat, lng);
	distance = spherical.computeDistanceBetween(user_point, new_point);
	if (typeof distance !== 'undefined') {
		if (distance <= 100) {
			navigator.geolocation.clearWatch(watchId);
			located = true;
			$.ajax({
				type: "POST",
				url: "/validate/geolocation/",
				data: {
					id: placeid,
					lat: userlat,
					lng: userlng,
					csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
				},
				success: success
			});
		}
	}
}

function success(data) {
	$("#target").html(data.html);
	init();
	$('#loading').hide();
	$('#geo1').hide();
	$("#geo2").show();
}

function handleError(error) {
	navigator.geolocation.clearWatch(watchId);
}

function handleError2(a) {
	navigator.geolocation.clearWatch(watchId);
	$('#loading').hide();
	$("#errorh5").html(a);
	$('#geo3').show();
}
function notSupportedError(a) {

	$("#geo_info").html("<h5 style='color:#DA4A38'>"+a+"</h5>");
	$(".locate_btn").addClass("disabled");
	
}

function swapout() {
	init();
	$('#geo1').show();
	$("#geo2").hide();
	$("#geo3").hide();
}

function hometel_swap() {
	$('#hometel1').show();
	$("#hometel2").hide();
}

function mobiletel_swap() {
	$('#mobiletel1').show();
	$("#mobiletel2").hide();
}