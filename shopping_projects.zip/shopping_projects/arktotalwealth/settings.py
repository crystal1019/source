# Django settings for arktotalwealth project.
import sys
sys.path = ['/usr/lib/python2.4/site-packages'] + sys.path
sys.path = ['/usr/lib/python2.4/site-packages/PIL'] + sys.path

import deseb

DEBUG = False
TEMPLATE_DEBUG = DEBUG

ADMINS = (
    # ('chaol', 'chaol@1md.com.au'),
)

SERVER_EMAIL = 'root@arktotalwealth.com.au'
MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'arktotalwealth_new',                      # Or path to database file if using sqlite3.
        'USER': 'root',                      # Not used with sqlite3.
        'PASSWORD': 'root',                  # Not used with sqlite3.
        'HOST': '10.0.6.7',                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
    }
}

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'Australia/Sydney'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

BLOG_POSTS_PER_PAGE = 8

DOMAIN = 'www.arktotalwealth.com.au'
PRIVATE_KEY = 'dou8leiv7@3l+f$3wemqwdy!$4(w6#&$d7z$s!cd!en$@n(0^^m@sh6cdou8le'
PRIVATE_MESSAGE = 'greedy is good'

EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'arktotalwealth@gmail.com'
EMAIL_HOST_PASSWORD = 'arktotalwealth1'
EMAIL_PORT = 587
EMAIL_USE_TLS = True

DEFAULT_FROM_EMAIL = 'Info <info@arktotalwealth.com.au>'



EMAIL_FROM = 'info@arktotalwealth.com.au'

RHEC_ADMIN_APP_WEIGHTS = {
                          'Auth' : (1,'Auth'),
                          'Emails':(2,'Email & Database Management'),
                          'Component':(3,"Generic Components"),                            
                          'Website':(4,"Website Content"),
                          'Overview':(5,"Overview"),
                          'Service':(6,'Our Services'),
                          'Team':(7,'Team'),
                          'Mediacenter':(9,'Media Center'),
                          'Twitterplan': (10, 'Twitter Planner'),
                          'Tagging':(11,'Tagging'),
                          }


HAYSTACK_SITECONF = 'arktotalwealth.search_sites'
HAYSTACK_SEARCH_ENGINE = 'whoosh'
HAYSTACK_WHOOSH_PATH = '/var/www/vhosts/arktotalwealth.com.au/httpdocs/media/whoosh_index/'
CAPTCHA_OUTPUT_FORMAT = "<td width='108' valign='top'>%(image)s</td><td align='left' valign='middle'>%(hidden_field)s %(text_field)s"
PRIVATE_KEY = 'dou8leiv7@3l+f$3wemqwdy!$4(w6#&$d7z$s!cd!en$@n(0^^m@sh6cdou8le'
PRIVATE_MESSAGE = 'greedy is good'

FILEBROWSER_MAX_UPLOAD_SIZE = 20971520
FILEBROWSER_EXTENSIONS = {
    'Folder': [''],
    'Image': ['.jpg','.jpeg','.gif','.png','.tif','.tiff'],
    'Document': ['.pdf','.doc','.rtf','.txt','.xls','.csv','.swf','.flv'],
    'Video': ['.mov','.wmv','.mpeg','.mpg','.avi','.rm'],
    'Audio': ['.mp3','.mp4','.wav','.aiff','.midi','.m4p']
}
# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale
USE_L10N = True

# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
MEDIA_ROOT = '/var/www/vhosts/arktotalwealth.com.au/httpdocs/media/'

CSV_EXPORT_ROOT = '/var/www/vhosts/arktotalwealth.com.au/httpdocs/media/images/export.csv'
# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash.
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"
MEDIA_URL = '/media/'

CSV_EXPORT_URL = '/media/images/export.csv'
# Absolute path to the directory static files should be collected to.
# Don't put anything in this directory yourself; store your static files
# in apps' "static/" subdirectories and in STATICFILES_DIRS.
# Example: "/home/media/media.lawrence.com/static/"
STATIC_ROOT = ''

# URL prefix for static files.
# Example: "http://media.lawrence.com/static/"
STATIC_URL = '/media/'

# URL prefix for admin static files -- CSS, JavaScript and images.
# Make sure to use a trailing slash.
# Examples: "http://foo.com/static/admin/", "/static/admin/".
ADMIN_MEDIA_PREFIX = '/media/adminmedia/'

# Additional locations of static files
STATICFILES_DIRS = (
    # Put strings here, like "/home/html/static" or "C:/www/django/static".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
)

# List of finder classes that know how to find static files in
# various locations.
STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
#    'django.contrib.staticfiles.finders.DefaultStorageFinder',
)

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'iv7@3l+f$3wemqwdy!$4(w6#&$d7z$s!cd!en$@n(0^^m@sh6c'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
#     'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    "django.core.context_processors.auth",
    "django.core.context_processors.request",
    #'grappelli.context_processors.admin_template_path'
)

GRAPPELLI_ADMIN_TITLE = 'ArkTotalWealth'

ROOT_URLCONF = 'arktotalwealth.urls'

TEMPLATE_DIRS = (
    "/home/chaol/projects/arktotalwealth/templates"
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
)

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
   # 'django.contrib.staticfiles',
    
    'arktotalwealth.component',
    'arktotalwealth.service',
    'arktotalwealth.mediacenter',
    'arktotalwealth.team',
    'arktotalwealth.website',
    'arktotalwealth.overview',
    'arktotalwealth.emails',
    'captcha',
    'haystack',
    'tagging',
    'twitterplan',
    'grappelli',
    'filebrowser',
    # Uncomment the next line to enable the admin:
    'django.contrib.admin',
    # Uncomment the next line to enable admin documentation:
    # 'django.contrib.admindocs',
    'django.contrib.sitemaps',
)

# A sample logging configuration. The only tangible logging
# performed by this configuration is to send an email to
# the site admins on every HTTP 500 error.
# See http://docs.djangoproject.com/en/dev/topics/logging for
# more details on how to customize your logging configuration.
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
    }
}
