angular.module('activity.directives', []).directive('scrollToSelected', [function(){
	return function(scope, elem, attrs) {
		scope.$watch("highlighted", function(nv, ov){
			if(nv !== null && attrs['scrollToSelected'] === 'false'){
				//This is really shit but had to wait for the class to be applied by angular...
				setTimeout(function(){
					elem.scrollTop(elem.scrollTop() + $($(".selected")[0]).position().top - elem.height() / 2 + $($(".selected")[0]).height() / 2);
				}, 2);
			}
		});
	};
}]);