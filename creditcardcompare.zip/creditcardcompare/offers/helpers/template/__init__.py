from django.conf import settings

OFFER = 0
CATEGORY = 1

METAFIELD_END_DATE_FORMAT = {
    'creditcardcompare.com.au': '%%(%d)s %B %Y',
    'financechoices.co.uk': '%d %B %Y',
    'frequentflyercreditcards.com.au': '%d.%m.%Y',
    'goldcreditcards.com.au': '%d.%m.%Y',
    'moneycompare.com.au': '%d/%m/%Y',
    'click4credit.com.au': '',
}
METAFIELD_END_DATE_PREFIX = {
    'airlinecreditcards.com.au': ' up to ',
    'frequentflyercreditcards.com.au': ' valid up to ',
    'goldcreditcards.com.au': ' through ',
    'moneycompare.com.au': ' available up to ',
    'click4credit.com.au': '',
}
CUSTOM_DATE_FORMAT = {
    '01':'1st',
    '02':'2nd',
    '03':'3rd',
    '21':'21st',
    '22':'22nd',
    '23':'23rd',
    '31':'31st',
}
META_DUMMY_VALUES = ('-', 'na', 'n.a.', 'n/a', 'none', 'None')
META_VALUE_DEFAULT_CATEGORY_FORMAT = '<td>%(meta_value)s</td>'
META_VALUE_DEFAULT_OFFER_FORMAT = '%(meta_value)s'
META_VALUE_CATEGORY_FORMAT = {
    'creditcardhelp.com.au': '<td class=meta>%(meta_value)s</td>',
    'financechoices.co.uk': '<li>%(meta_value)s</li>',
    'savingup.com.au': '<td class=meta>%(meta_value)s</td>',
}
META_VALUE_OFFER_FORMAT = {
    'airlinecreditcards.com.au': '<tr><td><strong>%(meta_key)s</strong></td><td>%(meta_value)s</td></tr>',
    'broadbandcompare.com.au': '<li>%(meta_value)s</li>',
    'frequentflyercreditcards.com.au': '<tr><td><strong>%(meta_key)s</strong></td><td>%(meta_value)s</td></tr>',
    'goldcreditcards.com.au': '%(meta_value)s',
}
META_VALUE_INTRO_FORMAT = {
    'creditcardcompare.com.au': '%(rate)s%% for %(period)s<br /> then %%(meta_value)s',
    'creditcardhelp.com.au': '%(rate)s%% for %(period)s<br />(reverts to %%(meta_value)s)',
    'savingup.com.au': '%(rate)s %%(conjunction) %(period)s<br /> then %%(meta_value)s',
}

def site_format_date(_date, site_name=''):
    site_name = site_name or settings.SITE_NAME
    if _date:
        date_format = METAFIELD_END_DATE_FORMAT.get(site_name, '%d/%m/%Y')
        date_prefix = METAFIELD_END_DATE_PREFIX.get(site_name, ' until ') 
        end_date = date_prefix + _date.strftime(date_format)
        try:
            return end_date % CUSTOM_DATE_FORMAT
        except KeyError:
            day = _date.strftime('%d')
            return end_date % {day:day.lstrip('0')+'th'}
    else:
        return ''
    
def site_format_meta(meta_value, intro_value, 
                     site_name=settings.SITE_NAME, page=CATEGORY, meta_key=None):
    data = {'meta_value': meta_value, 'meta_key': meta_key}
    if intro_value and meta_value != intro_value['rate'] \
    and intro_value['rate'] not in META_DUMMY_VALUES:
        data['meta_value'] = _insert_intro_value(site_name, intro_value, data)
    if page: # if CATEGORY   
        return META_VALUE_CATEGORY_FORMAT.get(
                                    site_name, 
                                    META_VALUE_DEFAULT_CATEGORY_FORMAT) % data
    return META_VALUE_OFFER_FORMAT.get(site_name, 
                                       META_VALUE_DEFAULT_OFFER_FORMAT) % data
                                       
def _insert_intro_value(site_name, intro_value, data):
    intro_meta_value = META_VALUE_INTRO_FORMAT.get(site_name, '') % intro_value
    if site_name == 'savingup.com.au' \
    and len(intro_value['period'].strip().split()) != 2:
        data.update({'conjunction': 'ultil'})
    elif site_name == 'savingup.com.au':
        data.update({'conjunction': 'ultil'})
    if intro_meta_value:
        return intro_meta_value % data
    else:
        return intro_value['rate']