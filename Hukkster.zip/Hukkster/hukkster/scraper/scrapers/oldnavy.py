from .base_gap import BaseGapScraper

 
class OldNavyGapScraper(BaseGapScraper):
    @staticmethod
    def get_domain():
        return 'oldnavy.gap.com'

    def _get_store(self):
        return 'oldnavy.gap'
