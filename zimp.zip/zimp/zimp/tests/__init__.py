INSTALLED = False

from .general import *
