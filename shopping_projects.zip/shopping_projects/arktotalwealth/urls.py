from django.conf.urls.defaults import patterns, include, url

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

from django.conf import settings
from arktotalwealth.sitemap import *

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'arktotalwealth.views.home', name='home'),
    # url(r'^arktotalwealth/', include('arktotalwealth.foo.urls')),

	(r'^services/', include('arktotalwealth.service.urls')),
	(r'^team/', include('arktotalwealth.team.urls')),
	(r'^financial-advice/', include('arktotalwealth.mediacenter.urls')),
    (r'^overview/', include('arktotalwealth.overview.urls')),
	(r'^sitemap\.xml$', 'django.contrib.sitemaps.views.sitemap', {'sitemaps': sitemaps}),
	(r'^captcha/', include('captcha.urls')),
	(r'^reademail','arktotalwealth.emails.views.readnotification'),
    (r'^unsubscribe','arktotalwealth.emails.views.unsubscribe'),    
    (r'^subscribe.json$', 'arktotalwealth.emails.views.subscribe'),
	(r'^grappelli',include("grappelli.urls")),
    (r'^admin/filebrowser/', include("filebrowser.urls")),
    (r'^admin/emails/subscription/sendmail/', 'arktotalwealth.emails.views.sendmail'),
    (r'^admin/emails/email/(?P<id>.*)/viewemail/', 'arktotalwealth.emails.views.viewemail'),     
    (r'^admin/website/enquiry/export/', 'arktotalwealth.website.views.export'),
    
    (r'^admin/website/enquiry/addtospammerslist/$', 'arktotalwealth.admin_views.addtospammerslist', {'path':'enquiry'}),
    (r'^admin/mediacenter/comment/addtospammerslist/$', 'arktotalwealth.admin_views.addtospammerslist', {'path':'comment'}),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    (r'^admin/', include(admin.site.urls)),
    (r'^media/(?P<path>.*)$','django.views.static.serve',{'document_root':settings.MEDIA_ROOT}),
    (r'^', include('arktotalwealth.website.urls')),
)
