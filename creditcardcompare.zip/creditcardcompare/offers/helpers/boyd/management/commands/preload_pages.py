from urllib2 import urlopen
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    '''Use for preloading pages into Memcached
    '''
    def handle(self, *args, **options):
        for url in args:
            response = urlopen(url)
            print response.getcode(), response.url
