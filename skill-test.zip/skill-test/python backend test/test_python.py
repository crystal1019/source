# def func():
#     return 1, 2, 3
# (a,b) = func()


# class A:
#     brothers = []
#
#     def __init__(self,name):
#         self.name = name
# a = A('Richard')
# b = A('Elly')
# a.brothers.append('John')
# print a.name, a.brothers, b.name, b.brothers



# class A(object):
#     def calc(self):
#         return 7
#
# class B(object):
#     def calc(self):
#         return 6
#
# class C(A, B):
#     pass
#
#
# c = C()
#
# print(c.calc())


# class Human(object):
#     def __setattr__(self, name, value):
#         if name == 'gender':
#             if value in ('male', 'Famale'):
#                 self.gender = value
#             else:
#                 print('asdfsadf')
# h = Human()
# h.name = 'Mary'
# h.gender = 'Famale'
# print h.gender

# class A:
#     pass
#
# class B:
#     pass
#
# a= A()
# b = B()
#
# print(type(a)==type(b), type(a), type(b))
#
# import datetime
# class Human(object):
#     name = None
#     gender = None
#     birthday = None
#
#     def __getattr__(self, name):
#
#         if name == 'age':
#             return datetime.datetime.now() - self.birthday
#         else:
#             return "Asdfsa"
#     def __getattribute__(self, name):
#
#         return object.__getattribute__(self, name)
#
# h = Human()
# h.birthday = datetime.datetime(1984,8,20)
#
# h.age = 28

# print(h.age)


# class Organization(object):
#     __employees = []
#
# google = Organization()
# google.__employees.append('Eric')

# import copy
#
# class A(object):
#     pass
#
# a = A()
# a.lst = [1,2,3]
# a.str = 'cats and dogs'
# b = copy.copy(a)
# a.lst.append(100)
# a.str = 'cats and mice'
#
# print b.lst
# print b.str


# MULTIPLIER = 8
#
# a = lambda x, y:(x*MULTIPLIER)/y
#
# print a(2,3)

# a = ['orange', 'apple', 'banana']
# b = a
# a = ['tomato', 'cucumber', 'carrot']
# print b

#
# l = [i for i in xrange(10000)]
# y = (i for i in xrange(10000))
#
# print y

#
# map = 7
#
# def fun():
#     return map
#
# print(fun())

# class Field(object):
#     pass
#
# print(Field)
#
# import random
# def func(type_='s'):
#     if type_ == 's':
#         return 'Mark'
#     elif type_ == 'i':
#         return random.randint(0,1000)
#
# def dec(func, type_):
#     x = 8
#     def wrapper():
#         value = func(type_)
#         if isinstance(value, int):
#             return value*x
#         elif isinstance(value, basestring):
#             return 'Hi'+ value
#     return wrapper
# print dec(func(),'i')()

lst =['I', 'am', 'Python', 'programmer']
s = ""

# for x in lst:
#     s += x

s = "".join(lst)
print(s)

