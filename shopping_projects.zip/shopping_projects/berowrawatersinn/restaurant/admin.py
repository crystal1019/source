from berowrawatersinn.restaurant.models import *
from berowrawatersinn.website.admin import CommonPageAdmin
from django.contrib import admin

class RestaurantPageAdmin(CommonPageAdmin):
    list_display = CommonPageAdmin.list_display + ['is_landing']
    
    
admin.site.register(RestaurantPage, RestaurantPageAdmin)