from django.conf.urls import patterns, url
from views import TestTemplateView, TestMetaTagView


urlpatterns = patterns('',
    url(r'^(?P<template_name>[A-Za-z0-9\-/_]+)\.html$', TestTemplateView.as_view(), name='test-templates'),
    url(r'^metatags/$', TestMetaTagView.as_view(), name='test-metatags'),
)