from django.contrib.auth.models import User
from app.models import RecipeLink, Recipe

model = RecipeLink
split = 'Link\n'

f = open('recipelinks.txt', 'r')
contents = f.read()
f.close()

fs = contents.split(split)
for f in fs:
    f = f.split('\n')
    fld_dict = {}
    for fld in f:
        fld = fld.split(' ')
        if len(fld) == 2:
            fld[0] = fld[0].strip()
            fld[1] = fld[1].strip()
            if fld[0] != '' and fld[1] != '':
                if fld[0] == 'recipe':
                    fld[1] = Recipe.objects.get(pk = fld[1])
                fld_dict[fld[0]] = fld[1]

    if fld_dict != {}:
        f_obj = model.objects.create(**fld_dict)
        f_obj.save()
