
-- RELATÓRIO BÁSICO DAS TRANSAÇÕES/MOVIMENTO
CREATE OR REPLACE VIEW vw_rep_movimento AS
select
id,
created_at as data,
case type when t.checkin_trans then value else 0 end as checkin,
case type when t.buy_trans then value else 0 end as compra,
case type when t.share_trans then value else 0 end as compartilhado,
case type when t.rescue_trans then value else 0 end as resgate,
case type when t.cancel_trans then value else 0 end as cancelado,
case type when t.checkin_trans then 1 else 0 end as 	qt_checkin,
case type when t.buy_trans then 1 else 0 end as qt_compra,
case type when t.share_trans then 1 else 0 end as qt_compartilhado,
case type when t.rescue_trans then 1 else 0 end as qt_resgate,
case type when t.cancel_trans then 1 else 0 end as qt_cancelado
from vw_transactions_type as t, vw_transactions as v;


-- RELATÓRIO DAS TRANSAÇÕES AGRUPADO POR DIA
CREATE VIEW vw_rep_movimento_grupo_dia AS
select
date(v.data) as data,
sum(v.checkin) as checkin,
sum(v.compra) as compra,
sum(v.compartilhado) as compartilhado,
sum(resgate) as resgate,
sum(cancelado) as cancelado
from vw_rep_movimento v
group by date(v.data);


-- RELATÓRIO DAS TRANSAÇÕES AGRUPADO POR MÊS/ANO
CREATE or replace VIEW vw_rep_movimento_grupo_mes AS
select
concat(extract(month from v.data), '/', extract(year from v.data)) as id,
extract(month from v.data) as mes,
extract(year from v.data) as ano,
sum(v.checkin) as checkin,
sum(v.compra) as compra,
sum(v.compartilhado) as compartilhado,
sum(resgate) as resgate,
sum(cancelado) as cancelado,
sum(v.qt_checkin) as qt_checkin,
sum(v.qt_compra) as qt_compra,
sum(v.qt_compartilhado) as qt_compartilhado,
sum(v.qt_resgate) as qt_resgate,
sum(v.qt_cancelado) as qt_cancelado
from vw_rep_movimento v
group by extract(month from v.data)
order by extract(month from v.data), extract(year from v.data);


-- VIEW COM DESCRIÇÃO DOS TIPOS DE TRANSAÇÃO
create or replace view vw_transactions_type_detail as
select checkin_trans as id, 'Check-ins' as description from vw_transactions_type
UNION ALL
select buy_trans, 'Acúmulos' from vw_transactions_type
UNION ALL
select share_trans, 'Compartilhamentos' from vw_transactions_type
UNION ALL
select rescue_trans, 'Resgates' from vw_transactions_type
UNION ALL
select cancel_trans, 'Cancelamentos' from vw_transactions_type;

-- VIEW MOVIMENTO POR PERFIL
CREATE OR REPLACE VIEW vw_rep_movimento_perfil AS
select v.*, gender, case gender when 1 then 'Masculino' when 2 then 'Feminino' end as genero, birth_date, year(current_date) - year(birth_date) as idade from vw_transactions v
inner join userinfo ui on ui.id = v.to_id;


-- VIEW CLIENTE REVISITANTE
CREATE OR REPLACE VIEW vw_cliente_revisitante AS
select
  case when count(*) = 1 then 1 else 0 end as Novo,
  case when count(*) > 1 then 1 else 0 end as Revisitante,
  from_id,
  to_id

from vw_transactions
GROUP BY from_id, to_id;


-- VIEW MOVIMENTO MARCA
create or replace view vw_movimento_marca as
select b.razao_social as brand, b.id as brand_id, v.*
from vw_transactions v
join retailers r on r.id = v.from_id
join brands b on b.id = r.brand_id;


-- VIEW SHARE OF WALLET
create or replace view vw_share_wallet as
select r.id as retailer_id, r.razao_social as retailer, sum(v.value) as valor,
  (select sum(v2.value) from vw_transactions v2
  where v2.to_id = v.to_id and
        month(v2.created_at) = month(v.created_at) and
        year(v2.created_at) = year(v.created_at)
  ) as total,
month(v.created_at) as mes,
year(v.created_at) as ano
from vw_transactions v
join retailers r on r.id = v.from_id
where v.type = 1
group by r.id, r.razao_social, mes, ano;


  create table rep_idades (
    id smallint primary key,
    gender smallint,
    idade1 smallint,
    idade2 smallint
  );

  insert into rep_idades (id, gender, idade1, idade2) values
      (1, 1, 0, 4),
      (2, 1,  5, 9),
      (3,  1, 10, 14),
      (4,  1, 15, 19),
      (5,  1, 20, 29),
      (6,  1, 30, 39),
      (7,  1, 40, 44),
      (8,  1, 45, 49),
      (9,  1, 50, 54),
      (10,  1, 55, 59),
      (11,  1, 60, 64),
      (12,  1, 65, 69),
      (13,  1, 70, 74),
      (14,  1, 75, 79),
      (15,  1, 80, 84),
      (16,  1, 85, 89),
      (17,  1, 90, 94),
      (18,  1, 95, 99),
      (19,  1, 100, 999),
      (21,  2, 0, 4),
      (22,  2, 5, 9),
      (23,  2, 10, 14),
      (24,  2, 15, 19),
      (25,  2, 20, 29),
      (26,  2, 30, 39),
      (27,  2, 40, 44),
      (28,  2, 45, 49),
      (29,  2, 50, 54),
      (30,  2, 55, 59),
      (31,  2, 60, 64),
      (32,  2, 65, 69),
      (33,  2, 70, 74),
      (34,  2, 75, 79),
      (35,  2, 80, 84),
      (36,  2, 85, 89),
      (37,  2, 90, 94),
      (38,  2, 95, 99),
      (39,  2, 100, 999);
