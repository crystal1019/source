"""
  copyright 2014 Seth Black
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from virtualsales.main.models import *

admin.site.register(Campaign)

class ListNumberInline(admin.TabularInline):
    model = ListNumber

class CallNotesInline(admin.TabularInline):
    model = CallNotes

class ListAdmin(admin.ModelAdmin):
    inlines = (ListNumberInline,)

class CallScheduleAdmin(admin.ModelAdmin):
    inlines = (CallNotesInline,)

admin.site.register(List, ListAdmin)
admin.site.register(CallSchedule, CallScheduleAdmin)
