import memcache

def getKeyForObject(obj_type, id):	
	if obj_type is None:
		return None
	if id:
		v = obj_type + '-' + str(id)
		return v
	else:
		v = obj_type + '-all'
		return v
		
def getObjectForTypeAndKey(obj_type, id):
	cache_key = getKeyForObject(obj_type, id)
	
	if cache_key:
		obj = memcache.get(cache_key)
		return obj
	return None
	
def getMultiObjects(prefix, ids):
	return memcache.get_multi(ids,key_prefix=prefix)
	
def clearAll():
	memcache.flush_all()

def setObjectForTypeAndKey(obj_type, id, obj, time=259200):
	cache_key = getKeyForObject(obj_type, id)
	if cache_key:
		memcache.set(cache_key, obj, time)
		return True
	return False

def clearObjectForKey(cache_key):
	memcache.delete(cache_key)
	return True

def clearObjectForTypeAndId(obj_type, id):
	key = getKeyForObject(obj_type, id)
	clearObjectForKey(key)	
