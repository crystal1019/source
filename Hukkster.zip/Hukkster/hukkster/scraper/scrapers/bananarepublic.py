from .base_gap import BaseGapScraper


class BananaRepublicGapScraper(BaseGapScraper):
    @staticmethod
    def get_domain():
        return 'bananarepublic.gap.com'

    def _get_store(self):
        return 'bananarepublic.gap'

