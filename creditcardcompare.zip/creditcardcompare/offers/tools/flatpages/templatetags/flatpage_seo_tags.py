from django import template
from django.contrib.sites.models import Site

register = template.Library()

from offers.core.templatetags import varname_re

class FlatPageSEOOptionsNode(template.Node):
    def __init__(self, flatpage, varname):
        self.flatpage = template.Variable(flatpage)
        self.varname = varname

    def render(self, context):
        def _option_or_default(option, default):
            if option:
                return option
            else:
                return default

        flatpage = self.flatpage.resolve(context)
        site = Site.objects.get_current()
        options = flatpage.seo_options.filter(site=site)
        if options.count():
            option = options[0]
            context[self.varname] = dict(
                title=_option_or_default(option.page_title, flatpage.title),
                description=option.page_description,
                noindex=option.noindex,
            )
        else:
            context[self.varname] = dict(
                title=flatpage.title,
                description='',
                noindex=False
            )

        return ''

@register.tag(name='get_flatpage_seo_options')
def do_get_flatpage_seo_options(parser, token):
    try:
        tag_name, flatpage, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    return FlatPageSEOOptionsNode(flatpage, varname)
