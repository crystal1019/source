import masterpage

import method_question
import method_user
import method_url
import method_cache

DEFAULT_CHARSET = 'utf-8'

class ViewQuestionThread(masterpage.MasterPage):			   	
		
	def get(self):
		#  Get id parameter.
		# TODO(gayle): Error handling on parameters
		key = method_url.getId(self)
		if key is None or key == '' or not self.isInt(key):
			self.displayError('Error: Question Thread Does Not Exist', 'There is no question thread with this id.  Please hit the BACK key to click a new question')
			return

		page_cache_key = 'question-questionthread'
		question_html = method_cache.getObjectForTypeAndKey(page_cache_key, key)
		if not question_html:
			questions = method_question.getQuestionsWithThreadId(key)
			if not questions:
				self.displayError('Error: Question Thread Does Not Exist', 'There is no question thread with this id.  Please hit the BACK key to click a new question')
				return
			author_name = questions[0].author_name
			if len(questions[0].companies2) <= 0:
				company_name = ''
			else:
				company_name = questions[0].companies2[0].text
				
			if len(questions[0].jobs2) <= 0:
				job_name = ''
			else:
				job_name = questions[0].jobs2[0].text
				
			title = company_name.encode('utf-8') + ' Interview Report '
			if job_name and job_name != '':
				title = title + ' for ' + job_name
			if author_name and author_name != '':
				title = title + ' by ' + author_name
			template_values = {'questions': questions, 'author_name': author_name, 'company_name': company_name}
			question_html = self.getBody(template_values, 'html/control-questionthread.html')
			a = title 
			b = '###TITLE###' 
			c = question_html 
			a1 = a.encode('utf-8') 
			b1 = b.encode('utf-8')
			c1 = c
			question_html = a1 + b1 + c1
			method_cache.setObjectForTypeAndKey(page_cache_key, key, question_html, 604800)
		parts = question_html.split('###TITLE###')
		title = parts[0]
		question_html = parts[1]
		if method_user.userIsAdmin():
			to_replace = 'style="display:none" admin="no"'
			new_text = ""
			question_html = question_html.replace(to_replace, new_text)
		else:
			user = method_user.getLoggedInUser()
			if user:
				user_id = user.uid
				to_replace = 'style="display:none" admin="noUnless' + str(user_id) + '"'
				new_text = ""
				question_html = question_html.replace(to_replace, new_text)				
			
			
		template_values = {
			'rendered_body': question_html,	 
			'parent_tab': 'interviews',	 
		}
		
		self.pushPage(template_values, title, 'html/main.html')