function newDataArray(data) {
	var startDay = data[0].date,
		newData = [data[0]];
	for (i = 1; i < data.length; i++) {
		var diff = dateDiff(data[i - 1].date, data[i].date);
		var startDate = new Date(data[i - 1].date);
		if (diff > 1) {
			for (j = 0; j < diff - 1; j++) {
				var fillDate = new Date(startDate).setDate(startDate.getDate() + (j + 1));
				newData.push({
					date: fillDate
				});
			}
		}
		newData.push(data[i]);
	}
	return newData;
}

function dateDiff(d1, d2) {
	return Math.floor((d2 - d1) / (1000 * 60 * 60 * 24));
}