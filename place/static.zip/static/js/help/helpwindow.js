var help_manager = {
	help_config: null, // Stores the current help configuration
	loading_markup: '<div id="help-loading" style="text-align: center;"> \
		<img src="/static/img/ajax-loader-ps.gif"></img> \
		</div>', // Common loading markup
	error_markup: '<div id="help-error" style="text-align: center;"></div>', // Common error markup
	helpdialog: null, // Help Dialog jquery object
	_size: null, // Private
	is_fullscreen: false, // Keep track if the dialog is full screen
	// Show the help window.
	show: function() { 
		var self = this; // For scoping.
		// Don't allow a second help window to open.
		if ( $('#help-dialog').length > 0) {
			return;
		}
		// Build window markup.
		var win = ['<div id="help-dialog">'];
		win.push('<div id="help-win-container">');
		win.push(this.loading_markup);
		win.push('</div>'); 

		this.helpdialog = $(win.join(''));

		// Create the window dialog.
		this.helpdialog.dialog({
			title      : 'Help',
			dialogClass: "help-dialog-overides",
			autoOpen   : true,
			width      : 600,
			height     : 400,
			minHeight  : 300,
			minWidth   : 400,
	        close: function(event, ui) {
	        	$('#help-dialog').remove();
	        },
	        resize: function(event, ui) {
		    	if (self.helpdialog.dialog('option', 'width') != $(window).width() || 
		    		self.helpdialog.dialog('option', 'height') != ($(window).height() - 20))  {
		    		self.is_fullscreen = false;	
		    	}
		    	else {
		    		self.is_fullscreen = true;
		    	}
		    }
	    });
	    this._initTitleTools(); // Add custom title tools to the title container
	    this.loadToc(); // Load the table of contents.
	},
	loadToc: function() {
		var self = this; // For scoping
		this.helpdialog.dialog('option', 'buttons', []);

		// Go and get the help records for the
		// table of contents.
		$.ajax({
			url: '/assistant/helprecords/',
			data: {
				'url': this.getCurrentUrl() 
			},
			dataType: 'html',
			type: 'POST',
			success: function(obj) {
				$('#help-win-container').html(obj);
				
				// Add click event to all HelpGroup & HelpRecord elements
				$('#help-dialog .help-toc-item').click( function() {
					self._tocClick(this);
				});
			},
			error: function(err) {
				self.sendError();
			},
			complete: function() {
				// In case loading is still around get rid of it.
				$('#help-loading').remove();
			}
		});
	},
	
	navigate: function(config) {
		// If progress bar doesn't exist add it.
		if ( $('#help-nav-progress').length == 0 ) {
			// Add progress bar
			$('.help-dialog-overides .ui-dialog-buttonpane').prepend('<div id="help-nav-progress"><div class="progress"><div class="bar" style="width: 0%;"></div></div></div>');
		}
		this.help_config = config;
		var self = this; // For scoping
		$('#help-win-container').html(this.loading_markup);
		$.ajax({
			url: '/assistant/navigate/',
			dataType: 'html',
			data: config,
			type: 'POST',
			success: function(obj, textStatus, jqXHR) {
				$('#help-win-container').html(obj);
				self.refreshNavigation();
			},
			error: function(jqXHR, textStatus, errorThrown) {
				self.sendError();
			},
			complete: function(jqXHR, textStatus) {
				$('#help-loading').remove();
			}
		});
	},

	// Update the states of the navigation buttons.
	refreshNavigation: function() {
		var page_progress = $('#help-win-container input[name="page_progress"]').val();
		if ( page_progress > -1 ) {
			$('#help-nav-progress .progress').css('display', 'block');
			$('#help-nav-progress .bar').css( 'width', page_progress + '%' );
			$('.help-nav-btn').show();
			var page = parseInt($('#help-win-container input[name="page"]').val());
			var next_page = parseInt($('#help-win-container input[name="next_page"]').val());
			var prev_page = parseInt($('#help-win-container input[name="prev_page"]').val());
			var max_pages = parseInt($('#help-win-container input[name="max_pages"]').val());

			if ( page == 0) {
				$('#help-btn-back').prop('disabled', true);
			}
			else {
				$('#help-btn-back').prop('disabled', false);
			}
			if ( next_page > max_pages ) {
				$('#help-btn-next').prop('disabled', true);
			}
			else {
				$('#help-btn-next').prop('disabled', false);	
			}
		}
		else {
			$('#help-nav-progress .progress').hide();	
		}
	},
	// Get the url of the current page 
	// without domain and query string.
	getCurrentUrl: function() {
		return window.location.pathname;
	},
	// Common error used for all ajax.
	sendError: function (){
		$('#help-win-container').html(self.error_markup);
		// Add error alert message
		createAlert(
			'We are currently experiencing problems, please try again later.',
			'Error',
			'error',
			false,
			function(obj){ $('#help-error').append(obj.data.markup); },
			'help-error-alert'
		);
	},
	_fullscreen: function() {
		if( !this.is_fullscreen ) {
    		this._size = [
    			this.helpdialog.dialog('option', 'width'),
    			this.helpdialog.dialog('option', 'height')
    		];
    		this.helpdialog.dialog('option', 'position',['left','top']);
    		this.helpdialog.dialog('option', 'width', $(window).width());
    		this.helpdialog.dialog('option', 'height', $(window).height() - 20);
    		this.is_fullscreen = true;
    	}
    	else {
    		this.helpdialog.dialog('option', 'position', 'center');
    		this.helpdialog.dialog('option', 'width', this._size[0]);
    		this.helpdialog.dialog('option', 'height', this._size[1]);
    		this.is_fullscreen = false;
    	}
	},
	_tocClick: function(helpitem) {
		helpitem = $(helpitem);
		var self = this; // For scoping
		var group = null;
		var hr_elems = null;
		var page = 1;
		var helprecord_ids = [];

		// help record
		if ( helpitem.data('helprecord') ) {
			hr_elems = helpitem.parent('ul').find('li');
			page = helpitem.data('helppage');
		}
		// help group
		else {
			hr_elems = helpitem.parent().find('.helprecords li');
		}
		// Collect helprecord ids.
		$.each(hr_elems, function (k, v){ 
			helprecord_ids.push($(this).data('helprecord'));
		});
		// Get helpgroup id
		group = helpitem.data('helpgroup');

		// Add buttons for help navigation
		this.helpdialog.dialog('option', 'buttons', [
			{
				id: 'help-btn-back',
				html: '<i class="icon-white icon-chevron-left"></i> Back',
				"class": 'btn btn-success',
				click: function() {
					var config = self.help_config;
					config.page--;
					// If the page is 0 head back to the TOC page.
					if ( config.page <= 0) {
						self.loadToc();
					}
					else {
						self.navigate(config);
					}
				}
			},
        	{
        		id: 'help-btn-home',
        		html: '&nbsp;<i class="icon-home"></i>&nbsp;',
        		"class": 'btn',
        		click: function() {
					self.loadToc();
				}
			},
			{
				id: 'help-btn-next',
				html: ' Next <i class="icon-white icon-chevron-right"></i>',
				"class": 'btn btn-success',
				click: function() {
					var config = self.help_config;
					config.page++;
					self.navigate(config);
				}
			}
		]);

		// Change buttons to be a button group.
		$('.help-dialog-overides .ui-dialog-buttonset').addClass('btn-group');
		this.navigate({
			'page'          : page,
			'group_id'      : group,
			'helprecord_ids': helprecord_ids
		});
	},
	_initTitleTools: function() {
		var self = this; // For scoping.
		// Remove Existing icon
		$('.help-dialog-overides .ui-dialog-titlebar-close ui-corner-all').remove();

		// Add container to store new tools
		var tool_container_markup = '<div href="#" class="ui-dialog-titlebar-tools help-title-tools"></div>';
	    $('.help-dialog-overides .ui-dialog-titlebar').append(tool_container_markup);
	    
	    var tool_container = $('.help-title-tools');
	    // Add tools
	    tool_container.append('<i title="Snap window to the left" id="help-tool-snapleft" class="icon-step-backward"></i>');
	    tool_container.append('<i title="Snap window to the right" id="help-tool-snapright" class="icon-step-forward"></i>');
	    tool_container.append('<i title="Toggle fullscreen" id="help-tool-fullscreen" class="icon-fullscreen"></i>');
	    tool_container.append('<i title="Close help window." id="help-tool-close" class="icon-remove"></i>');

	    // Bind click evnets to each new tool
	    
	    /* START TOOL BINDING */

	    $('#help-tool-close').click( function() {
	    	self.helpdialog.dialog('close');
	    });

	    // Toggle full screen on & off
	    $('#help-tool-fullscreen').click( function() {
	    	self._fullscreen();
	    });

	    // Snap help dialog to the left
	    $('#help-tool-snapleft').click( function() {
	    	self.helpdialog.dialog('option', 'position',['left','top']);
	    	self.helpdialog.dialog('option', 'height', $(window).height() - 20);
	    	self.helpdialog.dialog('option', 'width', 600);
	    	self.is_fullscreen = false;
	    });

	    // Snap help dialog to the right
	    $('#help-tool-snapright').click( function() {
	    	self.helpdialog.dialog('option', 'position',['right','top']);
	    	self.helpdialog.dialog('option', 'height', $(window).height() - 20);
	    	self.helpdialog.dialog('option', 'width', 600);
	    	self.is_fullscreen = false;
	    });

	    $('.help-dialog-overides .ui-dialog-titlebar').dblclick( function() {
	    	self._fullscreen();
	    });

	   
	    /* END TOOL BINDING */
	}
};

