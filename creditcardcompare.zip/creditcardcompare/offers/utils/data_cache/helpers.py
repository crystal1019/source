from django.conf import settings
from offers.helpers.template import site_format_meta
# from models import get_cache_model
from utils import create_data_cache, get_field_name

OFFER = 0
CATEGORY = 1


def get_cached_meta_fields(offer, sortable_meta_fields, page=CATEGORY):
    data = create_data_cache(offer)
    new_data = ''
    for metafield in reversed(sortable_meta_fields):
        try:
            field_name = get_field_name(metafield.key)
        except AttributeError:
            field_name = get_field_name(metafield.meta_field.key)
        new_data += data[field_name] or site_format_meta('-', {}, 
                                                           settings.SITE_NAME,
                                                           page, metafield.key)
    return new_data