import masterpage
import method_user
import method_salary
import method_url
	
class ViewSalary(masterpage.MasterPage):
	def get(self):
		if method_user.getLoggedInUser() is None:
			self.redirectToLogin()	
			return	
		id = method_url.getId(self)
		salary = method_salary.getSalaryWithId(id, True)	
		template_values = {
			'item': salary
		}		 
		
		self.pushPage(template_values, 'View Salary', 'html/viewsalary.html')	  
		
