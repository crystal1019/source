$(document).ready(function(){
	$("#termslabel").append("<a href='/terms' target='_blank'>here</a>.");
	
	
	$('input:text').css("width","216px");
	$('input:checkbox').css("margin-left","10px");
	$('input:checkbox').live('change', function(){
	    
	    
	    if($(this).is(':checked')){
	
	         $('button[type="submit"], #dialog-ok').removeClass('disabled'); 

	    } else {
	        $('button[type="submit"], #dialog-ok').addClass('disabled'); 
	    }
	});
});

