from django.db.models.query import RawQuerySet
from django.http import HttpResponse
from django.utils.encoding import smart_unicode
from django.contrib import admin


def add_len_protocol_to_raw_sql_query():
    """
    Adds/Overrides a dynamic implementation of the length protocol to the definition of RawQuerySet for the remainder of this thread's lifespan
    Source: http://stackoverflow.com/questions/2317452/django-count-rawqueryset
    """
    def __len__( self ):
        from django.db import connection
        sql = 'SELECT COUNT(*) FROM (' + self.raw_query + ') B;'
        cursor = connection.cursor()
        cursor.execute( sql )
        row = cursor.fetchone()
        return row[ 0 ]
    setattr( RawQuerySet, '__len__', __len__ )


class DownloaderAdmin(admin.ModelAdmin):
    def get_field_list(self):
        return self.list_display[1:]
    
    def extract_value(self, obj, field):
        if field == 'gender':
            return {'1': 'male', '0': 'female'}[smart_unicode(getattr(obj, field))]
        return smart_unicode(getattr(obj, field))
    
    def changelist_view(self, request, extra_context=None):
        if request.POST.get('action') and request.POST.get('action').startswith('batch_download'):
            # download table even when no row is selected
            request.POST = request.POST.copy()
            request.POST.update({admin.helpers.ACTION_CHECKBOX_NAME: '1'})
        return super(DownloaderAdmin, self).changelist_view(request, extra_context=None)
    
    def batch_download_csv(self, request, queryset):
        if queryset.count() == 0:
            queryset = self.queryset(request).filter(**dict(request.GET.items()))
        
        fields = self.get_field_list()
        f = '|'.join(fields)
        for obj in queryset:
            f += '\n' + '|'.join([self.extract_value(obj, field) for field in fields])
        
        response = HttpResponse(f,content_type='text/csv') 
        response['Content-Disposition'] = "attachment; filename=%s.csv" % self.model.__name__
        return response
    
    def batch_download_xls(self, request, queryset):
        if queryset.count() == 0:
            queryset = self.queryset(request).filter(**dict(request.GET.items()))
        
        import xlwt
        workbook = xlwt.Workbook(encoding = 'ascii')
        worksheet = workbook.add_sheet('report')
        
        fields = self.get_field_list()
        for field in fields:
            worksheet.write(0, fields.index(field), field)
        INDEX_START = 1
        for index, obj in enumerate(queryset, INDEX_START):
            for field in fields:
                worksheet.write(index, fields.index(field), self.extract_value(obj, field))
        
        xls_response = HttpResponse(content_type="application/ms-excel") 
        xls_response['Content-Disposition'] = 'attachment; filename=%s.xls' % self.model.__name__
        workbook.save(xls_response) 
        return xls_response
    
    batch_download_csv.short_description = "Download table as CSV"
    batch_download_xls.short_description = "Download table as XLS"
    actions = [batch_download_csv, batch_download_xls]