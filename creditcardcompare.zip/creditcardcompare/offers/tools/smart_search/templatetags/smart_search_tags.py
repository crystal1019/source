from django import template
from offers.tools.smart_search.models import SearchDetail


register = template.Library()
    
class LeadNameNode(template.Node):
 
    def __init__(self, category_slug):
        self.category_slug = category_slug
 
    def render(self, context):
        try:
            slug = template.Variable(self.category_slug).resolve(context)
        except template.VariableDoesNotExist:
            slug = ''
        try:
            return SearchDetail.objects.get(id=slug.split('-')[-1]).lead.first_name
        except (ValueError, SearchDetail.DoesNotExist):
            return ''

@register.tag(name='get_lead_name')
def do_get_lead_name(parser, token):
    try:
        _tag_name, category_slug = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, \
        '%r tag requires exactly 1 arguments.' % token.split_contents()[0]

    return LeadNameNode(category_slug)