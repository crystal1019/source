__author__ = 'RJB'
from flask import Blueprint
auth = Blueprint('auth', __name__)
from . import routes
