var loader = null;
function compareCards(){
	href = $('.compare-button').attr('name');
	window.parent.location = href;
};
function initTableSorter() {
	$(".sortthis").bind("sortStart",function() {
		if ($('#no-result')[0] != undefined) {
			$('#no-result').remove();
		};
	});
	jQuery(".sortthis").tablesorter({ 
		debug: false, 
		widgets: ['columnHighlight'] });
	jQuery(".tablesorter th, .tablesorter th .info").tooltip({ track: true, delay: 100, showURL: false, showBody: false, top: 25, left: -5 });
	$('.compare-checkbox').click(function(evt){ toggleControls(); });
	//transfer floatable clicks to the fixed headers
    $(".floatable th").click(function() {
   	  if(this.id){
   	  	$(".sortthis").find('#'+this.id).click();
   	  }else{
   	  	$(".sortthis th")[this.cellIndex].click();
   	  };
	});
};
function toggleControls(){
	href = '/tools/compare-cards/?cards=';
	$('.compare-checkbox:checked').each(function () {
           href += this.value+'-';
	});
	$('.compare-button').attr('name',href.slice(0,-1));
	cbutton = $('.compare-button');
	cboxes = $('.compare-checkbox:checked');
	if(cboxes.length>1){
		cbutton.attr('disabled',false);
	}else{
		cbutton.attr('disabled',true);
	}
	if (cboxes.length > 2) {
		$('.compare-checkbox').filter(":not(:checked)").attr('disabled',true);
	}else{
		$('.compare-checkbox').filter(":not(:checked)").attr('disabled',false);
	}
	$('.compare-checkbox').click(toggleControls);
};
function sendTable(){
	if (validate('emailform','email')){
		$('#emailform').hide();
		jQuery.ajax({
			type: 'GET',
			url: $('#emailform').attr('action'),
			data: $('#emailform').serialize(),
			error: function() {
			},
			success: function(data) {
				alert(data);
			}
		});
	};
	return false;
};
function getActiveOnlyQuery(){
	if (window.location.search.search('active_only')!=-1){
		return 'active_only=';
	}
	return '';
};
$(function(){
	toggleControls();
	$(document).ajaxComplete(function(event, xhr, settings){
		if (isPagination(event, xhr, settings)){
			toggleControls();
		}
	});
});
