angular.module('menu.controllers', [])
    .controller('MenuCtrl', ['$scope', '$http', '$sce',

        function($scope, $http, $sce) {

            // This function gets the value of a key in the URL's query string.
            // Source: http://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
            function getParameterByName(name) {
                name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                    results = regex.exec(location.search);
                return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
            }

            function getNextUrl() {
                var currentNextUrl = getParameterByName('next');
                if (currentNextUrl) {
                    return currentNextUrl;
                } else {
                    return window.location.pathname;
                }
            }

            $scope.next = getNextUrl();
            $scope.user = null;
            $scope.notifications = [];
            $scope.organizations = [];
            $scope.main_menu_open = false;
            $scope.notification_menu_open = false;
            $scope.organization_menu_open = false;
            $scope.loaded = false;

            $scope.load = function() {
                $http.get(
                    '/profile-menu/', {}
                ).success(function(data) {
                    $scope.loaded = true;
                    $scope.user = data.data.user;
                    $scope.notifications = data.data.notifications;
                    for (var i = 0; i < $scope.notifications.length; i++) {
                      var notification = $scope.notifications[i];
                      $scope.notifications[i] = $sce.trustAsHtml(notification);
                    }
                    $scope.organizations = data.data.organizations;
                }).error(function() {

                });
            }

            $scope.showMenu = function(menu_name) {
                $scope[menu_name] = true;
            };

            $scope.hideMenu = function(menu_name) {
                $scope[menu_name] = false;
            };

            $scope.load();
        }
    ])