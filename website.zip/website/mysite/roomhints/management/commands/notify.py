from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.models import Project
from roomhints.models import Feedback
from roomhints.models import Beta
from roomhints.models import Profile, Comment

from datetime import datetime, timedelta
from django.utils.timezone import utc
import math
from roomhints.utils import paid_days
from roomhints.views import profile_get

class Command(BaseCommand):
    help = 'Send notification emails for some events'

    def handle(self, *args, **options):
        # projuniq = None
        # for a in args:
        #     projuniq = a
        output = ""
        ball = Beta.objects.filter(notifiedus=False).all()
        if len(ball) > 0:
            for b in ball:
                content = "A new user signed up for the beta: " + str(b)
                output += content + "\n"
                mes = MyEmailSend()
                mes.send_email('Beta user signup',content,'in.style@roomhints.com',['tiffwillson@gmail.com'],
                               'smtp.gmail.com','in.style@roomhints.com','roomhints1')
                b.notifiedus = True
                b.save()

        ball = Beta.objects.filter(notifiedthem=False).all()
        if len(ball) > 0:
            for b in ball:
                content = ""
                if b.am_designer == True:
                    content = "Hi!\n\nWe received your beta request.\n\nWe are giving beta access to select designers to lead our platform. We'll be in touch with you shortly to understand how we can best help.\n\nThank you for your support.\n\nRoomHints"
                elif b.am_brand == True:
                    content = "Hi!\n\nWe received your beta request.\n\nWe are giving beta access to select brands to lead our platform. We'll be in touch with you shortly to understand how we can best help.\n\nThank you for your support.\n\nRoomHints"
                else:
                    content = "Hi!\n\nThank you for signing up for RoomHints.\n\nThere's a bit of a wait at the moment, which means you too will get our undivided attention when your turn comes up like all our members.\n\nWe want to get the iPhone app right. It's excruciating when things take long, so not only are we hurrying up, but are also shortening interior design from half a year to under a month. We think you're going to like it.\n\nYou will have full control in choosing designs of course. The ones we suggest will be the best for you specifically, and it's ok if you change your mind (shh, don't tell your friends.)\n\nElated,\nRoomHints"
                output += content + "\n"
                mes = MyEmailSend()
                mes.send_email('RoomHints: Beta request received',content,'in.style@roomhints.com',[b.email],
                               'smtp.gmail.com','in.style@roomhints.com','roomhints1')
                b.notifiedthem = True
                b.save()

        fall = Feedback.objects.filter(notifiedus=False).all()
        if len(fall) > 0:
            for f in fall:
                content = f.content
                output += content + "\n"
                all_p = Project.objects.filter(profile_id=f.profile_id)
                if len(all_p) > 0:
                    content += "\n\nTheir rooms are:\n"
                    for p in all_p:
                        content += "http://roomhints.com/room?projuniq=" + p.projuniq
                        if p.public == False:
                            content += " [deleted]"
                        content += "\n"
                mes = MyEmailSend()
                mes.send_email('RoomHints user feedback',content,'in.style@roomhints.com',['tiffwillson@gmail.com'],
                               'smtp.gmail.com','in.style@roomhints.com','roomhints1')
                f.notifiedus = True
                f.save()

        # Notify us when there is a new paying customer
        startdate = datetime.utcnow().replace(tzinfo=utc)
        enddate = startdate - timedelta(days=paid_days)
        upall = Profile.objects.filter(stripe_id__isnull=False,charge_seconds__gt=enddate).all()
        if len(upall) > 0:
            for up in upall:
                pall = Project.objects.filter(profile_id=up.id,public=True,charge_seconds__gt=enddate,charge_notifiedus=False).all()
                if len(pall) > 0:
                    for p in pall:
                        content = "RoomHints has a new paying customer for $" + str(int(math.ceil(up.charge_amount))) + " for room:\n"
                        content += "http://roomhints.com/room?projuniq=" + p.projuniq + "\n"
                        output += content + "\n"
                        mes = MyEmailSend()
                        mes.send_email('RoomHints PAYING customer',content,'in.style@roomhints.com',['tiffwillson@gmail.com'],
                                       'smtp.gmail.com','in.style@roomhints.com','roomhints1')
                        up.charge_notifiedus = True
                        up.save()
                        p.charge_notifiedus = True
                        p.save()

        # Notify all designers involved in a project if a paying customer added a comment to it
        upcall = Profile.objects.filter(stripe_id__isnull=False,charge_seconds__gt=enddate).all()
        if len(upcall) > 0:
            for up in upcall:
                #output += "Processing profile " + str(up.id) + "\n"
                pall = Project.objects.filter(profile_id=up.id,public=True,charge_seconds__gt=enddate).all()
                if len(pall) > 0:
                    for p in pall:
                        #output += "..processing project " + p.projuniq + "\n"
                        call = Comment.objects.filter(project_id=p.id,des_notified=False).order_by('seconds')
                        if len(call) > 0:
                            # Find all designers that had added comments, to notify all of them
                            des_emails = dict()
                            for c in call:
                                if c.profile.designer == True:
                                    account = profile_get(c.profile.user.username)
                                    if account['email'] != None and account['email'] != "":
                                        des_emails[account['email']] = True

                            #output += "The designers to notify are: "
                            #for des in des_emails.keys():
                            #    output += des + " "
                            #output += "\n"

                            # Now notify them for each comment
                            for c in call:
                                #output += "   ...processing comment " + str(c.id) + "\n"
                                if c.profile.designer == False:
                                    # This comment was added by a customer. Should notify the designers
                                    # output += "Should notify the designers for: " + c.content + "\n"
                                    mes = MyEmailSend()
                                    content = "A RoomHints paying customer added a comment for room:\n"
                                    content += "http://roomhints.com/room?projuniq=" + p.projuniq + "\n\n"
                                    content += c.content
                                    #output += "content would be: " + content + "\n"
                                    mes.send_email('RoomHints COMMENT from paying customer',content,'in.style@roomhints.com',des_emails.keys(),'smtp.gmail.com','in.style@roomhints.com','roomhints1')
                                    c.des_notified = True
                                    c.save()


        if len(ball) > 0 or len(fall) > 0 or len(upall) > 0 or len(upcall) > 0:
            output = str(datetime.utcnow().replace(tzinfo=utc)) + "\n\n" + output

        print output
