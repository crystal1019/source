'''
@author: chaol
'''
from eway import config
from eway.client import EwayPaymentClient
from eway.fields import Customer, CreditCard
from decimal import Decimal
from django.conf import settings
import math
import urllib
from django.core.mail import send_mail

import datetime

from random import *

from django.core.mail import EmailMultiAlternatives
from django.template import Context, loader, RequestContext
from django.http import HttpResponseRedirect

from bellabustiere.shop.models import *
import string
from django.contrib.sites.models import Site
from django.db.models import Q
import operator
from django.contrib.gis.utils import GeoIP

def check_product_by_ip(request, product):
    exclusive = product.get_shipping_only_country()
    if exclusive:
        try:
            ip = request.META["HTTP_CF_CONNECTING_IP"]
        except:
            ip = request.META["REMOTE_ADDR"]
        try:
            g= GeoIP()
            cityinfo = g.city(ip)
            country = cityinfo.get('country_name','')
            if country.upper() in exclusive:
                return True
            else:
                return False
        except:
            pass
    return True
    

def getRandom(number,codes=[]):
    allcodes = []
    coupons = Coupon.objects.all()
    for x in coupons:
        allcodes += x.codes.split(',')
    codes = codes
    for x in xrange(number):
        code = ''.join(random.choice((string.letters+string.digits)) for i in xrange(8))
        while codes.count(code) != 0 or allcodes.count(code) != 0:
            code = ''.join(random.choice((string.letters+string.digits)) for i in xrange(8))
        codes.append(code)
    return ','.join(codes) 


''' -----------------------------------'''    

def getTopCategory(products):
    c = []
    for x in products:
        cat = x.category_now.all()
        for xx in cat:
            if xx.get_root() not in c:
                c.append(xx)
    c = sorted(c, key=lambda x:x.priority, reverse=True)
    return c
    


''' used in shop.views '''

def findNeibougher(product, products=None):
    prev = ''
    next = ''
    if products:
        for i,x in enumerate(products):
            if x == product:
                try:
                    prev = products[i-1]
                except:
                    prev = ''
                    
                try:
                    next = products[i+1]
                except:
                    next = ''
    else:
        try:
            cat = product.category_now.all()[0]
            prev = product.get_previous_entry(category=cat)
            next = product.get_next_entry(category=cat)
        except:
            pass
    return prev, next
        

def getAllRelated(products):
    activity = []
    brand = []
    clothes = []

    for x in products:
        activity += x.activity.filter(is_landing=False, is_active=True,sites__id=settings.SITE_ID)
        brand += x.brand.filter(is_landing=False, is_active=True, sites__id=settings.SITE_ID)
        clothes += x.category_now.filter(is_landing=False, is_active=True,sites__id=settings.SITE_ID)
    
        
    activity = list(set(activity))
    brand = list(set(brand))
    clothes = list(set(clothes))    
    
    activity = sorted(activity,key=lambda x:x.priority, reverse=True)
    brand = sorted(brand,key=lambda x:x.priority, reverse=True)
    clothes = sorted(clothes,key=lambda x:x.priority, reverse=True)
        
    return activity, brand, clothes

def getPerPage(limit):
    if limit == 'All,':
        return 10000
    else:
        return 18

    
def sortProduct(products, sort):
    if sort and sort == 'price,':
        return products.order_by('price')
    
    return products

def filterProducts(products, size, color, price, clothes, activity, designer):
    pricedict = settings.PRICE_FILTER_DICT
    
    if size:
        sizeobj = SizeGroup.objects.filter(code__in=size.split(','))
        sizess = []
        for x in sizeobj:
            sizess += x.size.all()
    else:
        sizess = Size.objects.all()
    if color:
        colorobj = StyleGroup.objects.filter(code__in=color.split(','))
        colorss = [] 
        for x in colorobj:
            colorss += x.styles.all()
    else:
        colorss = Style.objects.all()
    
    clothesobj = Categories.objects.filter(slug__in=clothes.split(',')) if clothes else Categories.objects.get_all_leaf_nodes()
    activityobj = Activity.objects.filter(slug__in=activity.split(',')) if activity else Activity.objects.filter(is_active=True)
    designerobj = Brand.objects.filter(slug__in=designer.split(',')) if designer else Brand.objects.filter(is_active=True)
    
    products = products.filter(activity__in=activityobj).filter(brand__in=designerobj).filter(category_now__in=clothesobj)
    
    pricesobj = [pricedict[x] for x in price[:-1].split(',')] if price else ''
    qs=[]
    if pricesobj:
        for x in pricesobj:
            min,max = x[1],x[2]
            q = Q(price__lte=max, price__gt=min)
            qs.append(q)
        
        products = products.filter(reduce(operator.or_, qs),)
    
    
    result = []
    for x in products:
        thesizes = x.getAllSize()
        thecolor = x.getAllColor()
        if set(thesizes).intersection(set(sizess)) and set(thecolor).intersection(set(colorss)):
            result.append(x)
    
    products = result    
    
    return products

#this is to get the current order, and create new order if required. it will also check the order user and assign the order to user smartly.
def getCurrentOrder(request):
    new = False
    order = ''
    try:
        order = Order.objects.get(pk=request.session.get("order_id", 0), status=OrderStatus.objects.get(status=settings.TXT_SHOP_ORDER_STATUS_IN_PROGRESS))
        
        if int(request.POST.get('quantity-select',0)) > 0 or request.POST.get('add-voucher-to-bag','') == 'confirmadd':
           new = True
           
    except:
        
        if int(request.POST.get('quantity-select',0)) > 0 or request.POST.get('add-voucher-to-bag','') == 'confirmadd':
           new = True
           
           
        if new:
            order = Order()
            order.status = OrderStatus.objects.get(status=settings.TXT_SHOP_ORDER_STATUS_IN_PROGRESS)
            order.site = Site.objects.get(id=settings.SITE_ID)
            try:
                order.ip = request.META["HTTP_CF_CONNECTING_IP"] 
            except:
                try:
                    order.ip = request.META["REMOTE_ADDR"]
                except:
                    pass
                
            order.save()
    if order and ((request.user and request.user.is_active and not order.user) or (request.user and request.user.is_active and order.user and order.user != request.user)):
        order.user = request.user
        order.save()
                
            
            
    return order, new

def getOrderRelated(order,wholesale):
    po = order.productorder_set.all()
    temp = [x.product for x in po]
    ll = []
    m = map(lambda x:x.product.getRelatedProducts(wholesale),po)
    for x in m:
        ll += x
    ll = [x for x in ll if x not in temp]
    s = set(ll)
    ll = list(s)
    shuffle(ll)
    return ll

def checkInventory(order):

    pos = order.productorder_set.all()
    for x in pos:
        try:
            product = x.product.productsizecolor_set.filter(size=x.size,style=x.style)
            product = product[0] if product else ''
            if product and product.inventory or product and product.inventory == 0:
                product.inventory -= x.quantity
                product.save(vend=False)
                if product.inventory <= 0:
                    t = loader.get_template('productinshort.html')
                    c = Context({'product':product})
                    msg = t.render(c)
                    send_mail("Bella Bustiere Product In Short - Product "+ x.product.title, msg, 'no-reply@bellabustiere.com', ['sales@'+settings.SITE_DOMAIN], fail_silently=False)
            
        except:
            pass
        
        try:
            from bellabustiere.vendapi import *
            vend = VendAPI()
            vend.sync_to_vend_by_po(x)
            if not product:
                product = x.product.productsizecolor_set.filter(size=x.size,style=x.style)
                product = product[0] if product else ''
            if product.inventory <= 0:
                t = loader.get_template('productinshort.html')
                c = Context({'product':product})
                msg = t.render(c)
                send_mail("Bella Bustiere Product In Short - Product "+ x.product.title, msg, 'no-reply@bellabustiere.com', ['sales@'+settings.SITE_DOMAIN], fail_silently=False)
        except:
            pass
    return 1

        


def send_confirm_email(order):
    profile = order.user.get_profile()
    shipping = profile.shipping_set.all()
    billing = profile.billing_set.all()
    t = loader.get_template('orderconfirmationemail.html')
    d = {"profile":profile, "shipping":shipping[0], "billing":billing[0],'order':order}
    c = Context(d)
    msgg = t.render(c)
    email = EmailMultiAlternatives(settings.SITE_NAME+" Order Received - Order "+ order.getOrderNumber(), msgg, 'no-reply@'+settings.SITE_DOMAIN, ['sales@'+settings.SITE_DOMAIN, order.user.email],['dou8le@gmail.com'])
    email.attach_alternative(msgg, "text/html")
    email.send()
    
    
def payment_temando(order):
    try:
        result = temandoAPI(order, getBoxWeight(order),getBoxes(order),order.getProfileShipping().postcode,order.getProfileShipping().suburb, method='book')
        if result.requestId:
            temando,created = TemandoLogging.objects.get_or_create(order=order)
            temando.book_info = result
            temando.save()
        return True
    except:
        pass
    return False

def payment_paypal_start(order):
    msg = ''
    
    msgg = getResponse(order)
    
    if msgg['ACK'] == 'Success':
                
        return HttpResponseRedirect("https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=%s&useraction=commit" % msgg['TOKEN'])
    else:
        msg = msgg
    return msg

def payment_paypal_end(request,order):
    msg = ''

    token = request.GET.get('token')
    payerid = request.GET.get('PayerID')
    try:
        response = getResponse(order, action='do', token=token, payerid=payerid)
    except:
        response = {'ACK':'Error'}
    message = response
    if response['ACK'] == 'Success':
        

       
        msg = 'success'
    else:
        msg = 'Sorry, we cannot checkout your order with paypal, please pay by another method.' 

    return msg

def create_creditcard_info(request,order,form):
    profile = order.user.get_profile()
    shipping = profile.shipping_set.all()
    billing = profile.billing_set.all()
    customer = Customer()
    names = form.cleaned_data.get("name").split()
    firstname = names[0]
    lastname = names[-1]
    customer.first_name = firstname
    customer.last_name = lastname
    customer.email = billing[0].email
    customer.address = billing[0].address.encode('utf8')
    customer.postcode = billing[0].postcode
    customer.invoice_description = "Order from " + settings.SITE_NAME
    customer.invoice_reference = order.getOrderNumber()
    customer.country = billing[0].country
    
    #op = CreditPayment()
    credit_card = CreditCard()
    #op.type = form.cleaned_data.get("type")
    credit_card.number = form.cleaned_data.get("number")
    credit_card.expiry_month = form.cleaned_data.get("expiryMonth")
    credit_card.expiry_year = form.cleaned_data.get("expiryYear")
    
    credit_card.holder_name = '%s %s' % (firstname, lastname,)
    credit_card.verification_number = form.cleaned_data.get("CVV")
    credit_card.ip_address = request.META["REMOTE_ADDR"]
    
    return customer, credit_card
    

def payment_creditcard(request,order,customer,credit_card):
    msg = 'Invalid Credit Card'
    
    if customer.is_valid() and credit_card.is_valid():
        

        eway_client =  EwayPaymentClient(settings.EWAYID,config.REAL_TIME_CVN,True)
        response = eway_client.authorize(Decimal(str(order.getInitialPay())), credit_card=credit_card, customer=customer)
        if response.status.lower() =='true':
            
            
            
            msg = 'success'
        else:
            msg = response.error
    return msg

#_wholesale is the indicator showing whether pending shopping cost for admin to input later, which will be defined in settings
def calculate_shipping(order, postcode, country, wholesale, _wholesale='manual'):
    try:

        price = postInternational(getBoxes(order),getBoxWeight(order),postcode,country,order.getTotal(),order.is_wholesale)
        if not price:
            price = "?"
        price = 0.00 if price =='free' else price    
    except Exception, e:
        price = "?"    
    
    if _wholesale == 'manaual':
        price = 0.00 if wholesale else price
            
    else:
        return price

def calculate_tax(order, country):
    if country.strip().lower() == "australia":
        tax = float(order.getTotalGST())
    else:
        tax = 0.00
        
    return tax

#to update the price for all the product in this order no matter size and style, according to set price, discount price and sales price
def sync_productorder(order):
    price = 0
    pos = order.productorder_set.all()
    
    for x in pos:   
        product = x.product
        quan = sum([xx.quantity for xx in order.productorder_set.filter(product=product)])
  
        if order.user:
            discount_price, discount_percentage, discountid = product.getTaxFreePrice(quan,isWholesale(order.user),x.coupon) if not order.ordered else product.getTaxFreePrice(quan,isWholesale(order.user),x.coupon,time=order.ordered)
            sale_price, sale_percentage, saleid = Sale.objects.get_discount(product, order,'', isWholesale(order.user)) if not order.ordered else Sale.objects.get_discount(product, order,order.ordered, isWholesale(order.user))
            x.price = sale_price if sale_percentage > discount_percentage else discount_price
            x.discount = sale_percentage if sale_percentage > discount_percentage else discount_percentage
            x.sale_applied = 0 if discount_percentage > sale_percentage else saleid
            x.discount_applied = 0 if sale_percentage > discount_percentage else discountid
            
        else:
            discount_price, discount_percentage, discountid = product.getTaxFreePrice(quan,False,x.coupon) if not order.ordered else product.getTaxFreePrice(quan,False,x.coupon, time=order.ordered)
            sale_price, sale_percentage, saleid = Sale.objects.get_discount(product, order,'', False) if not order.ordered else Sale.objects.get_discount(product, order,order.ordered, False)
            x.price = sale_price if sale_percentage > discount_percentage else discount_price
            x.discount = sale_percentage if sale_percentage > discount_percentage else discount_percentage
            x.sale_applied = 0 if discount_percentage > sale_percentage else saleid
            x.discount_applied = 0 if sale_percentage > discount_percentage else discountid      
    
        price = x.price
        x.save()
    
    vos = order.voucherorder_set.all()
    for x in vos:
        x.quantity = 1
        x.price = x.voucher.getCurrentPrice()
        x.save()

    order.save()
    return price

def tax_display(order,country):
    if country and country.strip().lower() == "australia":
        tax = float(order.getTotalGST())
        retailtax = order.getTotalRetailGST()
    else:
        tax = 0.00
        retailtax = formatCurrency(0.00)
        
    return tax,retailtax


def update_cart(request,order):
    for x in request.POST.items():
        if x[0].startswith('quantity-') and int(x[1]) > 0:
            try:
                pid = x[0].split('quantity-')[1]
                quantity = int(x[1])
                op = order.productorder_set.filter(id = pid)
                op = op[0]
                op.quantity = quantity
                op.save()
            except:
                pass
            
    sync_productorder(order)
    
    return 1

def remove_po(order,po):
    po.delete()
    sync_productorder(order)    
    return 1

#finalize_orde helper function to save shipping log and billing log
def final_info(order):
    shipping = order.getProfileShipping()
    billing = order.getProfileBilling()
    s = {'first_name': shipping.first_name, 'last_name':shipping.last_name, 'company':shipping.company, 'address':shipping.address,'address2':shipping.address2, 'address3':shipping.address3, 'suburb':shipping.suburb, 'state':shipping.state, 'postcode':shipping.postcode,'country':shipping.country.country, 'phone':shipping.phone}
    b = {'first_name': billing.first_name, 'last_name':billing.last_name, 'company':billing.company, 'address':billing.address,'address2':billing.address2, 'address3':billing.address3, 'suburb':billing.suburb, 'state':billing.state, 'postcode':billing.postcode,'country':billing.country.country, 'phone':billing.phone}
    return str(s), str(b)

def finalize_order(order):
    
    #order status change:
    if order.method == 'voucher':
        order.status = OrderStatus.objects.get(status='Ordered')
        order.paid_from_website = order.paid_from_website + str(0.00) + ','
    else:

        order.status = OrderStatus.objects.get(status='Ordered')
        
        order.paid_from_website = order.paid_from_website + str(order.getInitialPay()) + ',' 
            
    now = datetime.datetime.now()
    order.ordered = now
    order.sync_order = False
    s, b = final_info(order)
    order.shipping_final = s
    order.billing_final = b
    
    order.save()
        
    #make voucher valid and send email as gift.
    vo = order.voucherorder_set.all()
    for x in vo:
        x.voucher.valid = True
        x.voucher.save()
        if not x.voucher.send_date:
            x.voucher.send_email(order)
            
    try:
        from bellabustiere.vendapi import *
        vend = VendAPI()
        vend.import_all_orders(list=[order])
    except:
        pass
            
    try:
        from bellabustiere.xeroapi import *
        xero = XeroAPI()
        xero.import_single_order(order)        
    except:
        pass
    return 1

def checkout_switch(request,rp):
    if rp.get('billing-edit',''):
        return '/shop/checkout-billing.html' if not request.user.is_active else '/members/profile.html'
    
    elif rp.get('shipping-edit',''):
        return '/shop/checkout-shipping.html' if not request.user.is_active else '/members/profile.html'
    
    elif rp.get('delivery-edit',''):
        return '/shop/checkout-delivery.html'
    
    elif rp.get('payment-edit'):
        return '/shop/checkout-payment.html'
    
    else:
        return ''

#
def update_order(order):
    try:
        postcode = order.getPostCode()
        country = order.getPostCountry()
        realprice = calculate_shipping(order, postcode, country, isWholesale(order.user))
        tax = calculate_tax(order, country)
        totalprice = float(order.getTotalTaxFreePrice())+tax+realprice
        order.shipping_charged = realprice
        order.tax_charged = tax
        order.total_charged = totalprice
        order.save()
    except:
        pass
    return 1

def check_productcoupon(product,cp,wholesale):
    
    cp = cp[0] if cp else None
    
    use_coupon = DiscountPrice.objects.check_coupon(product,cp,wholesale) if cp else None
    
    return use_coupon

def getResponse(order,action='set',token='',payerid=''):
    Username = settings.USERNAME
    Password = settings.PASSWORD
    Signature = settings.SIGNATURE
    token = token
    payerid = payerid
    tokens = {}
    domain = settings.DOMAIN
    credientials = {'USER':Username,
        'PWD':Password,
        'VERSION': '52.0',
        'SIGNATURE':Signature}

    if action == 'set':
        actions = {'METHOD'        : 'SetExpressCheckout',
                   'PAYMENTACTION' : 'Sale',
                   'AMT'           : order.getInitialPay(),
                   'CURRENCYCODE'  : 'AUD',
                   'RETURNURL'     : 'http://%s/shop/checkout-final%s.html' %(domain,order.id),
                   'CANCELURL'     : 'http://%s/shop/cart.html' % domain,
                   'NOSHIPPING'    : '1'
                       }
    else:
        actions = {'METHOD'        : 'DoExpressCheckoutPayment',
                   'TOKEN'         : token,
                   'PAYMENTACTION' : 'Sale',
                   'CURRENCYCODE'  : 'AUD',
                   'AMT'           : order.getInitialPay(),
                   'PAYERID'       : payerid
                       }
    cres = urllib.urlencode(credientials)
    acts = urllib.urlencode(actions)
    params = "%s&%s" %(cres,acts)
    #print params 
    response = urllib.urlopen("https://api-3t.paypal.com/nvp", params)
    uri_response = urllib.unquote(response.read())
        
        #split up the response
    for token in uri_response.split('&'):
        tokens[str(token.split("=")[0])] = str(token.split("=")[1])
    return tokens

''' ------------------------ '''

def formatCurrency(amount):
    try:
        p = str(amount).split(".")
        if len(p[1]) < 2:
            p[1] = str(p[1])+str(0)
        elif len(p[1]) > 2:
            p[1] = str(p[1][:2])
        price = ".".join(p)
        return price
    except:
        return amount
    
def create_username(email, type='wholesale'):
    if type == 'retail':
        username = email
        username = username.replace("@", "_")
        username = username.replace(".", "_")      
        username = str(settings.SITE_ID)+"retail_"+username  
        
    elif type == 'member':
        username = email
        username = username.replace("@", "_")
        username = username.replace(".", "_")      
        username = str(settings.SITE_ID)+"member_"+username
    else:
        username = email
        username = username.replace("@", "_")
        username = username.replace(".", "_")
        username = str(settings.SITE_ID) + '_' + username  
        
    return username      
