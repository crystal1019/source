$(document).ready(function(){
	// todo , but first find solution for many rows;
	var query = $('.pagedepth').children();
	query.each(function(){
		//console.log($(this).position());
	});
});