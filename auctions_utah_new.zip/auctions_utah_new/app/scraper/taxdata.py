__author__ = 'RJB'
import datetime as dt
import re
import requests
from bs4 import BeautifulSoup as bs
from app.models import TaxData, Properties, db

r_session = requests.session()


class SlcAsrScraper(object):
    """gets Salt Lake county tax data from a (subject_property_id, parcel number) tuple and stores it.
    Can be  a list of tuples"""
    url = 'http://slco.org/assessor/new/resultsMain.cfm?RequestTimout=8'

    def __init__(self, id_parcels):
        self.id_parcels = list(id_parcels)

    def get_page(self, parcelnum):
        print 'Getting tax data for parcel#: ', parcelnum
        req = r_session.post(self.url, data={'parcelid': parcelnum})
        soup = bs(req.content) if req.ok else None
        return soup

    @staticmethod
    def parse_page(soup):
        """Turns html soup to a TaxData object
         with attributes based on the keys given in regex pattern.
        Returns an empty dict if nothing found in page"""
        label_convert = {'bldstyle': 'bld_style', 'numbedrooms': 'bedrooms', 'propertytype': 'property_type',
                         'fullbaths': 'full_baths', 'numstories': 'stories', 'stories': 'stories', 'tqbths': 'three_quarter_baths',
                         'yearbuilt': 'year_built', 'halfbaths': 'half_baths', 'numkitchens': 'kitchens',
                         'totacres': 'lot_acres'}
        link_attr_regex = r'baths|yearbuilt|mainarea|style|stories|bedrooms|area|abovegrade|tqbths|kitchens|totacres|propertytype'
        tdata = TaxData()
        div = soup.find('div', {'id': 'detailDiv'})
        if div:
            cols = div.find_all('a', {'href': re.compile(link_attr_regex)}) if div else []
            coords = soup.find('div', {'id': 'googlemap'})
            tdata.lat_lon = ','.join(coords.stripped_strings)
            tdata.address = soup.find('table', {'width': '100%'}).find_all('td')[3].text.replace(u'\xa0', ' ')
            total_sqft, dupe = 0, False
            proc_status, area_info = [], []
            for i in cols:
                #element 'href' format: href=javascript:newwin('x','y','LABELNAME');
                label_start_index, label_end_index = i['href'].rfind(",'")+2, i['href'].rfind("')")
                label = i['href'][label_start_index:label_end_index]
                print 'Label: ', label
                db_label = label_convert.get(label)
                value = i.string if i.string else '0'
                print 'Value: ', value
                if db_label:
                    print 'Label converted, setting: %s: %s' % (db_label, value)
                    setattr(tdata, db_label, value)
                elif 'area' in label or label == 'abovegrade':
                    element = label+': '+value
                    if area_info.count(element):  # if label already seen (header might show up twice)
                        continue
                    elif label in ['abovegrade', 'basementarea']:
                        area_info.append(element)
                        total_sqft += int(value)
                else:
                    proc_status.append(label+': '+i. string)
            tdata.total_sqft  = total_sqft
            tdata.area_info   = ', '.join(area_info)
            tdata.proc_status = ', '.join(proc_status)
            tdata.year_built = tdata.year_built.strip(u'\xc2').strip(u'\xa0')
        else:
            tdata.proc_status = 'No records found for parcel number.'
        return tdata

    def run(self):
        for property_id, parcelnum in self.id_parcels:
            soup = self.get_page(parcelnum)
            tdata = self.parse_page(soup)
            tdata.parcel_number = parcelnum
            tdata.property_id = property_id
            tdata.date_updated = dt.datetime.now()
            tdata.save()


class UtCntyAssrScraper(object):
    """gets Utah county tax data from a (subject_property_id, parcel number) tuple and stores it.
    Can be  a list of tuples"""
    search_url = 'http://www.utahcounty.gov/LandRecords/SerialVersions.asp?'
    link_url = 'http://www.utahcounty.gov/LandRecords/'

    def __init__(self, id_parcels):
        self.id_parcels = id_parcels

    def get_page(self, parcelnum):
        req = r_session.get(self.search_url, params={'av_serial': parcelnum, 'button': 'Submit+Query'})
        link = bs(req.content).find('a', {'href': re.compile(r'av_serial')})['href']
        if req.ok and link:
            rq = r_session.get(self.link_url+link)
            soup2 = bs(rq.content)
            return soup2

    @staticmethod
    def parse_page(soup):
        coords = soup.find_all('script', {'type': 'text/javascript'})[1].text
        lat_lon = re.search(r'(?<=GLatLng\().*(?=\))', coords).group()
        print 'Lat/Lon %s FOUND!' % (lat_lon or 'NOT')
        appraisal_info_link = soup.find('option', {'value': re.compile(r'AppraisalInfo\.asp\?\w+=\d+')})['value']
        print appraisal_info_link
        print 'Appraisal_link: %s FOUND! ' % (appraisal_info_link or 'NOT!')
        appraisal_info_req = r_session.get('http://www.utahcounty.gov/LandRecords/'+appraisal_info_link)
        if appraisal_info_req.ok:
            appraisal_info = bs(appraisal_info_req.content)
            appraisal_soup = appraisal_info.find('table', {'cellpadding': 2}).find_all('tr')
            key_converter = {'Address': 'address', 'Primary Use': 'property_type', 'Land Size': 'lot_acres',
                             'Improvement Type': 'bld_style', 'Year Built': 'year_built', 'Bedroom Count': 'bedrooms',
                             'Full Bath': 'full_baths', 'Half Bath': 'half_baths', '3/4 Bath': 'three_quarter_baths',
                             'Sq Ft': 'area_info', 'Bsmt Sq Ft': 'area_info', 'Bsmt Sq Ft Finished': 'area_info'}
            area_tally = 0  # 'Sq Ft' + 'Bsmt Sq Ft'
            tdata = TaxData(lat_lon=lat_lon)
            area_info = []
            for row in appraisal_soup[1:]:
                stripped_row = list(row.stripped_strings)
                # get rid of trailing ':'
                key_candidate = stripped_row[0][:-1] if len(stripped_row) > 1 else None
                have_key = key_converter.get(key_candidate)
                if (len(stripped_row) < 11) and have_key:
                    vals = ', '.join(stripped_row[1:])
                    print 'SETTING %s: %s!' % (key_candidate, vals)
                    setattr(tdata, have_key, vals)
                    if key_candidate in ['Sq Ft', 'Bsmt Sq Ft']:
                        print 'Tallying Area: ', key_candidate
                        area_tally += int(''.join(i for i in vals if i.isdigit()))
                        print 'Total Area Tally: ', area_tally
                    if 'Sq' in key_candidate:
                        print 'Adding to AREA INFO: ', key_candidate+', '+vals
                        area_info.append('{0}: {1}'.format(key_candidate, vals))
                        print '\t', area_info
            tdata.area_info = ', '.join(area_info)
            tdata.year_built = int(tdata.year_built)
            tdata.address = tdata.address.replace(u'\xa0', ' ')
            tdata.total_sqft = area_tally
            return tdata

    def run(self):
        for property_id, parcelnum in self.id_parcels:
            soup = self.get_page(parcelnum)
            tdata = self.parse_page(soup)
            tdata.parcel_number = parcelnum
            tdata.property_id = property_id
            tdata.date_updated = dt.datetime.now()
            tdata.save()


def run_tax_scraper():
    print 'Starting tax scraper...'
    # if have parcel number and county of interest
    need_tax_slc = db.session.query(Properties.id, Properties.parcel_number).filter(
        db.and_(Properties.county == 'Salt Lake', Properties.parcel_number != None,
                Properties.tax_data_date == None)).all()
    slcscraper = SlcAsrScraper(need_tax_slc)
    slcscraper.run()
    need_tax_ut = db.session.query(Properties.id, Properties.parcel_number).filter(
        db.and_(Properties.county == 'Utah', Properties.parcel_number != None,
                Properties.tax_data_date == None)).all()
    utscraper = UtCntyAssrScraper(need_tax_ut)
    utscraper.run()


if __name__ == '__main__':
    run_tax_scraper()