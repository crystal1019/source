from django import forms
from django.core.files.uploadedfile import UploadedFile
from django.utils.translation import ugettext_lazy as _
from nested_inlines.forms import BaseNestedModelForm
from models import Offer

class ImageUploadCleanupMixin(object):
    def save(self, commit=True):
        if self.cleaned_data.get('image'):
            # Replace an already existing image by deleting it. This is because
            # the default for Django is to add a _ after the file's name if it
            # already exists.
            image = self.cleaned_data.get('image')
            if self.instance.pk is not None and isinstance(image, UploadedFile):
                self.instance.image.storage.delete(self.instance.image.name)
        saved_instance = super(OfferAdminForm, self).save(commit)
        return saved_instance

class OfferAdminForm(BaseNestedModelForm, ImageUploadCleanupMixin):
    class Meta:
        model = Offer
        exclude = ()
        
class SendTableForm(forms.Form):
    email = forms.EmailField(error_messages=dict(invalid=_('Email is invalid.'), required=_('Email is required.')))
    newsletter = forms.BooleanField(initial=True, required=False)
    terms = forms.BooleanField(initial=True, error_messages={'required': 'You must agree to the terms and conditions.'})
