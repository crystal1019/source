from datetime import date
from django import template
from django.template import Library
from offers.tools.flatpages.models import Video


register = Library()


class VideoNode(template.Node):
    def __init__(self, varname):
        self.varname = varname

    def render(self, context):
        context[self.varname] = Video.objects.filter(page__extras__published__lte=date.today())
        return ''


@register.tag(name='get_all_videos')
def do_get_all_videos(parser, token):
    try:
        _tag_name, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments' % token.split_contents()[0]
    return VideoNode(varname)
    