import objects
import method_db
import method_cache
import method_user

flag_limit = 3
vote_collapse_limit = -2

def addInfoToCommentList(comments):
	comment_list = []
	for comment in comments:
		comment_list.append(comment)
	comment_roots = []
	root_to_children_map = {}
	for comment in comment_list:
		if comment.votes_net < vote_collapse_limit:
			comment.collapse = True
		else:
			comment.collapse = False
		obj = method_db.addInfoToObject(comment)
		if obj:
			if not(comment.parent_id == comment.ancestor_id) and comment.parent_id > 0:
				obj.is_child = True
				if not(obj.parent_id in root_to_children_map):
					root_to_children_map[obj.parent_id] = []
				(root_to_children_map[obj.parent_id]).append(obj)
			else:
				obj.is_child = False
				comment_roots.append(obj)
	
	comment_list = []
	for root in comment_roots:
		comment_list.append(root)
		if root.uid in root_to_children_map:
			children = sorted(root_to_children_map[root.uid], key=lambda comment: comment.date)
			for child in children:
				child.reply_id = None
				comment_list.append(child)
			comment_list[len(comment_list)-1].reply_id = root.uid
		else:
			root.reply_id = root.uid

	return comment_list

def getCommentsWithAncestor(key):
	comments = objects.Comment.query(objects.Comment.visible == True, objects.Comment.ancestor_id == key).order(-objects.Comment.votes_net).order(objects.Comment.date)
	return addInfoToCommentList(comments)

def getCommentAndSubcomments(key):
	comments = objects.Comment.query(objects.Comment.visible == True, objects.Comment.parent_id == key).order(-objects.Comment.votes_net).order(objects.Comment.date)
	primary_comment = objects.Comment.query(objects.Comment.visible == True, objects.Comment.uid == key).get()
	comment_list = [primary_comment]
	for c in comments:
		comment_list.append(c)
	return addInfoToCommentList(comment_list)

def deleteComment(comment):
	number_children = 0
	if comment.parent_id != 0 and comment.parent_id != comment.ancestor_id:
		comment.visible = False
		comment.under_review = False
	else:
		number_children = objects.Comment.query(objects.Comment.parent_id == comment.uid).count()
		if number_children == 0:
			comment.visible = False
			comment.under_review = False
	method_db.putObject(comment)	
	method_db.refreshCommentCount(comment.ancestor_id, comment.type)
	ancestor = method_db.getObjectWithTypeAndId(comment.ancestor_id, comment.type)
	method_db.onObjectUpdated(ancestor)	
	
def undeleteComment(comment):
	if comment.parent_id != 0 and comment.parent_id != comment.ancestor_id:
		comment.visible = True
		comment.under_review = False
	else:
		comment.visible = True
		comment.under_review = False
	method_db.putObject(comment)	
	method_db.refreshCommentCount(comment.ancestor_id, comment.type)
	ancestor = method_db.getObjectWithTypeAndId(comment.ancestor_id, comment.type)
	method_db.onObjectUpdated(ancestor)	

def getCommentWithId(comment_id, force=False):
	comment = method_cache.getObjectForTypeAndKey('comment', comment_id)
	if not comment:
		comment = objects.Comment.query(objects.Comment.uid == comment_id).get()
		method_cache.setObjectForTypeAndKey('comment', None, comment)
	comment = method_db.addInfoToObject(comment, force)
	if force: # if forcing the comment to be visible
		return comment
	else:
		return method_db.ensureVisible(comment)
	

def getFlaggedCommentCount():
	flagged_count = method_cache.getObjectForTypeAndKey('flagged_comment_count', None)
	if not flagged_count:
		flagged_count = objects.Comment.query(objects.Comment.under_review == True).count()
		method_cache.setObjectForTypeAndKey('flagged_comment_count', None, flagged_count)
	return flagged_count	
	
def clearCache(comment):
	method_cache.clearObjectForTypeAndId('user', str(comment.author_id))
	method_cache.clearObjectForTypeAndId('question-questionhtml', comment.parent_id)	
	method_cache.clearObjectForTypeAndId('question-rendered', comment.parent_id)	
	method_cache.clearObjectForTypeAndId('question-questionhtml', comment.ancestor_id)	
	method_cache.clearObjectForTypeAndId('question-rendered', comment.ancestor_id)				

def clearFlaggedCommentCountCache():
	method_cache.clearObjectForTypeAndId('flagged_comment_count', None)

def getCommentsWithParent(key):
	#comment_list = method_cache.getObjectForTypeAndKey('comment-parent', key)
	#if not comment_list:
	comments = objects.Comment.query(objects.Comment.visible == True, objects.Comment.parent_id == key).order(objects.Comment.date)
	comment_list = []
	for comment in comments:
		comment_list.append(comment)
		#method_cache.setObjectForTypeAndKey('comment-parent', key, comment_list)
	comments = []
	for comment in comment_list:
		obj = method_db.addInfoToObject(comment)
		if obj:
			obj.is_child = True
			obj.reply_id = ""
			comments.append(obj)  
	return comments
	
def getRecentComments():
	comments_list = method_cache.getObjectForTypeAndKey('comment-recent', None)
	if not comments_list:
		comments = objects.Comment.query(objects.Comment.visible == True).order(-objects.Comment.date).fetch(20)
		comments_list = []
		for comment in comments:
			comments_list.append(comment)
		method_cache.setObjectForTypeAndKey('comment-recent', None, comments_list)
	return comments_list