from django.db import models


class Shop(models.Model):
    domain = models.CharField(max_length=100, unique=True)

    created = models.DateTimeField(auto_now_add=True, blank=True, null=True, editable=False)
    changed = models.DateTimeField(auto_now=True, blank=True, null=True, editable=False)

    class Meta:
        ordering = ('domain',)

    def __unicode__(self):
        return self.domain
