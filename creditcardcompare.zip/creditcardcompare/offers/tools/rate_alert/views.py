import json as simplejson
from datetime import datetime, timedelta
from importlib import import_module
from django.conf import settings
from django.db.models import Q
from django.http import HttpResponse, Http404
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.sites.models import Site
from django.views.generic.edit import FormView

from offers.helpers.lead.helpers import save_lead, EmailThread
from offers.helpers.lead.models import EmailConfirmation
from offers.core.models import Offer, Category
from models import Alert
from forms import RegistrationFormDesktop, RegistrationFormMobile 


def send_alert_command(custom_settings='settings.ccc'):
    '''Only used by management command
    '''
    local_settings = import_module(custom_settings)
    print 'Processing registered alerts from %s' % local_settings.SITE_NAME
    settings.TEMPLATE_DIRS = local_settings.TEMPLATE_DIRS
    settings.SITE_NAME = local_settings.SITE_NAME
    q = lambda d: Q(site__id=local_settings.SITE_ID,
                    confirmed=True,
                    expiry=d)
    get_2_weeks = q(datetime.today().date() + timedelta(days = 14))
    get_1_month = q(datetime.today().date() + timedelta(days = 30))
    due_1_month = Q(site__id=local_settings.SITE_ID,
                    confirmed=True,
                    duedate=datetime.today().date() + timedelta(days = 30))
    alerts14 = Alert.objects.filter(get_2_weeks)
    alerts30 = Alert.objects.filter(get_1_month)
    duedate30 = Alert.objects.filter(due_1_month)
    for alert in alerts14:
        _send_email(alert, 'rate_alert/alert_email14.html')
        alert.delete()
    for alert in alerts30:
        _send_email(alert, 'rate_alert/alert_email30.html')
    for alert in duedate30:
        _send_email(alert, 'rate_alert/duedate_email30.html', subject="Your card's annual fee payment will be due soon")
    return alerts14.count()+alerts30.count()

def _send_email(alert, template, subject='Balance Transfer Expiration Alert'):
    print 'Sending alert to %s' % alert.lead.email
    EmailThread(**{
            'email': alert.lead.email,
            'sender': 'rate.alerts@' + settings.SITE_NAME,
            'subject': subject,
            'context': {'offer': alert.offer},
            'template': template
        }).start()
        
def deactivate(request, confirmation_key):
    email = EmailConfirmation.objects.confirm_email(confirmation_key)
    if email is not None:
        alerts = Alert.objects.filter(lead__email=email,
                                      site=Site.objects.get_current())
        for alert in alerts:
            alert.confirmed = False
            alert.save()
        if alerts.count():
            return render_to_response('rate_alert/deactivation_complete.html', {},
                                      RequestContext(request))
    return render_to_response('rate_alert/deactivation_failed.html',
                              {'deactivation_key': confirmation_key},
                              RequestContext(request))
    
class RegisterView(FormView):
    template_name = 'rate_alert/ratealert_step1.html'
    
    def get_form_class(self):
        if self.request.session['is_mobile']:
            return RegistrationFormMobile
        return RegistrationFormDesktop
    
    def get(self, request):
        if not request.is_ajax():
            return super(RegisterView, self).get(request)
        try:
            category = Category.on_site.get(slug=request.GET['category_slug'])
        except Category.DoesNotExist:
            raise Http404
        offers = category.offers_published_on_site()
        offers = [o.title for o in offers]
        return HttpResponse(simplejson.dumps({'offers': offers}), content_type='application/json')
        
    
    def get_context_data(self, form):
        context = super(RegisterView, self).get_context_data()
        context.update({'offers': Offer.on_site.all(), 'form': form})
        return context
    
    def form_valid(self, form):
        self.save_registration(form)
        return self.get(self.request)

    def save_registration(self, form):
        lead = save_lead({
                    'first_name': form.cleaned_data['first_name'],
                    'email': form.cleaned_data['email'],
                    'ip':self.request.META['REMOTE_ADDR'],
                    'source':self.request.build_absolute_uri()
                })
        Alert.objects.create(lead=lead,
                             site = Site.objects.get_current(),
                             offer=Offer.objects.get(title=form.cleaned_data['offer']),
                             expiry=form.get_expirydate(),
                             duedate=form.get_duedate())
        confirmation = EmailConfirmation.objects.create(email_address=lead.email)
        EmailThread(**{
                'email': lead.email,
                'subject': 'Balance Transfer Expiration Alert',
                'context': {'deactivation_key': confirmation.confirmation_key,
                            'site': Site.objects.get_current(),
                            'offer_name': form.cleaned_data['offer'],
                            'voucher': form.cleaned_data.get('voucher')},
                'template': 'rate_alert/deactivation_email.html',
            }).start()
        if form.cleaned_data.get('voucher'):
            EmailThread(**{'email': lead.email,
                           'subject': 'Claim your $50 wine voucher now',
                           'template': 'reviews/email.html',
                        }).start()
