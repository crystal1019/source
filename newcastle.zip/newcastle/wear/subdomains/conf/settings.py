from django.conf import settings
import scraper


BASE_DOMAIN = getattr(settings, 'BASE_DOMAIN', 'example.com')
UNALLOWED_SUBDOMAINS = getattr(settings, 'UNALLOWED_SUBDOMAINS', ['csi', 'pcsvcs'])
