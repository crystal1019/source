-- MySQL dump 10.13  Distrib 5.1.61, for apple-darwin11.3.0 (i386)
--
-- Host: localhost    Database: berowrawatersinn
-- ------------------------------------------------------
-- Server version	5.1.61

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_bda51c3c` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_message`
--

DROP TABLE IF EXISTS `auth_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_message_fbfc09f1` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_message`
--

LOCK TABLES `auth_message` WRITE;
/*!40000 ALTER TABLE `auth_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_e4470c6e` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add message',4,'add_message'),(11,'Can change message',4,'change_message'),(12,'Can delete message',4,'delete_message'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add log entry',8,'add_logentry'),(23,'Can change log entry',8,'change_logentry'),(24,'Can delete log entry',8,'delete_logentry'),(25,'Can add banner',9,'add_banner'),(26,'Can change banner',9,'change_banner'),(27,'Can delete banner',9,'delete_banner'),(28,'Can add site meta',10,'add_sitemeta'),(29,'Can change site meta',10,'change_sitemeta'),(30,'Can delete site meta',10,'delete_sitemeta'),(31,'Can add misc page',11,'add_miscpage'),(32,'Can change misc page',11,'change_miscpage'),(33,'Can delete misc page',11,'delete_miscpage'),(34,'Can add location page',12,'add_locationpage'),(35,'Can change location page',12,'change_locationpage'),(36,'Can delete location page',12,'delete_locationpage'),(37,'Can add restaurant page',13,'add_restaurantpage'),(38,'Can change restaurant page',13,'change_restaurantpage'),(39,'Can delete restaurant page',13,'delete_restaurantpage'),(40,'Can add kitchen page',14,'add_kitchenpage'),(41,'Can change kitchen page',14,'change_kitchenpage'),(42,'Can delete kitchen page',14,'delete_kitchenpage'),(43,'Can add component',15,'add_component'),(44,'Can change component',15,'change_component'),(45,'Can delete component',15,'delete_component');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'chaol','','','chaol@1md.com.au','sha1$c2341$a9e396dfa665f5984c498fcb3896c11ef287be69',1,1,1,'2013-02-12 15:12:06','2013-02-11 17:26:53');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_fbfc09f1` (`user_id`),
  KEY `auth_user_groups_bda51c3c` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_fbfc09f1` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_fbfc09f1` (`user_id`),
  KEY `django_admin_log_e4470c6e` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2013-02-12 12:11:56',1,7,'1','example.com',2,'Added site meta \"example.com\".'),(2,'2013-02-12 14:20:09',1,7,'1','www.berowrawatersinn.com.au',2,'Changed domain and name.'),(3,'2013-02-12 14:20:41',1,7,'1','www.berowrawatersinn.com.au',2,'Changed footer for site meta \"www.berowrawatersinn.com.au\".'),(4,'2013-02-12 15:24:12',1,9,'1','Banner object',1,''),(5,'2013-02-12 15:25:11',1,11,'1','Introduction',1,''),(6,'2013-02-12 15:41:10',1,9,'2','stay on river banner',1,''),(7,'2013-02-12 15:52:39',1,11,'2','Staying On The River',1,''),(8,'2013-02-12 15:55:01',1,11,'1','Introduction',2,'Changed content.'),(9,'2013-02-12 15:56:18',1,11,'1','Introduction',2,'Changed content.'),(10,'2013-02-12 16:07:46',1,11,'1','Introduction',2,'Changed content.'),(11,'2013-02-12 16:09:42',1,11,'1','Introduction',2,'Changed content.'),(12,'2013-02-12 17:11:43',1,11,'1','Introduction',2,'Changed banner.'),(13,'2013-02-12 17:15:30',1,11,'1','Introduction',2,'Changed banner.'),(14,'2013-02-12 17:29:01',1,13,'1','The Restaurant',1,''),(15,'2013-02-13 10:58:09',1,9,'3','events banner -- 1596 X 517',1,''),(16,'2013-02-13 10:58:37',1,13,'2','Special Events',1,''),(17,'2013-02-13 11:01:40',1,13,'2','Special Events',2,'Changed content.'),(18,'2013-02-13 11:04:13',1,9,'4','gift banner -- 1345 X 517',1,''),(19,'2013-02-13 11:13:39',1,13,'3','Gift Certificates',1,''),(20,'2013-02-13 11:21:17',1,13,'3','Gift Certificates',2,'Changed content.'),(21,'2013-02-13 11:23:06',1,9,'5','general info banner -- 1286 X 518',1,''),(22,'2013-02-13 11:25:39',1,13,'4','General Information',1,''),(23,'2013-02-13 11:31:35',1,13,'4','General Information',2,'Changed content.'),(24,'2013-02-13 12:15:01',1,13,'4','General Information',2,'No fields changed.'),(25,'2013-02-13 12:17:23',1,9,'6','terms banner -- 1286 X 518',1,''),(26,'2013-02-13 12:19:01',1,13,'5','Terms & Conditions',1,''),(27,'2013-02-13 12:20:10',1,13,'5','Terms & Conditions',2,'Changed content.'),(28,'2013-02-13 12:23:14',1,9,'7','kitchen banner -- 1270 X 517',1,''),(29,'2013-02-13 12:24:48',1,14,'1','The Kitchen',1,''),(30,'2013-02-13 12:29:35',1,14,'1','The Kitchen',2,'Changed content.'),(31,'2013-02-13 12:31:07',1,14,'1','The Kitchen',2,'Changed content.'),(32,'2013-02-13 12:35:38',1,9,'8','menu banner -- 1270 X 517',1,''),(33,'2013-02-13 12:35:41',1,14,'2','The Menu',1,''),(34,'2013-02-13 12:39:08',1,9,'9','cellar banner -- 1270 X 517',1,''),(35,'2013-02-13 12:40:06',1,14,'3','The Cellar',1,''),(36,'2013-02-13 13:34:19',1,12,'1','The Location',1,''),(37,'2013-02-13 13:34:35',1,12,'1','The Location',2,'Changed is_landing.'),(38,'2013-02-13 13:37:30',1,9,'10','plane banner -- 1343 X 517',1,''),(39,'2013-02-13 13:38:14',1,12,'2','ARRIVE BY SEAPLANE',1,''),(40,'2013-02-13 13:40:42',1,9,'11','boat banner -- 1343 X 517',1,''),(41,'2013-02-13 13:41:04',1,12,'3','ARRIVE BY BOAT',1,''),(42,'2013-02-13 13:42:22',1,9,'11','boat banner -- 1343 X 517',2,'Changed is_active.'),(43,'2013-02-13 13:55:46',1,9,'12','car banner -- 1343 X 517',1,''),(44,'2013-02-13 13:56:37',1,12,'4','ARRIVE BY CAR',1,''),(45,'2013-02-13 13:59:19',1,12,'4','ARRIVE BY CAR',2,'Changed content.'),(46,'2013-02-13 14:02:26',1,12,'4','ARRIVE BY CAR',2,'Changed content.'),(47,'2013-02-13 15:13:01',1,9,'13','index banner -- 1527 X 666',1,''),(48,'2013-02-13 15:13:05',1,7,'1','www.berowrawatersinn.com.au',2,'Changed banner for site meta \"www.berowrawatersinn.com.au\".'),(49,'2013-02-13 15:33:24',1,15,'1','BEROWA WATERS INN',1,''),(50,'2013-02-13 15:33:58',1,15,'2','THE KITCHEN',1,''),(51,'2013-02-13 15:34:59',1,15,'3','CONTACT US',1,''),(52,'2013-02-13 15:46:28',1,15,'3','CONTACT US',2,'Changed content.'),(53,'2013-02-13 15:46:59',1,15,'3','CONTACT US',2,'Changed content.'),(54,'2013-02-13 15:49:13',1,15,'3','CONTACT US',2,'No fields changed.'),(55,'2013-02-13 15:51:46',1,15,'3','CONTACT US',2,'Changed content.'),(56,'2013-02-13 15:52:30',1,15,'3','CONTACT US',2,'Changed content.'),(57,'2013-02-13 15:52:52',1,15,'3','CONTACT US',2,'Changed content.'),(58,'2013-02-13 15:53:32',1,15,'3','CONTACT US',2,'Changed content.'),(59,'2013-02-13 15:55:10',1,15,'3','CONTACT US',2,'Changed content.'),(60,'2013-02-13 15:56:20',1,15,'3','CONTACT US',2,'Changed content.'),(61,'2013-02-13 15:58:04',1,15,'3','CONTACT US',2,'Changed content.'),(62,'2013-02-13 16:05:05',1,11,'3','Privacy Policy',1,''),(63,'2013-02-13 16:06:04',1,7,'1','www.berowrawatersinn.com.au',2,'Changed footer for site meta \"www.berowrawatersinn.com.au\".'),(64,'2013-02-13 16:11:40',1,11,'3','Privacy Policy',2,'Changed slug.'),(65,'2013-02-13 16:22:22',1,15,'3','CONTACT US',2,'Changed priority.'),(66,'2013-02-13 16:22:33',1,15,'3','CONTACT US',2,'Changed priority.'),(67,'2013-02-13 16:22:47',1,13,'5','Terms & Conditions',2,'Changed priority.'),(68,'2013-02-13 16:23:19',1,13,'4','General Information',2,'Changed priority.'),(69,'2013-02-13 16:24:37',1,13,'5','Terms & Conditions',2,'Changed priority.'),(70,'2013-02-13 16:24:37',1,13,'4','General Information',2,'Changed priority.'),(71,'2013-02-13 16:30:11',1,7,'1','www.berowrawatersinn.com.au',2,'Changed footer for site meta \"www.berowrawatersinn.com.au\".'),(72,'2013-02-13 16:50:21',1,13,'1','The Restaurant',2,'Changed content.'),(73,'2013-02-13 16:51:51',1,13,'5','Terms & Conditions',2,'Changed content.'),(74,'2013-02-13 16:57:40',1,14,'2','The Menu',2,'Changed content.'),(75,'2013-02-13 16:58:14',1,14,'2','The Menu',2,'Changed content.');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'permission','auth','permission'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'message','auth','message'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(7,'site','sites','site'),(8,'log entry','admin','logentry'),(9,'banner','website','banner'),(10,'site meta','website','sitemeta'),(11,'misc page','website','miscpage'),(12,'location page','location','locationpage'),(13,'restaurant page','restaurant','restaurantpage'),(14,'kitchen page','kitchen','kitchenpage'),(15,'component','website','component');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_c25c2c28` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('e529438228759c262638d60a9ac5fcb9','Y2JlZWRjYzIxMDYxYjA3NTBjZDNkNGVmMjkwNGVlZDQ4YzMyNjM4ZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQSKAQF1Lg==\n','2013-02-25 17:27:17'),('0b2147a2e56a0427c61c265a79e05de5','Y2JlZWRjYzIxMDYxYjA3NTBjZDNkNGVmMjkwNGVlZDQ4YzMyNjM4ZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQSKAQF1Lg==\n','2013-02-26 15:12:06');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'www.berowrawatersinn.com.au','www.berowrawatersinn.com.au');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_kitchenpage`
--

DROP TABLE IF EXISTS `kitchen_kitchenpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kitchen_kitchenpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `meta_keywords` longtext,
  `meta_description` longtext,
  `is_landing` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kitchen_kitchenpage_a951d5d6` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_kitchenpage`
--

LOCK TABLES `kitchen_kitchenpage` WRITE;
/*!40000 ALTER TABLE `kitchen_kitchenpage` DISABLE KEYS */;
INSERT INTO `kitchen_kitchenpage` VALUES (1,'The Kitchen','kitchen','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"grey-para\">At Berowra waters inn, we have reinterpreted the traditional &lsquo;degustation menu&rsquo; concept and instead have crafted a menu of smaller dishes.</p>\r\n<p class=\"subheader\">Brian Geraghty</p>\r\n<p class=\"less-padding\">Irish born Brian Geraghty moved to Australia at the age of f our and began cooking at just 14. After undertaking his apprenticeship in various restaurants near his home in regional NSW, he moved to Sydney determined to work for and learn from some of the masters of Australian modern cuisine.</p>\r\n<p class=\"less-padding\">Securing a place in the kitchen at Forbes and Burton, a one-hatted modern bistro in Surry Hills, he worked under David Pegrum before moving on to Astral Restaurant where he was influenced by Sean Connolly. Brian then set off for London to join two-Michelin Star, Pied a Terre, with Australian chef Shane Osborn.</p>\r\n<p class=\"less-padding\">Upon his return to Australia, Brian joined Sydney&rsquo;s well-known Quay restaurant and then Tony Bilson\'s restaurant - Bilson&rsquo;s as Executive Sous Chef.</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p>As the Berowra Waters Inn is a destination dining experience, we wish to offer you a degustation or tasting menu.</p>\r\n<p><img src=\"/media/uploads/chef.jpg\" alt=\"\" width=\"390\" height=\"205\" /></p>\r\n<p class=\"quote\">\"Tony has spoken so often with so much passion about the River and his early days at the Inn that I felt it was an opportunity to start my own chapter here,\" said Brian. &ldquo;It&rsquo;s definitely going to be a great adventure, there&rsquo;s nothing quite like this place. For the degustation we are using both traditional and modern techniques with the wonderful produce on offer here.&rdquo;</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',1),(2,'The Menu','menu','<table class=\"menu-fix\" style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"grey-para\">As Berowra Waters Inn is a destination restaurant, we want you to take your time to enjoy both the food and the river. Our menu is designed as a series of degustation, or tasting dishes allowing you to leisurely graze your way through a story of flavours. The dishes reflect the best seasonal produce available from local farmers and producers and our dedicated suppliers.</p>\r\n<p>Berowra Waters Inn is the ideal location for your Special Event. Only accessible by water the Inn has enjoyed this quiet position since 1926. The current Inn was designed by Glenn Murcutt and has recently been fully renovated. Our floor plan enables us to offer you and your guests a variety of dining options, which when matched with our award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n</td>\r\n<td class=\"table-padding suggestions-bg center\" valign=\"top\">\r\n<p class=\"subheader suggest-header\">summer suggestions</p>\r\n<p class=\"suggest-item\">Hawkesbury Oyster with Cauliflower and Creme <br /> Fraiche Tian, Lobster Gelee</p>\r\n<p class=\"suggest-item\">Pepper Seared Tuna, Pomme Ratte, Olive,<br /> Cabernet Pearls, Black Olive Oil,</p>\r\n<p class=\"suggest-item\">Seared Scallopes, Smoked Eel, Petit Pois a La <br /> Francaise, Raost Almond Puree,</p>\r\n<p class=\"suggest-item\">Spring Garden: Poached asparagus, Crispy Hens yolk, <br /> Vegatable Vinigrette, Chervil Veloute</p>\r\n<p class=\"suggest-item\">Blue-eyed Cod, With Mud Craband Garlic Variations</p>\r\n<p class=\"suggest-item\">Slow Cooked Beef Rib with Pepper Crust, Sauce <br /> ordelaise, Brassacase</p>\r\n<p class=\"suggest-item\">Ash Rolled Goat Chesse, Caramalised Red Onion Sorbet, Celery, Walnut Sourdough</p>\r\n<p class=\"suggest-item\">Milliefeuille of Spring Berries, Formage Frais Sorbet, <br /> Kirscwasser Liquer Gel</p>\r\n<p class=\"suggest-item\">Torte of Dark Chocolate with Dark Ale Ice Cream</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0),(3,'The Cellar','cellar','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"grey-para\">Berowra waters inn has endeavoured to select a wine collection that shows the high standard, dedication and diversity of the Australian wine industry.</p>\r\n<p>To this end we feature a predominately Australian wine selection, augmented with wines from other New World countries and Europe that we feel produce an interesting wine in a specific grape variety or style.</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p>Our cellar here at the Inn is dug into the sandstone foundations of the building and provides an constant temperature for the slow aging of our premium wines.</p>\r\n<p>In an effort to ensure you receive the full joy of your wine selection, we use Riedel stemware for the service of all our wines. You may discover the joys of these fine glasses that deliver each wines unique \'message\', bouquet and taste to the palette, highlighting the full wine experience.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0);
/*!40000 ALTER TABLE `kitchen_kitchenpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_kitchenpage_banner`
--

DROP TABLE IF EXISTS `kitchen_kitchenpage_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kitchen_kitchenpage_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kitchenpage_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kitchenpage_id` (`kitchenpage_id`,`banner_id`),
  KEY `kitchen_kitchenpage_banner_c1bb2cba` (`kitchenpage_id`),
  KEY `kitchen_kitchenpage_banner_50ab1ff4` (`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_kitchenpage_banner`
--

LOCK TABLES `kitchen_kitchenpage_banner` WRITE;
/*!40000 ALTER TABLE `kitchen_kitchenpage_banner` DISABLE KEYS */;
INSERT INTO `kitchen_kitchenpage_banner` VALUES (3,1,7),(7,2,8),(5,3,9);
/*!40000 ALTER TABLE `kitchen_kitchenpage_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_locationpage`
--

DROP TABLE IF EXISTS `location_locationpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_locationpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `meta_keywords` longtext,
  `meta_description` longtext,
  `is_landing` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_locationpage_a951d5d6` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_locationpage`
--

LOCK TABLES `location_locationpage` WRITE;
/*!40000 ALTER TABLE `location_locationpage` DISABLE KEYS */;
INSERT INTO `location_locationpage` VALUES (1,'The Location','location','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"capital-orange\">Berowra waters inn has endeavoured to select a wine collection that shows the high standard, dedication and diversity of the Australian wine industry.</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p>As the Inn is secluded in the native bush setting on the Hawkesbury river it can only be accessed by water ...</p>\r\n<ul>\r\n<li>Via our ferry boat from one of the public wharves</li>\r\n<li>Via private vessel</li>\r\n<li>Via sea plane</li>\r\n</ul>\r\n<p>Via our limousine and our private ferry</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',1),(2,'ARRIVE BY SEAPLANE','arrive-seaplane','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"orange-para less-padding\">The sea planes deliver a spectacular flight over the sydney harbor and the national parks on the way to Berowra Waters.</p>\r\n<p class=\"less-padding\">Sea Plane is a fantastic way to arrive at the inn. The sea planes come from either Palm Beach in the north or Rose Bay in the East. The sea planes only fly during daylight hours and deliver a spectacular flight over Sydney harbour and the bushland of the national parks on the way to Berowra Waters.</p>\r\n<p>It is approximately a thirty minute scenic flight before landing at the Inn.</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p class=\"less-padding\">All sea plane bookings are made direct with the sea plane companies.</p>\r\n<p class=\"less-padding\">Contact details for the sea plane companies are on their websites:</p>\r\n<p class=\"less-less-padding\"><a href=\"#\">www.sydneyseaplanes.com.au</a></p>\r\n<p class=\"less-less-padding\"><a href=\"#\">www.seawing-airways.com.au</a></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0),(3,'ARRIVE BY BOAT','arrive-boat','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"orange-para\">As the inn is secluded in the native bush setting on the hawkesbury river, it can only be accessed by water...</p>\r\n<p class=\"orange-para\">For guests that have a gps, please enter <br /> S33.35.7 E 151.07.4</p>\r\n<p class=\"subheader\">boat hire</p>\r\n<p class=\"less-padding\">Should you wish to hire a boat and cruise the Hawkesbury the following companies hire houseboats in the area</p>\r\n<p class=\"less-less-padding\"><a href=\"#\">www.holidaysafloat.com.au</a></p>\r\n<p class=\"less-less-padding\"><a href=\"#\">www.luxuryafloat.org</a></p>\r\n<p class=\"less-less-padding\"><a href=\"#\">www.ripples.com.au</a></p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p class=\"less-padding\">We maintain three moorings located out the front of the restaurant to the port of the pontoon and these can be booked when you make a reservation. Please advise us of the size of your craft.</p>\r\n<p class=\"less-padding\">When you approach the Inn you may drop your guests at the restaurant pontoon. Our Ferry Master will then direct you to a mooring where you will be picked up in our punt.</p>\r\n<p class=\"less-padding\">The moorings will happily accommodate up to 60\' vessels. If you have a larger craft we may need to secure your craft bow and stern.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0),(4,'ARRIVE BY CAR','arrive-car','<p class=\"subheader less-padding more-top\">Sydney CBD, City East or Northern Suburbs</p>\r\n<p>If leaving the city, eastern suburbs or inner west then head for the harbour bridge or harbour tunnel and head north.</p>\r\n<p>Take the Pacific Highway turnoff at Chatswood and join the Pacific Highway heading northbound.</p>\r\n<p>Travel along the Pacific Highway until you reach the suburb of Wahroonga, here you will see a signpost for the \'F3\' motorway heading north - take this turn off and join the \'F3\'.</p>\r\n<p>Approximately 9km up the F3 is the \'Berowra\' turn off.</p>\r\n<p>Take this turn off and follow the signs to \'Berowra\' (this is actually back on the Pacific Highway). As you approach Berowra (approx 1km) you turn left at the traffic lights, it is clearly signposted to \'Berowra Waters\'.</p>\r\n<p>Follow the signs through the village of Berowra that are marked \'Berowra Waters\' - this will take you onto the road leading down through the bush to the river. As you approach the bottom of the hill there is a turn off to the right called \'Kirkpatrick Way\'. The road and \'Berowra Waters Inn\' are clearly signposted.</p>\r\n<p>Approximately 200m up Kirkpatrick Way there is a Public Wharf on your left, this is also signposted.</p>\r\n<p>You may park in the vicinity and make your way onto the wharf where our Private Ferry will pick you up for a short trip across to the restaurant.</p>\r\n<p class=\"subheader more-top\">FROM NEWCASTLE, HUNTER VALLEY &amp; GOSFORD</p>\r\n<p>If you are heading south on the \'F3\' continue travelling south over the \'Brooklyn Bridge\'. M</p>\r\n<p>Take the next exit after the bridge, which is approx 2.5km, which is marked \'Berowra\'. You are now heading south on the Pacific Highway.</p>\r\n<p>As you approach Berowra, just past the railway station, you turn right at the traffic lights, it is clearly signposted to \'Berowra Waters\'.</p>\r\n<p>Follow the signs through the village of Berowra that are marked \'Berowra Waters\' - this will take you onto the road leading down through the bush to the river.</p>\r\n<p>As you approach the bottom of the hill there is a turn off to the right called \'Kirkpatrick Way\'. The road and \'Berowra Waters Inn\' are clearly signposted.</p>\r\n<p>Approximately 200m up Kirkpatrick Way there is a Public Wharf on your left, this is also signposted.</p>\r\n<p>You may park in the vicinity and make your way onto the wharf where our Private Ferry will pick you up for a short trip across to the restaurant.</p>\r\n<p class=\"subheader  more-top\">FROM DURAL, CASTLE HILL BAULKHAM HILLS, BLUE MOUNTAINS &amp; PARRAMATTA</p>\r\n<p>Make your way to the \'Old Northern Road\' and continue along it until you reach \'Wylds Road, Arcadia\'.</p>\r\n<p>Turn right into \'Wylds Road\' and continue along it until you reach the end.</p>\r\n<p>At the end of \'Wylds Road turn left into \'Arcadia Road\' and follow the signposts to \'Berowra Waters\'.</p>\r\n<p>\'Arcadia Road\' turns into \'Bay Road\' and continues down to Berowra Waters.</p>\r\n<p>As you reach the bottom of the hill and the river, there is a Marina on your left with a large car park. Turn left into the car park and park your vehicle.</p>\r\n<p>There is a concrete boat ramp in the corner of the car park and next to this is a public wharf. Please make your way onto the wharf and our Private Ferry will pick you up for a short trip across to the restaurant.</p>',1,0,'','',0);
/*!40000 ALTER TABLE `location_locationpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_locationpage_banner`
--

DROP TABLE IF EXISTS `location_locationpage_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_locationpage_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locationpage_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `locationpage_id` (`locationpage_id`,`banner_id`),
  KEY `location_locationpage_banner_f9167cc` (`locationpage_id`),
  KEY `location_locationpage_banner_50ab1ff4` (`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_locationpage_banner`
--

LOCK TABLES `location_locationpage_banner` WRITE;
/*!40000 ALTER TABLE `location_locationpage_banner` DISABLE KEYS */;
INSERT INTO `location_locationpage_banner` VALUES (2,1,1),(3,2,10),(4,3,11),(7,4,12);
/*!40000 ALTER TABLE `location_locationpage_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_restaurantpage`
--

DROP TABLE IF EXISTS `restaurant_restaurantpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant_restaurantpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `meta_keywords` longtext,
  `meta_description` longtext,
  `is_landing` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `restaurant_restaurantpage_a951d5d6` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_restaurantpage`
--

LOCK TABLES `restaurant_restaurantpage` WRITE;
/*!40000 ALTER TABLE `restaurant_restaurantpage` DISABLE KEYS */;
INSERT INTO `restaurant_restaurantpage` VALUES (1,'The Restaurant','restaurant','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"orange-para\">Located at Dusthole point on Berowra waters, the inn has a unique location with views over the Hawkesbury River to undisturbed natural bushland.</p>\r\n<p>Berowra Waters Inn is the ideal location for your Special Event. Only accessible by water the Inn has enjoyed this quiet position since 1926. The current Inn was designed by Glenn Murcutt and has recently been fully renovated. Our floor plan enables us to offer you and your guests a variety of dining options, which when matched with our award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p>Our floor plan enables us to offer you and your guests a variety of dining options, which when matched with our award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n<p class=\"subheader\">Reservations</p>\r\n<p class=\"p-enlarge\">Our online reservations will be available soon, if you require any assistance in the meantime, please contact us at: <a href=\"mailto:reservations@berowrawatersinn.com\">reservations@berowrawatersinn.com.</a></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',1),(2,'Special Events','special-events','<table style=\"width: 782px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"281\"><img src=\"/media/assets/images/special-events-pic.jpg\" alt=\"\" /></td>\r\n<td valign=\"top\">\r\n<p class=\"events-header\">The Private Dining Room</p>\r\n<p class=\"events-sub-header\">Up To 28 Guests</p>\r\n<p class=\"specials-para\">Our Private Dining Room has a stunning location at the west end of the building. We are able to accommodate up to 14 guests on one boardroom style table or up to 28 guests utilising several tables. With two \'walls\' of glass to enjoy the serene bush setting and sparkling waters of the Hawkesbury. The room also features an open sandstone fireplace for those chilly, crystal clear winter days. award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style=\"width: 782px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"281\"><img src=\"/media/assets/images/special-events-pic.jpg\" alt=\"\" /></td>\r\n<td valign=\"top\">\r\n<p class=\"events-header\">The Private Dining Room</p>\r\n<p class=\"events-sub-header\">Up To 28 Guests</p>\r\n<p class=\"specials-para\">Our Private Dining Room has a stunning location at the west end of the building. We are able to accommodate up to 14 guests on one boardroom style table or up to 28 guests utilising several tables. With two \'walls\' of glass to enjoy the serene bush setting and sparkling waters of the Hawkesbury. The room also features an open sandstone fireplace for those chilly, crystal clear winter days. award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style=\"width: 782px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"281\"><img src=\"/media/assets/images/special-events-pic.jpg\" alt=\"\" /></td>\r\n<td valign=\"top\">\r\n<p class=\"events-header\">The Private Dining Room</p>\r\n<p class=\"events-sub-header\">Up To 28 Guests</p>\r\n<p class=\"specials-para\">Our Private Dining Room has a stunning location at the west end of the building. We are able to accommodate up to 14 guests on one boardroom style table or up to 28 guests utilising several tables. With two \'walls\' of glass to enjoy the serene bush setting and sparkling waters of the Hawkesbury. The room also features an open sandstone fireplace for those chilly, crystal clear winter days. award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style=\"width: 782px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"281\"><img src=\"/media/assets/images/special-events-pic.jpg\" alt=\"\" /></td>\r\n<td valign=\"top\">\r\n<p class=\"events-header\">The Private Dining Room</p>\r\n<p class=\"events-sub-header\">Up To 28 Guests</p>\r\n<p class=\"specials-para\">Our Private Dining Room has a stunning location at the west end of the building. We are able to accommodate up to 14 guests on one boardroom style table or up to 28 guests utilising several tables. With two \'walls\' of glass to enjoy the serene bush setting and sparkling waters of the Hawkesbury. The room also features an open sandstone fireplace for those chilly, crystal clear winter days. award winning food, wine list and service will ensure that your next event is talked about well into the future!</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0),(3,'Gift Certificates','gift-certificates','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"orange-para\">We are pleased to offer you a flexible \'Gift Certificate\' that can be tailored to suit your budget.</p>\r\n<p>Our menu is designed as a series of \'degustation\' or tasting dishes. The dishes are listed so you may enjoy a progression through the menu with or without the wines matched by the glass by our sommelier.&nbsp;</p>\r\n<p>Please contact us at <a href=\"#\">reservations@berowrawatersinn.com</a> <br /> for more information.</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p class=\"subheader\">TERMS &amp; CONDITIONS</p>\r\n<p>We will not issue a \'Gift Certificate\' without the completed form and payment details or cash payment made in person. The Gift Certificate is valid for 12 months from the time of issue. Normal booking and reservation procedures must be followed when using a \'Gift Certificate\'. Please look after the \'Gift Certificate\' as should a \'Gift Certificate\' be lost we will not re-issue the certificate. The guest must present the original certificate when they dine. Each one is uniquely numbered and we will not accept anything other than the original certificate.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0),(4,'General Information','general-information','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"orange-para less-padding\">Berowra Waters Inn<br /> Via East or West Public Wharves<br /> Berowra Waters NSW 2082<br /> Australia</p>\r\n<p class=\"orange-para sub less-less-padding\">Mail to:</p>\r\n<p class=\"less-less-padding\">10 Charltons Creek Rd <br /> Berrilee NSW 2159, Australia</p>\r\n<p class=\"orange-para less-less-padding\">T 61 9456 1027</p>\r\n<p class=\"orange-para less-padding\"><a href=\"mailto:reservations@berowrawatersinn.co\">E reservations@berowrawatersinn.com</a></p>\r\n<p class=\"orange-para sub less-less-padding\">Opening Hours:</p>\r\n<p class=\"less-less-padding\">Opening hours will be confirmed shortly, for more <br /> information, contact us at <a href=\"mailto:reservations@berowrawatersinn.com\">reservations@berowrawatersinn.com</a></p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p class=\"orange-para sub less-less-padding\">cuisine</p>\r\n<p>As the Berowra Waters Inn is a destination dining experience, we wish to offer you a degustation or tasting menu.</p>\r\n<p class=\"orange-para sub less-less-padding\">credit cards</p>\r\n<p>American Express, Visa &amp; MasterCard.</p>\r\n<p class=\"orange-para sub less-less-padding\">capacity</p>\r\n<p>The main restaurant seats around 50 guests with space for an additional 28 guests in the Private Dining Room. However as a venue for a Special Event utilising larger tables the restaurant can accommodate up to 120 guests.</p>\r\n<p class=\"orange-para sub less-less-padding\">dress code</p>\r\n<p>As the Berowra Waters Inn is a destination dining experience, we wish to offer you a degustation or tasting menu.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0),(5,'Terms & Conditions','terms-conditions','<table style=\"width: 780px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td valign=\"top\" width=\"364\">\r\n<p class=\"orange-para sub less-less-padding\">Minimum Spend</p>\r\n<p>However we do require a minimum spend on the food and beverage component of your event.</p>\r\n<p class=\"orange-para sub  less-less-padding\">EXCLUSIVE USE OF THE ENTRIE RESTAURANT</p>\r\n<p>Please contact us at <a href=\"mailto:reservations@berowrawatersinn.com\">reservations@berowrawatersinn.com</a> for more information.</p>\r\n<p class=\"orange-para sub  less-less-padding\">BOOKINGS AND CONFIRMATION</p>\r\n<p>Upon booking we will forward you a Reservation Confirmation Form which will need to be completed and faxed back to us to secure your booking. We request a credit card for this confirmation to hold on file, nothing will be charged at this point.</p>\r\n<p class=\"orange-para sub  less-less-padding\">Payment</p>\r\n<p>Full payment must be made at the completion of the event. Please note that we do not accept personal cheques. Company cheques are only acceptable with prior arrangement.</p>\r\n</td>\r\n<td class=\"table-padding\" valign=\"top\">\r\n<p class=\"orange-para sub less-less-padding\">CONFIRMING FINAL GUEST NUMBERS</p>\r\n<p>We require final confirmed final numbers for your event 48 hours prior to the event. <br /> This number can be increased or decreased, however we reserve the right to charge the number confirmed at 48 hours notice as the minimum charge, any increase over the confirmed number will be automatically charged. .</p>\r\n<p class=\"orange-para sub  less-less-padding\">SERVICE CHARGE</p>\r\n<p>Please contact us at reservations@berowrawatersinn.com for more information.</p>\r\n<p class=\"orange-para sub  less-less-padding\">CANCELLATION</p>\r\n<p>Please refer to our full terms and conditions that will be provided to you when you make your booking enquiry at the restaurant. For further information please contact our guest relations Manager on: <br /> Email: <a href=\"mailto:reservations@berowrawatersinn.com\">reservations@berowrawaterinn.com</a></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>',1,0,'','',0);
/*!40000 ALTER TABLE `restaurant_restaurantpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_restaurantpage_banner`
--

DROP TABLE IF EXISTS `restaurant_restaurantpage_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant_restaurantpage_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurantpage_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `restaurantpage_id` (`restaurantpage_id`,`banner_id`),
  KEY `restaurant_restaurantpage_banner_42685e92` (`restaurantpage_id`),
  KEY `restaurant_restaurantpage_banner_50ab1ff4` (`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_restaurantpage_banner`
--

LOCK TABLES `restaurant_restaurantpage_banner` WRITE;
/*!40000 ALTER TABLE `restaurant_restaurantpage_banner` DISABLE KEYS */;
INSERT INTO `restaurant_restaurantpage_banner` VALUES (11,1,1),(3,2,3),(5,3,4),(8,4,5),(12,5,6);
/*!40000 ALTER TABLE `restaurant_restaurantpage_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_banner`
--

DROP TABLE IF EXISTS `website_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `image` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `link` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_banner`
--

LOCK TABLES `website_banner` WRITE;
/*!40000 ALTER TABLE `website_banner` DISABLE KEYS */;
INSERT INTO `website_banner` VALUES (1,'Intro-banner','images/intro-banner-img.jpg',1,0,NULL),(2,'stay on river banner','images/staying-banner-img.jpg',1,0,NULL),(3,'events banner','images/restaurant-banner-img.jpg',1,0,''),(4,'gift banner','images/gift-banner-img.jpg',1,0,''),(5,'general info banner','images/general-banner-img.jpg',1,0,''),(6,'terms banner','images/terms-banner-img.jpg',1,0,''),(7,'kitchen banner','images/kitchen-banner-img.jpg',1,0,''),(8,'menu banner','images/menu-banner-img.jpg',1,0,''),(9,'cellar banner','images/cellar-banner-img.jpg',1,0,''),(10,'plane banner','images/plane-banner-img.jpg',1,0,''),(11,'boat banner','images/boat-banner-img.jpg',1,0,''),(12,'car banner','images/car-banner-img.jpg',1,0,''),(13,'index banner','images/flash-home-img.jpg',1,0,'');
/*!40000 ALTER TABLE `website_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_component`
--

DROP TABLE IF EXISTS `website_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_component` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `content` longtext NOT NULL,
  `link` varchar(200) DEFAULT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_component`
--

LOCK TABLES `website_component` WRITE;
/*!40000 ALTER TABLE `website_component` DISABLE KEYS */;
INSERT INTO `website_component` VALUES (1,'BEROWA WATERS INN','<p>Set in bushland on the beautiful Hawkesbury river and accessed only by seaplane, boat or a short trip in our own private ferry, Berowra waters inn is truly a Sydney icon. <a href=\"#\"> Read More &gt;</a></p>','',0),(2,'THE KITCHEN','<p>As Berowra Waters Inn is a destination restaurant, we want you to take your time to enjoy both the food and the river. Our menu is designed as a series of degustation, or tasting dishes allowing you to leisurely graze your way through a story of flavours <a href=\"#\"> Read More &gt;</a></p>','',0),(3,'CONTACT US','<p class=\"less-less-padding\">Bookings are essential</p>\r\n<p class=\"less-less-padding\">By Phone:</p>\r\n<p class=\"orange-para less-less-padding pp\">+61 2 9546 1027</p>\r\n<p class=\"less-less-padding\">By eMail:</p>\r\n<p class=\"orange-para less-less-padding pp\"><a href=\"mailto:reservations@berowrawatersinn.com\">reservations@berowrawatersinn.com</a></p>\r\n<p>get Directions on <a href=\"#\">Google Maps Here</a>:</p>','',0);
/*!40000 ALTER TABLE `website_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_miscpage`
--

DROP TABLE IF EXISTS `website_miscpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_miscpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `meta_keywords` longtext,
  `meta_description` longtext,
  `landing` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `landing` (`landing`),
  KEY `website_miscpage_a951d5d6` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_miscpage`
--

LOCK TABLES `website_miscpage` WRITE;
/*!40000 ALTER TABLE `website_miscpage` DISABLE KEYS */;
INSERT INTO `website_miscpage` VALUES (1,'Introduction','introduction','<p>Set in bushland on the beautiful Hawkesbury river and accessed only by seaplane, boat or a short trip in our own private ferry, Berowra waters inn is truly a Sydney icon.</p>\r\n<p>Forty minutes north of central Sydney the Berowra River widens and flows through a wild and rugged gorge. On the west bank nestled amongst the gum trees lies one of Australia\'s great dining rooms.</p>',1,0,'','','Introduction'),(2,'Staying On The River','staying-river','<p class=\"staying\">SWe highly recommend staying on the river to enhance your Berowra Waters experience.<br /> Please <a href=\"#\">click here</a> for a a variety of accommodation options.</p>',1,0,'','','Stay'),(3,'Privacy Policy','privacy_policy','<p>This is privacy policy</p>',1,0,'','',NULL);
/*!40000 ALTER TABLE `website_miscpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_miscpage_banner`
--

DROP TABLE IF EXISTS `website_miscpage_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_miscpage_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `miscpage_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `miscpage_id` (`miscpage_id`,`banner_id`),
  KEY `website_miscpage_banner_5358b0bb` (`miscpage_id`),
  KEY `website_miscpage_banner_50ab1ff4` (`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_miscpage_banner`
--

LOCK TABLES `website_miscpage_banner` WRITE;
/*!40000 ALTER TABLE `website_miscpage_banner` DISABLE KEYS */;
INSERT INTO `website_miscpage_banner` VALUES (11,3,1),(2,2,2),(9,1,1);
/*!40000 ALTER TABLE `website_miscpage_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_sitemeta`
--

DROP TABLE IF EXISTS `website_sitemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_sitemeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `meta_keywords` longtext NOT NULL,
  `meta_description` longtext NOT NULL,
  `footer` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_sitemeta`
--

LOCK TABLES `website_sitemeta` WRITE;
/*!40000 ALTER TABLE `website_sitemeta` DISABLE KEYS */;
INSERT INTO `website_sitemeta` VALUES (1,1,'Berowrawaters Inn','<p>berorawaters, inn,&nbsp;</p>','<p>berowrawaters inn is the best</p>','<div class=\"left\">\r\n<p>Berowra Waters Inn</p>\r\n<p>Via East and West Public WharvesBerowra Waters</p>\r\n<p>NSW Australia</p>\r\n<p class=\"extra-top\">&copy; Copyright Berowra Waters Inn 2013</p>\r\n<p><a href=\"/privacy_policy.html\">Read Our Privacy Policy</a></p>\r\n</div>\r\n<div class=\"right\">\r\n<p>By Phone:</p>\r\n<div class=\"phone-foot\">+61 2 9456 1027</div>\r\n<p>By eMail:</p>\r\n<div class=\"phone-foot\"><a href=\"mailto:reservations@berowrawatersinn.com\">reservations@berowrawatersinn.com</a></div>\r\n<div class=\"clear-both\">&nbsp;</div>\r\n</div>');
/*!40000 ALTER TABLE `website_sitemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_sitemeta_banner`
--

DROP TABLE IF EXISTS `website_sitemeta_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_sitemeta_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitemeta_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitemeta_id` (`sitemeta_id`,`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_sitemeta_banner`
--

LOCK TABLES `website_sitemeta_banner` WRITE;
/*!40000 ALTER TABLE `website_sitemeta_banner` DISABLE KEYS */;
INSERT INTO `website_sitemeta_banner` VALUES (3,1,13);
/*!40000 ALTER TABLE `website_sitemeta_banner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-13 17:24:38
