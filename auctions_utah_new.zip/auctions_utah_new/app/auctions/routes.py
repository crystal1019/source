import datetime as dt
from flask import render_template, flash, redirect, url_for
from . import auctions
from app.scraper.utahRE import CompStat
from app.models import Properties, db
from flask.ext.login import login_required, current_user
from app.auctions.forms import ProfileForm


@auctions.route('/upcoming')
@auctions.route('/')
@login_required
def currentpropspage():
    properties = db.session.query(Properties).filter(db.and_(Properties.sale_date >= dt.datetime.today(),
             #Properties.tax_data.any(),
             db.or_(Properties.county == 'Salt Lake', Properties.county == 'Utah'))).order_by(Properties.sale_date)
    prop = properties.filter(Properties.comps.any()).order_by(Properties.sale_date.desc()).first()
    comps = prop.comps.all()  # db.session.query(Comps).join(Comps.subject_properties).filter(Properties.id == prop.id).all()
    fullb = prop.tax_data[0].full_baths or 0
    halfb = (prop.tax_data[0].half_baths or 0) * .5
    tqb = (prop.tax_data[0].three_quarter_baths or 0) * .75
    total_baths = fullb + halfb + tqb
    stats = CompStat(comps)
    stats.calculate()
    return render_template('auctions/upcoming.html', props=properties.all(),
                           prop1=prop, comps=comps, stats=stats, total_baths=total_baths)


@auctions.route('/properties<int:property_id>')
@login_required
def propsDetailPage(property_id):
    comps = db.session.query(Properties).filter_by(db.and_(Properties.id == property_id, Properties.comps.any())).one()
    return render_template('auctions/prop_template.html', comps=comps)


@auctions.route('/comps<int:prop_id>')
@login_required
def compsPage(prop_id):
    prop = db.session.query(Properties).filter_by(id=prop_id).one()
    #compstring = ','.join(prop.comps.query(Comps.mls_id).all())
    comps = prop.comps.all() #db.session.query(Comps).join(Comps.subject_properties).filter(Properties.id == prop.id).all()
    fullb = prop.tax_data[0].full_baths or 0
    halfb = (prop.tax_data[0].half_baths or 0) * .5
    tqb = (prop.tax_data[0].three_quarter_baths or 0) * .75
    total_baths = fullb + halfb + tqb
    stats = CompStat(comps)
    stats.calculate()
    return render_template('auctions/comp_template2.html', comps=comps, prop=prop, stats=stats, total_baths=total_baths)


@auctions.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    form = ProfileForm()
    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.location = form.location.data
        db.session.add(current_user._get_current_object())
        db.session.commit()
        flash('Your profile has been updated.')
        return redirect(url_for('auctions.currentpropspage', username=current_user.username))
    form.name.data = current_user.name
    form.location.data = current_user.location
    return render_template('auctions/profile.html', form=form)


@auctions.app_template_filter('dollar')
def currency_format(bucks):
    return '${:,.2f}'.format(float(bucks))


#@auctions.add_app_template_filter('floatorna')
@auctions.app_template_filter('floatorna')
def not_empty(val):
    return '{:0.2f}'.format(val) if val else 'n/a'

