import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class TalbotsScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'talbots.com'
    
    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()    

    def fetch_url(self):
        try:
            request = requests.request('get', self.url)
            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except BaseException, e:
            logging.error('Error %s for %s' % (e.msg, self.url))

    def parse_selection(self, data):
        """
        Parse color, size, price
        """
        data = data.replace(',', '')
        return data.split()

    def generate_record(self, url, site, title, price, image,
                        sku, size=None, color=None, promos=[]):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record

    def craw_html_data(self, soup, html, raw_data):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """
        if raw_data:
            # site name
            site_name = raw_data['site_name']
       
            # url 
            url = raw_data['url']

            # description
            description = raw_data['description']

            # image
            image = raw_data['image']

            # title
            title = raw_data['title']
        else:
            site_name = soup.find('meta', attrs={'property':'og:site_name'})['content']
            url = soup.find('meta', attrs={'property':'og:url'})['content']
            description = soup.find('meta', attrs={'property':'og:description'})['content']
            image = soup.find('meta', attrs={'property':'og:image'})['content']
            title = soup.find('meta', attrs={'property':'og:title'})['content']

        results = []
        
        # Product Id
        pid = soup.find('select', attrs={'id':'quantitySku', 'class':'quantitySku'})['productid']
        
        # price
        price = soup.find('strong', attrs={'class':'itemPrice'}).text
        price = float(price.replace('$', ''))
        
        # colors
        product_colors = soup.find('div', attrs={'class': 'productColors'})
        selection_colors = product_colors.findAll('li')
                
        # Sizes
        product_sizes = soup.find('div', attrs={'class':'productSizes'})
        selection_sizes = product_sizes.findAll('input')
        
        results = []
       
        for row_size in selection_sizes:
            for row_color in selection_colors:        
                size = row_size['value'] 
                color = row_color['title']
                record = self.generate_record(url, site_name, title, price, image, pid, size, color)
                results.append(record)
        
        return results

    def get_base(self, regex, html):
        """
        Pull subset of the HTML for regex evaluation.
        """

        return re.compile(regex).findall(html)[0]

    def get_data_regexes(self, regexes, base):
        """
        Loop over regex rules and pull data.
        return dictionary
        """

        result = {}

        for aregex in regexes:
            try:
                resunts = re.compile(aregex['find']).findall(base)
                result[aregex['name']] = (',').join(resunts)
            except: # TODO: too broad, please improve
                result[aregex['name']] = 'NOTHING'
        return result

    def get_data_json(self, data):
        """
        Parse json to dictionary.
        """
        return json.loads(data)

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        selections = self.craw_html_data(soup, self.html, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(TalbotsScraper.get_domain(), self.url)

        return selections
