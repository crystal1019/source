from django.forms import Form, ModelChoiceField, FileField, ModelForm,\
    CharField, BooleanField, ChoiceField, ModelMultipleChoiceField,  FileField
from django.template import Context, loader
from django.forms.widgets import Textarea, CheckboxSelectMultiple
from django.contrib.auth.models import User
from models import *


class JobForm(Form):
    quality = ChoiceField(choices=Job.QUALITY_CHOICES)
    special_instructions = CharField(widget=Textarea)
    source_locale = ModelChoiceField(queryset=Locale.objects.all())
    target_locales = ModelMultipleChoiceField(queryset=Locale.objects.all(), widget=CheckboxSelectMultiple)
    source_file = FileField()

    job_type = None
    owner = None

    def __init__(self, *args, **kwargs):
        self.job_type = kwargs.pop('job_type', None)
        self.owner = kwargs.pop('owner', None)
        super(JobForm, self).__init__(*args, **kwargs)

    def save(self):
        job = Job.objects.create(job_type=self.job_type,
            owner = self.owner,
            quality = self.cleaned_data['quality'],
            source_locale = self.cleaned_data['source_locale'],
            special_instructions = self.cleaned_data['special_instructions']
        )

        for locale in self.cleaned_data['target_locales']:
            job.target_locales.add(locale)

        source_file = File.objects.create(
            job=job,
            original_filename = self.cleaned_data['source_file'].name,
            attach=self.cleaned_data['source_file'])

        return job


class AddFileForm(Form):
    source_file = FileField()

    job = None

    def __init__(self, *args, **kwargs):
        self.job = kwargs.pop('job', None)
        super(AddFileForm, self).__init__(*args, **kwargs)

    def save(self):
        source_file = File.objects.create(
            job=self.job,
            original_filename = self.cleaned_data['source_file'].name,
            attach=self.cleaned_data['source_file']
        )

        return source_file



