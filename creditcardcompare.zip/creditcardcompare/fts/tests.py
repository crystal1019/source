from django.conf import settings
from django.core.urlresolvers import reverse
from django.test import LiveServerTestCase
from selenium import webdriver


class ExclusiveOfferTest(LiveServerTestCase):
    fixtures = ["test_data.json"]

    def setUp(self):
        self.browser = webdriver.Firefox()

    def tearDown(self):
        self.browser.quit()
        
    def test_on_home_page(self):
        self.browser.get(self.live_server_url)
        body = self.browser.find_element_by_tag_name('body')
        self.assertNotIn('EXCLUSIVE OFFER', body.text)
        
        from offers.core.models import Offer
        offer = Offer.on_site.filter(is_active=True).order_by("?")[0]
        offer.is_exclusive = True
        offer.save()
        
        self.browser.get(self.live_server_url)
        body = self.browser.find_element_by_tag_name('body')
        self.assertIn('EXCLUSIVE OFFER', body.text)
        
    def test_category_page(self):
        from offers.core.models import Category, Offer
        for category in Category.on_site.filter(is_visible=True).order_by("?"):
            try:
                offer = Offer.on_site.filter(is_active=True).order_by("?")[0]
            except IndexError:
                continue
            break
        
        self.browser.get(self.live_server_url + '/%s.php' % category.slug)
        body = self.browser.find_element_by_tag_name('body')
        self.assertNotIn('EXCLUSIVE OFFER', body.text)
        
        offer.is_exclusive = True
        offer.save()
        
        self.browser.get(self.live_server_url + '/%s.php' % category.slug)
        body = self.browser.find_element_by_tag_name('body')
        self.assertIn('EXCLUSIVE OFFER', body.text)
        

class SimpleTest(LiveServerTestCase):
    fixtures = ["initial_data.json"]

    def setUp(self):
        self.browser = webdriver.Firefox()

    def tearDown(self):
        self.browser.quit()
        
    def test_can_open_home(self):
        response = self.client.get(reverse("home"))
        self.failUnlessEqual(response.status_code, 200)
        self.browser.get(self.live_server_url)
        body = self.browser.find_element_by_tag_name('body')
        self.assertIn('copyright', body.text.lower())
        
    def test_can_open_admin(self):
        response = self.client.get(reverse('admin:index'))
        self.failUnlessEqual(response.status_code, 200)
        self.browser.get(self.live_server_url + '/admin777/')
        body = self.browser.find_element_by_tag_name('body')
        self.assertIn('Control Panel', body.text)
