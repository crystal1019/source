import logging
from bs4 import BeautifulSoup
from urlparse import urljoin
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class DiapersScraper(BaseScraper):
    base_image_url = 'http://c1.diapers.com/images/products/p/'

    @staticmethod
    def get_domain():
        return 'diapers.com'

    def compile_image_url(self, sku):
        prefix = sku.split('-')[0]
        url = urljoin(self.base_image_url, '%s/%s_1z.jpg' % (prefix, sku))
        return url

    def clean_price(self, val):
        return val.replace('$', '')

    def extract_color(self, colors, title):
        for color in colors:
            if color in title:
                return color

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        selections = []

        # Gear
        for variant in soup.find_all('tr', class_='diaperItemTR'):
            container = variant.find('input', class_='skuHidden')

            if container is None:
                logger.critical('Was not able to extract sku')
                raise HukksterTooManyOptions(DiapersScraper.get_domain(), self.url)

            title = container['itemdes']
            sku = container['value']
            price = container['price']

            data = {
                'title': title,
                'current_price': {
                    'value': float(price)
                },
                'selections': {
                    'color': title.split('-')[-1].strip()
                },
                'url': raw_data['url'],
                'store': raw_data['site_name'].lower(),
                'image': self.compile_image_url(sku.lower()),
                'local_id': sku
            }
            selections.append(data)

        # Shoes and clothes
        colors = [color.img['color'] for color in soup.find_all('div', class_='colorPaneItems')]

        for li in soup.find_all('li', class_='enbaledSizeButton'):
            variant = li.input

            data = {
                'title': variant['itemdesc'],
                'current_price': {
                    'value': float(self.clean_price(variant['price']))
                },
                'selections': {
                    'color': self.extract_color(colors, variant['itemdesc']),
                    'size': variant['value']
                },
                'url': raw_data['url'],
                'store': raw_data['site_name'].lower(),
                'image': self.compile_image_url(variant['sku'].lower()),
                'local_id': variant['sku']
            }
            selections.append(data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(DiapersScraper.get_domain(), self.url)

        return selections
