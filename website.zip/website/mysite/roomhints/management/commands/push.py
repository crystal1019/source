from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.models import Hint
from datetime import datetime, timedelta
from roomhints.utils import random_number, make_unique, make_unique_photo, search_profile_id, photo_convert, device_send, push_comments
import shutil
from roomhints.color import get_color_stats
from roomhints.affiliate import affiliate_data, affiliate_set
import os
from iospush.models import Device, doFeedbackLoop
from django.utils.timezone import utc
import math

class Command(BaseCommand):
    help = 'Make sure all hints in search use small pictures'

    def handle(self, *args, **options):
        test = True
        for a in args:
            if a == "all":
                test = False

        if test:
            # Used for testing
            d = Device.objects.filter(device_token='cae914b97e7e2f3fb760a4484e2f0393b5f2621e32d46ac23942e4d1e6df63f2').get()
            d.last_notified_at = datetime.utcnow().replace(tzinfo=utc)
            d.save()
            d.send_message("This is a push test message - you forgot to type 'push all'",badge=42)
            #d.send_message(None,badge=3)
            #doFeedbackLoop(sandbox=True)
            #doFeedbackLoop()
        else:
            # Send notifications for all questions
            push_comments(None)

