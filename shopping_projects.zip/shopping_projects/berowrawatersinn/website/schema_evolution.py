
# all of your evolution scripts, mapping the from_version and to_version to a list if sql commands
_evolutions = [
    [('fv1:6661487855772628971','fv1:8375859699303185212'), # generated 2013-02-12 17:14:07.030199
        "ALTER TABLE `website_banner` ADD COLUMN `link` varchar(200);",
    ],
    [('fv1:1301020382166940194','fv1:1990923339792543915'), # generated 2013-02-13 14:51:44.358389
        "CREATE TABLE `website_sitemeta_banner` (\n    `id` integer AUTO_INCREMENT NOT NULL PRIMARY KEY,\n    `sitemeta_id` integer NOT NULL REFERENCES `website_sitemeta` (`id`),\n    `banner_id` integer NOT NULL REFERENCES `website_banner` (`id`),\n    UNIQUE (`sitemeta_id`, `banner_id`)\n)\n;",
    ],
    [('fv1:-872764203978658575','fv1:1990923339792543915'), # generated 2013-04-03 09:57:59.918115
        "DROP TABLE `website_reservation`;",
    ],
] # don't delete this comment! ## _evolutions_end ##
