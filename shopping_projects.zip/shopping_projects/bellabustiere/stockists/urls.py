'''
@author: chaol
'''
from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^(?P<region>.*)/(?P<category>.*).html$', 'bellabustiere.stockists.views.stockists'),
    (r'^(?P<region>.*).html$', 'bellabustiere.stockists.views.stockists'),
    
)
