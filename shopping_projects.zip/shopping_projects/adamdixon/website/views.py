# Create your views here.
from django.http import HttpResponse
from django.template import loader, RequestContext
from adamdixon.website.models import *
from adamdixon.common import *

def home(request):
    t = loader.get_template('index.html')
    jsbanner = FlashImage.objects.filter(in_js=True)

    c = RequestContext(request, commondict({
            'jsbanner':jsbanner,
            'path':'index',
    },request))

    return HttpResponse(t.render(c))

def catchall(request,slug):
    page = MiscPage.objects.get(slug=slug)
    if page.is_landing == 'contact':
        t = loader.get_template('contact.html')
    elif page.is_landing == 'collections':
        t = loader.get_template('collections.html')
    else:
        t = loader.get_template('base.html')
    
    collections = Collection.objects.filter(is_active=True)
    c = RequestContext(request, commondict({
            'page':page,
            'current_meta':page,
            'collections':collections,
    },request))
    
    return HttpResponse(t.render(c))
