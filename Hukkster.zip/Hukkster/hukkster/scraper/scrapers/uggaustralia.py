import demjson
import logging
import re
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('UggaustraliaScraper')

class UggaustraliaScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'uggaustralia.com'
    
    def parse(self):
        raw_data = self.parse_opengraph()
        
        m = re.search(r'app.Product\((.*?)\);', self.html, re.S)
        if not m:
            raise HukksterTooManyOptions(UggaustraliaScraper.get_domain(), self.url)
        product = demjson.decode(m.group(1))
        
        logger.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logger.debug('Finished parsing HTML data')
        
        title = soup.find('h1', attrs={'itemprop': 'name'}).text.strip()
        price = soup.find('div', attrs={'class': 'salesprice'}).text.strip()
        
        colors = [color['val'] for color in product['data']['variations']['attributes'][0]['vals']]
        sizes = [size['val'] for size in product['data']['variations']['attributes'][1]['vals']]
        
        dic_color_image = dict([(color['val'], color['images']['large'][0]['url']) for color in product['data']['variations']['attributes'][0]['vals']])
        
        selections = []
        for color, size in [(c, s) for c in colors for s in sizes]:
            data = {
                'title': title,
                'current_price': {
                    'value': price
                },
                'url': raw_data['url'],
                'store': raw_data['site_name'].lower(),
                'image': dic_color_image[color],
                'local_id': product['data']['ID'],
                'selections': {
                    'size': size,
                    'color': color
                },
                'promos':[]
            }
            selections.append(data)
        
        return selections
