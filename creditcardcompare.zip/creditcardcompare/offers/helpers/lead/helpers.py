from datetime import date
from pygeoip import GeoIP
from django.conf import settings
from forms import LeadForm, ExtraFieldForm
from models import Lead, ExtraField, GEODATA
from offers.helpers.boyd.mail import GenericMailThread as EmailThread


def detect_region_id(request):
    try:
        region = GeoIP(GEODATA).region_by_addr(request.META.get('REMOTE_ADDR','127.0.0.1'))
    except TypeError:
        return '00'
    else:
        return region['region_name']
    
def contact_message(request, form=None):
    data = form.cleaned_data if form is not None else request.POST
    firstname = data.get('firstname', (data.get('name', '').split() or [''])[0])
    EmailThread(**{
        'email': settings.REVIEW_MODERATOR,
        'sender': data['email'],
        'subject': 'Contact message from %s' % request.META['HTTP_REFERER'],
        'context': {'name':firstname,'message':data['message'], 'email':data['email']},
        'template': 'flatpages/email.html',
    }).start()
    lead = signup_newsletter(request, form)
    save_extrafield(lead, 'message', data)
    
def signup_newsletter(request, form=None):
    data = form.cleaned_data if form is not None else request.POST

    firstname = lastname = ''        
    if data.get('name'):
        name = data['name'].split()
        try:
            firstname = name[0]
            lastname = ' '.join(name[1:])
        except IndexError:
            pass
    elif data.get('firstname', False) and data.get('lastname', False):
        firstname = data['firstname']
        lastname = data['lastname']
    
    return save_lead({
        'first_name': firstname,
        'last_name': lastname,
        'email': data['email'],
        'ip':request.META['REMOTE_ADDR'],
        'source':request.META['HTTP_REFERER']
    })
    
def save_lead(cleaned_data):
    '''Creates or updates a lead.
    Returns the form if cleaned_data is invalid
    otherwise returns the lead.
    
    save_lead({
        'first_name': '',
        'last_name': '',
        'email': '',
        'phone': '',
        'state': 1,
        'ip':request.META['REMOTE_ADDR'],
        'source':request.build_absolute_uri()
    })
    '''
    
    try:
        lead = Lead.objects.get(email=cleaned_data['email'])
    except Lead.DoesNotExist:
        lead_form = LeadForm(cleaned_data)
    else:
        if lead.source:
            cleaned_data['source'] = lead.source
        lead_form = LeadForm(cleaned_data, instance=lead)
    if lead_form.is_valid():
        return lead_form.save()
    else:
        return lead_form
    
def save_extrafield(lead, extrafield_name, cleaned_data):
    '''Creates or updates a lead's extra field.
    Returns the form if cleaned_data is invalid
    otherwise returns the extra field.
    '''
    
    try:
        extra_field = lead.extrafield_set.get(name=extrafield_name)
        extra_field.value = cleaned_data[extrafield_name]
        extra_field.save()
    except ExtraField.DoesNotExist:
        extra_field_form = ExtraFieldForm({'name':extrafield_name, 
                                           'value':cleaned_data[extrafield_name],
                                           'lead':lead.id})
        if extra_field_form.is_valid():
            extra_field = extra_field_form.save()
        else:
            return extra_field_form
    return extra_field

def send_ebook(request, 
               email_subject='Getting Out of Debt - Free eBook [Download Link]', 
               template='lead/email.html'):
    name = request.GET.get('name', request.GET['email'].split('@')[0])
    EmailThread(**{
        'email':request.GET['email'],
        'sender':settings.REVIEW_MODERATOR,
        'subject':email_subject,
        'context':{},
        'template':template
    }).start()
    save_lead({'first_name':name,
               'email':     request.GET['email'],
               'source':  request.META.get('HTTP_REFERER', 
                                request.build_absolute_uri().split('?')[0]),
               'ip': request.META['REMOTE_ADDR']}) 

def get_age(searchdetail_or_postdata):
    if type(searchdetail_or_postdata) == dict:
        year = int(searchdetail_or_postdata['birthyear'])
        try:
            month = int(searchdetail_or_postdata['birthmonth'])
        except KeyError:
            month = 1
        try:
            day = int(searchdetail_or_postdata['birthday'])
        except KeyError:
            day = 1
        birthdate = date(year, month, day)
    else:
        birthdate = date(int(searchdetail_or_postdata.birthyear),
                         int(searchdetail_or_postdata.birthmonth),
                         int(searchdetail_or_postdata.birthday))
    if birthdate > date.today().replace(year=birthdate.year):
        return date.today().year - birthdate.year - 1
    else:
        return date.today().year - birthdate.year
