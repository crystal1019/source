cd /home/chaol/projects/arkstart
python manage.py twitter_push  > /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/twitter_process
echo "---------------" >> /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/twitter_process
cat  /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/twitter_process >> /var/www/vhosts/arkstart.com.au/httpdocs/media/index_process/twitter_allprocess
