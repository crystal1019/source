
company_name = "AppointmentWorks";
var label = "County:";
var type = 2;
org_string = "CSI";
rest_url = "/ws/broker/" + org_string + "/";
next_url = "http://www.concertedservices.org/"

timezone = "America/New_York"

LOC_MAIN_OFFICE = 'Main Office';
LOC_DOWNTOWN_OFFICE = 'Downtown Office';
selected_req_id = 1;
selected_location = LOC_MAIN_OFFICE;

COUNTY_APPLING = 'Appling'; 
COUNTY_ATKINSON = 'Atkinson';
COUNTY_BACON = 'Bacon';
COUNTY_BRANTLEY = 'Brantley';
COUNTY_BULLOCH = 'Bulloch';
COUNTY_CANDLER = 'Candler';
COUNTY_CHARLTON = 'Charlton';
COUNTY_CLINCH = 'Clinch';
COUNTY_COFFEE = 'Coffee';
COUNTY_EFFINGHAM = 'Effingham';
COUNTY_EVANS = 'Evans';
COUNTY_JEFF_DAVIS = 'Jeff Davis';
COUNTY_LONG = 'Long';
COUNTY_PIERCE = 'Pierce';
COUNTY_TATTNALL = 'Tattnall';
COUNTY_TOOMBS = 'Toombs';
COUNTY_WARE = 'Ware';
COUNTY_WAYNE = 'Wayne';

selected_location = COUNTY_BULLOCH;
locationResourceMap ={};
locationResourceMap[COUNTY_APPLING] = "1"; 
locationResourceMap[COUNTY_ATKINSON] = "2";
locationResourceMap[COUNTY_BACON] = "3";
locationResourceMap[COUNTY_BRANTLEY] = "19";
locationResourceMap[COUNTY_BULLOCH] = "20";
locationResourceMap[COUNTY_CANDLER] = "21";
locationResourceMap[COUNTY_CHARLTON] = "4";
locationResourceMap[COUNTY_CLINCH] = "5";
locationResourceMap[COUNTY_COFFEE] = "6";
locationResourceMap[COUNTY_EFFINGHAM] = "28";
locationResourceMap[COUNTY_EVANS] = "10";
locationResourceMap[COUNTY_JEFF_DAVIS] = "11";
locationResourceMap[COUNTY_LONG] = "13";
locationResourceMap[COUNTY_PIERCE] = "22";
locationResourceMap[COUNTY_TATTNALL] = "14";
locationResourceMap[COUNTY_TOOMBS] = "15";
locationResourceMap[COUNTY_WARE] = "16";
locationResourceMap[COUNTY_WAYNE] = "23";
selected_req_id = 1;

groupId ={};
groupId[COUNTY_APPLING] = "6"; 
groupId[COUNTY_ATKINSON] = "8";
groupId[COUNTY_BACON] = "10";
groupId[COUNTY_BRANTLEY] = "12";
groupId[COUNTY_BULLOCH] = "14";
groupId[COUNTY_CANDLER] = "16";
groupId[COUNTY_CHARLTON] = "18";
groupId[COUNTY_CLINCH] = "20";
groupId[COUNTY_COFFEE] = "22";
groupId[COUNTY_EFFINGHAM] = "24";
groupId[COUNTY_EVANS] = "26";
groupId[COUNTY_JEFF_DAVIS] = "28";
groupId[COUNTY_LONG] = "30";
groupId[COUNTY_PIERCE] = "32";
groupId[COUNTY_TATTNALL] = "34";
groupId[COUNTY_TOOMBS] = "36";
groupId[COUNTY_WARE] = "38";
groupId[COUNTY_WAYNE] = "40";

initialOptionsLabel = "County: ";
selectedOption = COUNTY_BULLOCH;
initialOptionsMap ={};
initialOptionsMap[COUNTY_APPLING] = COUNTY_APPLING; 
initialOptionsMap[COUNTY_ATKINSON] = COUNTY_ATKINSON;
initialOptionsMap[COUNTY_BACON] = COUNTY_BACON;
initialOptionsMap[COUNTY_BRANTLEY] = COUNTY_BRANTLEY;
initialOptionsMap[COUNTY_BULLOCH] = COUNTY_BULLOCH;
initialOptionsMap[COUNTY_CANDLER] = COUNTY_CANDLER;
initialOptionsMap[COUNTY_CHARLTON] = COUNTY_CHARLTON;
initialOptionsMap[COUNTY_CLINCH] = COUNTY_CLINCH;
initialOptionsMap[COUNTY_COFFEE] = COUNTY_COFFEE;
initialOptionsMap[COUNTY_EFFINGHAM] = COUNTY_EFFINGHAM;
initialOptionsMap[COUNTY_EVANS] = COUNTY_EVANS;
initialOptionsMap[COUNTY_JEFF_DAVIS] = COUNTY_JEFF_DAVIS;
initialOptionsMap[COUNTY_LONG] = COUNTY_LONG;
initialOptionsMap[COUNTY_PIERCE] = COUNTY_PIERCE;
initialOptionsMap[COUNTY_TATTNALL] = COUNTY_TATTNALL;
initialOptionsMap[COUNTY_TOOMBS] = COUNTY_TOOMBS;
initialOptionsMap[COUNTY_WARE] = COUNTY_WARE;
initialOptionsMap[COUNTY_WAYNE] = COUNTY_WAYNE;


selected_zip_code = '12300';

zipcode_resc_map = {};
zipcode_resc_map['12300'] = LOC_MAIN_OFFICE;
zipcode_resc_map['12301'] = LOC_MAIN_OFFICE;
zipcode_resc_map['12302'] = LOC_MAIN_OFFICE;
zipcode_resc_map['12303'] = LOC_DOWNTOWN_OFFICE;
zipcode_resc_map['12304'] = LOC_DOWNTOWN_OFFICE;

console.log('csi loaded..');
//






// Custom feilds function

var col_half_class = "dt_col_half";
var soc_class = "dt_soc";

var generateCustomFields = function(tmp_row) {
	console.log('CustomFields in csi');
	
	 var tmp_col_half4 = $("<div>")                
                  .addClass(col_half_class)
                  .appendTo(tmp_row);                      
     $("<div>").text("SSN: ")
             .appendTo(tmp_col_half4 );   
     $("<input id='soc'>")
             .attr("type", "text")
             .attr("placeholder", "Social Security Number")
             .addClass(soc_class)
             .appendTo(tmp_col_half4 ); 	
}
//--------


// Custome Fields validatin
var validateCustomFields = function() {
	cleanSSN = $("#soc").val().replace(/[^0-9]/g,'');
	if(cleanSSN.length < 9) {  
	  return 0;
	}	
	return 1;
}

//-------
//Custom data function
var generateCustomData = function(inputs) {
	
	customAttributes = [];
	
	//customAttributes[0] = {};
	//customAttributes[0]['attributeId'] = 3;
	//customAttributes[0]['attributeValue'] = $(".dt_soc").val().replace(/[^0-9]/g,'');;
	console.log("PN PN 172-31-30-77");
	console.log($(".dt_phonenumber").val());
	//console.log(phonenumber);
	customAttributes[0] = {};
	customAttributes[0]['attributeId'] = 7;
	customAttributes[0]['attributeValue'] = site;

	customAttributes[1] = {};
	customAttributes[1]['attributeId'] = 6;
	cleanPhone = $(".dt_phonenumber").val().replace(/[^0-9]/g,'');
	customAttributes[1]['attributeValue'] = cleanPhone;

	
	console.log($("#email").val());
	console.log($("#soc").val());
	ssn = $("#soc").val()
	ssnEnding = ssn.substr(ssn.length - 4);
	console.log("ssn en");
	console.log(ssnEnding);


	customAttributes["userName"] = cleanPhone + '--' + ssnEnding;	
	return customAttributes;
}

var clearCustomFields = function() {
	
}

var maskCustomFields = function() {
	//$("#soc").mask("99999");
}
