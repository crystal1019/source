import csv
from bellabustiere.stockists.models import *
from django.template.defaultfilters import slugify
from django.contrib.sites.models import Site

class StockistsManagement:
    
    def __init__(self,path):
        self.records = self.readFile(path)
        self.upload()
    
    def readFile(self,path):
        f = csv.reader(open(path,'rb'),delimiter=',')
        records = []
        for x in f:
            records.append(x)
            
        records = records[1:]
        print records
        return records
    
    def upload(self):
        for x in self.records:
            s, created = Stockist.objects.get_or_create(name=x[0])
            s.name = x[0]
            s.address = x[1]
            s.address2 = x[2] + ', ' + x[3] if x[3] else x[2]
            s.suburb = x[4]
            s.state = x[5]
            s.postcode = x[6]
            s.phone = x[7]
            s.fax = x[8]
            s.email = x[9]
            s.website = x[10]
            s.region = 'AUSTRALIA'
            s.save()
            
            sellcategory = x[12].split(',')
            
            for xx in sellcategory:
                if xx.strip():
                    sc, created = SellCategory.objects.get_or_create(name=xx.strip().title())
                    sc.slug = slugify(xx.strip().title())
                    sc.save()
                    s.category.add(sc)
                
            
            site = Site.objects.get(id=3)
            s.sites.add(site)
                
        return None
            
            

        