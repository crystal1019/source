import os
from django.conf import settings
from django.db import models
from wurfl_cloud import Cloud as WurflCloud, utils
from offers.helpers.boyd.mail import GenericMailThread


IS_MOBILE = settings.DEFAULT_TEMPLATE == settings.DEVICES['smartphone']


class UserAgent(models.Model):
    agent = models.CharField(max_length=250, unique=True)
    os = models.CharField(max_length=15, blank=True, null=True)
    browser = models.CharField(max_length=15, blank=True, null=True)
    hit_count = models.IntegerField(default=0)
    first_hit = models.DateTimeField(auto_now_add=True)
    last_hit = models.DateTimeField(auto_now=True)
    is_mobile = models.BooleanField(help_text='If this is a smartphone browser.')
    is_tablet = models.BooleanField()
    is_smartphone = models.BooleanField()
    
    class Meta:
        ordering = ('-hit_count', '-last_hit')
        db_table = 'template_utils_useragent'
    
    def __unicode__(self):
        return '%s-%s' % (self.os, self.browser)
        
    def populate_is_mobile(self):
        try:
            config = utils.load_config(os.path.join(settings.PROJECT_DIR, '../conf', 'wurfl_config.json'))
        except IOError, e:
            self.is_mobile = IS_MOBILE
            self.notify(e)
            return
        cache = utils.get_cache(config)
        client = WurflCloud(config, cache)
        try:
            device = client(self.agent, capabilities=["is_smartphone", "is_tablet"])
        except LookupError, e:
            self.is_mobile = IS_MOBILE
            self.notify(e)
        else:
            self.is_mobile = device['capabilities']['is_smartphone']
            self.is_smartphone = device['capabilities']['is_smartphone']
            self.is_tablet = device['capabilities']['is_tablet']
                
    def save(self, *args, **kwargs):
        if self.id is None:
            self.populate_is_mobile()
        return super(UserAgent, self).save(*args, **kwargs)
    
    def hit(self):
        self.hit_count += 1
        self.save()
        
    def notify(self, error):
        msg = '''
            Cannot detect whether this device is mobile or not: %s.<br/>
            %s
            The default behavior is to serve %s template
        ''' % (self.agent, error, 'mobile' if self.is_mobile else 'desktop')
        GenericMailThread(**{
            'email': settings.ADMINS[0][1],
            'subject': 'Warning: Cannot detect device!',
            'context': {'message': msg},
            'template': 'flatpages/email.html',
            'connection': None,  # do not use Sendgrid
        }).start()
