
# all of your evolution scripts, mapping the from_version and to_version to a list if sql commands
_evolutions = [
    [('fv1:-2258228385236687079','fv1:5322245798593224238'), # generated 2013-02-07 15:22:33.886053
        "ALTER TABLE `website_miscpage` MODIFY COLUMN `is_landing` varchar(100) NULL;",
    ],
] # don't delete this comment! ## _evolutions_end ##
