from time import time

from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.sites.models import Site
from django.contrib.contenttypes.models import ContentType
from django.core.urlresolvers import reverse


def get_path(instance, filename):
    ctype = ContentType.objects.get_for_model(instance)
    model = ctype.model
    extension = filename.split('.')[-1]
    name = str(time()).replace('.', '_')
    return "%s/%s.%s" % (model, name, extension)


CURRENCY_CHOICES = (
        ('USD', 'US Dollars'),
        ('CAD', 'Canadian Dollars')
    )


class Locale(models.Model):
    code = models.CharField(max_length=5)
    label = models.CharField(max_length=10)

    def __unicode__(self):
        return self.code


class Organization(models.Model):
    name = models.CharField(max_length=100)
    welcome_message = models.TextField(blank=True, null=True)
    system_message = models.CharField(max_length=140, blank=True, null=True)
    logo = models.ImageField(upload_to=get_path, blank=True)
    more_css = models.TextField(blank=True, null=True)
    tms_username = models.CharField(max_length=20)
    tms_password = models.CharField(max_length=20)
    tms_email = models.CharField(max_length=20)
    locale = models.ForeignKey('Locale')
    default_currency = models.CharField(max_length=5, choices=CURRENCY_CHOICES, default='en-us')
    site = models.OneToOneField(Site)

    def __unicode__(self):
        return self.name


class UserProfile(models.Model):
    user = models.OneToOneField(User)
    company = models.CharField(max_length=200, blank=True, null=True)
    address_1 = models.CharField(max_length=200, blank=True, null=True)
    address_2 = models.CharField(max_length=200, blank=True, null=True)
    city = models.CharField(max_length=200, blank=True, null=True)
    postal = models.CharField(max_length=10, blank=True, null=True)
    organization = models.ForeignKey('Organization')
    default_source_lang = models.ForeignKey('Locale', blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)

    def __unicode__(self):
        return '%s %s' % (self.user.first_name, self.user.last_name)


class JobType(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    pricing_multiplier = models.FloatField(default=1)

    def __unicode__(self):
        return self.name


    def get_absolute_url(self):
        return reverse('job_type', args=[str(self.id)])


class JobTypeExample(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    organization = models.ForeignKey('Organization')
    job_type = models.ForeignKey('JobType')
    thumbnail = models.ImageField(upload_to=get_path, blank=True)

    def __unicode__(self):
        return self.name


class Job(models.Model):

    QUALITY_CHOICES = (
        (0, 'Low'),
        (1, 'Medium'),
        (3,  'High')

    )

    STATUS_CHOICES = (
        (0, 'New'),
        (1, 'Confirmed'),
        (10, 'Complete')
    )

    job_type = models.ForeignKey('JobType')
    owner = models.ForeignKey(User, blank=True, null=True)
    tms_job_id = models.CharField(max_length=100, blank=True, null=True)
    quality = models.IntegerField(choices=QUALITY_CHOICES, default=1)
    special_instructions = models.TextField(blank=True, null=True)
    source_locale = models.ForeignKey('Locale', blank=True, null=True)
    target_locales = models.ManyToManyField('Locale', related_name="target_locales")
    creation_date = models.DateTimeField(auto_now_add=True)
    due_date = models.DateField(blank=True, null=True)
    completion_date = models.DateField(blank=True, null=True)
    translated_file = models.FileField(upload_to=get_path, blank=True)
    status = models.IntegerField(choices=STATUS_CHOICES, default=0)



    def files(self):
        return File.objects.filter(job=self)

    def __unicode__(self):
        return '%s %s %s' % (
            self.owner and self.owner.first_name or "Anonymous",
            self.owner and self.owner.last_name or "User",
            self.creation_date.strftime('%m/%d/%Y %I:%M:%S %p')
            )

    def get_absolute_url(self):
        return reverse('job_detail', args=[str(self.id)])


class File(models.Model):
    job = models.ForeignKey('Job')
    original_filename = models.CharField(max_length=100, default="unknown")
    attach = models.FileField(upload_to=get_path)

    def __unicode__(self):
        return self.original_filename
