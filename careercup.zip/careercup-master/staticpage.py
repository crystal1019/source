import masterpage

class StaticPage(masterpage.MasterPage):
	def get(self):	
		page_map = {
			'/book': [{'parent_tab': 'resources'}, 'Cracking the Coding Interview (Book)', 'html/book.html'],
			'/about': [{'parent_tab': 'about'}, 'About CareerCup', 'html/about.html'], 
			'/careercup_book_solutions': [{'parent_tab': 'resources'}, 'Cracking the Coding Interview Solutions', 'html/booksolutions.html'],
			'/chatroomthings': [{'parent_tab': 'resources'}, 'Chat Room Rules and Suggestions', 'html/chatroomthings.html'],
			'/ctciapp': [{'parent_tab': 'resources'}, 'Cracking the Coding Interview iPhone App', 'html/ctciapp.html'],
			'/googleresume': [{'parent_tab': 'googleresume'}, 'The Google Resume', 'html/googleresume.html'],
			'/helpcareercup': [{}, 'How Can You Help CareerCup', 'html/helpcareercup.html'],
			'/interview': [{}, 'Programmer Mock Interviews', 'html/mockinterviews.html'],
			'/resources': [{'parent_tab': 'resources'}, 'Technical Interviewing Resources', 'html/resources.html'],
			'/resume': [{'parent_tab': 'resume'}, 'This is what a GOOD resume should look like', 'html/resume.html'],
			'/resumereview': [{}, 'Resume Review', 'html/resumereview.html'],
			'/sendmoney': [{}, 'Send Money to Gayle', 'html/sendmoney.html'],
			'/video': [{'parent_tab': 'resources'}, 'Cracking the Coding Interview (Video)', 'html/video.html'],
			'/wiserprofile': [{}, 'Wiser Profile - Review, Feedback, and Tips for Your LinkedIn Profile', 'html/wiserprofile.html']
		}
		root_url = self.request.path
		if root_url in page_map:
			values = page_map[root_url]
			self.pushPage(values[0], values[1], values[2])
		else:
			self.error(404)
			self.response.out.write(self.getBody({}, 'html/404.html')) 
