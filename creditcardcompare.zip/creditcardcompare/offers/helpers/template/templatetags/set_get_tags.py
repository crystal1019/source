from django import template
from offers.core import helpers, utils
from offers.helpers.template import get_functions

 
register = template.Library()

 
class SetVarNode(template.Node):
    def __init__(self, var_name, var_value):
        self.var_name = var_name
        self.var_value = var_value
 
    def render(self, context):
        try:
            value = template.Variable(self.var_value).resolve(context)
        except template.VariableDoesNotExist:
            value = self.var_value
        context[self.var_name] = value
        return u""
    
class GetVarNode(template.Node):
    '''Gets returned value of given function using supplied parameters'''
    
    def __init__(self, func_name, var_name, *args):
        self.func_name = func_name
        self.var_name = var_name
        self.args = args
 
    def render(self, context):
        def _get_func(from_modules=[utils, helpers, get_functions]):
            '''Keeping this function for backward compatibility of templates
            '''
            try:
                return getattr(from_modules.pop(), self.func_name)
            except AttributeError:
                return _get_func(from_modules)
            except IndexError:
                return ''
        
        args = []
        for arg in self.args:
            if arg[0] == arg[-1] and arg[0] in ('"', "'"):
                args.append(arg[1:-1])
            else:
                args.append(template.Variable(arg).resolve(context))
        try:
            result = self.get_function(context)(*args)
        except template.VariableDoesNotExist:
            try:
                result = _get_func()(*args)
            except TypeError:
                return ''
        if self.var_name:
            context[self.var_name] = result
            return ''
        return result
        
    def get_function(self, context):
        parts = self.func_name.split('.')
        obj = template.Variable(parts.pop(0)).resolve(context)
        
        while len(parts)>0:
            p = parts.pop(0)
            try:
                obj = getattr(obj, p)
            except AttributeError:
                obj = getattr(obj(), p)
        return obj

@register.tag(name='set')
def set_var(parser, token):
    """
        {% set <var_name> = <var_value> %} or
        {% set <<var_value> as var_name> %}
    """
    parts = token.split_contents()
    if parts[2]=="=" and len(parts)==4:
        return SetVarNode(parts[1], parts[3])
    elif parts[2]=="as" and len(parts)==4:
        return SetVarNode(parts[3], parts[1])
    raise template.TemplateSyntaxError("'set' tag must be of the form: {% set <var_name> = <var_value> %} or {% set <<var_value> as var_name> %}")

@register.tag(name='get')
def get_var(parser, token):
    """
        {% get <func_name> <params>%} or {% get <func_name> as <var_name> <params>%}
    """
    varname = None
    parts = token.split_contents()
    if len(parts) > 2:
        if parts[2] == 'as':
            varname = parts[3]
            args = parts[4:]
        else:
            args = parts[2:]
    else:
        args = []
    return GetVarNode(parts[1], varname, *args)