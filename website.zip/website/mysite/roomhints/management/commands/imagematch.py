from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.imagematcher import find_image_match
from roomhints.imagematcher import score_images
from roomhints.imagematcher import score_images_dem
from roomhints.imagematcher import score_images_brief
from roomhints.imagematcher import score_images_ccv
from roomhints.models import Project

class Command(BaseCommand):
    help = 'Finds which product an image is showing and where to get it'

    def handle(self, *args, **options):
        input_image = None
        input_image2 = None
        for a in args:
            if input_image == None:
                input_image = a
            elif input_image2 == None:
                input_image2 = a

        search_images = None
        if input_image2 == None:
            # Match against all images
            p = Project()
            p.budget = -1
            p.custom = "rug"
            p.photo_web = input_image
            search_images, output_image, output_image_score, scores = find_image_match(input_image,"defaulthints",p)
            p.public = False
        else:
            # Match these two images
            output_image = input_image2
            #output_image_score = score_images_brief(input_image,input_image2)
            output_image_score = score_images_dem(input_image,input_image2,'dummy')
            #output_image_score = score_images_ccv(input_image,input_image2,'dummy')
            search_images = 1

        output = ""
        output += "InImage:      " + str(input_image) + "\n"
        output += "OutImage:     " + str(output_image) + "\n"
        output += "OutScore:     " + str(output_image_score) + "\n"
        output += "Total images: " + str(search_images) + "\n"
        print output
