'''
@author: chaol
'''
from django.conf.urls.defaults import *
from arkstart.blog.feeds import BlogFeed

urlpatterns = patterns('',
    (r'^$', 'arkstart.blog.views.home'),
    (r'^blog/feed/',BlogFeed()),    
    (r'^blog/tags/(?P<tag>.*).html$', 'arkstart.blog.views.tag'),
    (r'^search.html$','arkstart.blog.views.blogsearch'),    
    (r'^blog/(?P<category>.*)-archive(?P<offset>.*).html$', 'arkstart.blog.views.home'),
   
    (r'^blog/(?P<code>.*).html$', 'arkstart.blog.views.post'),
    
    (r'^register.html$', 'arkstart.website.views.register'),
    (r'^login.html$', 'arkstart.website.views.login'),
    (r'^logout.html$', 'arkstart.website.views.logout'),
    
    (r'^(?P<path>.*)$', 'arkstart.website.views.catchall'),

)
