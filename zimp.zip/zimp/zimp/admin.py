from django.contrib import admin
from .models import *


class UserAdmin(admin.ModelAdmin):
    search_fields = ['email']


class BrandAdmin(admin.ModelAdmin):
    search_fields = ['razao_social']


class RetailerAdmin(admin.ModelAdmin):
    search_fields = ['razao_social']


class MallAdmin(admin.ModelAdmin):
    search_fields = ['razao_social']


admin.site.register(User, UserAdmin)
admin.site.register(UserInfo)
admin.site.register(Mall, MallAdmin)
admin.site.register(Brand, BrandAdmin)
admin.site.register(Retailer, RetailerAdmin)
admin.site.register(Nearbytes)
