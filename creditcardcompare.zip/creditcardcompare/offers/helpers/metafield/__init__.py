import re


def get_rewards_points_ratio(value):
    '''
    >>> get_rewards_points_ratio('1 pt per $1 spent')
    1.0
    >>> get_rewards_points_ratio('0.5 pt per $1 spent')
    0.5
    >>> get_rewards_points_ratio('5.0 pts per $1 spent')
    5.0
    >>> get_rewards_points_ratio('1 pt per $1 spent <br />(Amplify)')
    1.0
    >>> get_rewards_points_ratio('1 QFF pt per $1 spent')
    1.0
    >>> get_rewards_points_ratio('2 pts per $2 spent')
    1.0
    >>> get_rewards_points_ratio('1 = 2 points')
    2.0
    >>> get_rewards_points_ratio('2 = 2 Velocity Points')
    1.0
    >>> get_rewards_points_ratio('1 = 1 QFF point')
    1.0
    >>> get_rewards_points_ratio('2$ = 1 point')
    0.5
    >>> get_rewards_points_ratio('1 cent per $1 spent')
    1.0
    >>> get_rewards_points_ratio('2 cents per $1 spent')
    2.0
    >>> get_rewards_points_ratio('0')
    0.0
    '''
    if value in ('-', None, '0'):
        return 0.0
    patt1 = re.compile('^([\d.]+) ?.* (pts?|cents?) per \$(\d).*')
    patt2 = re.compile('^([\d.]+)\$? = ([\d.]+) ?.* [p|P]oints?')
    
    ratio = patt1.search(value)
    if ratio is not None:
        return float(ratio.groups(0)[0])/float(ratio.groups(0)[2])
    ratio = patt2.search(value)
    if ratio is not None:
        return float(ratio.groups(0)[1])/float(ratio.groups(0)[0])
    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()