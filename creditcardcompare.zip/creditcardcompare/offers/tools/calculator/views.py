import json as simplejson
from django.conf import settings
from django.http import HttpResponse, Http404
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.humanize.templatetags.humanize import intcomma
from offers.helpers.lead.helpers import save_extrafield, save_lead as save_lead_helper
from offers.core.models import Category
from offers.core.utils import metafield_value
from offers.utils import f
from forms import MinimumRepaymentForm, CarLoanForm
from helpers import CUSTOM_ERROR_MSG
from helpers import generate_series, calculate_term_length, get_annuity
from helpers import get_current_balance, get_complex_annuity, get_remaining_balance
import re


def balance_transfer(request):
    if not request.POST:
        return render_to_response('calculator/balance_transfer.html', {}, RequestContext(request))
    YEAR_COUNT = 1
    balance = re.sub("[^\d\.-]", "", request.POST['balance'])
    monthly_payment = f(balance)*f(request.POST['minimum_repayment'])/100.0
    monthly_payment += f(request.POST['monthly_over_payment'].strip())
    i = lambda term, remaining: monthly_payment * term - (f(balance) - remaining)
    series_data1 = generate_series(request.POST['old_name'],
                                   f(balance), 
                                   f(request.POST['old_rate']), 
                                   YEAR_COUNT,
                                   monthly_payment)
    series_data2a = generate_series(request.POST['new_name'],
                                   f(balance), 
                                   f(re.sub("[^\d\.]", "", request.POST['balance_transfer_rate'])),
                                   int(request.POST['balance_transfer_period'])/12.0,
                                   monthly_payment)
    remaining = get_remaining_balance(f(balance),
                                      monthly_payment,
                                      f(request.POST['balance_transfer_rate'])/12.0,
                                      int(request.POST['balance_transfer_period']))
    series_data2b = generate_series(request.POST['new_name'],
                                   remaining, 
                                   f(request.POST['new_rate']), 
                                   YEAR_COUNT-int(request.POST['balance_transfer_period'])/12.0,
                                   monthly_payment)
    series_data2 = {'name': request.POST['new_name'], 'data': series_data2a['data'] + series_data2b['data'][1:]}
    series_interest1 = [round(i(x, r),2) for x, r in enumerate(series_data1['data'])]
    series_interest2 = [round(i(x, r),2) for x, r in enumerate(series_data2['data'])]
    series_data1['data'][-1] += f(request.POST.get('old_annual_fee', 0))
    series_data2['data'][-1] += f(request.POST.get('new_annual_fee', 0))
    context = {'first_balance': series_data1,
               'second_balance': series_data2,
               'first_interest': {'data': series_interest1},
               'second_interest': {'data': series_interest2}}
    return HttpResponse(simplejson.dumps(context))

def savings_goal(request):
    if not request.POST:
        return render_to_response('calculator/savings-goal.html', {}, RequestContext(request))

    months = int(request.POST['months'])
    try:
        months_promo = int(request.POST['promo_interest_rate_duration'])
    except ValueError:
        months_promo = 0
    initial = f(re.sub("[^\d\.-]", "", request.POST['initial_amount']))
    savings_goal = f(re.sub("[^\d\.-]", "", request.POST['savings_goal']))
    annual_rate = f(re.sub("[^\d\.]", "", request.POST['interest_rate']))
    annual_rate_promo = f(re.sub("[^\d\.]", "", request.POST['promo_interest_rate']))
    
    if months_promo > months:
        months_promo = months
    annuity = get_complex_annuity(initial, savings_goal,
                                  months_promo,
                                  months - months_promo,
                                  annual_rate_promo/12.0,
                                  annual_rate/12.0)
    running_balance = []
    running_investment = []
    for x in range(months+1):
        if x <= months_promo:
            cur_bal = get_current_balance(initial, annuity, x, 0, annual_rate_promo/12.0, annual_rate/12.0)
        else:
            cur_bal = get_current_balance(initial, annuity, months_promo, x-months_promo, annual_rate_promo/12.0, annual_rate/12.0)
        running_balance.append(round(cur_bal, 2))
        running_investment.append(round(annuity * x + initial, 2))
    
    context = {
        'annuity': '%.2f' % annuity,
        'running_balance': running_balance,
        'running_investment': running_investment}
    return HttpResponse(simplejson.dumps(context))

def car_loan(request):
    if settings.SITE_NAME != 'moneycompare.com.au':
        raise Http404
    
    series = []
    annuity = 0
    if request.POST:
        post_data = request.POST.copy()
        post_data['amount'] = re.sub("[^\d*(?:\.\d+]", "", post_data['amount'])
        form = CarLoanForm(post_data)
        if form.is_valid():
            lead = save_lead_helper({
                        'first_name': request.POST['first_name'],
                        'last_name': request.POST['last_name'],
                        'email': request.POST['email'],
                        'phone': request.POST['phone'],
                        'state': request.POST['state'],
                        'ip':request.META['REMOTE_ADDR'],
                        'source':request.build_absolute_uri()
                    })
            save_extrafield(lead, 'amount', form.cleaned_data)
            rate = f(form.cleaned_data['rate'])
            term = f(form.cleaned_data['term'])
            series.append(generate_series('Remaining Balance',
                                          form.cleaned_data['amount'],
                                          rate, term))
            series.append(generate_series('Interest Paid',
                                          form.cleaned_data['amount'],
                                          rate, term))
            annuity = get_annuity(form.cleaned_data['amount'],rate,term)
    else:
        form = CarLoanForm()
        form.fields['source'].initial = request.build_absolute_uri()
    return render_to_response('calculator/car-loan.html', 
                              {'form':form, 'all_series': series, 'annuity': annuity},
                              RequestContext(request))

def _save_lead(request):
    lead_data = request.POST.copy()
    lead_data.update({'ip':request.META['REMOTE_ADDR']})
    save_lead_helper(lead_data)
    
def _fetch_featured_offer():
    '''Returns data of the featured offer 
    from Balance Transfer Credit Cards category
    '''
    category = Category.objects.get(slug='balance-transfer-credit-cards')
    try:
        offer = category.offers_published_on_site()[0]
    except IndexError:
        return
    rate = metafield_value(offer, 'Balance Transfer Rate', False)
    return offer.title, rate

def _calculate_repayment(form, name):
    repayment = f(form.cleaned_data[name])
    if form.cleaned_data[name + '_type'] == '%':
        return int(form.cleaned_data['amount']) * repayment / 100
    return repayment

def minimum_repayment(request):
    context = {}
    data = {'term': '',
            'rate': request.POST.get('rate', ''),
            'overpayment': '.'}
    result_text = '''It will take %(term)s months to repay your
        balance of $%(principal)s at %(rate)s%% p.a.
        with a minimum monthly repayment of $%(minimum)s%(overpayment)s'''
    
    if request.POST:
        form = MinimumRepaymentForm(request.POST)
        if form.is_valid():
            series = []
            
            principal = f(form.cleaned_data['amount'])
            data['principal'] = intcomma('%0.2f' % principal)
            minimum = _calculate_repayment(form, 'minimum_repayment')
            data['minimum'] = intcomma('%0.2f' % minimum)
            title, rate =_fetch_featured_offer()
            series.append(generate_series(title + ' (Minimum Repayment)', principal, rate, annuity=minimum))
            try:
                series.append(generate_series('Your Card (Minimum Repayment)', principal, form.cleaned_data['rate'], annuity=minimum))
            except Exception, e:
                if e.message == CUSTOM_ERROR_MSG:
                    form._errors["minimum_repayment"] = form.error_class(Exception(CUSTOM_ERROR_MSG % 'Minimum Repayment'))
                else:
                    raise e
            else:
                data['term'] = '%0.2f' % (calculate_term_length(principal, form.cleaned_data['rate'], minimum) * 12)
            
            overpayment = _calculate_repayment(form, 'overpayment')
            if overpayment and not form.errors:
                series.append(generate_series(title + ' (Overpayment)', principal, rate, annuity=minimum + overpayment))
                series.append(generate_series('Your Card (Overpayment)', principal, form.cleaned_data['rate'], annuity=minimum + overpayment))

                data['term'] = '%0.2f' % (calculate_term_length(principal, form.cleaned_data['rate'], minimum + overpayment) * 12)
                data['overpayment'] = ' and making monthly overpayments of $%s.' % intcomma('%0.2f' % overpayment)
            context = {'all_series': series, 'result_text': result_text % data}
    else:
        form = MinimumRepaymentForm()

    if request.is_ajax():
        try:
            context.update({'error': form.errors.popitem()[1]})
        except Exception,e:
            pass
        return HttpResponse(simplejson.dumps(context))
    context.update({'form':form, 'term': data['term']})
    return render_to_response('calculator/minimum_repayment.html', 
                              context,
                              RequestContext(request))