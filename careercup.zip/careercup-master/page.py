import masterpage

import math

import method_url
import method_question
import method_cache
import logging	
import objects	

class ViewPage(masterpage.MasterPage): 
	number_questions = 0
	
	def getQuestionKeys(self, subattributes, page_num):
		sort = self.getCurrentSort()
		set_start = method_url.getFirstPageOfSet(method_question.pages_per_set, page_num)
		results = method_question.getQuestions(sort, subattributes, set_start, True)
		return results
	
	def getCurrentSort(self):
		current_sort = method_url.getStringParam(self, 'sort')
		if not current_sort or current_sort == '':
			current_sort = 'date'
		return current_sort
	
	def isDefaultPage(self):
		if self.getPageIndex() == 0 and self.getCurrentSort() == 'date':
			return True
		return False	
		
	def getPageCacheKey(self, subattributes, sort):
		page_cache_key = 'page'	+ '-' + sort
		if subattributes['company']:
			page_cache_key = page_cache_key + '-' + subattributes['company']			
		if subattributes['job']:
			page_cache_key = page_cache_key + '-' + subattributes['job']
		if subattributes['topic']:
			page_cache_key = page_cache_key + '-' + subattributes['topic']
		return page_cache_key				
			
	def get(self):
		if self.getCurrentSort() not in method_question.sorts:
			return self.show404()

		# get primary attribute
		attribute_id = method_url.getPid(self)
		subattributes = {	'job': method_url.getStringParam(self, 'job'), 
							'company': method_url.getStringParam(self, 'company'), 
							'topic': method_url.getStringParam(self, 'topic')}		
		
		# Get attribute.
		attribute = None
		if attribute_id:
			attribute = method_question.getAttributeWithPid(attribute_id)
			if not attribute:
				return self.show404()
			subattributes[attribute.type] = attribute_id
					
		# get page cache key
		page_num = self.getPageIndex()
		sort = self.getCurrentSort()
		page_cache_key = self.getPageCacheKey(subattributes, sort)
		
		attributes = method_question.getAllAttributes()		
		first_page_of_set = method_url.getFirstPageOfSet(method_question.pages_per_set, page_num)
		last_page_of_set = method_url.getLastPageOfSet(method_question.pages_per_set, page_num)

		results = self.getQuestionKeys(subattributes, page_num)
		all_question_keys = results[0]
		has_more_sets = results[2]
		question_keys = self.pruneToPage(all_question_keys, page_num - first_page_of_set, method_question.per_page)

		rendered_questions_attempt = method_cache.getMultiObjects('question-rendered-', map(lambda x: str(x.id()), question_keys))
		
		rendered_questions = []
		for key in question_keys:
			if not(key is None):
				if key in rendered_questions_attempt and not(rendered_questions_attempt[key] is None):
					rendered = rendered_questions_attempt[key]
				else:
					rendered = method_question.renderQuestion(self, key.id(), None)
					rendered_questions.append(rendered)	
		
		if not has_more_sets:
			next_set = -1
		else:
			next_set = last_page_of_set + 1
		pages_in_set = int(math.ceil(len(all_question_keys) / method_question.per_page))
		last_page_of_set = min(last_page_of_set, first_page_of_set + pages_in_set)

		if last_page_of_set > page_num:
			next_page = page_num + 1
		else:
			next_page = -1
		
		page_calcs = method_url.doPageCalculations(has_more_sets, page_num, method_question.pages_per_set, method_question.per_page, len(all_question_keys))
		
		template_values = {
			'rendered_questions': rendered_questions,
			'page_calcs' : page_calcs,
			'url_root' : method_url.getUrlWithoutPage(self),			
			'attribute': attribute,
			'companies': attributes['company'],
			'topics': attributes['topic'],
			'jobs': attributes['job'],
			'subattribute_job': subattributes['job'],
			'subattribute_topic': subattributes['topic'],
			'subattribute_company': subattributes['company'],
			'current_sort': sort,
			'sorts': method_question.sorts,
			'parent_tab': 'interviews'
		}
		logging.info(template_values['url_root'])

		if attribute:
			self.pushPage(template_values, attribute.text + ' Interview Questions', 'html/page.html')
		else:
			self.pushPage(template_values, 'Interview Questions', 'html/page.html')