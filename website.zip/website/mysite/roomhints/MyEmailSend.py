#!/usr/bin/python

import sys
import os
import re

from smtplib import SMTP_SSL as SMTP       # this invokes the secure SMTP protocol (port 465, uses SSL)
#from smtplib import SMTP                  # use this for standard SMTP protocol   (port 25, no encryption)
from email.MIMEText import MIMEText

class MyEmailSend():

    # send_email()
    # destination is an array of recipients - only the first recipient is used
    def send_email(self,subject, content, sender, destination, smtpserver, USERNAME, PASSWORD):
        try:
            # typical values for text_subtype are plain, html, xml
            text_subtype = 'plain'
            msg = MIMEText(content, text_subtype)
            msg['Subject']=       subject
            msg['From']   = sender # some SMTP servers will do this automatically, not all
            msg['To'] = destination[0]
            # Setting a header could help us not get into an infinite
            # loop. But a better way is to not send a response to begin with
            msg['X-Epistoli-response'] = ''

            conn = SMTP(smtpserver, 465)
            conn.set_debuglevel(False)
            conn.login(USERNAME, PASSWORD)
            try:
                conn.sendmail(sender, destination, msg.as_string())
            finally:
                conn.close()
        except Exception, exc:
            sys.exit( "mail failed; %s" % str(exc) ) # give a error message
