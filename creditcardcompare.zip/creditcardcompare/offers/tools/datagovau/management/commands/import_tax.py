import os
from datetime import date
from django.core.management.base import BaseCommand
from offers.tools.datagovau.models import Location


class Command(BaseCommand):
    BATCH = 'personal tax'
    
    def handle(self, *args, **options):
        Location.objects.filter(batch=self.BATCH).delete()
        f = open(os.path.join(os.path.dirname(__file__), 'tax.csv'))
        headers = f.readline().split('|')
        counter = 0
        for l in f.readlines():
            line_data = l.split('|')
            for year, data in zip(headers[:-1], line_data[:-1]):
                print 'Processed %s locations.' % counter
                for postcode in line_data[-1].split(','):
                    counter += 1
                    try:
                        Location(date=date(int(year.split('-')[1]), 4, 1),
                                 address=postcode,
                                 data=data,
                                 batch=self.BATCH
                        ).save()
                    except ValueError, e:
                        if data != '':
                            raise e
        f.close()
        