import json as simplejson
from django.http import HttpResponse, Http404
from helpers import contact_message, send_ebook, signup_newsletter


def send_email(request):
    if request.method=='POST' and request.POST.get('email', None) and request.is_ajax():
        if request.POST.get('message'):
            contact_message(request)
        else:
            signup_newsletter(request)
        return HttpResponse(simplejson.dumps({'result': '<ul><li>Thanks for signing up.</li></ul>'}), content_type='text/plain')
    raise Http404
    
def get_ebook(request):
    if request.is_ajax() and request.GET.get('email',None):
        send_ebook(request)
        msg = '''<ul><li>Thank you. You\'ll get an email with the download
                    link. Check your spam box in case it ends up in there!
                    </li><li>&nbsp;</li></ul>
                  '''
        return HttpResponse(simplejson.dumps({'result': msg}), content_type='text/plain')

    from os.path import dirname, join
    fname = join(dirname(__file__), 'templates/lead/eBook Getting Out of Debt.pdf')
    r = HttpResponse(open(fname, 'rb').read(), content_type='appliction/pdf')
    name = 'eBook Getting Out of Debt'
    r['Content-Disposition'] = 'filename=%s.pdf' % name
    return r
