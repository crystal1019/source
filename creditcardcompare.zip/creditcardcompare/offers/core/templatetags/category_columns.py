from django import template
from django.conf import settings
from django.db.models import Q
from django.contrib.flatpages.models import FlatPage

from offers.core.models import Category

register = template.Library()
from offers.core.templatetags import varname_re

class CategoryColumnsNode(template.Node):
    def __init__(self, category):
        self.category = template.Variable(category)

    def render(self, context):
        try:
            category = self.category.resolve(context)

        except template.VariableDoesNotExist:
            pass

        else:
            def _get_default_columns(parent_category):
                for column in settings.CATEGORY_COLUMNS:
                    _filter = None
                    for kword in column[1]:
                        if _filter is None:
                            _filter = Q(name__icontains=kword)
                        else:
                            _filter |= Q(name__icontains=kword)
                    try:
                        category_column = parent_category.children.get(_filter, sites=settings.SITE_ID)
                    except parent_category.DoesNotExist:
                        pass
                    else:
                        context[column[0]] = dict(name=category_column.name, children=category_column.children.filter(sites=settings.SITE_ID))

            def _get_alternate_columns(parent_category):
                _get_default_columns(parent_category)
                try:
                    column2_categories = context[settings.CATEGORY_COLUMNS[1][0]]['children']
                except KeyError:
                    pass
                else:
                    # Include only subcategories that have products belonging to
                    # the current category.
                    categories = list()
                    cats_pk = list()
                    for cat in column2_categories:
                        for offer in cat.offer_set.filter(sites=settings.SITE_ID):
                            if not cat.pk in cats_pk:
                                categories.append(cat)
                                cats_pk.append(cat.pk)
                    context[settings.CATEGORY_COLUMNS[1][0]]['children'] = categories

            if category.parent is None:
                _get_default_columns(category)
            else:
                top_category = category.parent
                max_loops = 10
                use_alternate_columns = True
                while top_category.parent:
                    for kword in settings.CATEGORY_COLUMNS[1][1]:
                        if kword.lower() in top_category.name.lower():
                            use_alternate_columns = False
                    top_category = top_category.parent
                    max_loops -= 1
                    if max_loops < 0:
                        # Account for the possibility that someone might create
                        # a never-ending chain of categories.
                        break
                if use_alternate_columns:
                    _get_alternate_columns(top_category)
                else:
                    _get_default_columns(top_category)

        return ''

class IfInCategoryNode(template.Node):
    def __init__(self, nodelist, category, subcategory):
        self.nodelist = nodelist
        self.category = template.Variable(category)
        self.subcategory = template.Variable(subcategory)

    def render(self, context):
        try:
            category = self.category.resolve(context)
            subcategory = self.subcategory.resolve(context)
        except template.VariableDoesNotExist:
            pass
        else:
            in_category = False
            if subcategory.parent is not None:
                if category.pk != subcategory.pk:
                    parent = subcategory.parent
                    while parent:
                        if category.pk == parent.pk:
                            in_category = True
                            break
                        parent = parent.parent
                else:
                    in_category = True

            if in_category:
                return self.nodelist.render(context)

        return ''
    
class CategoryNode(template.Node):
    def __init__(self, slug, varname):
        self.slug = slug
        self.varname = varname

    def render(self, context):
        if self.slug[0] == self.slug[-1] and self.slug[0] in ('"', "'"):
            category_slug = self.slug[1:-1]
        else:
            category_slug = template.Variable(self.slug).resolve(context)
        try:
            context[self.varname] = Category.objects.get(slug=category_slug, sites=settings.SITE_ID)
        except Category.DoesNotExist:
            category_slug = category_slug.replace('-','-credit-card-').strip('/')
            context.dicts[1][self.varname] = Category.objects.get(slug=category_slug, sites=settings.SITE_ID)
        return ''

@register.tag(name='get_category')
def do_get_category(parser, token):
    try:
        tag_name, slug, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 argument' % token.split_contents()[0]
    return CategoryNode(slug, varname)

class GuideForCategoryNode(template.Node):
    def __init__(self, category, varname):
        self.category = template.Variable(category)
        self.varname = varname

    def render(self, context):
        try:
            category = self.category.resolve(context)
        except template.VariableDoesNotExist:
            context[self.varname] = []
            return ''

        cat_slug = category.slug
        guides = []
        while cat_slug:
            guides = FlatPage.objects.filter(sites=settings.SITE_ID, url__istartswith='/guides/%s/' % cat_slug).exclude(url__iexact='/guides/%s/' % cat_slug).order_by('-id')[:6]
            if guides.count():
                break
            else:
                cat_slug = '-'.join(cat_slug.split('-')[1:])

        context[self.varname] = guides
        return ''
@register.tag(name='category_columns')
def do_category_columns(parser, token):
    try:
        tag_name, category = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 1 argument' % token.split_contents()[0]
    return CategoryColumnsNode(category)

@register.tag(name='ifincategory')
def do_ifincategory(parser, token):
    try:
        tag_name, category, subcategory = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 argument' % token.split_contents()[0]
    else:
        nodelist = parser.parse(('endifincategory',))
        parser.delete_first_token()
        return IfInCategoryNode(nodelist, category, subcategory)

#tag used for broadbandcompare.com.au only
@register.tag(name='guides_for_category')
def do_guides_for_category(parser, token):
    try:
        tag_name, category, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 4 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    return GuideForCategoryNode(category, varname)