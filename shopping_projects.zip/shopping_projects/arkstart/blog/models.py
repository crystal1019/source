'''
@author: chaol
'''

from django.db import models
from tagging.fields import TagField
from tagging.models import Tag
from django.contrib.sites.models import Site
from django.conf import settings
from arkstart.BeautifulSoup import BeautifulSoup


class BlogCategory(models.Model):
    name = models.CharField(max_length=30)
    slug = models.SlugField(unique=True,null=True)
    image = models.ImageField(upload_to="images/",blank=True,null=True)
    priority = models.IntegerField(default=0, help_text="Used to control ordering of categories, higher numbers show higher in the list")
    is_active = models.BooleanField(default=False)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    sites = models.ManyToManyField(Site)
    
    def __unicode__(self):
        return self.name
    
    def getName(self):
        return self.__unicode__()

    def geturl(self):
        return '/blog/%s-archive1.html' % self.slug
        
    def getChildren(self):
        return self.categories_set.filter(is_active=True).order_by("-priority","name")
    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['-priority',]


class PublishStatus(models.Model):
    status = models.CharField(max_length=60, unique=True)
    display_to_user = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    def __unicode__(self):
        return self.status
    class Meta:
        verbose_name_plural = "Publish Status"

class CommentStatus(models.Model):
    status = models.CharField(max_length=60, unique=True)
    display_to_user = models.BooleanField(default=True)
    def __unicode__(self):
        return self.status
    class Meta:
        verbose_name_plural = "Comment Status"
        
class Author(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(unique=True)
    
    def __unicode__(self):
        return "%s -- %s" %(self.name, self.email)

class BlogPost(models.Model):
    title = models.CharField(max_length=40)
    slug = models.SlugField("Unique ID", help_text="This should be automatically generated", unique=True)
    category = models.ManyToManyField(BlogCategory)
    content = models.TextField()
    tags = TagField()
    priority = models.IntegerField(default=0)
    publishdate = models.DateTimeField()
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    status = models.ForeignKey(PublishStatus)
    viewed = models.IntegerField(default=0)
    author = models.ForeignKey(Author, null=True)
    top_image = models.ImageField(upload_to="images/", blank=True, null=True,help_text='the image shown in top stories. width:74px, height:71px;')
    homepage_image = models.ImageField(upload_to="images/", blank=True, null=True, help_text='the image shown next to title in featured post. width:274px, height:189px;')
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True, default='')
    membertype = models.ManyToManyField('userprofile.MemberType')
    sites = models.ManyToManyField(Site)
    
    def geturl(self):
        return "/blog/%s.html" % self.slug
    
    def get_absolute_url(self):
        return "/blog/%s.html" % self.slug
    
    def get_all_content(self):
        return "%s %s %s %s" %(self.title, ' '.join([x.name for x in self.category.all()]) , self.content, self.get_tags())
    

    def getCategory(self):
        try:
            return self.category.all()[:0].get()
        except:
            return ''
        
    def getCommentsCount(self):
        return self.getComments().count()
    def getComments(self):
        return self.comment_set.filter(sites__id=settings.SITE_ID,status__display_to_user=True).order_by("created")
    def get_previous_entry(self):
        try:
            return self.get_previous_by_publishdate(sites__id=settings.SITE_ID,status__display_to_user=True)
        except:
            return None
    def get_next_entry(self):
        try:
            return self.get_next_by_publishdate(sites__id=settings.SITE_ID,status__display_to_user=True)
        except:
            return None
        
    def get_content_image(self):
        try:
            soup = BeautifulSoup(self.content)
            image = soup.img['src']
            if '://' not in image:
                return 'http://www.arkstart.com.au%s' %image
            else:
                return image
        except:
            return ''

    def get_tags(self):
        return Tag.objects.get_for_object(self)

    def __unicode__(self):
        return self.title

class Comment(models.Model):
    post = models.ForeignKey(BlogPost)
    name = models.CharField(max_length=50)
    email = models.EmailField()
    website = models.URLField(blank=True, null=True)
    comment = models.TextField()#max_length=600 no such thing for textareas...
    created = models.DateTimeField("Date Posted", auto_now_add=True)
    status = models.ForeignKey(CommentStatus)
    sites = models.ManyToManyField(Site)
    
    def __unicode__(self):
        return "Comment by "+self.name+" on "+self.post.title