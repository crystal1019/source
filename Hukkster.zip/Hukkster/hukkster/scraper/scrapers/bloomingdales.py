#coding=utf-8
import logging
import re
import cgi
import urllib
import lxml.html
import demjson
from urlparse import urlparse
from urlparse import urlunparse
from urlparse import urljoin
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class ParseFailedError(Exception):
    pass


IMAGE_URL_PREFIX = "http://images.bloomingdales.com/is/image/BLM/products/"
IMAGE_PARAMS = "?wid=550&qlt=90,0&layer=comp&op_sharpen=0&resMode=sharp2&op_usm=0.7,1.0,0.5,0&fmt=jpeg"


class BloomingDalesScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'bloomingdales.com'

    def detect_encoding(self, html_content):
        from bs4 import UnicodeDammit
        ud = UnicodeDammit(html_content, is_html=True)
        return ud.original_encoding

    def clean_string2(self, val):
        try:
            val = self.clean_string(val)
            return val.replace(u'\xa0', ' ')
        except AttributeError:
            return val

    def _extract_float(self, root, xpath_expr, text_pattern, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(root, xpath_expr, is_expected_to_be_found)
        if node is not None:
            float_text = self.clean_string(node.text_content())
            m = re.search(text_pattern, float_text.encode("utf8"))
            if m:
                float_text = m.group(1).replace(",", "")
                float_value = float(float_text)
                return float_value
            else:
                if is_expected_to_be_found:
                    logging.debug("Error: Found no float value using %r" % xpath_expr)
                    raise ParseFailedError()
                else:
                    return 0
        else:
            return 0

    def _expect_and_extract_single_node(self, root, xpath_expr, is_expected_to_be_found=True):
        nodes = root.xpath(xpath_expr)
        if len(nodes) == 0:
            if is_expected_to_be_found:
                logging.debug("Error: Unabled to find a node with xpath expression: %r" % xpath_expr)
                raise ParseFailedError()
            else:
                return None
        else:
            if len(nodes) > 1:
                logging.debug("Error: Found more than one node using %r" % xpath_expr)
            return nodes[0]

    def _expect_and_extract_single_node_text_content(self, root, xpath_expr, is_expected_to_be_found=True):
        node = self._expect_and_extract_single_node(root, xpath_expr, is_expected_to_be_found=is_expected_to_be_found)
        # _expect_and_extract_single_node has already handled the unexpected node not found case.
        if node is not None:
            return node.text_content()
        else:
            return ""

    def _extract_attr_value(self, root, xpath_expr):
        return self._expect_and_extract_single_node(root, xpath_expr)

    def _extract_value_using_regex(self, pattern, text, failure_msg=""):
        m = re.search(pattern ,text)
        if m:
            return m.group(1)
        else:
            logging.debug("Error: Failed to extract value using pattern '%s'. %s" % (pattern, failure_msg))
            raise ParseFailedError()

    def parse_item_infos_from_js(self):
        item_texts = [m.group(0) for m in re.finditer(r'{\s+"upcID"\:[^}]+}', self.html)]
        item_infos = []
        for item_text in item_texts:
            sold_out = self._extract_value_using_regex(r'isAvailable"\:\s+"([^"]+)', item_text) <> "true"
            if not sold_out:
                size = self._extract_value_using_regex(r'size"\:\s+"([^"]*)"', item_text)
                selections = {"color": self._extract_value_using_regex(r'color"\:\s+"([^"]*)"', item_text)}
                if len(size) > 0:
                    selections["size"] = size
                item_infos.append({"selections": selections})
        return item_infos

    def _extract_js_dict(self, var_name):
        pattern = var_name + r"\s*=\s*(\{[^\;]+\})\;"
        json_text = self._extract_value_using_regex(pattern, self.html)
        if json_text is None:
            return None
        return demjson.decode(json_text)

    def _extract_image_dict(self, root, local_id):
        var_name = r"BLOOMIES\.pdp\.primaryImages\[%s\]" % local_id
        image_dict = self._extract_js_dict(var_name)
        return dict([(color, urljoin(IMAGE_URL_PREFIX, image_path) + IMAGE_PARAMS) 
                    for color, image_path in image_dict.items()])

    def _extract_prices(self, root):
        priceBig = self._expect_and_extract_single_node_text_content(root, 
            "//div[@id='PriceDisplay']//span[@class='priceBig']", is_expected_to_be_found=True)
        priceBig = float(self._extract_value_using_regex(r"([\d\.\,]+)", priceBig))
        priceSale = self._expect_and_extract_single_node_text_content(root, 
            "//div[@id='PriceDisplay']//span[@class='priceSale']", is_expected_to_be_found=False)
        if priceSale:
            priceSale = float(self._extract_value_using_regex(r"([\d\.\,]+)", 
                    priceSale, failure_msg="Failed to extract from priceSale: %s" % priceSale))
        else:
            priceSale = None
        if priceSale is not None:
            return {"original_price": {"value": priceBig}, "current_price": {"value":priceSale}}
        else:
            return {"original_price": {"value": priceBig}, "current_price": {"value":priceBig}}

    def _extract_local_id(self, url):
        parsed_qs = cgi.parse_qs(urlparse(url).query)
        if parsed_qs.has_key("ID"):
            return parsed_qs["ID"][0]
        else:
            logging.debug("Failed to extract local_id from URL: %s" % url)
            raise ParseFailedError()

    def parse_member_product_case(self, root, raw_data):
        from ..helpers import select_scraper
        products = []
        for member_product_href in root.xpath("//div[@id='memberProductList']//div[@class='memberShortDesc']//a/@href"):
            member_product_url = urljoin(self.url, member_product_href)
            member_product_scraper = select_scraper(member_product_url)
            products += member_product_scraper.parse()
        return products
    
    def parse_products(self, root, raw_data):
        chooseItemsNode = self._expect_and_extract_single_node(root, "//div[@id='pdp_chooseItems']", 
                is_expected_to_be_found=False)
        if chooseItemsNode is not None:
            return self.parse_member_product_case(root, raw_data)

        if not raw_data.has_key("url"):
            logging.debug("Error: Failed to extract url from Open Graph Data")
            raise ParseFailedError()
        local_id = self._extract_local_id(raw_data["url"])
        title = self._expect_and_extract_single_node_text_content(root, "//h1[@id='productTitle']")
        image_dict = self._extract_image_dict(root, local_id)
        item_infos = self.parse_item_infos_from_js()
        for item_info in item_infos:
            item_info["local_id"] = local_id
            item_info["title"] = title
            item_info["url"] = raw_data["url"]
            item_info["store"] = "bloomingdales"
            color = item_info["selections"]["color"]
            item_info["image"] = image_dict[color]
            item_info["promos"] = []
            item_info.update(self._extract_prices(root))
        return item_infos

    def parse(self):
        raw_data = self.parse_opengraph()

        # Parsing the HTML
        logging.debug('Parsing HTML data')
        encoding = self.detect_encoding(self.html)
        root = lxml.html.fromstring(unicode(self.html, encoding))
        logging.debug('Finished parsing HTML data')

        try:
            products = self.parse_products(root, raw_data)
        except ParseFailedError:
            products = None

        # Giving up, it doesn't look as a product
        if products is None or not len(products):
            raise HukksterTooManyOptions(BloomingDalesScraper.get_domain(), self.url)

        return products
