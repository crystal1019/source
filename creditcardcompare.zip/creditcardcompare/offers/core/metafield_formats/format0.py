import re
from django.conf import settings
from offers.core.metafield_formats import FormatBase


NONE_VALUES = ('', '-', 'None', '%', '-%')
NONE_FEES = ('', '-', '0', '0%', 'None')


class Format(FormatBase):
    def annual_fee(self):
        value = self.get_value(self.meta.key).replace('p.a.', '').strip()
        second_annual = self.get_value('Annual Fee 2nd Year').replace('p.a.', '').strip()
        second_annual_q = self.get_value('Annual Fee (Qualifying Customers)').replace('p.a.', '').strip()
        if self.is_mobile:
            if second_annual not in NONE_VALUES:
                return (value + '<span>&nbsp;p.a.</span>', '<h4><span>1st year then %s</span></h4>' % second_annual)
            elif second_annual_q not in NONE_VALUES:
                tooltip = 'for qualifying customers'
                if value.strip() == second_annual_q.strip():
                    return ('%s<sup title="%s">*</sup>' % (second_annual_q, tooltip), '')
                else:
                    return ('%sor&nbsp;%s<sup title="%s">*</sup>' % (value, second_annual_q, tooltip), '')
            elif value not in NONE_VALUES:
                return (value + '<span>&nbsp;p.a.<br/>ongoing</span>', '')
            return ('-', '')
        if second_annual not in NONE_VALUES:
            return (value, '<br /><span class="fsprebig fn1bold">1st</span> year<br/>then %s' % second_annual)
        elif second_annual_q not in NONE_VALUES:
            tooltip = 'for qualifying customers'
            if value.strip() == second_annual_q.strip():
                return ('%s<sup title="%s">*</sup>' % (second_annual_q, tooltip), '<br />ongoing')
            else:
                return ('%sor&nbsp;%s<sup title="%s">*</sup>' % (value, second_annual_q, tooltip), '<br />ongoing')
        elif value not in NONE_VALUES:
            return (value, '<br />ongoing')
        return ('-', '')
    
    def balance_transfer_rate(self):
        rate = self.get_value(self.meta.key).replace('p.a.', '').strip()
        if rate in NONE_VALUES:
            return ('-', '')
        period = self.get_value('Balance Transfer Period', 'bare_value_or_default')
        if period in NONE_VALUES:
                return ('%s<br/><span>ongoing</span>' % rate, '')
        try:
            fallback_rate = self.get_value(self.meta.offer.bt_fallback.key).replace('p.a.', '').strip()
        except AttributeError:
            comment = self.m(' months<br/><span class="fsprebig fn1bold">%s</span>p.a.', '<h4>%s<span>&nbsp;p.a.</span></h4>') % rate
        else:
            comment = self.m(' months<br /><span class="fsprebig fn1bold">%s</span>p.a.<br />then %s', '<h4>%s<span>&nbsp;p.a.<br />then %s</span></h4>') % (rate, fallback_rate)
        fee = self.get_value('Balance Transfer Fee')
        if fee not in NONE_FEES:
            comment = self.m(comment + '<br />with a %s fee' % fee, comment.replace('</h4>', '<br /><span>with a %s fee</span></h4>' % fee))
        return (period + self.m('', '<span> months</span>'), comment)
    
    def _get_reward(self, value):
        try:
            v1, v2 = value.split('per')
        except ValueError:
            return ('', '$%s' % value)
        noncap = ('-', 'Unlimited', 'unlimited')
        if self.get_value('Points Cap Per Month (AmEx)') not in noncap or self.get_value('Points Cap Per Month (MC/VISA)') not in noncap:
            v2 = v2.replace('spent', 'spent capped')
        return (v1, self.m('<br />per %s', 'per %s') % v2)
    
    def _get_points(self, key=None):
        key = key or self.meta.key
        amex = self.get_value(key, 'bare_value_or_default')
        if amex not in NONE_VALUES:
            return self._get_reward(amex)
        mcvisa = self.get_value(key.replace(' (AmEx)', ' (MC/VISA)'), 'bare_value_or_default')
        if mcvisa not in NONE_VALUES:
            return self._get_reward(mcvisa)
        return ('-', '')
    
    def frequent_flyer_points_amex(self, key=None):
        return self._get_points(key)
    
    def frequent_flyer_points_mcvisa(self):
        return self._get_points(self.meta.key.replace(' (MC/VISA)', ' (AmEx)'))
    
    def purchase_rate(self):
        rate = self.get_value(self.meta.key).replace('p.a.', '').strip()
        intro_rate = self.get_value('Intro Purchase Rate').replace('p.a.', '').strip()
        intro_expiry = self.get_value('Intro Purchase Rate', 'expiry')
        period = self.get_value('Intro Purchase Period', 'bare_value_or_default')
        if self.is_mobile:
            if intro_rate not in NONE_VALUES and period not in NONE_VALUES:
                comment = '<h4>%s<span>&nbsp;p.a.<br/>then %s</span><h4>' % (intro_rate, rate)
                return (period + '<span> months</span>', comment)
            elif intro_rate not in NONE_VALUES and intro_expiry not in NONE_VALUES:
                comment = '<h4><span>%s %s then %s</span><h4>' % (intro_expiry.day, intro_expiry.strftime('%B %Y'), rate)
                return (intro_rate + '<span>&nbsp;p.a. until</span>', comment)
            elif rate not in NONE_VALUES:
                return (rate + '<span>&nbsp;p.a.<br/>ongoing</span>', '')
            return ('-', '')
        if intro_rate not in NONE_VALUES and period not in NONE_VALUES:
            comment = ' months <br /><span class="fsprebig fn1bold">%s</span> p.a.<br/>then %s' % (intro_rate, rate)
            return (period, comment)
        elif intro_rate not in NONE_VALUES and intro_expiry not in NONE_VALUES:
            comment = ' p.a. <br />until %s %s<br/>then %s' % (intro_expiry.day, intro_expiry.strftime('%B %Y'), rate)
            return (intro_rate, comment)
        elif rate not in NONE_VALUES:
            return (rate, ' p.a. <br />ongoing')
        return ('-', '')
    
    def reward_points_amex(self, key=None):
        value = self._get_points()
        if value != ('-', ''):
            return value
        return self._get_points('Frequent Flyer Points (AmEx)')
    
    def reward_points_mcvisa(self):
        return self.reward_points_amex(self.meta.key.replace(' (MC/VISA)', ' (AmEx)'))
        
    def rewards_program(self):
        meta = self.get_value(self.meta.key, None)
        if meta.value_or_default not in NONE_VALUES:
            if meta.logo:
                return ('<img src="%s%s" height="25" width="75" alt="%s"/><br />' % (settings.MEDIA_URL, meta.logo, meta.value_or_default.strip()), meta.value_or_default)
            return ('', meta.value_or_default)
        return ('-', '')
    
    def first_purchase_bonus(self):
        result = self.sign_up_bonus()
        if result[1]:
            result[1] += '<br />after 1st purchase'
        return result
    
    def sign_up_bonus(self):
        value = self.get_value(self.meta.key)
        if value in ('-', self.meta.meta_field.suffix):
            return ('-', '')
        try:
            points = re.match('^([\d,]+) .*', value).groups(0)[0]
        except AttributeError:
            return ['', value]
        return [points, self.m('<br />%s', '%s') % value.replace(points, '')]
