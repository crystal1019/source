import masterpage
import method_url

class ThankYou(masterpage.MasterPage):   
    def get(self):
		transaction_id = method_url.getStringParam(self, "txn_id")
		first_name = method_url.getStringParam(self, "first_name")
		if not first_name:
			first_name = ''
		last_name = method_url.getStringParam(self, "last_name")
		if not last_name:
			last_name = ''
		self.pushPage({
			'parent_tab': 'resources', 
			'transaction_id' : transaction_id,
			'first_name' : first_name,
			'last_name' : last_name,
			}, 'Thank you for your purchase!', 'html/thankyou.html')   
