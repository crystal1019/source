[galleria][]
========

Open source software to run galleries and artists web sites.  This project is designed to setout an open source software for running Art gallerys, commissioning art galleries and artist marketing sites.

It will have a number of modules to cover the normal operations:

- Contact management
- Commissioning artist management
- stock management
- website building
- artist portfolio management

For more information see the linked website [galleria][].  This has information on the current status and how to contribute.

[galleria]: https://github.com/drummonds/galleria/wiki



