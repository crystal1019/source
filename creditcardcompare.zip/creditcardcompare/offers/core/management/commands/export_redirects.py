from django.conf import settings
from django.contrib.redirects.models import Redirect
from django.core.management.base import NoArgsCommand

class Command(NoArgsCommand):
    help = 'Export redirects to Apache mod_rewrite rules.'

    def handle_noargs(self, **options):
        verbosity = int(options.get('verbosity', 1))
        rewrite_rules = list()
        for redirect in Redirect.objects.filter(site=settings.SITE_ID):
            prev_new_path = redirect.new_path
            if redirect.new_path.startswith('/'):
                new_path = 'http://www.moneychoices.com.au' + redirect.new_path
                rewrite_rules.append((redirect.old_path, new_path))
            elif 'moneycompare.com.au' in redirect.new_path:
                new_path = redirect.new_path.replace('moneycompare.com.au', 'moneychoices.com.au')
                rewrite_rules.append((redirect.old_path, new_path))
            elif 'moneychoices.com.au' in redirect.new_path:
                rewrite_rules.append((redirect.old_path, redirect.new_path))
        rewrite_conds = list()
        for rule in rewrite_rules:
            rewrite_conds.append('RewriteCond %%{REQUEST_URI} =%s' % rule[0].replace('$', '\\$'))
            rewrite_conds.append('RewriteRule (.*) %s [L,R=301]' % rule[1])
        print 'RewriteEngine on'
        print ' \n'.join(rewrite_conds)
        print 'RewriteCond %{REQUEST_URI} !^/admin/.*$'
        print 'RewriteRule (.*) http://www.moneychoices.com.au$1 [L,R=301]'
