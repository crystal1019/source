from google.appengine.ext.webapp import template
import os

import masterpage
import objects

import method_question
import method_cache
		
class SiteMap(masterpage.MasterPage):  

	def getQuestions(self):
		# Get questions.
		return method_question.getRecentQuestions()
		
	def getAttributes(self):
		return method_question.getAllAttributes()
	
	def addAttributesToList(self, sites, attributes):
		important = ['microsoft-interview-questions', 'google-interview-questions', 'amazon-interview-questions', 'bloomberg-lp-interview-questions', 'facebook-interview-questions', 'yahoo-interview-questions']
		for a in attributes:
			if a.uid in important:
				priority = 1
			else:
				priority = .75
			site = {'loc': 'http://www.careercup.com/page?pid=' + str(a.pretty_id),
					'priority': priority}
			sites.append(site)
		
	def get(self):
		sitemap = method_cache.getObjectForTypeAndKey('sitemap', None)
		if not sitemap:
			attributes = objects.Attribute.query()
			sites = []
			self.addAttributesToList(sites, attributes)
		
			template_values = {
				'sites': sites,
			}
			path = os.path.join(os.path.dirname(__file__), 'html/sitemap.xml')
			sitemap = template.render(path, template_values) 
			method_cache.setObjectForTypeAndKey('sitemap', None, sitemap, 3600)
		self.response.out.write(sitemap)