from google.appengine.api import users

import objects
import masterpage

import method_db
import method_user
import method_question
import method_cache
import method_forum
	
class EditUser(masterpage.MasterPage):		 
		
	# Inserts attribute into database
	def addAttribute(self, attribute_value, attribute_type):
		if len(attribute_value) == 0:
			return 0
		uid = method_question.getExistingAttribute(attribute_value, attribute_type)
		if uid > 0:
			return uid
		
		attribute = objects.Attribute()
		attribute.type = attribute_type
		attribute.text = attribute_value
		return method_db.putObject(attribute)	   
		
	def mergeSelectedAttributes(self, dropdown_id, textbox_id, type):
		new_attribute = self.request.get(textbox_id).strip()
		current_attributes = self.request.get_all(dropdown_id)
		attributes = []

		for attribute in current_attributes:
			int_attribute = attribute
			if int_attribute == '': # id is 0 -> "new" was selected
				if new_attribute:
					pretty_id = method_question.addAttribute(new_attribute, type)
					if pretty_id != '':
						attributes.append(pretty_id)
			else:
				attributes.append(int_attribute)
		#return attributes
		if len(attributes) == 0:
			return None
		pretty_id = attributes[0]
		return method_question.getAttributeWithPid(pretty_id)			
		
	def post(self):			   
		# Get user.
		user = method_user.getLoggedInUser()
		
		if not(user):
			return
		
		labels = []
		urls = []
		
		if user.company_id:
			original_company_id = user.company_id_pretty
		else:
			original_company_id = None
			
		if user.job_id:
			original_job_id = user.job_id_pretty
		else:
			original_job_id = None
		
		company = self.mergeSelectedAttributes('dropdownCompanies[]', 'OtherCompany', 'company')
		job_title = self.mergeSelectedAttributes('dropdownJobTitles[]', 'OtherJobTitle', 'job')

		if company:
			user.company_id_pretty = company.pretty_id
			user.company_name = company.text
		else:
			user.company_id_pretty = None
			user.company_name = None
		
		if job_title:
			user.job_id_pretty = job_title.pretty_id
			user.job_name = job_title.text
		else:
			user.job_name = None
			user.job_id_pretty = None
		
		user.please_contact = self.setValueFromCheckbox('pleaseContact')
		user.email_on_message = self.setValueFromCheckbox('emailOnMessage')
		user.email_on_new_question = self.setValueFromCheckbox('emailOnQuestion')
		
		for i in range(0, 4):
			label = self.request.get('label' + str(i))
			link = self.request.get('url' + str(i))
			if not(label) or label == '':
				label = link
			if link and link != '':
				labels.append(str(label))
				urls.append(str(link))
			#self.response.out.write(self.request.get('url' + str(i)))			  
			#return

		name = self.request.get('name')
		if not(name) or name == '':
			name = user.user.nickname()
		user.name = name
		user.link_urls = urls
		user.link_labels = labels
		user.blurb = self.request.get('AboutMe')
		user.resume_text = self.request.get('Resume')
		user.image = self.request.get('avatar')
		method_db.putObject(user)
		
		page_cache_key = 'user'
		method_cache.clearObjectForTypeAndId(page_cache_key, str(user.uid))		
			
		questions = objects.Question.query(objects.Question.author_id == user.uid)
		self.updateAuthorInfoForList(questions, user, 'question')
		comments = objects.Comment.query(objects.Comment.author_id == user.uid)
		self.updateAuthorInfoForList(comments, user, 'comment') 
		forums = objects.ForumPost.query(objects.ForumPost.author_id == user.uid)
		self.updateAuthorInfoForList(forums, user, 'forum')  		
		salaries = objects.SalaryInfo.query(objects.SalaryInfo.author_id == user.uid)
		self.updateAuthorInfoForList(salaries, user, 'salaries') 
		
		self.displayError('Profile Updated', 'Thank you!  Your profile has been updated.')
		
	def updateAuthorInfoForList(self, list, user, type):
		for item in list:
			item.author_name = user.name
			item.author_image = user.image
			item.put()		  
			if type == 'question':
				method_question.clearQuestionCache(item, False)
			elif type == 'comment':
				method_cache.clearObjectForTypeAndId(type, item.uid)
			elif type == 'salaries':
				method_cache.clearObjectForTypeAndId(type, None)				
			elif type == 'forum':
				method_forum.clearCache(item)
		
		
	def putErrorMessage(self, error_message):		
		self.request.get('lblError')
		error_message		  
		#self.response.out.write('<script>control = document.getElementById("lblError"); control.value = error_message; </script>')
	
		#path = os.path.join(os.path.dirname(__file__), 'html/addquestion.html')
		#self.response.out.write(template.render(path, template_values)) 
			
	def convertString(self, s):
		if not(s):
			return ''
		return s
		
	def selectAttributes(self, all_attributes, selected_attribute):
		list = []
		for attribute in all_attributes:
			if selected_attribute and attribute.pretty_id == selected_attribute:
				attribute.selected = True
			else:
				attribute.selected = False
			list.append(attribute)
		return list 
			
	
	def get(self):
		template_values = {
			'please_contact': None,
			'error_message': ''
		}
			
		# Get user.
		user = method_user.getLoggedInUser()
		
		if not(user):
			self.redirectToLogin()
			return
		
		jobs = method_question.getAttributesByTypeSorted('job', 'alpha')
		companies = method_question.getAttributesByTypeSorted('company', 'alpha') 
		
		jobs = self.selectAttributes(jobs, user.job_id_pretty)
		companies = self.selectAttributes(companies, user.company_id_pretty)		 
			 
		template_values['about_me'] = self.convertString(user.blurb)
		template_values['resume'] = self.convertString(user.resume_text)
		template_values['jobs'] = jobs
		template_values['companies'] = companies
		template_values['name'] = user.name
	   
		avatar = user.image
		if avatar:
			template_values['avatar'] = avatar
			
		template_values['please_contact'] = user.please_contact
		template_values['email_on_message'] = user.email_on_message		 
		template_values['email_on_new_question'] = user.email_on_new_question
		
		labels = user.link_labels 
		urls = user.link_urls	
	   
		
		for i in range(0, 4):
			if len(labels) > i:
				template_values['label' + str(i)] = self.convertString(labels[i])
			else:
				template_values['label' + str(i)] = ''			 
			if len(urls) > i:
				template_values['url' + str(i)] = self.convertString(urls[i])				 
			else:
				template_values['url' + str(i)] = ''		 
		
		self.pushPage(template_values, 'Edit User', 'html/edituser.html')	
		
