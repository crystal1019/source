from threading import Thread


def add_months(date, months):
    month = date.month + months - 1
    year = date.year + (month / 12)
    month = (month % 12) + 1
    day = date.day
    while (day > 0):
        try:
            new_date = date.replace(year=year, month=month, day=day)
            break
        except:
            day = day - 1    
    return new_date


class GenericThread(Thread):
    def __init__(self, func_obj, *args, **kwargs):
        super(GenericThread, self).__init__()
        self.func_obj = func_obj
        self.args = args
        self.kwargs = kwargs
        
    def run(self):
        self.func_obj(*self.args, **self.kwargs)
