from dbindexer import autodiscover
import search
autodiscover()
search.autodiscover()
