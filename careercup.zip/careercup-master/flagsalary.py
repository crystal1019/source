import masterpage

import method_db
import method_email
import method_salary
import method_url
import method_user
	
class FlagSalary(masterpage.MasterPage):	
	def post(self):		
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return

		id = method_url.getId(self)
		salary = method_salary.getSalaryWithId(id)		
			
		# Add user to salary
		users = salary.flag_users
		if users == None:
			users = []
		elif user.uid in users: # User has already flagged the salary
			return
		users.append(user.uid)			
		salary.flag_users = users
		
		# Add reason to salary
		reason = self.request.get('flagReason')
		reasons = salary.flag_reasons
		if reasons == None:
			reasons = []
		reasons.append(reason)
		salary.flag_reasons = reasons		

		# Delete salary if necessary
		salary.flag_count = salary.flag_count + 1
		if salary.flag_count >= method_salary.flag_limit or method_user.userIsAdmin():
			method_salary.deleteSalary(salary)
		salary.under_review = True
		method_db.putObject(salary)
		
		method_salary.clearFlaggedSalaryCountCache()
		method_email.sendMeEmail('', 'Flagged Salary Reported', 'Flagged Salary Reported') 	
		self.displayError('Thank You!', 'Thank you!  This flag will be looked at shortly by a moderator. <br/><br/> Wanna be a moderator?  Email gayle@careercup.com.')		
 
	def get(self):		  
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return	
		id = method_url.getId(self)
		salary = method_salary.getSalaryWithId(id, True)
		if user.uid in salary.flag_users:
			already_flagged = True
		else:
			already_flagged = False
		
		template_values = {'salary_id': id, 'parent_tab': 'interviews', 'already_flagged' : already_flagged}
		self.pushPage(template_values, 'Flag Salary', 'html/flagsalary.html')   
		
