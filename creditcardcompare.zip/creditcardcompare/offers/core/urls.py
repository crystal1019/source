from django.conf import settings
from django.conf.urls import patterns, url
from django.views.generic import TemplateView
from views import OfferOutboundRedirect, CategoryList
from sitemaps import CategorySitemap

sitemaps = {
    'category': CategorySitemap,
}

urlpatterns = patterns('offers.core.views',
    url(r'^find/$', TemplateView.as_view(template_name= 'offers/filter_offer_list.html')),
    url(r'^search/$', 'offer_search_list'),
    url(r'^other\.php$', CategoryList.as_view()),
    url(r'^apply/(?P<is_exclusive>exclusive/)?(?P<issuer_slug>[A-Za-z0-9\-])+/(?P<offer_id>\d+)$', OfferOutboundRedirect.as_view()),
    url(r'^tools/compare-cards/(?P<category_slug>[A-Za-z0-9\-]+)/$', 'compare_cards', name="compare-cards"),
    url(r'^tools/compare-offers/(?P<category_slug>[A-Za-z0-9\-]+)/$', 'compare_cards', name="compare-offers"),
)
# temporary pages
urlpatterns += patterns('offers.core.views',
    url(r'^content/(?P<category_slug>[A-Za-z0-9\-]+)\.php$', 'offer_list_for_category', {'template': 'offers/category_content.html', 'limit': 5}, name='category-page-content'),
    url(r'^sleek/other\.php$', CategoryList.as_view(template_name='offers/categories_sleek.html')),
    url(r'^sleek/(?P<category_slug>[A-Za-z0-9\-]+)/(?P<offer_slug>[A-Za-z0-9\-]+)\.php$', 'offer_details', {'template': 'offers/offer_sleek.html'}),
    url(r'^sleek/(?P<category_slug>[A-Za-z0-9\-]+)\.php$', 'offer_list_for_category', {'template': ('offers/category_sleek.html', 'offers/category.html')}, name='category-page-sleek'),
    url(r'^sleek/$', 'offer_list_for_category', {'category_slug': settings.HOMEPAGE_CATEGORY.get(settings.SITE_NAME, ''), 'template': ('offers/index_sleek.html', 'offers/index.html')}, name="home"),
    url(r'^compact/other\.php$', CategoryList.as_view(template_name='offers/categories_compact.html')),
    url(r'^compact/(?P<category_slug>[A-Za-z0-9\-]+)/(?P<offer_slug>[A-Za-z0-9\-]+)\.php$', 'offer_details', {'template': 'offers/offer_compact.html'}),
    url(r'^compact/(?P<category_slug>[A-Za-z0-9\-]+)\.php$', 'offer_list_for_category', {'template': ('offers/category_compact.html', 'offers/category.html')}, name='category-page-compact'),
    url(r'^compact/$', 'offer_list_for_category', {'category_slug': settings.HOMEPAGE_CATEGORY.get(settings.SITE_NAME, ''), 'template': ('offers/index_compact.html', 'offers/index.html')}, name="home"),
)
#  offer and category pages
urlpatterns += patterns('offers.core.views',
    url(r'^bare/(?P<category_slug>[A-Za-z0-9\-]+)/$', 'offer_list_bare'),
    url(r'^bare/(?P<category_slug>[A-Za-z0-9\-]+)/(?P<offer_slug>[A-Za-z0-9\-]+)\.php$', 'offer_details'),
    url(r'^(?P<category_slug>[A-Za-z0-9\-]+)/(?P<offer_slug>[A-Za-z0-9\-]+)/$', 'offer_details'),
    url(r'^(?P<category_slug>[A-Za-z0-9\-]+)/(?P<offer_slug>[A-Za-z0-9\-]+)\.php$', 'offer_details'),
    url(r'^(?P<category_slug>[A-Za-z0-9\-]+)/$', 'offer_list_for_category'),
    url(r'^(?P<category_slug>[A-Za-z0-9\-]+)\.php$', 'offer_list_for_category', name='category-page'),
)
# homepage
urlpatterns += patterns('offers.core.views',
    url(r'^$', 'offer_list_for_category', {'category_slug': settings.HOMEPAGE_CATEGORY.get(settings.SITE_NAME, ''), 'template': 'offers/index.html'}, name="home"),
)
