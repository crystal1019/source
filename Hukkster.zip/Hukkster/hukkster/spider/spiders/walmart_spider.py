import logging
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from ...core.models import Shop
from ..items import CategoryItem, Product


logger = logging.getLogger('spider')


class WalmartSpider(CrawlSpider):
    name = 'walmart'
    domain = 'walmart.com'
    allowed_domains = ['www.walmart.com',]
    start_urls = [
        'http://www.walmart.com/cp/All-Departments/121828',
    ]

    rules = (
        Rule(SgmlLinkExtractor(allow=('cp\/All-Departments', )), callback='parse_categories'),  # Continue following all URLs
    )

    def __init__(self, *args, **kwargs):
        self.shop, created = Shop.objects.get_or_create(domain=self.domain)
        if created:
            logger.info('Created a new shop: %s', self.shop)
        super(WalmartSpider, self).__init__(*args, **kwargs)

    def parse_categories(self, response):
        hxs = HtmlXPathSelector(response)

        categories = set()
        for cat in hxs.select('//a[@class="NavXLBold"]/text()'):
            category = CategoryItem()
            category['shop'] = self.shop
            category['name'] = cat.extract().strip()
            categories.add(category)
        return categories
