from django.conf.urls.defaults import patterns, include, url

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()
from django.conf import settings

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'berowrawatersinn.views.home', name='home'),
    # url(r'^berowrawatersinn/', include('berowrawatersinn.foo.urls')),
    url(r'^kitchen/', include('berowrawatersinn.kitchen.urls')),
    url(r'^location/', include('berowrawatersinn.location.urls')),
    url(r'^restaurant/', include('berowrawatersinn.restaurant.urls')),
    url(r'^booking.html$', 'berowrawatersinn.reservation.views.booking'),
    url(r'^get_time.json', 'berowrawatersinn.reservation.views.get_time'),
    url(r'^get_arrive_info.json','berowrawatersinn.reservation.views.get_arrive_info'),
    url(r'^media/(?P<path>.*)$','django.views.static.serve', {'document_root':settings.MEDIA_ROOT}),
    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),
    url('^grappelli', include('grappelli.urls')),
    url('^admin/filebrowser/', include('filebrowser.urls')),
    # Uncomment the next line to enable the admin:
    url(r'^admin/reservation/booking/calendar/$', 'berowrawatersinn.admin_views.calendar_show'),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^', include('berowrawatersinn.website.urls')),
)
