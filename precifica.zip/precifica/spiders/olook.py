# -*- coding: utf-8 -*-

from operator import itemgetter, not_
from urlparse import urljoin
from functools import partial

from scrapy import Request
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors import LinkExtractor
from scrapy.contrib.loader.processor import Identity, MapCompose, TakeFirst

from ..items import PrecificaItemLoader as ItemLoader, ProductItem
from . import ExtraURLsSitemapSpider, PrecificaSpider


class OlookSpider(PrecificaSpider, ExtraURLsSitemapSpider, CrawlSpider):
    name = "olook"
    site = "Olook"
    compat_domain = "www.olook.com.br"
    aloowed_domains = ['www.olook.com.br']
    start_urls = ['http://www.olook.com.br']
    sitemap_urls = ['http://www.olook.com.br/robots.txt']

    rules = (
        Rule(LinkExtractor(restrict_xpaths=['//a[@class="sub_menu"]'])),
        Rule(LinkExtractor(restrict_xpaths=['//*[@class="menu-group clearfix"]'
                                            '/*[@class="menu sub-menu'
                                            ' container"]//a'])),
        Rule(LinkExtractor(allow=[r'\?page=\d+'],
                           restrict_xpaths=['//*[@class="pagination"]//a'])),
        Rule(LinkExtractor(restrict_xpaths=['//*[@class="product_link"]']),
             callback='parse_product'),
    )

    def parse_product(self, response):
        item = ItemLoader(ProductItem(), response=response)
        item.default_output_processor = TakeFirst()

        item.add_css('categories', 'ul.breadcrumb li a::text',
                     itemgetter(slice(1, None)))
        item.add_css('categories', 'script', re=r"'Subcategory':\s*'([^']+)'")
        item.categories_out = Identity()
        item.add_css('name', '[itemprop="name"]::text')
        item.add_css('brand', '[itemprop="brand"] ::text')
        item.add_css('image', '.big_pic img::attr(src)',
                     MapCompose(partial(urljoin, response.url)))
        item.add_css('price', '.cost [itemprop="price"]::text',
                     re=r'([\d\.,]+)')
        item.add_css('description', '.description::text')
        item.add_css('_specs_html', '#tab-content2')
        item.add_css('color', '#product .colors > li > img::attr(title)')
        item.add_css('sku', '#id::attr(value)')
        item.add_css('sku', ('#sold_out .js-product_available_notice_submit::'
                             'attr(data-product-id)'))
        item.add_css('available', '#sold_out', not_)

        yield item.load_item()

        for color in response.css('.colors > li > a::attr(href)').extract():
            yield Request(urljoin(response.url, color),
                          callback=self.parse_product)
