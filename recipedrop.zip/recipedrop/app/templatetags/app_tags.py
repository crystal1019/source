from django import template
from django.template import Variable
from django.core.urlresolvers import reverse

register = template.Library()

@register.tag(name = 'user_link')
def do_user_link(parser, token):
    tag_name, user = token.split_contents()
    return UserLinkNode(user)

class UserLinkNode(template.Node):
    def __init__(self, user):
        self.user = Variable(user)

    def render(self, context):
        user = self.user.resolve(context)
        url = reverse('user', args = [user.id])

        return '<a href="' + url + \
            '" class="user_link">' + user.profile.display_name + \
            '</a>'

@register.tag(name = 'recipe_link')
def do_recipe_link(parser, token):
    tag_name, recipe = token.split_contents()
    return RecipeLinkNode(recipe)

class RecipeLinkNode(template.Node):
    def __init__(self, recipe):
        self.recipe = Variable(recipe)

    def render(self, context):
        recipe = self.recipe.resolve(context)
        url = reverse('recipe', args = [recipe.id])

        return '<a href="' + url + \
            '" class="recipe_link">' + recipe.title + \
            '</a>'

@register.tag(name = 'recipe_comment_link')
def do_recipe_comment_link(parser, token):
    tag_name, recipe, comment_id = token.split_contents()
    return RecipeCommentLinkNode(recipe, comment_id)

class RecipeCommentLinkNode(template.Node):
    def __init__(self, recipe, comment_id):
        self.recipe = Variable(recipe)
        self.comment_id = Variable(comment_id)

    def render(self, context):
        recipe = self.recipe.resolve(context)
        comment_id = self.comment_id.resolve(context)

        url = '%s#%s' % (
            reverse('recipe', args = [recipe.id]),
            comment_id
            )

        return '<a href="' + url + \
            '" class="recipe_comment_link">' + recipe.title + \
            '</a>'

@register.tag(name = 'blog_post_comment_link')
def do_blog_post_comment_link(parser, token):
    tag_name, blog_post, comment_id = token.split_contents()
    return BlogPostCommentLinkNode(blog_post, comment_id)

class BlogPostCommentLinkNode(template.Node):
    def __init__(self, blog_post, comment_id):
        self.blog_post = Variable(blog_post)
        self.comment_id = Variable(comment_id)

    def render(self, context):
        post = self.blog_post.resolve(context)
        comment_id = self.comment_id.resolve(context)

        url = '%s#%s' % (
            reverse('standalone_blog_post', args = [post.id]),
            comment_id
            )

        return '<a href="' + url + \
            '" clsas="blog_comment_link">' + post.title + \
            '</a>'

def removespaces(value):
    return value.replace(' ', '')

register.filter('removespaces', removespaces)


@register.simple_tag(takes_context=True)
def googleviewer(context):
    request = context['request']
    host = request.META['HTTP_HOST']
    return u'http://docs.google.com/viewer?url=http://'+host


