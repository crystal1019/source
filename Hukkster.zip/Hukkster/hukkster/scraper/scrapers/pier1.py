import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class Pier1Scraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'pier1.com'

    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()
        
    def fetch_url(self):
        try:
            request = requests.request('get', self.url)
            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except BaseException, e:
            logging.error('Error %s for %s' % (e.msg, self.url))

    def generate_record(self, url, site, title, price, image,
                        sku, size, color, promos):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record

    def parse_product(self, soup, html):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """
        # site name
        site = soup.find('meta', attrs={'property': 'og:site_name'})['content']
        # url
        url = soup.find('meta', attrs={'property': 'og:url'})['content']
        # size, promos and color not display in site
        size = []
        color = []
        promos = []
        
        # check parse single or multi
        check = soup.find('div', attrs={'id': 'product-set-list'})
        
        selections = []
        
        if check is None or not len(check):
            # title
            title = soup.find('meta', attrs={'property': 'og:title'})['content']
            # image
            image = soup.find('meta', attrs={'property': 'og:image'})['content']
            # price
            price = float(soup.find('span', attrs={'class': 'price-standard'}).text[1:])
            # sku
            sku = soup.find('span', attrs={'itemprop': 'productID'}).text
            
            record = self.generate_record(url, site, title,
                                                      price, image, sku, size, color, promos)
            selections.append(record)
            return selections
        else: 
            # get all products
            products = soup.find_all('div', attrs={'class': 'product-set-item'})
            for product in products:
                # title
                title = product.find('h1', attrs={'class': 'product-name'}).text
                regex = re.compile(r'[\n\t]')
                title = regex.sub('', title)
                # image
                image = product.find('img', attrs={'class': 'primary-image'})['src']
                # price
                price = float(product.find('span', attrs={'class': 'price-standard'}).text[1:])
                # sku
                sku = product.find('button', attrs={'class': 'sub-product-item'})['id']
                print sku
                
                record = self.generate_record(url, site, title,
                                                          price, image, sku, size, color, promos)
                selections.append(record)
            
            return selections
    
    def parse(self):
        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')
        # Try to parse a single-product variant first
        try:
            selections = self.parse_product(soup, self.html)
        except:
            raise HukksterTooManyOptions(Pier1Scraper.get_domain(), self.url)
        return selections



























