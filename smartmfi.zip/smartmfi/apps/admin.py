from django.contrib import admin
from apps.models import InputForm



# Register your models here.
