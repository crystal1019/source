from django.contrib import admin
from models import Conversion, Lead, ExtraField
from offers.tools.smart_search.models import Bank, SearchDetail
from offers.tools.beatcard.models import UserData
from utils import batch_download

class BankInline(admin.StackedInline):
    model = Bank
    extra = 0

class SearchDetailInline(admin.StackedInline):
    model = SearchDetail
    extra = 0
    inlines = (BankInline,)
    
    class Media:
        js = ['js/jquery-1.3.2.min.js',
              'js/collapsed_stacked_inlines.js',
              'admin_media/js/collapsed_stacked_inlines.js',]
    
class ExtraFieldInline(admin.TabularInline):
    model = ExtraField
    extra = 0
    exclude = ('name',)

class UserDataInline(admin.StackedInline):
    model = UserData
    extra = 0
    
class ConversionAdmin(admin.ModelAdmin):
    list_display = ('uid', 'query')

class LeadAdmin(admin.ModelAdmin):
    inlines = (ExtraFieldInline, SearchDetailInline,UserDataInline)
    list_display = ('email', '__unicode__', 'country', 'state', 'date', 'source')
    list_filter = ('date', )
    search_fields = ('first_name', 'last_name')
    
    def lookup_allowed(self, key, *args, **kwargs):
        if 'date' in key:
            return True
        else:
            return super(LeadAdmin, self).lookup_allowed(key, *args, **kwargs)
            
    batch_download.short_description = "Download selected leads"
    actions = [batch_download]


admin.site.register(Lead, LeadAdmin)
admin.site.register(Conversion, ConversionAdmin)