from django.db import models
from embed_video.fields import EmbedVideoField

class Item(models.Model):
    video = EmbedVideoField()  # same like models.URLField()

from django.db import models
from django.db.models.signals import post_save
from django.contrib.auth.models import User

class Drinker(models.Model):
        user            = models.OneToOneField(User)
        birthday        = models.DateField()
        name            = models.CharField(max_length=100)

        def __unicode__(self):
                return self.name