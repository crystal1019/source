
function fire_test(){
    $.get( "/account/visitor_stats/", function( data ) {
        console.log(jQuery.parseJSON( data ));

        $.each(jQuery.parseJSON(data), function(i, item) {
               console.log(i)
        });
    });
}


function load_chart_data(){
    var loaded_data = testData(['Visitors'], 30);
    console.log(loaded_data);
    nv.addGraph(function() {
        var chart = nv.models.lineChart()
            .margin({top: 0, bottom: 25, left: 25, right: 25})
            //.showLegend(false)
            .color([
                $orange, '#cf6d51'
            ]);

        chart.legend.margin({top: 3});

        chart.yAxis
            .showMaxMin(false)
            .tickFormat(d3.format(',.f'));

        chart.xAxis
            .showMaxMin(false)
            .tickFormat(function(d) { return d3.time.format('%b %d')(new Date(d)) });
        var data = loaded_data;

        d3.select('#visits-chart svg')
            .datum(data)
            .transition().duration(500)
            .call(chart);

        return chart;
    });
}