import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class NeedSupplyScraper(BaseScraper):
    base_image_url = 'http://cdn.needsupply.com/media/catalog/product/'

    @staticmethod
    def get_domain():
        return 'needsupply.com'

    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()

    def fetch_url(self):
        try:
            request = requests.request('get', self.url)
            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except BaseException, e:
            logging.error('Error %s for %s' % (e.msg, self.url))


    def clean_html(self, html):
        htmlempty = ''
        for char in html:
            if (ord(char) != 10) and (ord(char) != 13):
                htmlempty += char
        return htmlempty


    def generate_record(self, url, site, title, price, image,
                        sku, size, color, promos=[]):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record

    def parse_single_product(self, soup, html, raw_data):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """
        if raw_data:
            site_name = raw_data['site_name']
            url = raw_data['_url']
        else:
            site_name = soup.find('title').text
            url = self.url

        # product image
        image = soup.find('img', attrs={'id': 'product_image'})['src']

        # title
        title = soup.find('meta', attrs={'name': 'keywords'}).text
       
        # description
        description = soup.find('meta', attrs={'name': 'description'}).text

        html = self.clean_html(html)
        script_regex = 'spJsonConfig\\s*=\\s*([^;]+);'
        json_data = self.get_base(script_regex, html)
        dict_data = self.get_data_json(json_data)

        # SKU
        sku = dict_data['productId']

        # price
        price = float(dict_data['basePrice'])

        # sizes and colors
        attributes = dict_data['attributes']
        colors = []
        sizes = []
        for value in attributes.values():
            label = value['label']
            for option in value['options']:
                data = option['label']
                if label == 'Color':
                    colors.append(data)
                elif label == 'Size':
                    sizes.append(data)

        has_color = len(colors) > 0
        has_size = len(sizes) > 0

        selections = []

        if has_color and has_size:
            for color in colors:
                for size in sizes:
                    record = self.generate_record(url, site_name, title,
                                                  price, image, sku, size, color)
                    selections.append(record)
        elif has_color:
            for color in colors:
                record = self.generate_record(url, site_name, title,
                                              price, image, sku, '', color)
                selections.append(record)
        elif has_size:
            for size in sizes:
                record = self.generate_record(url, site_name, title,
                                              price, image, sku, size, '')
                selections.append(record)
        else:
            record = self.generate_record(url, site_name, title,
                                          price, image, sku, '', '')
            selections.append(record)

        return selections


    def get_base(self, regex, html):
        """
        Pull subset of the HTML for regex evaluation.
        """

        return re.compile(regex).findall(html)[0]

    def get_data_regexes(self, regexes, base):
        """
        Loop over regex rules and pull data.
        return dictionary
        """

        result = {}

        for aregex in regexes:
            try:
                resunts = re.compile(aregex['find']).findall(base)
                result[aregex['name']] = ','.join(resunts)
            except: # TODO: it's too broad, please improve
                result[aregex['name']] = 'NOTHING'
        return result

    def get_data_json(self, data):
        """
        Parse json to dictionary.
        """
        return json.loads(data)
    
    def parse_multi_product(self, soup):
        # store
        site_name = soup.find('title').text
        # url
        url = self.url
        
        products = soup.find_all('tr')
        if len(products):
            del products[0]
        
        selections = []
        for product in products:
            sku = product['id']
            image = product.find('td', attrs = {'class': 'items'}).find('img')['src']
            title = product.find('td', attrs = {'class': 'description'}).text
            price = float(product.find('td', attrs = {'class': 'price'}).text[1:])
            # get colors and sizes
            
            colors = product.find('td', attrs = {'class': 'color'}).find_all('option')
            sizes = product.find('td', attrs = {'class': 'size'}).find_all('option')
            
            if colors is None or not len(colors):
                color = ''
                if sizes is None or not len(sizes):
                    size = ''
                    record = self.generate_record(url, site_name, title,
                                                      price, image, sku, size, color)
                    selections.append(record)
                else:
                    del sizes[0] 
                    for size in sizes:
                        size =size.text
                        record = self.generate_record(url, site_name, title,
                                                      price, image, sku, size, color)
                        selections.append(record)
            else:
                del colors[0]
                if sizes is None or not len(sizes):
                    size = ''
                    for color in colors:
                        record = self.generate_record(url, site_name, title,
                                                      price, image, sku, size, color)
                        selections.append(record)
                else:
                    del sizes[0] 
                    for color in colors:
                        color = color.text
                        for size in sizes:
                            size =size.text
                            record = self.generate_record(url, site_name, title,
                                                          price, image, sku, size, color)
                            selections.append(record)
        return selections
    
    def parse(self):
        
        parse_multi = False
        raw_data = self.parse_opengraph()
        
        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')
        
        # Try to parse a single-product variant first
        try:
            selections = self.parse_single_product(soup, self.html, raw_data)
        except:  # TODO: WTF? Never use broad exceptions
            parse_multi = True

        # We assume it's a multi-product item
        if parse_multi:
            selections = self.parse_multi_product(soup)
        
        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(NeedSupplyScraper.get_domain(), self.url)
        
        return selections



























