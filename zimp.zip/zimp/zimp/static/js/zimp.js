var app = angular.module('zimp', ['ui.bootstrap', 'ngCookies']);

app.controller('LojistaController', function($scope, $http) {

});

app.run(function($rootScope, $http, $cookies){
    $http.defaults.headers.post['X-CSRFToken'] = $cookies.csrftoken;
    $http.defaults.headers.put['X-CSRFToken'] = $cookies.csrftoken;
    $http.defaults.headers.post['Content-Type'] = 'application/json;charset=utf-8';
});
