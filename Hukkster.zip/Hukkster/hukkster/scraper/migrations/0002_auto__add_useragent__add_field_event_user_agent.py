# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'UserAgent'
        db.create_table('scraper_useragent', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('identifier', self.gf('django.db.models.fields.CharField')(unique=True, max_length=255)),
        ))
        db.send_create_signal('scraper', ['UserAgent'])

        # Adding field 'Event.user_agent'
        db.add_column('scraper_event', 'user_agent',
                      self.gf('django.db.models.fields.related.ForeignKey')(default=1, to=orm['scraper.UserAgent']),
                      keep_default=False)


    def backwards(self, orm):
        # Deleting model 'UserAgent'
        db.delete_table('scraper_useragent')

        # Deleting field 'Event.user_agent'
        db.delete_column('scraper_event', 'user_agent_id')


    models = {
        'scraper.event': {
            'Meta': {'ordering': "('-created',)", 'object_name': 'Event'},
            'created': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'db_index': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'status': ('django.db.models.fields.PositiveSmallIntegerField', [], {'db_index': 'True'}),
            'target': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['scraper.Target']"}),
            'user_agent': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['scraper.UserAgent']"})
        },
        'scraper.target': {
            'Meta': {'object_name': 'Target'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'target_type': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200'})
        },
        'scraper.useragent': {
            'Meta': {'object_name': 'UserAgent'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'identifier': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '255'})
        }
    }

    complete_apps = ['scraper']