from django import forms
from bellabustiere.website.models import *
import datetime

from django.template import loader, RequestContext, Context
from django.http import HttpResponse, HttpResponseRedirect
from django.core.mail import EmailMultiAlternatives

def sendEmail(template,s,r,title, e_from):
    t = loader.get_template(template)
    c = Context({'s':s,'r':r})
    content = t.render(c)
    email = EmailMultiAlternatives(title , content, e_from, [s.email])
    email.attach_alternative(content, "text/html")
    email.send()


def generateDays():
    return [(x,str(x)) for x in range(1,32)]

def generateMonths():
    return [(x,str(x)) for x in range(1,13)]

def generateYears():
    now = datetime.datetime.now()
    return [(x,str(x)) for x in range(1900,now.year)]

class SubscribeForm(forms.ModelForm):
    class Meta:
        model = Subscription
    
    day_choice = forms.IntegerField(required=False, widget=forms.Select(choices=generateDays()))
    month_choice = forms.IntegerField(required=False,widget=forms.Select(choices=generateMonths()))
    year_choice = forms.IntegerField(required=False,widget=forms.Select(choices=generateYears()))

    def __init__(self,*args, **kwargs):
        super(SubscribeForm,self).__init__(*args,**kwargs)
        self.fields['first_name'].required = True
        self.fields['last_name'].required = True
        self.fields['first_name'].error_messages = {'required':'Please enter your First Name'}
        self.fields['last_name'].error_messages = {'required':'Please enter your Last Name'}
        self.fields['postcode'].error_messages = {'required':'Please enter your Postcode'}
        self.fields['email'].error_messages = {'required':'Please enter your Email Address'}
        self.fields['sites'].required = False
        
    def save(self,*args, **kwargs):
        s = super(SubscribeForm, self).save(commit=False)
        day = self.cleaned_data['day_choice']
        month = self.cleaned_data['month_choice']
        year = self.cleaned_data['year_choice']
        
        dob = datetime.date(year,month,day)
        s.dob = dob
        s.group = SubscriptionGroup.objects.get(name__iexact='Retail')
        s.status = True
        s.save()
        
                
        
        return s 
    