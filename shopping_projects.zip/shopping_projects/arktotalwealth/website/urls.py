from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('arktotalwealth.website.views',
					(r'^search/$', 'search',{'uri':'main'}),
					(r'^sendmessage.html$', 'message'),
					(r'^$', 'home'),
					(r'^(?P<path>.*)$', 'catchall'),


)