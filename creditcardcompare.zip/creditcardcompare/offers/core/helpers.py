from django.conf import settings
from offers.core.models import OfferMeta, MetaFieldTooltip, OfferCategory
from offers.tools.lightbox.models import PostClick


IS_RATE = True
TWO_COLUMNED = 2


def update_sort_order(category, request):
    cards = request.GET['sorted-cards'].split('-')
    cards.reverse()
    try:
        counter = OfferCategory.objects.filter(category=category).exclude(offer_id__in=cards).order_by('-sort_order')[0].sort_order
    except IndexError:
        counter = 0
    for card in cards:
        counter += 1
        OfferCategory.objects.filter(category=category, offer_id=card).update(sort_order=counter)

def rate_history_months():
    history = []
    months = OfferMeta.objects.all().dates('date', 'month')
    for month in months:
        try:
            history.append(month.strftime('%b %y'))
        except AttributeError:
            continue
    return history

def duplicate_offer(modeladmin, request, queryset):
    def _add_to_offer(new_offer, query_set):
        for model_object in query_set:
            model_object.id = None
            model_object.offer = new_offer
            model_object.save()
    for offer in queryset.all():
        meta_instances = offer.meta_instances.all()
        offercategory_set = offer.offercategory_set.order_by('pk')
        site_options = offer.site_options.all()
        
        offer.id = None
        offer.is_active = False
        offer.slug = offer.slug + "-duplicate"
        offer.save()
        
        _add_to_offer(offer, meta_instances)
        _add_to_offer(offer, offercategory_set)
        _add_to_offer(offer, site_options)
                
def generate_post_click(category_slug=None, offer_id=None):
    if category_slug is not None:
        try:
            return PostClick.objects.filter(site__id=settings.SITE_ID, offer__categories__slug=category_slug)[0]
        except IndexError:
            pass
    elif offer_id is not None:
        try:
            return PostClick.objects.filter(offer__id=offer_id)[0]
        except IndexError:
            pass


def html_sortable_meta_fields(offer, sortable_fields):
    def get_value(key, field=None):
        try:
            meta = offer.meta_instances.get(meta_field__key=key)
        except OfferMeta.DoesNotExist:
            return '-'
        if field is None:
            return meta.value_or_default.replace('p.a.', '')
        try:
            return getattr(meta, field)
        except AttributeError:
            return '-'
        
    html = ''
    for meta in reversed(sortable_fields):
        if meta.key == 'Purchase Rate':
            rate = get_value(meta.key)
            intro_rate = get_value('Intro Purchase Rate')
            intro_expiry = get_value('Intro Purchase Rate', 'expiry')
            period = get_value('Intro Purchase Period')
            
            if intro_rate != '-' and period != '-':
                html = append_column(html, {'value': intro_rate, 'period': 'for ' + period, 'comment': 'then '+rate}, TWO_COLUMNED, IS_RATE)
            elif intro_rate != '-' and intro_expiry != '-':
                html = append_column(html, {'value': intro_rate, 'period': 'until %s %s' % (intro_expiry.day, intro_expiry.strftime('%B %Y')), 'comment': 'then '+rate}, TWO_COLUMNED, IS_RATE)
            else:
                html = append_column(html, {'value': rate, 'period': '', 'comment': ''}, TWO_COLUMNED, IS_RATE)
        elif meta.key == 'Intro Purchase Rate':
            rate = ''
            intro_rate = get_value('Intro Purchase Rate')
            if intro_rate != '-':
                period = get_value('Intro Purchase Period')
                html = append_column(html, {'value': intro_rate, 'period': 'for ' + period, 'comment': rate}, TWO_COLUMNED, IS_RATE)
            else:
                html = append_column(html, {'value': intro_rate, 'period': '', 'comment': ''}, TWO_COLUMNED, IS_RATE)
        
        elif meta.key == 'Balance Transfer Rate':
            rate = get_value(meta.key)
            try:
                fallback_rate = get_value(offer.bt_fallback.key)
            except AttributeError:
                comment = ''
            else:
                comment = 'then %s' % fallback_rate
            if rate != '-':
                period = get_value('Balance Transfer Period')
                html = append_column(html, {'value': rate, 'period': 'for ' + period, 'comment': comment}, TWO_COLUMNED, IS_RATE)
            else:
                html = append_column(html, {'value':' -', 'comment': ''}, TWO_COLUMNED)
        elif meta.key == 'Balance Transfer Period':
            continue
        elif meta.key == 'Annual Fee':
            value = get_value(meta.key)
            second_annual = get_value('Annual Fee 2nd Year')
            second_annual_q = get_value('Annual Fee (Qualifying Customers)')
            
            if second_annual != '-':
                html = append_column(html,{'value': value, 'comment': '1st year'})
            elif second_annual_q != '-':
                tooltip = 'for qualifying customers'
                if value.strip() == second_annual_q.strip():
                    html = append_column(html,{'value': '%s<sup title="%s">*</sup>' % (second_annual_q, tooltip), 'comment': ''})
                else:
                    html = append_column(html,{'value': '%sor&nbsp;%s<sup title="%s">*</sup>' % (value, second_annual_q, tooltip), 'comment': ''})
            else:
                html = append_column(html,{'value': value, 'comment': ''})
        elif 'Frequent Flyer Points' in meta.key:
            value = get_value(meta.key)
            if value != '-':
                value += ' (MC/VISA)'
            else:
                value = ''
            amex_value = get_value('Frequent Flyer Points (AmEx)')
            if amex_value != '-':
                amex_value += ' (AmEx)'
            else:
                amex_value = ''
            if value or amex_value:
                html = append_column(html, {'value': '', 'comment': value + '<br />' + amex_value})
            else:
                html = append_column(html, {'value': '', 'comment': '-'})
        else:
            value = get_value(meta.key)
            html = append_column(html, {'value': '', 'comment': value})
    return html
                
                    
def append_column(html, data, col_span=1, is_rate=False):
    column = '<td colspan="%s">' % col_span
    if is_rate:
        # keep it in single line for tablesorter to properly work
        column += """<span class="rate">%(value)s</span><span class="duration">%(period)s</span>%(comment)s""" % data
    else:
        column += '<span class="fee">%(value)s</span>%(comment)s' % data
    column += '</td>'
    return html + column


def html_sortable_header_fields_1(sortable_fields):
    html = ''
    _id = 3
    for meta in reversed(sortable_fields):
        key = meta.key.replace(' (MC/VISA)', '')
        data = {'id': _id, 'colspan': 1, 'rowspan': 1, 'class': 'class="double pointer"', 'key': key, 'tooltip': ''}
        if 'Rate' in meta.key:
            data.update({'colspan': 2, 'key': meta.key.replace('Transfer Rate', 'Transfer')})
            _id += 1
        elif 'Period' in meta.key:
            continue
        else:
            data.update({'rowspan': 2, 'class': 'class="pointer"'})
            _id += 1

        try:
            tooltip = meta.tooltips.get(sites__id=settings.SITE_ID)
        except MetaFieldTooltip.DoesNotExist:
            data.update({'tooltip': 'click to sort'})
        else:
            data.update({'tooltip': tooltip.text})

        html += append_header(data)
        
    return html 
        
        
def append_header(data):
    new_row = '''
        <th colspan="%(colspan)s" %(class)s rowspan="%(rowspan)s" title="%(tooltip)s">%(key)s %%s</th>
        ''' % data
    new_row = new_row % ('<br /><span class="arrow">(p.a.)</span>' if data['key'] == 'Annual Fee' else '')
    return new_row
