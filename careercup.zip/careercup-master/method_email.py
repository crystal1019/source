import os

from google.appengine.ext.webapp import template
from google.appengine.api import mail

def sendEmail(from_user, to_user, subject, body, type, link):
	reply_to = 'mail@careercup.com'
	if from_user:
		reply_to = from_user.user.email()
	if not to_user:
		return
	email = to_user.user.email()
	if to_user.user.nickname():
		email = to_user.user.nickname() + ' <' + to_user.user.email() + '>'
	return sendEmailToRawEmail(reply_to, email, subject, body, type, link)
	
def sendEmailToRawEmail(from_user, to_user, subject, body, type, link):
	email_subject = 'CareerCup: ' + subject
	from_email = 'CareerCup <mail@careercup.com>'
	reply_to = 'mail@careercup.com'
	if from_user:
		reply_to = from_user
	message = mail.EmailMessage(sender=from_email, subject=email_subject, bcc='gaylejunk@gmail.com')
	message.bcc = to_user

	message.reply_to = reply_to
	message.body = body

	template_values = {}
	template_values['subject'] = subject
	template_values['body'] = body 
	template_values['url'] = link  

	path = os.path.join(os.path.dirname(__file__), 'html/emailtemplate.html')
	html = template.render(path, template_values) 
	message.html = html		   
	message.send()
	
	return html
	
def sendMeEmail(reply_to, subject, body):
	email_subject = 'CareerCup: ' + subject
	from_email = 'gaylel@gmail.com'
	message = mail.EmailMessage(sender=from_email, subject=email_subject)
	message.to = 'gaylelaakmann@gmail.com'
	if not reply_to:
		reply_to = 'gayle@careercup.com'
	message.reply_to = reply_to
	message.body = body

	template_values = {}
	template_values['subject'] = subject + ' : ' + reply_to
	template_values['body'] = body.replace('\n', '<br/>')
	
	path = os.path.join(os.path.dirname(__file__), 'html/emailtemplate.html')
	html = template.render(path, template_values) 
	
	message.html = html		   
	message.send()