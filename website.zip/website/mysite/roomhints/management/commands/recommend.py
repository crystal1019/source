from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.models import Project
from roomhints.models import RoomType
from roomhints.models import RoomHint
from roomhints.models import DefaultHint

from roomhints.views import add_roomhint_from_dhint

from roomhints.imagematcher import find_image_match
from roomhints.imagematcher import score_images
from roomhints.imagematcher import score_images_dem
from roomhints.imagematcher import score_images_brief

from datetime import datetime, timedelta
from roomhints.utils import random_number

class Command(BaseCommand):
    help = 'For every room in the past 2 days that has not had any roomhints added to it, recommend a hint'

    def handle(self, *args, **options):
        projuniq = None
        for a in args:
            projuniq = a

        to_process = []
        if projuniq == None:
            rt = RoomType.objects.filter(name="decorate").get()
            projects = Project.objects.filter(roomtype_id=rt.id,public=True).order_by('-seconds')[:10]
            for p in projects:
                all_rh = RoomHint.objects.filter(project_id=p.id).all()
                if len(all_rh) == 0:
                    # if this room has no hints, plan to add one
                    to_process.append(p)
        else:
            p = Project.objects.filter(projuniq=projuniq).get()
            to_process.append(p)

        output = ""
        for p in to_process:
            print str(datetime.now()) + " ---------------> processing " + p.projuniq + " " + str(p)
            # We may be running in test mode, so add a hint only if there aren't any
            all_rh = RoomHint.objects.filter(project_id=p.id).all()
            if len(all_rh) == 0:
                # This room has no hints, add some
                output += "This room has no hints, will try to add some\n"
                input_image = settings.MEDIA_ROOT + p.photo_web.name
                # Match against all images
                search_images, output_image, output_image_score, scores = find_image_match(input_image, "defaulthints",p)
                output += "------> for " + p.projuniq + "\n"
                output += str(scores) + "\n"
                output += "Total images:  " + str(search_images) + "\n"
                output += "InImage:       " + str(input_image) + "\n"
                score_keys_sorted = sorted(scores['by_score'],reverse=True)
                print ("score_keys_sorted ...." + str(score_keys_sorted))
                counter = 0
                max_hints = random_number(3,4)
                for k in score_keys_sorted:
                    for match_image in scores['by_score'][k]:
                        if counter < max_hints:
                            if k > 0:
                                # Add this recommendation
                                counter += 1
                                output += "OutImage:      " + settings.MEDIA_ROOT + str(match_image) + "\n"
                                output += "OutImage plain: " + match_image + "\n"
                                output += "OutScore:      " + str(k) + "\n"

                                # Automatically add this match as a hint           
                                dh = DefaultHint.objects.filter(photo=match_image).get()
                                output += "Will ADD default hint with id " + str(dh.id) + "\n"
                                min_seconds = 120
                                max_seconds = 3600
                                if counter == 1:
                                    min_seconds = 60 * 2
                                    max_seconds = 60 * 10
                                elif counter == 2:
                                    min_seconds = 60 * 10
                                    max_seconds = 60 * 45
                                elif counter == 3:
                                    min_seconds = 60 * 45
                                    max_seconds = 60 * 60 * 5
                                elif counter == 4:
                                    min_seconds = 60 * 10
                                    max_seconds = 60 * 60 * 5
                                add_roomhint_from_dhint(dh,p,min_seconds,max_seconds)
                            else:
                                # If something goes wrong, the score is 0.
                                output += "Matching is failing to run\n"
            else:
                output += "This room has hints, will NOT add one\n"

        print output
