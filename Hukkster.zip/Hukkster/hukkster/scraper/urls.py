from django.conf.urls import patterns, url


urlpatterns = patterns('hukkster.scraper.views',
    url(r'^find/$', 'scrape', name='scrape')
)
