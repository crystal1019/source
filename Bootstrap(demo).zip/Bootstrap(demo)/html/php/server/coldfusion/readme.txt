Coldfusion example by Patrick Hedgepath - Pegasus Web Productions LLC - www.pegweb.com

Code has been tested with version 2.0 of Valum's AJAX file uploader on Cold Fusion Enterprise 9.x server
If you have any improvements to this code please feel free to email them to me webmaster@pegweb.com

    1. Unzip Valum's AJAX Uploader into your web root.
    2. Use the upload-page.cfm in place of the demo.htm file found in the "client" folder
	3. Open the image-uploader.cfc and edit the lines in each function that say <cfset UploadDir = ""> to include the path you want the images to upload to on the server.
    4. Place image-uploader.cfc in the same folder on the server and the upload-page.cfm file
    5. Browse to the upload-page.cfm file and test it out.

Questions, problems, comments? Go to the forums and post https://github.com/valums/file-uploader