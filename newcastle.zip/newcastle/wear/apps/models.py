from django.db import models
# from django import forms

# Create your models here.
class Login(models.Model):

    firstname = models.CharField(max_length=100, blank=True, null=True)
    lastname = models.CharField(max_length=100, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    is_staff = models.BooleanField(default=True)
