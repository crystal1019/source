#!/usr/bin/env python
# coding: UTF-8

from django.contrib import admin
from models import *


admin.site.register(AttributeOptionThumbnail, admin.ModelAdmin)