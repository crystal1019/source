/**
 * Dialog window for cropping avatar images.
 * @param  {string} img_url Image source url.
 * @return {null} N/A
 */
function image_crop_dialog(img_url) {
    var jcrop_api;

    // Add jcrop to image.
    function addCropping(){
        $('#crop_img').Jcrop({
            aspectRatio: 1,//1.38,
            boxWidth   : 560,
            boxHeight  : 400,
            setSelect  : [ 100, 100, 10, 10 ],
            bgOpacity  : 0.6
            },
            function(){
                jcrop_api = this;
            }
        );
    }

    $('#dialog').on('shown', function(){
        addCropping();
        $('#dialog').off('shown');
    });

    img_crop_dimensions = null;
    var dg = $('#dialog');
    // Body Content
    var m = ['<div>'];
    m.push('<div>');
    m.push('<img id="crop_img" src="' + img_url + '"/>');
    m.push('</div>');
    m.push('</div>');
    dg.find('.modal-body').html(m.join(''));
    dg.modal({
        show: true,
        backdrop: 'static'
    });

    dg.find('#dialog-ok').click(function() {
        var img = $('#crop_img');
        data = jcrop_api.tellSelect();
        data['crop'] = true;
        data['img'] = img.attr('src');
        data['img_width'] = img.width();
        data['img_height'] = img.height();
        $.ajax({
                url: '/assets/avatar_upload/',
                type: 'post',
                data: data,
                success: function(obj) {
                    if (obj.success) {
                        window.location.href = ".";
                    }
                }
            });

        dg.modal('hide');
        $(this).off('click');
    });
}