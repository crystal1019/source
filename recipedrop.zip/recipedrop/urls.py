
from django.conf.urls.defaults import patterns,url,include
from django.conf import settings

import haystack
from app.mobile import SearchView
haystack.autodiscover()

urlpatterns = patterns('',

    url('^$', 'app.views.home', name = 'home'),

    url(r'^search/', include('haystack.urls')),

    url(r'^fonts/(?P<path>.*)$', 'django.views.static.serve',
        {'document_root': settings.STATIC_ROOT + 'fonts/'}),
    url(r'^static/(?P<path>.*)$', 'django.views.static.serve',
        {'document_root': settings.STATIC_ROOT}),

    url(r'^settings/$', 'app.user_settings.settings', name = 'settings'),

    url(r'^bookmarklet/$', 'app.views.bookmarklet', name='bookmarklet'),

    url(r'^users/signup/$', 'app.users.signup',
        name = 'new_user'),

    url(r'^users/login/$', 'app.users.login_view',
        name = 'login'),

    # from django.contrib.auth.urls
    url(r'^password_reset/$', 'django.contrib.auth.views.password_reset',
        {'template_name': 'password_reset/password_reset.html',
         'email_template_name': 'password_reset/email.html',
         'from_email': 'support@recipedrop.com'},
        name='password_reset'),
    url(r'^password_reset/done/$', 'django.contrib.auth.views.password_reset_done',
        {'template_name': 'password_reset/done.html'},
        name='password_reset_done'),
    url(r'^reset/(?P<uidb36>[0-9A-Za-z]{1,13})-(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        'django.contrib.auth.views.password_reset_confirm',
        {'template_name': 'password_reset/confirm.html'},
        name='password_reset_confirm'),
    url(r'^reset/done/$', 'django.contrib.auth.views.password_reset_complete',
        {'template_name': 'password_reset/complete.html'},
        name='password_reset_complete'),


    url(r'^users/profile_photo/big/(\d+)/$', 'app.users.profile_photo_big',
        name = 'profile_photo_big'),

    url(r'^users/profile_photo/(\d+)/$', 'app.users.profile_photo',
        name = 'profile_photo'),

    url(r'^users/delete_profile_photo/$', 'app.users.delete_photo',
        name = 'delete_profile_photo'),

    url(r'^users/profile/(\d+)/$', 'app.users.profile_data',
        name = 'profile_data'),

    url(r'^users/logout/$', 'app.users.logout_view', name = 'logout'),

    url(r'^user/(\d+)/$', 'app.users.user', name = 'user'),

    url(r'^friends/requests/(\d+)/$', 'app.friends.request_friend',
        name='friend_request'),

    url(r'^friends/approve/(\d+)/$', 'app.friends.approve',
        name='friend_approve'),

    url(r'^friends/unfriend/(\d+)/$', 'app.friends.unfriend',
        name='unfriend'),

    url(r'^friends/action/(\d+)/$', 'app.friends.action',
        name='friend_action'),

    url(r'^notifications/viewed/$', 'app.notifications.viewed',
        name='viewed_notifications'),

    url(r'^recipes/new/$', 'app.recipes.new',
        name='new_recipe'),
    url(r'^recipes/edit/(\d+)/$', 'app.recipes.edit', name='edit_recipe'),

    url(r'^recipes/(\d+)/$', 'app.recipes.recipe_no', name='recipe_no'),

    url(r'^recipes/delete/(\d+)/$', 'app.recipes.delete', name='delete_recipe'),
    url(r'^recipes/images/(\d+)/$', 'app.recipes.photo', name='recipe_photo'),
    url(r'^recipes/files/(\d+)/$', 'app.recipes.recipe_file',
        name='recipe_file'),

    url(r'^recipes/upload/$', 'app.recipes.upload', name='recipe_upload'),
    url(r'^recipes/upload/delete/$', 'app.recipes.delete_upload',
        name='delete_upload'),

    url(r'^recipes/save/$', 'app.recipes.save', name='save_recipe'),

    url(r'^recipes/new_comment/(\d+)/$', 'app.recipes.new_comment',
        name='new_recipe_comment'),
    url(r'^recipes/delete_comment/$', 'app.recipes.delete_comment',
        name='delete_comment'),
    url(r'^recipes/commentscnt/(\d+)/$', 'app.recipes.comments_count',
        name='comment_count'),
    url(r'^recipes/unsubscribe/(\d+)/$', 'app.recipes.unsubscribe_comments',
        name='recipe_comment_unsubscribe'),
    url(r'^recipes/(?P<slug>[\w-]+)/$', 'app.recipes.recipe', name='recipe'),

    url(r'^download/(\d+)/$', 'app.uploads.download_handler', name='download'),

    url(r'^access_control/$', 'app.views.access_control',
        name='set_access_control'),

    url(r'^blogs/new_post/$', 'app.blogs.new_post',
        name='new_blog_post'),
    url(r'^blogs/post/(\d+)/$', 'app.blogs.post', name='blog_post'),
    url(r'^blogs/edit/(\d+)/$', 'app.blogs.edit_post', name='edit_blog_post'),
    url(r'^blogs/delete/(\d+)/$', 'app.blogs.delete_post',
        name='delete_blog_post'),
    url(r'^blogs/view_post/(\d+)/$', 'app.blogs.standalone_post',
        name='standalone_blog_post'),
    url(r'^blogs/new_comment/(\d+)/$', 'app.blogs.new_comment',
        name='new_blog_comment'),
    url(r'^blogs/delete_comment/$', 'app.blogs.delete_comment',
        name='delete_blog_post_comment'),

    url(r'^tags/all/$', 'app.tags.all', name='all_tags'),
    url(r'^tags/new/$', 'app.tags.new', name='new_tag'),
    url(r'^tags/delete/$', 'app.tags.delete', name='delete_tag'),

    url(r'^bookmark/(\d+)/$', 'app.bookmarks.bookmark',
        name='bookmark'),
    url(r'^unbookmark/(\d+)/$', 'app.bookmarks.unbookmark',
        name='unbookmark'),
    url(r'^bookmarks/$', 'app.bookmarks.bookmarks',
        name='bookmarks'),

    url(r'^invite/$', 'app.users.invite', name='invite'),

    url(r'^welcome/$', 'app.views.welcome', name='welcome'),
)

urlpatterns += patterns('app.mobile',
    url(r'^mobile/login/$', 'login_page', name = 'mobile_login'),
    url(r'^mobile/$', 'recipes_my', name='mobile_recipes_my'),
    url(r'^mobile/recipes/all/$', 'recipes_all', name='mobile_recipes_all'),
    url(r'^mobile/recipes/loadmore/$', 'recipes_loadmore'),
    url(r'^mobile/recipes/(?P<tag>.*)/$', 'recipes_by_tag', name='mobile_recipes_by_tag'),
    url(r'^mobile/recipe/(\d+)/$', 'recipe', name='mobile_recipe'),
    url(r'^mobile/calendar/(\d+)/$', 'calendar', name='mobile_calendar'),
    url(r'^mobile/updates/$', 'updates', name='mobile_updates'),
    url(r'^mobile/search/$', SearchView(template='mobile/search.html'), name='mobile_search'),
    url(r'^mobile/new/$', 'new_recipe', name='mobile_new_recipe'),
)
