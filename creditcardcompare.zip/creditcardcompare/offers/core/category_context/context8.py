from django.conf import settings
from offers.core.models import Category, Offer


class Context:
    def __init__(self, request, context):
        self.request = request
        self.old_context = context
        self.added_context = {'noindex': self.old_context['category'].seo_page_options['noindex']}
    
    @property
    def context(self):
        if settings.HOMEPAGE_CATEGORY[settings.SITE_NAME] == self.old_context['category'].slug: # when in CCC homepage
            self.added_context.update(self.get_homepage_context())
        else:
            self.added_context.update(self.get_category_context())
        return self.added_context
    
    def get_category_context(self):
        context = {'qna_sections': self.old_context['category'].persiteoption.get_qna_sections(),
                   'slider_type': self.old_context['category'].get_slider_type(),}
        return context
    
    def get_homepage_context(self):
        try:
            balance_transfer = Category.objects.get(slug='balance-transfer-credit-cards')
            low_rate = Category.objects.get(slug='low-interest-credit-cards')
            frequent_flyer = Category.objects.get(slug='frequent-flyer-credit-cards')
        except Category.DoesNotExist:
            return
        
        balance_transfer.header, low_rate.header, frequent_flyer.header = '0% balance transfer cards', 'low rate cards', 'frequent flyer cards' 
        balance_transfer.text = 'Transfer debt to a 0% credit card and save money on interest by paying it off over a long interest-free period.'
        low_rate.text = 'Get a card with an introductory 0% offer or ongoing low rate on purchases and then pay it off over a longer period of time.'
        frequent_flyer.text = 'Turn your everyday spending into free flights and upgrades with your preferred airline.'
        
        context = {'balance_transfer': balance_transfer,
                   'low_rate': low_rate,
                   'frequent_flyer': frequent_flyer,}
        try:
            context['limited_offer'] = Offer.objects.get(slug="westpac-low-rate-credit-card-comparison-sites-only", is_active=True)
        except Offer.DoesNotExist:
            pass
        return context
        
        
        