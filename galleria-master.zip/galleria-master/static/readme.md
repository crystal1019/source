# This is just a placedholder for the static files.
# Ensure it will be created in git
