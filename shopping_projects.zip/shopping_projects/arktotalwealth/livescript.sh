#!/bin/bash
cd /home/chaol/projects/arktotalwealth
python manage.py update_index > /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/process
echo "---------------" >> /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/process
cat  /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/process >> /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/allprocess
