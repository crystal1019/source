var loader = null;
function compareCards(){
	href = $('.compare-button').attr('name');
	window.parent.location = href;
};
function toggleControls(){
	href = $('.compare-button').attr('url');
	$('.compare-checkbox:checked').each(function () {
           href += this.value+'-';
	});
	$('.compare-button').attr('name',href.slice(0,-1));
	cbutton = $('.compare-button');
	cboxes = $('.compare-checkbox:checked');
	if(cboxes.length>1){
		cbutton.attr('disabled',false);
	}else{
		cbutton.attr('disabled',true);
	}
	if (cboxes.length > 2) {
		$('.compare-checkbox').filter(":not(:checked)").attr('disabled',true);
	}else{
		$('.compare-checkbox').filter(":not(:checked)").attr('disabled',false);
	}
	$('.compare-checkbox').click(toggleControls);
};
$(function(){
	toggleControls();
	$(document).ajaxComplete(function(event, xhr, settings){
		try{
			if (isPagination(event, xhr, settings)){
				toggleControls();
			}
		}catch(e){}
	});
});
