$(document).ready(function() {
    jQuery("#id_cardtype").change(function(){
        toggleSecondCardType();
    });
    toggleSecondCardType();
});
function toggleSecondCardType(){
	$('.second_card_type').hide();
    text = $('#id_cardtype option:selected').html();
    if (text.trim() == 'Balance Transfer'){
        $('#balance_transfer').show(300);
    }else if (text.trim() == 'Frequent Flyer'){
        $('#frequent_flyer').show(300);  
    }else if (text.trim() == 'Rewards'){
        $('#rewards').show(300);  
    }else if (text.trim() == 'Insurance'){
        $('#insurance').show(300);  
    };
};
