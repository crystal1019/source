from django.core.context_processors import csrf
from django.template.loader import render_to_string
from django.shortcuts import render_to_response, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.template import RequestContext
from django.http import HttpResponse, HttpResponseServerError
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.conf import settings

from django.views.decorators.cache import cache_control  #  never_cache

from friends import friends, friend_action_template
from models import Profile, Friendship, Notification, UserFeed, \
    ACCESS_FRIENDS, ACCESS_PUBLIC
from forms import *
from util import success_json
from uploads import *
from emails import send_invite

import json

NUM_EVENTS = 5

RECIPE_PER_PAGE=32


def new_user(request, email, name, password):

    try:
        u = User.objects.get(email = email)
        return [('email', [render_to_string('signup_email_taken.html')])]
    except:
        pass

    u = User.objects.create(email = email, username = email)
    u.set_password(password)
    u.save()

    p = Profile.objects.create(user = u,
                               display_name = name,
                               access = ACCESS_PUBLIC)
    p.save()

    u = authenticate(username = email, password = password)
    if u is not None:
        login(request, u)
    else:
        return False

    return True

def get_next(d):
    return d['next'] if 'next' in d else None

def signup(request):

    c = RequestContext(request)
    c.update(csrf(request))

    def failure(errs):
        return HttpResponseServerError(
            json.dumps({'alert': render_to_string('signup_failure.html', c),
                        'errors': errs})
            )

    if request.method == 'POST':
        next_url = get_next(request.POST)

        form = SignupForm(request.POST)
        if form.is_valid():
            errs = new_user(request,
                            form.cleaned_data['email'],
                            form.cleaned_data['name'],
                            form.cleaned_data['password'])

            if errs is not True:
                return failure(errs)
            else:
                return success_json({
                        'redirect': next_url or '/welcome/'
                        })
        else:
            return failure([
                    (field.name, field.errors) for field in form
                    ])

    else:
        form = SignupForm()

    c.update({'form': form})

    return render_to_response('signup.html', c)

def login_view(request):
    c = RequestContext(request)
    c.update(csrf(request))

    if request.method == 'POST':
        next_url = get_next(request.POST)
        
        failure = HttpResponseServerError(
            json.dumps({'alert': render_to_string('login_failure.html', c)})
            )

        form = LoginForm(request.POST)
        if form.is_valid():
            u = authenticate(
                username = form.cleaned_data['email'],
                password = form.cleaned_data['password']
                )

            if u is not None:
                login(request, u)
                return success_json({
                        'redirect': next_url or '/'
                        })
            else:
                return failure
        else:
            return failure

    else:
        form = LoginForm()

    c.update({'form': form})
        
    return render_to_response('login.html', c)

def logout_view(request):
    logout(request)
    return redirect('/')

def logged_in(request):
    return (request.user and not request.user.is_anonymous())

def can_see_user(viewer, target):
    return viewer == target or \
        target.profile.access == ACCESS_PUBLIC or \
        (target.profile.access == ACCESS_FRIENDS and friends(viewer, target))



def profile_context(request, u):
    action_template = friend_action_template(request.user, u)

    my_recipes = u.recipe_set.order_by('-created_at').all()
    recipes = recipe_bookmark_merge(my_recipes, u.bookmark_set.all())

    tags = []
    for r in recipes:
        tags.extend(map(lambda rt: rt.tag, r.recipetag_set.all()))    
    tags = list(set(tags))
    tags.sort(key = lambda t : t.tag)

    num_cols = 4
    paginator = Paginator(recipes, RECIPE_PER_PAGE)
    # for Django 1.4 
    pageno = request.GET.get('page')
    # django 1.3 pageno = int(request.GET.get('page', '1'))    

    try:
        recipes = paginator.page(pageno)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        recipes = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        recipes = paginator.page(paginator.num_pages)

    recipe_columns = [[rec for (j, rec) in enumerate(recipes)
                       if j % num_cols == i] for i in range(num_cols)]

    return {
        'view_user': u,
        'is_me': u == request.user,
        'friend_action_template': action_template,
        'can_see': can_see_user(request.user, u),
        'recipes': recipes,
        'recipe_columns': recipe_columns,
        'tags': tags,
        'new_blog_post_form': BlogPostForm(),
        'blog_posts': u.profile.blog_posts(request.user),
        'events': UserFeed.objects.filter(
            user = u,
            user_own_evt = True
            ).order_by('-created')[:NUM_EVENTS]
        }

def recipe_bookmark_merge(recipes, bookmarks):
    merged = list(recipes)
    merged.extend(map(lambda b: b.recipe, bookmarks))
    merged.sort(key = lambda r: r.created_at, reverse = True)
    return merged
        
def user(request, uid):
    c = RequestContext(request)

    u = User.objects.get(id = uid)

    c.update(profile_context(request, u))
    
    if request.method == 'POST':
        if request.FILES:
            request.POST['user'] = request.user.id
            request.POST['typ'] = USER_IMAGE

            profile = request.user.profile
            profile.photo = upload_handler(
                content_file_name(request.FILES['file'].name),
                request.FILES['file'],
                request.user.email,
                is_image=True,
                thumb_width = 46, 
                thumb_height = 46
                )
            profile.save()

            return success_json({})
        else:
            if u == request.user:
                form = ProfileForm(request.POST,
                                   instance = request.user.profile)
                if form.is_valid():
                    form.save()
                    return redirect(reverse('user', args=[u.id]))
                else:
                    c.update({
                            'form': form,
                            'edit_errors': True
                            })
                    return render_to_response('profiles/profile.html', c)
            
    if u == request.user:
        form = ProfileForm(instance = request.user.profile)
        c.update({'form': form})

    return render_to_response('profiles/profile.html', c)

def profile_data(request, uid):
    c = RequestContext(request)
    u = User.objects.get(id = uid)
    c.update(profile_context(request, u))
    return render_to_response('profiles/profile_data.html', c)

def notifications(u):
    ns = Notification.objects.filter(
        target_user = u,
        seen = False
        ).order_by('-created_at')

    return ns

#@never_cache
@cache_control(must_revalidate=True, max_age=3600)
def profile_photo(request, uid):
    u = User.objects.get(id = uid)
    
    profile = u.profile
    if profile.photo:
        return download_handler(request, profile.photo, False, thumbnail = True )
    else:
        if settings.LIVE:
            return redirect(settings.STATIC_URL + 'placeholder.gif' )
    return redirect('/static/placeholder.gif')

@cache_control(must_revalidate=True, max_age=3600)
def profile_photo_big(request, uid):
    u = User.objects.get(id = uid)
    
    profile = u.profile
    if profile.photo:
        return download_handler(request, profile.photo, False, thumbnail = False )
    else:
        if settings.LIVE:
            return redirect(settings.STATIC_URL + 'placeholder.gif' )
    return redirect('/static/placeholder.gif')
    

@login_required
def delete_photo(request):
    if request.method == 'POST':
        profile = request.user.profile
        profile.photo = None
        profile.save()

        return HttpResponse()

    return HttpResponseServerError()


@login_required
def invite(request):
    c = RequestContext(request)
    c.update(csrf(request))
    if request.method == 'POST':
        form = InviteForm(request.POST)
        if form.is_valid():

            try:
                u = User.objects.get(email = form.cleaned_data['invitee'])
                result = {'user_exists': u}
            except:
                send_invite(form.cleaned_data['invitee'],
                            form.cleaned_data['message'],
                            request.user)
                result = {'invite_sent': True}
            c.update(result)
            return render_to_response('invites/invite.html', c)

    
    else:
        form = InviteForm()

    c.update({'form': form})
    return render_to_response('invites/invite.html', c)
