angular.module('channel.controllers', []).controller('ChannelCtrl', ["$scope", "$http", "$q", "$compile",
    function($scope, $http, $q, $compile) {

        $scope.groupTopics = function() {
            var newarr;
            var cards_per_column;
            if ($scope.width > 600) {
                cards_per_column = 3;
            } else if ($scope.width <= 600 && $scope.width >= 400) {
                cards_per_column = 2;
            } else {
                cards_per_column = 1;
            }
            for (i = 0, len = $scope.ungroupedTopics.length; i < len; i += cards_per_column) {
                newarr = [];
                for (var x = 0; x < cards_per_column; x++) {
                    if (angular.isDefined($scope.ungroupedTopics[i + x])) {
                        newarr.push($scope.ungroupedTopics[i + x]);
                    }
                }
                $scope.topics.push(newarr);
            }
        };

        $scope.initMap = function() {
            $scope.gmap = new google.maps.Map(document.getElementById("map_canvas"), {
                center: new google.maps.LatLng(49.277297, -123.147651),
                zoom: 8,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                mapTypeControl: false,
                panControl: false,
                draggable: true,
                zoomControl: true,
                streetViewControl: false,
                zoomControlOptions: {
                    position: google.maps.ControlPosition.LEFT_TOP,
                    style: google.maps.ZoomControlStyle.SMALL
                }
            });
            var bounds = new google.maps.LatLngBounds();
            for (i = 0, len = $scope.ungroupedTopics.length; i < len; i++) {
                var tpl = Mustache.render($scope.infobubble_tpl, $scope.ungroupedTopics[i]);
                var latlng = new google.maps.LatLng($scope.ungroupedTopics[i].aoi_center.lat, $scope.ungroupedTopics[i].aoi_center.lng);
                var marker = new google.maps.Marker({
                    position: latlng,
                    map: $scope.gmap,
                    title: $scope.ungroupedTopics[i].title,
                    icon: $scope.topic_icons.hasOwnProperty($scope.ungroupedTopics[i].category) ? $scope.topic_icons[$scope.ungroupedTopics[i].category] : null,
                    shadow: $scope.topic_icon_shadow

                });

                var info = new InfoBubble({
                    maxWidth: 220,
                    minHeight: 200,
                    maxHeight: 325,
                    content: tpl,
                    padding: 0,
                    shadowStyle: 0,
                    closeButton: '/static/img/infobubble-close-button.png',
                    backgroundClassName: 'infobubble-topic-box',
                    borderRadius: 0
                });
                marker.setOptions({
                    'info': info
                });
                google.maps.event.addListener(marker, 'click', function() {
                    // Close all info bubbles that are open.
                    for (var n = 0, tp_cnt = $scope.markers.length; n < tp_cnt; n++) {
                        var tp = $scope.markers[n];
                        if (tp.info) {
                            tp.info.close();
                        }
                    }
                    this.info.open($scope.gmap, this);
                });
                bounds.extend(latlng);
                $scope.markers.push(marker);
            }
            $scope.gmap.fitBounds(bounds);
            $scope.participant_markers = [];
            var user_icon = new google.maps.MarkerImage('/static/img/green_dot.png');
            for (var x = 0, len = $scope.participants.length; x < len; x++) {
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng($scope.participants[x].location.lat, $scope.participants[x].location.lng),
                    map: $scope.gmap,
                    icon: user_icon
                });
            }
        };

        $scope.options = options;
        $scope.ungroupedTopics = json_data.topics;
        $scope.participants = json_data.participants;
        $scope.topics = [];
        $scope.totalheight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

        if ($scope.options.show_map === "0") {
            $scope.contentheight = $scope.totalheight * 0.98;
        } else {
            $scope.mapheight = $scope.totalheight * 0.43;
            $scope.contentheight = $scope.totalheight * 0.55;
        }

        $scope.width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        $scope.markers = [];
        //Highlight featured false = show by default, if it has a value hide - weird I know
        $scope.infobubble_tpl = [
            '<figure class="topic_box{{#featured}} featured{{/featured}}">',
            '{{#featured}}<header>Featured topic</header>{{/featured}}',
            '<div class="inner">',
            '{{#image}}<a href="/topic/{{id}}/" target="_blank"><img src="{{image.url}}" alt="{{title}}"></a>{{/image}}',
            '<a href="/topic/{{id}}/" target="_blank"><h4>{{title}}</h4></a>',
            '<summary><p>{{abstract}}</p></summary>',
            '{{#is_archived}}<section><p class="ftr_pin archived">Archived</p></section>{{/is_archived}}',
            '</div></figure>'
        ].join("");

        $scope.topic_icons = {
            'government': new google.maps.MarkerImage('/static/img/marker_govt.png'),
            'private': new google.maps.MarkerImage('/static/img/marker_private.png'),
            'community': new google.maps.MarkerImage('/static/img/marker_community.png'),
            'agency': new google.maps.MarkerImage('/static/img/marker_agency.png'),
            'government-seed': new google.maps.MarkerImage('/static/img/marker_govt_seed.png')
        };
        $scope.topic_icon_shadow = new google.maps.MarkerImage("/static/img/marker_shadow.png",
            new google.maps.Size(38.0, 34.0),
            new google.maps.Point(0, 0),
            new google.maps.Point(10.0, 34.0)
        );
        $scope.groupTopics(json_data);
        $scope.initMap();
    }
]);