
DEBUG = True

# Make these unique, and don't share it with anybody.
SECRET_KEY = "0cb5cb07-b09c-4c6c-8e7b-b69ccc82392c42ab85de-9b9d-4c6b-a6b1-42da66450a50496834cf-b3b6-4a6a-80f7-28f0ab747c48"
NEVERCACHE_KEY = "a3210d7b-6949-4290-a035-08b30b8a1b00265af6ef-7481-421f-a887-a4b2318335149f43c7fb-6a2e-4a7c-b936-08801907aa02"

DATABASES = {
    "default": {
        # Ends with "postgresql_psycopg2", "mysql", "sqlite3" or "oracle".
        "ENGINE": "django.db.backends.sqlite3",
        # DB name or path to database file if using sqlite3.
        "NAME": "dev.db",
        # Not used with sqlite3.
        "USER": "",
        # Not used with sqlite3.
        "PASSWORD": "",
        # Set to empty string for localhost. Not used with sqlite3.
        "HOST": "",
        # Set to empty string for default. Not used with sqlite3.
        "PORT": "",
    }
}
