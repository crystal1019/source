/*
 * --------------------------------------------------------------------
 * Simple Password Strength Checker
 * by Siddharth S, www.ssiddharth.com, hello@ssiddharth.com
 * for Net Tuts, www.net.tutsplus.com
 * Version: 1.0, 05.10.2009 	
 * --------------------------------------------------------------------
 */


$(document).ready(function() 
{

	var strPassword;
	var charPassword=0,baseScore = 0, score = 0;
	var pass;
	var output;
	//check to see context
	if($("#id_0-password1").length>0)
	{
		var pass = $("#id_0-password1");
		var output = $("#password1");
	}
	else if($("#id_new_password1").length>0)
	{
		var pass = $("#id_new_password1");
		var output = $("#new_password1");
	}
	else
	{
		var pass = $("#id_password_1");
		var output = $("#password1");
	}
	
	var minPasswordLength = 6; 

	output.html('<div id ="text" style="width:100%;"></div><div id ="holder"style="width:220px;height:10px;">\
	<div id = "weak" style="width:25%;background-color:#da4f49;height:10px;float:left;"></div> \
	<div id="moderate"style="width:25%;background-color:#faa732;height:10px;float:left;"></div> \
	<div id="strong"style="width:25%;background-color:#5bb75b;height:10px;float:left;"></div> \
	<div id="vstrong"style="width:25%;background-color:green;height:10px;float:left;"></div></div>');
	
	var num = {};
	num.Excess = 0;
	num.Upper = 0;
	num.Numbers = 0;
	num.Symbols = 0;

	var bonus = {};
	bonus.Excess = 3;
	bonus.Upper = 4;
	bonus.Numbers = 5;
	bonus.Symbols = 5;
	bonus.Combo = 0; 
	bonus.FlatLower = 0;
	bonus.FlatNumber = 0;
	outputResult();
	pass.bind("keyup", checkVal);
	$('button[type="submit"], #dialog-ok').addClass('disabled'); 
	
function checkVal()
{
	init();
	if (charPassword.length >= minPasswordLength)
	{
		baseScore = 50;	
		analyzeString();	
		calcoutput();	
	}
	else
	{
		baseScore = 0;
	}
	outputResult();
}


function init()
{
	strPassword= pass.val();
	charPassword = strPassword.split("");	
	num.Excess = 0;
	num.Upper = 0;
	num.Numbers = 0;
	num.Symbols = 0;
	bonus.Combo = 0; 
	bonus.FlatLower = 0;
	bonus.FlatNumber = 0;
	baseScore = 0;
	score =0;
}

function analyzeString ()
{	
	for (i=0; i<charPassword.length;i++)
	{
		if (charPassword[i].match(/[A-Z]/g)) {num.Upper++;}
		if (charPassword[i].match(/[0-9]/g)) {num.Numbers++;}
		if (charPassword[i].match(/(.*[!,@,#,$,%,^,&,*,?,_,~])/)) {num.Symbols++;} 
	}
	num.Excess = charPassword.length - minPasswordLength;
	
	if (num.Upper && num.Numbers && num.Symbols)
	{
		bonus.Combo = 25; 
	}

	else if ((num.Upper && num.Numbers) || (num.Upper && num.Symbols) || (num.Numbers && num.Symbols))
	{
		bonus.Combo = 15; 
	}
	
	if (strPassword.match(/^[\sa-z]+$/))
	{ 
		bonus.FlatLower = -15;
	}
	
	if (strPassword.match(/^[\s0-9]+$/))
	{ 
		bonus.FlatNumber = -35;
	}
}
	
function calcoutput()
{
	score = baseScore + (num.Excess*bonus.Excess) + (num.Upper*bonus.Upper) + (num.Numbers*bonus.Numbers) + (num.Symbols*bonus.Symbols) + bonus.Combo + bonus.FlatLower + bonus.FlatNumber;
	
}	
	
function outputResult()
{	

	if(score==0){
		$("#text").html('<p><span class="muted">Please enter 6 or more characters</span></p>');
		$("#weak, #moderate, #strong, #vstrong").hide();
		$('button[type="submit"], #dialog-ok').addClass('disabled'); 
	}
	 if (score>0&&score<50)
	{
		$("#text").html('<p><span class="muted">Password Strength:</span><span class="text-error"> Weak</span></p>');
		$("#weak").show();
		$("#moderate, #strong, #vstrong").hide();
		$('button[type="submit"], #dialog-ok').addClass('disabled'); 	
	}
	else if (score>=50 && score<75)
	{
		$("#text").html('<p><span class="muted">Password Strength:</span><span class="text-warning"> Moderate</span></p>');
		$("#weak,#moderate").show();
		$("#strong, #vstrong").hide();
		$('button[type="submit"], #dialog-ok').removeClass('disabled'); 
	}
	else if (score>=75 && score<100)
	{
		$("#text").html('<p><span class="muted">Password Strength:</span><span class="text-success"> Strong</span></p>');
		$("#weak, #moderate, #strong").show();
		$("#vstrong").hide();
		$('button[type="submit"], #dialog-ok').removeClass('disabled'); 
	}
	else if (score>=100)
	{
		$("#text").html('<p><span class="muted">Password Strength:</span><span style="color:green;"> Very Strong</span></p>');
		$("#weak,#moderate, #strong, #vstrong").show();
		$('button[type="submit"], #dialog-ok').removeClass('disabled'); 
	}
	
}
	

}
); 
