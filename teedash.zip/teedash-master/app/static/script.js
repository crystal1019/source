
$(document).ready(function(){
  var content;

  //Handle clicks on each button
  $('#topcamp').click(function(){

    $('#query_type').val('topcamp');
    var topDate = $('#topDate').val();
    $('#param').val(topDate);

    pushForm();

  });

  $('#justtip').click(function(){

    $('#query_type').val('justtip');

    var d = new Date();
    var month = d.getMonth()+1;
    var day = d.getDate()-3;
    var output = d.getFullYear() + '-' + month + '-' + day;

    $('#param').val(output);

    pushForm();
  });

  $('#keywordcamp').click(function(){

    $('#query_type').val('keywordcamp');
    var keyword = $('#keyword').val();
    $('#param').val(keyword);

    pushForm();


  });

});

function pushForm() {
  $.ajax({
        type:'get',
        url: '/process',
        cache:false,
        async:false,
        data: $('#queryform').serialize(),        
        success: function(data) {
          console.log("success");
          console.log(data);
          content = data;
          $('#results').html(data);
      },
        error:function(data) {
         console.log("error");
         $('#results').html("<h1>Sorry! The Teespring infrastructure is a piece of shit and you broke it!</h1>");
      }
     });
};