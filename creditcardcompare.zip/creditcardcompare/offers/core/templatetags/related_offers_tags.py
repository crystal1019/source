from django import template
from django.conf import settings
from django.db.models import Q

register = template.Library()

from offers.core.templatetags import varname_re

class RelatedOffersNode(template.Node):
    def __init__(self, offer, varname, max_entries):
        self.offer = template.Variable(offer)
        self.varname = varname
        self.max_entries = max_entries

    def render(self, context):
        offer = self.offer.resolve(context)
        related_offers = offer.related_offers
        context[self.varname] = list()
        for related_offer in related_offers:
            if related_offer.outbound_url and 0 != len(related_offer.outbound_url):
                context[self.varname].append(related_offer)
                if len(context[self.varname]) == self.max_entries:
                    break
        return ''
    
class OfferSortOrder(template.Node):
    def __init__(self, offer, category, varname):
        self.offer = template.Variable(offer)
        self.category = template.Variable(category)
        self.varname = varname

    def render(self, context):
        offer = self.offer.resolve(context)
        category = self.category.resolve(context)
        context[self.varname] = offer.offercategory_set.get(category=category).sort_order \
                                or 1 # 0 and 1 have the same design
        return ''
    
@register.tag(name='get_sort_order')
def do_get_sort_order(parser, token):
    try:
        tag_name, offer, category, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    return OfferSortOrder(offer, category, varname)

@register.tag(name='get_related_offers')
def do_get_related_offers(parser, token):
    try:
        tag_name, offer, _as, varname, max_entries = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 4 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    try:
        max_entries = int(max_entries)
    except:
        raise template.TemplateSyntaxError, '%r tag. max_entries must be a number.' % (tag_name)

    return RelatedOffersNode(offer, varname, max_entries)
