import re
from BeautifulSoup import BeautifulSoup 

def insert_toc(function_to_decorate):
    def wrapper(request, *args, **kwargs):
        response = function_to_decorate(request, *args, **kwargs)
        if request.session['is_mobile']:
            return response
        soup = BeautifulSoup(response.content)
        toc_tags = soup.findAll(id=re.compile('^toc_*'))
        if len(toc_tags)==1:
            soup.find(id='table-of-contents').decompose()
            response.content = soup.renderContents()
            return response
        html = ''
        for tag in toc_tags:
            html += '<li><a href="#%s">%s</a></li>' % (dict(tag.attrs)['id'], tag.getText())
        try:
            soup.find(id='table-of-contents').ol.append(BeautifulSoup(html))
        except AttributeError:
            pass
        else:
            response.content = soup.renderContents()
        return response
    return wrapper