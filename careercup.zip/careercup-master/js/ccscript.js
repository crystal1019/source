function gup( name )
{
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results == null )
    return "";
  else
    return results[1];
}

function loadWidgetBody(user, user_id, author_name, date_string, image, text, uid, is_admin, read_url, edit_url, votes, type) {
    var author = author_name;
    if (user) {
        author = '<a href="/user?id=' + user_id + '">' + user + '</a>';
    }
    var picture = "0";
    if (image) {
        picture = image;
    }
    var admin_link = '';
    if (is_admin == 'True') {
        admin_link = ' <span class="widgetEditLink">| <a href="/' + edit_url + '?id=' + uid + '">Edit</a></span>';
    }
    if (read_url) {
        url = '/' + read_url + '?id=' + uid;
        read_url = '<span class="widgetMore"> <a href="' + url + '">Read More &raquo;</a></span>';
        text = '<a href="' + url + '">' + text + '</a>';
    }
    var vote_html = "";
    if (votes) {
        var form = '<form method="post" action="/submitvote?id=' + uid + '&type=' + type + '"><div class="approvalImages"><input type="image" src="/images/thumbsup.png" name="vote" value="yes"> <input type="image" src="/images/thumbsdown.png" name="vote" value="no"></div></form>';
        vote_html = '<td width="40">' 
                        + '<div class="approvalLarge">'
                            + '<div class="approvalLargeLabel">+' + votes + '</div>'
                            + '<div class="approvalSmallLabel">Votes</div>'
                        + '</div>' + form
                    + '</td>';
    }
    var html = '<div class="widgetBody">'
                    + '<table cellpadding="3" width="100%">'
                        + '<tr valign="top">'
                            + '<td width="66">'
                                + '<div class="widgetPicture">'
                                    + '<img src="/images/' + image + '_small.png" width="64">' 
                                + '</div>' 
                            + '</td>' 
                            + '<td>' 
                                + '<div class="widgetText">' + text + read_url + '</div>' 
                                + '<div class="widgetAuthorInfo">' 
                                    + '- ' + author + ' on <span class="questionDate"> ' + date_string + admin_link                               
                                + '</div>' 
                            + '</td>' 
                            + vote_html
                        + '</tr>' 
                    + '</table>' 
                + '</div>';
    return html;
}

function gotoPage(url) {
    window.location = url;
}

function newWindow(url) {
	var popupWindow = window.open(url + '#bottom', 'Reply', 'height=500, width=800, left=100, top=100, resizable=yes, scrollbars=yes, toolbar=no, menubar=no, location=no, directories=no, status=yes');
}

function newWindowTop(url) {
	var popupWindow = window.open(url,'Reply','height=500, width=800, left=100, top=100, resizable=yes, scrollbars=yes, toolbar=no, menubar=no, location=no, directories=no, status=yes');
}

function mergeTextAndCommentCount(text, count) {
    if (count != 'None' && count != '0') {
        text += ' <span class="commentCount">(' + count + ' <img src="/images/comment.gif"/>)</span>';
    }
    return text
}

function hideControl(id) {
    control = document.getElementById(id)
    if (control) {
        control.style.display = 'none'; 
        tab = document.getElementById("header" + id);
        if (tab) {
            tab.className = 'pageTabTitle';
        }
    }
}

function showControl(id) {
    control = document.getElementById(id)
    if (control) {
        control.style.display = '';
        tab = document.getElementById("header" + id);    
        if (tab) {
            tab.className = "pageTabTitleActive";
        }
    }
}

function stringContains(s, t) {
	if (s.indexOf(t) > -1) {
		return true;
	}
	return false;
}

function tryClear() {
	if (!this.is_cleared) {
		var e = document.getElementById('searchbox');
		e.value = '';
		e.className = 'blacktext';
		this.is_cleared = false;
	}
}

function makeTabActive(tab) {
	var tab = document.getElementById(tab);
	if (tab) {
		tab.className = "page_navigation_active_li";
		tab.innerHTML = tab.innerHTML.replace("inactive", "active").replace("inactive", "active");
	}
}

function getCookie(c_name)
{
	if (document.cookie.length>0)
	  {
	  c_start=document.cookie.indexOf(c_name + "=");
	  if (c_start!=-1)
	    {
	    c_start=c_start + c_name.length+1;
	    c_end=document.cookie.indexOf(";",c_start);
	    if (c_end==-1) c_end=document.cookie.length;
	    return unescape(document.cookie.substring(c_start,c_end));
	    }
	  }
	return "";
}

function setCookie(c_name, value)
{
	document.cookie=c_name+ "=" +escape(value);
}

function getReferrer()
{
	var ref = document.referrer;
	if (stringContains(ref, 'careercup.com')) { // If referrer from CareerCup, get cached referrer
		ref = getCookie('ref');
	} else {
		setCookie('ref', ref); // Else, use document.referrer and cache referrer
	}
	return ref;
}

function updateReferrers(url) {
	var links = document.getElementsByTagName('a');
	var iframes = document.getElementsByTagName('iframe');
	var ref = getReferrer();
	var affiliate = 0;
	var amzn_affiliate = "";
	if (stringContains(ref, 'http://www.glassdoor.com') || stringContains(ref, 'http://www.wetfeet.com')) {
		affiliate = 104575;
	} else if (stringContains(ref, 'http://www.softwareinterview.com')) {
		affiliate = 84306;
	} else if (stringContains(ref, 'http://halcyon.usc.edu/~kiran')) {
		affiliate = 104753;
		amzn_affiliate = "careercupkiran-20";
	} else if (stringContains(ref, 'http://technical-interview.com')) {
		affiliate = 130537;
	} else if (stringContains(ref, 'http://www.technical-interview.com')) {
		affiliate = 130537;
	} else if (stringContains(ref, 'http://www.mytechinterviews.com')) {
		affiliate = 139226;
	} else if (stringContains(ref, 'http://mytechinterviews.com')) {
		affiliate = 139226;
	}  else if (stringContains(ref, 'careerbliss.com') || stringContains(ref, 'cybercoders.com')) {
		affiliate = 162685;
		amzn_affiliate = "careercupcb-20";
	}  
	if (affiliate != 0) {
		for (var i = 0; i < links.length; i++) {
			var link = links[i];
			if (stringContains(link.href, 'cl=84190')) {
				link.href = link.href.replace('cl=84190', 'cl=84190&aff=' + affiliate);
			}
		}
	}
	if (amzn_affiliate != "") {
		for (var i = 0; i < links.length; i++) {
			var link = links[i];
			if (stringContains(link.href, 'care01-20')) {
				link.href = link.href.replace('care01-20', amzn_affiliate);
			}		
		}
		for (var i = 0; i < iframes.length; i++) {
			var iframe = iframes[i];
			if (stringContains(iframe.src, 'care01-20')) {
				iframe.src = iframe.src.replace('care01-20', amzn_affiliate);
			}		
		}
	}	
}

function setCookie(name, value, expires) {	
	document.cookie = name + "=" + escape(value) + "; path=/" + ((expires == null) ? "" : "; expires=" + expires.toGMTString()); 
}

function setChatDisabled(v) {
	setCookie("disableChat", v);
	if (confirm("Refresh page?")) {
		location.reload(true);
	}
}

function putChat() {
	var val = getCookie("disableChat");
	if (val == "1") {
		$('#disableChatText').html('<a onclick="javascript:setChatDisabled(0);" style="cursor:pointer;">Enable Chat</a>.');
	} else {
		document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));
		$('#disableChatText').html('<a onclick="javascript:setChatDisabled(1);" style="cursor:pointer;">Disable Chat</a>.');
	}
}

function getCookie( check_name ) {
	// first we'll split this cookie up into name/value pairs
	// note: document.cookie only returns name=value, not the other components
	var a_all_cookies = document.cookie.split( ';' );
	var a_temp_cookie = '';
	var cookie_name = '';
	var cookie_value = '';
	var b_cookie_found = false; // set boolean t/f default f

	for ( i = 0; i < a_all_cookies.length; i++ )
	{
		// now we'll split apart each name=value pair
		a_temp_cookie = a_all_cookies[i].split( '=' );


		// and trim left/right whitespace while we're at it
		cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');

		// if the extracted name matches passed check_name
		if ( cookie_name == check_name )
		{
			b_cookie_found = true;
			// we need to handle case where cookie has no value but exists (no = sign, that is):
			if ( a_temp_cookie.length > 1 )
			{
				cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
			}
			// note that in cases where cookie is initialized but no value, null is returned
			return cookie_value;
			break;
		}
		a_temp_cookie = null;
		cookie_name = '';
	}
	if ( !b_cookie_found )
	{
		return null;
	}
}


_activeProductTab = "headerProductBooks";
_activeProductBody = "headerProductBodyBooks";

function switchToProduct(prodTab, prodBody) {
	if (_activeProductTab != null && _activeProductTab != "") {
		var e = document.getElementById(_activeProductTab);
		e.className = 'header_product_tabs';
		_activeProductTab = null;
	}
	if (_activeProductBody != null && _activeProductBody != "") {
		var e = document.getElementById(_activeProductBody);
		e.style.display = 'none';
		_activeProductBody = null;
	}
	
	if (prodTab != null && prodTab != "") {
		var e = document.getElementById(prodTab);
		e.className = 'header_product_tabs_active';
		_activeProductTab = prodTab;
	}
	if (prodBody != null && prodBody != "") {
		var e = document.getElementById(prodBody);
		e.style.display = '';
		_activeProductBody = prodBody;
	}			
}

function postToUrl(path, params, method) {
    method = method || "post"; // Set method to post by default, if not specified.

    // The rest of this code assumes you are not using a library.
    // It can be made less wordy if you use one.
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);

    for(var key in params) {
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", key);
        hiddenField.setAttribute("value", params[key]);

        form.appendChild(hiddenField);
    }

    document.body.appendChild(form);
    form.submit();
}

function postVoteResponse(commentId, net, count) {
	$('#votesNet' + commentId).html(net);
	$('#votesCountActual' + commentId).html(count);	
}

var disabled = {};

function vote(val, commentId) {
	vote(val, commentId, 'comment')
}

function vote(val, commentId, vote_type) {
	if (disabled[commentId]) {
		return;	
	}
	if (_user_id == null) {
		window.location = _url;
		return;
	}
	disabled[commentId] = true;
	
	var params = {}
	params["val"] = val;
	params["commentId"] = commentId;
	params["vote_type"] = vote_type;
	params["redirection"] = document.location.href;
	
	var count_original = parseInt($('#votesCountActual' + commentId).html());
	var net_original = parseInt($('#votesNet' + commentId).html());
	
	var count = count_original + 1;
	var net = net_original + val;	
	postVoteResponse(commentId, net, count);

	$('#ajax_vote_handler').load('/vote #vote', params, 
    	function(response, status, xhr) {
    		disabled[commentId] = false;
    		if (response == 'login') {
    			window.location = _url;
    		} else if (response != '') { 
    			var parts = response.split('#');
    			var net = parseInt(parts[0]);
    			var count = parseInt(parts[1]);
    			postVoteResponse(commentId, net, count);
    		} else {
    			postVoteResponse(commentId, net_original, count_original);
    		}
		}
	);
}

function getItemNameForFavorite(item_id, item_type) {
	if (item_type == 'forum-all') {
		return item_name = item_type + 'favorite';
	} else {
		return item_name = item_type + item_id + 'favorite';
	}
}

function postFavoriteResponse(item_id, val, item_type) {
	var item_name = getItemNameForFavorite(item_id, item_type);
	if (val == 1) {
		$('#' + item_name).attr('alt', 'Unfollow');
		$('#' + item_name).attr('title', 'Unfollow');
		$('#' + item_name).removeClass('favoriteOff').addClass('favoriteOn');
	} else if (val == -1) {
		$('#' + item_name).attr('alt', 'Follow');
		$('#' + item_name).attr('title', 'Follow');	
		$('#' + item_name).removeClass('favoriteOn').addClass('favoriteOff');
	}
}

function addFavorite(itemId, vote_type) {
	if (disabled[itemId]) {
		return;	
	}
	if (_user_id == null) {
		window.location = _url;
		return;
	}
	disabled[itemId] = true;
	
	var params = {};
	var val;
	var item_name = getItemNameForFavorite(itemId, vote_type);
	if ($('#' + item_name).hasClass('favoriteOff')) {
		val = 1;
	} else {
		val = -1;
	}
	params["val"] = val;
	params["itemId"] = itemId;
	params["item_type"] = vote_type;
	params["redirection"] = document.location.href;
	
	postFavoriteResponse(itemId, val, vote_type);
	
	$('#ajax_vote_handler').load('/addfavorite #addfavorite', params, 
    	function(response, status, xhr) {
    		disabled[itemId] = false;
    		if (response == 'login') {
    			window.location = _url;
    		} else if (response != '') { 
    			postFavoriteResponse(itemId, parseInt(response), vote_type);
    		}
		}
	);
}

function writeBookLink(book, body, additional) {
	var link = "";
	if (book == "ctci") {
		if (country_origin == "IN") {
			link = 'http://www.flipkart.com/books/098478280X&&affid=supportcar';
		} else if (country_origin == 'GB') {
			link = 'http://www.amazon.co.uk/gp/product/098478280X/ref=as_li_ss_tl?ie=UTF8&tag=care0a-21&linkCode=as2&camp=1634&creative=19450&creativeASIN=098478280X';
		} else if (country_origin == 'DE') {
			link = 'http://www.amazon.de/gp/product/098478280X/ref=as_li_ss_tl?ie=UTF8&tag=careercup08-21&linkCode=as2&camp=1638&creative=19454&creativeASIN=098478280X';
		} else if (country_origin == 'FR') {
			link = 'http://www.amazon.fr/gp/product/098478280X/ref=as_li_ss_tl?ie=UTF8&tag=care05-21&linkCode=as2&camp=1642&creative=19458&creativeASIN=098478280X'
		} else if (country_origin == 'ES') {
			link = 'http://www.amazon.es/gp/product/844153523X/ref=as_li_ss_tl?ie=UTF8&tag=care00-21&linkCode=as2&camp=3626&creative=24822&creativeASIN=098478280X'
		} else if (country_origin == 'CA') {
			link = 'http://www.amazon.ca/gp/product/098478280X/ref=as_li_ss_tl?ie=UTF8&camp=15121&creative=390961&creativeASIN=098478280X&linkCode=as2&tag=care0c4-20'
		} else {
			link = 'http://www.amazon.com/gp/product/098478280X/ref=as_li_ss_tl?ie=UTF8&tag=care01-20&linkCode=as2&camp=217145&creative=399373&creativeASIN=098478280X';
		}
	} else if (book == "ctpmi") {
		if (country_origin == "IN") {
			link = 'http://pothi.com/pothi/book/gayle-laakmann-mcdowell-cracking-pm-interview';
		} else if (country_origin == 'GB') {
			link = 'http://www.amazon.co.uk/gp/product/0984782818/ref=as_li_ss_tl?ie=UTF8&tag=care0a-21&linkCode=as2&camp=1634&creative=19450&creativeASIN=0470927623';
		} else if (country_origin == 'DE') {
			link = 'http://www.amazon.de/gp/product/0984782818/ref=as_li_ss_tl?ie=UTF8&tag=careercup08-21&linkCode=as2&camp=1638&creative=19454&creativeASIN=0470927623';
		} else if (country_origin == 'FR') {
			link = 'http://www.amazon.fr/gp/product/0984782818/ref=as_li_ss_tl?ie=UTF8&tag=care0a-21&linkCode=as2&camp=1642&creative=19458&creativeASIN=0470927623';
		} else if (country_origin == 'ES') {
			link = 'http://www.amazon.es/gp/product/0984782818/ref=as_li_ss_tl?ie=UTF8&tag=care00-21&linkCode=as2&camp=3626&creative=24822&creativeASIN=0470927623';
		} else if (country_origin == 'CA') {
			link = 'http://www.amazon.ca/gp/product/0984782818/ref=as_li_ss_tl?ie=UTF8&camp=15121&creative=390961&creativeASIN=0470927623&linkCode=as2&tag=care0c4-20';
		} else {
			link = 'http://www.amazon.com/gp/product/0984782818/ref=as_li_ss_tl?ie=UTF8&tag=care01-20&linkCode=as2&camp=217145&creative=399373&creativeASIN=0470927623';
		}				
	} else if (book == "tgr") {
		if (country_origin == "IN") {
			link = 'http://www.flipkart.com/books/8126538058?affid=supportcar';
		} else if (country_origin == 'GB') {
			link = 'http://www.amazon.co.uk/gp/product/0470927623/ref=as_li_ss_tl?ie=UTF8&tag=care0a-21&linkCode=as2&camp=1634&creative=19450&creativeASIN=0470927623';
		} else if (country_origin == 'DE') {
			link = 'http://www.amazon.de/gp/product/0470927623/ref=as_li_ss_tl?ie=UTF8&tag=careercup08-21&linkCode=as2&camp=1638&creative=19454&creativeASIN=0470927623';
		} else if (country_origin == 'FR') {
			link = 'http://www.amazon.fr/gp/product/098478280X/ref=as_li_ss_tl?ie=UTF8&tag=care0a-21&linkCode=as2&camp=1642&creative=19458&creativeASIN=0470927623';
		} else if (country_origin == 'ES') {
			link = 'http://www.amazon.es/gp/product/844153523X/ref=as_li_ss_tl?ie=UTF8&tag=care00-21&linkCode=as2&camp=3626&creative=24822&creativeASIN=0470927623';
		} else if (country_origin == 'CA') {
			link = 'http://www.amazon.ca/gp/product/0470927623/ref=as_li_ss_tl?ie=UTF8&camp=15121&creative=390961&creativeASIN=0470927623&linkCode=as2&tag=care0c4-20';
		} else {
			link = 'http://www.amazon.com/gp/product/0470927623/ref=as_li_ss_tl?ie=UTF8&tag=care01-20&linkCode=as2&camp=217145&creative=399373&creativeASIN=0470927623';
		}		
	}
	var f = '<a href="' + link + '" ' + additional + ' >' + body + '</a>';
	document.write(f);
}

function writeBookCode(book, showborder) {
	var borderstr = showborder == true ? "&border=yes" : "";
	var borderstr_amzn = showborder == true ? "000000" : "FFFFFF";
	if (book == "ctci") {
		if (country_origin == "IN") {
			document.write('<iframe src="http://www.flipkart.com/affiliateWidget/simpleBanner?bc=FFFFFF&tc=333333&lc=091670&buy=yes&affid=supportcar&id=ACX3FWPS4C&type=3&price=yes' + borderstr + '&height=260&width=120" style="width:120px;height:260px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');
		} else if (country_origin == "GB") {
			document.write('<iframe src="http://rcm-uk.amazon.co.uk/e/cm?lt1=_blank&bg1=FFFFFF&IS2=1&bc1=' + borderstr_amzn + '&fc1=000000&lc1=0000FF&t=care0a-21&o=2&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');			
		} else if (country_origin == "DE") {
			document.write('<iframe src="http://rcm-de.amazon.de/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=careercup08-21&o=3&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "FR") {
			document.write('<iframe src="http://rcm-fr.amazon.fr/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care05-21&o=8&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "ES") {
			document.write('<iframe src="http://rcm-es.amazon.es/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care00-21&o=30&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=844153523X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "CA") {
			document.write('<iframe src="http://rcm-ca.amazon.ca/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care0c4-20&o=15&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else {
			document.write('<iframe src="http://rcm.amazon.com/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care01-20&o=1&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');
		}
	} else if (book == "ctpmi") {
		if (country_origin == "IN") {
			document.write('<iframe src="http://www.flipkart.com/affiliateWidget/simpleBanner?bc=FFFFFF&tc=333333&lc=091670&buy=yes&affid=supportcar&id=ACX3FWPS4C&type=3&price=yes' + borderstr + '&height=260&width=120" style="width:120px;height:260px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');
		} else if (country_origin == "GB") {
			document.write('<iframe src="http://rcm-uk.amazon.co.uk/e/cm?lt1=_blank&bg1=FFFFFF&IS2=1&bc1=' + borderstr_amzn + '&fc1=000000&lc1=0000FF&t=care0a-21&o=2&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0984782818" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');			
		} else if (country_origin == "DE") {
			document.write('<iframe src="http://rcm-de.amazon.de/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=careercup08-21&o=3&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0984782818" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "FR") {
			document.write('<iframe src="http://rcm-fr.amazon.fr/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care05-21&o=8&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "ES") {
			document.write('<iframe src="http://rcm-es.amazon.es/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care00-21&o=30&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0984782818" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "CA") {
			document.write('<iframe src="http://rcm-ca.amazon.ca/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care0c4-20&o=15&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0984782818" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else {
			document.write('<iframe src="http://rcm.amazon.com/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care01-20&o=1&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0984782818" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');
		}
	} else if (book == "tgr") {
		if (country_origin == "IN") {
			document.write('<iframe src="http://www.flipkart.com/affiliateWidget/simpleBanner?bc=FFFFFF&tc=333333&lc=091670&buy=yes&affid=supportcar&id=8126538058&type=3&price=yes' + borderstr + '&height=260&width=120" style="width:120px;height:260px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');
		} else if (country_origin == "GB") {		
			document.write('<iframe src="http://rcm-uk.amazon.co.uk/e/cm?lt1=_blank&bg1=FFFFFF&IS2=1&bc1=' + borderstr_amzn + '&fc1=000000&lc1=0000FF&t=care0a-21&o=2&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0470927623" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');							
		} else if (country_origin == "DE") {
			document.write('<iframe src="http://rcm-de.amazon.de/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=careercup08-21&o=3&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0470927623" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "FR") {
			document.write('<iframe src="http://rcm-fr.amazon.fr/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care05-21&o=8&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0470927623" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');					
		} else if (country_origin == "ES") {
			document.write('<iframe src="http://rcm-es.amazon.es/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care00-21&o=30&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=844153523X" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else if (country_origin == "CA") {
			document.write('<iframe src="http://rcm-ca.amazon.ca/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care0c4-20&o=15&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0470927623" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');				
		} else {
			document.write('<iframe src="http://rcm.amazon.com/e/cm?lt1=_blank&bc1=' + borderstr_amzn + '&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=care01-20&o=1&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=0470927623" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>');
		}		
	}
}

function switchTab(t) {
	var tabs = ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7"];
	for (var i in tabs) {
		var name = tabs[i];
		if (name == t) {
			$('#' + name).show();
			$('#header' + name).addClass('pageTabTitleActive'); 
		} else {
			$('#' + name).hide(); 
			$('#header' + name).removeClass('pageTabTitleActive'); 
		}
	}	
}

function setSelectionRange(input, selectionStart, selectionEnd) {
  if (input.setSelectionRange) {
    input.focus();
    input.setSelectionRange(selectionStart, selectionEnd);
  }
  else if (input.createTextRange) {
    var range = input.createTextRange();
    range.collapse(true);
    range.moveEnd('character', selectionEnd);
    range.moveStart('character', selectionStart);
    range.select();
  }
}

function replaceSelection (input, replaceString) {
	if (input.setSelectionRange) {
		var selectionStart = input.selectionStart;
		var selectionEnd = input.selectionEnd;
		input.value = input.value.substring(0, selectionStart)+ replaceString + input.value.substring(selectionEnd);
    
		if (selectionStart != selectionEnd){ 
			setSelectionRange(input, selectionStart, selectionStart + 	replaceString.length);
		} else{
			setSelectionRange(input, selectionStart + replaceString.length, selectionStart + replaceString.length);
		}
	}else if (document.selection) {
		var range = document.selection.createRange();

		if (range.parentElement() == input) {
			var isCollapsed = range.text == '';
			range.text = replaceString;

			 if (!isCollapsed)  {
				range.moveStart('character', -replaceString.length);
				range.select();
			}
		}
	}
}

function showFavorites(favorites, item_type) {
	if (item_type == 'forum-all') {
		postFavoriteResponse(null, 1, item_type);
	} else {
		if (favorites != null) {
			for (var i = 0; i < favorites.length; i++) {
				postFavoriteResponse(favorites[i], 1, item_type);
			}
		}
	}
}

function showFavorite(fav, item_type) {
	if (item_type == 'forum-all') {
		postFavoriteResponse(null, 1, item_type);
	} else {
		postFavoriteResponse(fav, 1, item_type);
	}
}

function showUserInfo(userid) {
	$('.authorShow' + userid).show();
	$('.authorHide' + userid).hide();
}

function showAdminInfo() {
	$('.adminShow').show();
	$('.adminHide').hide();
}

function uncollapseComment(commentId) {
	$('#collapsedComment' + commentId).hide();
	$('#uncollapsedComment' + commentId).slideDown();
}


// We are going to catch the TAB key so that we can use it, Hooray!
function catchTab(item,e) {
	if (navigator.userAgent.match("Gecko")) {
		c=e.which;
	} else {
		c=e.keyCode;
	}
	if (c==9) {
		replaceSelection(item,String.fromCharCode(9));
		setTimeout("document.getElementById('"+item.id+"').focus();",0);	
		return false;
	}
}

function insertReply(comment_form_type, comment_parent_id, comment_ancestor_id) { 
	var commenthtml = $('#addCommentMain').html();
	commenthtml = commenthtml.replace("parent=" + comment_parent_id, "parent=" + comment_parent_id);
	commenthtml = commenthtml.replace('id="addCommentMain"', 'id="addCommentMain"' + comment_parent_id);
	commenthtml = commenthtml.replace('submitting' + comment_ancestor_id, 'submitting' + comment_parent_id);
	$('#insertReplyHere' + comment_parent_id).html(commenthtml);
	$('#insertReplyHere' + comment_parent_id).slideDown();
	$('#replyButton' + comment_parent_id).hide();
	var button = $('#insertReplyHere' + comment_parent_id).find('input[type=submit]');
	var js = 'javascript:postComment(\'' + comment_form_type + '\',' + comment_parent_id + ',' + comment_ancestor_id + ');';
	button.attr('onclick', js);
}



function postComment(comment_form_type, comment_parent_id, comment_ancestor_id) {
	var reply_name = '#insertReplyHere' + comment_parent_id;
	var username = $(reply_name).find("input[name='AuthorName']");
	username.attr("disabled", true);
	var body = $(reply_name).find("textarea");
	body.attr("disabled", true);
	var button = $('#insertReplyHere' + comment_parent_id).find('input[type=submit]');
	button.attr("disabled", true);
	button.hide();
	$('#submitting' + comment_parent_id).show();
	
	params = {'Comment': body.val(), 'AuthorName': username.val()};
	var url = '/addcomment?type=' + comment_form_type + '&parent=' + comment_parent_id + '&ancestor=' + comment_ancestor_id + '&form=comments';

	$('#ajax_vote_handler').load(url, params, 
    	function(response, status, xhr) {
    		if (response != '') {
    			$('#commentThread' + comment_parent_id).html(response);
    			refreshUserAdminInfo();
    		}
		}
	);	
}

function buildUrl(root, params) {
	var url = root;
	var first = true;
	for (var key in params) {
		if (params[key] && params[key] != "") {
			if (first) {
				url += "?";
				first = false;
			} else {
				url += "&";
			}
			url += key;
			url += "=";
			url += params[key];
		}
	}
	return url;
}

function getParamMap(keys) {
	var params = {};
	for (var k in keys) {
		var key = keys[k];
		var value = gup(key);
		if (value && value != "") {
			params[key] = value;
		}
	}
	return params;
}

function getSortUrl(sortby)
{
	var params = getParamMap(keys);
	params["sort"] = sortby;
	var url = buildUrl(root, params);
	return url;
}

function doFilterSort()
{
	var url = root;
	var first = true;
	for (var control in controls)
	{
		var c = document.getElementById(controls[control]);
		if (c)
		{
			id = c.value;
			if (id)
			{
				if (first) {
					url += '?pid=' + id;
					first = false;
				} else {
					url += '&' + controls[control] + '=' + id;
				}
				
			}
		}
	}
	gotoPage(url);
}