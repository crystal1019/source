javascript:(function(e,a,g,h,f,c,b,d){if(!(f=e.jQuery)||g>f.fn.jquery||h(f)){c=a.createElement("script");c.type="text/javascript";c.src="http://ajax.googleapis.com/ajax/libs/jquery/"+g+"/jquery.min.js";c.onload=c.onreadystatechange=function(){if(!b&&(!(d=this.readyState)||d=="loaded"||d=="complete")){h((f=e.jQuery).noConflict(1),b=1);f(c).remove()}};a.documentElement.childNodes[0].appendChild(c)}})(window,document,"1.3.2",function($,L){
    function handler(evt) {
	evt.preventDefault();
	var img_src = evt.target.src;
	window.open("http://www.recipedrop.com/recipes/new?img=" + img_src + "&link=" + document.location.href, "_blank");
	$("img").unbind("click", handler);
	$("img").unbind("hover", hoverer);
    }
    function hoverer(evt) {
	$(evt.target).css("cursor", "pointer");
	$(evt.target).css("cursor", "hand");
	$(evt.target).fadeOut(500);
	$(evt.target).fadeIn(500);
    }
    $("img").click(handler);
    $("img").hover(hoverer);

    var $instructions = $("<div><b>Click an image to create a recipe for this page. Your recipe will open in a new tab or window.</b></div>");
    $instructions.css('position', 'fixed').css('top', '1em').css('right', '1em');
    $instructions.css('padding', '15px').css('border', '2px solid #166DD1').css('background-color', '#EFEFEF');
    $instructions.css('font-family', 'Helvetica').css('font-size', '13px');
    $instructions.css('z-index', '50000');
    $('body').append($instructions);
});