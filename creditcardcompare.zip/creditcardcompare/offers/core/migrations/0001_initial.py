# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.db.models.manager
import django.contrib.sites.managers


class Migration(migrations.Migration):

    dependencies = [
        ('sites', '0001_initial'),
        ('lead', '__first__'),
    ]

    operations = [
        migrations.CreateModel(
            name='BalanceTransfer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('until', models.IntegerField(help_text=b'Minimum card ownership period to allow balance transfer.', null=True, blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='BankProfile',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('contact_page_url', models.URLField(null=True, blank=True)),
                ('local_phone', models.CharField(max_length=250, null=True, blank=True)),
                ('intl_phone', models.CharField(max_length=250, null=True, blank=True)),
                ('opening_hours', models.TextField(null=True, blank=True)),
                ('image', models.ImageField(help_text='Small-sized bank logo.', max_length=115, upload_to=b'uploads/categories/', blank=True)),
                ('image_big', models.ImageField(upload_to=b'uploads/categories/', max_length=115, blank=True, help_text='Big-sized bank logo.', null=True, verbose_name=b'Image (big)')),
                ('available_in', models.ManyToManyField(to='lead.State')),
            ],
            options={
                'ordering': ('issuer__name',),
            },
        ),
        migrations.CreateModel(
            name='BankType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(help_text=b'E.g. Credit Union, Mutual Bank, etc.', max_length=50, null=True, verbose_name=b'Bank Type', blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('slug', models.SlugField(unique=True, max_length=128, verbose_name='url slug', blank=True)),
                ('creation_date', models.DateTimeField(verbose_name='created on', editable=False, blank=True)),
                ('last_modification_date', models.DateTimeField(verbose_name='last modified on', editable=False, blank=True)),
                ('slider', models.SmallIntegerField(default=0, help_text=b'Used in CCC to specify which slider filter to use.', verbose_name=b'Slider Type', choices=[(0, b'None'), (1, b'Savings (BT)'), (2, b'Earnings'), (3, b'Savings (Purchase)')])),
                ('publication_date', models.DateTimeField(help_text='The date when Balance Transfer Rate and Intro Purchase Rate expires.', null=True, verbose_name='expires on', blank=True)),
                ('name', models.CharField(max_length=256, verbose_name='name')),
                ('is_visible', models.BooleanField(default=True, help_text='if checked, all offers in this category will be visible', verbose_name='is visible')),
                ('hero', models.ImageField(help_text=b'Hero image to be used in the page of this category.', upload_to=b'uploads/categories/', null=True, verbose_name=b'Hero Image', blank=True)),
                ('hero_mobile', models.ImageField(help_text=b'Hero image to be used in the page of this category.', upload_to=b'uploads/categories/', null=True, verbose_name=b'Hero Image (mobile)', blank=True)),
                ('parent', models.ForeignKey(related_name='children', blank=True, to='core.Category', help_text='this is used for nesting categories. Any offer that belongs to a category will also belong to its parent categories', null=True)),
            ],
            options={
                'ordering': ('name',),
                'verbose_name': 'category',
                'verbose_name_plural': 'categories',
            },
            managers=[
                (b'objects', django.db.models.manager.Manager()),
                (b'on_site', django.contrib.sites.managers.CurrentSiteManager(b'sites')),
            ],
        ),
        migrations.CreateModel(
            name='MetaField',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=64, verbose_name='key')),
                ('default', models.TextField(help_text='default value for any offer that uses this meta', null=True, verbose_name='default value', blank=True)),
                ('is_sortable', models.BooleanField(default=False, help_text='allows the meta to be used in a table list', verbose_name='is sortable')),
                ('has_filter', models.SmallIntegerField(default=0, help_text='Order of slider in filters. Set to 0 to disable.', verbose_name='filter order')),
                ('prefix', models.CharField(help_text='prefix for value when value is displayed (leading and trailing whitespace is preserved), e.g. $', max_length=16, null=True, verbose_name='prefix', blank=True)),
                ('suffix', models.CharField(help_text='suffix for value when value is displayed (leading and trailing whitespace is preserved), e.g. %', max_length=20, null=True, verbose_name='suffix', blank=True)),
            ],
            options={
                'ordering': ['key'],
            },
        ),
        migrations.CreateModel(
            name='MetaFieldTooltip',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('text', models.CharField(max_length=200, verbose_name='tooltip text')),
                ('metafield', models.ForeignKey(related_name='tooltips', to='core.MetaField')),
                ('sites', models.ManyToManyField(to='sites.Site')),
            ],
        ),
        migrations.CreateModel(
            name='Offer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('slug', models.SlugField(unique=True, max_length=128, verbose_name='url slug', blank=True)),
                ('creation_date', models.DateTimeField(verbose_name='created on', editable=False, blank=True)),
                ('last_modification_date', models.DateTimeField(verbose_name='last modified on', editable=False, blank=True)),
                ('slider', models.SmallIntegerField(default=0, help_text=b'Used in CCC to specify which slider filter to use.', verbose_name=b'Slider Type', choices=[(0, b'None'), (1, b'Savings (BT)'), (2, b'Earnings'), (3, b'Savings (Purchase)')])),
                ('publication_date', models.DateTimeField(help_text='The date when Balance Transfer Rate and Intro Purchase Rate expires.', null=True, verbose_name='expires on', blank=True)),
                ('title', models.CharField(max_length=256, verbose_name='name')),
                ('image', models.ImageField(help_text='small sized image of the offer', max_length=115, upload_to=b'uploads/offers/', blank=True)),
                ('tiny_image', models.ImageField(help_text='tiny sized image for imbedded pages', upload_to=b'uploads/offers/', blank=True)),
                ('large_image', models.ImageField(help_text='large sized image of the offer', upload_to=b'uploads/offers/', blank=True)),
                ('show_outbound_message', models.BooleanField(default=True, help_text='if checked, the outbound message will be displayed.', verbose_name='show outbound message')),
                ('is_active', models.BooleanField(default=True, help_text='if checked, the offer is visible', verbose_name='is active')),
                ('is_exclusive', models.BooleanField(help_text='if checked, the offer will be marked as Exclusive', verbose_name='is exclusive')),
                ('can_be_reviewed', models.BooleanField(default=True, help_text='if checked, the offer can reviewed by users', verbose_name='can be reviewed')),
                ('is_toplevel_offer', models.BooleanField(default=True, help_text='if checked, the offer will be shown as breakout offer in /other.php', verbose_name='Breakout offer')),
                ('show_lightbox', models.BooleanField(default=True, help_text='if checked, the lightbox will popup', verbose_name='show lightbox ?')),
                ('source', models.CharField(help_text=b'scraped from', max_length=30, null=True, blank=True)),
                ('new_on', models.DateField(help_text=b'Set the start date for a new offer. Expires automatically after 7 days.', null=True, blank=True)),
                ('bt_fallback', models.ForeignKey(related_name='fallback_offers', blank=True, to='core.MetaField', help_text='Fallback rate when Balance Transfer Period matures.', null=True, verbose_name=b'BT fallback')),
            ],
            options={
                'ordering': ('title',),
            },
            managers=[
                (b'sorted_offers', django.db.models.manager.Manager()),
                (b'on_site', django.contrib.sites.managers.CurrentSiteManager(b'sites')),
            ],
        ),
        migrations.CreateModel(
            name='OfferCategory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('sort_order', models.IntegerField(default=0)),
                ('category', models.ForeignKey(to='core.Category')),
                ('offer', models.ForeignKey(to='core.Offer')),
            ],
            options={
                'ordering': ('category',),
                'db_table': 'core_offer_category',
                'verbose_name_plural': "categories (The first category added will be the offer's primary category)",
            },
        ),
        migrations.CreateModel(
            name='OfferImport',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('file', models.FileField(help_text=b'\nAvailable headers: [\'Offer ID\', \'Offer\', \'Title\', \'Bank\', \'Issuer Type\'].<br/>\nAll metafield names are valid headers too.<br/>\nThis is case-sensitive, which means "title" is not "Title".\n', upload_to=b'uploads/bulkimport/')),
                ('csv_sep', models.CharField(default=b',', max_length=1, verbose_name=b'CSV Separator')),
                ('date', models.DateTimeField(auto_now=True)),
                ('imported', models.IntegerField(default=0, verbose_name=b'# of rows imported')),
                ('failed', models.IntegerField(default=0, verbose_name=b'# of rows failed')),
                ('failed_entries', models.FileField(null=True, upload_to=b'uploads/bulkimport/', blank=True)),
                ('logs', models.TextField(default=b'', null=True, blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='OfferMeta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('date', models.DateTimeField(auto_now=True)),
                ('value', models.CharField(max_length=256, null=True, verbose_name='value', blank=True)),
                ('meta_field_alt', models.CharField(help_text=b'Value override. Get the value of this meta field instead.', max_length=64, null=True, verbose_name=b'Alternate Meta', blank=True)),
                ('expiry', models.DateField(null=True, verbose_name='date when value ends', blank=True)),
                ('next_value', models.CharField(max_length=256, null=True, blank=True)),
                ('load_next_value', models.DateTimeField(null=True, verbose_name='next value load time', blank=True)),
                ('logo', models.ImageField(help_text='Usually used for Rewards Program.', null=True, upload_to=b'uploads/offers/metafields/', blank=True)),
                ('meta_field', models.ForeignKey(related_name='meta_instances', to='core.MetaField')),
                ('offer', models.ForeignKey(related_name='meta_instances', to='core.Offer')),
            ],
            options={
                'ordering': ['meta_field__key'],
                'verbose_name_plural': 'Offer Meta',
            },
        ),
        migrations.CreateModel(
            name='OfferMetaHistory',
            fields=[
                ('vid', models.IntegerField(serialize=False, primary_key=True)),
                ('id', models.CharField(max_length=36)),
                ('date', models.DateTimeField(auto_now=True)),
                ('value', models.CharField(max_length=256, null=True, verbose_name='value', blank=True)),
                ('expiry', models.DateField(null=True, verbose_name='date when value ends', blank=True)),
                ('logo', models.ImageField(help_text='Usually used for Rewards Program.', null=True, upload_to=b'uploads/offers/metafields/', blank=True)),
                ('meta_field', models.ForeignKey(related_name='meta_history', to='core.MetaField')),
                ('offer', models.ForeignKey(related_name='meta_history', to='core.Offer')),
            ],
            options={
                'db_table': 'core_offermeta_rev_history',
            },
        ),
        migrations.CreateModel(
            name='PerSiteCategoryMeta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('display', models.CharField(max_length=50, null=True, verbose_name=b'Display Name', blank=True)),
                ('order', models.SmallIntegerField(default=0)),
                ('metafield', models.ForeignKey(to='core.MetaField')),
            ],
        ),
        migrations.CreateModel(
            name='PerSiteCategoryOption',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('page_title', models.CharField(help_text='the title tag', max_length=256, null=True, verbose_name='page title', blank=True)),
                ('page_description', models.CharField(help_text='the description meta tag', max_length=256, null=True, verbose_name='page description', blank=True)),
                ('h1_title', models.CharField(max_length=256, null=True, blank=True)),
                ('noindex', models.BooleanField(default=False, help_text='If checked, < meta name="Robots" content="noindex, follow"> will be added on the header of its pages.', verbose_name="don't index ?")),
                ('qna', models.TextField(null=True, verbose_name="Q&A's", blank=True)),
                ('category_lead_description', models.TextField(help_text='This field is Textile enabled. All HTML entered will be stripped upon saving.', null=True, verbose_name='lead paragraph', blank=True)),
                ('category_description', models.TextField(help_text='This field is Textile enabled. All HTML entered will be stripped upon saving.', null=True, verbose_name='category description', blank=True)),
                ('category_short_description', models.CharField(help_text='Needed in the homepage dropdown menu. Might be used somewhere else in the future.', max_length=100, null=True, verbose_name='short description', blank=True)),
                ('on_navbar', models.BooleanField(default=False, help_text='If checked and has appropriate parent category, it will show up in nav menu. Also affects homepage dropdown menu (in the hero).', verbose_name='Include in navigation menu?')),
                ('category', models.ForeignKey(related_name='site_options', to='core.Category')),
                ('meta_fields', models.ManyToManyField(help_text='what meta values to show in the categories table list', related_name='persitecategory', through='core.PerSiteCategoryMeta', to='core.MetaField', blank=True)),
                ('site', models.ForeignKey(to='sites.Site')),
            ],
            options={
                'ordering': ('site__name', '-id'),
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='PerSiteOfferMeta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('display', models.CharField(max_length=50, null=True, verbose_name=b'Display Name', blank=True)),
                ('order', models.SmallIntegerField(default=0)),
                ('metafield', models.ForeignKey(to='core.MetaField')),
            ],
        ),
        migrations.CreateModel(
            name='PerSiteOfferOption',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('page_title', models.CharField(help_text='the title tag', max_length=256, null=True, verbose_name='page title', blank=True)),
                ('page_description', models.CharField(help_text='the description meta tag', max_length=256, null=True, verbose_name='page description', blank=True)),
                ('h1_title', models.CharField(max_length=256, null=True, blank=True)),
                ('noindex', models.BooleanField(default=False, help_text='If checked, < meta name="Robots" content="noindex, follow"> will be added on the header of its pages.', verbose_name="don't index ?")),
                ('qna', models.TextField(null=True, verbose_name="Q&A's", blank=True)),
                ('offer_description', models.TextField(help_text='This field is Textile enabled. All HTML entered will be stripped upon saving.', null=True, verbose_name='offer description', blank=True)),
                ('table_features', models.TextField(help_text='Used by CCC to show the bullet features on the category table (under "name" column).', null=True, blank=True)),
                ('outbound_url', models.URLField(null=True, verbose_name='outbound url', blank=True)),
                ('outbound_url_m', models.URLField(null=True, verbose_name='mobile outbound url', blank=True)),
                ('promo_text_ends', models.DateField(null=True, verbose_name='end date of promo text', blank=True)),
                ('promo_features', models.TextField(help_text='Breakout offer features. Meta tag-enabled. Separate entries using new line (simply press "Enter")', null=True, blank=True)),
                ('exclusive_features', models.TextField(help_text='Exclusive offer features. Meta tag-enabled. Separate entries using new line (simply press "Enter")', null=True, blank=True)),
                ('promo_trackers', models.TextField(help_text='First entry: "Apply URL". Second entry: "Tracker image URL". Separate entries using new line (simply press "Enter")', null=True, blank=True)),
                ('pros', models.TextField(help_text='Separate entries using new line (simply press "Enter")', null=True, blank=True)),
                ('cons', models.TextField(help_text='Separate entries using new line (simply press "Enter")', null=True, blank=True)),
                ('meta_fields', models.ManyToManyField(help_text='what meta values to show in the columns', related_name='persiteoffer', through='core.PerSiteOfferMeta', to='core.MetaField', blank=True)),
                ('offer', models.ForeignKey(related_name='site_options', to='core.Offer')),
                ('site', models.ForeignKey(to='sites.Site')),
            ],
            options={
                'ordering': ('site__name', '-id'),
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='SiteBreakout',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(help_text=b'Use this in place of the offer title.', max_length=100, null=True, verbose_name=b'Title (optional)', blank=True)),
                ('promote_frequency', models.IntegerField(default=100, help_text='Ex: to promote this offer in this category to 30% of page visitors, enter a value 30')),
                ('promote_counter', models.IntegerField(default=0)),
                ('category', models.ForeignKey(to='core.Category')),
                ('offer', models.ForeignKey(to='core.Offer')),
                ('site', models.ForeignKey(to='sites.Site')),
            ],
        ),
        migrations.AddField(
            model_name='persiteoffermeta',
            name='persite',
            field=models.ForeignKey(to='core.PerSiteOfferOption', db_column=b'persiteofferoption_id'),
        ),
        migrations.AddField(
            model_name='persitecategorymeta',
            name='persite',
            field=models.ForeignKey(to='core.PerSiteCategoryOption', db_column=b'persitecategoryoption_id'),
        ),
        migrations.AddField(
            model_name='offer',
            name='categories',
            field=models.ManyToManyField(help_text="an offer can belong to multipe categories. The first category selected is the offer's primary category", to='core.Category', through='core.OfferCategory'),
        ),
        migrations.AddField(
            model_name='offer',
            name='meta',
            field=models.ManyToManyField(help_text='apr, monthly fee, interest, etc ...', to='core.MetaField', through='core.OfferMeta'),
        ),
        migrations.AddField(
            model_name='offer',
            name='sites',
            field=models.ManyToManyField(to='sites.Site', through='core.PerSiteOfferOption', blank=True),
        ),
        migrations.AddField(
            model_name='category',
            name='sites',
            field=models.ManyToManyField(to='sites.Site', through='core.PerSiteCategoryOption', blank=True),
        ),
        migrations.AddField(
            model_name='category',
            name='transfer_limits',
            field=models.ManyToManyField(help_text='List of issuers to which balance transfer is not allowed.', related_name='no_transfer_allowed+', through='core.BalanceTransfer', to='core.Category', blank=True),
        ),
        migrations.AddField(
            model_name='bankprofile',
            name='issuer',
            field=models.OneToOneField(related_name='issuer_profile', to='core.Category'),
        ),
        migrations.AddField(
            model_name='bankprofile',
            name='type',
            field=models.ForeignKey(blank=True, to='core.BankType', help_text=b'E.g. Credit Union, Mutual Bank, etc.', null=True),
        ),
        migrations.AddField(
            model_name='balancetransfer',
            name='no_transfer_from',
            field=models.ForeignKey(related_name='no_transfer_from', to='core.Category'),
        ),
        migrations.AddField(
            model_name='balancetransfer',
            name='no_transfer_to',
            field=models.ForeignKey(related_name='no_transfer_to', to='core.Category'),
        ),
        migrations.AlterUniqueTogether(
            name='offermeta',
            unique_together=set([('meta_field', 'offer')]),
        ),
        migrations.AlterUniqueTogether(
            name='offercategory',
            unique_together=set([('category', 'offer')]),
        ),
        migrations.AlterUniqueTogether(
            name='balancetransfer',
            unique_together=set([('no_transfer_from', 'no_transfer_to')]),
        ),
    ]
