from arktotalwealth.website.models import *
from django.contrib import admin
from django.http import HttpResponseRedirect

class MiscPageAdmin(admin.ModelAdmin):
	list_display = ['title','path']
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]	 

class EnquiryAdmin(admin.ModelAdmin):
	list_display = ('email','first_name','surname','phone','submitdate', 'comments')

	actions = ['set_as_spammers',]
	
	def set_as_spammers(self,request,queryset):
		selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
		return HttpResponseRedirect('addtospammerslist/?ids=%s' % ",".join(selected))	

	def get_form(self, request, obj=None, **kwargs):
		form = super(EnquiryAdmin,self).get_form(request,**kwargs)
		form.base_fields['interest'].queryset = Interest.objects.exclude(place='subscribe')
		return form

	change_list_template = 'admin/change/enquiry.html'
	
class ImagePlayerAdmin(admin.ModelAdmin):
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]	 
	
class SpammerListAdmin(admin.ModelAdmin):
    list_display = ('ip', 'last_post')

admin.site.register(MiscPage, MiscPageAdmin)
admin.site.register(ImagePlayer, ImagePlayerAdmin)
admin.site.register(Enquiry, EnquiryAdmin)
admin.site.register(Interest)
admin.site.register(EmailReceiver)
admin.site.register(SpammerList,SpammerListAdmin)

from django.contrib.sites.models import Site
admin.site.unregister(Site)

from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
class MyUserAdmin(UserAdmin):
	staff_fieldsets = (
		(None, {'fields': ('username',)}),
		(('Personal info'), {'fields': ('first_name', 'last_name', 'email')}),
		(('Permissions'),{'fields':('is_active','is_staff')}),
		#(('Important dates'), {'fields': ('last_login', 'date_joined')}),
		(('Groups'), {'fields': ('groups',)}),
	)

	def change_view(self, request, *args, **kwargs):
	    # for non-superuser
	    if not request.user.is_superuser:
	        try:
	            self.fieldsets = self.staff_fieldsets
	            response = UserAdmin.change_view(self, request, *args, **kwargs)
	        finally:
	            # Reset fieldsets to its original value
	            self.fieldsets = UserAdmin.fieldsets
	        return response
	    else:
	        return UserAdmin.change_view(self, request, *args, **kwargs)
	
	def queryset(self, request):
	    #form.status.queryset = OrderStatus.objects.exclude(status="In Progress")
	    if not request.user.is_superuser:
	        return super(UserAdmin,self).queryset(request).exclude(is_superuser=True) 
	    else:
	        return super(UserAdmin,self).queryset(request)
	       
admin.site.unregister(User)
admin.site.register(User, MyUserAdmin)