$(document).ready(function () {
    $('.edit_blog_post').live('click', function () {
        var url = $(this).attr('data-url'),
        pid = $(this).attr('data-post'),
        container = $(this).parents('div.post_container');
        $.get(url, function (resp) {
            container.replaceWith(resp);

            util.ajaxify_forms('#edit_post_container_' + pid);
            util.ajaxify_forms('#delete_post_container_' + pid,
                               function () {
                                   $('#post_' + pid).remove();
                                   $('#delete_post_container_' + pid).remove();
                               });

            $('#post_' + pid).find('input.cancel_edit').click(function () {
                $.get($(this).attr('data-url'),
                      function (resp) {
                          $('#post_' + pid).replaceWith(resp);
                          $('#delete_post_container_ ' + pid).remove();
                      });
            });

            $('#post_' + pid).find('input.delete_post').click(function () {
                $('#delete_post_container_' + pid).find('form').trigger('submit');
            });
        });
    });

    // Comments

    function new_comment(resp) {
        var id = resp.comment;
        $('#comments').append(
            '<div id="comment_container_' + id + '">' + resp.html + '</div>'
        );
        $('#new_comment textarea[name=contents]').val('');
    }

    util.ajaxify_forms('#new_comment', new_comment);

    function comment_deleted(resp) {
        $('#comment_container_' + resp.comment).remove();
    }

    $('.delete_comment').live('click', function () {
        var cmt = $(this).attr('data-comment');

        util.ajaxify_forms('#delete_comment_' + cmt, comment_deleted);
        $('#delete_comment_' + cmt +' input[name=comment]').val(cmt);
        $('#delete_comment_' + cmt + ' form').trigger('submit');
    });

});