angular.module('ProfileApp',
    [
        'profile.controllers',
        'profile.directives',
        'common.directives',
        'common.services'
    ]
).config(["$httpProvider",
    function($httpProvider) {
        $httpProvider.defaults.headers.post['X-CSRFToken'] = $('input[name=csrfmiddlewaretoken]').val();
    }
]);