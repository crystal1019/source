from .base_gap import BaseGapScraper


class PiperlimeGapScraper(BaseGapScraper):
    @staticmethod
    def get_domain():
        return 'piperlime.gap.com'

    def _get_store(self):
        return 'piperlime.gap'

