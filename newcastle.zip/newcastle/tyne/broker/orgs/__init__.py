import importlib

orgClasses = {}
def getInstance(orgName):
	if not orgName in orgClasses:
		importedModule = 	importlib.import_module('tyne.broker.orgs.' + orgName)
		cObj = getattr(importedModule, orgName)
		#instantiate the obj
		clazzInstance = cObj()
		orgClasses[orgName] = clazzInstance
		
	return orgClasses[orgName]


