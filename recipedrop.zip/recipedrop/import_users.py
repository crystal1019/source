from django.contrib.auth.models import User

f = open('users.txt', 'r')
contents = f.read()
f.close()

users = contents.split('User\n')
for u in users:
    u = u.split('\n')
    fld_dict = {}
    for fld in u:
        fld = fld.split(' ')
        if len(fld) == 2:
            fld[0] = fld[0].strip()
            fld[1] = fld[1].strip()
            if fld[0] != '' and fld[1] != '':
                fld_dict[fld[0]] = fld[1]

    if fld_dict != {}:
        u_obj = User.objects.create(**fld_dict)
        u_obj.save()
