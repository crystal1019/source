from arkstart.blog.models import *
import datetime
from arkstart.website.models import *
from django.conf import settings
from arkstart.userprofile.models import *
def commonDict(d,request):
    featured = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by('-priority')[:4]
    site_meta = SiteMeta.objects.get(site__id=settings.SITE_ID)
    misclist = MiscPage.objects.filter(status__display_to_user=True)
    arkgroup = ArkGroup.objects.all()[:6]
    try:
        usr = MemberType.objects.filter(super_member=False, member=False)[:1].get()
    except:
        usr = ''
    if request.user and request.user.is_active and not request.user.is_staff:
        try:
            usr = request.user.get_profile().membertype
        except:
            pass
        
    user = request.user
    data = {
            'featured':featured,
            'site_meta':site_meta,
            'arkgroup':arkgroup,
            'domain':settings.DOMAIN,
            
            'usr':usr,
            'user':user,
            
            'misclist':misclist,
            }
    
    data.update(d)
    
    return data