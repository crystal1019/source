angular.module('profile.controllers', [])
    .controller('ProfileCtrl', ["$scope",
        function($scope){
            $scope.current_tab = 'home';
            //http://stackoverflow.com/a/18265285/2807539
            $scope.safeApply = function(fn) {
                var phase = this.$root.$$phase;
                if (phase == '$apply' || phase == '$digest') {
                    if (fn) {
                        fn();
                    }
                } else {
                    this.$apply(fn);
                }
            };
        }
    ])
    .controller('PlacesCtrl', ["$scope", "$http",
        function($scope, $http){
            $scope.getStats = function(){
                $http.get('/profile/place_stats/')
                .success(function(resp){
                    if(resp.success) {
                        $scope.place_data = resp.data;
                    }
                });
            };

            $scope.getStats();
        }
    ])
    .controller('ConnectedCtrl', ["$scope", "$http", "addCategoryIcons",
        function($scope, $http, addCategoryIcons){
            $scope.connected_topics = null;
            $scope.getTopics = function(){
                $http.get('/profile/connected_topics/')
                .success(function(resp){
                    if(resp.success) {
                        $scope.connected_topics = resp.data.card_topics;
                        addCategoryIcons($scope.connected_topics);
                        $scope.$emit('map_topics', resp.data.map_topics);
                    }
                });
            };
            $scope.getTopics();
        }
    ])
    .controller('MyTopicsCtrl', ["$scope", "$http", "addCategoryIcons",
        function($scope, $http, addCategoryIcons){
            $scope.my_topics = null;
            $scope.loadMetrics = function(topic){
                topic.metrics = true;
                topic.metrics_loaded = false;

                $http.get('/topic/topic_metrics_json/', {
                    params: {
                        topic: topic.id
                    }
                })
                .success(function(resp){
                    if(resp.success){
                        topic.metrics = resp.data;
                        topic.metrics_loaded = true;
                    }
                });
            }
            $scope.getTopics = function(){
                $http.get('/profile/my_topics/')
                .success(function(resp){
                    if(resp.success) {
                        $scope.my_topics = resp.data;
                        addCategoryIcons($scope.my_topics);
                    }
                });
            };
            $scope.getTopics();
        }
    ])
    .controller('OrganizationCtrl', ["$scope", "$http",
        function($scope, $http){
            $scope.getOrganizations = function(){
                $scope.organizations = null;
                $http.get('/profile/my_organizations/')
                .success(function(resp){
                    if(resp.success) {
                        $scope.organizations = resp.data;
                    }
                });
            };
            $scope.getOrganizations();
        }
    ]);
