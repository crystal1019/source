$('.smartsearchdropdown').each(function(){
	var selectDropdown = {
		open:false,
		selected:null,
		value:null
	};
	var q = $(this);
	q.click(function(){
		// console.log('clicked');
		if(selectDropdown.open){
			q.find('.ctx1dropdownlist').hide(100);
			selectDropdown.open=false;
		} else {
			q.find('.ctx1dropdownlist').show(100);
			selectDropdown.open=true;
		}
	});

	q.find('.ctx1dropdownslot').click(function(e){
		selectDropdown.selected = e.currentTarget.innerText || e.currentTarget.textContent;
		selectDropdown.value = e.currentTarget.getAttribute('value');
		q.find('.ctx1dropdowntext').text(selectDropdown.selected);
		q.find('.ctx1dropdownlist').hide(100);
		selectDropdown.open=false;

		// apply to local input
		q.find('input').attr('value',selectDropdown.value);
	});
});
