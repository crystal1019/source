$(document).foundation();


// This is all nonsense that I put in to mock intended behaviour.
$(document).ready(function() {
  var toolbarCollapseDifference = parseInt($('.tool-bar-buttons-that-disappear').css('height'), 10);

  // Re-size Textarea
  $('.pattern-input textarea').delay(400).height(325);


  // Handle toolbar collapse
  $('.tool-bar-collapse-button a').click(function(event) {
    event.preventDefault();
    var bodyPaddingToolbarCollapsed = parseInt($('body').css('padding-top'), 10) - toolbarCollapseDifference;

    $('.tool-bar-collapse-button').addClass('hide');
    $('.tool-bar-expand-button').removeClass('hide');

    $('.tool-bar-collapse').addClass('hide');
    $('body').css('padding-top', bodyPaddingToolbarCollapsed);
  });


  // Handle toolbar expand
  $('.tool-bar-expand-button a').click(function(event) {
    event.preventDefault();
    var bodyPaddingToolbarExpanded = parseInt($('body').css('padding-top'), 10) + toolbarCollapseDifference;

    $('.tool-bar-expand-button').addClass('hide');
    $('.tool-bar-collapse-button').removeClass('hide');

    $('.tool-bar-collapse').removeClass('hide');
    $('body').css('padding-top', bodyPaddingToolbarExpanded);
  });


  // Handle generate
  $('.generate-button button').click(function(event) {
    event.preventDefault();
    $('.generate-button').addClass('hide');
    $('.generate-cancel-button').removeClass('hide');
    window.setTimeout(function() {
      $('.generate-cancel-button').addClass('hide');
      $('.generated-iframes').removeClass('hide');
      $('.generate-button').removeClass('hide');
      $('.tool-bar-collapse-button a').trigger('click');
      $('.pattern-input textarea').height(125);
    }, 2000);
  });


  // Handle cancel generate
  $('.generate-cancel-button a').click(function(event) {
    event.preventDefault();
    $('.generate-cancel-button').addClass('hide');
    $('.generate-button').removeClass('hide');
  });


  // DO A BUNCH OF STUFF SO I DON'T HAVE TO CLICK MANUALLY
  // $('.generate-button button').trigger('click');
});