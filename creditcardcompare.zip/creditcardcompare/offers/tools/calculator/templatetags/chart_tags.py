from django import template


register = template.Library()


class RenderChartNode(template.Node):
 
    def __init__(self, chart_title, all_series):
        self.chart_title = chart_title
        self.all_series = all_series
 
    def render(self, context):
        t = template.loader.get_template('calculator/chart.html')
        c = template.Context({
            'chart_title': self.chart_title.strip("'").strip('"'),
            'all_series': template.Variable(self.all_series).resolve(context)
        })
        return t.render(c)
 

@register.tag(name='render_chart')        
def render_chart(parser, token):
    '''all_series must be in the form:
    series = {'name':'chart name', 'data':[1,2,3]}
    all_series = [series,series]
    '''
    try:
        tag_name, chart_title, all_series = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments.' % token.split_contents()[0]
    return RenderChartNode(chart_title, all_series)