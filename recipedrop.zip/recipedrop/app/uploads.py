import string
import random
import os
import mimetypes
import boto
from PIL import Image
import cStringIO
import math
from io import BytesIO
import logging

from django.conf import settings
from django.shortcuts import redirect
from django.http import HttpResponse
from django.views.decorators.cache import cache_control

#from django.contrib.auth.models import User
#from boto.s3.key import Key
#from django.db import models
#from django import forms


logger = logging.getLogger('app.uploads')


RECIPE_UPLOAD = 0
RECIPE_IMAGE = 1
USER_IMAGE = 2

typ_dirs = {
    RECIPE_UPLOAD: 'recipes',
    RECIPE_IMAGE: 'recipe_images',
    USER_IMAGE: 'user_images'
}

FILENAME_LEN = 16

MAX_IMG_WIDTH = 1000
MAX_IMG_HEIGHT = 1000

METAMIME = {'JPEG': {'Content-Type': 'image/jpeg'},
            'PNG': {'Content-Type': 'image/png'},
            '*Unknown*': {'Content-Type': 'application/octet-stream'},
            }

if settings.LIVE:
    s3 = boto.connect_s3()
    bucket = s3.create_bucket(settings.S3_BUCKET)


# from
# http://stackoverflow.com/questions/2257441/python-random-string-generation-with-upper-case-letters-and-digits
def id_generator(size=FILENAME_LEN,
                 chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for x in range(size))


def typ_to_dir(typ):
    return typ_dirs[typ]


def content_file_name(filename):
    new_name = ''.join([id_generator(),
                        os.path.splitext(filename)[-1]])
    return new_name


def check_contents_mime(b, contents):
    try:
        filedata = BytesIO(contents)
        im = Image.open(filedata)
        return im.format
    except IOError:
        return '*Unknown*'


def upload_handler(filename, file_data, subdir='',
                   thumb_width=None, thumb_height=None, is_image=False, allow_types=False):
    if allow_types:
        logger.debug("file %s content_type %s " % (filename, file_data.content_type))
        if not file_data.content_type in allow_types:
            logger.error("Error inf file type %s accept %s " % (file_data.content_type, allow_types))
            return
    if not settings.LIVE:

        path = os.path.join(settings.MEDIA_ROOT, subdir)

        if not os.path.exists(path):
            os.makedirs(path)

        path = os.path.join(path, filename)

        with open(path, 'w+') as f:
            for chunk in file_data.chunks():
                f.write(chunk)

        return path
    else:
        path = os.path.join(subdir, filename)
        _, ext = os.path.splitext(filename)
        ext = ext[1:]
        if ext.upper() == u'JPG':
            ext = 'JPEG'

        if not is_image:
            key = bucket.new_key(path)
            key.set_contents_from_file(file_data)
            # add public, set mime
            key.set_acl('public-read')
            try:
                content = key.get_contents_as_string()
                image_format = check_contents_mime(key.bucket, content)
            except Exception as xx:
                image_format = "*Unknown*"
                logger.debug("exception %s" % xx)
            newmime = METAMIME.get(image_format, 'application/octet-stream')
            key.copy(key.bucket, key.name, preserve_acl=True, metadata=newmime)
            return path

        img = Image.open(file_data)

        # TODO: clean up all this nasty resizing repetition

        if thumb_width:
            resized = img.copy()
            # assumes thumb_width >= thumb_height
            # second component of thumbnail size is supposed to be width
            resized.thumbnail((thumb_width, thumb_width),
                              Image.ANTIALIAS)

            (w, h) = resized.size
            if w < thumb_width:
                resized = resized.resize(
                    (thumb_width,
                     int(math.ceil(((thumb_width * 1.0) / w) * h))),
                    Image.ANTIALIAS)
            (w, h) = resized.size
            if h < thumb_height:
                resized = resized.resize(
                    (int(math.ceil(((thumb_height * 1.0 / h) * w))),
                        thumb_height),
                    Image.ANTIALIAS)
            (w, h) = resized.size

            resized = resized.crop((0, 0, thumb_width, thumb_height))

            out_resized = cStringIO.StringIO()
            resized.save(out_resized, ext)
            key = bucket.new_key('%s_thumbnail' % path)
            key.set_contents_from_string(out_resized.getvalue())

            # add public, set mime
            key.set_acl('public-read')
            image_format = check_contents_mime(key.bucket, out_resized.getvalue())
            newmime = METAMIME.get(image_format, 'application/octet-stream')
            key.copy(key.bucket, key.name, preserve_acl=True, metadata=newmime)

        (w, h) = img.size
        if w > MAX_IMG_WIDTH:
            img = img.resize(
                (MAX_IMG_WIDTH,
                    int(math.ceil(((MAX_IMG_WIDTH * 1.0) / w) * h))),
                Image.ANTIALIAS)
        (w, h) = img.size
        if h > MAX_IMG_HEIGHT:
            img = img.resize(
                (int(math.ceil(((MAX_IMG_HEIGHT * 1.0) / h) * w)),
                 MAX_IMG_HEIGHT),
                Image.ANTIALIAS)

        img_out = cStringIO.StringIO()
        img.save(img_out, ext)
        key = bucket.new_key(path)
        # TODO: chunk it out?
        key.set_contents_from_string(img_out.getvalue())

        # add public, set mime
        key.set_acl('public-read')
        image_format = check_contents_mime(key.bucket, img_out.getvalue())
        newmime = METAMIME.get(image_format, 'application/octet-stream')
        key.copy(key.bucket, key.name, preserve_acl=True, metadata=newmime)

        return path


@cache_control(max_age=86400)
def download_handler(request, path, save_as=True, thumbnail=False):
    if settings.LIVE:
        if thumbnail:
            return redirect(settings.S3_URL + path + '_thumbnail')
        return redirect(settings.S3_URL + path)
    if settings.LIVE:
        key = '%s_thumbnail' % path
        b = bucket.get_key(key)
        if thumbnail and b:
            contents = b.get_contents_as_string()
        else:
            b = bucket.get_key(path)
            contents = b.get_contents_as_string()
    else:
        with open(path) as f:
            contents = f.read()

    if save_as:
        resp = HttpResponse(contents, mimetype='application/force-download')
        filename = os.path.split(path)[-1]
        resp['Content-Disposition'] = 'attachment; filename=%s' % filename
        resp['Content-Type'] = mimetypes.guess_type(path)
    else:
        resp = HttpResponse(contents)
        resp['Content-Type'] = mimetypes.guess_type(path)

    return resp
