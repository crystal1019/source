import memcache, re
from django.core.cache import cache
from django.views.decorators.csrf import csrf_protect
from django.template.response import ContentNotRenderedError


def cleanup_uri(request):
    uri = request.build_absolute_uri()
    try:
        params = uri.split('?')[1].split()[0]
    except IndexError:
        return uri
    newparams = re.sub('&?gclid=[^&]*', '', params)
    newparams = re.sub('&?utm_[^=]*=[^&]*', '', newparams)
    return uri.replace(params, newparams.strip('&')).strip('?')

def cache_page(function_to_decorate):
    function_to_decorate = csrf_protect(function_to_decorate)
    def wrapper(request, *args, **kwargs):
        if request.method == 'POST' or request.user.is_staff:
            return function_to_decorate(request, *args, **kwargs)
        cache_key = cleanup_uri(request)
        if request.session.get('is_mobile', False):
            cache_key = 'mobile-' + cache_key
        try:
            cached_page = cache.get(cache_key)
            if cached_page: 
                return cached_page
        except memcache.Client.MemcachedKeyLengthError:
            pass
        response = function_to_decorate(request, *args, **kwargs)
        try:
            cache.set(cache_key, response, 60 * 60 * 24)
        except memcache.Client.MemcachedKeyLengthError:
                pass
        except ContentNotRenderedError:
            response.render()  # for class-based views
            cache.set(cache_key, response, 60 * 60 * 24)
        return response
        
    return wrapper