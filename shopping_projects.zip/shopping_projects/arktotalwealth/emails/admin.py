from django.contrib import admin
from django.http import HttpResponseRedirect
from models import *

class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('email','first_name','surname','phone','subscribed','group','email_not_read')
    list_filter = ('subscribed','group',)
    list_editable = ('group',)
    search_fields = ('email',)

    actions = ['send_mail']
    list_per_page = 2147483647
    
    filter_horizontal = ['interest',]
    
    def get_form(self, request, obj=None, **kwargs):
        form = super(SubscriptionAdmin,self).get_form(request,**kwargs)
        form.base_fields['interest'].queryset = Interest.objects.exclude(place='enquiry')
        return form
    
    def send_mail(self,request,queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        return HttpResponseRedirect('sendmail/?ids=%s' % ",".join(selected))
        
    

    
class EmailAdmin(admin.ModelAdmin):
    list_display=('title','created','send_already','read_percentage','not_read_percentage')
    list_filter=('created',)

    actions = ['duplicate_email']
    
    def duplicate_email(self,request,queryset):
        content = ''
        titles = []
        for x in queryset:
            titles.append(x.title)
            content += x.content
        e = Email()
        num = 0
        title = 'please_change_me'
        while title in titles:
            num += 1
            titlelist = title.split('_')[:3]
            titlelist.append(str(num))
            title = '_'.join(titlelist)
            
            
        e.title = title
        e.content = content
        e.save()
        return HttpResponseRedirect('/admin/emails/email/')
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup_email.js',]    
        
#admin.site.register(Email, EmailAdmin)
#admin.site.register(Subscription,SubscriptionAdmin)
#admin.site.register(SubscriptionGroup)
