# Create your views here.
from django.template import RequestContext, Context, loader
from django.http import HttpResponse
from django import forms
import simplejson as json
from django.core.context_processors import csrf
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.cache import cache_page
from django.views.decorators.http import condition
from django.conf import settings
from django.shortcuts import render_to_response
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.contrib.auth.models import User
from django.db import connection, transaction
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

from roomhints.models import RoomType
from roomhints.models import RoomSetting
from roomhints.models import Project
from roomhints.models import HintType
from roomhints.models import HintTypeList
from roomhints.models import Hint
from roomhints.models import HintStyle
from roomhints.models import HintStyleList
from roomhints.models import RoomHint
from roomhints.models import RoomHintLike
from roomhints.models import Feedback
from roomhints.models import Comment
from roomhints.models import Beta
from roomhints.models import Profile
from roomhints.models import ProjectImpression
from roomhints.models import RoomHintImpression
from roomhints.models import FrontPhoto
from roomhints.models import ChoiceImpressionGroup
from roomhints.models import ChoiceImpression
from roomhints.models import SearchImpressionGroup
from roomhints.models import SearchImpression
from roomhints.models import Category
from roomhints.models import HintSimilarity
from roomhints.models import Event
import hashlib
import random
from datetime import datetime, timedelta
from django.utils.timezone import utc
import calendar
import subprocess
from roomhints.MyEmailSend import MyEmailSend
from haystack.query import SearchQuerySet
from roomhints.search_indexes import Hint
import shutil
import copy
import logging
from roomhints.utils import make_unique, photo_convert, url_encode
from roomhints.utils import make_unique_photo
from roomhints.utils import seconds_to_age
from roomhints.utils import random_seconds, random_name, random_home_quote
from roomhints.utils import compute_badge_count_for_profile, compute_badge_count_for_project, compute_badge_count_for_comments, push_max, paid_days, push_comments, search_profile_id, custom_last, custom_first
from roomhints.crawler import crawl_hint
from roomhints.crawler import crawl_hint_clean
import urllib
from roomhints.imagematcher import find_image_match
import os
import math
from roomhints.search import search
from roomhints.color import get_color_stats
from roomhints.affiliate import affiliate_data, affiliate_set, affiliate_find, affiliate_data_from_sku
from roomhints.models import AffiliateRedirection
from iospush.models import Device
from urllib import urlretrieve
import stripe
from roomhints.url2png import url2png, url2price

logger = logging.getLogger(__name__)

# set your secret key: remember to change this to your live secret key in production
# see your keys here https://manage.stripe.com/account
stripe_test_secret_key = "sk_test_jj4U0Kx544fx5N8hdZwBPQEQ"
stripe_test_publishable_key = "pk_test_foMGVvQ128tZIGzHvTJj6skl"
stripe_live_secret_key = "sk_live_QmcTu5c4ssAAtZkKsalXZ3Ud"
stripe_live_publishable_key = "pk_live_SFDHhU4vvQKzFyLXwzdRn3vx"

stripe.api_key = stripe_test_secret_key
stripe_publishable_key = stripe_test_publishable_key
stripe.api_key = stripe_live_secret_key
stripe_publishable_key = stripe_live_publishable_key
stripe_price = 20

class BetaForm(forms.Form):
    email = forms.EmailField()
    am_designer = forms.BooleanField(required=False)
    want_designer = forms.BooleanField(required=False)

def index(request):
    return HttpResponseRedirect('http://signup.roomhints.com')
    #return HttpResponseRedirect('http://signup.roomhints.com/roomhints-2/')

title = "Room Hints | Style your room on the spot"
def front(request):
    page = dict()
    page['title'] = title
    page['page'] = 'front'
    f = FrontPhoto.objects.order_by('?')[0] # random select
    front = dict()
    front['photo'] = f.photo_web.name
    #p = Project.objects.filter(projuniq="392ada514cd8f12010b50f34137ca0ac29ea").get()
    #b6d34cdc532de3bbda630ccb09ebecfb91e5
    rt = RoomType.objects.filter(name="decorate").get()
    projects = Project.objects.filter(roomtype_id=rt.id,public=True).order_by('-seconds')[:4]
    show_projects = []
    for onep in projects:
        data_item = dict()
        data_item['name'] = onep.name
        if not onep.name: # FIXME: remove this; older projects did not have names
            onep.name = ''
        data_item['name'] = onep.name
        data_item['photo_square'] = onep.photo_square.name
        data_item['age'] = seconds_to_age(onep.seconds)
        show_projects.append(data_item)

    if request.method == 'GET':
        return render(request, 'roomhints/front_page.html', { "page": page, "projects": show_projects, "front":front } )
    else:
        return HttpResponseRedirect('/')

@condition(etag_func=None)
def room_show(request):
    f = open('/tmp/ajax', 'ab+')
    f.write('got regular call\n')
    f.close()
    if request.is_ajax():
        f = open('/tmp/ajax', 'ab+')
        f.write('got ajax call\n')
        f.close()
        return HttpResponse( stream_response_generator(), mimetype='text/html')
    else:
        return HttpResponse()

def stream_response_generator():
    yield "<html><body>\n"
    num = 100
    rt = RoomType.objects.filter(name="showroom_user").get()
    projects = Project.objects.filter(roomtype_id=rt.id,public=True).order_by('-seconds')[:num]
    for x in range(0,num-1):
        yield "<div>" + settings.MEDIA_URL + projects[x].photo_mob.name + "</div>\n"
        yield " " * 1024  # Encourage browser to render incrementally
        time.sleep(1)
    yield "</body></html>\n"

def validateEmail(email):
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    try:
        validate_email(email)
        return True
    except ValidationError:
        return False

def account(request):
    if request.method == 'GET':
        if request.user.is_authenticated():
            return render(request, 'roomhints/account_must_logout.html')
        #return HttpResponse()
        # Don't let the entire Internet get accounts :)
        return render(request, 'roomhints/account.html')
    if request.method == 'POST':
        u = None
        up = None
        profuniq, u, up = make_profuniq(request,'web')
        up = profuniq_to_prof(profuniq)
        f = open('/tmp/account','ab+')
        f.write("up is " + str(up) + "\n")
        f.write("u is " + str(u) + " and up.id is " + str(up.id) + "\n")
        f.close()
        
        password = request.POST.get('password','')
        password2 = request.POST.get('password2','')
        username = request.POST.get('username','')
        name = request.POST.get('name','')

        account = dict()
        account['username'] = username
        account['password'] = password
        account['password2'] = password2
        account['error'] = False
        existing_users = User.objects.filter(email=username)
        if len(existing_users) == 1:
            # This email already exists
            account['error'] = "This username already exists."
            return render(request, 'roomhints/account.html', { "account": account } )

        existing_users = User.objects.filter(username=username)
        if len(existing_users) == 1:
            # This email already exists
            account['error'] = "This username already exists."
            return render(request, 'roomhints/account.html', { "account": account } )

        if password != password2:
            account['error'] = "The passwords entered don't match."
            return render(request, 'roomhints/account.html', { "account": account } )

        # Make the account have this username
        # First make the user login, else set_password will fail
        u = authenticate(username=profuniq, password=anonymous_password)
        u.first_name = name
        f = open('/tmp/pass', 'ab+')
        f.write("will set the password '" + password + "' for user " + str(u) + " that will get username " + str(username) + "\n")
        u.set_password(password)
        if validateEmail(username):
            u.email = username
        u.username = username
        u.save()
        up.has_account = True
        up.save()
        login(request,u)
        request.session['profuniq'] = u.username
        return HttpResponseRedirect('/designer')

def prep_rooms(allp):
    rooms=[]
    if len(allp) > 0:
        for p in allp:
            data_item=dict()
            data_item['projuniq'] = p.projuniq
            data_item['photo'] = p.photo_mob.name
            data_item['custom'] = p.custom
            data_item['date'] = p.seconds
            data_item['budget'] = 'no budget'
            if p.budget != -1:
                data_item['budget'] = "budget: $" + str(p.budget)
            data_item['age'] = seconds_to_age(p.seconds)
            rooms.append(data_item)
    return rooms

def designer(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "Designer"
        page['page'] = "designer"
        page['is_designer'] = up.designer

        return render(request, 'roomhints/designer.html', { "page":page })
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms_helped(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        sql = "select p.projuniq,p.photo_mob,p.custom,p.seconds,p.budget from roomhints_project p, roomhints_roomtype rt where p.public = true and p.roomtype_id = rt.id and rt.name='decorate' and p.id in (select distinct p.id from roomhints_project p, roomhints_roomhint rh where rh.project_id = p.id and rh.profile_id = " + str(up.id) + " union select distinct p.id from roomhints_project p, roomhints_comment c where c.project_id = p.id and c.profile_id = " + str(up.id) + ") order by seconds desc limit 500"
        helped_rooms = rooms_list(sql)

        page = dict()
        page['title'] = "Helped"
        page['page'] = "designer_rooms_helped"
        page['is_designer'] = up.designer
        page['room_count'] = len(helped_rooms)

        if up.designer:
            return render(request, 'roomhints/designer_rooms_helped.html', { "helped_rooms":helped_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms_surprise(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        surprise_rooms = rooms_list(not_hidden_sql(False,"Surprise me!"))

        page = dict()
        page['title'] = "Surprise"
        page['page'] = "designer_rooms_surprise"
        page['is_designer'] = up.designer
        page['room_count'] = len(surprise_rooms)

        if up.designer:
            return render(request, 'roomhints/designer_rooms_surprise.html', { "surprise_rooms":surprise_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms_livestream(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        rt_decorate = RoomType.objects.filter(name="decorate").get()

        # startdate = datetime.utcnow().replace(tzinfo=utc)
        # enddate = startdate + timedelta(days=7)
        p_latest = Project.objects.filter(public=True, roomtype_id=rt_decorate.id).order_by('-seconds')[:100] #.filter(date_gt=enddate,date_lt=startdate)
        latest_rooms = prep_rooms(p_latest)

        page = dict()
        page['title'] = "The Live Stream"
        page['page'] = "designer_rooms_livestream"
        page['is_designer'] = up.designer

        if up.designer:
            return render(request, 'roomhints/designer_rooms_livestream.html', { "latest_rooms":latest_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def profile_get(username):
    account = dict()
    sql = "select au.username, au.email, au.first_name, au.last_name, up.website, up.photo_headshot, up.photo_vertshot, up.location, up.aesthetic, up.talent  from roomhints_profile up, auth_user au where up.user_id = au.id and au.username = %s"
    cursor = connection.cursor()
    cursor.execute(sql,[username])
    for row in cursor.fetchall():
        account['username'] = row[0]
        account['email'] = row[1]
        account['first'] = row[2]
        account['last'] = row[3]
        account['website'] = row[4]
        account['headshot'] = row[5]
        account['vertshot'] = row[6]
        account['location'] = row[7]
        account['aesthetic'] = row[8]
        account['talent'] = row[9]
    return account
    
def designer_profile(request):
    up = profuniq_to_prof(request.user.username)
    page = dict()
    page['title'] = "My Profile"
    page['page'] = "designer_profile"
    page['is_superuser'] = False
    if search_profile_id() == up.id or 798 == up.id: # Tiff and I
        page['is_superuser'] = True

    if request.method == 'GET':
        if request.user.is_authenticated() and up.designer == True:
            account = profile_get(request.user.username)
            return render(request, 'roomhints/designer_profile.html', { "page":page, "account":account } )
        else:
            return HttpResponse()
    else:
        return HttpResponse()

def designer_profile_edit(request):
    up = profuniq_to_prof(request.user.username)
    page = dict()
    page['title'] = "Edit My Profile"
    page['page'] = "designer_profile_edit"
    if request.method == 'GET':
        if request.user.is_authenticated() and up.designer == True:
            account = profile_get(request.user.username)
            return render(request, 'roomhints/designer_profile_edit.html', { "page":page, "account":account } )
        else:
            return HttpResponse()
    elif request.method == 'POST':
        f = open('/tmp/designer_profile_edit','ab+')
        f.write("designer profile edit\n")
        first = request.POST['firstname']
        #last = request.POST['lastname']
        location = request.POST['location']
        aesthetic = request.POST['aesthetic']
        talent = request.POST.get('talent','')
        f.write("talent_words\n")
        talent_words = talent.split()
        talent = " ".join(talent_words[0:3]) # Keep only 3 words
        f.write("talent_words - pass\n")
        username = request.POST['username']
        website = request.POST['website']
        is_betainvite = request.POST.get('is_betainvite','')
        f.write("talent_words - pass\n")
        f.write("is_betainvite"  + str(is_betainvite) + "\n")
        up = profuniq_to_prof(request.user.username)
        f.write("up - pass\n")
        up.user.first_name = first
        up.user.username = username
        f.write("set username\n")
        #up.user.last_name = last
        up.location = location
        up.aesthetic = aesthetic
        up.talent = talent
        up.website = website
        f.write("website is " + website + "\n")
        found_file = False
        if 'uploaded_file_headshot' in request.FILES.keys():
            up.photo_headshot = 'pics/headshots/' + make_unique(36) + ".jpg"
            handle_uploaded_file(request.FILES['uploaded_file_headshot'],settings.MEDIA_ROOT + up.photo_headshot.name)
            temp_pic_color = '/tmp/' + make_unique(36) + ".jpg"
            photo_square(settings.MEDIA_ROOT + up.photo_headshot.name, temp_pic_color, "320")
            shutil.copy(temp_pic_color, settings.MEDIA_ROOT + up.photo_headshot.name)
            found_file = True

        f.write("headshot - pass\n")
        found_file = False
        if 'uploaded_file_vertshot' in request.FILES.keys():
            up.photo_vertshot = 'pics/vertshots/' + make_unique(36) + ".jpg"
            handle_uploaded_file(request.FILES['uploaded_file_vertshot'],settings.MEDIA_ROOT + up.photo_vertshot.name)
            found_file = True
        f.write("vertshot - pass\n")
        up.user.save()
        up.save()
        if is_betainvite == "yes":
            f.write("is_betainvite, so will redirect to /designer")
            return HttpResponseRedirect('/designer')
        else:
            f.write("NOT is_betainvite, so will redirect to /designer/profile")
            return HttpResponseRedirect('/designer/profile')
    else:
        return HttpResponse()

def designer_invite_beta(request):
    up = profuniq_to_prof(request.user.username)
    page = dict()
    page['title'] = "Invite Beta Users"
    page['page'] = "designer_invite_beta"
    if search_profile_id() == up.id or 798 == up.id: # Tiff and I
        if request.user.is_authenticated() and up.designer == True:
            if request.method == 'GET':
                betauniq = request.GET.get('betauniq','')
                if betauniq != "":
                    # Submitted a betauniq: inviting a designer
                    b = Beta.objects.filter(betauniq=betauniq).get()
                    mes = MyEmailSend()
                    content = "Hi!\n\nYou have been selected to join our beta.\n\nYou can do so by clicking the link below and following the instructions:\nhttp://roomhints.com/beta/invite?betauniq=" + b.betauniq + "\n\nWelcome, to the RoomHints community.\n\nRoomHints"
                    mes.send_email('RoomHints: Beta Invited',content,'in.style@roomhints.com',[b.email,'in.style@roomhints.com'],'smtp.gmail.com','in.style@roomhints.com','roomhints1')
                    b.invited = True
                    b.save()
                    return HttpResponseRedirect('/designer/invite/beta')
                else:
                    # Just show designers
                    ball = Beta.objects.filter(am_designer=True).order_by('seconds')
                    betas = []
                    page['count'] = len(ball)
                    if len(ball) > 0:
                        for b in ball:
                            betas.append(b)
                    return render(request, 'roomhints/designer_invite_beta.html', { "page":page, "betas":betas } )
        else:
            return HttpResponse()
    else:
        return HttpResponse()
        
def designer_hint_send(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:

        latest_rooms = rooms_list(not_hidden_sql(False))

        hintuniq = request.GET.get('hintuniq')
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        page = dict()
        page['title'] = title
        page['page'] = "designer_hint_send"
        page['is_designer'] = up.designer

        if up.designer:
            return render(request, 'roomhints/designer_hint_send.html', { "latest_rooms":latest_rooms, "page":page, "hint":h } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms_paying(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        paying_rooms = rooms_list(not_hidden_sql(True))

        page = dict()
        page['title'] = "Paying"
        page['page'] = "designer_rooms_paying"
        page['is_designer'] = up.designer
        page['room_count'] = len(paying_rooms)

        if up.designer:
            return render(request, 'roomhints/designer_rooms_paying.html', { "paying_rooms":paying_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def rooms_list(sql):
    rooms = []
    cursor = connection.cursor()
    cursor.execute(sql)
    f = open('/tmp/waiting','ab+')
    for row in cursor.fetchall():
        f.write("row is " + str(row) + "\n")
        room_item = dict()
        room_item['projuniq'] = row[0]
        room_item['photo'] = row[1]
        room_item['custom'] = row[2]
        room_item['date'] = row[3]
        room_item['budget'] = "no budget"
        if row[4] != -1:
            room_item['budget'] = "budget: $" + str(row[4])
        room_item['age'] = seconds_to_age(row[3])
        rooms.append(room_item)
    cursor.close()
    return rooms

def waiting_sql(is_paying):
    # Look for rooms for which the user did not yet receive at least one
    # hint from a designer (except if the designer asked a question), or
    # if there were any comments in that room
    # the last comment was not from a designer (it was from a user)
    def last_comment_from(designer):
        return "(select project_id from (select c.project_id, up.designer from roomhints_comment c, roomhints_profile up where c.project_id = p.id and c.profile_id = up.id order by c.seconds desc limit 1) allcomm where designer = " + designer + ")"

    sql = "select p.projuniq,p.photo_mob,p.custom,p.seconds,p.budget from roomhints_project p, roomhints_roomtype rt"
    if is_paying:
        sql+= ", roomhints_profile up"
    sql += " where p.public = true and p.hide = false and p.roomtype_id = rt.id and rt.name='decorate' and (p.id not in (select distinct project_id from roomhints_roomhint rh, roomhints_profile up where rh.profile_id = up.id and up.designer=true) or p.id in " + last_comment_from("false") + ") and (p.id not in " + last_comment_from("true") + ") "
    if is_paying:
        sql += "and p.profile_id = up.id and up.stripe_id is not null and up.charge_seconds > now() - interval '" + str(paid_days) + " day' "
    sql += "order by seconds asc"
    return sql

def not_hidden_sql(is_paying,name=None,not_name=False):
    sql = "select p.projuniq,p.photo_mob,p.custom,p.seconds,p.budget from roomhints_project p, roomhints_roomtype rt"
    if is_paying:
        sql += ", roomhints_profile up"
    sql += " where p.public = true and p.hide = false and p.roomtype_id = rt.id and rt.name = 'decorate'"
    if name != None:
        sql += " and p.custom "
        if not_name:
            sql+= "not "
        sql += "like '%" + name + "%'"
    if is_paying:
        sql += " and p.profile_id = up.id and up.stripe_id is not null and up.charge_seconds > now() - interval '" + str(paid_days) + " day' and p.charge_seconds > now() - interval '" + str(paid_days) + " day'"
    sql += "order by seconds asc"
    return sql

def designer_rooms_waiting(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        rt_decorate = RoomType.objects.filter(name="decorate").get()

        waiting_rooms = rooms_list(not_hidden_sql(False))

        page = dict()
        page['title'] = "Waiting"
        page['page'] = "designer_rooms_waiting"
        page['is_designer'] = up.designer
        page['room_count'] = len(waiting_rooms)

        if up.designer:
            return render(request, 'roomhints/designer_rooms_waiting.html', { "waiting_rooms":waiting_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms_looking(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "Looking"
        page['page'] = "designer_rooms_looking"
        page['is_designer'] = up.designer
        looking_rooms = []

        def last_action(designer):
            search_sql = ""
            if designer == "false":
                # Also account for search queries
                search_sql = " union select * from (select sig.project_id, max(sig.seconds) as seconds from roomhints_searchimpressiongroup sig group by sig.project_id order by sig.project_id desc, max(sig.seconds) desc) as sigmax"
            sql = "select final.project_id, max(final.seconds) as seconds from (select * from (select c.project_id, max(c.seconds) as seconds from roomhints_comment c, roomhints_profile up where c.profile_id = up.id and up.designer = " + designer + " group by c.project_id order by c.project_id desc, max(c.seconds) desc) as cmax union select * from (select rh.project_id, max(rh.seconds) as seconds from roomhints_roomhint rh, roomhints_profile up where rh.profile_id = up.id and up.designer = " + designer + " group by rh.project_id order by rh.project_id desc, max(rh.seconds) desc) as rhmax " + search_sql + " order by seconds desc) as final group by final.project_id order by final.project_id desc, max(final.seconds) desc"
            return sql

        last_user_action_sql = last_action("false")
        last_designer_action_sql = last_action("true")

        last_action_sql = "select lastuser.project_id, lastuser.seconds, lastdesigner.seconds, case when lastdesigner.seconds is null then true else lastuser.seconds > lastdesigner.seconds end as looking from (" + last_user_action_sql + ") as lastuser full outer join (" + last_designer_action_sql + ") as lastdesigner on lastuser.project_id = lastdesigner.project_id"
        last_action_sql = "select project_id from (" + last_action_sql + ") as lastaction_projects where looking = true"

        #f = open('/tmp/looking','ab+')
        #f.write("last_action_sql is: " + last_action_sql + "\n")
        sql = "select p.projuniq, p.photo_mob, p.custom, p.seconds, p.budget from roomhints_project p, roomhints_roomtype rt, (" + last_action_sql + ") as lastaction where p.public = true and p.hide = false and p.roomtype_id = rt.id and rt.name = 'decorate' and p.id = lastaction.project_id order by seconds asc"
        looking_rooms = rooms_list(sql)
        page['room_count'] = len(looking_rooms)

        if up.designer:
            return render(request, 'roomhints/designer_rooms_looking.html', { "looking_rooms":looking_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def designer_feedback(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer:

        page = dict()
        page['title'] = "Feedback"
        page['page'] = "designer_feedback"
        page['is_designer'] = up.designer

        comments = []
        startdate = datetime.utcnow().replace(tzinfo=utc)
        enddate = startdate - timedelta(days=21)
        call = Feedback.objects.filter(seconds__gt=enddate).order_by('-seconds')
        if len(call) > 0:
            for c in call:
                citem = dict()
                citem['content'] = c.content
                citem['feeduniq'] = c.feeduniq
                citem['profile_id'] = c.profile_id
                pall = Project.objects.filter(profile_id=c.profile_id)
                if len(pall) > 0:
                    p = pall[0]
                    citem['last_projuniq'] = p.projuniq
                    citem['show_last_projuniq'] = p.projuniq[:6]
                    citem['photo'] = p.photo_mob.name
                    citem['age'] = seconds_to_age(c.seconds)
                    comments.append(citem)
        
        return render(request, 'roomhints/designer_feedback.html', { "page":page, "comments":comments })
    else:
        return HttpResponseRedirect('/designer/login')

def designer_feedback_contact(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        profile_id = None
        if request.method == "GET":
            profile_id = request.GET.get('profile_id')
            page['processed'] = "no"
        elif request.method == "POST":
            profile_id = request.POST.get('profile_id')
            page['processed'] = "yes"
            user_profile = Profile.objects.filter(pk=profile_id).get()
            comment = request.POST.get('comment')
            f = open('/tmp/comment','ab+')
            f.write("push comment is  " + comment + "\n")
            if len(comment) > push_max():
                comment_size = len(comment)
                f.write("push comment was above max")
                return render(request, 'roomhints/comment_result.html', { "comment_limit":push_max(), "comment_size":comment_size } )
            else:
                f.write("push comment was NOT above max\n")
                f.write("up.id is " + str(up.id) + "\n")
                d_all = Device.objects.filter(device_token=user_profile.device.device_token)
                if len(d_all) > 0:
                    d = d_all[0]
                    d.last_notified_at = datetime.utcnow().replace(tzinfo=utc)
                    d.save()
                    d.send_message(comment)

        page['title'] = title
        page['page'] = "room"
        page['is_designer'] = up.designer
        page['profile_id'] = profile_id
        return render(request, 'roomhints/designer_feedback_contact.html', { "page":page })

def designer_questions(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:

        page = dict()
        page['title'] = "Questions"
        page['page'] = "designer_questions"
        page['is_designer'] = up.designer

        comments = []
        startdate = datetime.utcnow().replace(tzinfo=utc)
        enddate = startdate - timedelta(days=7)
        #call = Comment.objects.order_by('-seconds')[:30]
        call = Comment.objects.filter(seconds__gt=enddate,public=True).order_by('-seconds')
        if len(call) > 0:
            for c in call:
                citem = dict()
                citem['content'] = c.content
                citem['communiq'] = c.communiq
                pall = Project.objects.filter(pk=c.project_id,public=True)
                if len(pall) > 0:
                    p = pall[0]
                    citem['projuniq'] = p.projuniq
                    citem['showprojuniq'] = p.projuniq[:6]
                    citem['photo'] = p.photo_mob.name
                    citem['age'] = seconds_to_age(c.seconds)
                    citem['name'] = c.profile.user.first_name
                    citem['received'] = False
                    if c.received_seconds != None:
                        citem['received'] = True
                    if c.profile.designer:
                        citem['sent_by_designer'] = True
                    else:
                        citem['sent_by_designer'] = False
                    citem['push_sent'] = comment_pushed(c)
                    comments.append(citem)
        
        return render(request, 'roomhints/designer_questions.html', { "page":page, "comments":comments })
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        p_show = []
        cursor = connection.cursor()
        cursor.execute("select projuniq, photo_mob, custom, seconds, budget from roomhints_project p, roomhints_roomtype rt where p.roomtype_id = rt.id and ((rt.name = 'showroom_user' and p.approved = true) or rt.name='showroom') and p.profile_id = " + str(up.id))
        for row in cursor.fetchall():
            p = Project()
            p.profile_id = up.id
            p.projuniq = row[0]
            p.photo_mob = row[1]
            p.custom = row[2]
            p.seconds = row[3]
            p.budget = row[4]
            p_show.append(p)
        cursor.close()
        show_rooms = prep_rooms(p_show)

        page = dict()
        page['title'] = title
        page['page'] = "designer_rooms"
        page['is_designer'] = up.designer

        if up.designer:
            return render(request, 'roomhints/designer_rooms.html', { "projects":show_rooms, "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/login')

def designer_rooms_delete(request):
    up = profuniq_to_prof(request.user.username)
    page = dict()
    page['title'] = title
    page['page'] = "designer_rooms_delete"
    page['is_designer'] = up.designer
    page['is_superuser'] = False
    if search_profile_id() == up.id or 798 == up.id: # Tiff and I
        page['is_superuser'] = True
        sure = request.GET.get('sure', '')
        projuniq = request.GET.get('projuniq', '')
        p = Project.objects.filter(projuniq=projuniq).get()
        if p.profile.id == up.id:
            page['owner'] = 1
        else:
            page['owner'] = 0
        if sure == "yes" and page['owner'] == 1:
            p = Project.objects.filter(projuniq=projuniq).get()
            p.public = False
            p.save()
            deleted = dict()
            deleted['name'] = p.name
            deleted['exists'] = True
            request.session['deleted_room'] = deleted
            return HttpResponseRedirect('/designer/rooms/approve')
        else:
            return render(request, 'roomhints/designer_rooms_delete.html', { "project":p, "page":page } )
    else:
        return HttpResponseRedirect('/designer/rooms/approve')

def designer_rooms_approve(request):
    up = profuniq_to_prof(request.user.username)
    page = dict()
    page['title'] = title
    page['page'] = "designer_rooms_approve"
    page['is_designer'] = up.designer
    page['is_superuser'] = False
    if search_profile_id() == up.id or 798 == up.id: # Tiff and I
        page['is_superuser'] = True

        if request.user.is_authenticated() and up.designer == True:
            kind = request.GET.get('kind','')
            if kind != "":
                projuniq = request.GET.get('projuniq','')
                f = open('/tmp/approve','ab+')
                f.write("kind is " + str(kind) + " for projuniq " + str(projuniq))
                p = Project.objects.filter(projuniq=projuniq).get()
                if kind == "publish":
                    p.approved = True
                elif kind == "unpublish":
                    p.approved = False
                p.save()
                return HttpResponseRedirect('/designer/rooms/approve')
            else:
                p_show = []
                cursor = connection.cursor()
                cursor.execute("select projuniq, photo_mob, p.name, seconds, approved, rt.name from roomhints_project p, roomhints_roomtype rt where p.roomtype_id = rt.id and (rt.name = 'showroom_user' or rt.name = 'showroom') and p.public = true order by p.seconds desc")
                for row in cursor.fetchall():
                    p = dict()
                    p['profile_id'] = up.id
                    p['projuniq'] = row[0]
                    p['photo'] = row[1]
                    p['name'] = row[2]
                    p['date'] = row[3]
                    p['approved'] = row[4]
                    p['roomtype'] = row[5]
                    p_show.append(p)
                cursor.close()
                return render(request, 'roomhints/designer_rooms_approve.html', { "projects":p_show, "page":page } )
        else:
            return HttpResponseRedirect('/designer/login')
    else:
        return HttpResponseRedirect('/designer/login')

def prep_hints(allh):
    hints = []
    if len(allh) > 0:
        for h in allh:
            data_item = dict()
            data_item['hintuniq'] = h.hintuniq
            data_item['photo'] = h.photo_web.name
            data_item['price'] = math.ceil(h.price)
            data_item['source'] = h.source
            data_item['source_url'] = h.source_url
            data_item['sku'] = h.sku
            data_item['name'] = h.name
            data_item['age'] = seconds_to_age(h.seconds)
            data_item['love'] = h.love
            data_item['love_count'] = h.love_count
            t = h.seconds
            data_item['seconds'] = calendar.timegm(t.timetuple())
            data_item['dominant_hex'] = h.dominant_hex
            data_item['hinttypes'] = hinttype_get(h.id)
            data_item['hintstyles'] = hintstyle_get(h.id)
            hints.append(data_item)
    return hints

def designer_hints(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "Hints"
        page['page'] = "designer_hints"
        page['is_designer'] = up.designer
        if up.designer:
            return render(request, 'roomhints/designer_hints.html', { "page":page } )
        else:
            return render(request, '404.html')
    else:
        return HttpResponseRedirect('/designer/hints')

def hints_to_hintsbytype(hints_all):
    hints_by_type = dict()
    if len(hints_all) > 0:
        for h in hints_all:
            h_item = dict()
            h_item['hintuniq'] = h.hintuniq
            h_item['photo'] = h.photo_mob.name
            h_item['price'] = math.ceil(h.price)
            h_item['source'] = h.source
            h_item['source_url'] = h.source_url
            h_item['sku'] = h.sku
            h_item['name'] = h.name
            h_item['age'] = seconds_to_age(h.seconds)
            h_item['love'] = h.love
            h_item['love_count'] = h.love_count
            t = h.seconds
            h_item['seconds'] = calendar.timegm(t.timetuple())
            h_item['dominant_hex'] = h.dominant_hex
            h_item['hinttypes'] = hinttype_get(h.id)
            h_item['hintstyles'] = hintstyle_get(h.id)
            htl = hinttypelist_get(h.id)
            for htl_item in htl:
                ht = HintType.objects.filter(pk=htl_item).get()
                if not ht.id in hints_by_type.keys():
                    hints_by_type[ht.id] = dict()
                    hints_by_type[ht.id]['name'] = ht.name
                    hints_by_type[ht.id]['hints'] = []
                hints_by_type[ht.id]['hints'].append(h_item)
            if len(htl) == 0:
                # This hint was not categorized
                # 47 is __Uncategorized__
                ht = HintType.objects.filter(name="__Uncategorized__").get()
                if not ht.id in hints_by_type.keys():
                    hints_by_type[ht.id] = dict()
                    hints_by_type[ht.id]['name'] = ht.name
                    hints_by_type[ht.id]['hints'] = []
                hints_by_type[ht.id]['hints'].append(h_item)

    return hints_by_type                    
    #return sorted(hints_by_type, key=lambda entry: entry['name'],reverse=True)


def designer_hints_view(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        # startdate = datetime.utcnow().replace(tzinfo=utc)
        # enddate = startdate + timedelta(days=7)
        h_show = Hint.objects.filter(profile_id = up.id,public=True).order_by('-seconds')
        show_hints = hints_to_hintsbytype(h_show)

        deleted = None
        if 'deleted_hint' in request.session.keys():
            deleted = copy.copy(request.session['deleted_hint'])
            del request.session['deleted_hint']
        page = dict()
        page['title'] = title
        page['page'] = "designer_hints_view"
        page['is_designer'] = up.designer
        if up.designer:
            return render(request, 'roomhints/designer_hints_view.html', { "show_hints":show_hints, "page":page, "deleted":deleted } )
        else:
            return render(request, '404.html')
    return HttpResponseRedirect('/designer/hints')

def myrooms(request):
    if request.user.is_authenticated():
        up = profuniq_to_prof(request.user.username)
        rt_decorate = RoomType.objects.filter(name="decorate").get()

        p_decorate = Project.objects.filter(profile_id = up.id,roomtype_id = rt_decorate.id)
        decorate_rooms = prep_rooms(p_decorate)
        page = dict()
        page['title'] = title
        page['page'] = "myrooms"
        page['is_designer'] = up.designer

        comments = []
        call = Comment.objects.order_by('-seconds')[:50]
        if len(call) > 0:
            for c in call:
                citem = dict()
                citem['content'] = c.content
                citem['communiq'] = c.communiq
                p = Project.objects.filter(pk=c.project_id).get()
                citem['projuniq'] = p.projuniq
                citem['showprojuniq'] = p.projuniq[:6]
                citem['photo'] = p.photo_mob.name
                citem['age'] = seconds_to_age(c.seconds)
                comments.append(citem)
        
        return render(request, 'roomhints/myrooms.html', { "decorate_rooms": decorate_rooms, "page":page })
    else:
        return HttpResponseRedirect('/designer/login')

def designer_signup(request):
    if request.method == "GET":
        page = dict()
        page['title'] = "Designer Signup"
        page['page'] = "designer_signup"
        f = FrontPhoto.objects.order_by('?')[0] # random select
        front = dict()
        front['photo'] = f.photo_web.name
        return render(request, 'roomhints/designer_signup.html', {"front":front, "page":page} )
    else:
        return HttpResponseRedirect('/designer/signup')

def designer_hint_add(up,request,name,source,source_url,sku,price,hinttypelist,hintstylelist):
    h = Hint()
    h.hintuniq = make_unique(36)
    h.seconds = datetime.utcnow().replace(tzinfo=utc)
    h.name = name
    h.source = source
    h.source_url = source_url
    if price == '':
        price = 0
    h.sku = sku
    price = str(price).replace(',','') # Remove commas from price, ie in: 1,600
    price = float(price)
    h.price = math.ceil(price)
    h.profile_id = up.id
    h.keywords = ""
    h.love_count = 0
    h.photo = 'pics/hints/' + make_unique(36) + ".jpg"
    h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
    h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
    found_file = False
    if 'uploaded_file' in request.FILES.keys():
        handle_uploaded_file(request.FILES['uploaded_file'],settings.MEDIA_ROOT + h.photo.name)
        found_file = True
    if found_file:
        photo_convert(settings.MEDIA_ROOT + h.photo.name,
                      settings.MEDIA_ROOT + h.photo_web.name, "480000")
        photo_convert(settings.MEDIA_ROOT + h.photo.name,
                      settings.MEDIA_ROOT + h.photo_mob.name, "147200")
        color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
        h.dominant_hex = color_hex
    else:
        h.dominant_hex = "ffffff"
    h.save()
    hinttypelist_set(h.id,hinttypelist)
    hintstylelist_set(h.id,hintstylelist)
    # Setup affiliate
    aff = affiliate_data(h)
    ar = affiliate_set(aff['url'],h)
    return h

def designer_hint_add_from_sku(profile_id,sku,aff):
    if aff == None:
        print ("SKU " + str(sku) + " can't be matched")
        return None
    else:
        h = Hint()
        h.hintuniq = make_unique(36)
        h.seconds = datetime.utcnow().replace(tzinfo=utc)
        h.profile_id = profile_id
        h.name = aff['name']
        h.price = aff['price']
        h.source = aff['source']
        h.source_url = aff['url']
        h.sku = sku
        h.photo = 'pics/hints/' + make_unique(36) + ".jpg"
        h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
        h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
        outpath = '/tmp/crawl/' + make_unique_photo()
        try:
            urlretrieve(aff['photo_url'],outpath)
            shutil.copy(outpath, settings.MEDIA_ROOT + h.photo.name)
            crawl_hint_clean(outpath)
            photo_convert(settings.MEDIA_ROOT + h.photo.name,
                          settings.MEDIA_ROOT + h.photo_web.name, "480000")
            photo_convert(settings.MEDIA_ROOT + h.photo.name,
                          settings.MEDIA_ROOT + h.photo_mob.name, "147200")
            color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
            h.dominant_hex = color_hex
            print(str(aff))
            #aff['photo_url']
            h.save()
            ar = affiliate_set(aff['url'],h)
            print("set affiliate url " + h.affiliate_url)
            return h
        except IOError, e:
            # It might be missing
            print("image '" + aff['photo_url'] + "' is missing")
            return None

def designer_hint_new(request):
    up = profuniq_to_prof(request.user.username)

    page = dict()
    page['title'] = title
    page['page'] = "designer_hint_new"
    page['is_designer'] = up.designer

    if request.method == "GET":
        ht = hinttype_get(None)
        hs = hintstyle_get(None)
        return render(request, 'roomhints/designer_hint_new.html', { "page":page, "hinttypes":ht, "hintstyles":hs } )
    elif request.method == "POST":
        f = open('/tmp/designer_hint_new', 'ab+')
        f.write("hint new POST\n")
        name = request.POST['name']
        source = request.POST['source']
        source_url = request.POST['source_url']
        sku = request.POST['sku']
        price = request.POST['price']
        hinttypelist = request.POST.getlist('hinttype_id')
        hintstylelist = request.POST.getlist('hintstyle_id')
        h = designer_hint_add(up,request,name,source,source_url,sku,price,hinttypelist,hintstylelist)
        page['title'] = h.name
        f.close()
        return HttpResponseRedirect('/designer/hint?hintuniq=' + h.hintuniq)
    else:
        return HttpResponseRedirect('/designer/hint/new')

def designer_hint_edit(request):
    profuniq, u, up = make_profuniq(request,'web')
    up = profuniq_to_prof(profuniq)

    page = dict()
    page['title'] = title
    page['page'] = "designer_hint_edit"
    page['is_designer'] = up.designer
    page['heading'] = "Edit This Product"

    hintuniq = request.GET.get('hintuniq', '')
    h = Hint.objects.filter(hintuniq=hintuniq).get()
    if h.profile.id == up.id:
        page['owner'] = 1
    else:
        page['owner'] = 0

    if request.method == "GET":
        ht = hinttype_get(h.id)
        hs = hintstyle_get(h.id)
        f = open('/tmp/designer_hint_edit_get','ab+')
        f.write("ht is: " + str(ht) + "\n" + str(h.id) + "\n")
        f.write("hs is: " + str(hs) + "\n" + str(h.id) + "\n")
        if h.cx == None:
            h.cx = 0
        if h.cy == None:
            h.cy = 0
        if h.cw == None:
            h.cw = 0
        if h.ch == None:
            h.ch = 0
        return render(request, 'roomhints/designer_hint_edit.html', { "hint":h, "page":page, "hinttypes":ht, "hintstyles":hs } )
    elif request.method == "POST":
        if page['owner'] == 0:
            # Do not process the change if not the hints owner
            return HttpResponseRedirect('/designer/hint?hintuniq=' + h.hintuniq)

        f = open('/tmp/designer_hint_edit', 'ab+')
        f.write("hint edit POST\n")
        name = request.POST['thename']
        source = request.POST['source']
        source_url = request.POST['source_url']
        sku = request.POST['sku']
        price = request.POST['price']
        hinttypelist = request.POST.getlist('hinttype_id')
        hintstylelist = request.POST.getlist('hintstyle_id')
        dominant_hex = request.POST['dominant_hex']
        x1 = request.POST['x1']
        x2 = request.POST['x2']
        y1 = request.POST['y1']
        y2 = request.POST['y2']
        cw = request.POST['w']
        ch = request.POST['h']
        h.cx = x1
        h.cy = y1
        h.cw = cw
        h.ch = ch
        h.name = name
        h.source = source
        h.source_url = source_url
        h.sku = sku
        h.price = price
        hinttypelist_set(h.id,hinttypelist)
        hintstylelist_set(h.id,hintstylelist)
        h.dominant_hex = dominant_hex
        if 'uploaded_file' in request.FILES.keys(): # We might be called from designer_hint_new_url
            uploaded_filename = request.FILES['uploaded_file']
            if uploaded_filename != '':
                handle_uploaded_file(request.FILES['uploaded_file'],settings.MEDIA_ROOT + h.photo.name)
                h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
                h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
                photo_convert(settings.MEDIA_ROOT + h.photo.name,
                              settings.MEDIA_ROOT + h.photo_web.name, "480000")
                photo_convert(settings.MEDIA_ROOT + h.photo.name,
                              settings.MEDIA_ROOT + h.photo_mob.name, "147200")
        h.save()
        page['title'] = h.name
        f.close()
        return HttpResponseRedirect('/designer/hint?hintuniq=' + h.hintuniq)
    else:
        return HttpResponseRedirect('/designer/hint/edit')

def designer_hint_delete(request):
    profuniq, u, up = make_profuniq(request,'web')
    up = profuniq_to_prof(profuniq)

    page = dict()
    page['title'] = title
    page['page'] = "designer_hint_delete"
    page['is_designer'] = up.designer

    if request.method == "GET":
        hintuniq = request.GET.get('hintuniq', '')
        sure = request.GET.get('sure', '')
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        if h.profile.id == up.id:
            page['owner'] = 1
        else:
            page['owner'] = 0
        if sure == "yes" and page['owner'] == 1:
            h = Hint.objects.filter(hintuniq=hintuniq).get()
            h.public = False
            h.save()
            deleted = dict()
            deleted['price'] = math.ceil(h.price)
            deleted['name'] = h.name
            deleted['exists'] = True
            request.session['deleted_hint'] = deleted
            page['page'] = "designer_hints_view"
            return HttpResponseRedirect('/designer/hints')
        else:
            ht = hinttype_get(h.id)
            hs = hintstyle_get(h.id)
            return render(request, 'roomhints/designer_hint_delete.html', { "hint":h, "page":page, "hinttypes":ht, "hintstyles":hs } )
    else:
        return HttpResponseRedirect('/designer/hint?hintuniq=' + h.hintuniq)

def designer_hint_new_many(request):
    profuniq, u, up = make_profuniq(request,'web')
    up = profuniq_to_prof(profuniq)

    page = dict()
    page['title'] = title
    page['page'] = "designer_hint_new_many"
    page['is_designer'] = up.designer

    def untangle(tokens,char):
        ret = []
        for t in tokens:
            items = t.split(char)
            for i in items:
                i = i.strip('\r\n')
                ret.append(i)
        return ret
        
    if request.method == "GET":
        ht = hinttype_get(None)
        hs = hintstyle_get(None)
        return render(request, 'roomhints/designer_hint_new_many.html', { "page":page, "hinttypes":ht, "hintstyles":hs } )
    elif request.method == "POST":
        f = open('/tmp/designer_hint_new_many', 'ab+')
        f.write("hint new POST\n")
        source = request.POST['source']
        skus = request.POST['skus']
        skulist = untangle([ skus ],'\n')
        skulist = untangle(skulist,',')
        f.write('skulist is ' + str(skulist) + '\n')
        hinttypelist = request.POST.getlist('hinttype_id')
        f.write('hinttypelist is ' + str(hinttypelist) + '\n')
        hintstylelist = request.POST.getlist('hintstyle_id')
        f.write('hintstylelist is ' + str(hintstylelist) + '\n')
        skus_loaded = []
        skus_failed = []
        for sku in skulist:
            if sku != "": # If there were blank lines, ignore blank skus
                # Add SKUs for this vendor only if they were not added already
                cursor = connection.cursor()
                sql = "select id from roomhints_hint where lower(source)=%s and sku=%s and profile_id=" + str(up.id) + " and public=true"
                f.write("sql is " + sql + "\n")
                cursor.execute(sql,[ source.lower(), sku ])
                match = False
                for row in cursor.fetchall():
                    f.write('sku ' + sku + " found for " + source.lower() + "\n")
                    match = True
                cursor.close()
                if match == False:
                    f.write('no existing sku ' + sku + "\n")
                    # There is no such existing SKU. Add the new one
                    aff = affiliate_data_from_sku(sku)
                    if aff != None:
                        h = designer_hint_add_from_sku(up.id,sku,aff)
                        if h == None:
                            skus_failed.append(sku)
                        else:
                            hinttypelist_set(h.id,hinttypelist)
                            hintstylelist_set(h.id,hintstylelist)
                            sku_item = dict()
                            sku_item['sku'] = sku
                            sku_item['hintuniq'] = h.hintuniq
                            sku_item['photo'] = h.photo_mob.name
                            skus_loaded.append(sku_item)
                    else:
                        skus_failed.append(sku)
                else:
                    skus_failed.append(sku)
        f.close()

        return render(request, 'roomhints/designer_hint_new_many_result.html', { "page":page, "skus_loaded":skus_loaded, "skus_failed":skus_failed, "source":source } )
    else:
        return HttpResponseRedirect('/designer/hint/new_many')

def hinttypelist_set(hint_id,hinttypeslist):
    HintTypeList.objects.filter(hint_id=hint_id).delete()
    for ht_id in hinttypeslist:
        htl = HintTypeList()
        htl.hint_id = hint_id
        htl.hinttype_id = ht_id
        htl.save()
    
def hinttypelist_get(hint_id):
    hinttypeslist = []
    if hint_id != None:
        ht_all = HintTypeList.objects.filter(hint_id=hint_id)
        if len(ht_all) > 0:
            for htl in ht_all:
                hinttypeslist.append(htl.hinttype_id)
    return hinttypeslist

def hinttype_get(hint_id):
    htl = hinttypelist_get(hint_id)
    ht_all = HintType.objects.order_by('name').all()
    ht = []
    for this_ht in ht_all:
        ht_item = dict()
        ht_item['id'] = this_ht.id
        ht_item['name'] = this_ht.name
        if this_ht.id in htl:
            ht_item['checked'] = 1
        else:
            ht_item['checked'] = 0
        ht.append(ht_item)
    return ht

# If only this were Arc..
def hintstylelist_set(hint_id,hintstyleslist):
    HintStyleList.objects.filter(hint_id=hint_id).delete()
    for hs_id in hintstyleslist:
        hsl = HintStyleList()
        hsl.hint_id = hint_id
        hsl.hintstyle_id = hs_id
        hsl.save()
    
def hintstylelist_get(hint_id):
    hintstyleslist = []
    if hint_id != None:
        hs_all = HintStyleList.objects.filter(hint_id=hint_id)
        if len(hs_all) > 0:
            for hsl in hs_all:
                hintstyleslist.append(hsl.hintstyle_id)
    return hintstyleslist

def hintstyle_get(hint_id):
    hsl = hintstylelist_get(hint_id)
    hs_all = HintStyle.objects.order_by('name').all()
    hs = []
    for this_hs in hs_all:
        hs_item = dict()
        hs_item['id'] = this_hs.id
        hs_item['name'] = this_hs.name
        if this_hs.id in hsl:
            hs_item['checked'] = 1
        else:
            hs_item['checked'] = 0
        hs.append(hs_item)
    return hs

def designer_hint_new_url(request):
    profuniq, u, up = make_profuniq(request,'web')
    up = profuniq_to_prof(profuniq)

    page = dict()
    page['title'] = title
    page['page'] = "designer_hint_new_url"
    page['is_designer'] = up.designer
    page['heading'] = "Verify This Product"

    if request.method == "GET":
        ht = hinttype_get(None)
        hs = hintstyle_get(None)
        return render(request, 'roomhints/designer_hint_new_url.html', { "page":page, "hinttypes":ht, "hintstyles":hs } )
    elif request.method == "POST":
        f = open('/tmp/designer_hint_new_url', 'ab+')
        f.write("hint new url POST\n")
        f.write("\n")
        url = request.POST['url']
        hinttypelist = request.POST.getlist('hinttype_id')
        hintstylelist = request.POST.getlist('hintstyle_id')
        f.write("received hinttypelist " + str(hinttypelist) + " and url " + str(url) + "\n")
        f.write("received hintstylelist " + str(hintstylelist) + " and url " + str(url) + "\n")

        sql = "select id from roomhints_hint where source_url = %s and public = true and profile_id = " + str(up.id)
        cursor = connection.cursor()
        cursor.execute(sql, [url])
        match = False
        match_hint_id = None
        for row in cursor.fetchall():
            match_hint_id = row[0]
            f.write("source_url " + url + " already exists\n")
            match = True
        cursor.close()

        if match == False:
            f.write("no existing source_url " + url + "\n")

            crawl_price = None
            crawl_name = None
            crawl_source = None
            crawl_photo_url = None
            crawl_photo = None
            crawl_price, crawl_name, crawl_source, crawl_photo_url, crawl_photo, crawl_all_imgs = crawl_hint(url)
            #f.write("hint new url - 3 - crawl_price is " + str(crawl_price) + " for item called " + str(crawl_name) + " and crawl_source is " +  str(crawl_source) + " and crawl_photo_url is " + str(crawl_photo_url) + " and crawl_photo is " + str(crawl_photo) + "\n")
            h = Hint()
            h.sku = ""
            h.keywords = ""
            h.profile_id = up.id
            h.name = crawl_name
            h.source = crawl_source
            h.source_url = url
            h.photo = 'pics/hints/' + make_unique(36) + ".jpg"
            h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
            h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
            f.write("crawl_photo is " + str(crawl_photo) + "\n")
            shutil.copy(crawl_photo, settings.MEDIA_ROOT + h.photo.name)
            crawl_hint_clean(crawl_photo)
            if crawl_price == None:
                crawl_price = 0
            h.price = crawl_price
            photo_convert(settings.MEDIA_ROOT + h.photo.name,
                          settings.MEDIA_ROOT + h.photo_web.name, "480000")
            photo_convert(settings.MEDIA_ROOT + h.photo.name,
                          settings.MEDIA_ROOT + h.photo_mob.name, "147200")
            color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
            h.dominant_hex = color_hex
            h.save()
            hinttypelist_set(h.id,hinttypelist)
            hintstylelist_set(h.id,hintstylelist)
            f.write("add from url - 8\n")
            ht = hinttype_get(h.id)
            hs = hintstyle_get(h.id)
            f.write("will show designer_hint_edit.html with checked hinttypes " + str(ht) + "\n")
            page['owner'] = True
            return render(request, 'roomhints/designer_hint_edit.html', { "hint":h, "page":page, "hinttypes":ht, "hintstyles":hs } )
        else:
            h = Hint.objects.filter(pk=match_hint_id).get()
            page['page'] = "designer_hint_new_url_result"
            return render(request, 'roomhints/designer_hint_new_url_result.html', {"page":page, "hint":h})
    else:
        return HttpResponseRedirect('/designer/hint/new_url')

def designer_login(request):
    if request.method == "GET":
        return render(request, 'roomhints/login.html')
    elif request.method == "POST":
        ok = False
        username = request.POST.get('username','')
        password = request.POST.get('password','')
        if "@" in username:
            try:
                user = User.objects.get(email=username)
                username = user.username
            except:
                messages.error(request, 'Username not exists.')
        u = authenticate(username=username,password=password)
        if u:
            ok = True
        else:
            messages.error(request, 'Username or password not match.')
        
        if ok:
            print "OK"
            if u.is_active:
		print "LOGIN"
                login(request,u)
                request.session['profuniq'] = username
                return HttpResponseRedirect('/designer')
    
    return render(request, 'roomhints/login.html')

def designer_logout(request):
    try:
        logout(request)
        del request.session['profuniq']
    except KeyError:
        pass
    return render(request, 'roomhints/designer_logout.html')

def beta(request):
    if request.method == 'POST': # If the form has been submitted...
        #form = BetaForm(csrf(request.POST)) # A form bound to the POST data
        form = BetaForm(request.POST)
        if form.is_valid(): # All validation rules pass
            # Process the data in form.cleaned_data
            b = Beta()
            b.email = form.cleaned_data['email']
            b.am_designer = form.cleaned_data['am_designer']
            b.want_designer = form.cleaned_data['want_designer']
            if 'am_brand' in form.cleaned_data.keys(): #fixme: don't know why this is broken
                b.am_brand = form.cleaned_data['am_brand']
            b.betauniq = make_unique(6)
            b.seconds = datetime.utcnow().replace(tzinfo=utc)
            b.notifiedus = False
            b.notifiedthem = False
            b.save()
            return HttpResponseRedirect('/beta/request')
        else:
            return HttpResponseRedirect('/beta/invalid')
    else:
        return HttpResponse()
        form = BetaForm()

    return render(request, 'roomhints/index.html', { 'form': form })

def beta_invalid(request):
    return render(request, 'roomhints/beta_invalid.html')

def beta_request(request):
    t = loader.get_template('roomhints/beta_request.html')
    c = RequestContext(request,{})
    return HttpResponse(t.render(c))

def beta_invite(request):
    betauniq = request.GET.get('betauniq','')
    ball = Beta.objects.filter(betauniq=betauniq)
    if len(ball) > 0:
        b = ball[0]
        page = dict()
        page['title'] = "RoomHints Beta Invite"
        page['page'] = "designer_beta_invite"
        page['betauniq'] = betauniq
        if request.method == "GET":
            return render (request, 'roomhints/beta_invite.html', { "page":page })
        elif request.method == "POST":
            # Copy-pasted from def account. There is uncertainty at present.
            f = open('/tmp/beta_invite','ab+')
        
            password = request.POST.get('password','')
            password2 = request.POST.get('password2','')
            username = request.POST.get('username','')
            name = request.POST.get('name','')

            account = dict()
            account['username'] = username
            account['password'] = password
            account['password2'] = password2
            account['error'] = False
            existing_users = User.objects.filter(email=username)
            if len(existing_users) == 1:
                # This email already exists
                account['error'] = "This username already exists."
                return render(request, 'roomhints/beta_invite.html', { "page":page, "account": account } )

            existing_users = User.objects.filter(username=username)
            if len(existing_users) == 1:
                # This email already exists
                account['error'] = "This username already exists."
                return render(request, 'roomhints/beta_invite.html', { "page":page, "account": account } )

            if password != password2:
                account['error'] = "The passwords entered don't match."
                return render(request, 'roomhints/beta_invite.html', { "page":page, "account": account } )


            u = None
            up = None
            profuniq, u, up = make_profuniq(request,'web')
            up = profuniq_to_prof(profuniq)
            f.write("up is " + str(up) + "\n")
            f.write("u is " + str(u) + " and up.id is " + str(up.id) + "\n")
            f.close()
            # Make the account have this username
            # First make the user login, else set_password will fail
	    u = authenticate(username=profuniq, password=password)
            u.first_name = name
            f = open('/tmp/pass', 'ab+')
            f.write("will set the password '" + password + "' for user " + str(u) + " that will get username " + str(username) + "\n")
            u.set_password(password)
            if validateEmail(username):
                u.email = username
            u.username = username
            u.save()
            # NOTE: We make them designers
            up.designer = True
            up.has_account = True
            up.save()
            login(request,u)
            request.session['profuniq'] = u.username
            #return HttpResponseRedirect('/designer')
            page['title'] = "Fill-In Your Profile"
            page['page'] = "designer_profile_edit_beta_invite"
            page['is_betainvite'] = True
            b.used = True
            b.save()
            return render (request, 'roomhints/designer_profile_edit.html', { "page":page, "account":account })
    else:
        return render (request, 'roomhints/beta_invite_invalid.html')

def app(request):
    return HttpResponseRedirect('https://itunes.apple.com/us/app/room-hints-interior-design/id572215690?ls=1&mt=8')

def signup(request):
    return HttpResponseRedirect('http://roomhints.com')
    
@csrf_exempt
def api_v3_project(request):
    data = dict()
    data['newest'] = []        

    max_entries = 10
    roomsetting = request.GET.get('roomsetting','')
    seconds = request.GET.get('seconds','')
    if seconds == '' or seconds == '0':
        # If no seconds are supplied, show few entries from recentnly
        t = datetime.utcnow().replace(tzinfo=utc) - timedelta(days=300)
        seconds = calendar.timegm(t.timetuple())
    else:
        seconds = int(seconds)
    seconds_todatetime = datetime.fromtimestamp(seconds+1)

    all = None
    rt = RoomType.objects.filter(name="showroom").get()
    if roomsetting != "" and roomsetting != "all":
        rs = RoomSetting.objects.filter(name=roomsetting).get()
        all = Project.objects.filter(public=True,roomtype_id=rt.id,roomsetting_id=rs.id).order_by('-seconds').filter(seconds__gt=seconds_todatetime).order_by('seconds')[:max_entries]
    else:
        all = Project.objects.filter(public=True,roomtype_id=rt.id).order_by('-seconds').filter(seconds__gt=seconds_todatetime).order_by('seconds')[:max_entries]
    for p in all:
        value = dict()
        value['projuniq'] = p.projuniq
        value['name'] = p.name
        #value['seconds'] = p.seconds
        value['custom'] = p.custom
        value['photobefore_url'] = settings.MEDIA_URL + p.photo_mob.name
        t = p.seconds
        value['seconds'] = calendar.timegm(t.timetuple())
        data['newest'].append(value)

    ret = json.dumps(data, sort_keys=True, indent=4)
    return HttpResponse(ret)

def handle_uploaded_file(f,name):
    with open(name, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

def photo_square(big,small,square_dim):
    dims = square_dim + "x" + square_dim
    p = subprocess.Popen("convert -define jpeg:size=" + dims + " " + big +
                         " -gravity center -extent " + dims + " -auto-orient " + small, shell=True,
                         stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    response = p.communicate(input=the_input)[0]

def add_hints_automatically(p):
    query = p.custom
    search_data = search(query)
    for defhint in search_data['search']:
        h = Hint()
        h.hintuniq = make_unique(36)
        h.seconds = datetime.utcnow().replace(tzinfo=utc)
        h.price = math.ceil(defhint['price'])
        h.source = defhint['name'] + ", " + defhint['source']
        h.source_url = defhint['source_url']
        h.sku = defhint['sku']
        h.keywords = ""
        h.photo = 'pics/hints/' + make_unique(36) + ".jpg"
        h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
        h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
        shutil.copy(settings.MEDIA_ROOT + defhint['photo'], settings.MEDIA_ROOT + h.photo.name)
        photo_convert(settings.MEDIA_ROOT + h.photo.name,
                      settings.MEDIA_ROOT + h.photo_web.name, "480000")
        photo_convert(settings.MEDIA_ROOT + h.photo.name,
                      settings.MEDIA_ROOT + h.photo_mob.name, "147200")
        color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
        h.dominant_hex = color_hex
        h.save()

# ngnix sets HTTP_X_REAL_IP
def get_ip(request):
    return request.META['HTTP_X_REAL_IP']

 # So we can authenticate in the future
anonymous_password='ColemakBeatsDvorak'
def profile_add(request,origin):
    username = make_unique(12)
    password = anonymous_password
    u = User.objects.create_user(username,'',password)
    u.save()
    up = Profile()
    up.user_id = u.id
    up.designer = False
    up.origin = origin
    up.has_account = False
    up.ip = get_ip(request)
    up.save()
    #u = authenticate(username=username,password=password)
    #login(request,u)
    d = Device()
    d.last_notified_at = datetime.utcnow().replace(tzinfo=utc)
    # We need to have unique device_tokens in the table to create a profile
    d.device_token = make_unique(36)
    d.save()
    up.device_id = d.id
    up.save()
    return u, up

def api_v3_start_pre(request):
    if request.method == 'GET':
        data = dict()
        data['message'] = "HOW IT WORKS: Take a photo of a room or space to decorate.\n\nWHAT YOU GET: Use our advanced furniture search tool to find matching furniture for your room.\n\nChat with a designer for friendly style guidance at any time."
        data['height'] = 245
        data['camera_y'] = 260
        data['label_y'] = 50
        # Keep 'ask' for backward compatibility
        data['ask'] = "Do you want a designer to give hints for your room?"
        data['ask_height'] = 50
        data['inform'] = "We received your room photo.\n\nIf you would like style guidance, you can always chat with a designer.\n\nYOU CAN NOW make your own design decisions using our advanced furniture search tool. It finds furniture that matches your room style, colors, and preferred price range."
        data['inform_height'] = 275
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    else:
        return HttpResponse()

@csrf_exempt
def api_v3_profile_add(request):
    if request.method == 'POST':
        u, up = profile_add(request,"mobile")

        data = dict()
        data['profuniq'] = u.username
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)

    return HttpResponse()

# Adding this in utils reports: Error: cannot import name Project
def project_paid(project_id):
    startdate = datetime.utcnow().replace(tzinfo=utc)
    enddate = startdate - timedelta(days=paid_days)
    pall = Project.objects.filter(pk=project_id,public=True).all()
    if len(pall) > 0:
        p = pall[0]
        if p.charge_seconds != None: # and p.charge_seconds > enddate:
            t = p.charge_seconds
            seconds_created = calendar.timegm(t.timetuple())
            paid_seconds_duration = paid_days * 24 * 60 * 60 # 1 day extra to be sure
            seconds_todatetime = datetime.fromtimestamp(seconds_created+paid_seconds_duration).replace(tzinfo=utc)
            seconds_now = datetime.utcnow().replace(tzinfo=utc)
            if seconds_todatetime > seconds_now:
                return True, seconds_todatetime

    return False, None

def api_v3_profile(request):
    if request.method == 'GET':
        data = dict()
        f = open('/tmp/profile','ab+')
        profuniq = request.GET.get('profuniq','')
        f.write("profile get from " + str(profuniq))
        f.write("profile get from " + str(profuniq) + " ")
        if profuniq == "(null)" or profuniq == "": # Apparrently, the app ends up sending this when the app first starts, where it hasn't yet received a profuniq and the MyRooms screen is starting up. Ignore it.
            data['badges'] = dict()
            data['total_badge_count'] = 0
        else:
            up = profuniq_to_prof(profuniq)
            f.write("received up " + str(up) + "\n")
            all_p = Project.objects.filter(profile_id=up.id,public=True).order_by('-seconds')
            data['total_badge_count'] = compute_badge_count_for_profile(up.id)
            data['badges'] = dict()
            if len(all_p) > 0:
                for p in all_p:
                    data_item = dict()
                    data_item['badge_count'] = compute_badge_count_for_project(p.id)
                    #paid_ret, paid_datetime = profile_paid(up)
                    #if paid_ret == True:
                    if project_paid(p.id) == True:
                        data_item['paid'] = "yes"
                    else:
                        data_item['paid'] = "no"
                    data['badges'][p.projuniq] = data_item
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    else:
        return HttpResponse()

def choices_mostliked(projuniq,custom,like_hintuniq,dislike_hintuniq):
    choices = []
    # Must get the profile_id for this project
    p = Project.objects.filter(projuniq=projuniq).get()
    profile_id = p.profile_id

    if p.shown_choices <= 4:
        # Only show up to 6 choices (4 + 2 to come), so show choices only 3 times
    
        cursor = connection.cursor()
        # Find most liked hints and project
        # 1st version, ignore this
        # select distinct hintuniq,love_count,price,source,source_url,photo_mob, case when source_url != '' then 1  else 0 end as has_source_url from roomhints_hint where love_count is not null and lower(source) LIKE '%" + custom + "sofa%' order by love_count desc, has_source_url desc"


        # Find most liked hints that are sofas
        # select id as hint_id from roomhints_hint h where love_count is not null and lower(source) LIKE '%sofa%' order by love_count desc
        # Find most liked hints for projects looking for sofas: note p.custom (search term) over h.source (store name)
        # select h.id as hint_id, h.project_id, p.custom, h.love_count from roomhints_hint h, roomhints_project p where h.love_count is not null and lower(p.custom) LIKE '%%' and h.project_id = p.id order by h.love_count desc;


        # Find most liked hints which the user of this project has never liked before
        # select hint_id from (select id as hint_id from roomhints_hint h where love_count is not null and lower(source) LIKE '%sofa%' order by love_count desc) mliked WHERE hint_id NOT IN (SELECT l.hint_id from roomhints_like l where l.prof_id = %profile_id);
        # select hint_id from (select h.id as hint_id, h.project_id, p.custom, h.love_count from roomhints_hint h, roomhints_project p where h.love_count is not null and lower(p.custom) LIKE '%%' and h.project_id = p.id order by h.love_count desc) mliked WHERE hint_id NOT IN (SELECT l.hint_id from roomhints_like l where l.prof_id = %profile_id);


        # subselect the above
        # Project more stuff from these most liked hints
        # select h.hintuniq, h.love_count, h.price, h.source, h.source_url, h.photo_mob from
        # (select hint_id from (select h.id as hint_id, h.project_id, p.custom, h.love_count from roomhints_hint h, roomhints_project p where h.love_count is not null and lower(p.custom) LIKE '%%' and h.project_id = p.id order by h.love_count desc) mliked WHERE hint_id NOT IN (SELECT l.hint_id from roomhints_like l where l.prof_id = %profile_id)) as unseen, roomhints_hint h where h.id = unseen.hint_id;

        # Find if a user has seen this hint before
        #cursor.execute("select h.hintuniq, h.love_count, h.price, h.source, h.source_url, h.photo_mob from (select hint_id from (select id as hint_id from roomhints_hint h where love_count is not null and lower(source) LIKE '%" + custom + "%' order by love_count desc) mliked WHERE hint_id NOT IN (SELECT l.hint_id from roomhints_like l where l.prof_id = " + str(profile_id) + ")) as unseen, roomhints_hint h where h.id = unseen.hint_id limit 2")
        sql = "select h.hintuniq, h.love_count, h.price, h.source, h.source_url, h.photo_mob from (select hint_id from (select h.id as hint_id, h.project_id, p.custom, h.love_count from roomhints_hint h, roomhints_project p where h.love_count is not null and lower(p.custom) LIKE '%" + custom + "%' and h.project_id = p.id order by h.love_count desc) mliked WHERE hint_id NOT IN (SELECT l.hint_id from roomhints_like l where l.prof_id = " + str(profile_id) + ")) as unseen, roomhints_hint h where h.id = unseen.hint_id limit 2"
        cursor.execute(sql)
        for row in cursor.fetchall():
            data_item = dict()
            data_item['hintuniq'] = row[0]
            data_item['price'] = row[2]
            data_item['source'] = row[3]
            data_item['source_url'] = row[4]
            data_item['photo_url'] = settings.MEDIA_URL + row[5]
            choices.append(data_item)

        # if len(choices) > 0:
        #     cig = ChoiceImpressionGroup()
        #     cig.project = p
        #     cig.seconds = datetime.utcnow().replace(tzinfo=utc)
        #     cig.save()

        #     for c in choices:
        #         c = ChoiceImpression()
        #         dh = DefaultHint.objects.filter(hintuniq=c['hintuniq']).get()
        #         c.dhint = dh
        #         c.seconds = datetime.utcnow().replace(tzinfo=utc)
        #         c.impression_group = cig
        #         c.chosen = False

    # Finish
    if len(choices) == 2:
        p.shown_choices += len(choices)
        p.save()
    elif len(choices) == 0:
        # There are no more choices. Make the project public
        p.public = True
        p.save()

    return choices

def add_dhint_from_raw(price,source_url,name,imagepath):
    dh = DefaultHint()
    dh.name = name
    dh.category_id = 2
    dh.keywords = ""
    dh.price = price
    dh.source = ""
    dh.source_url = source_url
    photoname = 'pics/default_hints/' + make_unique(36) + ".jpg"
    shutil.copy(imagepath, settings.MEDIA_ROOT + photoname)
    dh.photo = photoname
    dh.save()
    return dh

def add_roomhint_from_hint(h,p,min_seconds,max_seconds=900):
    rh = RoomHint()
    rh.project = p
    rh.hint = h
    rh.profile_id = h.profile_id;
    # Postdate hints so the user thinks a human being is adding them
    post_seconds = random_seconds(min_seconds,max_seconds)
    t = datetime.utcnow().replace(tzinfo=utc) + timedelta(seconds=post_seconds)
    rh.seconds = t # calendar.timegm(t.timetuple())
    rh.love = False
    rh.love_count = 0
    rh.public = True
    rh.delete_seconds = None
    rh.received_seconds = None
    rh.save()
    return rh

def choices_profile(projuniq,custom,like_hintuniq,dislike_hintuniq):
    choices = []
    p = Project.objects.filter(projuniq=projuniq).get()
    profile_id = p.profile_id

    f = open('/tmp/f', 'ab+')
    f.write('choices_profile - 1\n')

    # Process feedback
    #try:
    f.write("processing feedback -----for " + str(like_hintuniq) + " for project_id " + str(p.id) + "\n")
    all_dh = DefaultHint.objects.filter(hintuniq=like_hintuniq)
    if len(all_dh) == 1:
        dh = all_dh[0]
        # First, find the last impression group for this project. We
        # don't want to update some other one accidentally
        cig_feedback = ChoiceImpressionGroup.objects.filter(project_id=p.id).order_by('-seconds')[:1][0]
        f.write("processing feedback -- 1 for " + str(cig_feedback.id) + "\n")
        f.write("processing feedback -- 2 for " + str(dh.id) + "\n")
        ci_feedback = ChoiceImpression.objects.filter(group_id=cig_feedback.id,dhint_id=dh.id).get()
        f.write("processing feedback -- 3 \n")
        ci_feedback.chosen = True
        ci_feedback.save()
        # Add this selection as a hint
        add_hint_from_dhint(ci_feedback.dhint,p)
    else:
        f.write("processing feedback -- DOES NOT EXIST \n")

    # except Exception, e:
    #     # Does not exist
    #     f.write("processing feedback -- DOES NOT EXIST \n")
    #     pass

    f.write('choices_profile - 2\n')

    def getchoice_first(order):
        #f.write("getchoice_first \n")
        sql = "select ci.id from roomhints_choiceimpression ci, roomhints_choiceimpressiongroup cig where ci.group_id = cig.id and cig.project_id = " + str(p.id) + " and ci.chosen=true order by seconds desc limit 1 offset " + str(order)
        #f.write('sql is ' + sql + "\n")
        cursor = connection.cursor()
        cursor.execute(sql)
        ci_id = None
        for row in cursor.fetchall():
             ci_id = row[0]
        cursor.close()
        if ci_id != None:
            ci = ChoiceImpression.objects.get(pk=ci_id)
            return ci
        return None

    def getchoice_hint(cig,category,keywords,notkeywords,notthis=None):
        f.write("getchoice_hint \n")

        sql_keywords = ""
        for k in keywords:
            f.write('getchoice_hint ---- will require like keyword ' + k + "\n")
            sql_keywords += " AND dh.keywords LIKE '%" + k + "%'"

        sql_not_keywords = ""
        for k in notkeywords:
            f.write('getchoice_hint ---- will exclude like keyword ' + k + "\n")
            sql_not_keywords += " AND dh.keywords NOT LIKE '%" + k + "%'"

        sql_notthis = ""
        if notthis:
            f.write("getchoice_hint ---- NOTTHIS is excepted\n")
            sql_notthis += " AND dh.hintuniq != '" + notthis + "'"
        # FIXME: SQL injection attack
        sql = "select dh.id, dh.category_id from roomhints_defaulthint dh, roomhints_category c where dh.public=true AND dh.category_id = c.id AND c.name = '" + category + "' " + sql_keywords + sql_not_keywords + sql_notthis + " ORDER BY RANDOM() LIMIT 1"
        f.write('getchoice_hint SQL: ' + sql + "\n")
        cursor = connection.cursor()
        cursor.execute(sql)
        dh_id = None
        for row in cursor.fetchall():
            dh_id = row[0]
        cursor.close()
        f.write("getchoice_hint found dh_id:" + str(dh_id) + "\n")

        if dh_id != None:
            ci = ChoiceImpression()
            d = DefaultHint.objects.get(pk=dh_id)
            ci.dhint = d
            ci.seconds = datetime.utcnow().replace(tzinfo=utc)
            ci.group = cig
            ci.chosen = False
            ci.save()
            ci_item = dict()
            ci_item['hintuniq'] = d.hintuniq
            ci_item['price'] = d.price
            ci_item['source'] = d.source
            ci_item['source_url'] = d.source_url
            ci_item['keywords'] = d.keywords
            ci_item['photo_url'] = settings.MEDIA_URL + d.photo.name
            f.write('getchoice_hint returning ' + str(ci_item) + "\n")
            return ci_item

        return None

    cig = ChoiceImpressionGroup()
    cig.project = p
    cig.seconds = datetime.utcnow().replace(tzinfo=utc)
    cig.save()

    if p.shown_choices == 0:
        # This is the first impression. Show one rustic and one modern
        f.write('this is the first impression\n')
        ci1 = getchoice_hint(cig,'Rustic',[custom],['color'])
        ci2 = getchoice_hint(cig,'Modern',[custom],['color'])
        if ci1 != None:
            choices.append(ci1)
        if ci2 != None:
            choices.append(ci2)
    elif p.shown_choices == 2:
        # This is the second impression. First find what was last chosen
        f = open('/tmp/f','ab+')
        f.write('this is the second impression - 0\n')
        ci_first = getchoice_first(0)
        f.write('this is the second impression - 1\n' + str(ci_first))
        # Now find what category it was in
        cat = Category.objects.get(pk=ci_first.dhint.category.id)
        f.write('it was in category ' + cat.name + '\n')
        if cat.name == 'Modern':
            # Show either Contemporary or Modern
            ci1 = getchoice_hint(cig,'Contemporary',[p.custom],['color'])
            ci2 = getchoice_hint(cig,'Modern',[p.custom],['color'])
            if ci1 != None:
                choices.append(ci1)
            if ci2 != None:
                choices.append(ci2)
        elif cat.name == 'Rustic':
            # Show either Contemporary or Rustic
            ci1 = getchoice_hint(cig,'Contemporary',[p.custom],['color'])
            ci2 = getchoice_hint(cig,'Rustic',[p.custom],['color'])
            if ci1 != None:
                choices.append(ci1)
            if ci2 != None:
                choices.append(ci2)
    elif p.shown_choices == 4:
        # Whatever it is they last chose, show two of those, one in
        # color
        f.write('this is the third impression, should show color\n')
        ci_second = getchoice_first(1)
        cat = Category.objects.get(pk=ci_second.dhint.category.id)
        f.write('it was in category ' + cat.name + '\n')
        ci1 = getchoice_hint(cig,cat.name,[p.custom, 'color'],[])
        ci2 = getchoice_hint(cig,cat.name,[p.custom, 'color'],[],ci1['hintuniq'])
        if ci1 != None:
            choices.append(ci1)
        if ci2 != None:
            choices.append(ci2)

    if len(choices) > 1:
        p.shown_choices += len(choices)
        p.save()

    # Make project public immediately
    p.public = True
    p.save()

    # Should suffle the array items
    random.shuffle(choices)
    f.write("choices are now: " + str(choices) + "\n")
    return choices

# Disconnect the recommendation engine without breaking anything
def choices_profile_v4(projuniq,custom,like_hintuniq,dislike_hintuniq):
    choices = []
    p = Project.objects.filter(projuniq=projuniq).get()
    profile_id = p.profile_id
    p.public = True
    return choices

def debug_choices(request):
    if request.method == 'GET':
        projuniq = request.GET.get('projuniq','')
        custom = request.GET.get('custom','')
        data = dict()
        data['projuniq'] = projuniq
        data['choices'] = choices_profile_v4(projuniq,custom,None,None)
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)

    return HttpResponse()
    
@csrf_exempt
def api_v3_project_choices(request):
    if request.method == 'POST' or request.method == 'GET':
        projuniq = request.GET.get('projuniq','')
        custom = request.GET.get('custom','')
        like_hintuniq = request.GET.get('like_hintuniq','')
        dislike_hintuniq = request.GET.get('dislike_hintuniq','')
        data = dict()
        data['projuniq'] = projuniq
        data['choices'] = choices_profile_v4(projuniq,custom,like_hintuniq,dislike_hintuniq)
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)

    return HttpResponse()

def project_recommend(p,custom):
    matches = []
    use_price = False
    output = ""
    max_hints = 6

    def searchimpression_price_stats(p,sig_last):
        avg_price = None
        max_price = None
        min_price = None
        cursor = connection.cursor()
        sql = "select avg(price),max(price),min(price) from (select h.id,h.price from roomhints_searchimpressiongroup sig, roomhints_searchimpression si, roomhints_hint h where sig.project_id = " + str(p.id)+ " and sig.custom = %s and si.hint_id = h.id and si.group_id = sig.id and si.chosen=true and sig.id = " + str(sig_last.id) + ") as s"
        cursor.execute(sql,[p.custom])
        for row in cursor.fetchall():
            avg_price = row[0]
            max_price = row[1]
            min_price = row[2]
        cursor.close()
        return avg_price,max_price,min_price

    def roomhint_price_stats(p,and_liked):
        # Don't consider hints that where disliked the last time
        avg_price = None
        max_price = None
        min_price = None
        sql = ""
        extra = ""
        if and_liked == True:
            extra = " and rh.love = true"
        # Look for roomhints that were saved by the user, not by a designer
        price_sql = "select h.id,h.price from roomhints_roomhint rh, roomhints_hint h, roomhints_project p where rh.hint_id = h.id and rh.project_id = " + str(p.id) + " and rh.profile_id = p.profile_id and rh.public=true" + extra
        sql = "select avg(price),max(price),min(price) from (" + price_sql + ") as s"
        cursor = connection.cursor()
        cursor.execute(sql)
        price = None
        for row in cursor.fetchall():
            avg_price = row[0]
            max_price = row[1]
            min_price = row[2]
        cursor.close()
        return avg_price, max_price, min_price

    def price_is_good(past_avg_price,this_price):
        add = True
        output = ""
        output += "Last price:     " + str(past_avg_price) + "\n"
        if past_avg_price != None:
            price_diff = math.fabs(this_price - past_avg_price)
            price_diff_percent = price_diff / past_avg_price * 100
            output += "Price diff:     " + str(price_diff) + "\n"
            output += "Price diff %:   " + str(price_diff_percent) + "\n"
            high = 1.0 * 100
            low = 1.0 * 100
            if this_price > past_avg_price and price_diff_percent > high:
                output += "REJECT: price higher than " + str(high) + "% of last search choices (diff is " + str(price_diff) + " - " + str("%.1f" % price_diff_percent) + "%)\n"
                add = False
            elif this_price < past_avg_price and price_diff_percent > low:
                output += "REJECT: price lower than " + str(low) + "% of last search choices (" + str(price_diff) + " - " + str("%.1f" % price_diff_percent) + "%)\n"
                add = False
        return add, output

    def hint_is_not_repeated(times,hint):
        add = True
        output = ""
        sig_len = len(sig_pastall)
        if sig_len > 0:
            if times > sig_len:
                sig_max = sig_len
            else:
                sig_max = times
            sig_search = sig_pastall[0:sig_max]
            times_counter = 0
            for sig_this in sig_search:
                times_counter += 1
                si_past_all = SearchImpression.objects.filter(group_id=sig_this.id,hint_id=hint.id)
                if len(si_past_all) > 0:
                    # This was shown recommended over the last "times" times.
                    # Do not recommend it again
                    output += "REJECT: displayed last " + str(times_counter) + " time\n"
                    add = False

        return add, output

    def candidate_add(h,match_plan):
        output = ""
        output += "Will ADD hint with id " + str(h.id) + "\n"
        
        # Automatically add this match as a searchimpression
        si = SearchImpression()
        si.hint = h
        si.seconds = datetime.utcnow().replace(tzinfo=utc)
        si.group = sig
        si.chosen = False
        si.color_score = match_plan['color_score']
        si.feature_score = match_plan['feature_score']
        si.total_score = match_plan['total_score']
        si.dominant_hex = match_plan['dominant_hex']
        si.save()
        # Do not save search results for them.
        # rh = add_roomhint_from_hint(h,p,1,1)

        si_item = dict()
        si_item['hintuniq'] = h.hintuniq
        si_item['price'] = hint_price(h)
        si_item['source'] = h.name # Show the name of the item, not the vendor
        si_item['source_url'] = h.affiliate_url # Always setup source urls through our affiliate redirector
        if si_item['source_url'] == None: # No affiliate entry
            si_item['source_url'] = h.source_url
            f = open('/tmp/affiliate_url','ab+')
            f.write("Hint " + str(h.hintuniq) + " had no affiliate_url; used: " + h.source_url + "\n")
            f.close()
        si_item['keywords'] = h.keywords
        # Send the mobile resolution photo to the app
        si_item['photo_url'] = settings.MEDIA_URL + h.photo_mob.name
        si_item['loves'] = h.love_count
        si_item['hint_love_count'] = h.love_count
        # Do not send scores
        #si_item['color_score'] = match_plan['color_score']
        #si_item['feature_score'] = match_plan['feature_score']
        #si_item['total_score'] = match_plan['total_score']
        #si_item['dominant_hex'] = match_plan['dominant_hex']
        return output, si_item

    def candidate_filter(sig_pastall,h,rh_pastall,sig_last,match_plan,past_avg_price,matches):
        add = True
        output = ""

        # Add this recommendation, if it hasn't been chosen before
        if len(sig_pastall) > 0: # There were previous recommendation groups
            for sig_this in sig_pastall:
                si_past_all = SearchImpression.objects.filter(group_id=sig_this.id,hint_id=h.id,chosen=False)
                if len(si_past_all) > 0:
                    # This hint was displayed but not chosen (touched) before.
                    # Do not recommend it again.
                    # si_path_this = si_past_all[0]
                    output += "REJECT: shown but not chosen before\n"
                    add = False

        if use_price == True and add == True:
            if len(rh_pastall) > 0: # There are previous roomhints the user saved
                for rh_other in rh_pastall:
                    if rh_other.hint_id == h.id:
                        output += "REJECT: already a roomhint\n"
                        add = False

            if sig_last != None:
                si_past_all = SearchImpression.objects.filter(group_id=sig_last.id,hint_id=h.id)
                # Consider adding this recommendation, if it is not more than 60% away
                # from the average price of all the items chosen in the last search
                price_add, price_output = price_is_good(past_avg_price,h.price)
                output += price_output
                if price_add == False:
                    add = False

        # # If something was recommended the last time, don't recommend it again
        # repeated_add, repeated_output = hint_is_not_repeated(1,h)
        # output += repeated_output
        # if repeated_add == False:
        #     add = False

        # If someone took a picture of a blank wall, don't add it.
        if int(float(match_plan['feature_score'])) == 0:
            output += "REJECT: no features (blank wall)\n"
            add = False

        # If we were planning to recommend this already, do not recommend it twice
        for m in matches:
            output += "comparing " + h.hintuniq + " with "+ m['hintuniq'] + "\n"
            if h.hintuniq == m['hintuniq']:
                output += "REJECT: Planned to recommend already\n"
                add = False

        return output, add

    def first_search(p,sig_pastall,rh_pastall,max_hints,past_avg_price):
        output = ""
        matches = []
        input_image = settings.MEDIA_ROOT + p.photo_web.name # web resolution for match
        search_images, output_image, output_image_score, scores = find_image_match(input_image, "defaulthints",p)
        output += "------> for " + p.projuniq + " " + str(custom_last(p.custom)) + "\n"
        output += "Total images:  " + str(search_images) + "\n"
        output += "InImage:       " + str(input_image) + "\n"

        output += str(scores) + "\n"
        score_keys_sorted = sorted(scores['by_score'],reverse=True)
        counter = 0
        for k in score_keys_sorted:
            for match_plan in scores['by_score'][k]:
                if counter < max_hints:
                    if k > 0:
                        add = True
                        match_image = str(match_plan['image'])
                        all_h = Hint.objects.filter(photo=match_image)
                        if len(all_h) > 0:
                            h = all_h[0]
                            output += "OutImage:       " + settings.MEDIA_ROOT + match_image + "\n"
                            output += "OutImage plain: " + match_image + "\n"
                            output += "OutScore:       " + str(match_plan['feature_score']) + ":" + str(match_plan['color_score']) + "=" + str(match_plan['total_score']) + " #" + str(match_plan['dominant_hex']) + "\n"
                            output += "Price:          " + str(math.ceil(h.price)) + "\n"

                            filter_output, filter_add = candidate_filter(sig_pastall,h,rh_pastall,sig_last,match_plan,past_avg_price,matches)
                            output += filter_output
                            if filter_add == False:
                                add = False

                            if add:
                                # Add this recommendation
                                candidate_output, candidate_item = candidate_add(h,match_plan)
                                output += candidate_output
                                matches = matches + [ candidate_item ]
                                counter += 1
                        else:
                            output += "Unable to find image " + match_image + "\n"
                    else:
                        # If something goes wrong, the score is 0.
                        output += "Matching is failing to run\n"

        return output, matches

    def past_first_search(p,sig_pastall,rh_pastall,max_hints,past_avg_price):
        output = ""
        matches = []
        output += "will search for sig " + str(sig_last.id) + "\n"
        #sic_past_all = SearchImpression.objects.filter(group_id=sig_last.id,chosen=True)

        cursor = connection.cursor()

        def prev_hints(only_chosen):
            sql_prev = "select prev.hint_id from ("
            sql_prev +="select distinct si.hint_id, si.group_id = " + str(sig_last.id) + " as thisfirst, si.group_id, sig.seconds from roomhints_searchimpression si, roomhints_searchimpressiongroup sig where si.group_id = sig.id and sig.project_id = " + str(p.id) + " and sig.custom = %s and si.group_id <= " + str(sig_last.id)
            if only_chosen == True:
                sql_prev += " and si.chosen=true"

            sql_prev += " order by si.group_id = " + str(sig_last.id) + " desc, si.group_id desc, sig.seconds"
            sql_prev += ") as prev"
            return sql_prev

        # Search only in previous searchimpressiongroups - not the new one we just made up!
        # First find hints that best match the last search, then all other hints
        sql_prev_chosen = prev_hints(True)
        output += "sic_past_all sql is: " + sql_prev_chosen + "\n"
        cursor.execute(sql_prev_chosen,[p.custom])
        sic_past_all = []
        for row in cursor.fetchall():
            sic_past_all.append(row[0])
        cursor.close()

        output += "last sic_past_all = " + str(len(sic_past_all)) + "\n"
        sql_hs = ""
        sql_hs_counter = 0
        if len(sic_past_all) > 0:
            for sic_past_hint_id in sic_past_all:
                if sql_hs_counter == 0:
                    sql_hs += "and "
                    if len(sic_past_all) > 1:
                        sql_hs += "("
                else:
                    sql_hs += " or "
                # sic_past.hint_id -> sic_past_hint_id
                sql_hs += "(hs.one_id = " + str(sic_past_hint_id) + " and hs.two_id != " + str(sic_past_hint_id) + ")"
                sql_hs_counter = sql_hs_counter + 1

            if len(sic_past_all) > 1:
                sql_hs += ")"

        if len(sic_past_all) == 0:
            # The user did not touch anything at all for this hinttype. That will lead to
            # us showing him the results that are the most similar with each
            # other among all hints, not hints of a specific category. Let's
            # not do that.
            output += "The user did not touch anything at all for this hinttype_id\n"
            return output, matches

        # Some items were chosen before. Show more like them, but do not show items already shown
        # Show items that are of the same category.
        # sql_same_cat = "select count(*) from (select hinttype_id from roomhints_hinttypelist where hint_id = 6061 intersect select hinttype_id from roomhints_hinttypelist where hint_id = 5074) as s;"
        # (select count(*) from (select hinttype_id from htl1 where hint_id = hone.id \
        # intersect select hinttype_id from roomhints_hinttypelist where hint_id = htwo.id) as sim) > 0

        sql_htl = ""
        def compute_sql_htl():
            sql_htl = ""
            sql_htl_counter = 0
            if len(sic_past_all) > 0:
                sql_htl = "(select distinct hinttype_id from roomhints_hinttypelist where hint_id in ("
                for sic_past_hint_id in sic_past_all:
                    if sql_htl_counter > 0:
                        sql_htl += ", "
                    sql_htl += str(sic_past_hint_id)
                    sql_htl_counter += 1
                sql_htl += "))"
            return sql_htl

        if len(sic_past_all) > 0:
            sql_htl = " htl1.hinttype_id in " + compute_sql_htl() + " and htl2.hinttype_id in " + compute_sql_htl() + " and "

        sql = "select distinct hs.two_id, hs.color_score, hs.feature_score, hs.total_score from roomhints_hintsimilarity hs, roomhints_hint hone, roomhints_hint htwo, roomhints_hinttypelist htl1, roomhints_hinttypelist htl2 where " + sql_htl + " htl1.hint_id = hone.id and htl2.hint_id = htwo.id and hone.id = hs.one_id and htwo.id = hs.two_id and hone.public = true and htwo.public = true " + sql_hs + " and hs.two_id not in (" + prev_hints(False) + ") order by total_score desc limit 1000"
        #sql = "select distinct hs.two_id, hs.color_score, hs.feature_score, hs.total_score from roomhints_hintsimilarity hs, roomhints_hint hone, roomhints_hint htwo, roomhints_hinttype ht where ht.id = hone.hinttype_id and ht.id = htwo.hinttype_id and hone.id = hs.one_id and htwo.id = hs.two_id " + sql_hs + " and hs.two_id not in (" + prev_hints(False) + ") order by total_score desc limit 1000"
        cursor = connection.cursor()
        cursor.execute(sql,[p.custom])
        output += "sql is: " + sql + "\n"
        counter = 0
        row_counter = 0
        for row in cursor.fetchall():
            hint_id = row[0]
            color_score = row[1]
            feature_score = row[2]
            total_score = row[3]
            output += str(row_counter) + " processing row for hint_id "+ str(hint_id) + "\n"
            if counter < max_hints:
                h_all = Hint.objects.filter(pk=hint_id)
                if len(h_all) > 0:
                    h = h_all[0]

                    match_plan = dict()
                    match_plan['color_score'] = color_score
                    match_plan['feature_score'] = feature_score
                    match_plan['total_score'] = total_score
                    match_plan['dominant_hex'] = h.dominant_hex

                    add = True
                    filter_output, filter_add = candidate_filter(sig_pastall,h,rh_pastall,sig_last,match_plan,past_avg_price,matches)
                    output += filter_output
                    if filter_add == False:
                        add = False

                    if add == True:
                        candidate_output, candidate_item = candidate_add(h,match_plan)
                        output += candidate_output
                        matches = matches + [ candidate_item ]
                        counter += 1
                    else:
                        output += "Will NOT add hint with id " + str(h.id) + "\n"
            row_counter += 1

        return output, matches


    sig_pastall = SearchImpressionGroup.objects.filter(project_id=p.id).order_by('-seconds')
    sig_last_id = None
    output += "len(sig_pastall) is " + str(len(sig_pastall)) + "\n"
    if len(sig_pastall) > 0:
        sig_last = sig_pastall[0]
        sig_last_id = sig_last.id
        output += "sig_last_id is " + str(sig_last_id) + "\n"

    sig_last = None
    past_avg_price = None
    past_min_price = None
    past_max_price = None
    si_avg_price = None
    si_max_price = None
    si_min_price = None
    rhl_avg_price = None
    rhl_max_price = None
    rhl_min_price = None
    rh_avg_price = None
    rh_max_price = None
    rh_min_price = None
    if len(sig_pastall) > 0: # There were previous recommendation groups
        sig_last = sig_pastall[0] # Look only at the last search
        si_avg_price, si_max_price, si_min_price = searchimpression_price_stats(p,sig_last)

    rh_pastall = RoomHint.objects.filter(project_id=p.id,public=True).order_by('-seconds')
    rhl_avg_price, rhl_max_price, rhl_min_price = roomhint_price_stats(p,True)
    rh_avg_price, rh_max_price, rh_min_price = roomhint_price_stats(p,False)

    # This is one way of doing the pricing
    if rhl_avg_price != None:
        # Something the user likes is a better indicator than something they don't like
        past_avg_price = rhl_avg_price
        output += "Going based on pricing of LIKED roomhints\n"
    else:
        # The user doesn't like anything yet
        if rh_avg_price != None:
            # The user saved some options
            past_avg_price = rh_avg_price
            output += "Going based on pricing of SAVED roomhints\n"
        else:
            past_avg_price = si_avg_price
            output += "Going based on pricing of SEARCH impressions\n"

    # and this is another
    if si_avg_price != None:
        past_avg_price = si_avg_price
        output += "Going based on pricing of SEARCH impressions\n"
    else:
        # The user did not pick anything last time
        if rhl_avg_price != None:
            # Something the user likes is a better indicator than something they don't like
            past_avg_price = rhl_avg_price
            output += "Going based on pricing of LIKED roomhints\n"
        else:
            # The user doesn't like anything yet
            if rh_avg_price != None:
                # The user saved some options
                past_avg_price = rh_avg_price
                output += "Going based on pricing of SAVED roomhints\n"

    
    # Find the number of previous searches in this room for this item
    thisp_sigcount = project_searches(p,custom)
    # Find the number of previous touched items for this room
    thisp_sicount = project_chosens(p,custom)

    sig = SearchImpressionGroup()
    sig.project = p
    sig.seconds = datetime.utcnow().replace(tzinfo=utc)
    sig.custom = custom
    sig.save()

    if thisp_sigcount == 0:
        # Do an image match between the room photo and the hints
        first_output, first_matches = first_search(p,sig_pastall,rh_pastall,max_hints,past_avg_price)
        output += first_output
        matches = first_matches
    else:
        # Choose the next hints to show based on the last chosen (touched) hints
        past_output, past_matches = past_first_search(p,sig_pastall,rh_pastall,max_hints,past_avg_price)
        output += past_output
        matches = past_matches
        output += "precomputing had " + str(len(matches)) + " matches\n"
        # If the user has not touched anything at all so far, keep showing them
        # hints based on the room photo.
        output += "thisp_sicount is " + str(thisp_sicount) + "\n"
        if thisp_sigcount <= 2 and len(matches) < max_hints:
            # This was the first or second search attempt by the user and they still
            # haven't touched anything. Be forgiving and find more items
            first_output, first_matches = first_search(p,sig_pastall,rh_pastall,max_hints-len(matches),past_avg_price)
            output += first_output
            matches = past_matches + first_matches

    f = open('/tmp/search_recommend', 'ab+')
    f.write(output)
    f.close()
    return matches, sig_last_id

def project_chosens(p,custom=None):
    # Find number of searchimpressions that were touched for this project
    thisp_sicount = 0
    cursor = connection.cursor()
    if custom == None:
        custom = custom_last(p.custom)
    cursor.execute("select count(*) from roomhints_project p, roomhints_searchimpressiongroup sig, roomhints_searchimpression si where p.id = sig.project_id and sig.id = si.group_id and p.id=" + str(p.id) + " and sig.custom=%s",[custom])
    for row in cursor.fetchall():
        thisp_sicount = row[0]
    cursor.close()
    return thisp_sicount

def total_searches(profile_id):
    cursor = connection.cursor()
    # Find total number of searches
    ret = 0
    cursor.execute("select count(*) from roomhints_project p, roomhints_searchimpressiongroup sig where p.id = sig.project_id and p.profile_id=" + str(profile_id))
    for row in cursor.fetchall():
        ret = row[0]
    cursor.close()
    return ret
    
def project_searches(p,custom=None):
    # Find number of searches for this project
    thisp_sigcount = 0
    cursor = connection.cursor()
    if custom == None:
        custom = custom_last(p.custom)
    cursor.execute("select count(*) from roomhints_project p, roomhints_searchimpressiongroup sig where p.id = sig.project_id and p.profile_id=" + str(p.profile_id) + " and p.id=" + str(p.id) + " and sig.custom=%s",[custom])
    for row in cursor.fetchall():
        thisp_sigcount = row[0]
    cursor.close()
    return thisp_sigcount

def instructions(matches,p,sig_last_id):
    data = dict()
    data['search_header'] = 1
    data['search_footer'] = 1
    data['search_button'] = 1
    data['chat_button'] = 1
    data['purchase_button'] = 0
    data['purchase_y'] = 0
    data['search_touchinstructions'] = 1
    data['search_touchinstructions_text'] = "TOUCH the photos you like, to get better results."
    data['search_touchinstructions_viewheight'] = 65;
    data['search_touchinstructions_labelheight'] = 50;
    data['search_touchinstructions_y'] = 240 - data['search_touchinstructions_viewheight'];
    data['touch_action'] = "openhint" # other option is "search"

    data['search_showprice'] = 1 # hintall_showprice for search results
    data['hint_showprice'] = "yes"
    data['hint_showname'] = "no"

    # Find total number of searches
    sigcount = total_searches(p.profile_id)

    # Find number of searches for this project
    thisp_sigcount = project_searches(p)

    last_sicount = 0
    sql = ""
    if sig_last_id == None:
        # This is the first project submission, ignore the last_sicount
        pass 
    else:
        # A sig_id was just created, must use the one before it: sig_last_id
        sql = "select count(*) from roomhints_searchimpression si where si.group_id = " + str(sig_last_id) + " and si.chosen=true"
        cursor = connection.cursor()
        cursor.execute(sql)
        for row in cursor.fetchall():
            last_sicount = row[0]
        cursor.close()

    f = open('/tmp/instructions','ab+')
    f.write("sql is " + str(sql) + "\n")
    f.write("last_sicount is " + str(last_sicount) + "\n")
    #f.close()

    if sigcount <= 2 and thisp_sigcount == 1:
        #data['header_instructions'] = "You are looking at product hints that best match your room. They are only shown once.\n\nTouch products to buy."
        data['header_instructions'] = "\nYou were looking at product hints that best match your room. They are shown only once."
        data['header_y'] = 150;
        data['footer_instructions'] = "Touch the products you like best and search again to get better results."
        data['footer_y'] = 75;
        data['chat_button'] = 0
    else:
        #data['header_instructions'] = "Great, thanks! Now that we better understand your style, here are more product hints that match your room.\n\nTouch products to buy."
        data['header_instructions'] = "\n\nGreat, thanks! Now that we better understand your style, we are finding better product hints that match your room."
        data['header_y'] = 150;

        data['footer_instructions'] = ""
        data['footer_y'] = 50;
        data['chat_button'] = 0

        f.write("sigcount is " + str(sigcount) + "\n")

        if sigcount >= 3:
            # They know they must touch now
            # Explain them again they must save things they like
            data['search_touchinstructions_text'] = "         ==-SAVE-==      what you like,\n               it's only shown once."
            if sigcount >= 5:
                data['search_touchinstructions'] = 0

        if sigcount >= 6:
            # They used the application a lot. Say less.
            data['header_instructions'] = "Touch products you'd like to buy!"
            data['header_y'] = 75
            data['footer_instructions'] = "Didn't like these " + str(len(matches))+ "? Search Again."
            data['footer_y'] = 75
            data['chat_button'] = 1

        if last_sicount == 0 and sigcount < 6:
            data['header_instructions'] = "\n\n         Do you like what you see?\n\n\nRemember to touch the products you like to get more accurate results."
            data['header_y'] = 175;

        if last_sicount == 0 and sigcount >= 6:
            data['header_instructions'] = "\n         Do you like what you see?\n\n"
            data['header_y'] = 100;

    if len(matches) == 0:
        name = custom_last(str(p.custom))
        search_matches = search(name)
        f.write("there are " + str(len(search_matches['search'])) + " search_matches: " + str(search_matches['search']) + "\n")
        if len(search_matches['search']) == 0:
            # We didn't have any of those items to show
            data['header_instructions'] = "Unfortunately, we don't have any of those yet. Please try searching for something else.\n"
            data['header_y'] = 125
        elif thisp_sigcount == 1: # Detect a blank wall
            data['header_instructions'] = "Please take a photo of the area where the " + name + " will go. A photo of a blank wall isn't very helpful."
            data['header_y'] = 125
            #data['footer_instructions'] = "Recommendations get better when you touch photos and indicate the ones you like best.\n"        
            #data['footer_y'] = 100;
        else:
            data['header_instructions'] = "We don't have another " + name + " that matches your colors and style.\n\nOur designers can hand-select hints for your room.\n\nIf you want to search again for another " + name + ", take a new photo and TOUCH the items you like."
            data['header_instructions'] = "We don't have another " + name + " that matches your colors and style.\n\nIf you want to search again for another " + name + ", take a new photo and TOUCH the items you like."
            data['header_y'] = 200
            data['footer_instructions'] = ""
            data['footer_y'] = 0;
        data['search_footer'] = 0
        data['chat_button'] = 1

    return data

def instructions_surprise(up):
    data = dict()
    if up.charge_plan == None or up.charge_plan == "":
        # They do not have a monthly subscription
        data['header_instructions'] = "\n\nOur interior designers can surprise you with creative ideas for your room for $" + str(stripe_price) + " per month.\n\nAnyone can afford to invest so little in what can improve their living space so much.\n\n"
    else:
        # They do have a monthly subscription
        data['header_instructions'] = "\n\nOur interior designers will surprise you with creative ideas for your room soon.\n\n"
    q = random_home_quote()
    data['header_instructions'] += q[1]
    #data['header_instructions'] += "\n\n\n\n\n\n\n\n\n"
    data['header_instructions'] += "\n\n\n\n\n\n\n"
    data['purchase_button'] = 1
    data['purchase_y'] = 290
    data['header_y'] = 420
    data['footer_instructions'] = ""
    data['footer_y'] = 0
    data['search_header'] = 1
    data['search_footer'] = 0
    data['search_button'] = 0
    data['chat_button'] = 0
    data['touch_action'] = "openhint"
    return data

@csrf_exempt
def api_v4_project_recommend(request):
    if request.method == 'GET':
        matches = []
        data = dict()
        projuniq = request.GET.get('projuniq','')
        custom = request.GET.get('custom','')
        if custom == "a surprise":
            # They want to be surprised, not to search
            custom = "Surprise me!"
            data['search_results'] = []
            data['loves'] = []
            all = Project.objects.filter(projuniq=projuniq,public=True)
            sig_last_id = None
            p = None
            if len(all) == 1:
                p = all[0]
                old_custom = p.custom
                p.custom = custom
                p.custom = old_custom + ", " + custom
                p.hide = False
                p.save()
            data['instructions'] = instructions_surprise(p.profile)
        else:
            # They want to search
            all = Project.objects.filter(projuniq=projuniq,public=True)
            sig_last_id = None
            p = None
            if len(all) == 1:
                p = all[0]
                old_custom = p.custom
                p.custom = custom
                matches, sig_last_id = project_recommend(p,custom)
                p.custom = old_custom + ", " + custom
                p.hide = False
                p.save()
            data['search_results'] = matches
            data['instructions'] = instructions(matches,p,sig_last_id)
            loves = []
            for m in matches:
                loves.append(m)
            data['loves'] = loves
        ret = json.dumps(data, sort_keys=True, indent=4)
        f = open('/tmp/search_results','ab+')
        f.write(ret)
        f.close()
        return HttpResponse(ret)

    return HttpResponse()

@csrf_exempt
def api_v3_project_delete(request):
    if request.method == 'POST':
        projuniq = request.GET.get('projuniq','')
        profuniq = request.GET.get('profuniq','')
        all_p = Project.objects.filter(projuniq=projuniq)
        data = dict()
        if len(all_p) > 0:
            # There is a project to delete
            p = all_p[0]
            up = profuniq_to_prof(profuniq)
            data['deleted'] = "no"
            if p.profile_id == up.id:
                # "delete" it
                p.public = False
                p.delete_seconds = datetime.utcnow().replace(tzinfo=utc)
                p.save()
                data['deleted'] = "yes"
        else:
            # There is no project to delete. Pretend it was deleted,
            # so we let clients clear out rooms from the phone
            data['deleted'] = "yes"

        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    return HttpResponse()

def profuniq_to_prof(profuniq):
    all_u = User.objects.filter(username=profuniq)
    up = None
    if len(all_u) > 0:
        u = all_u[0]
        up = Profile.objects.filter(user_id=u.id)
        if len(up) > 0:
            up = up[0]
    return up

def project_view_add(pr,p,meta,request):
    pi = ProjectImpression()
    pi.prof = pr
    pi.project = p
    pi.seconds = datetime.utcnow().replace(tzinfo=utc)
    pi.meta = meta
    pi.ip = get_ip(request)
    pi.save()

@csrf_exempt
def api_v4_project_view(request):
    if request.method == 'POST':
        profuniq = request.GET.get('profuniq','')
        projuniq = request.GET.get('projuniq','')
        meta = request.GET.get('meta','')
        pr = profuniq_to_prof(profuniq)
        p = Project.objects.filter(projuniq=projuniq).get()
        project_view_add(pr,p,meta,request)
        return HttpResponse()

    return HttpResponse()

def project_add(request,profile_id):
    f = open('/tmp/out','ab+')
    f.write("submitted: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    p = Project()
    p.budget = -1 # not supplied
    for key in request.GET:
        value = request.GET[key]
        if key == 'project':
            p.name = value
        elif key == 'custom':
            p.custom = value
            if p.custom == "a surprise":
                p.custom = "Surprise me!"
        elif key == 'budget':
            if value != '':
                p.budget = int(value)
    p.profile_id = profile_id
    p.photo = 'pics/projects/' + make_unique(36) + ".jpg"
    p.photo_web = 'pics/projects/' + make_unique(36) + ".jpg"
    p.photo_mob = 'pics/projects/' + make_unique(36) + ".jpg"
    p.photo_square = 'pics/projects/' + make_unique(36) + ".jpg"
    p.seconds = datetime.utcnow().replace(tzinfo=utc)
    f.write("saved params: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    if 'name' in request.FILES.keys():
        handle_uploaded_file(request.FILES['name'],settings.MEDIA_ROOT + p.photo.name)
    elif 'uploaded_file' in request.FILES.keys():
        handle_uploaded_file(request.FILES['uploaded_file'],settings.MEDIA_ROOT + p.photo.name)
    f.write("saved photo: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    photo_convert(settings.MEDIA_ROOT + p.photo.name,
                  settings.MEDIA_ROOT + p.photo_web.name, "480000")
    f.write("converted web photo: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    photo_convert(settings.MEDIA_ROOT + p.photo.name,
                  settings.MEDIA_ROOT + p.photo_mob.name, "147200")
    f.write("converted mob photo: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    photo_square(settings.MEDIA_ROOT + p.photo.name,
                 settings.MEDIA_ROOT + p.photo_square.name, "480")
    f.write("converted square photo: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    temp_pic_color = '/tmp/' + make_unique(36) + ".jpg"
    photo_square(settings.MEDIA_ROOT + p.photo.name, temp_pic_color, "125")
    #color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + p.photo_mob.name)
    color_hex, color_rgb = get_color_stats(temp_pic_color)
    os.remove(temp_pic_color)
    p.dominant_hex = color_hex
    projuniq = make_unique(36)
    p.projuniq = projuniq
    p.public = True
    rt = RoomType.objects.filter(name="decorate").get()
    p.roomtype = rt
    rs = RoomSetting.objects.filter(name="unclassified").get()
    p.roomsetting = rs
    try:
        p.ip = request.META['HTTP_X_REAL_IP']
    except Exception, e:
        p.ip = request.META['REMOTE_ADDR']
    p.save()
    f.write("populated with hints: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
    return p

def clarifications(first):
    data = dict()
    if first == True:
        data['footer_message'] = 'Your room photo has been sent to the community of designers.\n\nIn less than 1 minute, you will receive product hints that match the colors and style of your room.'
        data['footer_y'] = 150
        data['footer_message'] = 'In less than 1 minute, you will receive product hints that match the colors and style of your room.'
        data['footer_y'] = 75
    else:
        data['footer_message'] = 'RoomHints instantly finds you furniture up to 45% off!'
        data['footer_message'] = 'RoomHints instantly finds the perfect selection for your room.'
        data['footer_y'] = 55
    return data

@csrf_exempt
def api_v3_project_add_pre(request):
    f = open('/tmp/addpre','ab+')
    data = dict()
    profuniq = request.GET['profuniq']
    up = profuniq_to_prof(profuniq)
    custom = request.GET['custom']
    if 'projuniq' in request.GET.keys():
        # This is a second attempt to search
        projuniq = request.GET['projuniq']
        data['clarifications'] = clarifications(False)
    else:
        # This is a first attempt to search
        data['clarifications'] = clarifications(True)

    ret = json.dumps(data, sort_keys=True, indent=4)
    f.write("will return " + str(ret) + "\n")
    return HttpResponse(ret)

def pitch():
    data = dict()
    q = random_home_quote()
    data['footer_y'] = q[0]
    data['footer_message'] = q[1]
    return data

@csrf_exempt
def api_v3_project_pay_pre(request):
    f = open('/tmp/paypre','ab+')
    data = dict()
    profuniq = request.GET['profuniq']
    up = profuniq_to_prof(profuniq)
    custom = request.GET['custom']
    data['pitch'] = pitch()

    ret = json.dumps(data, sort_keys=True, indent=4)
    f.write("will return " + str(ret) + "\n")
    return HttpResponse(ret)

@csrf_exempt
def api_v3_project_add(request):
    if request.method == 'POST':
        profuniq = request.GET['profuniq']
        up = profuniq_to_prof(profuniq)
        p = project_add(request,up.id)
        #add_hints_automatically(p)

        data = dict()
        data['projuniq'] = p.projuniq
        data['photo_url'] = settings.MEDIA_URL + p.photo_square.name # resolution on mobile
        data['custom'] = p.custom
        data['choices'] = choices_profile_v4(p.projuniq,p.custom,None,None)
        seconds = random_seconds(60 * 4, 60 * 14)
        #seconds = random_seconds(60 * 1, 60 * 3)
        minutes = int(seconds/60)
        duration = ""
        if minutes > 60 * 24:
            duration = str(minutes/(60*24)) + " days."
        elif minutes > 60 and minutes < 60 * 24:
            duration = str(minutes/60) + " hours."
        elif minutes < 60:
            duration = str(minutes) + " minutes."
        data['minutes'] = "Our designers received your request and will pick items for your room over the next: " + duration
        f = open('/tmp/out','ab+')
        f.write("begun searching: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
        if p.custom == "Surprise me!":
            # They want to be surprised, not to search
            data['search_results'] = []
            data['instructions'] = instructions_surprise(p.profile)
            data['loves'] = []
        else:
            matches, sig_last_id = project_recommend(p,p.custom)
            data['search_results'] = matches
            data['instructions'] = instructions(matches,p,None)
            loves = []
            for m in matches:
                loves.append(m)
            data['loves'] = loves
        ret = json.dumps(data, sort_keys=True, indent=4)
        f.write("responded: " + str(datetime.utcnow().replace(tzinfo=utc)) + "\n")
        f.close()
        return HttpResponse(ret)

    return HttpResponse()

def hint_price(h):
    price = math.ceil(h.price)
    # Rugs and runners could have a variable price due to their size. So set their price to 0.
    htl = hinttypelist_get(h.id)
    for htl_item in htl:
        if htl_item == 10 or htl_item == 11:
            # If it's a rug or a runner, do not show prices because they vary by item size
            price = ""
    return price

def hintout(h, p, rh):
    data_item = dict()
    data_item['hintuniq'] = h.hintuniq
    data_item['projuniq'] = p.projuniq
    data_item['photo_url'] = settings.MEDIA_URL + h.photo_mob.name
    data_item['price'] = hint_price(h)
    data_item['source'] = h.name # Show the name of the item, not the vendor
    data_item['source_url'] = affiliate_find(h)
    data_item['love'] = h.love # We leave this for backward compatibility as of 2012-07-20
    data_item['love_count'] = h.love_count # We leave this for backward compatibility as of 2012-07-20
    data_item['roomhint_love'] = rh.love
    data_item['roomhint_love_count'] = rh.love_count
    data_item['hint_love'] = h.love
    data_item['hint_love_count'] = h.love_count
    if rh.love_count == 1:
        data_item['love_count_text'] = str(rh.love_count) + " like"
    elif rh.love_count > 1:
        data_item['love_count_text'] = str(rh.love_count) + " likes"
    else:
        data_item['love_count_text'] = ""
        t = rh.seconds
        # If you use mktime rather than calendar.timegm you
        # will be off by four hours and communicate your
        # frustrations to your cofounder.
        data_item['seconds'] = calendar.timegm(t.timetuple())
    if rh.profile.designer:
        data_item['sent_by_designer'] = True
    else:
        data_item['sent_by_designer'] = False
    return data_item

def liked_hints(p):
    liked_hints = []
    all_liked_hints = RoomHint.objects.filter(project_id=p.id,public=True).order_by('seconds')
    for rh in all_liked_hints:
        # FIXME: One query per hint?
        h = Hint.objects.filter(pk=rh.hint_id).get()
        data_item_loved = hintout(h, p, rh)
        liked_hints.append(data_item_loved)
    return liked_hints

@csrf_exempt
def api_v4_hint(request):
    if request.method == 'GET':
        data = dict()
        data['hints'] = []
        data['loves'] = []

        projuniq = request.GET.get('projuniq','')
        p = Project.objects.filter(projuniq=projuniq).order_by('seconds').get()
        if p:
            # There was a match
            profuniq = request.GET.get('profuniq','')
            up = profuniq_to_prof(profuniq)
            pi = ProjectImpression()
            pi.prof = up
            pi.project = p
            pi.seconds = datetime.utcnow().replace(tzinfo=utc)
            pi.meta = "view"
            pi.ip = get_ip(request)
            pi.save()

            seconds = request.GET.get('seconds','')
            if seconds == '':
                seconds = 0
            else:
                seconds = int(seconds)
            seconds_todatetime = datetime.fromtimestamp(seconds+1) # FIXME? .replace(tzinfo=utc)
            seconds_now = datetime.utcnow().replace(tzinfo=utc)
            all_latest_hints = RoomHint.objects.filter(project_id=p.id,seconds__gt=seconds_todatetime,seconds__lt=seconds_now,public=True).order_by('seconds')
            for rh in all_latest_hints:
                # FIXME: One query per hint?
                h = Hint.objects.filter(pk=rh.hint_id).get()
                rh.received_seconds = seconds_now
                rh.save()
                data_item = hintout(h, p, rh)
                data['hints'].append(data_item)

            # Show liked hints
            lovekind = request.GET.get('lovekind','')
            data['loves'] = liked_hints(p)

            # Prepare coordinates for how the hints will be viewed on
            # the phone. Set them as a square
            x = 0
            y = 0
            y_count = 1;
            for data_item in data['hints']:
                data_item['x'] = x
                data_item['y'] = y
                data_item['width'] = 160
                x = x + 160
                if x >= 320:
                    x = 0
                data_item['height'] = 160
                y_count += 1
                # Prepare next y
                if y_count > 2:
                    y = y + 160
                    y_count = 1

            data['hints_display'] = dict()
            data['hints_display']['height'] = y + 160 # Leave room for last item
            data['badge_count'] = compute_badge_count_for_project(p.id)
            data['badge_count_comments'] = compute_badge_count_for_comments(p.id)
            data['hint_instructions'] = dict()
            paid_ret, paid_datetime = project_paid(p.id)
            if paid_ret == True:
                data['hint_instructions']['paid'] = "yes"
            else:
                data['hint_instructions']['paid'] = "no"
            all_hints = RoomHint.objects.filter(project_id=p.id,public=True)
            hints_from_designer = False
            hints_from_user = False
            for rh in all_hints:
                if rh.profile.designer:
                    hints_from_designer = True
                else:
                    hints_from_user = True
            if len(all_hints) == 0:
                data['hint_instructions']['header_instructions'] = "Check back shortly for product hints from designers."
                data['hint_instructions']['header_y'] = 10 + 50
                data['hint_instructions']['header_instructions'] = ""
                data['hint_instructions']['header_y'] = 10 + 0
                data['hint_instructions']['checkback'] = 1
            else:
                if hints_from_designer == True and hints_from_user == False:
                    data['hint_instructions']['header_instructions'] = "The following products were hand-selected specifically for your room by designers."
                    data['hint_instructions']['header_y'] = 40 + 50
                    data['hint_instructions']['checkback'] = 1
                elif hints_from_designer == False and hints_from_user == True:
                    data['hint_instructions']['header_instructions'] = "You saved the following products.\n\nCheck back shortly for product hints from designers."
                    data['hint_instructions']['header_y'] = 75 + 50
                    data['hint_instructions']['header_instructions'] = "You saved the following products."
                    data['hint_instructions']['header_y'] = 75 + 0
                    data['hint_instructions']['checkback'] = 1
                else:
                    data['hint_instructions']['header_instructions'] = "Good job developing your style!\n\nDesigners are always a moment away to hand-select more hints specifically for your room."
                    data['hint_instructions']['header_y'] = 100 + 50
                    data['hint_instructions']['checkback'] = 1
            data['hint_instructions']['hintall_showprice'] = 1
            data['hint_instructions']['hint_showprice'] = "yes"
            data['hint_instructions']['hint_showname'] = "no"
            data['hint_instructions']['show_search'] = "yes"
            ret = json.dumps(data, sort_keys=True, indent=4)
            return HttpResponse(ret)
        return HttpResponse()
    return HttpResponse()

def hint_view_add(request,profuniq,hintuniq,meta):
    projuniq = request.GET.get('projuniq','')
    pr = profuniq_to_prof(profuniq)
    h = Hint.objects.filter(hintuniq=hintuniq).get()
    p = Project.objects.filter(projuniq=projuniq).get()
    rhall = RoomHint.objects.filter(project_id=p.id,hint_id=h.id,public=True)
    if len(rhall) > 0:
        # The hint exists as a roomhint
        rh = rhall[0]
        rhi = RoomHintImpression()
        rhi.prof = pr
        rhi.roomhint = rh
        rhi.seconds = datetime.utcnow().replace(tzinfo=utc)
        rhi.meta = meta
        rhi.ip = get_ip(request)
        rhi.save()
    else:
        # The hint was displayed as a result of search, and was not a roomhint; just a hint
        sig = SearchImpressionGroup.objects.filter(project_id=p.id).order_by('-seconds')[:1][0]
        si_all = SearchImpression.objects.filter(hint=h.id,group_id=sig.id).order_by('-id')
        # It's possible that due to an bug in displaying search results a
        # hint is shown more than once
        si = si_all[0] # Always pick the last one
        # For forward compatibility: versions above 1.12.1 use v4/api/searchimpression/view to
        # set the chosen flag
        ignore_search = request.GET.get('ignore_search','')
        if ignore_search != "yes":
            si.chosen = True
            si.save()

@csrf_exempt
def api_v4_hint_view(request):
    if request.method == 'POST':
        meta = request.GET.get('meta','')
        profuniq, u, up = make_profuniq(request,'web')
        hintuniq = request.GET.get('hintuniq','')
        hint_view_add(request,profuniq,hintuniq,meta)
        return HttpResponse()

@csrf_exempt
def api_v4_searchimpression_view(request):
    if request.method == 'POST':
        profuniq, u, up = make_profuniq(request,'web')
        hintuniq = request.GET.get('hintuniq','')
        projuniq = request.GET.get('projuniq','')
        chosen = request.GET.get('chosen','')
        pr = profuniq_to_prof(profuniq)
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        p = Project.objects.filter(projuniq=projuniq).get()
        sig = SearchImpressionGroup.objects.filter(project_id=p.id).order_by('-seconds')[:1][0]
        si_all = SearchImpression.objects.filter(hint=h.id,group_id=sig.id).order_by('-id')
        # It's possible that due to a bug in displaying search results a
        # hint is shown more than once
        si = si_all[0] # Always pick the last one
        if chosen == "yes":
            si.chosen = True
        else:
            si.chosen = False
        si.save()

        # Find the breakdown of the style of items the user chose
        name = custom_last(p.custom)
        #sig_this = SearchImpressionGroup.objects.filter(project_id=p.id,custom=name).order_by('-seconds')
        sql = "select count(*), hs.name from roomhints_searchimpressiongroup sig, roomhints_searchimpression si, roomhints_hintstylelist hsl, roomhints_hintstyle hs where si.group_id = sig.id and sig.project_id = " + str(p.id)+ " and sig.custom = %s and si.chosen = true and si.hint_id = hsl.hint_id and hs.id = hsl.hintstyle_id group by hs.name order by 1 desc;"
        cursor = connection.cursor()
        cursor.execute(sql,[name])
        styles = []
        total = 0
        for row in cursor.fetchall():
            count = row[0]
            style = row[1]
            styles.append( [count, style] )
            total += count

        data = dict()
        data['style'] = "Eclectic reinterpreted"
        data['duration'] = 4
        if len(styles) == 0:
            data['style'] = ""
            data['duration'] = 0
        elif len(styles) == 1:
            data['style'] = styles[0][1]
        else:
            counter = 0
            data['style'] = ""
            while counter < 3 and counter < len(styles): # Don't show too much
                perc = styles[counter][0]*100/total
                perc_str = "%.0f" % perc
                if counter > 0:
                    data['style'] += " "
                data['style'] += str(perc_str) + "% " + styles[counter][1]
                counter += 1

        # It's not working that well. Disable it
        #data['style'] = ""
        #data['duration'] = 0

        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    return HttpResponse()

def make_profuniq(request,origin):
    u = None
    up = None
    profuniq = None
    # Need to figure out if a new profile should be generated
    if request.user.is_authenticated():
        # This user is already logged in, they must have a username
        u = request.user
        profuniq = u.username
        #profuniq = request.session['profuniq']
        up = profuniq_to_prof(profuniq)
    elif request.session.get('profuniq', None) == None:
        # This is a new browser session that doesn't have a profile yet
        # Generate a new profile
        u, up = profile_add(request,origin)
        request.session['profuniq'] = u.username
        profuniq = u.username
    else:
        # This is an older session that isn't authenticated
        u = request.user
        profuniq = request.session['profuniq']
        up = profuniq_to_prof(profuniq)
    return profuniq, u, up
    
def profile_hint_add(request,projuniq,source,source_url,price,hintuniq,origin):
    logger.debug("hint_add - 1\n")
    f = open('/tmp/hint', 'ab+')
    f.write("hint_add - 1" + "\n")
    all = Project.objects.filter(projuniq=projuniq)
    f.write("hint_add - 2 " + projuniq + "\n")
    profuniq = request.GET.get('profuniq','')
    u = None
    up = None
    #f.write('hint_add - session.get(profuniq blank) is ' + str(request.session.get('profuniq', '')) + " and .get(profuniq None) is " + str(request.session.get('profuniq',None)) + "\n")
    if profuniq == '':
        profuniq, u, up = make_profuniq(request,origin)

    # Use an existing profile
    #f.write("hint_add - profuniq is " + str(profuniq) + "\n")
    u = User.objects.filter(username=profuniq).get()
    up = Profile.objects.filter(user_id=u.id).get()
    f.write("hint_add - 2.5 " + str(u) + " " + str(up) + " " + str(len(all)) + "\n")
    if len(all) == 1:
        # There was a match
        p = all[0]
        f.write("hint_add - 3" + "\n")
        if price == '':
            price = 0
        should_crawl = True
        h = None
        if hintuniq != None and hintuniq != "":
            h = Hint.objects.filter(hintuniq=hintuniq).get()
            f.write("hint_add - 3.1 hint exists: '" + h.source_url + "' vs '" + source_url + "'\n")
            if h.source_url == source_url:
                # The user did not browse away from the source_url in the mobile browser. We don't need to crawl the web.
                should_crawl = False
                f.write("hint_add - 3.2 should not crawl\n")

        if should_crawl:
            h = Hint()
            h.profile_id = up.id
            h.price = price
            h.source = source
            h.source_url = source_url
            crawl_price = None
            crawl_name = None
            crawl_source = None
            crawl_photo_url = None
            crawl_photo = None
            f.write('hint_add - 3.5 origin is ' + origin + "\n")
            if origin == "mobile" and source_url != "":
                # This is a submission from Save It from mobile from the
                # browser. Crawl the url and extract data out of it.
                crawl_price, crawl_name, crawl_source, crawl_photo_url, crawl_photo, crawl_all_imgs = crawl_hint(source_url)
                #f.write("hint_add - 3.7 - crawl_price is " + str(crawl_price) + " for item called " + str(crawl_name) + " and crawl_source is " +  str(crawl_source) + " and crawl_photo_url is " + str(crawl_photo_url) + " and crawl_photo is " + str(crawl_photo) + "\n")
                f.write("hint_add - 4 - price is " + str(h.price) + "\n")
                h.hintuniq = make_unique(36)
                h.seconds = datetime.utcnow().replace(tzinfo=utc)
                h.keywords = ""
                h.photo = 'pics/hints/' + make_unique(36) + ".jpg"
                h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
                h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
                f.write("hint_add - 5\n")
                if 'name' in request.FILES.keys():
                    handle_uploaded_file(request.FILES['name'],settings.MEDIA_ROOT + h.photo.name)
                elif 'uploaded_file' in request.FILES.keys():
                    handle_uploaded_file(request.FILES['uploaded_file'],settings.MEDIA_ROOT + h.photo.name)
                else:
                    # This is a submission from Save It from Mobile.
                    f.write("crawl_photo is " + str(crawl_photo) + "\n")
                    shutil.copy(crawl_photo, settings.MEDIA_ROOT + h.photo.name)
                crawl_hint_clean(crawl_photo)
                h.source = crawl_source
                if crawl_price == None:
                    crawl_price = 0
                h.price = crawl_price
                h.name = crawl_name
                f.write("hint_add - 6\n")
                photo_convert(settings.MEDIA_ROOT + h.photo.name,
                              settings.MEDIA_ROOT + h.photo_web.name, "480000")
                photo_convert(settings.MEDIA_ROOT + h.photo.name,
                              settings.MEDIA_ROOT + h.photo_mob.name, "147200")
                f.write("hint_add - 7\n")
                color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
                h.dominant_hex = color_hex
                h.save()
                f.write("hint_add - 8\n")
            elif origin == "mobile":
                # This is a submission to add a new hint item that the user saw
                # while walking around
                f.write("hint_add - 8.5.0 - Add An Item")
                h.hintuniq = make_unique(36)
                h.seconds = datetime.utcnow().replace(tzinfo=utc)
                h.keywords = ""
                h.photo = 'pics/hints/' + make_unique(36) + ".jpg"
                h.photo_web = 'pics/hints/' + make_unique(36) + ".jpg"
                h.photo_mob = 'pics/hints/' + make_unique(36) + ".jpg"
                f.write("hint_add - 5\n")
                if 'name' in request.FILES.keys():
                    handle_uploaded_file(request.FILES['name'],settings.MEDIA_ROOT + h.photo.name)
                elif 'uploaded_file' in request.FILES.keys():
                    handle_uploaded_file(request.FILES['uploaded_file'],settings.MEDIA_ROOT + h.photo.name)
                photo_convert(settings.MEDIA_ROOT + h.photo.name,
                              settings.MEDIA_ROOT + h.photo_web.name, "480000")
                photo_convert(settings.MEDIA_ROOT + h.photo.name,
                              settings.MEDIA_ROOT + h.photo_mob.name, "147200")
                color_hex, color_rgb = get_color_stats(settings.MEDIA_ROOT + h.photo_mob.name)
                h.dominant_hex = color_hex
                h.save()

        # If this hint has not been added before, track it as a roomhint
        rh = roomhint_add(p, h, up)
        f.write("hint_add - 8.6\n")
        return h, p

    f.write("hint_add - 9\n")
    return None, None

@csrf_exempt
def api_v3_hint_add(request):
    if request.method == 'POST':
        projuniq = request.GET.get('projuniq','')
        source = request.GET.get('source','')
        source_url = request.GET.get('source_url','')
        price = request.GET.get('price','')
        hintuniq = request.GET.get('hintuniq','')
        if price != '':
            price = int(price)
        else:
            price = 0
        h, p = profile_hint_add(request,projuniq,source,source_url,price,hintuniq,'mobile')
        data = dict()
        if h:
            data['hintuniq'] = h.hintuniq
            data['added'] = "yes"
        else:
            data['added'] = "no"
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    return HttpResponse()

@csrf_exempt
def api_v4_hint_update(request):
    if request.method == 'POST':
        origin = 'mobile'
    elif request.method == 'GET':
        origin = 'web'

    if request.method == 'POST' or request.method == 'GET': # Support this for /room to send likes without posting
        profuniq = request.GET.get('profuniq','')
        if profuniq == '':
            profuniq, u, up = make_profuniq(request,origin)
        up = profuniq_to_prof(profuniq)
        projuniq = request.GET.get('projuniq','')
        p = Project.objects.filter(projuniq=projuniq).get()
        hintuniq = request.GET.get('hintuniq','')
        f = open('/tmp/hint_update','ab+')
        f.write("api_v4_hint_update of hintuniq " + str(hintuniq) + " with projuniq " + str(projuniq) + " and profuniq " + str(profuniq) + "\n")
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        update_of_hint = False
        rh_all = RoomHint.objects.filter(project_id=p.id,hint_id=h.id,public=True)
        if len(rh_all) > 0:
            rh = rh_all[0]
        else:
            # The update is for a hint, not a roomhint
            update_of_hint = True


        f.write('update_of_hint ' + str(update_of_hint) + "\n")
        if h and up and p:
            # There was a match

            # Regardless of who submitted the like, track the like
            rhl = None
            if update_of_hint == False:
                f.write("updating roomhintlike\n")
                rhl = RoomHintLike()
                rhl.prof = up
                rhl.roomhint = rh
                rhl.seconds = datetime.utcnow().replace(tzinfo=utc)
            like = request.GET.get('like','')
            if like == 'yes':
                cursor = connection.cursor()
                f.write("sql is UPDATE roomhints_hint set love_count = love_count + 1 WHERE id = " + str(h.id) + "\n")
                cursor.execute("UPDATE roomhints_hint set love_count = love_count + 1 WHERE id = " + str(h.id))
                if update_of_hint == False:
                    f.write("liked roomhintlike\n")
                    rhl.liked = True
                    cursor.execute("UPDATE roomhints_roomhint set love_count = love_count + 1 WHERE id = " + str(rh.id))
                cursor.close()
            elif like == 'no':
                cursor = connection.cursor()
                cursor.execute("UPDATE roomhints_hint set love_count = love_count - 1 WHERE id = " + str(h.id))
                if update_of_hint == False:
                    f.write("unliked roomhintlike\n")
                    rhl.liked = False
                    cursor.execute("UPDATE roomhints_roomhint set love_count = love_count - 1 WHERE id = " + str(rh.id))
                cursor.close()

            if update_of_hint == False:
                rhl.save()


            if update_of_hint == False:
                # Should not have to track like info twice in two
                # tables. A database should be able to give us counts very
                # fast.
                if p.profile_id == up.id:
                    # The user who submitted the like is the owner of the project
                    if rh.love_count == None:
                        rh.love_count = 0
                    if like == 'yes':
                        rh.love = True
                    elif like == 'no':
                        rh.love = False
                    rh.save()

            data = dict()
            data['hintuniq'] = h.hintuniq
            data['like'] = like
            ret = json.dumps(data, sort_keys=True, indent=4)
            return HttpResponse(ret)
        return HttpResponse()
    return HttpResponse()

@csrf_exempt
def api_v4_hint_delete(request):
    if request.method == 'POST':
        profuniq = request.GET.get('profuniq','')
        #up = profuniq_to_prof(profuniq)
        hintuniq = request.GET.get('hintuniq','')
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        projuniq = request.GET.get('projuniq','')
        p = Project.objects.filter(projuniq=projuniq).get()
        rh_all = RoomHint.objects.filter(project_id=p.id,hint_id=h.id,public=True)
        for rh in rh_all:
            # It's possile that the same hint was added in a project multiple times.
            rh.public = False
            rh.delete_seconds = datetime.utcnow().replace(tzinfo=utc)
            rh.save()
        return HttpResponse()
    return HttpResponse()

def roomhint_add(p, h, up, minutes=None):
    rh = RoomHint()
    rh.project = p
    rh.hint = h
    rh.profile = up
    startdate = datetime.utcnow().replace(tzinfo=utc)
    rh.seconds = datetime.utcnow().replace(tzinfo=utc)
    # if p.profile.id != up.id and up.designer == True:
    #     # When a designer is adding a roomhint, postdate it
    #     s = 60 * 60 * 4 Wait a while
    #     enddate = startdate + timedelta(seconds=s)
    #     rh.seconds = enddate
    rh.love = False
    rh.love_count = 0
    rh.public = True
    rh.delete_seconds = None
    rh.received_seconds = None
    rh.save()
    p.hide = False
    p.save()
    return rh

def hint_copy(request):
    projuniq = request.GET.get('projuniq','')
    p = Project.objects.filter(projuniq=projuniq).get()
    profuniq = request.GET.get('profuniq','')
    u = User.objects.filter(username=profuniq).get()
    up = Profile.objects.filter(user_id=u.id).get()
    hintuniq = request.GET.get('hintuniq','')
    fromsearch = request.GET.get('fromsearch','')
    h = Hint.objects.filter(hintuniq=hintuniq).get()
    # Copy only if there is no existing copy
    rh_all = RoomHint.objects.filter(project_id=p.id,hint_id=h.id,public=True)
    if len(rh_all) == 0:
        # There is no existing copy
        rh = roomhint_add(p, h, up)
        return h, p, rh
    else:
        # There is an existing copy
        pass
    return None, None, None

@csrf_exempt
def api_v3_hint_copy(request):
    if request.method == 'POST':
        f = open('/tmp/hintcopy','ab+')
        f.write("copy - 1\n")
        h, p, rh = hint_copy(request)
        f.write("copy - 2\n")
        data = dict()
        if h and p and rh:
            f.write("copy - 3\n")
            data_item = hintout(h, p, rh)
            f.write("copy - 4\n")
            data['hint'] = data_item
            data['copied'] = "yes"
            data['message'] = "  SAVED.   You can search for more."
        else:
            data['copied'] = "no"
            data['message'] = "You already saved this hint\nin this room."
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    return HttpResponse()

def feedback_add(up,content):
    f = Feedback()
    f.content = content
    f.feeduniq = make_unique(36)
    f.seconds = datetime.utcnow().replace(tzinfo=utc)
    f.profile = up
    f.notifiedus = False
    f.save()
    return f
    
@csrf_exempt
def api_v4_feedback_add(request):
    if request.method == 'POST':
        content = request.GET.get('content','')
        profuniq = request.GET.get('profuniq','')
        up = profuniq_to_prof(profuniq)
        f = feedback_add(up,content)
        data = dict()
        data['feeduniq'] = f.feeduniq
        data['message'] = "THANKS! We'll try to do what you said immediately.\n\nYou're the best!"
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    return HttpResponse()

def comment_add(p,up,content,auto_responded,des_notified):
    c = Comment()
    c.project = p
    c.content = content
    c.communiq = make_unique(36)
    c.seconds = datetime.utcnow().replace(tzinfo=utc)
    c.profile = up
    c.auto_responded = auto_responded
    c.des_notified = des_notified
    c.save()
    p.hide = False
    p.save()
    return c

@csrf_exempt
def api_v4_comment_add(request):
    if request.method == 'POST':
        content = request.GET.get('content','')
        profuniq = request.GET.get('profuniq','')
        projuniq = request.GET.get('projuniq','')
        up = profuniq_to_prof(profuniq)
        all_p = Project.objects.filter(projuniq=projuniq)
        # If there was a bug in adding a project, there might have been no project assigned?
        if len(all_p) > 0:
            p = all_p[0]
            data = dict()
            paid_ret, paid_datetime = project_paid(p.id)
            if paid_ret == False:
                all_c = Comment.objects.filter(profile_id=up.id,project_id=p.id,public=True)
                if len(all_c) >= 100:
                    data['should_pay'] = "yes"
                else:
                    c = comment_add(p,up,content,False,True)
                    data['communiq'] = c.communiq
                    data['should_pay'] = "no"
            else:
                c = comment_add(p,up,content,False,False)
                data['communiq'] = c.communiq
                data['should_pay'] = "no"
            # People don't want to share
            #data['message'] = "Our designers received your question and will give advice for your photo shortly.\n\nWhen you SHARE a photo, your friends are able to give you advice too."
            data['message'] = "Our designers received your question and will give advice for your photo shortly."
            ret = json.dumps(data, sort_keys=True, indent=4)
            return HttpResponse(ret)
        else:
            return HttpResponse()
    return HttpResponse()

@csrf_exempt
def api_v4_comment(request):
    data = dict()
    data['newest'] = []
    max_entries = 100
    
    projuniq = request.GET.get('projuniq','')
    seconds = request.GET.get('seconds','')
    profuniq = request.GET.get('profuniq','')
    p = Project.objects.filter(projuniq=projuniq,public=True).get()
    up = profuniq_to_prof(profuniq)
    if seconds == '' or seconds == '0':
        # If no seconds are supplied, show few entries from recently
        t = datetime.utcnow().replace(tzinfo=utc) - timedelta(days=300)
        seconds = calendar.timegm(t.timetuple())
    else:
        seconds = int(seconds)
    seconds_todatetime = datetime.fromtimestamp(seconds+1)
    call = Comment.objects.filter(public=True,project_id=p.id).order_by('-seconds').filter(seconds__gt=seconds_todatetime).order_by('seconds')[:max_entries]
    for c in call:
        value = dict()
        value['content'] = c.content
        if c.profile_id == up.id:
            value['owner'] = "yes"
        else:
            value['owner'] = "no"
        t = c.seconds
        c.received_seconds = seconds_todatetime
        c.save()
        value['seconds'] = calendar.timegm(t.timetuple())
        data['newest'].append(value) 
    data['badge_count'] = compute_badge_count_for_project(p.id)
    data['free_questions'] = ''
    paid_ret, paid_datetime = project_paid(p.id)
    if paid_ret == False:
        all_c = Comment.objects.filter(profile_id=up.id,project_id=p.id,public=True)
        if len(all_c) >= 2:
            data['free_questions'] = 'You have ' + str(2-len(all_c)) + ' free questions left.'
    ret = json.dumps(data, sort_keys=True, indent=4)
    return HttpResponse(ret)

@csrf_exempt
def api_v3_search(request):
    if request.method == 'GET':
        q = request.GET.get('q','')
        data = search(q)
        ret = json.dumps(data, sort_keys=True, indent=4)
        return HttpResponse(ret)
    return HttpResponse()

class HintForm(forms.Form):
    price = forms.IntegerField() # Not FloatField
    source = forms.CharField()
    photo = forms.ImageField()
    projuniq = forms.CharField()

class RoomForm(forms.Form):
    price = forms.IntegerField()
    projuniq = forms.CharField()
    source = forms.CharField()
    photo = forms.FileField()

def roomhint_pushed(rh):
    return False # roomhints are no longer pushed

def comment_pushed(c):
    f = open('/tmp/comment_pushed','ab+')
    f.write("in\n")
    pushed = False
    d_all = Device.objects.filter(pk=c.project.profile.device_id)
    if len(d_all) > 0:
        f.write("found device\n")
        d = d_all[0]
        if d.last_notified_at > c.seconds:
            f.write("push already sent\n")
            # A push was already sent
            pushed = True
    return pushed

def rooms_except(p_id,up_id):
    rooms = []
    cursor = connection.cursor()
    sql = "select projuniq, photo_mob, seconds from roomhints_project p where p.profile_id = " + str(up_id) + " and p.id != " + str(p_id) + " and p.public = true order by seconds desc"
    cursor.execute(sql)
    for row in cursor.fetchall():
        data_item = dict()
        data_item['showprojuniq'] = row[0][:6]
        data_item['projuniq'] = row[0]
        data_item['photo'] = row[1]
        data_item['age'] = seconds_to_age(row[2])
        rooms.append(data_item)
    cursor.close()
    return rooms

# See all hints of a room
# select p.projuniq, h.project_id, h.id, h.source, h.price from roomhints_hint h, roomhints_project p where p.id = h.project_id order by project_id;
def room(request):
    request.session.set_expiry(60*60*24*365*2) # 2 years
    if request.method == 'GET':
        profuniq = request.GET.get('profuniq','')
        u = None
        up = None
        if profuniq == '':
            profuniq, u, up = make_profuniq(request,'web')
        up = profuniq_to_prof(profuniq)
        projuniq = request.GET.get('projuniq','')
        logger.debug("Received projuniq " + str(projuniq))
        all = Project.objects.filter(projuniq=projuniq,public=True)
        if len(all) == 1:
            # If this is a redirection back, we want to track it
            redirect_out = redirect_out_get(request)

            p = all[0]
            project_view_add(up,p,'web_view',request)
            p.photo_web.name = settings.MEDIA_URL + p.photo_web.name
            other_rooms = rooms_except(p.id,p.profile_id)
            seconds_now = datetime.utcnow().replace(tzinfo=utc)
            #roomhints = RoomHint.objects.filter(project_id = p.id, seconds__lt=seconds_now,public=True).order_by('-seconds')
            roomhints = RoomHint.objects.filter(project_id=p.id, public=True).order_by('-seconds')
            showhints = []
            for rh in roomhints:
                rhl_all = RoomHintLike.objects.filter(roomhint_id=rh.id,prof_id=up.id).order_by('-id')
                love = 0
                if len(rhl_all) > 0:
                    # The last impression tells us whether the
                    # visiting user liked or disliked this roomhint
                    rhl = rhl_all[0]
                    love = rhl.liked
                    f = open('/tmp/rhl', 'ab+')
                    f.write(str(rhl.roomhint_id) + " " +str(love) + "\n")
                    
                h = Hint.objects.filter(pk=rh.hint_id).get()
                if h.hintuniq in redirect_out.keys():
                    # This was a redirection back, track it
                    hint_view_add(request,profuniq,h.hintuniq,'web_browse_stop')
                    del redirect_out[h.hintuniq]
                    request.session['redirect_out'] = redirect_out
                data_item = dict()
                data_item['hintuniq'] = h.hintuniq
                data_item['photo'] = h.photo_web.name
                data_item['price'] = math.ceil(h.price)
                data_item['name'] = h.name
                data_item['source'] = h.source
                data_item['source_url'] = url_encode(h.source_url)
                data_item['love'] = love
                data_item['owner_love'] = rh.love
                data_item['roomhint_love_count'] = rh.love_count
                data_item['hint_love_count'] = h.love_count
                data_item['sent_by_designer'] = rh.profile.designer
                data_item['push_sent'] = roomhint_pushed(rh)
                if rh.profile.id == up.id:
                    data_item['sent_by_me'] = True
                else:
                    data_item['sent_by_me'] = False
                if rh.received_seconds == None:
                    data_item['received_by_user'] = False
                else:
                    data_item['received_by_user'] = True
                data_item['hinttypes'] = hinttype_get(h.id)
                data_item['hintstyles'] = hintstyle_get(h.id)
                data_item['age'] = seconds_to_age(rh.seconds)
                if seconds_now < rh.seconds:
                    data_item['age_future'] = True
                else:
                    data_item['age_future'] = False
                showhints.append(data_item)
            room = dict()
            room['age'] = seconds_to_age(p.seconds)
            room_url = "http://roomhints.com/room?projuniq=" + p.projuniq
            geof = open('/tmp/geoip','ab+')
            try:
                geof.write("Will try to import...\n")
                from roomhints.geoip_is_broken import geoip_hack
                #from django.contrib.gis.utils.geoip import GeoIP
                #from django.contrib.gis.geoip import GeoIP
                #g = GeoIP(path='/home/roomhints/devel/RH/website/mysite/geoip/')
                #city = g.city('174.252.39.12')
                city = geoip_hack(p.ip)
                geof.write("Got PAST the g=GeoIP() line\n")
                room['geo_city'] = city['city']
                room['geo_country_name'] = city['country_name']
                room['geo_area_code'] = city['area_code']
                room['geo_postal_code'] = city['postal_code']
                room['geo_google_maps'] = "https://maps.google.com/maps?q=" + url_encode(room['geo_city']) + "," + url_encode(room['geo_country_name'])
            except Exception,e:
                geof.write("failed with exception\n" + str(e) + "\n")
                pass # If GeoIP is not setup, don't break
            room['comments'] = []
            # Wanted to filter out comments possibly scheduled
            # t = datetime.utcnow().replace(tzinfo=utc)
            # seconds = calendar.timegm(t.timetuple())
            # seconds_todatetime = datetime.fromtimestamp(seconds)
            seconds_todatetime = datetime.utcnow().replace(tzinfo=utc)
            f = open('/tmp/comment','ab+')
            f.write('searching for comments' + "\n")
            #call = Comment.objects.filter(project_id=p.id).order_by('-seconds').filter(seconds__gt=seconds_todatetime)
            call = Comment.objects.filter(public=True,project_id=p.id).order_by('-seconds')
            room['comments_count'] = 0
            if len(call) > 0:
                f.write("found " + str(len(call)) + " comments\n")
                for c in call:
                    citem = dict()
                    citem['content'] = c.content
                    citem['communiq'] = c.communiq
                    citem['age'] = seconds_to_age(c.seconds)
                    citem['name'] = c.profile.user.first_name
                    citem['received'] = False
                    if c.received_seconds != None:
                        citem['received'] = True
                    citem['push_sent'] = comment_pushed(c)
                    f.write('adding comment: ' + c.content + "\n")
                    if c.profile.designer == True:
                        citem['sent_by_designer'] = True
                    else:
                        citem['sent_by_designer'] = False
                    if c.profile.id == up.id:
                        citem['sent_by_me'] = True
                    else:
                        citem['sent_by_me'] = False
                    if c.received_seconds == None:
                        citem['received_by_user'] = False
                    else:
                        citem['received_by_user'] = True
                    room['comments'].append(citem)
                    room['comments_count'] += 1
            f.close()
            room['enc_room'] = url_encode(room_url)
            room['enc_room_photo'] = url_encode(p.photo_web.name)
            if p.custom == None: # backward compatibility with older app tiff uses to upload pictures.
                p.custom = ""
            room['enc_room_custom'] = url_encode(p.custom)
            room['plain_room'] = room_url
            room['email_subject'] = "RoomHints?"
            room['email_body'] = "I'm decorating, can you offer a hint?%0A%0A" + room_url + "%0A%0A%0A%0AWhat is a hint? A decorating tip for my space. Make sure to cc post@roomhints.com and state item $price keywords and url%0A%0A..for example%0A%0AStarry Night $562 painting " + url_encode("http://www.overstockart.com/starrynight3.html?utm_source=froogle&utm_medium=froogle-feed&utm_content=starrynight3&gclid=CJKn482TnrECFYFo4AoddUvjgA") + "%0A%0A..or you could get the App: http://roomhints.com/app"
            paid_ret, paid_seconds = project_paid(p.id)
            if paid_ret:
                room['paid'] = "yes"
                room['paid_amount'] = int(math.ceil(p.profile.charge_amount))
                room['paid_age'] = seconds_to_age(paid_seconds)
            else:
                room['paid'] = "no"
            page = dict()
            page['title'] = title
            page['is_designer'] = up.designer
            page['page'] = "room"
            page['users_can_add'] = False
            page['owner'] = False
            page['showroom_user'] = False
            page['has_account'] = up.has_account
            f = open('/tmp/account', 'ab+')
            f.write("paid_ret is " + str(paid_ret) + "\n")
            f.write('has_account is ' + str(up.has_account) + " for " + str(up.id) + "\n")
            f.close()
            if p.name == None:
                p.name = ""
            if p.roomtype.name == "showroom_user":
                page['showroom_user'] = True
            if p.profile_id == up.id:
                page['owner'] = True

            impressions = []
            feedback = []
            designer_hint_types = []
            if page['is_designer'] == True:
                page['has_feedback'] = False
                fall = Feedback.objects.filter(profile_id = p.profile_id).order_by('-seconds')
                if len(fall) > 0:
                    page['has_feedback'] = True
                    for f in fall:
                        feedback_item = dict()
                        feedback_item['age'] = seconds_to_age(f.seconds)
                        feedback_item['content'] = f.content
                        feedback.append(feedback_item)
                    
                # Display what the user had seen
                sig_all = SearchImpressionGroup.objects.filter(project_id=p.id).order_by('-seconds')
                if len(sig_all) > 0:
                    for s in sig_all:
                        sig_item = dict()
                        sig_item['custom'] = s.custom
                        sig_item['age'] = seconds_to_age(s.seconds)
                        sig_item['si'] = []
                        si_all = SearchImpression.objects.filter(group_id=s.id).order_by('-total_score')
                        for si in si_all:
                            si_item = dict()
                            si_item['photo'] = si.hint.photo_mob.name
                            si_item['chosen'] = si.chosen
                            si_item['name'] = si.hint.name
                            si_item['source'] = si.hint.source
                            si_item['source_url'] = si.hint.source_url
                            si_item['price'] = math.ceil(si.hint.price)
                            si_item['hintuniq'] = si.hint.hintuniq
                            si_item['hinttypes'] = hinttype_get(si.hint.id)
                            sig_item['si'].append(si_item)
                        impressions.append(sig_item)

                # Have the designer hints handy in case the designer wants to add some
                des_all = Hint.objects.filter(profile_id=up.id,public=True).order_by('-seconds')
                designer_hint_types = hints_to_hintsbytype(des_all)
            
            return render(request, 'roomhints/room.html', { 'project': p, 'hints': showhints, 'page': page, 'room':room, 'impressions':impressions, 'designer_hint_types':designer_hint_types, 'feedback':feedback, 'other_rooms':other_rooms })
        else:
            # This project might be deleted
            all_p = Project.objects.filter(projuniq=projuniq)
            p = None
            if len(all_p) == 1:
                p = all_p[0]

        page = dict()
        page['title'] = title
        page['page'] = "room"
        page['is_designer'] = up.designer
        return render(request, 'roomhints/room_invalid.html', {'page': page, 'project': p})
    elif request.method == 'POST':
        f = open('/tmp/room', 'ab+')
        f.write('room POST - 1\n')
        f.write('room POST - ' + str(request.FILES)+ '\n')
        f.write('room POST - ' + str(request.POST)+ '\n')
        #form = RoomForm(request.POST,request.FILES)
        f.write('room POST - 2\n')
        # if form.is_valid(): # All validation rules pass
        #     f.write('room POST - 3\n')
        #     projuniq = form.cleaned_data['projuniq']
        #     source = form.cleaned_data['source']
        #     price = form.cleaned_data['price']
        #     photo = form.cleaned_data['name']
        #     f.write('room POST - 4\n')
        projuniq = request.POST['projuniq']
        source = request.POST['source']
        source_url = request.POST['source_url']
        price = request.POST['price']
        h, p = profile_hint_add(request,projuniq,source,source_url,price,None,'web')
        if 'roomname' in request.POST.keys():
            # This is a showroom providing a room name
            p.name = request.POST['roomname']
        f.write('room name is ' + str(p.name) + '\n')
        p.save()
        if h:
            f.write('room POST - 5 added\n')
            return HttpResponseRedirect('/room?projuniq=' + str(p.projuniq))
            # else:
            #     f.write('room POST - 6 add failed\n')
            #     return HttpResponseRedirect('/room')
        else:
            # Invalid
            f.write('room POST - 10 INVALID\n')
            return HttpResponseRedirect('/room')
    else:
        return HttpResponse()

def room_waiting_hide(request):
    if request.method == "GET":
        profuniq, u, up = make_profuniq(request,'web')
        projuniq = request.GET.get('projuniq','')
        hide = request.GET.get('hide','')
        if up.designer:
            all_p = Project.objects.filter(projuniq=projuniq,public=True)
            if len(all_p) > 0:
                p = all_p[0]
                if hide == "yes":
                    p.hide = True
                    p.save()
                elif hide == "no":
                    p.hide = False
                    p.save()
        #         return HttpResponseRedirect('/designer/rooms/waiting')
        #     else:
        #         return HttpResponseRedirect('/room?projuniq=' + projuniq)
        # else:
        #     return HttpResponseRedirect('/room?projuniq=' + projuniq)
        return HttpResponseRedirect('/room?projuniq=' + projuniq)
    else:
        return HttpResponse()

# Called by a designer
def room_hint_add(request):
    if request.method == 'GET':
        origin = "web"
        profuniq = request.GET.get('profuniq','')
        if profuniq == '':
            profuniq, u, up = make_profuniq(request,origin)
        up = profuniq_to_prof(profuniq)
        hintuniq = request.GET.get('hintuniq','')
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        projuniq = request.GET.get('projuniq','')
        p = Project.objects.filter(projuniq=projuniq).get()
        if h and up and p:
            # There was a match
            rh = roomhint_add(p, h, up, 60*4)
        return HttpResponse()

def room_hint_delete(request):
    if request.method == 'GET':
        origin = "web"
        profuniq = request.GET.get('profuniq','')
        if profuniq == '':
            profuniq, u, up = make_profuniq(request,origin)
        up = profuniq_to_prof(profuniq)
        hintuniq = request.GET.get('hintuniq','')
        h = Hint.objects.filter(hintuniq=hintuniq).get()
        projuniq = request.GET.get('projuniq','')
        p = Project.objects.filter(projuniq=projuniq).get()
        if h and up and p:
            # There was a match
            rh = RoomHint.objects.filter(project_id=p.id,hint_id=h.id,profile_id=up.id,public=True,received_seconds=None).order_by('-seconds').get()
            # Delete only roomhints added by you, which have not been deleted already,
            # and not received. if this hint was added more than once only delete the
            # Delete only if no push notification was sent yet
            if roomhint_pushed(rh) == False:
                rh.public = False
                rh.save()
        return HttpResponse()

def room_comment_delete(request):
    if request.method == 'GET':
        origin = "web"
        profuniq, u, up = make_profuniq(request,origin)
        up = profuniq_to_prof(profuniq)
        communiq = request.GET.get('communiq','')
        c = Comment.objects.filter(communiq=communiq,profile_id=up.id,public=True,received_seconds=None).get()
        # Delete only comments added by you, which have not been deleted already,
        # and not received. Delete only if no push notification was sent yet
        if comment_pushed(c) == False:
            c.public = False
            c.save()
        return HttpResponse()

def comment(request):
    if request.method == 'POST':
        projuniq = request.POST['projuniq']
        comment = request.POST['comment']
        profuniq, u, up = make_profuniq(request,'web')
        up = profuniq_to_prof(profuniq)
        p = Project.objects.filter(projuniq=projuniq).get()

        f = open('/tmp/comment','ab+')
        f.write("comment is  " + comment + "\n")
        if len(comment) > push_max():
            comment_size = len(comment)
            f.write("comment was above max")
            return render(request, 'roomhints/comment_result.html', { "comment_limit":push_max(), "comment_size":comment_size } )
        else:
            f.write("comment was NOT above max\n")
            f.write("up.id is " + str(up.id) + "\n")
            if up.designer == True:
                f.write("up.designer is " + str(up.designer) + "\n")
                c = comment_add(p,up,comment,False,True)
            return HttpResponseRedirect('/room?projuniq=' + p.projuniq + "#comments")
    else:
        return HttpResponse()

def comment_push(request):
    if request.method == 'GET':
        projuniq = request.GET.get('projuniq','')
        profuniq, u, up = make_profuniq(request,'web')
        up = profuniq_to_prof(profuniq)
        p = Project.objects.filter(projuniq=projuniq).get()
        if up.designer:
            push_comments(p.projuniq)
        return HttpResponseRedirect('/room?projuniq=' + p.projuniq + "#comments")
    else:
        return HttpResponse()


def comment_special(request):
    if request.method == 'GET':
        projuniq = request.GET.get('projuniq','')
        kind = request.GET.get('kind','')
        profuniq, u, up = make_profuniq(request,'web')
        up = profuniq_to_prof(profuniq)
        p = Project.objects.filter(projuniq=projuniq).get()
        if up.designer:
            comment = None
            name = up.user.first_name
            name_list = name.split(' ')
            if len(name_list) > 1:
                name = name_list[0]
            if name == "":
                name = random_name()
            if kind == "space":
                comment = "Hey! Is this the space where the " + custom_last(p.custom) + " will go? This is " + name + ", I'm a designer on RoomHints. Thanks!"
            elif kind == "blurry":
                comment = "Hi! Your photo came through blurry - can you shoot another one? This is " + name + ", I'm a designer on RoomHints. Thanks!"
            elif kind == "hints_sent":
                comment = "Here are a few hints for your room. I am " + name + " a designer with RoomHints. "
            elif kind == "upload":
                comment = "Hey, thanks for testing out RoomHints. I am " + name + " a designer with RoomHints. Upload a photo of your room and I will give you some hints."
            if comment != None:
                c = comment_add(p,up,comment,False,True)
        return HttpResponseRedirect('/room?projuniq=' + p.projuniq + "#comments")
    else:
        return HttpResponse()

def roomhints_header(request):
    return render(request, 'roomhints/roomhints_header.html')

def room_main(request):
    return render(request, 'roomhints/room_main.html')

def redirect_out_get(request):
    redirect_out = None
    # Append to any existing values
    if request.session.get('redirect_out', None) == None:
        redirect_out = dict()
    else:
        redirect_out = request.session['redirect_out']
    return redirect_out

def room_redirect(request):
    page = dict()
    page['title'] = title
    page['page'] = 'hint_browse'

    redir = dict()
    redir['target'] = request.GET.get('target')
    f = open('/tmp/room_redirect','ab+')
    f.write("target is " + redir['target'] + "\n")
    redir['projuniq'] = request.GET.get('projuniq')
    hintuniq = request.GET.get('hintuniq')
    redir['hintuniq'] = hintuniq
    profuniq, u, up = make_profuniq(request,'web')
    hint_view_add(request,profuniq,hintuniq,'web_browse_start')

    # Add in the user session information that will help us determine
    # when browsing for this hint stopped.
    redirect_out = redirect_out_get(request)
    redirect_out[hintuniq] = True
    request.session['redirect_out'] = redirect_out
    return render(request, 'roomhints/room_redirect.html', { 'redir': redir, 'page': page } )

@cache_page(60 * 60 * 24 * 365)
def facebook_channel(request):
    return render(request, 'roomhints/facebook_channel.html')

def room_new(request):
    request.session.set_expiry(60*60*24*365*2) # 2 years
    if request.method == 'GET':
        page = dict()
        page['title'] = title
        return render(request, 'roomhints/room_new.html', { "page": page} )
    elif request.method == 'POST':
        f = open('/tmp/room_new', 'ab+')
        rt = None
        custom = None
        name = None
        budget = -1
        roomtype = request.POST['roomtype']
        if roomtype == "user": # Coming from the front page
            rt = RoomType.objects.filter(name="showroom_user").get()
            custom = ""
            budget = -1
            if 'roomname' in request.POST.keys():
                name = request.POST['roomname']
        else:
            rt = RoomType.objects.filter(name="decorate").get()
            custom = request.POST['custom']
            budget = request.POST['budget']
        f.write('room_new: custom is :' + custom + "\n" )
        # Find out the user profile adding the room
        profuniq, u, up = make_profuniq(request,'web')
        up = profuniq_to_prof(profuniq)
        p = project_add(request,up.id)
        p.custom = custom # saving twice is clunky
        p.budget = budget
        p.name = name
        p.roomtype = rt
        p.save()
        f = open('/tmp/room_new', 'ab+')
        f.write('room_new: projuniq is: ' + p.projuniq + "\n")
        return HttpResponseRedirect('http://roomhints.com/room?projuniq=' + str(p.projuniq))
    else:
        return HttpResponse()

def designer_room_new(request):
    if request.method == 'GET':
        profuniq, u, up = make_profuniq(request,"web")
        up = profuniq_to_prof(profuniq)
        page = dict()
        page['title'] = title
        page['page'] = "designer_room_new"
        page['is_designer'] = up.designer
        return render(request, 'roomhints/designer_room_new.html', { "page": page })
    else:
        return HttpResponse()

def roomhint(request):
    request.session.set_expiry(60*60*24*365*2) # 2 years
    if request.method == 'GET':
        profuniq = request.GET.get('profuniq','')
        u = None
        up = None
        if profuniq == '':
            profuniq, u, up = make_profuniq(request,'web')
            #up = profuniq_to_prof(profuniq)
        # Track hint view on web

        p = None
        projuniq = request.GET.get('projuniq')
        all = Project.objects.filter(projuniq=projuniq,public=True)
        if len(all) == 1:
            p = all[0]

        h = None
        hintuniq = request.GET.get('hintuniq')
        all_h = Hint.objects.filter(hintuniq=hintuniq,public=True)
        if len (all_h) == 1:
            h = all_h[0]

        if p and h:
            all_rh = RoomHint.objects.filter(project_id=p.id, hint_id = h.id, public=True)
            if len(all_rh) == 1:
                rh = all_rh[0]
                return HttpResponseRedirect('room/redirect?target=' + h.source_url + '&projuniq=' + projuniq + '&hintuniq=' + h.hintuniq)
            else:
                return render(request, 'roomhints/hint_invalid.html')
        else:
            return render(request, 'roomhints/hint_invalid.html')

    return HttpResponse()

def designer_hint(request):
    request.session.set_expiry(60*60*24*365*2) # 2 years
    if request.method == 'GET':
        hintuniq = request.GET.get('hintuniq')
        all_h = Hint.objects.filter(hintuniq=hintuniq,public=True)
        if len (all_h) > 0:
            h = all_h[0]

            up = profuniq_to_prof(request.user.username)
            page = dict()
            page['title'] = h.name
            page['page'] = "hint"
            page['is_designer'] = up.designer
            if h.profile.id == up.id:
                page['owner'] = 1
            else:
                page['owner'] = 0
            ht = hinttype_get(h.id)
            hs = hintstyle_get(h.id)
            return render(request, 'roomhints/designer_hint.html', {'hint': h, "page":page, "hinttypes":ht, "hintstyles":hs } )
        else:
            return render(request, 'roomhints/hint_invalid.html')
    return HttpResponse()

@csrf_exempt
def hint_like(request):
    return api_v4_hint_update(request)

def how(request):
    page = dict()
    page['title'] = "How It Works"
    page['page'] = "how"
    return render(request, 'roomhints/how_it_works.html', {"page":page})

def privacy(request):
    page = dict()
    page['title'] = "Privacy"
    page['page'] = "privacy"
    return render(request, 'roomhints/privacy.html', {"page":page})

def careers(request):
    page = dict()
    page['title'] = "Careers"
    page['page'] = "careers"
    return render(request, 'roomhints/careers.html', { "page":page })

def terms(request):
    page = dict()
    page['title'] = "Terms of Service"
    page['page'] = "terms"
    return render(request, 'roomhints/terms.html', { "page":page })

def designer_stats(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "Stats"
        page['page'] = "designer_stats"
        page['is_designer'] = up.designer

        return render(request, 'roomhints/designer_stats.html', { "page":page })
    else:
        return HttpResponseRedirect('/designer/login')

def hint_stats(best):
    # Count number of hint saves, and searchimpressions, and roomhintimpressions
    days = 7
    ordering = ""
    if best:
        ordering += " order by saved_per_view desc, views asc"
    else:
        ordering += " order by saved_per_view asc, views desc"
    sql_saved = "select h.id as hint_id, count(*) as count from roomhints_roomhint rh, roomhints_hint h, roomhints_profile up where rh.profile_id = up.id and up.designer = false and h.public = true and rh.hint_id = h.id and rh.seconds > now() - interval '" + str(days) + " days' group by h.id order by count desc"
    sql_si = "select hint_id, count(*) as count from roomhints_searchimpression si, roomhints_searchimpressiongroup sig where sig.id = si.group_id and sig.seconds > now() - interval '" + str(days) + " days' group by hint_id order by count desc"
    sql_hi = "select h.id as hint_id, count(*) as count from roomhints_roomhint rh, roomhints_hint h, roomhints_roomhintimpression rhi where h.public = true and rhi.roomhint_id = rh.id and rh.hint_id = h.id  and rh.seconds < now() - interval '" + str(days) + " days' group by h.id order by 1 desc"
    sql = "select sic.count+hic.count as views, h.id, h.price, h.name, h.source, h.photo_mob, h.seconds, h.hintuniq, savedc.count, 100*savedc.count/(sic.count+hic.count) as saved_per_view from (" + sql_si + ") as sic, (" + sql_hi + ") as hic, (" + sql_saved + ") as savedc, roomhints_hint h where sic.hint_id = hic.hint_id and hic.hint_id = savedc.hint_id and sic.hint_id = h.id and h.public = true"
    sql += ordering
    sql += " limit 100"
    cursor = connection.cursor()
    cursor.execute(sql)
    hints = []
    for row in cursor.fetchall():
        data_item = dict()
        data_item['impressions'] = row[0]
        data_item['price'] = math.ceil(row[2])
        data_item['name'] = row[3]
        data_item['source'] = row[4]
        data_item['photo'] = row[5]
        data_item['age'] = seconds_to_age(row[6])
        data_item['hintuniq'] = row[7]
        data_item['save_count'] = row[8]
        data_item['save_per_view'] = row[9]
        hints.append(data_item)
    cursor.close()
    return hints

def designer_stats_hints_worst(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "Worst Hints"
        page['page'] = "designer_stats_hints_worst"
        page['is_designer'] = up.designer
        page['best'] = False

        if request.method == 'GET':
            hints = hint_stats(False)
            return render(request, 'roomhints/designer_stats_hints.html', { "hints":hints, "page":page } )
        else:
            return HttpResponse()
    else:
        return HttpResponse()

def designer_stats_hints_best(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "Best Hints"
        page['page'] = "designer_stats_hints_best"
        page['is_designer'] = up.designer
        page['best'] = True

        if request.method == 'GET':
            hints = hint_stats(True)
            return render(request, 'roomhints/designer_stats_hints.html', { "hints":hints, "page":page } )
        else:
            return HttpResponse()
    else:
        return HttpResponse()

def designer_stats_user_map(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = "User Map"
        page['page'] = "designer_stats_user_map"
        page['is_designer'] = up.designer

        if request.method == 'GET':
            users = []
            rt = RoomType.objects.filter(name="decorate").get()
            all_p = Project.objects.filter(roomtype_id=rt.id,public=True).order_by('-seconds')[:500]
            #geof = open('/tmp/map','ab+')
            #geof.write("Got projects...\n")
            if len(all_p) > 1:
                #geof.write("Got many\n")
                for p in all_p:
                    #geof.write("Got project " + str(p.projuniq) + "\n")
                    try:
                        #geof.write("Will try to import\n")
                        from roomhints.geoip_is_broken import geoip_hack
                        #geof.write("Imported\n")
                        city = geoip_hack(p.ip)
                        city['projuniq'] = p.projuniq
                        # geof.write("Got city\n")
                        # data_item = dict()
                        # data_item['count'] = ''
                        # data_item['city'] = city['city']
                        # data_item['latitude'] = city['latitude']
                        # data_item['longitude'] = city['longtude']
                        # geof.write("Got all\n")
                        # users.append(data_item)
                        users.append(city)
                        #geof.write("Appended. Now " + str(users) + "\n")
                    except Exception,e:
                        pass # If GeoIP is not setup, don't break
            #geof.write("Users is " + str(users) + "\n")
            return render(request, 'roomhints/designer_stats_user_map.html', { "users":users, "page":page } )
        else:
            return HttpResponse()
    else:
        return HttpResponse()

def popular_rooms(days,designer_rooms):
    rt_sql = ""
    if designer_rooms:
        rt_sql = "(rt.name = 'showroom' or rt.name = 'showroom_user')"
    else:
        rt_sql = "(rt.name = 'decorate')"
    rooms = []
    cursor = connection.cursor()
    sql = "select p.id, i.imp, p.name, p.photo_square, p.photo_web, p.seconds, p.projuniq from (select project_id, count(*) as imp from roomhints_projectimpression where seconds > now() - interval '" + str(days) + " day' and meta = 'view' group by project_id order by 2 desc) i, roomhints_project p, roomhints_roomtype rt where i.project_id = p.id and p.public = true and p.roomtype_id = rt.id and " + rt_sql + " order by 2 desc limit 20;"
    cursor.execute(sql)
    for row in cursor.fetchall():
        room = dict()
        room['id'] = row[0]
        room['views'] = row[1]
        room['photo_square'] = row[3]
        if room['photo_square'] == "":
            room['photo_square'] = row[4]
        room['age'] = seconds_to_age(row[5])
        room['projuniq'] = row[6]
        rooms = rooms + [ room ]
        cursor.close()
    return rooms


def designer_stats_designer_rooms(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        if request.method == 'GET':
            page = dict()
            page['title'] = "Most popular designer rooms"
            page['page'] = 'designer_stats_designer_rooms'
            page['is_designer'] = up.designer
            page['is_designer_room'] = 1
        
            show_projects = popular_rooms(7,True)
            return render(request, 'roomhints/designer_stats_rooms.html', { "page": page, "projects": show_projects } )
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

def designer_stats_client_rooms(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        if request.method == 'GET':
            page = dict()
            page['title'] = "Most popular client rooms"
            page['page'] = 'designer_stats_rooms'
            page['is_designer'] = up.designer
            page['is_designer_room'] = 0

            show_projects = popular_rooms(7,False)
            return render(request, 'roomhints/designer_stats_rooms.html', { "page": page, "projects": show_projects } )
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

    return render(request, 'roomhints/designer_stats_rooms.html')

def afred(request):
    if request.method == 'GET':
        reduniq = request.GET.get('reduniq')
        arall = AffiliateRedirection.objects.filter(reduniq=reduniq).order_by('-seconds')
        if len(arall) > 0:
            ar = arall[0]
            f = open('/tmp/afred','ab+')
            f.write("redirecting " + reduniq + " to " + ar.target + "\n")
            f.close()
            return HttpResponseRedirect(ar.target)
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

@csrf_exempt
def api_v4_device_add(request):
    f = open('/tmp/deviceadd','ab+')
    f.write("device add called\n")
    if request.method == 'POST':
        data = dict()
        data['success'] = "yes"
        f.write("will get devicetoken\n")
        device_token = request.GET['devicetoken']
        f.write("device_token is " + str(device_token) + "\n")
        profuniq = request.GET['profuniq']
        f.write("profuniq is " + str(profuniq) + "\n")
        d_all = Device.objects.filter(device_token=device_token)
        d = None
        if len(d_all) > 0:
            # This device is already registered
            d = d_all[0]
            f.write("The device is already registered\n")
        else:
            # This device is not registered
            f.write("The device is NOT already registered\n")
            d = Device()
            d.last_notified_at = datetime.utcnow().replace(tzinfo=utc)
            d.device_token = device_token
            d.save()

        # Associate this device with its profile
        f.write("associated device with profile\n")
        up = profuniq_to_prof(profuniq)
        up.device_id = d.id
        up.save()
        ret = json.dumps(data,sort_keys=True,indent=4)
        return HttpResponse(ret)
    else:
        return HttpResponse()

def pinterest_cae0b(request): 
    return render(request, 'roomhints/pinterest-cae0b.html')

def designer_styles(request):
    up = profuniq_to_prof(request.user.username)
    if request.user.is_authenticated() and up.designer == True:
        page = dict()
        page['title'] = title
        page['page'] = "designer_styles"
        page['is_designer'] = up.designer
        return render(request, 'roomhints/designer_styles.html', { "page":page} )
    else:
        return HttpResponse()

def profile_paid(up):
    if up.stripe_id != None and up.stripe_id != "":
        # This customer has paid before. Check if his last payment expired
        # charges_all = stripe.Charge.all(customer=up.stripe_id)
        # if charges_all['count'] > 0:
        #     charge_last = charges_all['data'][0]
        #     seconds_created = charge_last['created']
        t = up.charge_seconds
        seconds_created = calendar.timegm(t.timetuple())
        paid_seconds_duration = paid_days * 24 * 60 * 60 # 1 day extra to be sure
        seconds_todatetime = datetime.fromtimestamp(seconds_created+paid_seconds_duration).replace(tzinfo=utc)
        seconds_now = datetime.utcnow().replace(tzinfo=utc)
        if seconds_todatetime > seconds_now:
            return True, seconds_todatetime
    return False, None

@csrf_exempt
def api_v3_pay_meta(request):
    if request.method == "GET":
        data = dict()
        price = stripe_price
        data['publishable_key'] = stripe_publishable_key
        data['price'] = price * 100 # in cents
        data['currency'] = "usd"
        data['message'] = "You can get unlimited style advice and personalized product hints from a designer for $" + str(price) + " per room."
        data['message_footer'] = "\nThe service is for one month (it's not a subscription). Similar design services cost $400-$2000 per room and need a designer at your home. RoomHints is faster and will save you as much or more in discounts."
        data['message_plan'] = "You can get unlimited style advice and personalized product hints from a designer for $" + str(price) + " per month."
        data['message_plan_footer'] = "\nThe service is for unlimited rooms, with a 7-day free trial. Similar design services cost $400-$2000 per room and need a designer at your home. RoomHints is faster and will save you as much or more in discounts."
        data['message_plan_footer'] = "\nThe service is per room, prorated, and with a 7-day free trial. Similar design services cost $400-$2000 per room and need a designer at your home. RoomHints is faster and you can cancel at any time."
        data['paid'] = "no"
        profuniq = request.GET.get('profuniq','')
        projuniq = request.GET.get('projuniq','')
        up = profuniq_to_prof(profuniq)

        p = Project.objects.filter(projuniq=projuniq,public=True).get()
        paid_ret, paid_datetime = project_paid(p.id)
        #event_add(request,up,"pay_prompt")
        if paid_ret == True:
            until = str(paid_datetime.strftime("%A %d (%B %Y)"))
            if paid_ret == True:
                data['paid'] = "yes"
                data['message'] = "\n\nYou have a paid style help service for this room until " + until + "."
            else:
                data['paid'] = "no"
        else:
            # Expired
            data['paid'] = "no"

        ret = json.dumps(data,sort_keys=True,indent=4)
        return HttpResponse(ret)
    else:
        return HttpResponse()

@csrf_exempt
def api_v3_pay_add(request):
    if request.method == "POST":
        try:
            data = dict()
            data['message'] = 'You now have priority service.\n\nThank you for using RoomHints.'
            data['message_long'] = "\nThank you for your purchase.\n\nOne of our interior designers will look at your room and send you personalized hints.\n\nYou will get a push notification when the hints are ready.\n\nPlease feel free to reach out at any time if you have questions."
            # set your secret key: remember to change this to your live secret key in production
            # see your keys here https://manage.stripe.com/account

            # get the credit card details submitted by the form
            profuniq = request.GET.get('profuniq','')
            projuniq = request.GET.get('projuniq','')
            token = request.GET.get('stripeToken','')
            plan = request.GET.get('plan','')

            customer_id = None
            up = profuniq_to_prof(profuniq)
            p = Project.objects.filter(profile_id=up.id,projuniq=projuniq,public=True).get()
            if up.stripe_id != None and up.stripe_id != "":
                # This customer is being charged again. Reuse his existing info
                # later
                #customer_id = get_stripe_customer_id(user)
                customer_id = up.stripe_id
            else:
                # create a Customer
                customer = None
                if plan == "basic":
                    customer = stripe.Customer.create(
                        card=token,
                        description=profuniq + ":" + str(up.id),
                        plan="basic20"
                        )
                    up.charge_plan = "basic"
                else:
                    customer = stripe.Customer.create(
                        card=token,
                        description=profuniq + ":" + str(up.id)
                        )

                customer_id = customer.id

                # save the customer ID in your database so you can use it later
                #save_stripe_customer_id(user, customer.id)
                up.stripe_id = customer.id
                up.save()

            # charge the Customer instead of the card
            charge = stripe.Charge.create(
                amount=stripe_price * 100, # in cents
                currency="usd",
                customer=customer_id
                )

            charge_seconds = datetime.fromtimestamp(charge['created']).replace(tzinfo=utc)
            # Charge per room, not per customer.
            p.charge_seconds = charge_seconds
            p.charge_amount = charge['amount'] / 100
            p.save()
            # Keep the latest in the customer profile
            up.charge_seconds = charge_seconds
            up.charge_amount = charge['amount'] / 100
            up.save()

            ret = json.dumps(data,sort_keys=True,indent=4)
            return HttpResponse(ret)

        except stripe.InvalidRequestError:
            return HttpResponse()

    else:
        return HttpResponse()

@csrf_exempt
def api_v3_pay_cancel(request):
    if request.method == "POST":
        try:
            data = dict()
            # get the credit card details submitted by the form
            profuniq = request.GET.get('profuniq','')
            content = request.GET.get('content','')
            plan = request.GET.get('plan','')

            if plan == "basic":
                up = profuniq_to_prof(profuniq)
                customer = stripe.Customer.retrieve(up.stripe_id)
                #customer.cancel_subscription(at_period_end=True)
                customer.cancel_subscription()
                up.charge_plan = None
                up.save()
                data['message'] = "Your monthly subscription has been cancelled."
                data['message_long'] = "We are sorry to see you go.\n\nThank you for the privilege of improving your space."
                data['cancelled'] = "yes"
                feedback_add(up,"CANCELLED:" + str(content))
            else:
                data['cancelled'] = "no"
                
            ret = json.dumps(data,sort_keys=True,indent=4)
            return HttpResponse(ret)

        except stripe.InvalidRequestError, e:
            f = open('/tmp/cancel', 'ab+')
            f.write(str(e) + "\n")
            f.close()
            return HttpResponse()
    else:
        return HttpResponse()

def event_add(request,up,meta):
    e = Event()
    e.prof = up
    e.seconds = datetime.utcnow().replace(tzinfo=utc)
    e.meta = meta
    e.ip = get_ip(request)
    e.save()

@csrf_exempt
def api_v4_event_view(request):
    if request.method == 'POST':
        profuniq = request.GET.get('profuniq','')
        meta = request.GET.get('meta','')
        up = profuniq_to_prof(profuniq)
        event_add(request,up,meta)
        return HttpResponse()

def brand_signup(request):
    if request.method == "GET":
        f = FrontPhoto.objects.order_by('?')[0] # random select
        front = dict()
        front['photo'] = f.photo_web.name
        page = dict()
        page['title'] = "Brand Signup"
        page['page'] = "brand_signup"
        return render(request, 'roomhints/brand_signup.html', {"front":front, "page":page} )
    else:
        return HttpResponseRedirect('/brand/signup')

def test(request):
    return render(request, 'roomhints/test.html')

def color(request):
    return render(request, 'roomhints/color.html')

@csrf_exempt
def url_to_price(request):
    if request.method == "POST":
        url = request.POST.get('url','')
        data = dict()
        data = url2price(url)
        ret = json.dumps(data,sort_keys=True,indent=4)
        return HttpResponse(ret)
    elif request.method == "GET":
        url = request.GET.get('url','')
        data = dict()
        data = url2price(url)
        ret = json.dumps(data,sort_keys=True,indent=4)
        return HttpResponse(ret)

@csrf_exempt
def ping(request):
    return HttpResponse()
