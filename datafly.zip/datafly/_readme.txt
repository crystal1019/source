Password for git@96.126.102.11 - `Bbw3SIJotWhE`

Main git repository:
$ cd projects
$ git clone ssh://git@96.126.102.11/home/git/datafly.git

Also clone Datafly Starter (our project tools) into `starter` subfolder:

$ cd /projects/datafly
$ git clone ssh://git@96.126.102.11/home/git/starter.git

Virtualenv:

$ cd projects/datafly
$ virtualenv venv
$ venv/bin/pip install -r server/requirements.txt

To start development web server:

$ cd www
$ ../venv/bin/python app.py

For deployment install Fabric:

$ sudo pip install fabric --upgrade

Deploy command (to 96.126.102.11, /home/datafly/datafly):

$ cd script
$ fab deploy:staging

Password for 96.126.102.11 - `PyF4www`

Check "Development with LESS" section here (open in your browser):
starter/docs/docs.html
