from django.contrib import admin
from django.contrib.auth.models import Group, User
from django.contrib.sites.models import Site
from django.utils.translation import ugettext_lazy as _

from nested_inlines.admin import NestedModelAdmin, NestedTabularInline, NestedStackedInline
from models import Category, Offer, OfferCategory, MetaField, OfferMeta,\
    PerSiteCategoryOption, PerSiteOfferOption, BankProfile,\
    BalanceTransfer, MetaFieldTooltip, \
    BankType, SiteBreakout, PerSiteCategoryMeta, PerSiteOfferMeta
from forms import OfferAdminForm
from helpers import duplicate_offer
from offers.helpers.metafield.models import OfferImport
from offers.tools.flatpages.models import Video


class OfferImportAdmin(admin.ModelAdmin):
    model = OfferImport
    readonly_fields = ('imported', 'failed', 'logs')
    list_display = ('__unicode__', 'imported', 'failed', 'date')

class OfferMetaInline(admin.TabularInline):
    model = OfferMeta
    verbose_name = _('meta')
    verbose_name_plural = _('meta')
    extra = 0
    readonly_fields  = ('expiry', 'next_value', 'load_next_value', 'logo', 'logo_mobile')
    template = 'admin/core/offermeta/edit_inline/tabular.html'
    inlines = ()

class MetaFieldTooltipInline(admin.StackedInline):
    model = MetaFieldTooltip
    verbose_name = _('tooltip')
    verbose_name_plural = _('tooltips')
    extra = 0

class BalanceTransferInline(admin.TabularInline):
    model = BalanceTransfer
    fk_name = 'no_transfer_from'
    extra = 0
    inlines = ()

    def formfield_for_foreignkey(self, db_field, request=None, **kwargs):
        field = super(BalanceTransferInline, self).formfield_for_foreignkey(db_field, request, **kwargs)
        if db_field.name == 'no_transfer_to':
            if request._obj_ is not None:
                field.queryset = field.queryset.filter(parent__name__endswith='Issuers')  
            else:
                field.queryset = field.queryset.none()
        return field

class BankTypeAdmin(admin.ModelAdmin):
    model = BankType
    
    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}

class BankProfileAdmin(admin.ModelAdmin):
    model = BankProfile
    filter_horizontal = ['available_in']
    list_display = ('__unicode__', 'issuer_category', 'type')
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        '''limit category list to those whose parent category ends with "Issuers"'''
        if db_field.name == "issuer":
            kwargs["queryset"] = Category.objects.filter(parent__name__endswith='Issuers')
        return super(BankProfileAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)

class BankProfileInline(admin.StackedInline):
    model = BankProfile
    filter_horizontal = ['available_in']
    verbose_name = _('Issuer Profile')
    verbose_name_plural = _('Issuer Profile (if this category is an Issuer)')
    extra = 0
    inlines = ()
    
class PerSiteCategoryMetaInline(NestedTabularInline):
    model = PerSiteCategoryMeta
    extra = 0
    verbose_name = _('Table Column')
    verbose_name_plural = _('Table Columns')

class PerSiteCategoryOptionInline(NestedStackedInline):
    model = PerSiteCategoryOption
    verbose_name = _('Available in')
    plural_name = _('per site options')
    filter_horizontal = ('meta_fields',)
    extra = 1
    inlines = (PerSiteCategoryMetaInline,)

class PerSiteOfferMetaInline(NestedTabularInline):
    model = PerSiteOfferMeta
    extra = 0
    verbose_name = _('Table Column')
    verbose_name_plural = _('Table Columns')

class PerSiteOfferOptionInline(NestedStackedInline):
    model = PerSiteOfferOption
    verbose_name = _('Available in')
    plural_name = _('per site options')
    extra = 1
    inlines = (PerSiteOfferMetaInline,)

class MetaFieldAdmin(admin.ModelAdmin):
    list_display = ('key', 'default', 'is_sortable', 'prefix', 'suffix')
    search_fields = ('key',)
    inlines = (MetaFieldTooltipInline,)
    
class OfferCategoryInline(admin.TabularInline):
    model = OfferCategory
    extra = 0
    exclude = ('sort_order',)
    inlines = ()
    
class OfferCategoryInline2(OfferCategoryInline):
    ordering = ('-sort_order', 'offer__slug')
    inlines = ()
    verbose_name_plural = 'Offer List (offers assigned in this category)'
    
class SiteBreakoutInline(admin.TabularInline):
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        '''limit site list to those added to the offer to avoid 404 offer page'''
        if db_field.name == "site":
            offer_id = request.META['PATH_INFO'].strip('/').split('/')[-1]
            try:
                kwargs["queryset"] = Offer.objects.get(id=offer_id).sites.all()
            except ValueError: # when adding offers, offer_id = 'add'
                kwargs["queryset"] = Site.objects.filter(id=0)
        return super(SiteBreakoutInline, self).formfield_for_foreignkey(db_field, request, **kwargs)
    model = SiteBreakout
    exclude = ('promote_counter',)
    extra = 0
    inlines = ()
    
class VideoInline(admin.TabularInline):
    model = getattr(Video.categories, 'through')
    verbose_name = 'Video'
    verbose_name_plural = 'Videos'
    extra = 0
    inlines = ()

class OfferAdmin(NestedModelAdmin):
    form = OfferAdminForm
    save_on_top = True
    inlines = (OfferCategoryInline, OfferMetaInline, SiteBreakoutInline, PerSiteOfferOptionInline)
    # actions = ['publish']
    prepopulated_fields = {'slug': ('title',)}
    search_fields = ['title', 'slug']
    filter_horizontal = ['sites', 'categories']
    list_filter = ['sites', 'categories', 'is_active', 'last_modification_date']
    list_display = ['title', 'id',
                    'is_active', 'reviews', 'last_modification_date', 'outbound_url']
    fieldsets = (
            (None, {
                'fields': ('title', 'slug', 'bt_fallback', 'slider')
            }),
            ('Upload Image', {
                'classes': ('collapse',),
                'fields': ('image', 'tiny_image', 'large_image')
            }),
            ('Display Options', {
                #'classes': ('collapse',),
                'fields': (('is_active', 'show_lightbox', 'can_be_reviewed', 'show_outbound_message', 'is_toplevel_offer', 'is_exclusive', 'new_on'),)
            }),
        )
    
    class Media:
        js = ['js/jquery-1.3.2.min.js', 'js/countable.js', 'js/admin/counter.js']
        
    duplicate_offer.short_description = "Duplicate selected offers"
    actions = [duplicate_offer]
    
    def reviews(self, obj):
        return obj.cardreview_set.count() or ''
    
    def outbound_url(self, obj):
        if obj.outbound_url:
            return '%s...%s' % (obj.outbound_url[:25], obj.outbound_url[-25:])
        return ''

class OfferMetaAdmin(admin.ModelAdmin):
    list_display = ['offer', 'meta_field', 'value', 'expiry', 'date_changed', 'next_value', 'load_next_value']
    search_fields = ['offer__title',]
    
    def queryset(self, request):
        return OfferMeta.objects.all()
    
    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}

class CategoryAdmin(NestedModelAdmin):
    save_on_top = True
    prepopulated_fields = {'slug': ('name',)}
    filter_horizontal = ['sites',]
    list_filter = ['sites', 'is_visible', 'parent', 'last_modification_date']
    list_display = ['name', 'parent', 'is_visible', 'last_modification_date']
    search_fields = ['name', 'slug']
    inlines = (BankProfileInline, BalanceTransferInline, PerSiteCategoryOptionInline, OfferCategoryInline2, VideoInline)
    fieldsets = (
            (None, {
                'fields': ('name', 'slug', 'parent',)
            }),
            ('Display Options', {
                #'classes': ('collapse',),
                'fields': (('is_visible', 'slider', 'hero', 'hero_mobile'),)
            }),
        )
    class Media:
        js = ['js/jquery-1.3.2.min.js', 'js/countable.js', 'js/admin/counter.js']
        
    def get_form(self, request, obj=None, **kwargs):
        # just save obj reference for future processing in Inline
        request._obj_ = obj
        return super(CategoryAdmin, self).get_form(request, obj, **kwargs)
    



admin.site.unregister(Group)
admin.site.unregister(User)
admin.site.register(BankType, BankTypeAdmin)
admin.site.register(BankProfile, BankProfileAdmin)
admin.site.register(Offer, OfferAdmin)
admin.site.register(OfferMeta, OfferMetaAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(MetaField, MetaFieldAdmin)
admin.site.register(OfferImport, OfferImportAdmin)
