from django.core import serializers
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views.decorators.cache import cache_page
from models import Location


def cpi(request):
    if request.is_ajax():
        locations = Location.objects.filter(batch=request.GET['category']).order_by('date')
        return HttpResponse(serializers.serialize("json", locations))
    categories = Location.objects.exclude(batch__in=('personal tax', 'deleted', 'All Groups')
                                ).values('batch').distinct()
    return render_to_response('datagovau/cpi.html', {'categories': categories}, RequestContext(request))


@cache_page(60*60)
def wage(request):
    data = []
    for year in range(2000, 2012):
        data.append({'year': year, 'points': Location.objects.filter(batch='personal tax', date__year=year).exclude(lat=None)})
    return render_to_response('datagovau/wage.html', {'all_data': data}, RequestContext(request))
