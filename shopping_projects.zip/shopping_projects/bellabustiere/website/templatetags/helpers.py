"""Default variable filters."""

import re

try:
    from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
except ImportError:
    from django.utils._decimal import Decimal, InvalidOperation, ROUND_HALF_UP

import random as random_module
try:
    from functools import wraps
except ImportError:
    from django.utils.functional import wraps  # Python 2.3, 2.4 fallback.

from django.template import Variable, Library
from django.conf import settings
from django.utils.translation import ugettext, ungettext
from django.utils.encoding import force_unicode, iri_to_uri
from django.utils.safestring import mark_safe, SafeData
from django.utils.text import truncate_html_words
from bellabustiere.shop.models import *

register = Library()

def inlist(value, arg):
    if not value:
        return False
    return bool(value.count(arg) > 0)

register.filter(inlist)
def islast(value, arg):
    if not value:
        return False
    return bool(value[len(value)-1] == arg)

register.filter(islast)


def url_target_blank(text):
    return text.replace('<a ', '<a target="_blank" ')
register.filter(url_target_blank)

def my_truncatewords_html(s,num):
    return truncate_html_words(s,num,end_text="... <span class='orange'>Read More ></span>")
register.filter(my_truncatewords_html)



def get_normal_price(product, wholesale):
    return product.getNormalPrice(wholesale=wholesale)

register.filter(get_normal_price)

def get_total_normal_price(productorder, wholesale):
    return productorder.getTotalNormalPrice(wholesale=wholesale)
register.filter(get_total_normal_price)
