class Card:
    purchase_rate = 0.1999
    annual_fee = 150
    transfer_rate = 0.1999
    transfer_period = 6
    monthly_repay_rate = 0.02
    
    current_pb = 0
    current_period = 0
    
    table_stats = []
    
    def __init__(self, current_tb):
        self.current_tb = current_tb
        
        
    def go_next(self, previous_expense):
        table_row = [self.current_period, self.current_pb, self.current_pb*self.purchase_rate/12, \
                self.current_tb, (self.current_tb*self.transfer_rate/12 if self.current_period else 0),]
        
        current_pb = self.current_pb + previous_expense + self.current_pb*self.purchase_rate/12
        current_tb = self.current_tb + (self.current_tb*self.transfer_rate/12 if self.current_period else 0)
        current_pb, current_tb = self.apply_repayment(current_pb, current_tb, previous_expense, table_row)
        
        self.table_stats.append(table_row)
        
        self.current_period += 1
        self.current_pb = current_pb
        self.current_tb = current_tb
        
               
    def apply_repayment(self, current_pb, current_tb, previous_expense, table_row):
        total_bill = self.current_pb + self.current_tb + previous_expense
        minimum_repayment = total_bill*self.monthly_repay_rate
        table_row.append(minimum_repayment)
        if self.current_period <= self.transfer_period and self.current_tb > 0:
            if self.current_period == self.transfer_period:
                current_pb += current_tb - minimum_repayment
                return current_pb, 0
            if current_tb >= minimum_repayment:
                return current_pb, current_tb - minimum_repayment
            elif current_tb < minimum_repayment:
                return current_pb - (minimum_repayment-current_tb), 0
        elif self.current_period > self.transfer_period:        
            return current_pb-minimum_repayment, 0
        
    def print_stats(self):
        for row in self.table_stats:
            print '\t'.join(str(col) for col in row)
            
    def get_total_expense(self):
        if self.table_stats:
            pass
        else:
            for period in range(12):
                self.go_next(1000)
        total_repayment = sum(row[-1] for row in self.table_stats)
        return self.current_pb + total_repayment + self.annual_fee

bal = Card(4000)
print bal.get_total_expense()
bal.print_stats()