from datetime import date, datetime
from django import forms
from offers.core.models import Offer


class RegistrationForm(forms.Form):
    """
    Form for registering a new user account.
    
    Validates that the requested username is not already in use, and
    requires the password to be entered twice to catch typos.
    
    Subclasses should feel free to add any additional validation they
    need, but should avoid defining a ``save()`` method -- the actual
    saving of collected user data is delegated to the active
    registration backend.
    
    """
    first_name = forms.CharField(max_length=61,error_messages={'required': 'First name is required.'}, widget=forms.TextInput(attrs = {'placeholder': 'Type your first name here'}))
    email = forms.EmailField(error_messages={'required': 'Email is required.'}, widget=forms.TextInput(attrs={'placeholder': 'Type your email address here'}), label="E-mail")
    offer = forms.CharField(widget=forms.TextInput(attrs = {'class': 'typeahead', 'placeholder': 'Start typing in the name of your credit card'}))
    terms = forms.BooleanField(initial=True, label='I agree with the Privacy Policy', error_messages={'required': 'You must agree to the terms and conditions.'})
    voucher = forms.BooleanField(required=False, initial=True, label='Give me a $50 voucher for wine from Naked Wines')
    
    def clean_offer(self):
        data = self.cleaned_data['offer']
        try:
            Offer.objects.get(title=data)
        except Offer.DoesNotExist:
            raise forms.ValidationError('Please select your card from the list.')
        return data
    
    def clean_date(self, date_value):
        if date_value > date.today():
            return date_value
        raise forms.ValidationError('Please enter a future date.')
    
class RegistrationFormDesktop(RegistrationForm):
    duedate = forms.DateField(initial='01-01-2000', widget=forms.DateInput(attrs={'readonly': ''}))
    expiry = forms.DateField(initial='01-01-2000', widget=forms.DateInput(attrs={'readonly': ''}))
    
    def clean_duedate(self):
        return self.clean_date(self.get_duedate())
    
    def clean_expiry(self):
        return self.clean_date(self.get_expirydate())
    
    def get_duedate(self):
        return self.cleaned_data['duedate']
    
    def get_expirydate(self):
        return self.cleaned_data['expiry']

class RegistrationFormMobile(RegistrationForm):
    issuer = forms.CharField(required=False)
    dueday = forms.ChoiceField()
    duemonth = forms.ChoiceField()
    dueyear = forms.ChoiceField()
    expiryday = forms.ChoiceField()
    expirymonth = forms.ChoiceField()
    expiryyear = forms.ChoiceField()
    
    def __init__(self, *args, **kwargs):
        def create_choices(*args):
            choice_range = range(*args)
            return zip(choice_range, choice_range)
        super(RegistrationFormMobile, self).__init__(*args, **kwargs)

        year_now = date.today().year
        self.fields['dueday'].choices = self.fields['expiryday'].choices = create_choices(1, 31+1)
        self.fields['duemonth'].choices = self.fields['expirymonth'].choices = create_choices(1, 12+1)
        self.fields['dueyear'].choices = self.fields['expiryyear'].choices = create_choices(year_now, year_now+5)
        
    def clean_dueyear(self):
        return self.clean_date(self.get_duedate())
    
    def clean_expiryyear(self):
        return self.clean_date(self.get_expirydate())
        
    def get_duedate(self):
        try:
            duedate = '%s-%s-%s' % (self.data['dueyear'], self.data['duemonth'], self.data['dueday'])
        except KeyError:
            return '01-01-2000'
        return datetime.strptime(duedate, '%Y-%m-%d').date()    
    
    def get_expirydate(self):
        try:
            expirydate = '%s-%s-%s' % (self.data['expiryyear'], self.data['expirymonth'], self.data['expiryday'])
        except KeyError:
            return '01-01-2000'
        return datetime.strptime(expirydate, '%Y-%m-%d').date()
