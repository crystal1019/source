from app import db

# Campaign class
# class Campaign(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     key = db.Column(db.String(80))
#     name = db.Column(db.String(100))
#     spent = db.Column(db.Float)
#     sold = db.Column(db.Integer)
#     margin = db.Column(db.Float)
#     CPA = db.Column(db.Float)
#     URL = spent = db.Column(db.String(120))
#     enddate = db.Column(db.DateTime)
#     status = db.Column(db.String(80))

#     def __init__(self, key, name, spent, sold, margin, CPA, URL, enddate, status):
#         self.key = key
#         self.name = name
#         self.spent = spent
#         self.sold = sold
#         self.margin = margin
#         self.CPA = CPA
#         self.URL = URL
#         self.enddate = enddate
#         self.status = status

#     def __repr__(self):
#         return '<Name %r>' % self.name