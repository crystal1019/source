from django.conf.urls import patterns, url


urlpatterns = patterns('offers.tools.datagovau.views',
    url(r'^cost-of-living-heatmap/$', 'cpi', name='cpi'),
    url(r'^mean-taxable-income-heatmap/$', 'wage', name='wage'),
)
