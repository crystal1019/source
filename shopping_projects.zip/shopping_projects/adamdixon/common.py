from adamdixon.website.models import *
from django.conf import settings

def commondict(d, request):
    url_collection = MiscPage.objects.get_landing_url('collections')
    url_bio = MiscPage.objects.get_landing_url('bio')
    url_contact = MiscPage.objects.get_landing_url('contact')
    
    try:
        sitemeta = SiteMeta.objects.get(site__id=settings.SITE_ID)
    except:
        sitemeta = ''
    data = {
        'url_collection':url_collection,
        'url_bio':url_bio,
        'url_contact':url_contact,
        
        'site_meta':sitemeta,
            
    }
    
    data.update(d)
    
    return data