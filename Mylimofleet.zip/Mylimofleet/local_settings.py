
DEBUG = True

# Make these unique, and don't share it with anybody.
SECRET_KEY = "8c0d63c3-79fd-47d1-902e-aed5c15ee124261cd774-b68a-4a85-8887-1a901c97472e76a57001-84cb-4a84-a0dd-80628929cb36"
NEVERCACHE_KEY = "75d1675d-bf84-49c8-9f03-1f33d22f7780311f3d00-2650-4320-a50f-6b7c7e1060c34507280d-ae74-4708-b6d9-2a77cd18ffd3"

DATABASES = {
    "default": {
        # Ends with "postgresql_psycopg2", "mysql", "sqlite3" or "oracle".
        "ENGINE": "django.db.backends.sqlite3",
        # DB name or path to database file if using sqlite3.
        "NAME": "dev.db",
        # Not used with sqlite3.
        "USER": "",
        # Not used with sqlite3.
        "PASSWORD": "",
        # Set to empty string for localhost. Not used with sqlite3.
        "HOST": "",
        # Set to empty string for default. Not used with sqlite3.
        "PORT": "",
    }
}
