from django.db import models

from django.db.models.signals import post_save
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
import hashlib
import base64
from arktotalwealth.website.models import *

def encrypt_key(email):
    email = str(email)
    private_key = settings.PRIVATE_KEY
    msg = settings.PRIVATE_MESSAGE
    key_total = email+private_key+email
    dig = hashlib.sha256(key_total).hexdigest()
    public_key=base64.b64encode(dig)
    return public_key

# Create your models here.
class SubscriptionGroup(models.Model):
    name = models.CharField(max_length=255,unique=True)
    def __unicode__(self):
        return self.name

class Subscription(models.Model):
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=50, null=True)
    surname = models.CharField(max_length=50,null=True)
    phone = models.CharField(max_length=20,blank=True,null=True)
    interest = models.ManyToManyField(Interest, null=True)
    comment = models.TextField(blank=True,null=True)
    subscribed = models.DateTimeField(auto_now_add=True)
    ip = models.CharField(max_length=20, null=True, blank=True,editable=False)
    group = models.ForeignKey(SubscriptionGroup,blank=True,null=True)
    stamp = models.DateTimeField(auto_now_add=True)
    
 
    def __unicode__(self):
        return self.email
    
    def email_not_read(self):
        emails = self.emailstatus_set.filter(read=False)
        return ','.join([x.email.title for x in emails])
    
    def get_xmlstring(self):
        return '''<person>
                    <email-address>%s</email-address>
                    <first-name>%s</first-name>
                    <last-name>%s</last-name>
                    <phone-number>%s</phone-number>
                </person>'''%(self.email, self.first_name, self.surname,self.phone)
    
    class Meta:
        ordering = ('email',)
        
        
class Email(models.Model):
    title = models.CharField(max_length=255,unique=True)
    created = models.DateTimeField(auto_now_add=True)
    content = models.TextField()
    publish = models.DateTimeField(editable=False,blank=True,null=True)
    send = models.BooleanField(default=False,editable=False)
    def __unicode__(self):
        return self.title
    
    def send_already(self):
        return True if self.send else False
    
    def view_email(self):
        return "<a href='/admin/emails/email/%s/viewemail/'>view email</a>" % self.id
    
    view_email.allow_tags = True
    
    def read_percentage(self):
        all = self.emailstatus_set.all()
        all = len(all)
        read = self.emailstatus_set.filter(read=True)
        read = len(read)
        return '%s/%s (%s' %(read,all, round(float(float(read)/float(all)*100),2) if all != 0 else 0)  + '%)'
    
    def not_read_percentage(self):
        all = self.emailstatus_set.all()
        all = len(all)
        notread = self.emailstatus_set.filter(read=False)
        notread = len(notread)
        return '%s/%s' %(notread,all) 
        from django.db.models import *
    def sendmail(self,subscribe=''):
        domain = settings.DOMAIN
        if subscribe == '':
            subscribe = Subscription.objects.all()
        for x in subscribe:
            try:
                content = "%s <br /> <a href='http://%s/unsubscribe?email=%s&csrf=%s'>Unsubscribe</a><br /><img src='http://%s/reademail?id=%s&email=%s' width='1' height='1' />" %(self.content,domain,x.id,encrypt_key(x.id), domain, x.id, self.id)
                email = EmailMultiAlternatives(self.title , content, 'info@arktotalwealth.com.au', [x.email])
                email.attach_alternative(content, "text/html")
                email.send()
                es = x.emailstatus_set.filter(email = self)
                if not es:
                    es = EmailStatus()
                    es.email = self
                    es.subscribe = x
                    es.save()
            except:
                pass
                
            
class EmailStatus(models.Model):
    email = models.ForeignKey(Email)
    subscribe = models.ForeignKey(Subscription)
    read = models.BooleanField(default=False,editable=False)
    def __unicode__(self):
        return self.email.title
    

