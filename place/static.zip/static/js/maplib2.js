/*
    Requirements: underscore.js

*/

google.maps.visualRefresh = true;

/*************************
 *                        *
 *    Base Layer Class    *
 *                        *
 **************************/


function GLayer(gmap, options) {

    this.gmap = gmap;
    this.geomtype = null;
    if(google.maps.hasOwnProperty('drawing')){
        this._overlay_types = {
            "point": google.maps.drawing.OverlayType.MARKER,
            "polyline": google.maps.drawing.OverlayType.POLYLINE,
            "polygon": google.maps.drawing.OverlayType.POLYGON
        };
    }


    this.clickable = false;
    this.features = [];
    this._edit_feature = null;
    this.selected_feature = null;
    this.notification_zones = [];

    this.edit_stack = [];
    this.drawingManager = null;
    this.is_drawing = false;
    this.input_map = false;

    this.topic_icons = {
        'government': new google.maps.MarkerImage('/static/img/marker_govt.png'),
        'private': new google.maps.MarkerImage('/static/img/marker_private.png'),
        'community': new google.maps.MarkerImage('/static/img/marker_community.png'),
        'agency': new google.maps.MarkerImage('/static/img/marker_agency.png'),
        'government-seed': new google.maps.MarkerImage('/static/img/marker_govt_seed.png')
    };
    this.topic_icon_shadow = new google.maps.MarkerImage("/static/img/marker_shadow.png",
        new google.maps.Size(38.0, 34.0),
        new google.maps.Point(0, 0),
        new google.maps.Point(10.0, 34.0)
    );
    this.colors = [
        "#27a4ba",  // teal
        "#C23387",  // purple
        "#CEDE4F",  // green
        "#FF9E69"   // orange
    ];

    _.extend(this, options);
}

// Add events capability
MicroEvent.mixin(GLayer);
GLayer.prototype.constructor = GLayer;

// Editing actions
GLayer.CLEAN = 0;
GLayer.ADD = 1;
GLayer.MODIFIED = 2;
GLayer.DELETED = 3;

GLayer.prototype._events = [];

GLayer.prototype._bindEditEvents = function(feature) {
    var self = this;
    var is_dirty = function() {
        self.addToEditStack(feature, GLayer.MODIFIED);
    };
    google.maps.event.addListener(feature, "dragend", is_dirty);
    var paths = feature.getPaths();
    for (var i = 0; i < paths.length; i++) {
        this._events.push(google.maps.event.addListener(feature.getPath(), "insert_at", is_dirty));
        this._events.push(google.maps.event.addListener(feature.getPath(), "remove_at", is_dirty));
        this._events.push(google.maps.event.addListener(feature.getPath(), "set_at", is_dirty));
    }
};

GLayer.prototype.addPlace = function(place){
    var classes = [
        'teal-place',
        'purple-place',
        'green-place',
        'orange-place'
    ];
    var classes_length = 4;
    var idx = 0;
    var n = place.index;
    while (n--) {
        if ( idx >= classes_length - 1 ) {
            idx = 0;
        }
        else{
            idx++;
        }
    }
    var place_marker = new RichMarker({
        position: new google.maps.LatLng(place.coords[0], place.coords[1]),
        map     : this.gmap.map,
        shadow  : 'transparent',
        anchor  : RichMarkerPosition.MIDDLE,
        content : '<span class="place ' + classes[idx] + '">' + place.index + '</span>'
    });
    this.features.push(place_marker);
}

GLayer.prototype.addNotificationZone = function(radius, place) {
    // Sort out which color to use.
    var color_length = 4;
    var idx = 0;
    var n = place.index;
    while (n--) {
        if ( idx >= color_length ) {
            idx = 0;
        }
        else{
            idx++;
        }
    }
    var buffer = new google.maps.Circle({
        "center"      : new google.maps.LatLng(place.coords[0], place.coords[1]),
        "radius"      : radius,
        "fillColor"   : this.colors[idx],
        "fillOpacity" : 0.3,
        "strokeWeight": 0,
        "editable"    : false,
        "map"         : this.gmap.map
    });
    this.notification_zones.push(buffer);
    return buffer;
};

GLayer.prototype.loadParticipants = function(participants) {
    var self = this;
    for (var i = 0, len = participants.length; i < len; i++) {
        var user_marker = new google.maps.Marker({
            position: new google.maps.LatLng(participants[i].coords.lat, participants[i].coords.lng),
            map: self.gmap.map,
            icon: new google.maps.MarkerImage('/static/img/green_dot.png'),
            clickable: false
        });
    }
};

GLayer.prototype.loadSeedMarker = function(point) {
    var self = this;
    var seed_marker = new google.maps.Marker({
        position: new google.maps.LatLng(point.lat, point.lng),
        map: self.gmap.map,
        icon: new google.maps.MarkerImage('/static/img/marker_govt_seed.png'),
        clickable: false
    });
};

GLayer.prototype.startEditing = function() {
    this.drawingManager = this.drawingManager || new google.maps.drawing.DrawingManager({
        map: this.gmap.map,
        drawingControl: false,
        drawingMode: null
    });
    var self = this;
    for (var i = 0; i < this.features.length; i++) {
        var ft = this.features[i];
        ft.setOptions({
            clickable: true
        });
        this._events.push(google.maps.event.addListener(ft, 'click', (function(ft) {
            return function(event) {
                self._click_handler(ft, event.latLng);
            };
        })(ft)));
        this._bindEditEvents(ft);
    }
};

GLayer.prototype._click_handler = function(ft) {
    if (this._edit_feature == ft) {
        ft.setEditable(false);
        this._edit_feature = null;
    } else {
        if (this._edit_feature) {
            this._edit_feature.setEditable(false);
        }
        ft.setEditable(true);
        this._edit_feature = ft;
    }
    this.trigger('featureclicked', this._edit_feature);
};

GLayer.prototype.stopEditing = function() {
    for (var i = 0; i < this.features.length; i++) {
        var ft = this.features[i];
        ft.setEditable(false);
        google.maps.event.clearListeners(ft, 'click');
    }
    // Stop the editing of the current feature being edited.
    if (this._edit_feature) {
        this._edit_feature.setEditable(false);
    }

    // Clear events
    for (var x = this._events.length - 1; x >= 0; x--) {
        var evt = this._events[x];
        google.maps.event.removeListener(evt);
    }
};

GLayer.prototype.setClickable = function(is_clickable) {
    for (var i = 0; i < this.features.length; i++) {
        this.features[i].setOptions({
            clickable: is_clickable
        });
    }
};

GLayer.prototype.deleteFeature = function(feature) {
    feature.setMap(null);

    this.selected_feature = null;
    this._edit_feature = null;
    this.addToEditStack(feature, GLayer.DELETED);
};

GLayer.prototype.deleteAllFeatures = function() {
    this.selected_feature = null;
    this._edit_feature = null;

    // Reset stack since all features are being wiped
    this.edit_stack = [];
    for (var i = this.features.length - 1; i >= 0; i--) {
        var ft = this.features[i];
        ft.setMap(null);
        this.addToEditStack(ft, GLayer.DELETED);
    }
};

GLayer.prototype.enableDrawing = function(feature) {
    this.is_drawing = true;
};

GLayer.prototype.disableDrawing = function() {
    this.is_drawing = false;
};

GLayer.prototype.setStyle = function() {};

GLayer.prototype.getStyle = function() {};

GLayer.prototype.getUpdates = function() {
    var updates = [];
    for (var i = 0, len = this.features.length; i < len; i++) {
        var feature = this.features[i];
        if (feature.action != GLayer.CLEAN) {
            updates.push(feature);
        }
    }
    return updates;
};

GLayer.prototype.addToEditStack = function(feature, action, trigger_event) {
    if (_.isUndefined(trigger_event)) {
        trigger_event = true;
    }

    if (!action) return;

    if (action == GLayer.ADD) {
        feature.action = GLayer.ADD;
        this.edit_stack.push(feature);
    } else if (action == GLayer.MODIFIED) {
        // Only need to add a modified feature once to the stack.
        if (!feature.action) { // Not defined or clean
            feature.action = GLayer.MODIFIED;
            this.edit_stack.push(feature);
        }
    } else if (action == GLayer.DELETED) {
        // Clean out any other entries of this feature
        // in the stack.
        this.edit_stack = _.reject(this.edit_stack, function(ft) {
            return ft == feature;
        });
        this.features = _.reject(this.features, function(ft) {
            return ft == feature;
        });
        if (feature.action !== GLayer.ADD) {
            feature.action = GLayer.DELETED;
            this.edit_stack.push(feature);
        }
    }
    if (trigger_event) {
        this.trigger('featureedited', feature, action);
    }
};

GLayer.prototype.clearStack = function() {

    // Reset feature action to clean.
    for (var i = 0; i < this.edit_stack.length; i++) {
        this.edit_stack[i].action = GLayer.CLEAN;
    }
    this.edit_stack = [];
};

GLayer.prototype.setGMap = function(gmap) {
    this.gmap = gmap;
    for (var i = this.features.length - 1; i >= 0; i--) {
        // Don't want to draw deleted polygon
        if (this.features[i].action != GLayer.DELETED) {
            this.features[i].setMap(this.gmap.map);
        }
    }

    if (this.drawingManager) {
        this.drawingManager.setMap(this.gmap.map);
    }
};

GLayer.prototype.addTopics = function(topics) {

    for(var i = 0, len = topics.length; i < len; i ++){
        var topic = topics[i];
        var icon;
        if (topic.plan_code === 'seed') {
            topic.category = topic.category + '-seed';
        }

        var topic_marker = new google.maps.Marker({
            position: new google.maps.LatLng(topic.coords[0], topic.coords[1]),
            map     : this.gmap.map,
            icon: this.topic_icons.hasOwnProperty(topic.category) ? this.topic_icons[topic.category] : null,
            shadow  : this.topic_icon_shadow,
            clickable: true
        });

        topic_marker.setValues({'category': topic.category, 'topic':topic});

        this.features.push(topic_marker);
        var self = this;
        google.maps.event.addListener(topic_marker, 'click', function(){
            marker = this;
            // Close all info bubbles that are open.
            for (var n=0, tp_cnt=self.features.length; n < tp_cnt; n++){
                var tp = self.features[n];
                if (tp.info){
                    tp.info.close();
                }
            }

            // Check if marker has an infobubble,
            // if not create one and then open it.
            if (!marker.hasOwnProperty('info')){
                $.ajax({
                    url: '/topics/topic_card/',
                    type: 'get',
                    data: {
                        topic: marker.topic.id,
                        is_map: true
                    },
                    dataType: 'html',
                    success: function(html) {
                        var info = new InfoBubble({
                            maxWidth           : 220,
                            minHeight          : 230,
                            maxHeight          : 325,
                            content            : html,
                            padding            : 0,
                            shadowStyle        : 0,
                            closeButton        : '/static/img/infobubble-close-button.png',
                            backgroundClassName: 'infobubble-topic-box',
                            borderRadius       : 0
                        });
                        marker.setOptions({
                            "info": info
                        });
                        marker.info.open(self.gmap.map, marker);
                    },
                    error: function(err){

                    }
                });

            }
            else{
                if (!marker.info.isOpen()) {
                    marker.info.open(self.gmap.map, marker);
                }
            }
        });
    }
};

GLayer.prototype.fitLayer = function() {};

/****************************
 *                           *
 *    Polygon Layer Class    *
 *                           *
 *****************************/

function GPolygonLayer(gmap, options) {
    GLayer.call(this, gmap, options);

    this.geomtype = 'polygon';

    this.default_style = {
        strokeColor: "#000000",
        fillColor: "#D7191C",
        strokeWeight: 1,
        strokeOpacity: 0.75,
        fillOpacity: 0.5
    };

    // #FA6900
    // #69D2E7
    // #E94C6F
    // #542733
    // #E8B71A
    // #1FDA9A
    // #1FDA9A
    // #D0C91F


    this.fill_colors = [
        '#D7191C',
        '#F4A582',
        '#92C5DE',
        '#0571B0',
        '#7B3294',
        '#C2A5CF',
        '#A6DBA0',
        '#008837',
        '#A6611A',
        '#DFC27D',
        '#4DAC26',
        '#FB9A99',
        '#FF7F00',
        '#E5D8BD',
        '#A65628',
        '#F781BF',
        '#D4D800',
        '#00689C',
        '#F781BF',
        '#C1073F',
        '#350050',
        '#4F250C',
        '#AD4900',
        '#FFF37A',
        '#82783D'
    ];

    this._get_random_style = function() {
        var idx = Math.floor(Math.random() * this.fill_colors.length);
        var style = _.extend({}, this.default_style);
        style.fillColor = this.fill_colors[idx];
        return style;
    };
    this.is_being_dragged = false;
    var self = this;
}

GPolygonLayer.prototype.constructor = GPolygonLayer;
GPolygonLayer.prototype = new GLayer();

GPolygonLayer.prototype.stopEditing = function() {
    GLayer.prototype.stopEditing.call(this);
    this.disableDrawing();
};

GPolygonLayer.prototype.enableDrawing = function() {
    if (this.is_drawing) return;
    GLayer.prototype.enableDrawing.call(this);
    var self = this;
    this.drawingManager.setDrawingMode(google.maps.drawing.OverlayType.POLYGON);
    // Handles create new polygons
    google.maps.event.addListener(this.drawingManager, 'polygoncomplete', function(polygon) {
        var style = self._get_random_style('polygon');
        polygon.setOptions(style);

        polygon.setValues({
            label: 'No Label',
            gid: null,
            feature_type: self.geomtype
        });
        polygon._ps_id = '_' + self.features.length.toString();

        self._events.push(google.maps.event.addListener(polygon, 'click', function() {
            self._click_handler(polygon);
        }));
        self.features.push(polygon);
        if (self._edit_feature) {
            self._edit_feature.setEditable(false);
        }
        if (self.input_map) {
            var ps_object = {
                name: "Polygon " + self.features.length,
                description: ""
            };
            polygon.ps_object = ps_object;
            polygon.ps_object_clean = angular.copy(ps_object);
        }
        polygon.center_marker = self.getFeatureCenter(polygon);
        polygon.setEditable(true);
        self._edit_feature = polygon;
        self.selected_feature = polygon;
        self._bindEditEvents(polygon);

        // Add to edit stack
        self.addToEditStack(polygon, GLayer.ADD);
        self.trigger('newpolygon', polygon);
    });
};

GPolygonLayer.prototype.disableDrawing = function() {
    GLayer.prototype.disableDrawing.call(this);
    // Remove events
    if (this.drawingManager) {
        google.maps.event.clearListeners(this.drawingManager, 'polygoncomplete');
        this.drawingManager.setDrawingMode(null);
    }
};

GPolygonLayer.prototype.getUpdates = function() {
    var ft;
    result = [];
    var encoder = google.maps.geometry.encoding;
    for (var i = 0; i < this.edit_stack.length; i++) {
        ft = this.edit_stack[i];
        console.log(ft)
        var rec = {
            'action': ft.action,
            'gid': ft.gid,
            '_ps_id': ft.__gm_id || ft._ps_id
        };
        if (ft.action !== GLayer.DELETED) {
            rec.label = ft.label;
            rec.style = {
                "strokeWeight": ft.get('strokeWeight'),
                "strokeColor": ft.get('strokeColor'),
                "fillColor": ft.get('fillColor'),
                "strokeOpacity": ft.get('strokeOpacity'),
                "fillOpacity": ft.get('fillOpacity')
            };
            rec.geom = [];
            var paths = ft.getPaths().getArray();
            for (var j = 0; j < paths.length; j++) {
                rec.geom.push(encoder.encodePath(paths[j]));
            }
            // Input Map Polygons
            if (ft.hasOwnProperty('ps_object')) {
                rec.name = ft.ps_object.name;
                rec.description = ft.ps_object.description;
            }
        }
        result.push(rec);
    }
    return result;
};

GPolygonLayer.prototype.getBounds = function() {
    var envelope = new google.maps.LatLngBounds();
    for (var i = this.features.length - 1; i >= 0; i--) {
        envelope.union(this.features[i].getBounds());
    }
    return envelope;
};

GPolygonLayer.prototype.fitLayer = function(trigger_boundschanged) {
    if(this.features.length > 0){
        var envelope = new google.maps.LatLngBounds();
        for (var i = this.features.length - 1; i >= 0; i--) {
            envelope.union(this.features[i].getBounds());
        }
        this.gmap.map.fitBounds(envelope);
        var self = this;
        if(angular.isDefined(trigger_boundschanged)){
            if(trigger_boundschanged){
                self.gmap.trigger('boundschanged', self.gmap);
            }
        }
    }
};

GPolygonLayer.prototype.getFeatureCenter = function(ft) {
    if (ft.center_marker) {
        return ft.center_marker
    };

    var bounds = ft.getBounds();
    var bounds_center = bounds.getCenter();
    var latlng = new google.maps.LatLng(bounds_center.lat(), bounds_center.lng());
    // Using a marker was the only way infowindow would change position properly
    var center_point = new google.maps.Marker({
        map: null,
        position: latlng,
        optimized: false
    });
    return center_point;
}

/*
    polygons: [
        {
            "id": polygon.id,
            "label": polygon.label,
            "style": polygon.style,
            "geom": [ [], [], [] ] // first array is exterior ring, geometries are encoded.
        },
        ...
    ],
    clickable:  is the polygon clickable
*/
GPolygonLayer.prototype.loadEncodedPolygons = function(polygons, clickable, is_import) {
    var gencoder = google.maps.geometry.encoding;
    var map = this.gmap.map;
    var new_polygons = is_import || false;
    var self = this;

    for (var i = 0; i < polygons.length; i++) {
        var paths = [];
        var polygon = polygons[i];
        if (angular.isArray(polygon.geom)) {
            for (var j = 0; j < polygon.geom.length; j++) {
                var ring = polygon.geom[j];
                paths.push(gencoder.decodePath(ring));
            }
        } else {
            var ring = polygon.geom;
            paths.push(gencoder.decodePath(ring));
        }

        // Apply properties
        var opts = polygon.style || this._get_random_style('polygon');
        opts.gid = polygon.gid || polygon.id;
        opts.action = GLayer.CLEAN;
        opts.label = polygon.label;
        opts.paths = paths;
        opts.clickable = (clickable) ? true : false;
        opts.feature_type = self.geomtype;
        if (self.input_map) {
            var ps_object = {
                name: polygon.name,
                description: polygon.description,
                id: polygon.id
            }
            if (new_polygons) {
                ps_object.name = (polygon.label != "No Label" ? polygon.label : "Polygon " + (self.features.length + 1))
            }
            opts.ps_object = ps_object;
            opts.ps_object_clean = angular.copy(ps_object);
        }

        var ft = new google.maps.Polygon(opts);
        if (!self.editable) {
            ft.ps_id = polygon.id;
            ft.name = polygon.name;
            ft.description = polygon.description;
            self._events.push(google.maps.event.addListener(ft, 'click', function(evt) {
                self.trigger('featureclicked', this);
            }));
        }
        ft.center_marker = self.getFeatureCenter(ft);

        this.features.push(ft);
        if (new_polygons) {
            ft._ps_id = "_" + i.toString();
            this.addToEditStack(ft, GLayer.ADD);
        }
        if (ft.action != GLayer.DELETED) {
            ft.setMap(map);
        }
    }
    if (new_polygons) {
        this.stopEditing();
        this.startEditing();
        this.trigger('newpolygon', polygon);
    }
};

GPolygonLayer.prototype.setClean = function() {
    var self = this;
    for (var i = 0, len = self.features.length; i < len; i++) {
        if (self.features[i].action !== GLayer.DELETED) {
            self.features[i].action = GLayer.CLEAN;
        }
    }
};

GPolygonLayer.prototype.redraw = function(polygons) {
    for (var i = 0, len = this.features.length; i < len; i++) {
        this.features[i].setMap(null);
    }
    this.features = [];
    this.loadEncodedPolygons(polygons, true, false);
};

function GMap2(id, options) {

    this.is_loaded = false;

    // Dataset types
    this.TOPIC_PINS = 0;
    this.TOPIC_POLYS = 1;
    this.USER_PINS = 2;
    this.PLACE_PINS = 3;
    this.NOTIFICATION_ZONES = 4;

    this.events = [];

    if(google.maps.hasOwnProperty('drawing')){
        this.OVERLAY_TYPES = {
            "point": google.maps.drawing.OverlayType.MARKER,
            "polyline": google.maps.drawing.OverlayType.POLYLINE,
            "polygon": google.maps.drawing.OverlayType.POLYGON
        };
    }

    // Element id
    this.id = id;

    // Default options
    this.default_options = {
        center: new google.maps.LatLng(49.277297, -123.147651),
        zoom: 8,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        mapTypeControl: false,
        panControl: false,
        draggable: true,
        zoomControl: true,
        streetViewControl: false,
        zoomControlOptions: {
            position: google.maps.ControlPosition.RIGHT_BOTTOM,
            style: google.maps.ZoomControlStyle.SMALL
        }
    };

    var opts = this.default_options;
    // Apply any options
    for (var option in options) {
        opts[option] = options[option];
    }

    this.map = new google.maps.Map(document.getElementById(this.id), opts);

    var self = this;
    google.maps.event.addListener(
        this.map,
        'bounds_changed',
        function() {
            self._restrictZoom(self);
        }
    );

    this.is_loaded = true;
}
GMap2.prototype.constructor = GMap2;

// Add events capability
MicroEvent.mixin(GMap2);

GMap2.prototype._restrictZoom = function(self) {
    // Things get wonky at zoom level 1 and
    // level 1 is a weird zoom level anyhow.
    if (self.map && self.map.getZoom() <= 1) {
        self.map.setZoom(2);
    }
    self.trigger('boundschanged', self);
};

/****************************
 *                           *
 *    GeoMark Layer Class    *
 *                           *
 *****************************/

function GeoMarkLayer(gmap, options) {
    GLayer.call(this, gmap, options);

    this.geomtype = 'point';
    this.marks = [];
    this.posts = [];
    this._events = [];
    this.is_adding_markers = false;
    this.marker_icon = {
        url: '/static/img/marker.png',
        size: new google.maps.Size(20, 34),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(10, 30)
    };
    this.comment_click_event = null;
    this.is_commenting = false;
    this.unsaved_marker = null;
    this.comment_clusterer = null;
    this.gmark_clusterer = null;
    this.unclustered_markers = [];
    this.my_comment_icon = {
        url: '/static/img/ico-comment-orange.png',
        size: new google.maps.Size(32, 32),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(8, 31)
    };
    this.comment_icon = {
        url: '/static/img/ico-comment-grey.png',
        size: new google.maps.Size(32, 32),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(8, 31)
    };
    _.extend(this, options);
}

GeoMarkLayer.prototype.constructor = GeoMarkLayer;
GeoMarkLayer.prototype = new GLayer();

GeoMarkLayer.prototype.redraw = function(geomarks) {
    for (var i = 0, len = this.marks.length; i < len; i++) {
        this.marks[i].setMap(null);
    }
    this.marks = [];
    this.loadGeoMarks(geomarks);
};

GeoMarkLayer.prototype.enableMarking = function() {
    var self = this;
    self.is_adding_markers = true;
    self._events.push(google.maps.event.addListener(self.gmap.map, 'click', function(evt) {
        self.createMarker(evt.latLng);
    }));
};

GeoMarkLayer.prototype.setGMap = function(gmap) {
    this.gmap = gmap;
    if (this.comment_clusterer !== null) {
        this.comment_clusterer.setMap(this.gmap.map);
    }
    if (this.gmark_clusterer !== null) {
        this.gmark_clusterer.setMap(this.gmap.map);
    } else {
        for (var i = 0, len = this.marks.length; i < len; i++) {
            this.marks[i].setMap(this.gmap.map);
        }
    }
    for (var x = 0, len = this.unclustered_markers.length; x < len; x++) {
        this.unclustered_markers[x].setMap(this.gmap.map);
    }
};

GeoMarkLayer.prototype.disableMarking = function() {
    this.is_adding_markers = false;
    for (var x = 0, len = this._events.length; x < len; x++) {
        google.maps.event.removeListener(this._events[x]);
    }
};

GeoMarkLayer.prototype.createMarker = function(position) {
    var self = this;

    var marker = new google.maps.Marker({
        map: self.gmap.map,
        position: position,
        draggable: true,
        icon: self.marker_icon,
        zIndex: 5
    });

    marker.ps_object = {
        name: "Marker " + (this.marks.length + 1),
        description: ""
    };
    self.unsaved_marker = marker;
    marker.creation = true;
    marker.ps_object_clean = angular.copy(marker.ps_object);
    marker.action = GLayer.ADD;
    marker.feature_type = this.geomtype;
    self._initListeners(marker);
    self.marks.push(marker);
    self.trigger("select_marker", marker);
};

GeoMarkLayer.prototype.loadGeoMarks = function(geomarks) {
    var self = this;

    for (var x = 0, len = geomarks.length; x < len; x++) {

        var marker = new google.maps.Marker({
            map: self.gmap.map,
            position: new google.maps.LatLng(geomarks[x].position.lat, geomarks[x].position.lng),
            draggable: self.draggable,
            icon: self.marker_icon,
            zIndex: 3
        });
        var i = this.marks.push(marker) - 1;

        if (!this.draggable) {
            this.marks[i].ps_id = geomarks[x].id;
            this.marks[i].name = geomarks[x].name;
            this.marks[i].description = geomarks[x].description;

        } else {
            this.marks[i].action = GLayer.CLEAN;
            this.marks[i].ps_object = geomarks[x];
            this.marks[i].ps_object_clean = angular.copy(geomarks[x]);
            this.marks[i].feature_type = this.geomtype;
        }
        this._initListeners(this.marks[i]);
    }
};

GeoMarkLayer.prototype.deleteAllMarkers = function() {
    var self = this;
    for (var i = 0, len = self.marks.length; i < len; i++) {
        if (self.marks[i].action == GLayer.ADD) {
            self.marks[i].action = GLayer.CLEAN;
        } else {
            self.marks[i].action = GLayer.DELETED;
        }
        self.marks[i].setMap(null);
    }
};

GeoMarkLayer.prototype.cluster = function(user_id) {
    this.comment_clusterer = new MarkerClusterer(this.gmap.map, this.posts, {
        styles: [{
            textColor: 'black',
            url: '/static/img/ico-multiple-grey.png',
            height: 52,
            width: 46
        }]
    });
    this.gmark_clusterer = new MarkerClusterer(this.gmap.map, this.marks, {
        styles: [{
            textColor: 'white',
            url: '/static/img/ico-multiple-markers.png',
            height: 38,
            width: 30
        }]
    });
    if (user_id !== null) {
        var self = this;
        google.maps.event.addListener(self.comment_clusterer, "redrawend", function(clusterer) {
            var clusters = clusterer.getClusters();
            for (var x = 0, len = clusters.length; x < len; x++) {
                var markers = clusters[x].getMarkers();
                var users_comments = _.find(markers, function(m) {
                    return (parseInt(m.ps_data.author.id) === user_id) && (markers.length > 1)
                });
                if (!_.isUndefined(users_comments)) {
                    clusters[x].clusterIcon_.url_ = '/static/img/ico-multiple-orange.png';
                }
            }
        });
    }
};

GeoMarkLayer.prototype.loadIMPosts = function(posts, user) {
    var self = this;
    var icon = new google.maps.MarkerImage('/static/img/Comment_32.png');
    for (var x = 0, len = posts.length; x < len; x++) {
        if (parseInt(posts[x].author.id) === user) {
            icon = self.my_comment_icon;
        } else {
            icon = self.comment_icon;
        }
        var post = new google.maps.Marker({
            map: self.gmap.map,
            position: new google.maps.LatLng(posts[x].location.lat, posts[x].location.lng),
            draggable: self.draggable,
            icon: icon,
            zIndex: 2
        });
        post.ps_data = posts[x];
        post.marker_type = 'comment';
        this.posts.push(post);
        self._initListeners(post);
    }
};

GeoMarkLayer.prototype.newIMPostMarker = function(latlng) {
    var self = this;

    var post = new google.maps.Marker({
        map: self.gmap.map,
        position: latlng,
        draggable: self.draggable,
        icon: self.my_comment_icon,
        draggable: true,
        zIndex: 2
    });
    post.creation = true;

    self.new_post_dragstart = google.maps.event.addListener(post, 'dragstart', function(evt) {
        self.trigger('comment_dragstart', evt.latLng);
    });
    self.new_post_dragend = google.maps.event.addListener(post, 'dragend', function(evt) {
        self.trigger('comment_dragend', evt.latLng);
    });
    self.unsaved_marker = post;
    self._initListeners(post);
    self.disableCommenting();
    self.trigger("select_marker", post);
};

GeoMarkLayer.prototype.getUpdates = function() {
    var gmark_edits = _.filter(this.marks, function(mark) {
        return mark.action !== GLayer.CLEAN;
    });
    var cleaned_edits = [];
    if (gmark_edits.length > 0) {
        for (var i = 0, len = gmark_edits.length; i < len; i++) {
            cleaned_edits.push({
                id: gmark_edits[i].ps_object.id || null,
                name: gmark_edits[i].ps_object_clean.name,
                description: gmark_edits[i].ps_object_clean.description,
                action: gmark_edits[i].action,
                position: {
                    lat: gmark_edits[i].getPosition().lat(),
                    lng: gmark_edits[i].getPosition().lng()
                }
            });
        }
    }
    return cleaned_edits;
};

GeoMarkLayer.prototype.removeUnsavedMarker = function() {
    if (this.unsaved_marker !== null) {
        this.unsaved_marker.setMap(null);
        this.unsaved_marker = null;
    }
};

GeoMarkLayer.prototype._initListeners = function(marker) {
    var self = this;
    google.maps.event.addListener(marker, 'click', function() {
        self.trigger("select_marker", this);
    });
    if (self.draggable) {
        google.maps.event.addListener(marker, "dragend", function(event) {
            self.trigger("marker_moved", marker);
        });
    }
};

GeoMarkLayer.prototype.setClickable = function(is_clickable) {
    for (var i = 0; i < this.marks.length; i++) {
        this.marks[i].setClickable(is_clickable)
    }
};

GeoMarkLayer.prototype.enableCommenting = function() {
    var self = this;
    self.is_commenting = true;
    self.gmap.map.setOptions({
        draggableCursor: 'url(/static/img/Comment_33.png) 8 31, auto'
    });
    self.comment_click_event = google.maps.event.addListener(self.gmap.map, 'click', function(evt) {
        self.newIMPostMarker(evt.latLng);
    });
};

GeoMarkLayer.prototype.disableCommenting = function() {
    this.is_commenting = false;
    google.maps.event.removeListener(this.comment_click_event);
    this.comment_click_event = null;
    this.gmap.map.setOptions({
        draggableCursor: undefined
    });

};

GeoMarkLayer.prototype.setClean = function() {
    for (var i = 0, len = this.marks.length; i < len; i++) {
        if (this.marks[i].action !== GLayer.DELETED) {
            this.marks[i].action = GLayer.CLEAN;
        }
    }
};

// Add events capability
MicroEvent.mixin(GeoMarkLayer);

/*
    Add getBounds function to google maps Polygon instances
    (was removed in google maps API v3)
*/

if (!google.maps.Polygon.prototype.getBounds) {
    google.maps.Polygon.prototype.getBounds = function() {
        var bounds = new google.maps.LatLngBounds();
        var paths = this.getPaths();
        var path;

        for (var p = 0; p < paths.getLength(); p++) {
            path = paths.getAt(p);
            for (var i = 0; i < path.getLength(); i++) {
                bounds.extend(path.getAt(i));
            }
        }
        return bounds;
    };
}