import objects
import masterpage

import method_db
import method_email
import method_url
	
class ReportDuplicate(masterpage.MasterPage):				  
		
	def post(self):			   
		primaryQuestion = self.request.get('primaryQuestion')
		secondaryQuestion = self.request.get('secondaryQuestion')
		try:
			dup = objects.DuplicateReport()
			dup.primary_question = int(primaryQuestion)
			dup.secondary_question = int(secondaryQuestion)
			id = method_db.putObject(dup)
			primary_url = '<a href="http://www.careercup.com/question?id="' + str(dup.primaryQuestion) + '">' + str(dup.primaryQuestion) + '</a>'
			secondary_url = '<a href="http://www.careercup.com/question?id="' + str(dup.secondaryQuestion) + '">' + str(dup.secondaryQuestion) + '</a>'
			method_email.sendMeEmail('', 'Duplicate Reported', 'Duplicate Reported with questions ' + primary_url + ' and ' + secondary_url) 
		except:
			pass	
		self.displayError('Thank You!', 'Thank you!  This dup will be looked at shortly by a moderator. <br/><br/> Wanna be a moderator?  Email gayle@careercup.com.')		


	def get(self):		  
		id = method_url.getId(self)
		template_values = {'id': id,
			'parent_tab': 'interviews',	}
		self.pushPage(template_values, 'Report Duplicate', 'html/reportduplicate.html')   
		
