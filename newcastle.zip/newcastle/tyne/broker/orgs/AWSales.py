'''
Created on Sep 7, 2014

@author: apptworks
'''

from tyne.broker.orgs.OrgCommon import OrgCommon

BOOKED_SERVER_URL = 'https://sales.appointment.works'
#BOOKED_SERVER_URL = 'http://localhost'

#blank or end with /
BOOKED_ORG_NAME = ''

BOOKED_USER = 'secret_admin'
BOOKED_PASSWORD = 'se08$$05cheeduh'


class AWDemo(OrgCommon):
	def __init__(self):
		super().__init__(BOOKED_SERVER_URL, BOOKED_ORG_NAME, BOOKED_USER, BOOKED_PASSWORD)