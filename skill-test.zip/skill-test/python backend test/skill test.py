print "Input:"
data = raw_input()
lint, lalph, lnew, c, d   = [],[],[],0,0
for i in data.split():
    if ord(i[0]) >96 and  ord(i[0]) < 123:
        lalph.append(i)
    else:
        lint.append(int(i))
lalph.sort()
lint.sort()
for i in data.split():
    if ord(i[0]) >96 and  ord(i[0]) < 123:
        lnew.append(lalph[c])
        c+=1
    else:
        lnew.append(lint[d])
        d+=1
print "Output:"
print (" ".join(map(str, (lnew))))