from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from datetime import datetime, timedelta
from django.utils.timezone import utc

from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend
from roomhints.models import Profile
from roomhints.models import ProjectImpression
from roomhints.models import ProjectImpression
from roomhints.models import RoomHintImpression
from roomhints.utils import search_profile_id

class Command(BaseCommand):
    args = '<poll_id poll_id ...>'
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        email = False
        extra = ""
        counter = 0
        for a in args:
            if a == "email":
                email = True
            else:
                extra = a
            counter += 1

        output = ""
        cursor = connection.cursor()

        def sqlone(sql):
            cursor.execute(sql)
            for row in cursor.fetchall():
                return str(row[0])
            return "0"

        def popular_showrooms(days):
            output = ""
            output += "Most popular showrooms over past " + str(days+1) + " days:\n"
            sql = "select p.id, i.imp, p.name, p.projuniq from (select project_id, count(*) as imp from roomhints_projectimpression where seconds > now() - interval '" + str(days) + " day' group by project_id order by 2 desc) i, roomhints_project p, roomhints_roomtype rt where i.project_id = p.id and p.roomtype_id = rt.id and (rt.name = 'showroom' or rt.name='showroom_user') order by 2 desc;"
            cursor.execute(sql)
            for row in cursor.fetchall():
                output += "with " + str(row[1]) + " views:\t" + str(row[2]) + "\n"
                output += "     \t" + "http://roomhints.com/room?projuniq=" + str(row[3]) + "\n"
            return output


        def popular_hints(days):
            output = ""
            output += "Most popular hints over past " + str(days+1) + " days:\n"
            sql = "select c.id, c.imp, h.price, h.name from (select h.id, count(*) as imp from roomhints_roomhintimpression rhi, roomhints_roomhint rh, roomhints_hint h where rhi.seconds > now() - interval '" + str(days) + " day' and rhi.roomhint_id = rh.id and rh.hint_id = h.id group by h.id order by 2 desc) c, roomhints_hint h where c.id = h.id order by imp desc limit 10;"
            cursor.execute(sql)
            for row in cursor.fetchall():
                output += "with " + str(row[1]) + " views:\t$" + str(int(row[2])) + "\t" + row[3] + "\n"
            return output

        def popular_search(days):
            output = ""
            output += "Most popular search terms (past " + str(days) + " days):" + "\n"
            sql = "select count(*) from (select custom from roomhints_searchimpressiongroup where seconds > now() - interval '7 days' and (custom != 'couch' and custom != 'chair' and custom != 'table' and custom != 'dresser' and custom != 'lamp' and custom != 'rug') order by id desc) as s;"
            output += "with " + sqlone(sql) + " requests: all 'type it here' items\n"
            sql = "select count(*), custom from roomhints_searchimpressiongroup where seconds > now() - interval '" + str(days) + " day' group by custom order by count desc limit 20;"
            cursor.execute(sql)
            for row in cursor.fetchall():
                output += "with " + str(row[0]) + " requests:\t" + str(row[1]) + "\n"
            return output

        def paid_rooms_sql(days):
            return "select count(*) from roomhints_project where charge_seconds is not null and charge_seconds < now() - interval '" + str(days) + " day'"

        def users_sql(days, origin_list):
            ret_origin = " and ("
            counter = 0
            for origin in origin_list:
                if counter > 0:
                    ret_origin += " or "
                ret_origin += "p.origin='" + origin + "'"
                counter += 1
            ret_origin += ")"
            ret = "select count(*) from roomhints_profile p, auth_user u where u.id = p.user_id"
            if counter > 0:
                ret += ret_origin
            ret += " and u.date_joined < now() - interval '" + str(days) + "day'"
            return ret

        def active_users_sql(days_from,days_to):
            def seconds_comp(sec):
                comp =  sec + " > now() - interval '" + str(days_from) + " day' and "
                comp += sec + " < now() - interval '" + str(days_to) + " day'"
                return comp
            ret =  "select count(*) from (select distinct profile_id from ("
            # rooms
            ret += "select distinct profile_id from roomhints_project p where " + seconds_comp("p.seconds")
            # hints added
            ret += " union "
            ret += "select distinct profile_id from roomhints_hint h where " + seconds_comp("h.seconds")
            # hints given to rooms
            ret += " union "
            ret += "select distinct profile_id from roomhints_roomhint rh where " + seconds_comp("rh.seconds")
            # search queries
            ret += " union "
            ret += "select distinct profile_id from roomhints_searchimpressiongroup sig, roomhints_project p where sig.project_id = p.id and " + seconds_comp("sig.seconds")
            # room views (their own, design rooms)
            ret += " union "
            ret += "select distinct prof_id from roomhints_projectimpression pi where " + seconds_comp("pi.seconds")
            # roomhint like (their own, but also from website)
            ret += " union "
            ret += "select distinct prof_id from roomhints_roomhintlike rhl where " + seconds_comp("rhl.seconds")
            # roomhintimpression
            ret += " union "
            ret += "select distinct prof_id from roomhints_roomhintimpression rhi where " + seconds_comp("rhi.seconds")
            ret += ") as pall) as cpall"
            return ret

        def seconds_sql(days,table,where=""):
            return "select count(*) from roomhints_" + table + " where seconds < now() - interval '" + str(days) + " day' " + where

        def beta_sql(days):
            return seconds_sql(days,"beta")

        def rooms_sql(days):
            return seconds_sql(days,"project")

        def rooms_public_sql(days):
            return seconds_sql(days,"project"," and public = true")

        def rooms_deleted_sql(days):
            return seconds_sql(days,"project"," and public = false")

        def rooms_surprise_sql(days):
            return seconds_sql(days,"project"," and public = false and custom like 'Surprise me!'")

        def hints_sql(days):
            return seconds_sql(days,"hint")

        def roomhints_sql(days):
            return seconds_sql(days,"roomhint")

        def roomhints_opened_sql(days):
            return "select count(*) from roomhints_roomhint rh, roomhints_profile up, roomhints_project p where rh.seconds < now() - interval '" + str(days) + " day' and rh.project_id = p.id and p.profile_id = up.id and up.designer=false and rh.received_seconds is not null"

        def roomhints_savedinspiration_sql(days):
            return "select count(*) from roomhints_roomhint rh, roomhints_profile up, roomhints_project p where rh.seconds < now() - interval '" + str(days) + " day' and rh.project_id = p.id and p.profile_id = up.id and up.designer=false and rh.hint_id in (select h.id from roomhints_hint h, roomhints_roomhint rh, roomhints_project p, roomhints_roomtype rt where rh.project_id = p.id and p.roomtype_id = rt.id and (rt.name = 'showroom' or rt.name = 'showroom_user') and rh.hint_id = h.id)"

        def search_sql(days):
            return seconds_sql(days,"searchimpressiongroup")

        def search_impressions_sql(days):
            return "select count(*) from roomhints_searchimpressiongroup sig, roomhints_searchimpression si where si.group_id = sig.id and sig.seconds < now() - interval '" + str(days) + " day'"

        def search_chosen_sql(days):
            return search_impressions_sql(days) + " and si.chosen = true"

        def searchhints_sql(days):
            return seconds_sql(days,"hint"," and profile_id=" + str(search_profile_id()) + " and public=true")

        def projectimpressions_sql(days,meta):
            return seconds_sql(days,"projectimpression"," and meta = '" + meta + "'")

        def projectimpressions_inspiration_sql(days,meta):
            return "select count(*) from roomhints_projectimpression pi, roomhints_project p, roomhints_roomtype rt where pi.meta='" + meta + "' and pi.project_id = p.id and p.roomtype_id = rt.id and (rt.name='showroom' or rt.name = 'showroom_user') and pi.seconds < now() - interval '" + str(days) + " day' "

        def roomhintimpressions_sql(days,meta):
            return seconds_sql(days,"roomhintimpression"," and meta = '" + meta + "'")

        def roomhintlikes_sql(days):
            return seconds_sql(days,"roomhintlike"," and liked = true")

        def roomhintdislikes_sql(days):
            return seconds_sql(days,"roomhintlike"," and liked = false")

        def feedback_sql(days):
            return seconds_sql(days,"feedback")

        def event_sql(days,meta,unique=False):
            sql = "select count(*) from "
            if unique:
                sql += " (select distinct prof_id from "
            sql += "roomhints_event where seconds < now() - interval '" + str(days) + " day' and meta = '" + meta + "'"
            if unique:
                sql += ") as s"
            return sql

        def comment_sql(days):
            return seconds_sql(days,"comment")

        def commentcore_sql(days,where=None):
            sql = "select count(*) from roomhints_comment c, roomhints_profile p where c.profile_id = p.id and c.seconds < now() - interval '" + str(days) + " day'"
            if where != None:
                sql += " and " + where
            return sql

        def commentuser_sql(days):
            return commentcore_sql(days,"p.designer=false")

        def commentdesigner_sql(days):
            return commentcore_sql(days,"p.designer=true")

        def commentdesigner_auto_sql(days):
            return commentcore_sql(days,"p.designer=true and c.auto_responded=true")
        
        def commentdesigner_opened_sql(days):
            return commentcore_sql(days,"p.designer=false and c.received_seconds is not null")

        def growth_estimate(users,growth_perc,weeks):
            growth = float((100+float(growth_perc))/100)

            start = users
            i = 1
            output = ""
            while i <= weeks:
                users = int(float(users) * growth)
                if float(start) == 0:
                    perc = 0
                else:
                    perc = float(users)/float(start)
                output += " week " + str(i) + ":  " + str(users) + " (" + str("%.1f" % (perc)) + "x)" + "\n"
                i += 1
            return output

        def numdiff(this,last):
            ret = ""
            val = int(this)-int(last)
            if val > 0:
                ret += "+"
            return ret + str(val)

        def grate(this,last):
            if float(last) == 0:
                val = 0
            else:
                val = (float(this) - float(last))/float(last) * 100
            return str("%.1f" % val)

        def rate(num,days):
            minutes = days * 24 * 60
            val = minutes/num
            if val > 1:
                return "1 every " + str(val) + " minutes"
            else:
                val = num/minutes
                return str(val) + " per minute"

        def style(label,this,prev,tabs=3):
            counter = 0
            tabstr = ""
            while counter < tabs:
                tabstr += "\t"
                counter += 1
            return label + this + tabstr + prev + "\t\t" + numdiff(this,prev) + "  " + grate(this,prev) + "%\n"

        # def latest_projects(days):
        #     output = ""
        #     sql = "select p.projuniq from roomhints_project p, roomhints_profile pr where p.profile_id = pr.id and p.seconds > now() - interval '" + str(days) + " day' order by p.seconds desc;"
        #     cursor.execute(sql)
        #     for row in cursor.fetchall():
        #         output += "http://roomhints.com/room?projuniq=" + row[0] + "\n"
        #     return output

        def rooms_web_new(days):
            output = ""
            sql = "select count(*) as num, projuniq from (select pr.id, project_id, p.projuniq, u.date_joined from roomhints_projectimpression pi, roomhints_project p, roomhints_profile pr, auth_user u where u.date_joined > now() - interval '" + str(days) + " days' and u.id = pr.user_id and pr.id = pi.prof_id and pi.meta = 'web_view' and pi.project_id = p.id order by date_joined desc) as webnew group by projuniq order by num desc;"
            cursor.execute(sql)
            for row in cursor.fetchall():
                output += str(row[0]) + " web users viewed:  http://roomhints.com/room?projuniq=" + row[1] + "\n"
            return output

        days = 6 # it means whatever it says plus 1
        daystr = str(days+1)

        output += "  " + extra + "\n\n"
        output += "Generated on " + str(datetime.utcnow().replace(tzinfo=utc))
        output += "\n\n\n"
        output += "\n             You improve what you measure.." + "\n\n\n"
        output += "                     (until now)     (until " + daystr + " days ago)  (" + daystr + "-day growth)\n"
        prooms_this = sqlone(paid_rooms_sql(0))
        prooms_prev = sqlone(paid_rooms_sql(days))
        prooms_grate = grate(prooms_this,prooms_prev)
        output += style("Paid rooms:          ",prooms_this,prooms_prev,4)
        mob_this = sqlone(users_sql(0,['mobile']))
        mob_prev = sqlone(users_sql(days,['mobile']))
        mob_grate = grate(mob_this,mob_prev)
        output += style("Mobile users:        ",mob_this,mob_prev,4)
        active_this = sqlone(active_users_sql(days,0))
        active_prev = sqlone(active_users_sql(days*2,days))
        active_grate = grate(active_this,active_prev)
        output += style("*Active users:       ",active_this,active_prev)
        output += style("*Active users(30day):",sqlone(active_users_sql(30,0)),sqlone(active_users_sql(30*2,30)))
        beta_this = sqlone(beta_sql(0))
        beta_prev = sqlone(beta_sql(days))
        beta_grate = grate(beta_this,beta_prev)
        output += style("Beta signups:        ",beta_this,beta_prev,4)
        output += style("Web users:           ",sqlone(users_sql(0,['web'])),sqlone(users_sql(days,['web'])),4)
        users = sqlone(users_sql(0,['mobile', 'web']))
        output += style("Total users:         ",users,sqlone(users_sql(days,['mobile','web'])),4)
        output += "\n"
        rooms_this = sqlone(rooms_sql(0))
        rooms_prev = sqlone(rooms_sql(days))
        rooms_public_this = sqlone(rooms_public_sql(0))
        rooms_public_prev = sqlone(rooms_public_sql(days))
        rooms_deleted_this = sqlone(rooms_deleted_sql(0))
        rooms_deleted_prev = sqlone(rooms_deleted_sql(days))
        output += style("Rooms:               ",rooms_this,rooms_prev)
        output += style("Rooms Public:        ",rooms_public_this,rooms_public_prev)
        output += style("Rooms Deleted:       ",rooms_deleted_this,rooms_deleted_prev)
        output += style("Hints:               ",sqlone(hints_sql(0)),sqlone(hints_sql(days)))
        output += style("RoomHints:           ",sqlone(roomhints_sql(0)),sqlone(roomhints_sql(days)))
        output += style("RoomHints Opened:    ",sqlone(roomhints_opened_sql(0)),sqlone(roomhints_opened_sql(days)))
        output += style("RoomHints savedInsp: ",sqlone(roomhints_savedinspiration_sql(0)),sqlone(roomhints_savedinspiration_sql(days)))
        output += style("SearchEngineHints:   ",sqlone(searchhints_sql(0)),sqlone(searchhints_sql(days)))
        queries_this = sqlone(search_sql(0))
        queries_prev = sqlone(search_sql(days))
        queries_grate = grate(queries_this,queries_prev)
        output += style("SearchQueries:       ",queries_this,queries_prev)
        search_chosen_this = sqlone(search_chosen_sql(0))
        search_chosen_prev = sqlone(search_chosen_sql(days))
        output += style("Search Touched:      ",search_chosen_this,search_chosen_prev)
        output += "\n"
        output += "Mobile user rate:    " + rate(int(mob_this)-int(mob_prev),days) + "\n"
        output += "Search rate:         " + rate(int(queries_this)-int(queries_prev),days) + "\n"
        output += "Room rate:           " + rate(int(rooms_this)-int(rooms_prev),days) + "\n"
        output += "Rooms over install:  " + str("%.1f" % (float(rooms_this)/float(mob_this)*100)) + "%\n"
        spr = (float(queries_this)-float(queries_prev))/(float(rooms_this)-float(rooms_prev))
        dpr = (float(rooms_deleted_this)-float(rooms_deleted_prev))/(float(rooms_this)-float(rooms_prev))*100
        output += "Search per room:     " + str("%.2f" % spr) + "\n"
        output += "Room deletions:      " + str("%.1f" % dpr) + "%\n"
        output += "\n"
        output += style("Room Views:          ",sqlone(projectimpressions_sql(0,'view')),sqlone(projectimpressions_sql(days,'view')))
        output += style("InspirationRoomViews:",sqlone(projectimpressions_inspiration_sql(0,'view')),sqlone(projectimpressions_inspiration_sql(days,'view')))
        output += style("RoomHintViews:       ",sqlone(roomhintimpressions_sql(0,'view')),sqlone(roomhintimpressions_sql(days,'view')))
        output += style("RoomHints webbrowsed:",sqlone(roomhintimpressions_sql(0,'browse_start')),sqlone(roomhintimpressions_sql(days,'browse_start')))
        output += style("RoomHint Likes:      ",sqlone(roomhintlikes_sql(0)),sqlone(roomhintlikes_sql(days)))
        output += style("RoomHint Dis-Likes:  ",sqlone(roomhintdislikes_sql(0)),sqlone(roomhintdislikes_sql(days)))
        output += "\n"
        output += style("Total Q&A:           ",sqlone(comment_sql(0)),sqlone(comment_sql(days)))
        output += style("User Questions:      ",sqlone(commentuser_sql(0)),sqlone(commentuser_sql(days)))
        output += style("Designer Answers:    ",sqlone(commentdesigner_sql(0)),sqlone(commentdesigner_sql(days)))
        output += style("AutorespondedAnswers:",sqlone(commentdesigner_auto_sql(0)),sqlone(commentdesigner_auto_sql(days)))
        output += style("Answers Opened:      ",sqlone(commentdesigner_opened_sql(0)),sqlone(commentdesigner_opened_sql(days)))
        output += style("Feedback:            ",sqlone(feedback_sql(0)),sqlone(feedback_sql(days)))
        output += style("Demo:                ",sqlone(event_sql(0,'demo')),sqlone(event_sql(days,'demo')))
        output += style("Demo f/unique Users: ",sqlone(event_sql(0,'demo',True)),sqlone(event_sql(days,'demo',True)))
        output += "\n"
        output += style("Pressed Surprise:    ",sqlone(rooms_surprise_sql(0)),sqlone(rooms_surprise_sql(days)))
        output += style("Pressed Inspiration: ",sqlone(event_sql(0,'inspiration_open')),sqlone(event_sql(days,'inspiration_open')))
        output += style("Pressed HintAdd:     ",sqlone(projectimpressions_sql(0,'hint_add_open')),sqlone(projectimpressions_sql(days,'hint_add_open')),4)
        output += style("Pressed Pinterest:   ",sqlone(projectimpressions_sql(0,'pinterest')),sqlone(projectimpressions_sql(days,'pinterest')),4)
        output += style("Pressed Facebook:    ",sqlone(projectimpressions_sql(0,'facebook')),sqlone(projectimpressions_sql(days,'facebook')),4)
        output += style("Pressed Twitter:     ",sqlone(projectimpressions_sql(0,'twitter')),sqlone(projectimpressions_sql(days,'twitter')),4)
        output += style("Pressed Email:       ",sqlone(projectimpressions_sql(0,'email')),sqlone(projectimpressions_sql(days,'email')),4)
        output += style("Sent    Email:       ",sqlone(projectimpressions_sql(0,'email_sent')),sqlone(projectimpressions_sql(days,'email_sent')),4)
        output += style("Pressed EmailMySelf: ",sqlone(projectimpressions_sql(0,'email_hint')),sqlone(projectimpressions_sql(days,'email_hint')),4)
        output += style("Sent    EmailMySelf: ",sqlone(projectimpressions_sql(0,'email_hint_sent')),sqlone(projectimpressions_sql(days,'email_hint_sent')),4)
        output += style("Pressed Purchase:    ",sqlone(projectimpressions_sql(0,'pay_open')),sqlone(projectimpressions_sql(days,'pay_open')),4)
        output += style("Pressed Purc fSearch:",sqlone(projectimpressions_sql(0,'pay_fromsearch_open')),sqlone(projectimpressions_sql(days,'pay_fromsearch_open')),4)
        output += style("Pressed Charge:      ",sqlone(projectimpressions_sql(0,'pay_charge')),sqlone(projectimpressions_sql(days,'pay_charge')),4)
        output += style("Charge Failed:       ",sqlone(projectimpressions_sql(0,'pay_fail')),sqlone(projectimpressions_sql(days,'pay_fail')),4)
        output += style("Pressed Tell:        ",sqlone(event_sql(0,'recommend_open')),sqlone(event_sql(days,'recommend_open')),4)
        output += style("Sent    Tell:        ",sqlone(event_sql(0,'recommend_sent')),sqlone(event_sql(days,'recommend_sent')),4)
        output += "\n"
        output += popular_showrooms(0) + "\n"
        output += popular_hints(0) + "\n"
        output += popular_search(days) + "\n"

        # newroom_days = 1
        # output += "Latest room uploads (past " + str(newroom_days) + " days):" + "\n"
        # output += latest_projects(newroom_days) + "\n"

        # room_days = 2
        # output += "Rooms new web users saw (past " + str(room_days) + " days):" + "\n"
        # output += rooms_web_new(room_days)
        
        #output += "\n\n\n      let's not get paralyzed by data, for more days the data were\n\n"
        #output += popular_showrooms(days) + "\n"
        #output += popular_hints(days) + "\n"

        # output += "\n\n\nGiven these " + active_this + " active users and the " + active_grate + "% growth rate of active users, growth will be:\n"
        # output += growth_estimate(active_this,active_grate,52)
        # output += "\n\n\n"
        # output += "\n\n\nGiven these " + beta_this + " beta signups and the " + beta_grate + "% growth rate of beta signups, growth will be:\n"
        # output += growth_estimate(beta_this,beta_grate,52)
        # output += "\n\n\n"
        output += "\n\n\nGiven these " + mob_this + " mobile users and the " + mob_grate + "% growth rate of mobile users, growth will be:\n"
        output += growth_estimate(mob_this,mob_grate,52)

        cursor.close()
        print output
        if email:
            mes = MyEmailSend()
            perc = float(active_this)/float(mob_this) * 100
            active_to_mob = "%.1f" % perc
            subject = 'Stats: ' + mob_this + ' mobile users | ' + mob_grate + "% growth | " + prooms_grate + "% revenue growth"
            mes.send_email(subject,output,'in.style@roomhints.com',['tiffwillson@gmail.com'],
                           'imap.gmail.com', 'in.style@roomhints.com', 'roomhints1')
            
