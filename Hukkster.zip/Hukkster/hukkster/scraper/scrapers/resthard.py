import json
import opengraph
import re
import pprint
import logging
import json

from lxml.html import fromstring, tostring
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


def get_all_text(t):
    tl = t.xpath('.//text()')
    if isinstance(tl, list):
        return "".join(tl).strip()
    return tl


#class ResthardScraper(object):
class ResthardScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'restorationhardware.com'

    # def fetch_url(self):
    #     with open('data.html', 'r') as f:
    #         self.html = f.read()

    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ""
        t = lxml.xpath('.//@data-productid')
        if len(t) > 0:
            sku = t[0].strip()
        else:
            logger.debug('SKU nof found')
            return

        # title
        title = ""
        t = lxml.xpath('.//h3[@class="brand"]')
        if len(t) > 0:
            title = get_all_text(t[0])
        else:
            logger.debug('Title nof found')

        # Product price
        # 1st - special price
        product_current_price = None
        product_standard_price = None
        strike_price = lxml.xpath('.//div[@class="item-price-range"]/strike/text()')
        strong_price = lxml.xpath('.//div[@class="item-price-range"]/strong/text()')

        if strike_price and strong_price:
            text_price = "".join(strike_price).strip()
            prices = re.findall(r'\$(\d+)', text_price)
            product_standard_price = float(prices[len(prices) - 1])

            text_price = "".join(strong_price).strip()
            prices = re.findall(r'\$(\d+)', text_price)
            product_current_price = float(prices[len(prices) - 1])

        else:
            product_current_price = ""
            price = ""
            t = lxml.xpath('.//div[@class="item-price-range"]/text()')
            if len(t) > 0:
                text_price = "".join(t).strip()
                prices = re.findall(r'\$(\d+)', text_price)
                product_current_price = float(prices[len(prices) - 1])
            else:
                logger.debug('Price nof found')

        # Product selections
        tl = lxml.getroottree().xpath('.//script[contains(.,"product_data")]/text()')
        pairs = []

        if tl:
            jscript = tl[0]
            prog = re.compile(r'var product_data =(.*);\s+var\scmProduct', re.M + re.S + re.I)
            jsons = prog.findall(jscript)

            if jsons:
                js = unicode(jsons[0])
                jdata = json.loads(js)
                skus = jdata[sku]['skus']

                for el in skus:
                    pe = []
                    for k, v in el['attributes'].items():
                        value = v['displayName'].replace("&#034;", "\"")
                        pe.append((k, value))
                    pairs.append(pe)

        # Product images
        images = []
        tl = lxml.xpath('.//div[@class="two item-image zoom-trigger"]/img/@src')

        picmain = ""
        if tl:
            picmain = tl[0]
        else:
            tl = lxml.xpath('.//div[@class="two item-image zoom-trigger"]/a/img/@src')
            if tl:
                picmain = tl[0]
        images.append(picmain)

        # !!! Product promos
        # !!! please send me url's with promo for this site!!!

        selections = []
        data_url = raw_data.get('url', '')
        data_store = raw_data.get('site_name', '')
        data_image = raw_data.get('image', '')

        if data_image == '':
            images.reverse()
            data_image = images.pop()
            images.reverse()
        for pl in pairs:
            data = {'title': title,
                    'current_price': {
                        'value': product_current_price
                        },
                    'url': data_url,
                    'store': data_store.lower(),
                    'image': data_image,
                    'images': images,
                    'local_id': sku,
                    # 'selections': {
                    #     'size': product_sizes,
                    #     'color': product_colours,
                    #     },
                    'promos': []
                }
            data['selections'] = {}
            for name, variant in pl:
                name = name.encode('ascii')
                variant = variant.encode('ascii')
                data['selections'][name] = variant

            if product_standard_price:
                data['original_price'] = {'value': product_standard_price}
                #data['sold_out'] = True

            selections.append(data)
        return selections

    def parse_multi_product(self, lxml, raw_data):
        tl = lxml.xpath('.//div[contains(@class,"line-item group full")]')
        #print "multi=",len(tl)
        selections = []
        for te in tl:
            sel = self.parse_single_product(te, raw_data)
            selections.extend(sel)
        return selections

    def parse(self):
        logger.debug('Restorationhardware parse started')
        og = opengraph.OpenGraph(html=self.html)
        raw_data = dict([(k, v) for k, v in og.items()])
        if not self.html:
            raise HukksterTooManyOptions(ResthardScraper.get_domain(), self.url)

        lxml = fromstring(self.html)
        selections = self.parse_multi_product(lxml, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(ResthardScraper.get_domain(), self.url)

        return selections

if __name__ == '__main__':
    s = ResthardScraper()
    s.fetch_url()
    pprint.pprint(s.parse())
