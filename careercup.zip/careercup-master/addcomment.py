import os
from google.appengine.ext.webapp import template

from google.appengine.api import users

import objects
import masterpage

import method_comment
import method_cache
import method_db
import method_url
import method_user
import method_email
import method_notification

from datetime import datetime
	
class AddComment(masterpage.MasterPage):	
	def post(self):
		if self.isSpammer():
			return
		
		parent_id = method_url.getIntParam(self, 'parent')
		ancestor_id = method_url.getIntParam(self, 'ancestor')
		comment_type = method_url.getStringParam(self, 'type')
	
		comment = objects.Comment()
		text = self.request.get('Comment')
		user = method_user.getLoggedInUser()	
		
		# TODO(gayle): Error handling, html encoding
		if not(text):
			return
			
		if user:
			comment.author_name = user.name
			comment.author_id = user.uid
			author_name = comment.author_name
		else:
			author_name = self.request.get('AuthorName')
			if not(author_name.strip()):
				author_name = 'Anonymous'
			comment.author_name = author_name
		comment.parent_id = parent_id
		comment.ancestor_id = ancestor_id
		comment.type = comment_type
		
		if user:
			user.reputation = user.reputation + method_user.new_comment_multiplier
			method_db.putObject(user)

		comment.text = text
		if ('http://' in text) or ('www.' in text) or ('https://' in text):
			self.response.out.write('Sorry - no links allowed in comments!')
			return
		if self.hasBannedText(text):
			self.response.out.write('Hey, please stop spamming us. I don\'t do that to your site, do I? Then don\'t do it to mine.')
			return
		method_db.putObject(comment, False)	
		method_notification.notifyUsersOfComment(comment)
		comment_count = method_db.refreshCommentCount(ancestor_id, comment_type)

		# Send email
		ancestor_obj = method_db.getObjectWithTypeAndId(ancestor_id, comment_type)
		final_url = '/' + method_url.getUrlWithType(comment_type) + '?id=' + str(ancestor_id)		
		if ancestor_obj:
			ancestor_obj.last_comment = datetime.now()
			ancestor_obj.comment_count = comment_count
			method_db.putObject(ancestor_obj)
			type_description = comment_type
			if comment_type == 'forum':
				type_description = ' forum post'
			elif comment_type == 'question':
				type_description = ' question'			
			
			# Check subscriptions		
			emails = ancestor_obj.subscriptions
			email_list = ''
			for email in emails:
				email_list = email_list + email + ', '
								
			if user and self.setValueFromCheckbox('emailOnRespond'):
				ancestor_obj = method_user.subscribe(user,ancestor_obj)

			path = os.path.join(os.path.dirname(__file__), 'html/emailtemplate-comment.html')
			email_body = template.render(path, {'ancestor_text': ancestor_obj.text, 'comment_text': text} )
			if email_list != '':
				method_email.sendEmailToRawEmail(None, email_list, author_name + ' has commented on a ' + type_description + '.', email_body, 'comment', final_url)
							
			method_cache.clearObjectForTypeAndId('user', str(ancestor_obj.author_id))	
			
		method_cache.clearObjectForTypeAndId('user', str(comment.author_id))
				
		url = self.request.referer
		if '&mark=1' in url:
			url = url.replace('&mark=1', '')
		if '?mark=1' in url:
			url = url.replace('?mark=1', '')
		if comment_type == 'question':
			self.addActivity(comment.author_name, '/question?id=' + str(ancestor_id) + "#comment" + str(comment.uid), '/images/comment_activity.png', 'comment', 'question', None, comment.text)
		elif comment_type == 'forum':
			self.addActivity(comment.author_name, '/forumpost?id=' + str(ancestor_id) + "#comment" + str(comment.uid), '/images/comment_activity.png', 'comment', 'forum', None, comment.text)
		
		if parent_id == ancestor_id:
			self.redirect(url)
		else:
			comments = method_comment.getCommentAndSubcomments(parent_id)
			template_values = {'comments': comments}
			html = template.render('html/control-commentlist.html', template_values)
			self.response.out.write(html)	
		
	def putErrorMessage(self, error_message):		
		self.request.get('lblError')
		error_message		  
		#self.response.out.write('<script>control = document.getElementById("lblError"); control.value = error_message; </script>')
	
		#path = os.path.join(os.path.dirname(__file__), 'html/addquestion.html')
		#self.response.out.write(template.render(path, template_values)) 
	
	def get(self):
		error_message = ''
		
		parent_id = method_url.getIntParam(self, 'parent')
		force = method_url.getBooleanParam(self, 'force')
		parent_comment = method_comment.getCommentWithId(parent_id, force)
		if force:
			parent_comment.visible = True
		if not parent_comment:
			self.response.out.write('There is no comment with this id.	If you think this is an error, please file a bug at <a href="https://careercup.wufoo.com/forms/careercup-bug-report/">https://careercup.wufoo.com/forms/careercup-bug-report/</a>.')
			return
		
		name = None
		if users.get_current_user():
			name = users.get_current_user().nickname()
		
		comment_list = method_comment.getCommentsWithParent(parent_id)
		
		template_values = {
			'name': name,
			'comment': parent_comment,
			'comments': comment_list,
			'error_message': error_message,
			'comment_form_type': parent_comment.type,
			'comment_parent_id': parent_comment.uid,
			'comment_ancestor_id': parent_comment.ancestor_id,				
		}		 
		
		self.pushLoginInfo(template_values)
		self.response.out.write(self.getBody(template_values, 'html/addcomment.html'))	   
		
