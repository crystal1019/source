from django.contrib import admin
from arktotalwealth.team.models import *

class TeamPageAdmin(admin.ModelAdmin):
	prepopulated_fields = {'slug':('title',)}
	list_display= ('__unicode__','parent','priority','active','landingpage','include_teammembers' )
	list_editable = ('parent','priority','active','landingpage','include_teammembers')
	list_filter = ('parent','active','landingpage','include_teammembers')
	filter_horizontal = ('action_links',)
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]
	
class TeamMemberAdmin(admin.ModelAdmin):
	list_display = ('name', 'priority')
	list_editable = ('priority',)
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]	 

admin.site.register(TeamPage, TeamPageAdmin)
admin.site.register(TeamMember, TeamMemberAdmin)