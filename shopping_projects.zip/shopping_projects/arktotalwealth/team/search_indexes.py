import datetime
from haystack.indexes import *
from haystack import site
from arktotalwealth.team.models import *

class TeamPageIndex(SearchIndex):
    text = CharField(document=True, use_template=True)
    
class TeamMemberIndex(SearchIndex):
    text = CharField(document=True,use_template=True)


site.register(TeamPage, TeamPageIndex)
site.register(TeamMember, TeamMemberIndex)