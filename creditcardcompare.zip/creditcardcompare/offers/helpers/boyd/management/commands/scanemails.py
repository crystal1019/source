import os, glob
from django.conf import settings
from django.core.mail import send_mail
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        homedir = kwargs.get('homedir', 'home')
        for maildir in glob.glob(os.path.join(homedir, '*/homes/*/Maildir/new')):
            files = os.listdir(maildir)
            if len(files)!=0:
                message = 'Alert! Unforwarded email found in the mailbox '
                send_mail(message,
                          message + maildir,
                          settings.REVIEW_MODERATOR , 
                          [settings.REVIEW_MODERATOR], 
                          fail_silently=False )
            else:
                continue
