<?php
	$response = array(
		'result' => true,
		//'msg' => 'Супер! Вы в теме :)'
		'msg' => 'Ой! У вас емайл непавильный.'
	);
	
	echo json_encode($response);
?>