'''
@author: chaol
'''

from django.db import models
from django.core.validators import email_re
from bellabustiere.blog.models import PublishStatus
from django.db.models.signals import post_save
from django.core.mail import EmailMultiAlternatives
from django.conf import settings

from django.contrib.sites.models import Site
from django.conf import settings

import httplib2
def is_valid_email(email):
    return True if email_re.match(email) else False

class SiteMeta(models.Model):
    site = models.OneToOneField(Site)
    title = models.CharField(max_length=255, null=True, help_text='default page title on each page of the site')
    meta_keywords = models.CharField(max_length=255, help_text='default keywords on each page of the site', default='')
    meta_description = models.TextField(help_text='default description on each page of the site',default='')
    voucher_details = models.TextField(blank=True, null=True)
    delivery_return = models.TextField(blank=True, null=True)
    voucher_page_image = models.ImageField(upload_to='images/', help_text='size:347 X 446', blank=True, null=True)
    voucher_email_image = models.ImageField(upload_to='images/', help_text='size:242 X 335', blank=True, null=True)
    size_chart = models.FileField(upload_to='images/', help_text='max width 510', blank=True, null=True)
    popular_product = models.ForeignKey('shop.Product', null=True)

    def __unicode__(self):
        return self.site.domain
    
class PromoTile(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='images/')
    description = models.TextField(blank=True, null=True)
    link = models.URLField(blank=True, null=True)
    priority = models.IntegerField(default=0)
    active = models.BooleanField(default=False)
    
    def __unicode__(self):
        return self.name
    
    class Meta:
        ordering = ('-priority',)
        
class MediaUpload(models.Model):
    name = models.CharField(max_length=100)
    publishdate  = models.DateField()
    thumb_image = models.ImageField(upload_to='images/',help_text='image size: 169 X 259')
    upload_file = models.FileField(upload_to='images/')
    
    def __unicode__(self):
        return self.name
    
    class Meta:
        ordering = ['-publishdate',]

class MiscPage(models.Model):
    GROUP_CHOICE = [['about','About Us'],['contact','Customer Service'], ['null','No Group']]
    title = models.CharField(max_length=255)
    path = models.CharField(max_length=255,help_text="eg. /about/")
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    status = models.ForeignKey(PublishStatus)
    group = models.CharField(max_length=100, choices=GROUP_CHOICE, null=True)
    is_nav_landing = models.BooleanField('is this the group landing page',default=False)
    in_index = models.BooleanField("display in index page introduction panel?", default=False, editable=False)
    is_subscribe = models.BooleanField("is this page the subscribe page ?", default=False, )
    is_media = models.BooleanField(default=False)
    header = models.ImageField(upload_to="images/",blank=True,null=True,editable=False)
    priority = models.IntegerField(default=0)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    sites = models.ManyToManyField(Site)
    
    def __unicode__(self):
        return self.title
    
    def get_absolute_url(self):
        return '/' + self.path
    
    def get_group_url(self):
        grouppage = MiscPage.objects.filter(sites__id=settings.SITE_ID, is_nav_landing=True, group=self.group,status__display_to_user=True)
        return '/' + grouppage[0].path if grouppage else '#'
    
    def in_site(self):
        return ','.join([x.name for x in self.sites.all()])
        
    class Meta:
        ordering = ['group', '-priority']
    
class NewsItem(models.Model):
    title = models.CharField(max_length=255)
    message = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    publish_date = models.DateTimeField()
    url = models.URLField(blank=True, null=True)
    status = models.ForeignKey(PublishStatus)
    priority = models.IntegerField(default=0)
    def __unicode__(self):
        return self.title
    
    class Meta:
        ordering = ['-priority','-publish_date']
    
class SubscriptionGroup(models.Model):
    name = models.CharField(max_length=255,unique=True)
    def __unicode__(self):
        return self.name

class Subscription(models.Model):
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=50, blank=True, null=True)
    last_name = models.CharField(max_length=50, blank=True, null=True)
    dob = models.DateField(blank=True,null=True)
    company = models.CharField(max_length=100,blank=True,null=True)
    postcode = models.CharField(max_length=10,blank=True,null=True)
    subscribed = models.DateTimeField(auto_now_add=True)
    is_wholesale = models.BooleanField(default=False,editable=False)
    status = models.BooleanField(default=True)
    ip = models.CharField(max_length=20, null=True, blank=True)
    group = models.ForeignKey(SubscriptionGroup,blank=True,null=True)
    refered_by = models.ManyToManyField('self',related_name='referto',symmetrical=False ,blank=True, null=True, editable=False)
    imported = models.BooleanField(default=False,editable=False)
    stamp = models.DateTimeField(auto_now=True)
    sites = models.ManyToManyField(Site)
 
    def __unicode__(self):
        return self.email
    
    def email_not_read(self):
        emails = self.emailstatus_set.filter(read=False)
        return ','.join([x.email.title for x in emails])
    
    def api_xml(self):

        login_id = "julie@bellabustiere.com"
        token = "f536efc27cf9ed26063af7b21b703fbd1d54c4bb"
        xmlstring = '''<xmlrequest>
<username>%s</username>
<usertoken>%s</usertoken>
<requesttype>subscribers</requesttype>
<requestmethod>AddSubscriberToList</requestmethod>
<details>
    <emailaddress>%s</emailaddress>
    <mailinglist>3</mailinglist>
    <format>html</format>
    <confirmed>yes</confirmed>
    <customfields>
        <item>
            <fieldid>2</fieldid>
            <value>%s</value>
        </item>
        <item>
            <fieldid>3</fieldid>
            <value>%s</value>
        </item>
        <item>
            <fieldid>10</fieldid>
            <value>%s</value>
        </item>
        <item>
            <fieldid>7</fieldid>
            <value>%s</value>
        </item>
    </customfields>
</details>
</xmlrequest>'''   %(login_id, token, self.email,self.first_name,self.last_name,self.postcode, self.dob) 
        return xmlstring
    
    def connect_API(self,string):
        http = httplib2.Http()
        url = "http://em2.velocityhost.com.au/xml.php"    

        response, content = http.request(url, 'POST', body=string)
        return 1
    
    def save(self,**kwargs):
        super(Subscription,self).save(**kwargs)
        self.sites.add(Site.objects.get(id=settings.SITE_ID))
        
        string = self.api_xml()
        self.connect_API(string)
    
    class Meta:
        ordering = ('email',)
        
class Strings(models.Model):
    identifier = models.CharField(max_length=255, unique=True)
    text = models.CharField(max_length=255)
    def __unicode__(self):
        return self.identifier
    
    
class FlashImage(models.Model):
    image = models.FileField(upload_to="images/",help_text='size:961 X 473')
    promo_image = models.ImageField(upload_to='images/', blank=True, null=True)
    in_flash = models.BooleanField(default=False, editable=False)
    in_js = models.BooleanField('Active ?', default=False)
    title = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True,null=True)
    link = models.URLField(blank=True,null=True)
    priority = models.IntegerField(default=0)
    sites = models.ManyToManyField(Site)
    def __unicode__(self):
        return self.image.name
    
    def in_site(self):
        return ','.join([x.name for x in self.sites.all()])
    
class SpammerList(models.Model):
    ip = models.CharField(max_length=50, unique=True)
    last_post = models.TextField()
    
    def __unicode__(self):
        return self.ip

    
class Email(models.Model):
    FROM_ADDRESS = [["bellabustiere","Bella Bustiere <newsletter@bellabustiere.com.au>"]]
    title = models.CharField(max_length=255,unique=True)
    mailtitle = models.CharField(max_length=255,null=True)
    created = models.DateTimeField(auto_now_add=True)
    content = models.TextField()
    publish = models.DateTimeField(editable=False,blank=True,null=True)
    send = models.BooleanField(default=False,editable=False)
    fromaddress= models.CharField(max_length=255,choices=FROM_ADDRESS,null=True)
    
    def __unicode__(self):
        return self.title
    
    def send_already(self):
        return True if self.send else False
    
    def read_percentage(self):
        all = self.emailstatus_set.all()
        all = len(all)
        read = self.emailstatus_set.filter(read=True)
        read = len(read)
        return '%s/%s' %(read,all) 
    
    def not_read_percentage(self):
        all = self.emailstatus_set.all()
        all = len(all)
        notread = self.emailstatus_set.filter(read=False)
        notread = len(notread)
        return '%s/%s' %(notread,all) 
        
    def sendmail(self,subscribe=''):
        domain = settings.DOMAIN

        for x in subscribe:
            if is_valid_email(x.email):
                try:
                    content = "%s <br /> <img src='http://%s/reademail?id=%s&email=%s' width='1' height='1' />" %(self.content, domain, x.id, self.id)
                    email = EmailMultiAlternatives(self.mailtitle , content, self.get_fromaddress_display(), [x.email])
                    email.attach_alternative(content, "text/html")
                    email.send()
                    es = x.emailstatus_set.filter(email = self)
                    if not es:
                        es = EmailStatus()
                        es.email = self
                        es.subscribe = x
                        es.save()
                except:
                    pass
                
            
class EmailStatus(models.Model):
    email = models.ForeignKey(Email)
    subscribe = models.ForeignKey(Subscription)
    read = models.BooleanField(default=False,editable=False)
    def __unicode__(self):
        return self.email.title

#def EmailSaved(sender, **kwargs):
#    email = kwargs["instance"]
#    s = Subscription.objects.all()
    
#    for x in s:
#        es = x.emailstatus_set.filter(email = email)
#        if not es:
#            es = EmailStatus()
#            es.email = email
#            es.subscribe = x
#            es.save()
  
#post_save.connect(EmailSaved, sender=Email)

    