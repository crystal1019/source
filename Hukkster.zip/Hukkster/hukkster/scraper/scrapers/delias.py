import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class DeliasScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'delias.com'

    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()

    def fetch_url(self):
        try:
            request = requests.request('get', self.url)
            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except BaseException, e:
            logging.error('Error %s for %s' % (e.msg, self.url))


    def clean_html(self, html):
        htmlempty = ''
        for char in html:
            if (ord(char) != 10) and (ord(char) != 13):
                htmlempty += char
        return htmlempty


    def generate_record(self, url, site, title, price, image,
                        sku, size, color, promos=[]):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record

    def between(self, left, right, s):
        before,_,a = s.partition(left)
        a,_,after = a.partition(right)
        return before,a,after


    def parse_single_product(self, soup, html, raw_data):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """
        site_name = raw_data['site_name']
        url = raw_data['url']

        image = raw_data['image']
        title = raw_data['title']
        description = soup.find('meta', attrs={'name':'description'})['content']
        sku = soup.find('div', attrs={'class':'ProductCode'}).text
        try:
            price = soup.find('div', attrs={'class':'detailPrice'}).text.replace('$', '').replace('\r', '').replace('\n', '').replace('\t', '').replace(' ', '')
            price = float(price)
            promo = []
        except:
            price = float(soup.find('span', attrs={'class': 'pricesale'}).text[1:])
            promo = soup.find('span', attrs={'class':'pricewas'})

        selections = []
        colors = []
        sizes = []

        colorImgs = soup.find('div', attrs={'class':'detailSwatchContainer'}).findAll('img')
        for row in colorImgs:
            color = row['title']
            colors.append(color)

        import re
        regex = 'var goOption(.*)MLOptionsSku'
        s = re.compile(regex).findall(html)[0]
        start = s.find(']')
        end = s.find('[', start)
        s = s[start:end]
        after = s
        while True:
            _, a, after = self.between("'", "'",after)
            if a == '' or after == '': break
            sizes.append(a)

        
        for color in colors:
            for size in sizes:
                promos = []
                if promo:
                    promos=[promo.text]
                record = self.generate_record(url, site_name, title,
                                              price, image, sku, size, color, promos=promos)  
                selections.append(record)
        return selections

    def get_base(self, regex, html):
        """
        Pull subset of the HTML for regex evaluation.
        """

        return re.compile(regex).findall(html)[0]

    def get_data_regexes(self, regexes, base):
        """
        Loop over regex rules and pull data.
        return dictionary
        """

        result = {}

        for aregex in regexes:
            try:
                resunts = re.compile(aregex['find']).findall(base)
                result[aregex['name']] = ','.join(resunts)
            except: # TODO: it's too broad, please improve
                result[aregex['name']] = 'NOTHING'
        return result

    def get_data_json(self, data):
        """
        Parse json to dictionary.
        """
        return json.loads(data)
    
    def parse_multi_product(self, soup):
        # store
        site_name = soup.find('title').text
        # url
        url = self.url
        
        products = soup.find_all('tr')
        del products[0]
        
        selections = []
        for product in products:
            sku = product['id']
            image = product.find('td', attrs = {'class': 'items'}).find('img')['src']
            title = product.find('td', attrs = {'class': 'description'}).text
            price = float(product.find('td', attrs = {'class': 'price'}).text[1:])
            # get colors and sizes
            
            colors = product.find('td', attrs = {'class': 'color'}).find_all('option')
            sizes = product.find('td', attrs = {'class': 'size'}).find_all('option')
            
            if colors is None or not len(colors):
                color = ''
                if sizes is None or not len(sizes):
                    size = ''
                    record = self.generate_record(url, site_name, title,
                                                      price, image, sku, size, color)
                    selections.append(record)
                else:
                    del sizes[0] 
                    for size in sizes:
                        size =size.text
                        record = self.generate_record(url, site_name, title,
                                                      price, image, sku, size, color)
                        selections.append(record)
            else:
                del colors[0]
                if sizes is None or not len(sizes):
                    size = ''
                    for color in colors:
                        record = self.generate_record(url, site_name, title,
                                                      price, image, sku, size, color)
                        selections.append(record)
                else:
                    del sizes[0] 
                    for color in colors:
                        color = color.text
                        for size in sizes:
                            size =size.text
                            record = self.generate_record(url, site_name, title,
                                                          price, image, sku, size, color)
                            selections.append(record)
        return selections
    
    def parse(self):
        
        parse_multi = False
        raw_data = self.parse_opengraph()
        
        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')
        
        # Try to parse a single-product variant first
        selections = self.parse_single_product(soup, self.html, raw_data)

        # We assume it's a multi-product item
        if parse_multi:
            selections = self.parse_multi_product(soup)
        
        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(DeliasScraper.get_domain(), self.url)

        
        return selections



























