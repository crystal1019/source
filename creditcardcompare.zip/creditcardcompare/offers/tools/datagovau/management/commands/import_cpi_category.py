import os
from datetime import date
from django.core.management.base import BaseCommand
from offers.tools.datagovau.models import Location


class Command(BaseCommand):
    quarters = {'Mar': 3, 'Jun': 6, 'Sep': 9, 'Dec': 12}
    
    def handle(self, *args, **options):
        csv_path = os.path.dirname(__file__)
        f = open(os.path.join(csv_path, 'cpi_category.csv'))
        headers = f.readline().split('|')
        categories = [header.split(';')[1].strip() for header in headers[1:12]]
        city = headers[1].split(';')[2].strip()
        
        print city, len(categories), categories
        Location.objects.filter(batch__in=categories, address=city).delete()
        
        for l in f.readlines():
            row = l.replace('\n', '').split('|')
            for category, data in zip(categories, row[1:]):
                try:
                    data = float(data)
                except ValueError, e:
                    if data == '':
                        data = 0
                    else:
                        print '/%s/' % data
                        raise e
                month, year = row[0].split('-')
                Location(address=city,
                         data=data,
                         date=date(int(year), self.quarters[month], 1),
                         batch=category
                ).save()
        f.close()
