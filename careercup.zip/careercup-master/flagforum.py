import masterpage

import method_db
import method_email
import method_forum
import method_url
import method_user
	
class FlagForum(masterpage.MasterPage):	
	def post(self):		
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return

		id = method_url.getId(self)
		forum = method_forum.getForumPostWithId(id, True)		
			
		# Add user to forum
		users = forum.flag_users
		if users == None:
			users = []
		elif user.uid in users: # User has already flagged the forum
			return
		users.append(user.uid)			
		forum.flag_users = users
		
		# Add reason to forum
		reason = self.request.get('flagReason')
		reasons = forum.flag_reasons
		if reasons == None:
			reasons = []
		reasons.append(reason)
		forum.flag_reasons = reasons		

		# Delete forum if necessary
		forum.flag_count = forum.flag_count + 1
		if forum.flag_count >= method_forum.flag_limit or method_user.userIsAdmin():
			method_forum.deleteForumPost(forum)
		forum.under_review = True
		method_db.putObject(forum)
			
		method_forum.clearFlaggedCountCache()
		method_forum.clearCache(forum)	
		method_email.sendMeEmail('', 'Flagged Forum Post Reported', 'Flagged Forum Post Reported') 	
		self.displayError('Thank You!', 'Thank you!  This flag will be looked at shortly by a moderator. <br/><br/> Wanna be a moderator?  Email gayle@careercup.com.')		

	def get(self):		  
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return	
		id = method_url.getId(self)
		forum = method_forum.getForumPostWithId(id, True)
		if user.uid in forum.flag_users:
			already_flagged = True
		else:
			already_flagged = False
		
		template_values = {'forum_id': id, 'parent_tab': 'interviews', 'already_flagged' : already_flagged}
		self.pushPage(template_values, 'Flag Forum', 'html/flagforum.html')   
		
