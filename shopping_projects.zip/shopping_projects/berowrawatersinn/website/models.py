from django.db import models
from django.contrib.sites.admin import Site

# Create your models here.
class Banner(models.Model):
    name = models.CharField(max_length=40)
    image = models.ImageField(upload_to='images/', help_text='size: ')
    link = models.URLField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name + ' -- ' + '%s X %s' %(self.image.width, self.image.height)
    
    def show_image(self):
        return '''<img src='%s' height='36'>''' %self.image.url
    
    show_image.allow_tags = True
    
    class Meta:
        ordering = ['-priority',]
    

class CommonPage(models.Model):
    nav = '/'
    name = models.CharField(max_length=80)
    slug = models.SlugField()
    content = models.TextField()
    banner = models.ManyToManyField(Banner, blank=True, null=True)
    is_active = models.BooleanField(default=False)
    priority = models.IntegerField(default=0)
    meta_keywords = models.TextField(blank=True, null=True)
    meta_description = models.TextField(blank=True, null=True)

        
    def __unicode__(self):
        return self.name
        
    def get_absolute_url(self):
        return '%s%s.html' %(self.nav, self.slug) 
    
    def get_all_banners(self):
        return self.banner.filter(is_active=True)
    
    class Meta:
        abstract = True
        
        ordering = ['-priority',]
        

class Component(models.Model):
    name = models.CharField(max_length=60)
    content = models.TextField()
    link = models.URLField(blank=True, null=True)
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name
    
    class Meta:
        ordering = ['-priority',]
    
    

class SiteMeta(models.Model):
    site = models.OneToOneField(Site)
    title = models.CharField(max_length=255, null=True, help_text='default page title on each page of the site')
    meta_keywords = models.TextField(help_text='default keywords on each page of the site', default='')
    meta_description = models.TextField(help_text='default description on each page of the site',default='')
    banner = models.ManyToManyField(Banner,blank=True, null=True)
    footer = models.TextField(blank=True, null=True)

    def __unicode__(self):
        return self.site.domain

    def get_all_banners(self):
        return self.banner.filter(is_active=True)
    
class MiscPageManager(models.Manager):
    def get_nav_url(self,landing):
        try:
            return MiscPage.objects.get(landing=landing).get_absolute_url()
        except:
            return ''
    
class MiscPage(CommonPage):
    MISC_LANDING_CHOICES = (('Introduction','Introduction'),('Stay', 'Stay on the River'))
    landing = models.CharField(max_length=50, choices=MISC_LANDING_CHOICES, unique=True, blank=True, null=True)
    objects = MiscPageManager()
