import flask
import json

from tyne.broker import app
from tyne.broker import orgs


def mdictToDict(mdict):
	tgtDict = {}
	for key in mdict:
		tgtDict[key] = mdict[key]
		
	return tgtDict

@app.route('/health/', methods=['GET'])
def checkHealth():
	return("Hello World")


@app.route('/<orgName>/groups/', methods=['GET'])
def groups(orgName):
	orgClass = orgs.getInstance(orgName)
	
	if flask.request.method == 'GET':
		kwargs = mdictToDict(flask.request.args)
		result = orgClass.getGroups(**kwargs)

	try:
		result.keys()

		if 'groups' in result:
			return flask.jsonify(groups=result['groups'])
		if 'errors' in result:
			return flask.jsonify(errors=result['errors'])
		if 'error' in result:
			return flask.jsonify(errors=result['error'])
		
		return flask.jsonify(errors=result)
	except TypeError:
		return flask.jsonify(errors=result)


@app.route('/<orgName>/users/', methods=['GET', 'POST'])
def users(orgName):
	orgClass = orgs.getInstance(orgName)
	
	if flask.request.method == 'GET':
		kwargs = mdictToDict(flask.request.args)
		result = orgClass.getUsers(**kwargs)
	elif flask.request.method == 'POST':
		#bytes = flask.request.data
		result = orgClass.createUser(flask.request.args, flask.request.data.decode('utf-8'))
	else:
		result = "Error: do not recognize request method %s" % (flask.request.method)
	
	#if not a dict, turn it into one, as an error
	try:
		result.keys()

		if 'users' in result:
			return flask.jsonify(users=result['users'])
		if 'errors' in result:
			return flask.jsonify(errors=result['errors'])
		if 'error' in result:
			return flask.jsonify(errors=result['error'])
		
		return flask.jsonify(errors=result)
	except TypeError:
		return flask.jsonify(errors=result)


@app.route('/<orgName>/reservations/', methods=['GET', 'POST'])
@app.route('/<orgName>/reservations/<refNumber>', methods=['DELETE'])
def reservations(orgName, refNumber = None):
	orgClass = orgs.getInstance(orgName)

	if flask.request.method == 'GET':
		kwargs = mdictToDict(flask.request.args)
		result = orgClass.getReservations(**kwargs)

	elif flask.request.method == 'POST':
		#bytes = flask.request.data
		result = orgClass.createReservation(flask.request.args, flask.request.data.decode('utf-8'))
	elif flask.request.method == 'DELETE':
		#bytes = flask.request.data
		result = orgClass.deleteReservation(refNumber)
	else:
		result = "Error: do not recognize request method %s" % (flask.request.method)

	#if not a dict, turn it into one, as an error
	try:
		result.keys()

		if 'reservations' in result:
			print(json.dumps(result['reservations'], indent=2, sort_keys=True))
			return flask.jsonify(reservations=result['reservations'])
		if 'errors' in result:
			return flask.jsonify(errors=result['errors'])
		if 'error' in result:
			return flask.jsonify(errors=result['error'])
		
		return flask.jsonify(errors=result)
	except TypeError:
		return flask.jsonify(errors=result)


@app.route('/<orgName>/resources/', methods=['GET'])
def resources(orgName):
	orgClass = orgs.getInstance(orgName)
	
	if flask.request.method == 'GET':
		print(flask.request.args.items())
		kwargs = mdictToDict(flask.request.args)
		result = orgClass.getResources(**kwargs)
	else:
		result = "Error: do not recognize request method %s" % (flask.request.method)
	
	#if not a dict, turn it into one, as an error
	try:
		result.keys()

		if 'resources' in result:
			return flask.jsonify(resources=result['resources'])
		if 'errors' in result:
			return flask.jsonify(errors=result['errors'])
		if 'error' in result:
			return flask.jsonify(errors=result['error'])
		
		return flask.jsonify(errors=result)
	except TypeError:
		return flask.jsonify(errors=result)


@app.route('/<orgName>/schedules/', methods=['GET'])
def schedules(orgName):
	orgClass = orgs.getInstance(orgName)
	
	if flask.request.method == 'GET':
		print(flask.request.args.items())
		kwargs = mdictToDict(flask.request.args)
		result = orgClass.getSchedules(**kwargs)
	else:
		result = "Error: do not recognize request method %s" % (flask.request.method)
	
	#if not a dict, turn it into one, as an error
	try:
		result.keys()

		if 'schedules' in result:
			return flask.jsonify(schedules=result['schedules'])
		if 'errors' in result:
			return flask.jsonify(errors=result['errors'])
		if 'error' in result:
			return flask.jsonify(errors=result['error'])
		
		return flask.jsonify(errors=result)
	except TypeError:
		return flask.jsonify(errors=result)


@app.route('/<orgName>/schedules/available_times/', methods=['GET'])
def availableTimes(orgName):
	orgClass = orgs.getInstance(orgName)

	if flask.request.method == 'GET':
		print(flask.request.args.items())
		kwargs = mdictToDict(flask.request.args)
		result = orgClass.getAvailableTimes(**kwargs)
	else:
		result = "Error: do not recognize request method %s" % (flask.request.method)

	#if not a dict, turn it into one, as an error
	try:
		result.keys()

		if 'availability' in result:
			return flask.jsonify(availability=result['availability'])
		if 'errors' in result:
			return flask.jsonify(errors=result['errors'])
		if 'error' in result:
			return flask.jsonify(errors=result['error'])

		return flask.jsonify(errors=result)
	except TypeError:
		return flask.jsonify(errors=result)





@app.route('/testData', methods=['POST'])
def testData():	
	content = flask.request.json
	
	return flask.jsonify(test=content)
	
