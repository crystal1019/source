$(document).ready(function () {

    var submitted = false;
    var typdict = {
        0: 'recipe_file',
        1: 'link',
        2: 'contents'
    };

    var $file_draggify = $("#file_drag").draggify();

    function type_name_to_type(tn) {
        for (var typ in typdict) {
            if (typdict.hasOwnProperty(typ) && typdict[typ] === tn) {
                return typ;
            }
        }
    }

    function type_to_type_name(typ) {
        return typdict[typ];
    }

    function create_uploaded(id, type) {
        var uploaded_inp = '<input type="hidden" name="uploaded_' + type +
                '" value="' + id + '" />';
        $('#edit_recipe_form').append(uploaded_inp);
    }

    function recipe_input_click(evt) {
        function type_name_to_type(tn) {
            if (tn === 'recipe_file') {
                return 0;
            } else if (tn == 'link') {
                return 1;
            } else if (tn == 'contents') {
                return 2;
            }
        }

        var type_name = $(evt.target).parent('li').attr('data-controls');
        var $ctrls = $('.' + type_name + 
                      '_controls');

        localStorage['latest_recipe_entry_method'] = type_name;

        $('.data_field').parents('.control-group').hide();
        $ctrls.parents('.control-group').show();        
        $('#data_nav li').removeClass('current');
        $(this).parent('li').addClass('current');

        $('input[name=typ]').val(type_name_to_type(type_name));
    }

    function arrange_form_display() {        
        var $photos = $('.photos_controls');
        var $file = $('.recipe_file_controls');
        var $tag_list = $('.tag_list');
        var latest = localStorage['latest_recipe_entry_method'];
        var form_typ = $('input[name=typ]').val();
        var ctrls;

        $file.replaceWith($('#file_upload'));
        $('#file_drag').addClass('recipe_file_controls');

        // Move recipe entry methods into sidebar
        ctrls = [$('.link_controls').parents('.control-group'),
                 $('.contents_controls').parents('.control-group'),
                 $('.recipe_file_controls').parents('.control-group')];
        $(ctrls).each(function (i, ctrl) {
            $(ctrl).find('label').remove();
            $('.add_sidebar').append($(ctrl));
        });

        $tag_list.hide();

        $photos.find('input').replaceWith($('#photos_drop')).
            after($('#photos_display'));

        $('#data_nav li a').click(recipe_input_click);

        if (form_typ !== '') {
            $('#data_nav li[data-controls=' + type_to_type_name(form_typ) +
              '] a').click();
        } else {
            if (latest) {
                $('#data_nav li[data-controls=' + latest + '] a').click();
            } else {
                $('#data_nav li.current a').click();
            }
        }
    }

    function check_bookmarklet() {
        if (document.location.href.indexOf('link=') !== -1) {
            // we got here via bookmarklet
	    $('li[data-controls=link] a').click();
        }
    }

    function init_deletes() {
        function photo_deleted(resp) {
            var uid = resp.upload;
            $('#photos_display li[data-photo=' + uid + ']').remove();
            $('input[name=uploaded_photo][value=' + uid +']').remove();
        }

        var $form_container = $('.delete_photo_form');
        var $form = $form_container.find('form');

        $('#delete_recipe').click(function () {
            $('#delete_recipe_form input[type=submit]').click();
        });

        $('.delete_photo').live('click', function () {
            var photo = $(this).attr('data-photo');
            $form_container.find('input[name=id]').val(photo);
            $form_container.find('input[type=submit]').click();
        });

        $form.ajaxify(util.ajax_form_opts($form, photo_deleted));
    }

    function upload_ok(file, resp) {
        var filename = file.file.name.replace('.', '');
        var $remove_elem = $('.upload-' + filename).find('.remove_outer');

        $remove_elem.hide();
        $remove_elem.siblings('.upload_ok').show();

        create_uploaded(resp.id, resp.typ);
    }

    function init_file_uploads() {

        var file_upload_opts = util.draggify_opts($('#file_drag'));
        var $file_drag = $('#file_drag');
        file_upload_opts.multi = false;
        file_upload_opts.upload_on_drag = false;

        $('label[for=id_recipe_file]').hide();

        $('#change_file').click(function () {
            $(this).hide();
            $file_drag.show();
        });

        $file_draggify.init(file_upload_opts);
    }

    function form_submitted(evt) {
        var $file_drag = $('#file_drag');
        var $spinner = $file_drag.find('.drag_spin');
        var csrf = $('input[name=csrfmiddlewaretoken]').val();

        if (submitted) {
            return true;
        }

        evt.preventDefault();
        $spinner.spin(util.spinner_opts);
        submitted = true;

        $file_draggify.upload_files({
            single_upload_done: upload_ok,
            upload_url: $('#upload_url').val(),
            extra_data: {
                csrfmiddlewaretoken: csrf,
                extra: 'file'
            },
            all_uploads_done: function () {
                $spinner.spin(false);
                $('#edit_recipe_form').trigger('submit');
            }
        });

        return false;
    }

    function init_submit() {
        $('#edit_recipe_form').submit(form_submitted);
    }

    function init_photo_uploads() {

        function photo_uploaded(file, resp) {
            var $new_li = $('#uploaded_photo_li').clone();
            var src = $('#recipe_photo_url').val().replace('0', resp.id);
            $new_li.removeAttr('id').find('img').attr('src', src);
            $new_li.attr('data-photo', resp.id);
            $new_li.find('.delete_photo').attr('data-photo', resp.id);

            $('.thumbnails').append($new_li);
            $new_li.show();

            $('.drag_spin').spin(false);

            create_uploaded(resp.id, 'photo');
        }

        var csrf = $('input[name=csrfmiddlewaretoken]').val();
        $('#new_photo').draggify().init({
            multi: false,
            upload_on_drag: true,
            single_upload_done: photo_uploaded,
            upload_url: $('#upload_url').val(),
            extra_data: {
                csrfmiddlewaretoken: csrf,
                extra: 'photo'
            },
            drop: function (files, callback) {
                $('.drag_spin').spin(util.spinner_opts);
                callback();
            }
        });
    }

    arrange_form_display();
    check_bookmarklet();
    init_deletes();
    init_file_uploads();
    init_submit();
    init_photo_uploads();
});