#!/usr/bin/env python
import os, sys
try:
    from django.core.management import execute_from_command_line
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../django/django-1.8'))
    from django.core.management import execute_from_command_line


if __name__ == "__main__":
    execute_from_command_line(sys.argv)
