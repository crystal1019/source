from django.db import models
from django.contrib.auth.models import User

class Interest(models.Model):
    name = models.CharField(max_length=50, unique=True)
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name
    
class MemberType(models.Model):
    name = models.CharField(max_length=100, unique=True)
    super_member = models.BooleanField(default=False)
    member = models.BooleanField(default=False)
    
    def __unicode__(self):
        return self.name

class Profile(models.Model):
    user = models.ForeignKey(User, unique=True, null=True)
    membertype = models.ForeignKey(MemberType, null=True)
    mobile = models.CharField(max_length=20, blank=True, null=True)
    postcode = models.CharField(max_length=20)
    interests = models.ManyToManyField(Interest, null=True, blank=True)
    comments = models.TextField(blank=True, null=True)
    subscribe= models.BooleanField(default=True)
    
    def __unicode__(self):
        return self.user.username