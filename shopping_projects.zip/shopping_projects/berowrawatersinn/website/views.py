# Create your views here.
from django.http import HttpResponse
from django.template import loader, RequestContext
from berowrawatersinn.common import *

def home(request):
    t = loader.get_template('index.html')
    components = Component.objects.all()[:3]

    try:
        sitemeta = SiteMeta.objects.get(site__id=settings.SITE_ID)
    except:
        sitemeta = ''
    c = RequestContext(request, commondict({
        'current_meta':sitemeta,
        
        'components':components,
    
    },request))
    
    return HttpResponse(t.render(c))

def catchall(request,slug):
    t = loader.get_template('page.html')
    current_meta = MiscPage.objects.get(slug=slug)
    
    c = RequestContext(request, commondict({
        'current_meta':current_meta,
    
    },request))
    
     
    return HttpResponse(t.render(c))   