from django import forms
from models import Lead, ExtraField


class LeadForm(forms.ModelForm):
    source = forms.CharField(widget=forms.HiddenInput())

    class Meta:
        model = Lead
        exclude = ()

    def __init__(self, *args, **kwargs):
        super(LeadForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].error_messages['required'] = 'Please enter your first name'
        self.fields['email'].error_messages['required'] = 'Please enter your email'

class ExtraFieldForm(forms.ModelForm):
    class Meta:
        model = ExtraField
        exclude = ()
