from django.db import models
import datetime

# Create your models here.
class MealTypeManager(models.Manager):
    def get_available_booking_times(self, date=None):
        results = []
        total = 1
        booked = 0
        types = MealType.objects.all()
        for x in types:
            if date:
                booked, total = SeatsByDate.objects.get_book_info(date, x)
                
            if total and booked < total or total == None:
                start_temp = datetime.datetime(1000,1,1,x.can_book_from.hour,x.can_book_from.minute)
                end_temp = datetime.datetime(1000,1,1,x.can_book_to.hour,x.can_book_to.minute)
                delta = datetime.timedelta(seconds = int(x.can_book_interval)*60)
                v = start_temp
                while v <= end_temp:
                    r = datetime.time(v.hour,v.minute)
                    results.append(r)
                    v = v + delta
                    
                if date:
                    weekday = date.weekday()
                    additional = SeatsByWeekday.objects.filter(weekday=str(weekday),meal_type=x)
                    additional = additional[0] if additional else None
                    results.append(additional.additional_time) if additional and additional.additional_time else None
                    results.append(additional.additional_time1) if additional and additional.additional_time1 else None
                    results.append(additional.additional_time2) if additional and additional.additional_time2 else None

                    

        results = sorted(results)
        return results
    
    def get_mealtype(self, date,time):
        mealtype = MealType.objects.filter(can_book_from__lte=time, can_book_to__gte=time)
        if mealtype:
            return mealtype[0]
        else:
            weekday = date.weekday()
            additional = SeatsByWeekday.objects.filter(models.Q(additional_time=time) | models.Q(additional_time1=time) | models.Q(additional_time2=time), weekday=str(weekday),)
            
            return additional[0].meal_type if additional else None
        
        return None

class MealType(models.Model):
    INTERVAL_CHOICES = [['15','Every 15 Mins'],['30','Every 30 Mins']]
    name = models.CharField(max_length=20)
    can_book_from = models.TimeField()
    can_book_to = models.TimeField()
    can_book_interval = models.CharField(max_length=20,choices=INTERVAL_CHOICES)
    objects = MealTypeManager()
    def __unicode__(self):
        return self.name


class ArriveBy(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    priority = models.IntegerField(default=0)
    
    class Meta:
        verbose_name = 'Arrive by'
        verbose_name_plural = 'Arrive by'
    
    def __unicode__(self):
        return self.name
    

class Booking(models.Model):
    STATUS_CHOICES = [['Unconfirmed','Unconfirmed'], ['Confirmed','Confirmed'], ['Canceled','Canceled']]
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    date = models.DateField()
    time = models.TimeField()
    quantity = models.IntegerField()
    arrive_by = models.ForeignKey(ArriveBy)
    special_requests = models.TextField(blank=True, null=True)
    deposite_paid = models.BooleanField(default=False)
    status = models.CharField(max_length=50,choices=STATUS_CHOICES, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)    
    table_value = models.FloatField(blank=True, null=True)
    mealtype = models.ForeignKey(MealType, blank=True, null=True,editable=False)
    created = models.DateTimeField(auto_now_add=True)
    def __unicode__(self):
        return '''%s %s -- %s -- %s'''%(self.first_name,self.last_name,self.phone, self.email)
    
    def save(self,*args,**kwargs):
        try:
            mealtype = MealType.objects.get_mealtype(self.date,self.time)
            self.mealtype = mealtype
        except:
            pass
        
        super(Booking,self).save(*args,**kwargs)

class SeatsByWeekday(models.Model):
    WEEKDAY_CHOICES = [['0', 'Monday'],['1','Tuesday'],['2','Wednesday'],['3','Thursday'],['4','Friday'],['5','Saturday'],['6','Sunday']]
    weekday = models.CharField(max_length=20, choices=WEEKDAY_CHOICES)
    meal_type = models.ForeignKey(MealType)
    seats = models.IntegerField(default=0)
    cutoff = models.IntegerField(null=True, blank=True, help_text='empty means never cut off otherwise will cut off bookings when confirmed bookings reached this number')
    additional_time = models.TimeField(blank=True,null=True)
    additional_time1 = models.TimeField(blank=True,null=True)
    additional_time2 = models.TimeField(blank=True,null=True)
    
    
    class Meta:
        unique_together = (('weekday','meal_type'),)
        
    def __unicode__(self):
        return "%s - %s - %s" %(self.get_weekday_display(),self.meal_type, self.seats)
    
class SeatsByDateManager(models.Manager):
    def get_book_info(self, date, meal_type):
        total = SeatsByDate.objects.filter(date=date,meal_type=meal_type)
        if total:
            total = total[0].cutoff
        else:
            weekday = str(date.weekday())
            total = SeatsByWeekday.objects.filter(weekday=weekday,meal_type=meal_type)
            if total:
                total = total[0].cutoff
            else:
                total = 0
                
        booked = sum([x.quantity if MealType.objects.get_mealtype(date,x.time) == meal_type else 0  for x in Booking.objects.filter(date=date, status='Confirmed')])
        return booked, total
    
    def get_calendar_info(self, date, meal_type):
        total = SeatsByDate.objects.filter(date=date,meal_type=meal_type)
        if total:
            total = total[0].seats
        else:
            weekday = str(date.weekday())
            total = SeatsByWeekday.objects.filter(weekday=weekday,meal_type=meal_type)
            if total:
                total = total[0].seats
            else:
                total = 0
                
        booked = sum([x.quantity if MealType.objects.get_mealtype(date,x.time) == meal_type else 0  for x in Booking.objects.filter(date=date, status='Confirmed')])
        return booked, total
    
    def get_follow_available_date(self,days=180):
        now = datetime.date.today()
        datelist = [ now + datetime.timedelta(days=x) for x in range(0,days) ]
        results = []
        for x in datelist:
            mm = MealType.objects.get_available_booking_times(date=x)
            if mm:
                results.append(int(x.strftime('%s')) * 1000)
                
        return results
    
class SeatsByDate(models.Model):
    date = models.DateField()
    meal_type = models.ForeignKey(MealType)
    seats = models.IntegerField(default=0)
    cutoff = models.IntegerField(null=True, blank=True, help_text='empty means never cut off otherwise will cut off bookings when confirmed bookings reached this number')
    objects = SeatsByDateManager()
    
    class Meta:
        unique_together = (('date','meal_type'),)
        
    def __unicode__(self):
        return "%s - %s - %s" %(self.date, self.meal_type, self.seats)
    