'''
@author: chaol
'''
from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^$', 'bellabustiere.website.views.home'),
    #(r'^subscribe.html$', 'website.views.subscribe'),
    (r'^subscribe.json$', 'bellabustiere.website.views.subscribe'),
    (r'^coupon.json$','bellabustiere.website.views.coupon'),
  #  (r'^about.html', 'bellabustiere.website.views.about'),
    (r'^reademail','bellabustiere.website.views.readnotification'),
    (r'^search/$', 'bellabustiere.website.views.search'),
    (r'^robots.txt$', 'bellabustiere.website.views.robots'),
    (r'^currencychange.html$', 'bellabustiere.website.views.currencychange'),
    (r'^(?P<path>.*)$', 'bellabustiere.website.views.catchall'),
)
