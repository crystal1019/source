import logging
import re
from types import TypeType
from ..core.models import Shop
from .scrapers import *
from .exceptions import HukksterNotSupported


logger = logging.getLogger('scraper')
domain_re = re.compile(r'([0-9a-z][-\w]*[0-9a-z]\.)+[a-z0-9\-]{2,15}', re.IGNORECASE)


def select_scraper(url):
    """Selects a proper scraper class according to the domain name"""
    if url is not None:
        klasses = [j for (i, j) in globals().iteritems() if isinstance(j, TypeType) and issubclass(j, BaseScraper)]
        logger.debug('Locating a class for %s', url)
        for klass in klasses:
            domain = klass.get_domain()

            if domain in url:
                logger.debug('Located a handler class for %s: %s', url, klass)
                shop, created = Shop.objects.get_or_create(domain=domain)
                if created:
                    logger.info('Created a new shop: %s', shop)
                return klass(url)

        # We raise an exception if no handler is found
        m = re.search(domain_re, url)
        if m is not None:
            domain = m.group(0)

        raise HukksterNotSupported(domain, url)
    else:
        return None
