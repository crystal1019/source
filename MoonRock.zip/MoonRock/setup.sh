#!/bin/bash

echo "";
echo "======================";
echo "| Moonrock Installer |";
echo "======================";
echo "";
echo "Installing Node modules.";
echo "";
npm install
echo "";
echo "Installing Node modules.";
echo "";
bower install
echo "";
echo "Installation complete. Yay!";
echo "Now run 'grunt' to start the server.";
echo "";