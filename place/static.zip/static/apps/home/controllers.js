angular.module('home.controllers', []).controller('HomePageTopicsCtrl', ["$scope", "addCategoryIcons", "$http", "$timeout",
    function($scope, addCategoryIcons) {
        $scope.filter_type = null;
        $scope.safeApply = function(fn) {
            var phase = this.$root.$$phase;
            if (phase == '$apply' || phase == '$digest') {
                if (fn) {
                    fn();
                }
            } else {
                this.$apply(fn);
            }
        };
        $scope.filterTopics = function(category){
            if(category){
                $scope.filter_type = category;
                for(var i = 0, len = $scope.glayer.features.length; i < len; i++){
                    if($scope.glayer.features[i].category != category){
                        $scope.glayer.features[i].setMap(null);
                        if ($scope.glayer.features[i].info){
                            $scope.glayer.features[i].info.close();
                        }
                    }else{
                        $scope.glayer.features[i].setMap($scope.gmap.map);
                    }
                }
            }else{
                $scope.filter_type = null;
                for(var i = 0, len = $scope.glayer.features.length; i < len; i++){
                    $scope.glayer.features[i].setMap($scope.gmap.map);
                }
            }
        };
        $scope.addCategoryIcons = function(cardTopics) {
            addCategoryIcons(cardTopics);
        };
    }
]);
