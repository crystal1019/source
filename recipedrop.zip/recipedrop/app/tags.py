import json
from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseServerError, \
    HttpResponseForbidden
from django.contrib.auth.decorators import login_required
from django.template import RequestContext
from models import Tag, RecipeTag, Recipe

def all(request):
    tags = Tag.objects.all()
    tags = map(lambda t: t.tag, tags)
    return HttpResponse(json.dumps(tags),
                        content_type = 'application/json')

@login_required
def new(request):
    if request.method == 'POST':
        rid = request.POST['recipe']
        tag = request.POST['tag']

        recipe = Recipe.objects.get(id = rid)
        if recipe.author != request.user:
            return HttpResponseForbidden()

        tag = recipe.add_tag(tag)
        c = RequestContext(request)
        c.update({
                'tag': tag,
                'is_mine': True
                })
        return render_to_response('tags/tag.html', c)

@login_required
def delete(request):
    if request.method == 'POST':
        rid = request.POST['recipe']
        tag = request.POST['tag']

        recipe = Recipe.objects.get(id = rid)
        if recipe.author != request.user:
            return HttpResponseForbidden()

        tag = Tag.objects.get(tag = tag)
        rt = RecipeTag.objects.get(recipe = recipe, tag = tag)
        rt.delete()

        return HttpResponse(tag.tag)

    return HttpResponseServerError()
