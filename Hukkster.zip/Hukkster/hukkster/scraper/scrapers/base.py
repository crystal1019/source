import logging
import urllib2
import opengraph
from hukkster.scraper.models import UserAgent


logger = logging.getLogger('scraper')


class SmartRedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        result = urllib2.HTTPRedirectHandler.http_error_301(
            self, req, fp, code, msg, headers)
        result.status = code
        return result

    def http_error_302(self, req, fp, code, msg, headers):
        result = urllib2.HTTPRedirectHandler.http_error_302(
            self, req, fp, code, msg, headers)
        result.status = code
        return result


class ErrorHandler(object):
    def log_error(self, message):
        pass

    def email_error(self, message):
        pass


class BaseScraper(object):
    html = None

    @staticmethod
    def get_domain():
        return 'hukkster.com'

    def __init__(self, url):
        """
        Initializer
        :param url:
        """
        self.url = url
        self.ua = self.get_random_user_agent()
        logger.debug('Initiated the scraper for %s with %s' % (self.url, self.ua))
        self.fetch_url()

    def get_random_user_agent(self):
        """Picks a random User-Agent to cheat a website that we are a real visitor"""
        try:
            ua = UserAgent.objects.all().order_by('?')[0]
        except IndexError:
            ua = 'Hukkster Link Checker v2.0'

        return str(ua)

    def get_content_from_url(self, url):
        """Performs a HTTP query with a fake User-agent"""
        cookie_processor = urllib2.HTTPCookieProcessor()
        opener = urllib2.build_opener(SmartRedirectHandler, cookie_processor)
        urllib2.install_opener(opener)
        opener.addheaders = [('User-agent', self.ua)]

        content = None
        try:
            f = opener.open(url)
            content = f.read()
            logging.debug('Successfully fetched URL %s' % self.url)
        except urllib2.HTTPError, e:
            logging.error('Error %s for %s' % (e.msg, self.url))
        return content

    def fetch_url(self):
        content = self.get_content_from_url(self.url)
        if content is not None:
            self.html = content

    def parse_opengraph(self):
        """Parses Open Graph data. See http://ogp.me"""
        logging.debug('Started parsing Open Graph data')
        og = opengraph.OpenGraph(html=self.html)

        if og.is_valid():
            data = dict([(k, self.clean_string(v)) for k, v in og.items()])
            logging.debug('Got valid Open Graph data')
        else:
            if len(og.items()):
                data = dict()
                for item in og.items():
                    for key in ('title', 'image', 'url'):
                        if item[0] == key:
                            data[key] = item[1]
            else:
                data = None

            logging.debug('Got invalid Open Graph data')
        logging.debug('Finished parsing Open Graph data')
        return data

    def parse(self):
        raise NotImplementedError

    def save(self):
        raise NotImplementedError

    def clean_string(self, val):
        """Cleans a string by trimming starting/ending whitespaces and fixes escaped symbols
        :param val:
        """
        try:
            return val.strip().replace('\\', '')
        except AttributeError:
            return val
