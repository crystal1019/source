from datetime import datetime
from urllib import urlopen 
from django.conf import settings
from django.core.management.base import BaseCommand
from offers.helpers.boyd.mail import GenericMailThread
from offers.utils.data_cache.utils import cache_data
from offers.core.models import OfferMeta

class Command(BaseCommand):
    def handle(self, *args, **options):
        all_meta = OfferMeta.latest.filter(load_next_value__lte=datetime.today()
                                  ).exclude(next_value=None
                                  ).exclude(next_value='')
        if not all_meta:
            return  # no scheduled meta found, stop execution
        for meta in all_meta:
            meta.value = meta.next_value
            meta.next_value = None
            meta.load_next_value = None
            try:
                meta.save()
            except Exception,e:
                subject = 'Failed to load scheduled metafield!'
            else:
                subject = 'Successfully loaded scheduled metafield'
                
            GenericMailThread(**{
                'email': settings.REVIEW_MODERATOR,
                'sender': settings.REVIEW_MODERATOR,
                'subject': subject,
                'context': {'meta': meta},
                'template': 'emails/scheduled_meta.html',
            }).start()
        # reload metafields into cache table
        cache_data()
        if not settings.DEBUG:
            # clear cache from the 3 servers
            urlopen('http://www.creditcardcompare.com.au/tools/cache_admin/flush/')
            urlopen('http://www.moneychoices.com.au/tools/cache_admin/flush/')
            urlopen('http://www.savingup.com.au/tools/cache_admin/flush/')