$(document).ready(function () {

    function comment_created(resp) {
        console.log(resp.error);
        if (resp.error) {
            $('#new_comment').find('.error').html(resp.error);
        } else {
            var $new_comment = $('#new_comment_result').clone();
            $('#new_comment').find('.error').html('');
            var id;
            var $form;

            $new_comment.removeAttr('id');
            $new_comment.find('.comment_contents').replaceWith(resp);

            $('#new_comment_result').before($new_comment);
            $new_comment.show().removeClass('hidden');
            $('#new_comment textarea').val('');
            id = $new_comment.find('input[name=comment_id]').val();
            $new_comment.attr('data-comment', id);

            $form = $('#delete_comment_' + id).find('form');
            $form.ajaxify(util.ajax_form_opts($form, comment_deleted(id)));
            comments_count();
        }

    }

    function comment_deleted(id) {
        return function () {
            $('.comment[data-comment=' + id +']').remove();
            comments_count();
        };
    }

    function init_comments() {
        var $new_comment_form;

        $('.delete_comment_cont').each(function (i, elem) {
            var id = $(elem).attr('id');
            var $form = $('#' + id).find('form');
            var opts = util.ajax_form_opts($form,
                                           comment_deleted(id.split('_')[2]));
            $form.ajaxify(opts);
        });

        $('.delete_comment').live('click', function () {
            var id = $(this).attr('data-comment');
            $('#delete_comment_' + id + ' input[name=comment]').val(id);
            $('#delete_comment_' + id + ' input[type=submit]').click();
        });

        $new_comment_form = $('#new_comment').find('form');
        $new_comment_form.ajaxify(util.ajax_form_opts($new_comment_form,
                                                      comment_created));
    }

    function bookmark_action(resp) {
        var $bookmark = $('#bookmark_container');
        var $form;
        $bookmark.replaceWith(resp);
	// reselect container to find new form
	$bookmark = $("#bookmark_container");
        $form = $bookmark.find('form');
        $form.ajaxify(util.ajax_form_opts($form, bookmark_action));
    }

    function init_bookmarks() {
        var $bookmark_form;
    
        $('#bookmark_recipe').live('click', function () {
            $('#bookmark_container form').trigger('submit');
        });

        $('#unbookmark_recipe').live('click', function () {
            $('#bookmark_container form').trigger('submit');
        });

        $bookmark_form = $('#bookmark_container').find('form');
        $bookmark_form.ajaxify(util.ajax_form_opts($bookmark_form,
                                                   bookmark_action));
    }

    function comments_count() {
        var $rid = $('.comments-title').attr('data-id')
        
        $.ajax({
            url: '/recipes/commentscnt/' + $rid,
            dataType : "json", 
            success: function (data, textStatus) {
                    console.log("ovs-test ajax data received!",data,$rid)
                    $('.comments-title').replaceWith('<h2 class="comments-title" data-id="'+ $rid +'">'+ 
                        + data['no'] + ' Comments '
                        +'</h2>')
                }
            });
        console.log("ovs-test ok")
    }

    $('.fancybox').fancybox();
    init_comments();
    init_bookmarks();
});

