from google.appengine.ext import ndb

import objects
import method_cache
import method_url
import method_question
import method_user
import method_db
import logging

cache_key_notification_count = 'user-notifications'

def createNotificationForComment(comment, user):
	n = objects.Notification()
	n.user = user.user
	n.user_id = user.uid
	n.item_type_primary = 'comment'
	n.item_type_secondary = comment.type
	n.item_id_primary = str(comment.uid)
	n.item_id_secondary = str(comment.ancestor_id)
	n.item_description_primary = comment.author_name + ' added a new comment for ' + comment.type.capitalize() + ' #' + str(comment.ancestor_id)
	n.item_description_secondary = comment.text
	return n

def createNotificationForCommentVote(comment, userinfo_from, userinfo_to, points = 0):
	n = objects.Notification()
	n.user = userinfo_to.user
	n.user_id = userinfo_to.uid
	n.item_type_primary = 'vote-comment'
	n.item_type_secondary = comment.type
	n.item_id_primary = str(comment.uid)
	n.item_id_secondary = str(comment.ancestor_id)
	n.points = points
	if comment.author_id == userinfo_to.uid:
		n.item_description_primary = userinfo_from.name + ' voted up your ' + comment.type + ' comment'
	else:
		n.item_description_primary = userinfo_from.name + ' voted up a ' + comment.type + ' comment'
	n.item_description_secondary = comment.text
	return n

def createNotificationForFavorite(favorite, type, userinfo_from, userinfo_to, points = 0):
	n = objects.Notification()
	n.user = userinfo_to.user
	n.user_id = userinfo_to.uid
	n.item_type_primary = 'favorite'
	n.item_type_secondary = type
	n.item_id_primary = str(userinfo_from.uid)
	n.item_id_secondary = str(favorite.uid)
	n.points = points
	if type == 'question':
		n.item_description_secondary = favorite.text
		n.item_description_primary = userinfo_from.name + ' followed your ' + type	
	elif type == 'forumpost':
		n.item_description_secondary = favorite.text 
		n.item_description_primary = userinfo_from.name + ' followed your forum post'	
	elif type == 'user':
		n.item_description_primary = userinfo_from.name + ' followed you'		
		n.item_description_secondary = 'Reputation: ' + str(userinfo_from.reputation)
		if favorite.blurb:
			n.item_description_secondary = n.item_description_secondary + ' | ' + favorite.blurb
	return n

def createNotificationForQuestionVote(question, userinfo_from, userinfo_to, points = 0):
	n = objects.Notification()
	n.user = userinfo_to.user
	n.user_id = userinfo_to.uid
	n.item_type_primary = 'vote-question'
	n.item_type_secondary = 'question'
	n.item_id_primary = str(question.uid)
	n.points = points
	if question.author_id == userinfo_to.uid:
		n.item_description_primary = userinfo_from.name + ' voted up your question'
	else:
		n.item_description_primary = userinfo_from.name + ' voted up a question'	
	n.item_description_secondary = question.text
	return n

def createNotificationForQuestion(question, attribute_name, attribute_id, user):
	n = objects.Notification()
	n.user = user.user
	n.user_id = user.uid
	n.item_type_primary = 'question'
	n.item_type_secondary = 'attribute'
	n.item_id_primary = str(question.uid)
	n.item_id_secondary = attribute_id
	if attribute_name is None:
		n.item_description_primary = question.author_name + ' added a new interview question'	
	else:
		n.item_description_primary = question.author_name + ' added a new ' + attribute_name + ' interview question'
	n.item_description_secondary = question.text
	return n

def createNotificationForForum(forum, user):
	n = objects.Notification()
	n.user = user.user
	n.user_id = user.uid
	n.item_type_primary = 'forum'
	n.item_id_primary = str(forum.uid)
	n.item_description_primary = forum.author_name + ' added a new forum post: \"' + forum.subject + '\"'
	n.item_description_secondary = forum.text
	return n

def notifyUserOfCommentVote(comment, userinfo_from, userinfo_to):
	notifications = []
	notification = createNotificationForCommentVote(comment, userinfo_from, userinfo_to, method_user.vote_multiplier)
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, userinfo_to.uid)
	notifications.append(notification)
	
	followed_users = objects.UserInfo.query(objects.UserInfo.favorite_users == userinfo_from.uid)	
	for user in followed_users:
		if user.uid != userinfo_to and user.uid != userinfo_from:
			notification = createNotificationForCommentVote(comment, userinfo_from, userinfo_to)
			notifications.append(notification)	
			method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)
	ndb.put_multi(notifications)	

def notifyUserOfQuestionVote(question, userinfo_from, userinfo_to):
	notifications = []
	notification = createNotificationForQuestionVote(question, userinfo_from, userinfo_to, method_user.vote_multiplier)
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, userinfo_to.uid)
	notifications.append(notification)
		
	followed_users = objects.UserInfo.query(objects.UserInfo.favorite_users == userinfo_from.uid)	
	for user in followed_users:
		if user.uid != userinfo_to and user.uid != userinfo_from:
			notification = createNotificationForQuestionVote(question, userinfo_from, user)
			notifications.append(notification)	
			method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)
	ndb.put_multi(notifications)

def notifyUserOfFavorite(userinfo_from, userinfo_to, item, type):
	notification = createNotificationForFavorite(item, type, userinfo_from, userinfo_to, method_user.favorite_multiplier)
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, userinfo_to.uid)
	notification.put()

def notifyUsersOfComment(comment):
	if comment.type == 'question':
		users = objects.UserInfo.query(objects.UserInfo.favorites == comment.ancestor_id).fetch()
	else:
		users = objects.UserInfo.query(objects.UserInfo.favorite_forums == comment.ancestor_id).fetch()
		
	users = users + method_user.getFollowers(comment.author_id)
			
	notifications = []
	user_tracker = {}
	
	for user in users:
		if user.uid != comment.author_id and user.uid not in user_tracker:
			n = createNotificationForComment(comment, user)
			notifications.append(n)	
			method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)
			user_tracker[user.uid] = True
			
	ndb.put_multi(notifications)
	
def notifyUsersOfForum(forum):
	users = objects.UserInfo.query(objects.UserInfo.favorite_forum_all == True)	
	notifications = []
	
	user_tracker = {}
	
	for user in users:
		if user.uid != forum.author_id and user.uid not in user_tracker:
			n = createNotificationForForum(forum, user)
			notifications.append(n)	
			method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)
			user_tracker[user.uid] = True

	if forum.author_id:
		more_users = objects.UserInfo.query(objects.UserInfo.favorite_users == forum.author_id)			
		for user in more_users:
			if user.uid != forum.author_id and user.uid not in user_tracker:
				n = createNotificationForForum(forum, user)
				notifications.append(n)	
				method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)	
				user_tracker[user.uid] = True			
			
	ndb.put_multi(notifications)	
	
def notifyUsersOfQuestion(question, attribute_ids):
	notifications = []
	user_tracker = {}	
	for attribute_id in attribute_ids:
		if attribute_id != None and attribute_id != '-':
			users = objects.UserInfo.query(objects.UserInfo.favorite_attributes == attribute_id)
			notifications = []
			
			attribute_name = (method_question.getAttributeNameWithPid(attribute_id)).encode('utf-8')
			
			for user in users:
				if user.uid != question.author_id and user.uid not in user_tracker:
					n = createNotificationForQuestion(question, attribute_name, attribute_id, user)
					notifications.append(n)	
					method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)
					user_tracker[user.uid] = True
					
	users = objects.UserInfo.query(objects.UserInfo.favorite_users == question.author_id)
	primary_attribute_id = None
	primary_attribute_name = None	
	if len(attribute_ids) > 0:
		primary_attribute_id = attribute_ids[0]
		primary_attribute_name = (method_question.getAttributeNameWithPid(primary_attribute_id)).encode('utf-8')
	for user in users:		
		if user.uid != question.author_id and user.uid not in user_tracker:			
			n = createNotificationForQuestion(question, primary_attribute_name, primary_attribute_id, user)
			notifications.append(n)	
			method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)
			user_tracker[user.uid] = True			
	ndb.put_multi(notifications)	
	
def markQuestionAsRead(user, question_id):
	notifications1 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'comment', objects.Notification.item_id_secondary == unicode(question_id)).fetch(100)
	notifications2 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'question', objects.Notification.item_id_primary == unicode(question_id)).fetch(100)
	notifications3 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'vote-comment', objects.Notification.item_id_secondary == unicode(question_id)).fetch(100)
	notifications4 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'vote-question', objects.Notification.item_id_primary == unicode(question_id)).fetch(100)
	notifications5 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'favorite', objects.Notification.item_id_secondary == unicode(question_id)).fetch(100)

	nots = notifications1 + notifications2 + notifications3 + notifications4 + notifications5

	for n in nots:
		n.read = True

	ndb.put_multi(nots)
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)		
	
def markUserAsRead(user, user_id):
	notifications = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'favorite', objects.Notification.item_id_primary == unicode(user_id)).fetch(100)
	nots = []
	for n in notifications:
		n.read = True
		nots.append(n)

	ndb.put_multi(nots)
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)			
	
def markForumAsRead(user, forum_id):
	notifications1 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'forum', objects.Notification.item_id_primary == unicode(forum_id)).fetch(100)
	notifications2 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'comment', objects.Notification.item_type_secondary == 'forum', objects.Notification.item_id_secondary == unicode(forum_id)).fetch(100)
	notifications3 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'vote-comment', objects.Notification.item_id_secondary == unicode(forum_id)).fetch(100)
	notifications4 = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False, objects.Notification.item_type_primary == 'favorite', objects.Notification.item_id_secondary == unicode(forum_id)).fetch(100)
		
	nots = notifications1 + notifications2 + notifications3 + notifications4
	for n in nots:
		n.read = True

	ndb.put_multi(nots)
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)		
	
def getNotificationCountForUser(user, uid):	
	count = method_cache.getObjectForTypeAndKey(cache_key_notification_count, uid)
	if not count:
		count = objects.Notification.query(objects.Notification.user == user, objects.Notification.read == False).count();
		method_cache.setObjectForTypeAndKey(cache_key_notification_count, uid, count)
	return count

def clearAllNotificationsForUser(user):
	notifications = objects.Notification.query(objects.Notification.user == user.user).fetch(1000)
	ndb.delete_multi([m.key for m in notifications])
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)	
	
def markAllNotificationsAsRead(user):
	notifications = objects.Notification.query(objects.Notification.user == user.user, objects.Notification.read == False)
	nots = []
	for notification in notifications:
		notification.read = True
		nots.append(notification)
	ndb.put_multi(nots)			
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, user.uid)		
	
def getNotificationsForUser(userinfo):
	notifications = objects.Notification.query(objects.Notification.user == userinfo.user).order(-objects.Notification.date).fetch(1000)
	nots = []
	unread = 0
	for notification in notifications:
		if notification.read == False:
			unread = unread + 1
		if notification.item_type_primary == 'comment':
			notification.url = '/' + method_url.getUrlWithType(notification.item_type_secondary) + '?id=' + str(notification.item_id_secondary) + '&mark=1' + '#comment' + str(notification.item_id_primary)
			notification.image = 'comment_activity.png'
		elif notification.item_type_primary == 'question':
			notification.url = '/' + method_url.getUrlWithType(notification.item_type_primary) + '?id=' + str(notification.item_id_primary) + '&mark=1'
			notification.image = 'question_activity.png'
		elif notification.item_type_primary == 'forum':
			notification.url = '/' + method_url.getUrlWithType(notification.item_type_primary) + '?id=' + str(notification.item_id_primary) + '&mark=1'
			notification.image = 'forum_activity.png'
		elif notification.item_type_primary == 'vote-comment':
			notification.url = '/' + method_url.getUrlWithType(notification.item_type_secondary) + '?id=' + str(notification.item_id_secondary) + '&mark=1' + '#comment' + str(notification.item_id_primary)
			notification.image = 'voted.png'
		elif notification.item_type_primary == 'vote-question':
			notification.url = '/' + method_url.getUrlWithType(notification.item_type_secondary) + '?id=' + str(notification.item_id_primary) + '&mark=1'
			notification.image = 'voted.png'			
		elif notification.item_type_primary == 'favorite':
			logging.info('primary: ' + str(notification.item_id_primary))
			logging.info('secondary: ' + str(notification.item_id_secondary))
			notification.url = '/user?id=' + str(notification.item_id_primary) + '&mark=1'
			if notification.item_type_secondary == 'question' or notification.item_type_secondary == 'forumpost':
				notification.secondary_url = '/' + method_url.getUrlWithType(notification.item_type_secondary) + '?id=' + str(notification.item_id_secondary) + '&mark=1'
			notification.image = 'favorite_activity_icon.png'			
		nots.append(notification)
	method_cache.setObjectForTypeAndKey(cache_key_notification_count, userinfo.uid, unread)
	return nots
	
def clearCache(notification):
	method_cache.clearObjectForTypeAndId(cache_key_notification_count, notification.user_id)	