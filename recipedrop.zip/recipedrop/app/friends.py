from django.shortcuts import render_to_response
from django.contrib.auth.models import User
from django.template import RequestContext
from django.http import HttpResponseServerError
from django.contrib.auth.decorators import login_required
from models import Friendship, Notification

def anon(u):
    return u.is_anonymous()

def friends(u1, u2):

    if anon(u1) or anon(u2):
        return False

    existing = [Friendship.objects.filter(
            user1 = u1,
            user2 = u2,
            approved = True
            ),
                Friendship.objects.filter(
            user1 = u2,
            user2 = u1,
            approved = True
            )]

    return (len(existing[0]) > 0 or len(existing[1]) > 0) and \
        (u1.id != u2.id)

# u1 can friend u2 if they are different users, not already friends, and 
# neither has already friend-requested the other
def friendable(u1, u2):
    if anon(u1) or anon(u2):
        return False

    return (u1.id != u2.id) and (not friends(u1, u2)) and \
        (not friends_pending(u1, u2)) and (not friends_pending(u2, u1))

# friends_pending(u1, u2) is true if u1 has requested to be friends with 
# u2 and u2 hasn't approved it yet           
def friends_pending(u1, u2):
    if anon(u1) or anon(u2):
        return False

    existing = Friendship.objects.filter(
        user1 = u1,
        user2 = u2,
        approved = False
        )
    return len(existing) > 0

def get_friendship(u1, u2):
    f = None
    try:
        f = Friendship.objects.get(user1 = u1, user2 = u2, approved = True)
    except:
        try:
            f = Friendship.objects.get(user2 = u1, user1 = u2, approved = True)
        except:
            pass

    return f

def request_friend(request, user2):
    if request.method == 'POST':

        u2 = User.objects.get(id = user2)

        if friendable(request.user, u2):

            f = Friendship.objects.create(user1 = request.user,
                                          user2 = u2,
                                          approved = False)
            f.save()

            return render_to_response('friends/request_sent.html')

        else:
            if friends_pending(u2, request.user):
                return approve(request, u2)
            elif friends_pending(request.user, u2):
                return render_to_response('friends/request_sent.html')
            else:
                return render_to_response('friends/already_friends.html')

def approve(request, user1):
    if request.method == 'POST':
        c = RequestContext(request)

        u1 = User.objects.get(id = user1)
    
        f = Friendship.objects.get(user1 = u1,
                                   user2 = request.user)
        f.approved = True
        f.save()

        ns = Notification.objects.filter(
            target_user = request.user,
            other_user = u1,
            typ = 'friend',
            action = 'request',
            seen = False
            )
        for n in ns:
            n.seen = True
            n.save()

        c.update({'u': u1})

        return render_to_response('friends/approved.html', c)

def unfriend(request, user):
    c = RequestContext(request)

    if request.method == 'POST':
        u = User.objects.get(id = user)
        c.update({'name': u.profile.display_name })

        f = get_friendship(u, request.user)
        if f is not None:
            f.delete()

        return render_to_response('friends/unfriended.html', c)

def friend_action_template(u1, u2):
    friended = friends(u1, u2)
    waiting = friends_pending(u1, u2)
    requested = friends_pending(u2, u1)
    able = friendable(u1, u2)

    if friended:
        friend_action_template = 'profiles/unfriend.html'
    elif requested:
        friend_action_template = 'profiles/approve.html'
    elif waiting:
        friend_action_template = 'profiles/not_approved_yet.html'
    elif able:
        friend_action_template = 'profiles/send_request.html'
    else:
        friend_action_template = None

    return friend_action_template

@login_required
def action(request, uid):
    u = User.objects.get(id = uid)
    c = RequestContext(request)
    c.update({'view_user': u})
    templ = friend_action_template(request.user, u)

    if templ:
        return render_to_response(templ, c)
    else:
        return HttpResponseServerError()
