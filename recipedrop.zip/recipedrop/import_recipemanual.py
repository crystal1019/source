from app.models import RecipeManual, Recipe

f = open('recipemanual.txt')
contents = f.read()
f.close()

rms = contents.split('RecipeManual\n')
for rm in rms:
    if rm != '':
        rid = rm.split('\n')[0]
        print "\n".join(rm.split('\n')[1:])
        contents = "\n".join(rm.split('\n')[1:])
        recipe = Recipe.objects.get(id = rid)

        try:
            rm_obj = RecipeManual.objects.get(
                recipe = rid
                )
            rm_obj.contents = contents
        except:
            rm_obj = RecipeManual.objects.create(
                recipe = recipe,
                contents = contents
                )
        rm_obj.save()
