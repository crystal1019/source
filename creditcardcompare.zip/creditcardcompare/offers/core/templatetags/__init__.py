import re

varname_re = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]+$')
