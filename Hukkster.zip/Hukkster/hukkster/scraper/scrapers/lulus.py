import json
import logging
import opengraph
import re
from bs4 import BeautifulSoup
from urlparse import urljoin
from base import BaseScraper
import leaf
from ..exceptions import HukksterTooManyOptions


class LulusScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'lulus.com'

    #def fetch_url(self):
    #   with open('test_data/lulus/boots.html', 'r') as f:
    #      self.html = f.read()

    def make_float(self, value):
        if value:
            return float(re.sub(r'[^\d\.]', '', value.strip()))
        else:
            return None

    def leaf_get_text(self, parser, selector):
        ''' Get tag text or return None'''
        tag = parser.get(selector)
        if tag:
            if tag.text:
                return tag.text.strip()
        else:
            return None

    def parse(self):
        og_data = self.parse_opengraph()

        try:
            if og_data['type'] != 'product':
                raise HukksterTooManyOptions(LulusScraper.get_domain(),
                                             self.url)
        except KeyError:
            raise HukksterTooManyOptions(LulusScraper.get_domain(),
                                            self.url)


        doc = leaf.parse(self.html)
        items = list()
        common_data = dict()

        common_data['store'] = 'lulus'
        common_data['title'] = og_data['title']
        common_data['url'] = og_data['url']

        # get price
        #common_data['current_price']
        current_price = self.leaf_get_text(doc,'div.details span.price')
        current_price = self.make_float(current_price)

        # this is not an item
        if not current_price:
            # maybe this is a sale
            # get the current_price
            current_price = self.leaf_get_text(doc, 
                                               'div.details span.price ins')
            current_price = self.make_float(current_price)

            # get the original price
            original_price = self.leaf_get_text(doc,
                                                'div.details span.price del')
            original_price = self.make_float(original_price)

            if not current_price:
                raise HukksterTooManyOptions(LulusScraper.get_domain(),
                                             self.url)
            else:
                common_data['current_price'] = {'value': current_price}
                common_data['original_price'] = {'value': original_price}
        else:
            common_data['current_price'] = {'value': current_price}

        # local id
        local_id = doc.get('input[name="products_id"]')
        if local_id:
            common_data['local_id'] = local_id.element.attrib['value']

        # get color (one per item)
        swatch = doc.get('dl.swatches dt')
        while swatch:
            if swatch.element.text == 'Color:':
                common_data['color'] = swatch.element.getnext().text.strip()
                break
            else:
                swatch = swatch.element.next()

        # We don't need all images, uncomment if it's needed.
        # get images
        #common_data['images'] = list()
        #for img in doc('img.zoom_small'):
        #    img_url = img.element.attrib['src']
        #    # replace thumbnail by full-sized images
        #    img_url = re.sub(r'\/product\/small\/',
        #                     '/product/xlarge/',
        #                     img_url)
        #    common_data['images'].append(img_url)

        # get a main image, color is presented by item, one to one
        image = doc.get('img.zoom_small')
        if image and image.element.attrib['src'].strip():
            common_data['image'] = image.element.attrib['src']
            common_data['image'] = re.sub(r'\/product\/small\/',
                                   '/product/xlarge/',
                                   common_data['image'])

        # getting sizes
        for size in doc('dl.sizes dd input'):
            # 'sold-out' is the class of 'label' attribute, next of 'input'
            if 'sold-out' in size.element.getnext().attrib['class']:
                continue

            item = dict()
            # fill common data to each item
            item.update(common_data)

            item['selections'] = {}
            item['selections']['size'] = size.element.getnext().text
            if 'color' in common_data:
                item['selections']['color'] = common_data['color']
                del item['color'] # see item.update()

            items.append(item)


        return items
