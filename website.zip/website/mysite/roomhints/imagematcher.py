import os
import sys
#from django.conf import settings
import re
import subprocess
import threading
import shutil
import math

from django.conf import settings
from django.db import connection, transaction
from roomhints.models import Project
from roomhints.models import Hint
from roomhints.search_indexes import Hint
from roomhints.search import search
from roomhints.color import get_color_stats, hex_to_color, color_to_hex, hex_to_complement
from roomhints.utils import make_unique, search_profile_id, custom_last, custom_first

class ImageMatchThread(threading.Thread):
    def __init__(self,hint_image,project_image,oneorig,hint_hex,itemname,project_hex,project_color,project_color_complement,project_hex_complement):
        # one is the clean product picture without noise - that's the one we are looking to match
        self.hint_image = hint_image
        self.project_image = project_image
        self.oneorig = oneorig
        self.itemname = itemname
        self.project_hex = project_hex
        self.project_color = project_color
        self.project_color_complement = project_color_complement
        self.project_hex_complement = project_hex_complement
        self.total_score = 0
        self.color_score = 0
        self.feature_score = 0
        self.hint_hex = hint_hex
        self.hint_color = hex_to_color(self.hint_hex)
        self.hint_color_complement = hex_to_complement(self.hint_hex)
        self.hint_hex_complement = color_to_hex(self.hint_color_complement)
        threading.Thread.__init__(self)

    def run(self):
        #os.environ['DISPLAY'] = 'li510-191:1'
        os.environ['DISPLAY'] = ':1'

        dem_score = score_images_dem(self.hint_image,self.project_image,self.itemname)
        #dem_score = score_images_ccv(self.hint_image,self.project_image,self.itemname)
        #dem_score = 0 # disable feature extraction - it takes 10 secs, and I'm not sure it's helping
        self.feature_score = dem_score

        kind = "average"
        int_score = None
        bhat_score = None
        corr_score = None
        average_score = None
        # if self.itemname == "rug" or self.itemname == "chair":
        #     kind = "intersection"

        if kind == "intersection":
            int_score = score_images_intersection(self.hint_image,self.project_image,self.itemname)
            self.color_score = int_score
            if self.itemname == "chair":
                self.total_score = 1.3*dem_score + 3*int_score
            else:
                self.total_score = 1.1*dem_score + 18*int_score
        elif kind == "bhat":
            bhat_score = score_images_bhat(self.hint_image,self.project_image,self.itemname)
            self.color_score = bhat_score
            self.total_score = 1.1*dem_score + 50*(1-bhat_score)
        elif kind == "correlation":
            corr_score = score_images_correlation(self.hint_image,self.project_image,self.itemname)
            self.color_score = corr_score
            self.total_score = 1*dem_score + 15*corr_score
        elif kind == "average":
            average_score_dominant = score_images_average(self.hint_color,self.project_color,self.itemname)
            average_score_complement = score_images_average(self.hint_color_complement,self.project_color_complement,self.itemname)
            if average_score_dominant > average_score_complement:
                average_score = average_score_dominant
            else:
                average_score = average_score_complement
            self.color_score = average_score
            self.total_score = 1.1*dem_score + 15 * average_score

        # Trim precision
        self.feature_score = '%.2f' % self.feature_score
        self.color_score = '%.2f' % self.color_score
        self.total_score = '%.2f' % self.total_score

def find_image_match(input_image_path,kind,project=None):
    itemname = None
    image_list = []
    if kind == "projects":
        # Try to match against each small room picture
        projects = Project.objects.all()
        image_list = []
        for p in projects:
            image_data = dict()
            image_data['photo'] = p.photo_web.name
            image_data['dominant_hex'] = p.dominant_hex
            image_data['project_hex'] = p.dominant_hex
            image_data['project_color'] = hex_to_color(p.dominant_hex)
            image_data['project_color_complement'] = hex_to_color(p.dominant_hex)
            image_data['project_hex_complement'] = color_to_hex(image_data['project_color_complement'])
            image_list.append(p.photo_web.name)
    elif kind == "defaulthints":
        # Try to match against our own database of hints
        if project != None and project.custom != None and project.custom != "":
            # Search for the specific item asked
            #itemname = project.custom
            itemname = custom_last(str(project.custom))
            cursor = connection.cursor()
            ht_sql = ""
            builtin = False
            if itemname == "couch":
                # 2-couch, 7-sofa, 8-sectional
                ht_sql = "and (ht.id = 2 or ht.id = 7 or ht.id = 8)"
                builtin = True
            elif itemname == "chair":
                # 15-chair-for-lounging, 24-chair-for-office, 25-chair-plain
                ht_sql = "and (ht.id = 15 or ht.id = 24 or ht.id = 25)"
                builtin = True
            elif itemname == "desk" or itemname == "table":
                # 3-desk, 12-dining-table, 13-coffee-table, 44-console
                ht_sql = "and (ht.id = 3 and ht.id = 12 or ht.id = 13 or ht.id = 44)"
                ht_sql = "and (ht.id = 3)"
                builtin = True
            elif itemname == "rug":
                # 10-rug, 11-runner
                ht_sql = "and (ht.id = 10 or ht.id = 11)"
                builtin = True
            elif itemname == "dresser":
                # 16-dresser, 17-nightstand, 23-armoire, 31-entertainment center
                ht_sql = "and (ht.id = 16 or ht.id = 17 or ht.id = 23 or ht.id = 31)"
                builtin = True
            elif itemname == "lamp":
                # 5-lamp-short, 6-lamp-tall, 39-lamp-hanging
                ht_sql = "and (ht.id = 5 or ht.id = 6 or ht.id = 39)"
                builtin = True

            search_data = dict()
            f = open('/tmp/search_data','ab+')
            if builtin == True:
                sql = "select distinct h.id,h.dominant_hex,h.name,h.price,h.photo,h.sku,h.source,h.source_url from roomhints_hint h, roomhints_profile up, roomhints_hinttype ht, roomhints_hinttypelist htl where htl.hint_id = h.id and htl.hinttype_id = ht.id " + ht_sql + " and h.public = true and h.profile_id = " + str(search_profile_id()) + " order by 1 desc;"
                search_data['search'] = []
                cursor.execute(sql)
                for row in cursor.fetchall():
                    data_item = dict()
                    data_item['query'] = itemname
                    data_item['dominant_hex'] = row[1]
                    data_item['name'] = row[2]
                    data_item['price'] = math.ceil(row[3])
                    data_item['photo'] = row[4]
                    data_item['sku'] = row[5]
                    if data_item['sku'] == '':
                        data_item['sku'] = None
                    data_item['source'] = row[6]
                    data_item['source_url'] = row[7]
                    search_data['search'].append(data_item)
                f.write("query searchdata:\n" + str(search_data) + "\n")
                print(search_data)
            else:
                search_data = search(itemname)
                f.write("text searchdata:\n" + str(search_data) + "\n")

            project_hex = project.dominant_hex
            project_color = hex_to_color(project.dominant_hex)
            project_color_complement = hex_to_color(project.dominant_hex)
            project_hex_complement = color_to_hex(project_color_complement)

            for h in search_data['search']:
                print (h)
                # If there is no budget or the hint is within budget, add it
                if project.budget == -1 or project.budget > h['price']:
                    image_data = dict()
                    image_data['photo'] = h['photo']
                    image_data['dominant_hex'] = h['dominant_hex']
                    image_data['project_hex'] = project_hex
                    image_data['project_color'] = project_color
                    image_data['project_color_complement'] = project_color_complement
                    image_data['project_hex_complement'] = project_hex_complement
                    image_list.append(image_data)
                else:
                    print("Ignoring defaulthint " + h['name'] + " $" + str(h['price']) + " because it exceeds the budget " + str(project.budget))
        else:
            # Search over the entire database
            sprofile_id = search_profile_id()
            all_h = Hint.objects.filter(public=True,profile_id=sprofile_id).all()
            project_hex, project_color = image_hex2(input_image_path)
            project_color_complement = hex_to_color(project_hex)
            project_hex_complement = color_to_hex(project_color_complement)
            for h in all_h:
                #image_list.append(hint_color_data(h))
                image_data = dict()
                image_data['photo'] = h.photo_web.name
                image_data['dominant_hex'] = h.dominant_hex
                image_data['project_hex'] = project_hex
                image_data['project_color'] = project_color
                image_data['project_color_complement'] = project_color_complement
                image_data['project_hex_complement'] = project_hex_complement
                image_list.append(image_data)
                #image_list.append(h.photo.name)
            
    max_score_image, max_score, scores = find_image_match_from_list(input_image_path,image_list,itemname)
    return len(image_list), max_score_image, max_score, scores

def find_image_match_from_list(input_image_path,image_list,itemname):
    threads = []
    project_hex = None
    project_color = None
    counter = 0
    for item in image_list:
        counter += 1
        i = item['photo']
        hint_hex = item['dominant_hex']
        project_hex = item['project_hex']
        project_color = item['project_color']
        project_color_complement = item['project_color_complement']
        project_hex_complement = item['project_hex_complement']
        existing_image_path = settings.MEDIA_ROOT + i
        thread = ImageMatchThread(existing_image_path,input_image_path,i,hint_hex,itemname,project_hex,project_color,project_color_complement,project_hex_complement)
        threads.append(thread)
        thread.start()
        # count_mod = 6
        # if itemname == "table":
        #     count_mod = 3 # We seem to process a 600MB dem.exit process in matching tables
        count_mod = 16 # We seem to process up to 1GB at the end.
        if counter % count_mod == 0:
            # We won't go faster if we start swapping, so wait
            for t in threads:
                t.join()
    
    scores = dict()
    scores['by_image'] = dict()
    scores['by_score'] = dict()
    max_score = -1
    max_score_image = None    
    for t in threads:
        t.join() # Wait for the thread to finish
        if t.total_score not in scores['by_score'].keys():
            scores['by_score'][t.total_score] = []
        plan = dict()
        plan['image'] = t.oneorig
        plan['total_score'] = t.total_score
        plan['feature_score'] = t.feature_score
        plan['color_score'] = t.color_score
        plan['dominant_hex'] = t.hint_hex
        scores['by_score'][t.total_score].append(plan)
        scores['dominant_hex'] = project_hex
        scores['by_image'][t.oneorig] = dict()
        scores['by_image'][t.oneorig]['total_score'] = t.total_score
        scores['by_image'][t.oneorig]['feature_score'] = t.feature_score
        scores['by_image'][t.oneorig]['color_score'] = t.color_score
        scores['by_image'][t.oneorig]['dominant_hex'] = t.hint_hex
        if t.total_score > max_score:
            max_score = t.total_score
            max_score_image = t.oneorig
        #print str(t.feature_score) + ":" + str(t.color_score) + "=" + str(t.total_score) + " " + t.oneorig + " #" + str(t.hint_hex)

    return max_score_image, max_score, scores

def score_images_brief(one,two):
    # use BRIEF
    p = subprocess.Popen('export LD_LIBRARY_PATH=/usr/local/opencv-git/lib; /home/roomhints/devel/RH/imaging/test/brief ' + one + " " + two + " " + " 2>&1 | grep matches:", shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    #print "out is '" + out + "'"
    results = out.split('\n')
    #print results
    matches = -1
    if len(results) == 3 and results[1] == 'Aborted':
        matches = int(results[0].split(':')[1])
        return matches
    else:
        return 0

# Tiff says two to one works better (match a photo to a default hint)
def score_images_dem(one,two,itemname):
    freedom = 10
    if itemname == "chair":
        freedom = 15
    if itemname == "desk":
        freedom = 25
    #freedom = 10

    # use RANSAC
    # originally trying:  ./dem.exit SURF SURF BruteForce CrossCheckFilter in.jpg in.jpg  0
    # different params:   ./dem.exit SIFT SIFT FlannBased CrossCheckFilter in.jpg in.jpg  0
    # different params: ORB

    #cmd = 'export LD_LIBRARY_PATH=/usr/local/opencv-git/lib; /home/roomhints/devel/RH/imaging/test/dem.exit SURF SURF BruteForce CrossCheckFilter ' + one + " " + two + " 10 " + " 2>&1 | grep matches"
    #cmd = 'export LD_LIBRARY_PATH=/usr/local/opencv-git/lib; /home/roomhints/devel/RH/imaging/test/dem.exit SIFT SIFT FlannBased CrossCheckFilter ' + str(one) + " " + str(two) + " " + str(freedom)+ " " + " 2>&1 | grep matches"
    cmd = 'export LD_LIBRARY_PATH=/home/roomhints/devel/RH/imaging/opencv-bin-git-2.4.2/lib; /home/roomhints/devel/RH/imaging/test/dem.exit.64 SIFT SIFT FlannBased CrossCheckFilter ' + str(one) + " " + str(two) + " " + str(freedom)+ " " + " 2>&1 | grep matches"
    #cmd = 'export LD_LIBRARY_PATH=/usr/local/opencv-git/lib; /home/roomhints/devel/RH/imaging/test/dem.exit ORB ORB BruteForce CrossCheckFilter ' + one + " " + two + " 30 " + " 2>&1 | grep matches"

    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    print "out is '" + out + "'"
    results = out.split('\n')
    print results
    matches = -1
    if len(results) == 2 and results[0] != 'Aborted':
        matches = int(results[0].split(':')[1])
        return matches
    else:
        return 0

def score_images_ccv(one,two,itemname):
    cmd = '/home/roomhints/devel/RH/imaging/ccv/bin/siftmatch ' + str(one) + " " + str(two) + " " + " 2>&1 | grep 'keypoints out of'"

    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out = p.communicate(input=the_input)[0]
    print "out is '" + out + "'"
    results = out.split('\n')
    print results
    matches = int(results[0].split(' ')[0])
    return matches

def image_hex2(image):
    f = open('/tmp/color','ab+')
    f.write("will get dominant color\n")
    ret, c = get_color_stats(image)
    f.write("c is " + str(c) + " and ret is " + ret + "\n")
    f.close()
    return ret, c

def image_diff(a, b):
    score_max = 255 * 3
    score = score_max
    counter = 0
    d = []
    while counter < 3:
        absolute =  math.fabs(a[counter] - b[counter]) # absolute value
        d.append(absolute)
        counter += 1
        score -= absolute

    score = score / score_max
    print d
    print score
    return d, score

def image_hex(image):
    # Get average color in hex using imagemagick
    # convert  /tmp/40f3fe148312e1989ea0a0e6664f428b263e.jpg  -define histogram:unique-colors=true -format %c histogram:info:- | sort -r | grep -v '255,255,255' | head -1 |sed -e 's/.*#//' | awk '{ print $1 }'
    f = open('/tmp/bhat','ab+')
    # Ignore top entry, which is often white
    cmd = "/home/roomhints/devel/RH/website/mysite/roomhints/hexcolor.sh " + image
    f.write("issuing command: " + str(cmd) + "\n")
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out_all = p.communicate(input=the_input)[0]
    #f.write("out_all is : '" + str(out_all) + "'\n")
    out = out_all.split('\n')[0] # remove newline
    #print out
    #f.write("out is " + str(out) + "\n")
    f.write("Found average hex value #" + str(out) + " for " + image + "\n")
    f.close()
    return out # This is a hex value as a string

def image_pixel(value):
    # Create temp file with that hex value
    # convert -size 1x1 xc:#AE9E2F out.png
    filename = "/tmp/" + make_unique(12) + ".png"
    #cmd = "convert -size 1x1 xc:#" + value + " " + filename
    cmd = "/home/roomhints/devel/RH/website/mysite/roomhints/pixcolor.sh " + value + " " + filename
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out_all = p.communicate(input=the_input)[0]
    return filename
    
def score_images_average(one_color,two_color,itemname):
    f = open('/tmp/bhat','ab+')
    #f.write("score_images_average for " + one + " for " + itemname + "\n")
    diff_color, score = image_diff(one_color,two_color)
    f.write("diff_color " + str(diff_color) + " score " + str(score) + "\n")
    return score

# Bhattacharyya distance. Less is better
# http://docs.opencv.org/doc/tutorials/imgproc/histograms/histogram_comparison/histogram_comparison.html
def score_images_bhat(one,two,itemname):
    return score_images_comphist("bhat",one,two,itemname,3)

def score_images_correlation(one,two,itemname):
    return score_images_comphist("correlation",one,two,itemname,0)

def score_images_intersection(one,two,itemname):
    return score_images_comphist("intersection",one,two,itemname,2)

def score_images_comphist(kind,one,two,itemname,metric_index):
# e.g. Bhattacharyya distance in metric_index 3
# Method [0] Perfect, Base-Half, Base-Test(1): 1.000000, 0.999725, 0.809556
# Method [1] Perfect, Base-Half, Base-Test(1): 0.000000, 0.091376, 2016.540006
# Method [2] Perfect, Base-Half, Base-Test(1): 1.212333, 1.166819, 1.152306
# Method [3] Perfect, Base-Half, Base-Test(1): 0.000000, 0.133310, 0.732051
    cmd = 'export LD_LIBRARY_PATH=/usr/local/opencv-git/lib; /home/roomhints/devel/RH/imaging/test/comphist ' + str(one) + " " + str(two) + " " + " 2>&1"
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
    the_input = ''
    out_all = p.communicate(input=the_input)[0]
    out = out_all.split('\n')[metric_index] # remove newline
    f = open('/tmp/bhat','ab+')
    output = kind + "-" + str(metric_index) + " for " + itemname + " out for " + one + " " + two + " is:\n'" + out_all + "'\n"
    print out
    f.write(output)
    results = out.split(',')
    #f.write("results: " + str(results) + " with len " + str(len(results)) + "\n")
    #print results
    matches = -1
    if len(results) == 5:
        #f.write(kind + " for " + itemname + " matches IN\n")
        matches = float(results[4])
        f.write( kind + "-" + str(metric_index) + " for " + itemname + " matches:" + str(matches) + "\n")
        return matches
    else:
        return 0

def score_images(one,two):

      def get_extreme(val_str):
              #print val_str
          dist = float(val_str.split(':')[1])
              #print dist
          return dist

      p = subprocess.Popen('/home/roomhints/devel/RH/imaging/test/match_images.exit ' + one + " " + two + " 2>&1 | grep -v 'Failed to initialize'", shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.STDOUT)
      the_input = ''
      out = p.communicate(input=the_input)[0]
      #print "out is '" + out + "'"
      results = out.split('\n')
      #print results
      # We sometimes get results: [' --(!) Error reading images ', '']
      if not (len(results) == 2 or results[0] == 'OpenCV Error: Unsupported format or combination of formats (type=0'):
          max_dist = get_extreme(results[0])
          min_dist = get_extreme(results[1])
          #return 2 - min_dist + max_dist
          return 1 - max_dist
      else:
          return 0
