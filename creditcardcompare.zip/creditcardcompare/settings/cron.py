from settings.ccc import *


ON_CRON = True
INTERNAL_LINK = 'www.creditcardcompare.com.au'