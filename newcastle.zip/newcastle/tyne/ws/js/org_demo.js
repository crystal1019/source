//console.log('demo loaded..');
company_name = "AppointmentWorks";
var label = "Zip code:";
var type = 1;
org_string = "AWDemo";
rest_url = "/ws/broker/" + org_string + "/";
LOC_MAIN_OFFICE = 'Main Office';
LOC_DOWNTOWN_OFFICE = 'Downtown Office';
selected_req_id = 1;
selected_location = LOC_MAIN_OFFICE;
locationResourceMap ={};
locationResourceMap[LOC_MAIN_OFFICE] = 1;
locationResourceMap[LOC_DOWNTOWN_OFFICE] = 4;

selected_zip_code = '12300';
initialOptionsMap = {};
initialOptionsMap['12300'] = LOC_MAIN_OFFICE;
initialOptionsMap['12301'] = LOC_MAIN_OFFICE;
initialOptionsMap['12302'] = LOC_MAIN_OFFICE;
initialOptionsMap['12303'] = LOC_DOWNTOWN_OFFICE;
initialOptionsMap['12304'] = LOC_DOWNTOWN_OFFICE;

//

// Custom feilds function

var generateCustomFields = function(tmp_row) {
		
}
//--------

// Custome Fields validatin
var validateCustomFields = function() {
	
}
//-------
// Custom pcsvcs data function
var generateCustomData = function(inputs) {
	customAttributes = {}

	return customAttributes;
}

var clearCustomFields = function() {
	
}

var maskCustomFields = function() {
		
}
