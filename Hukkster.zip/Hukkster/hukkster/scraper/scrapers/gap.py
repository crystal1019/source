from .base_gap import BaseGapScraper


class GapScraper(BaseGapScraper):
    @staticmethod
    def get_domain():
        return 'www.gap.com'

    def _get_store(self):
        return 'gap'
