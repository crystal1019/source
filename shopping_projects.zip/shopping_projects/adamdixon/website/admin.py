from adamdixon.website.models import *
from django.contrib import admin
from django.contrib.sites.admin import SiteAdmin

class MiscPageAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'is_active', 'is_landing', 'priority')
    list_editable = ('is_active', 'is_landing', 'priority')
    prepopulated_fields = {'slug':('name',)}
    
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]
    
    
class CollectionAdmin(admin.ModelAdmin):
    list_display = ('name', 'priority', 'is_active')
    list_editable = ('priority', 'is_active')
    
    
admin.site.register(MiscPage, MiscPageAdmin)
admin.site.register(Collection,CollectionAdmin)
admin.site.register(FlashImage)

admin.site.unregister(Site)

class SiteMetaInline(admin.StackedInline):
    model = SiteMeta
    max_num = 1

class MySiteAdmin(SiteAdmin):
    model = Site
    list_display = ('domain', 'name')
    inlines = [SiteMetaInline,]
admin.site.register(Site, MySiteAdmin)