'''
@author: chaol
'''

from django.contrib import admin
from django.contrib.contenttypes import generic

from models import *

class StockistAdmin(admin.ModelAdmin):
    list_display = ('name', 'suburb', 'region')
    list_filter = ('region','sites')
    
class SellCategoryAdmin(admin.ModelAdmin):
    prepopulate_fields = {'slug':['name',]}

admin.site.register(Stockist, StockistAdmin)
admin.site.register(SellCategory, SellCategoryAdmin)