import os
from google.appengine.ext.webapp import template

from google.appengine.api import users

import datetime

import objects
import random
import masterpage

import method_db
import method_question
import method_user
import method_notification
import method_comment
import method_url
import method_email
import logging
import method_cache
	
class AddQuestion(masterpage.MasterPage):
	def getOrAddAttributes(self, dropdown_id, textbox_id, attribute_type):
		new_attribute = self.request.get(textbox_id).strip()
		current_attributes = self.request.get_all(dropdown_id)
		attributes = []
		
		for attribute_id in current_attributes:
			if attribute_id == '': # id is 0 -> "new" was selected
				if new_attribute:
					attribute = objects.Attribute.query(objects.Attribute.pretty_id == new_attribute).get()
					if attribute:
						attributes.append(attribute_id)
					else:	
						logging.info('new attribute: ' + attribute_id + ' ' + new_attribute)
						pretty_id = method_question.addAttribute(new_attribute, attribute_type)
						if pretty_id != '' and pretty_id != '-':
							attributes.append(pretty_id)
			elif attribute_id != '-':
				attributes.append(attribute_id)
		logging.info(attributes)
		return attributes
		
		
	def getCountry(self):
		int_attribute = self.request.get('dropdownCountry')
		if int_attribute == '': # id is 0 -> "new" was selected
			return self.request.get('OtherCountry')
		else:
			return int_attribute
			
	def validate(self, lst):
		for a in lst:
			if a <= 0:
				return False
		return True		  
		
	def updateAttributeCount(self, attribute_id, change_by):
		logging.info('updating ' + attribute_id + ' by ' + str(change_by))
		if change_by == 0:
			return
		attribute = objects.Attribute.query(objects.Attribute.pretty_id == attribute_id).get()
		if not attribute:
			return
		f = attribute.question_count
		attribute.question_count = f + change_by
		method_db.putObject(attribute)
	
	def incrementCountFromList(self, list1, list2, increment):		
		for a in list2:
			if a in list1:
				list1[a] = list1[a] + increment
			else:
				list1[a] = increment
				
	def checkForDup(self, body, questions):
		for q in questions:
			if q.text == body:
				return True
		questions_recent = objects.Question.query().order(-objects.Question.date).fetch(20)
		for q in questions_recent:
			if q.text == body:
				return True
		return False
	
	def deleteQuestion(self, qid):
		question = method_question.getQuestionWithId(qid)
		attributes = question.companies_pretty + question.topics_pretty + question.jobs_pretty
		for a in attributes:
			self.updateAttributeCount(a, -1)
		question.visible = False
		method_db.putObject(question)
		comments = method_comment.getCommentsWithAncestor(question.uid)
		for comment in comments:
			comment.visible = False
			method_db.putObject(comment)
		method_cache.clearObjectForTypeAndId('mainpage', None)		
	
	def moveToForum(self, qid):
		question = method_question.getQuestionWithId(qid)
		self.deleteQuestion(qid)			
		forum = objects.ForumPost()
		forum.author_id = question.author_id
		forum.author_name = question.author_name
		forum.author_image = question.author_image				
		subject = question.text[:30] + '...'
		subject = subject.replace('\n', '')
		forum.subject = subject
		forum.text = question.text
		forum.date = question.date
		forum.comment_count = question.comment_count
		forum_id = method_db.putObject(forum)
		comments = method_comment.getCommentsWithAncestor(question.uid)
		for comment in comments:
			self.response.out.write('Changed to forum ' + str(forum_id))
			comment.type = 'forum'
			comment.ancestor_id = forum_id
			if comment.parent_id == question.uid:
				comment.parent_id = forum_id
			method_db.putObject(comment)
		
		method_cache.clearObjectForTypeAndId('mainpage', None)
		method_notification.notifyUsersOfForum(forum)
		return forum
	
	def incrementAttributeCounter(self, attribute_counter, pid, delta):
		logging.info('incrementing: ' + pid + ' by ' + str(delta))
		if not pid in attribute_counter:
			attribute_counter[pid] = 0
		attribute_counter[pid] = attribute_counter[pid] + delta
	
	def post(self):
		if self.isSpammer():
			return		
		
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return
		if user.banned:
			self.putErrorMessage(user.banned_message)
			self.response.out.write(user.banned_message)
			return

		# get question metadata
		companies = self.getOrAddAttributes('dropdownCompanies[]', 'OtherCompany', 'company')  
		jobs = self.getOrAddAttributes('dropdownJobTitles[]', 'OtherJobTitle', 'job')		
		team = self.request.get('Team')
		country = self.getCountry()
		interviewType = None
		if self.request.get('dropdownInterviewType') != 'Other':
			interviewType = self.request.get('dropdownInterviewType')	

		if method_url.getId(self):
			max_id = 1000
		else:
			max_id = int(self.request.get('maxQuestionId'))
		logging.info('max id: ' + str(max_id))
		
		redirect_url = '' 
		
		count = 0
		is_deleting = False
		id = None
		
		questions = []
		added_new = True
		
		attribute_counter = {}
			
		if self.request.get('Delete'):
			self.deleteQuestion(method_url.getId(self))
			self.redirect('/')
			return
			
		if self.request.get('MoveToForum'):
			forum = self.moveToForum(method_url.getId(self))	
			self.redirect('/forumpost?id=' + str(forum.uid))
			return		
			
		for i in range(1000, max_id + 1):			
			# get / add topics
			topics = self.getOrAddAttributes('dropdownQuestionTypes' + str(i) + '[]', 'OtherCategory'  + str(i), 'topic')
			question_text = self.request.get('QuestionText' + str(i))
			if self.hasBannedText(question_text):
				self.response.out.write('Hey, please stop spamming us. I don\'t do that to your site, do I? Then don\'t do it to mine.')
				return				
			question = None
			if method_url.getId(self):
				question = method_question.getQuestionWithId(method_url.getId(self))
				if not question:
					self.redirect('/')
					return
				method_question.insertDeadQuestion(question)
				all_attributes = [] + question.companies_pretty + question.jobs_pretty + question.topics_pretty
				for a in all_attributes:
					self.incrementAttributeCounter(attribute_counter, a, -1)
				added_new = False			
			if question is None:
				question = objects.Question()
				question.author_id = user.uid
				question.author_image = user.image
				question.author_name = user.name
			
			# Set metadata
			question.text = question_text
			question.country = country
			question.team = team
			question.interview_type = interviewType
			question.last_comment = datetime.datetime.now() - datetime.timedelta(days=(365*10))

			# Set attributes
			question.companies_pretty = companies
			question.jobs_pretty = jobs
			question.topics_pretty = topics	
			
			if len(question.text) > 0 and ((question.uid is not None) or (self.checkForDup(question.text, questions) == False)):
				count = count + 1
				questions.append(question)				
						
		email_body = ''
		thread_id = None
		
		if len(questions) > 1:
			thread_id = int(random.random() * 100000)
			redirect_url = '/questionthread?id=' + str(thread_id)				
		
		for question in questions:
			question.thread_id = thread_id
			all_attributes = [] + question.companies_pretty + question.jobs_pretty + question.topics_pretty
			for a in all_attributes:
				self.incrementAttributeCounter(attribute_counter, a, 1)			
			quid = method_db.putObject(question, False)	
			if user:
				question = method_user.subscribeWithDelay(user, question)						
			if len(questions) == 1:
				redirect_url = '/question?id=' + str(quid)				
			self.addActivity(question.author_name, '/question?id=' + str(question.uid), '/images/question_activity.png', 'question', None, None, question.text)				
			method_question.clearQuestionCache(question, True)		
			attributes = question.companies_pretty + question.jobs_pretty + question.topics_pretty
			method_notification.notifyUsersOfQuestion(question, attributes)
			path = os.path.join(os.path.dirname(__file__), 'html/emailtemplate-question.html')
			email_body = email_body + template.render(path, {'body': question.text, 'uid': question.uid} ) 
		
		logging.info(attribute_counter)
		# Refresh attribute count
		for a in attribute_counter:
			self.updateAttributeCount(a, attribute_counter[a])
			attribute_counter[a] = 0
					
		# Email users	
		users = method_user.getUsersToEmailOnNewQuestion()
		if added_new:
			for u in users:
				subj_string = 'a new interview question'
				if count > 1:
					subj_string = str(count) + ' new interview questions'
				if count > 0 and added_new:
					method_email.sendEmail(None, u, questions[0].author_name + ' has added ' + subj_string, email_body, '', redirect_url)					

		method_cache.clearObjectForTypeAndId('mainpage', None)
		method_cache.clearObjectForTypeAndId('rss', None)
		method_cache.clearObjectForTypeAndId(masterpage.cache_key_attribute_menus, None)
		method_cache.clearObjectForTypeAndId(method_question.cache_key_attributes_list, 'company')
		method_cache.clearObjectForTypeAndId(method_question.cache_key_attributes_list, 'job')
		method_cache.clearObjectForTypeAndId(method_question.cache_key_attributes_list, 'topic')
			
		if redirect_url:
			self.redirect(redirect_url)
		else:
			self.redirect('/')
			

	def putErrorMessage(self, error_message):		
		self.request.get('lblError')
		error_message		  
		#self.response.out.write('<script>control = document.getElementById("lblError"); control.value = error_message; </script>')
	
		#path = os.path.join(os.path.dirname(__file__), 'html/addquestion.html')
		#self.response.out.write(template.render(path, template_values)) 
		
	
	def selectAttributes(self, all_attributes, selected_attributes):
		list = []
		for attribute in all_attributes:
			for selected_attribute in selected_attributes:
				if attribute.pretty_id == selected_attribute:
					attribute.selected = True
				else:
					attribute.selected = False
				break
			list.append(attribute)
		return list 
	
	def get(self):
		error_message = ''
		
		if method_user.getLoggedInUser() is None:
			self.redirectToLogin()	
			return	
		
		id = method_url.getId(self)
		if id:
			question = method_db.addInfoToObject(method_question.getQuestionWithId(id))
			'''	
			if not(method_user.userCanEdit(question)):
				if question:
					self.redirect('/question?id=' + str(question.uid))
				else:
					self.redirect('/categories')
				return'''
		else:
			question = None
		
		jobs = method_question.getAttributesByTypeSorted('job', 'alpha')
		topics = method_question.getAttributesByTypeSorted('topic', 'alpha')
		companies = method_question.getAttributesByTypeSorted('company', 'alpha')	 
		question_text = None
		country = None
		interviewType = None
		team = None
		
		if question:
			jobs = self.selectAttributes(jobs, question.jobs_pretty)
			topics = self.selectAttributes(topics, question.topics_pretty)
			companies = self.selectAttributes(companies, question.companies_pretty)
			question_text = question.text
			team = question.team
			interviewType = question.interview_type
			country = question.country
		else:
			for a in jobs:
				a.selected = "0"
			for a in topics:
				a.selected = "0"
			for a in companies:
				a.selected = "0"
		
		template_values = {
			'jobs': jobs,
			'topics': topics,
			'parent_tab': 'interviews',	
			'question_text': question_text,
			'team': team,
			'location': country,
			'interviewType': interviewType,
			'error_message': error_message,
			'companies': companies,
		}		 
		
		self.pushPage(template_values, 'Add Question', 'html/addquestion.html')	  
		
