import datetime
from haystack.indexes import *
from haystack import site
from arktotalwealth.website.models import *

class MiscPageIndex(SearchIndex):
    text = CharField(document=True, use_template=True)

site.register(MiscPage, MiscPageIndex)