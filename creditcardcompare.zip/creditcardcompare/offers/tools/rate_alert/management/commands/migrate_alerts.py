from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.contrib.sites.models import Site
from offers.tools.rate_alert.models import Alert
from offers.helpers.lead.helpers import save_lead
from offers.core.models import Offer


class Command(BaseCommand):
    def handle(self, *args, **options):
        Alert.objects.all().delete()
        alerts = User.objects.filter(is_staff=False)
        for alert in alerts:
            self.migrate(alert)
            
    def migrate(self, user):
        lead = save_lead({
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'email': user.email,
                    'source': 'BT Alert'
                })
        data = user.username.split('_')
        Alert.objects.create(lead=lead,
                             site=Site.objects.get(id=data[0]),
                             offer=Offer.objects.get(id=data[1]),
                             confirmed=user.is_active,
                             expiry=user.last_login)
        user.delete()
