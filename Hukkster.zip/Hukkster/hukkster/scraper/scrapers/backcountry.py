import logging
import re
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class BackCountryScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'backcountry.com'

    def extract_size(self, val):
        tmp = val.split('-')
        return tmp[-1]

    def extract_price(self, val):
        m = re.search(r'\(\$(\d+\.\d+)\)', val)
        if m is not None:
            return float(m.group(1))
        return 0.0

    def extract_image(self, soup, color, fallback):
        image = fallback
        li = soup.find('li', attrs={'data-img-title': color})

        if li is None:
            # Some variants are discontinued are tricky to find
            li = soup.find('li', attrs={'data-img-title': '%s (*Discontinued)' % color})

        if li is not None:
            try:
                image = 'http:%s' % li['data-large-img']
            except KeyError:
                pass

        return image

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        # SKU
        try:
            sku = soup.find('b', attrs={'itemprop': 'productID'}).text
            logging.debug('Extracted SKU')
        except AttributeError, e:
            logging.debug('Was not able to extract SKU: %s' % e.message)
            raise HukksterTooManyOptions(BackCountryScraper.get_domain(), self.url)

        selections = []
        for variant in soup.find_all('option', attrs={'value': re.compile(r'^%s' % sku)}):
            data = {
                'title': raw_data['title'],
                'current_price': {
                    'value': self.extract_price(variant.text)
                },
                'url': raw_data['url'],
                'store': raw_data['site_name'].lower(),
                'image': self.extract_image(soup, variant['data-img-title'], raw_data['image']),
                'local_id': sku,
                'selections': {
                    'size': self.extract_size(variant['value']),
                    'color': variant['data-img-title']
                }
            }
            selections.append(data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(BackCountryScraper.get_domain(), self.url)

        return selections
