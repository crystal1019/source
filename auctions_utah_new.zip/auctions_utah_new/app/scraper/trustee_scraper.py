__author__ = 'RJB'

import datetime
import json
import re
import requests
from dateutil.relativedelta import relativedelta
from dateutil import parser
from bs4 import BeautifulSoup
from app.scraper.settings import PROCESS_ROWS_DAYS_OUT
from app import models


#TODO incorporate get_rows into Parent class
#TODO simplify process_rows
#TODO remove all eligible variables into settings.py


class TrusteeScraper(object):
    def __init__(self, url):
        self.url = url

    def soupify(self):
        return BeautifulSoup(
            requests.get(
                self.url,
                headers={'User-Agent':
                         'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:35.0) Gecko/20100101 Firefox/35.0'}).content)

    @staticmethod
    def utahlegals_search(prop_dict, parsers):
        #search up to 90 days back
        # parser name format is get_*_from_text where * is one or more words separated by a '_'
        parser_names = ', '.join([i.__name__.split('_')[1] for i in parsers])
        print 'Cross referencing utahlegals.com for %s...' % parser_names
        search_date_lower_bounds = datetime.date.today()+relativedelta(days=-90)
        search_date_upper_bounds = datetime.datetime.now()
        print 'TSNumber: ', prop_dict['tsnumber']
        root_url   = "http://www.utahlegals.com/"
        search_url = root_url+"search.php?" \
                     "start={month}%2F{day}%2F{year}&" \
                     "end={month2}%2F{day2}%2F{year2}&" \
                     "action=search&" \
                     "paper=all&" \
                     "query={query}".format(month =search_date_lower_bounds.month,
                                            day   =search_date_lower_bounds.day,
                                            year  =search_date_lower_bounds.year,
                                            month2=search_date_upper_bounds.month,
                                            day2  =search_date_upper_bounds.day,
                                            year2 =search_date_upper_bounds.year,
                                            query =prop_dict['tsnumber'])
        r    = requests.get(search_url)
        search_soup = BeautifulSoup(r.content)
        article_previews = search_soup.find_all('div', {'class': 'ncontents'})
        target_links     = [preview.find('a', text='READ MORE') for preview in article_previews
                            if 'trustee' in preview.text[:70].lower()]
        now = search_date_upper_bounds
        if target_links:
            links_tried = 0
            for link in target_links:
                full_article_req = requests.get(root_url+link['href'])
                article_soup = BeautifulSoup(full_article_req.content)
                full_article_text = article_soup.find('div', {'style': 'text-align:left; padding:20px;'}).text
                #print "Full text: \n%s" % full_article_text
                #Check to see if one of the trustee partners' names is in the text
                if any((partner.replace(',', '').lower() in full_article_text.lower()) for partner in prop_dict['trustee'].split(' ')):
                    print 'Trustee: %s found in text. Initial criteria met!' % prop_dict['trustee']
                    data = dict(a_parser(full_article_text)
                                if a_parser.__name__.split('_')[1] != 'parcel' else
                                a_parser(full_article_text, prop_dict['county'])
                                for a_parser in parsers)
                    #print 'UTLegals data: ', data
                    p_values = data.values()  # represents only values derived from the parsers, does not include the ad itself
                    data['legal_ad'] = full_article_text
                    data['utahlegals_date'] = now
                    if 'name' in parser_names:
                        data['last_name'] = data['full_name'].split()[-1] if data['full_name'] else None
                    if all(p_values):
                        print 'All searches successful: %s, FOUND' % ', '.join(data.keys())
                        data.update({'utahlegals_incomplete': 0})
                        return data
                    elif any(p_values):
                        missing = ', '.join(k for k, v in data.items() if v is None)
                        print 'Searches partially sucessfull... %s NOT FOUND' % missing
                        data.update({'utahlegals_incomplete': '%s' % missing})
                        return data
                    elif links_tried >= 3:
                        print '%s NOT found in trustee ad!' % prop_dict['tsnumber']
                        data.update({'utahlegals_incomplete': 'Nothing Parced'})
                    links_tried += 1
        print 'Criteria(in order of search): {tsnumber}, {trustee},  NOT FOUND!'.format(
            tsnumber=prop_dict['tsnumber'], trustee=prop_dict['trustee'])
        return {'utahlegals_date': now, 'utahlegals_incomplete': 'No Search Results'}

    @staticmethod
    def get_parcel_number_from_text(text, county):
        county_patterns = {'Salt Lake': r'(?<=[":#.\s][\s\n])(\d{2}-\d{2}-\d{3}-\d{3}(?:\-{1}\d{4})?).*\s*\n*\s*.?[A-Za-z]+',
                           'Utah': r'\s(\d{2}[-:\s]\d{3}[-:\s]\d{4})[\s\n\.A-Za-z]'}
        parcel_pattern = re.compile(county_patterns[county])
        parcels = set(re.findall(parcel_pattern, text)) or None
        if parcels:
            print 'Parcel number(s): %s FOUND!' % '/'.join(parcels)
            return ('parcel_number', '/'.join(parcels))
        return ('parcel_number', None)

    @staticmethod
    def get_address_from_text(text):
        address_start_index = text.find('purported to be')
        #alt1 = (text.find('located at approximately'), 25)  # len=24
        if address_start_index >= 0:
            #print 'start index found: ', address_start_index
            #Find the end of the address using the chars proceeding the known pattern
            address_end_index    = text[address_start_index:].find('The') + address_start_index
            target_address    = text[address_start_index+len('purported to be')+1:address_end_index].replace('.', '').strip()
            print 'Address: %s, FOUND' % target_address
            return ('address', target_address)
        print 'Address NOT FOUND!'
        return ('address', None)

    @staticmethod
    def get_name_from_text(text):
        unique_phrase_before_name = 'executed by'
        name_start_index = text.find(unique_phrase_before_name)
        if name_start_index >= 0:
            #Find the end of the address using the chars proceeding the known pattern
            name_end_index = text[name_start_index:].lower().find('as')+name_start_index
            borrower_name = text[name_start_index+len(unique_phrase_before_name)+1:name_end_index].replace(',', '').strip()
            print 'Name: %s, FOUND' % borrower_name
            return 'full_name', borrower_name
        print 'Name NOT FOUND!'
        return 'full_name', None

    @staticmethod
    def convert_date_time_formats(date_time_in):
        """Takes a string representing a date in several formats and returns a datetime object"""
        time_obj_out = parser.parse(date_time_in)
        return time_obj_out

#TODO remove the county filter in complete entry

    @classmethod
    def complete_entry(cls, entry):
        """attempts to find values for certain missing fields
        by cross referencing utahlegals.com with the supplied parsers """
        result = set([])
        missing_keys = [k for k, v in entry.items() if v is None]
        for key in missing_keys:
            if 'name' in key:
                result.add(cls.get_name_from_text)
                continue
            print 'KEY: ', key
            print 'Missing: ', missing_keys
            if 'parcel' in key and entry['county'] in ['Salt Lake', 'Utah']:
                result.add(cls.get_parcel_number_from_text)
                continue
            if 'address' in key:
                result.add(cls.get_address_from_text)
        completed = cls.utahlegals_search(entry, result)
        entry.update(completed)
        return None

    def process_rows(self, array, row_formatter):
        """takes in a trustee scrape (collection of rows) and a function to format rows
        then maps the values to db column names with the elements:
        datetime, county, address, borrower, tsnumber, status, opening_bid...
        Returns a log of elements processed"""
        columns = ("trustee", "sale_date", "address", "county",
                   "full_name", "last_name", "tsnumber", "status", "opening_bid")
        now = datetime.datetime.now()
        date = None
        skip_next_row = False
        for row in array:
            print 'Unprocessed row: ', row
            try:
                entry_in_element = row_formatter(row)
            except TypeError:
                #accounts for ScalleyReading table format where the sale date is in the first table header row
                if skip_next_row:
                    #skips second header row
                    skip_next_row = False
                    continue
                elif 'TRUSTEE SALE' in row[0]:
                    print 'Searching for date... '
                    #contains the date
                    string_containing_date = row[0]
                    date_start_indx = string_containing_date.find('FOR')+4
                    date = string_containing_date[date_start_indx:]
                    print 'Date FOUND!\n'
                    #set to skip header row which always follows row containing date
                    skip_next_row = True
                    continue
                else:
                    entry_in_element = row_formatter(row, date)
            print 'Unpacking: ', row
            print 'Examining: ', entry_in_element
            subject_date = entry_in_element[1]
            print 'Element date: ', subject_date
            #Only process rows that are within x days of today
            days = PROCESS_ROWS_DAYS_OUT
            if now + relativedelta(days=days) >= subject_date > now:
                print 'WITHIN %s days. Processing...' % days
                mapped_entry = dict(zip(columns, entry_in_element))
                mapped_entry['scraped_row'] = '|'.join(row)
                mapped_entry['parcel_number'] = mapped_entry.get('parcel_number')
                print 'Preliminary entry: ', mapped_entry
                self.complete_entry(mapped_entry)
                #missing = [key for key, value in complete.items() if value is None]
                #print "Not complete: %s\nMissing: %s" % (complete, missing)
                print 'COMPLETED: ', mapped_entry
                prepped_entry = models.Properties(**mapped_entry)
                prepped_entry.bid_to_int()
                prepped_entry.update_or_save()
                print '\n'
            #All trustee sites list properties in ascending order based on auction date
            # once we reach a date greater than our upper bounds we can assume all other dates are greater
            elif subject_date > now+relativedelta(days=days):
                print 'Reached date outer-bounds!'
                break
            else:
                print 'Criteria not met, PASSING...\n'
        print 'Task: %s, is DONE\n\n\n' % self.__class__.__name__
        return


class SRScraper(TrusteeScraper):
    name = 'Scalley Reading'

    def entry_formatter(self, element, date):
        """takes in an applicable date and a list of fields ordered:
        tsnumber, name, county, courthouse, address, time, opening bid, status
        returns a tuple of format:
        (trustee, sale_datetime, address, county, full_name, last_name, tsnumber, status, bid)"""
        #columns = ("trustee", "sale_date", "preproc_address", "county", "full_name", "name", "tsnumber", "status", "opening_bid")
        try:
            tsnumber, name, county, crths, address, time, bid, status = element
            #status = "Opening Bid: %s, Status: %s" % (bid, sts)
        except ValueError:
            try:
                tsnumber, name, county, crths, address, time, val = element
                if '$' in val:
                    bid = val
                    status = ''
                else:
                    status = val
                    bid = ''
            except ValueError:
                tsnumber, name, county, crths, address, time = element
                bid = ''
                status = ''
        trustee       = self.name
        full_name     = name
        last_name     = name.replace(',', ' ').split()[0]
        sale_datetime = self.convert_date_time_formats(date+' '+time)
        return trustee, sale_datetime, address, county, full_name, last_name, tsnumber, status, bid

    def get_rows(self):
        soup = self.soupify()
        rows = soup.find('table').find_all('tr')
        rows_array = ([element for element in row.stripped_strings] for row in rows)
        return rows_array

    def run(self):
        rows = self.get_rows()
        self.process_rows(rows, self.entry_formatter)


class LundbergScraper(TrusteeScraper):
    name = 'Lundberg eTitle'

    def get_csv(self):
        r = requests.get("http://lundbergfirm.com/upload/SaleSched.CSV")
        csv = r.content.split('\r\n')
        for i in csv:
            prop = models.Properties()
            row = i.split(',')
            try:
                prop.county = row[1]
                prop.sale_date = parser.parse(' '.join([row[0], row[2]]))
                prop.full_name = row[3]
                if '$' in row[-1]:
                    prop.opening_bid = row[-1]
                else:
                    if '$' in row[-2]:
                        prop.opening_bid = ','.join(row[-2:])
                if 'post' in row[-1].lower():
                    prop.status = row[-1]
                if row[-1] == '' or 'post' in row[-1].lower() or '$' in row[-1]:
                    prop.tsnumber = row[-2]
                else:
                    prop.tsnumber = row[-3]
                if '$' in row[-1] or '' == row[-1] or 'post' in row[-1].lower():
                    prop.address = ','.join(row[4:-2])
                else:
                    prop.address = ','.join(row[4:-3])
                prop.bid_to_int()
            except IndexError:
                if row != ['']:
                    prop.proc_status = 'not end of row Lundberg error. ROW: %s' % row
                break
            days = PROCESS_ROWS_DAYS_OUT
            now = datetime.datetime.now()
            print 'Prop sale date: ', prop.sale_date
            print 'Within range: ', now + relativedelta(days=days) >= prop.sale_date
            if now + relativedelta(days=days) >= prop.sale_date > now:
                print 'WITHIN %s days. Processing...' % days
                prop.scraped_row = i
                mapped_entry = prop.__dict__
                print 'Preliminary entry: ', mapped_entry
                self.complete_entry(mapped_entry)
                print 'COMPLETED: ', mapped_entry
                prepped_entry = models.Properties(**mapped_entry)
                prepped_entry.update_or_save()
                print '\n'
            elif prop.sale_date > (now + relativedelta(days=days)):
                print 'Reached date outer-bounds!'
                break
            else:
                print 'Criteria not met, PASSING...\n'
        print 'Task: Lundberg, is DONE\n\n\n'

    def soupify(self):
        return BeautifulSoup(requests.post(self.url, {'agree': 'true'}).content)

    def entry_formatter(self, element):
        """Takes in an element containing values in the format =
        ('date', 'county', 'time', 'borrower', 'address', 'tsnumber', 'starting bid') and returns the format:
        ("trustee", "datetime", "address", "county", "full_name", "last_name", "tsnumber", "status", "opening bid")"""
        #columns = ("trustee", "sale_date", "preproc_address", "county", "full_name", "name", "tsnumber", "status", "opening_bid"
        try:
            dt, cnty, tm, bwr, adr, tsn, stbd = element
            if '$' in stbd:
                bid = stbd
                status = ''
            else:
                status = stbd
                bid = ''
        except ValueError:
            #no starting bid present
            try:
                dt, cnty, tm, bwr, adr, tsn = element
                bid = ''
                status = ''
            except ValueError:
                #No time is present
                dt, cnty, bwr, adr, tsn = element
                bid = ''
                status = ''
                tm = ''
        try:
            date = self.convert_date_time_formats(dt+' '+tm)
        except ValueError:
            date = self.convert_date_time_formats(dt)
        trustee  = self.name
        fullname = bwr
        return trustee, date, adr, cnty, fullname, bwr, tsn, status, bid

    def get_rows(self):
        soup = self.soupify()
        rows = soup.find('table', {'id': 'etitles'}).find('tbody').find_all('tr')
        rows_array = ([element for element in row.stripped_strings] for row in rows)
        return rows_array

    def run(self):
        rows = self.get_rows()
        self.process_rows(rows, self.entry_formatter)


class MHScraper(TrusteeScraper):
    name = 'Matheson Howell'
    #columns = ("trustee", "sale_date", "preproc_address", "county", "full_name", "name", "tsnumber", "status", "opening_bid"

    def entry_formatter(self, element):
        """Takes in an element containing values in the format =
        ('date', 'county', 'time', 'tsnumber', 'borrower', 'starting bid', 'status') and returns the format:
        ("trustee", "datetime", "address", "county", "full_name", "last_name", "tsnumber", "status", "opening bid")"""
        try:
            date, county, time, tsnumber, name, bid, status = element
        except ValueError:
            try:
                date, county, time, tsnumber, name, val = element
                if '$' in val:
                    bid = val
                    status = ''
                else:
                    status = val
                    bid = ''
            except ValueError:
                date, county, time, tsnumber, name = element
                status = ''
                bid = ''
        trustee = self.name
        sale_date = self.convert_date_time_formats(date+' '+time)
        address = None
        fullname = name
        return trustee, sale_date, address, county, fullname, name, tsnumber, status, bid

    def get_rows(self):
        soup = self.soupify()
        rows = soup.find('table').find_all('tr')
        rows_array = ([element for element in row.stripped_strings] for row in rows)
        return rows_array

    def run(self):
        rows = self.get_rows()
        self.process_rows(rows, self.entry_formatter)


class HWMScraper(TrusteeScraper):
    name = 'Halliday, Watkins, Mann'

    def entry_formatter(self, element):
        """Takes in an element containing values in the format =
        ('tsnumber', 'county', 'sale_date', 'sale_time', 'address', 'starting bid', 'ending_bid', 'bid_type', 'status')
        and returns the format:
        ("trustee", "datetime", "address", "county", "full_name", "last_name", "tsnumber", "status", "opening bid")"""
        #hwm_format = tsnumber, county, sale_date, sale_time, address, starting_bid, ending_bid, bid_type, status
        #columns = ("trustee", "sale_date", "preproc_address", "county", "full_name", "name", "tsnumber", "status", "opening_bid"
        try:
            tsnumber, county, sale_date, sale_time, address, starting_bid, ending_bid, bid_type, sts = element
        except ValueError:
            tsnumber, county, sale_date, sale_time, address, starting_bid, ending_bid, bid_type = element
            sts = ''
        dtm = self.convert_date_time_formats(sale_date+' '+sale_time)
        status = "Ending Bid: {eb}, Bid Type: {bt}, Sale Status: {st}".format(eb=ending_bid,
                                                                              bt=bid_type,
                                                                              st=sts)

        fullname = None
        last_name = None
        trustee = self.name
        return trustee, dtm, address, county, fullname, last_name, tsnumber, status, starting_bid

    def get_rows(self):
        soup       = self.soupify()
        table_body = soup.find('table', {'border': "1"})
        rows       = table_body.find_all('tr')[1:]
        rows_array = ([field.replace(u'\xa0', '') for field in row.strings]for row in rows)
        return rows_array

    def run(self):
        rows = self.get_rows()
        self.process_rows(rows, self.entry_formatter)


class SmithKnowlesScraper(TrusteeScraper):
    name = 'Smith Knowles'

    def entry_formatter(self, element):
        """Takes in an element containing values in the format =
        ('date', 'county', 'address', 'city', 'time', 'full_name', 'tsnumber', 'starting bid', 'status')
        and returns the format:
        ("trustee", "datetime", "address", "county", "full_name", "last_name", "tsnumber", "status", "opening bid")"""
        #columns = ("trustee", "sale_date", "preproc_address", "county", "full_name", "name", "tsnumber", "status", "opening_bid"
        try:
            date, county, address, city, time, borrower, tsnumber, start_bid, status = element
        except ValueError:
            date, county, address, city, time, borrower, tsnumber, start_bid = element
            status = ''
        dtm          = date+' '+time
        full_address = address+', '+city
        last_name    = borrower.replace(',', ' ').replace('.', ' ').replace('/', ' ').replace('(', ' ').replace(')', ' ').split()[0]
        trustee      = self.name
        new_elmnt    = (trustee, self.convert_date_time_formats(dtm), full_address, county,
                        borrower, last_name, tsnumber, status, start_bid)
        return new_elmnt

    def get_rows(self):
        soup       = self.soupify()
        table_body = soup.find('table', {'class': 'foreclosure-table'}).find('tbody')
        rows       = table_body.find_all('tr')
        rows_array = ([field for field in row.stripped_strings]for row in rows)
        return rows_array

    def run(self):
        rows = self.get_rows()
        self.process_rows(rows, self.entry_formatter)


class WoodallScraper(TrusteeScraper):
    name = 'Woodall'

    def entry_formatter(self, element):
        """Takes in an element containing values in the format =
        ('tsnumber', 'full_name', 'county', 'sale_datetime', 'address', 'city', 'status')
        and returns the format:
        ("trustee", "datetime", "address", "county", "full_name", "last_name", "tsnumber", "status", "opening bid")"""
        #woodall_format = ('tsnumber', 'borrower', 'county', 'date', 'time', 'address', 'city', 'status')
        #columns = ("trustee", "sale_date", "preproc_address", "county", "full_name", "name", "tsnumber", "status", "opening_bid"
        tsn, bwr, cnty, dtm, adr, cty, sts = element
        dt_tm        = self.convert_date_time_formats(dtm)
        full_address = adr+', '+cty
        last_name    = bwr.replace(',', ' ').replace('.', ' ').split()[0]
        bid          = ''
        trustee      = self.name
        result       = (trustee, dt_tm, full_address, cnty, bwr, last_name, tsn, sts, bid)
        return result

    def get_rows(self):
        row_kw = "aaData"
        row_dict = json.loads(requests.get(self.url).content)
        rows_array = row_dict[row_kw]
        return rows_array

    def run(self):
        rows = self.get_rows()
        self.process_rows(rows, self.entry_formatter)


def stoxscraper():
    """gets all Orange Title Co. listing from stox.com next x days where x is set in
    variable: PROCESS_ROWS_DAYS_OUT"""
    sess = requests.session()
    sess.headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:35.0) Gecko/20100101 Firefox/35.0'
    linkbase = 'https://jcstock.quickbase.com/db/'
    print 'Getting listings for Orange Title Co...'
    r = sess.get(linkbase+'bhty6arcz?a=q&qskip=0&qrppg=200&dlta=smdX65~')
    soup = BeautifulSoup(r.content)
    rows = soup.find('table', {'class': 'searchResults'}).find_all('tr', {'canview': "true"})
    rows = reversed(rows)  # reversed to make the list ascending by date so we can break out of the loop before processing all entries
    now = datetime.datetime.now()
    search_date_outer_bounds = now + datetime.timedelta(days=PROCESS_ROWS_DAYS_OUT)
    for row in rows:
        row_elements = [string for string in row.strings]
        print 'Row elements: ', row_elements
        print 'Sale date: ', row_elements[14]
        # [14] is sale date [16] is sale time
        sale_dtm = datetime.datetime.strptime(row_elements[14]+' '+row_elements[16], r'%m-%d-%Y %H:%M %p')
        if sale_dtm > search_date_outer_bounds:
            print 'Reached date outer bounds for STOX Scraper!'
            break
        prop = models.Properties(sale_date=sale_dtm)
        # only processes 'Orange Title' for now
        if (now <= sale_dtm <= search_date_outer_bounds) and 'orange' in row_elements[4].lower():
            print 'Date for %s within range (%s), processing...' % (row_elements[6], sale_dtm)  # [6] is tsnumber
            _, _, _, _, \
                prop.trustee, \
                _, \
                prop.tsnumber, \
                _, \
                prop.county, \
                _, \
                prop.address, \
                _, \
                prop.full_name, \
                _, _, _, _, _, \
                prop.opening_bid, \
                _, _, _, \
                prop.status,\
                _ = row_elements
            prop.county = prop.county[:-7]
            prop.last_name = prop.full_name.split()[-1]
            prop.opening_bid = prop.opening_bid.strip(u'\xa0')
            prop.scraped_row = '|'.join(element for element in row_elements if element)
            detail_link = row.find('a', {'class': 'ViewRecordIcon Tipsy'})['href']  # details page contains parcel number
            print 'Property detail link FOUND: ', linkbase+detail_link
            print 'Getting parcel number...'
            details_request = sess.get(linkbase+detail_link)
            detail_soup = BeautifulSoup(details_request.content)
            # tdf_11 is id of cell containing parcel info
            prop.parcel_number = detail_soup.find('td', {'id': 'tdf_11'}).text
            print 'Parcel number FOUND: ', prop.parcel_number
            utah_legals_link = detail_soup.find('td', {'id': 'tdf_45'}).text.replace(u'\xa0', '')
            utah_legals_link = utah_legals_link[utah_legals_link.rfind('http://'):]  # cut off 'http://' doubles
            if utah_legals_link and utah_legals_link.startswith('http://'):
                print 'utahlegals.com link found: ', utah_legals_link
                print 'Getting legal ad from utahlegals.com...'
                try:
                    ul_request = sess.get(utah_legals_link)
                except requests.ConnectionError:
                    print 'Bad utahlegals.com link: ', utah_legals_link
                    print 'Searching utahlegals.com... '
                    search_date_lower_bounds = datetime.date.today()+relativedelta(days=-90)
                    search_date_upper_bounds = datetime.datetime.now()
                    print 'TSNumber: ', prop.tsnumber
                    root_url   = "http://www.utahlegals.com/"
                    search_url = root_url+"search.php?" \
                                 "start={month}%2F{day}%2F{year}&" \
                                 "end={month2}%2F{day2}%2F{year2}&" \
                                 "action=search&" \
                                 "paper=all&" \
                                 "query={query}".format(month =search_date_lower_bounds.month,
                                                        day   =search_date_lower_bounds.day,
                                                        year  =search_date_lower_bounds.year,
                                                        month2=search_date_upper_bounds.month,
                                                        day2  =search_date_upper_bounds.day,
                                                        year2 =search_date_upper_bounds.year,
                                                        query =prop.tsnumber)
                    r    = requests.get(search_url)
                    search_soup = BeautifulSoup(r.content)
                    article_previews = search_soup.find_all('div', {'class': 'ncontents'})
                    target_links     = [preview.find('a', text='READ MORE') for preview in article_previews
                                        if 'trustee' in preview.text[:70].lower()]
                    now = search_date_upper_bounds
                    ul_request = None
                    if target_links:
                        links_tried = 0
                        for link in target_links:
                            full_article_req = requests.get(root_url+link['href'])
                            article_soup = BeautifulSoup(full_article_req.content)
                            full_article_text = article_soup.find('div', {'style': 'text-align:left; padding:20px;'}).text
                            #print "Full text: \n%s" % full_article_text
                            #Check to see if one of the trustee partners' names is in the text
                            if any((partner.replace(',', '').lower() in full_article_text.lower())
                                   for partner in prop.trustee.split(' ')):
                                ul_request = full_article_req
                                break
                            if links_tried >= 3:
                                print '%s NOT found in trustee ad!'
                                prop.utahlegals_incomplete = 'Nothing Parced, no results for tsnumber.'
                                break
                            links_tried += 1
                if not prop.utahlegals_incomplete:
                    ul_soup = BeautifulSoup(ul_request.content)
                    prop.legal_ad = ul_soup.find('div', {'style': 'text-align:left; padding:20px;'}).\
                        find('p').text.replace(u'\xa0', '')
                    prop.utahlegals_date = now
                    print 'Full article: ', prop.legal_ad
            prop.bid_to_int()
            prop.update_or_save()
        else:
            print 'Criteria not met, passing...'
    finished_time = datetime.datetime.now()
    diff = finished_time - now
    print 'STOX scraper finished in: ', diff


TRUSTEES = {LundbergScraper.__name__:       {'class': LundbergScraper, 'root_url': 'http://lundbergfirm.com/', 'pages': ['foreclosures']},
            MHScraper.__name__:             {'class': MHScraper, 'root_url': 'http://www.mathesonhowell.com/', 'pages': ['foreclosures/']},
            HWMScraper.__name__:            {'class': HWMScraper, 'root_url': 'http://halliday-watkins.com/', 'pages': ['index.php?id=23']},
            SmithKnowlesScraper.__name__:   {'class': SmithKnowlesScraper, 'root_url': "http://www.smithknowles.com/", 'pages': ["pending_foreclosure.php"]},
            WoodallScraper.__name__:        {'class': WoodallScraper, 'root_url': "http://www.utahtrustee.com/", 'pages': ["utilities/server_processing_pending.php"]},
            SRScraper.__name__:             {'class': SRScraper, 'root_url': 'http://www.scalleyreading.net/', 'pages': ['index.php/trustee/currentTrusteeSales', 'index.php/trustee/futureTrusteeSales']}}


def get_trustee_data(key, trustees=TRUSTEES):
    for page in trustees[key]['pages']:
        inst = trustees[key]['class'](trustees[key]['root_url']+page)
        inst.run()


def run_trustee_scrapers():
    for i in TRUSTEES.keys():
        get_trustee_data(i)
    stoxscraper()
    #berg = LundbergScraper('http://lundbergfirm.com/')
    #berg.get_csv()


if __name__ == "__main__":
    run_trustee_scrapers()