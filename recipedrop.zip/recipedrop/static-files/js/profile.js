$(document).ready(function () {

    // no blogs for now
    $('#blog').hide();

    function handle_photo_upload(file, resp) {
        var filename = file.file.name;
        var img_url = $('#photo_url').val();
        $('#profile_photo').find('img').attr('src', img_url +
                                            '?' + (new Date()).getTime());
        if (resp.upload_url) {
            $('input[name=upload_url]').val(resp.upload_url);
        }
        $('#delete_photo').show();
        // TODO: upload_data?
    }

    function photo_deleted() {
        var $img = $('#profile_photo').find('img');
        var src = $img.attr('src');
        $img.attr('src', src + '?' + (new Date()).getTime());
        $('#delete_photo').hide();
    }

    function init_photo() {
        var ava_url = $('.avatar').data('photo');
        $('.avatar').css('background', 'url(' + ava_url +
                         ') no-repeat center top');
    }

    function init_photo_upload() {
        var $delete_photo_form = $('#delete_photo_container').find('form');
        var csrf = $('input[name=csrfmiddlewaretoken]').val();

        if ($('#is_me').val() === 'True') {
            $('#profile_photo').draggify().init({
                multi: true,
                upload_on_drag: true,
                single_upload_done: handle_photo_upload,
                upload_url: $('#upload_url').val(),
                extra_data: {
                    csrfmiddlewaretoken: csrf
                }
            });

            $delete_photo_form.ajaxify(util.ajax_form_opts($delete_photo_form,
                                                           photo_deleted));

            $('#delete_photo').live('click', function () {
                $('#delete_photo_form input[type=submit]').click();
            });
        }       
    }

    function init_edit_form() {
        $('#edit').click(function () {
            $('#edit_container').show();
            $('#profile_container').hide();
            init_photo_upload();
        });
    }

    // Friend requests    

    function send_friend_request() {
        $('#friend_request_form').find('input[type=submit]').click();
    }

    function approve_friend_request() {
        $('#friend_approve_form').find('input[type=submit]').click();
    }

    function unfriend() {
        $('#unfriend_form').find('input[type=submit]').click();
    }

    function hide_friend_action(resp) {
        $('#friend_result').html(resp);
        $('#friend_result').show();

        $.get(
            $('#friend_action_url').val(),
            function (resp) {
                $('#friend_action').html(resp);
            }
        );

        $.get(
            $('#profile_data_url').val(),
            function (resp) {
                $('#profile_container #profile_data .inner-content').html(resp);
            }
        );
    }

    function init_friend_actions() {
        var friend_action_forms = [
            $('#friend_request_container').find('form'),
            $('#friend_approve_container').find('form'),
            $('#unfriend_container').find('form')
        ];

        $('#friend').live('click', send_friend_request);
        $('#friend_approve').live('click', approve_friend_request);
        $('#unfriend').live('click', unfriend);
        $('#friend_result').hide();

        $(friend_action_forms).each(function (i, $form) {
            $form.ajaxify(util.ajax_form_opts($form, hide_friend_action));
        });
    }

    function init_blog_toggle() {
        $('.profile_tab').click(function () {
            var activate = $(this).attr('data-activate');

            $('.profile_tab').each(function (i, tab) {
                var activate = $(tab).attr('data-activate');
                $('#' + activate).hide();
            });

            $('#' + activate).show();
            $('.profile_tab').removeClass('active');
            $(this).addClass('active');
        });
    }

    function handle_edit_errors() {
        // Return to edit form if there were errors
        var edit_errors = ($("#edit_errors").length > 0);
        if (edit_errors) {
            window.location.hash = 'edit';
        }
    }

    function parse_url_for_edit() {
        var url_parts = window.location.href.split('#');
        if (url_parts.length > 1) {
            if (url_parts[1] === 'edit') {
                $('#edit').click();
            } else if (url_parts[1] === 'blog') {
                $('li.profile_tab[data-activate=blog] a').click();
            }
        }
    }

    init_photo();
    init_edit_form();
    init_friend_actions();
    // init_blog_toggle();
    handle_edit_errors();
    parse_url_for_edit();

});