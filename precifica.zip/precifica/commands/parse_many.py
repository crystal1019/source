import logging

from w3lib.url import is_url

from scrapy.commands.parse import Command as ParseCommand
from scrapy.http import Request
from scrapy.exceptions import UsageError

logger = logging.getLogger(__name__)


class Command(ParseCommand):
    def syntax(self):
        return "[options] [urls]"

    def start_parsing(self, urls, opts):
        requests = [self.prepare_request(Request(url, opts.callback), opts)
                    for url in urls]

        self.pcrawler.crawl(self.spider, requests)
        self.crawler_process.start()

        if not self.first_response:
            log.msg(format='No response downloaded for: %(requests)s',
                    level=log.ERROR, requests=requests)

    def run(self, args, opts):
        if not args or not all(map(is_url, args)):
            raise UsageError()
        else:
            urls = args

        self.pcrawler = self.crawler_process.create_crawler()
        self.set_spider(urls[0], opts)

        if self.spider and opts.depth > 0:
            self.start_parsing(urls, opts)
            self.print_results(opts)
