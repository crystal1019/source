//console.log('pcsvcs loaded..');
company_name = "Panhandle Community Services"
var label = "Site: ";
var type = 2;
org_string = "PCSVCS";
rest_url = "/ws/broker/" + org_string + "/";
next_url = "http://www.pcsvcs.org/"

timezone = "America/Chicago"

selected_req_id = 1;

SITE_AMARILLO  = "Amarillo"
SITE_BORGER  = "Borger"
SITE_CHILDRESS = "Childress"
SITE_CLARENDON  = "Clarendon"
SITE_DALHART  = "Dalhart"
SITE_DIMMITT  = "Dimmitt"
SITE_DUMAS  = "Dumas"
SITE_HEREFORD  = "Hereford"
SITE_PAMPA  = "Pampa"
SITE_PERRYTON  = "Perryton"
SITE_TULIA  = "Tulia"
SITE_WELLINGTON  = "Wellington"


selected_location = SITE_AMARILLO;

locationResourceMap ={};
locationResourceMap[SITE_AMARILLO] = "1";
locationResourceMap[SITE_BORGER] = "2";
locationResourceMap[SITE_CHILDRESS] = "3";
locationResourceMap[SITE_CLARENDON] = "4";
locationResourceMap[SITE_DALHART] = "5";
locationResourceMap[SITE_DIMMITT] = "6";
locationResourceMap[SITE_DUMAS] = "7";
locationResourceMap[SITE_HEREFORD] = "8";
locationResourceMap[SITE_PAMPA] = "9";
locationResourceMap[SITE_PERRYTON] = "10";
locationResourceMap[SITE_TULIA] = "11";
locationResourceMap[SITE_WELLINGTON] = "12";

groupId ={};
groupId[SITE_AMARILLO] = "17";
groupId[SITE_BORGER] = "15";
groupId[SITE_CHILDRESS] = "27";
groupId[SITE_CLARENDON] = "23";
groupId[SITE_DALHART] = "5";
groupId[SITE_DIMMITT] = "7";
groupId[SITE_DUMAS] = "13";
groupId[SITE_HEREFORD] = "9";
groupId[SITE_PAMPA] = "19";
groupId[SITE_PERRYTON] = "21";
groupId[SITE_TULIA] = "11";
groupId[SITE_WELLINGTON] = "25";

initialOptionsLabel = "Site: ";
selectedOption = SITE_AMARILLO;

initialOptionsMap ={};

initialOptionsMap[SITE_AMARILLO] = SITE_AMARILLO;
initialOptionsMap[SITE_BORGER] = SITE_BORGER;
initialOptionsMap[SITE_CHILDRESS] = SITE_CHILDRESS;
initialOptionsMap[SITE_CLARENDON] = SITE_CLARENDON;
initialOptionsMap[SITE_DALHART] = SITE_DALHART;
initialOptionsMap[SITE_DIMMITT] = SITE_DIMMITT;
initialOptionsMap[SITE_DUMAS] = SITE_DUMAS;
initialOptionsMap[SITE_HEREFORD] = SITE_HEREFORD;
initialOptionsMap[SITE_PAMPA] = SITE_PAMPA;
initialOptionsMap[SITE_PERRYTON] = SITE_PERRYTON;
initialOptionsMap[SITE_TULIA] = SITE_TULIA;
initialOptionsMap[SITE_WELLINGTON] = SITE_WELLINGTON;


// Custom fields function

var col_half_class = "dt_col_half";
var zipCode_class = "zipcode";
var site_class = 'site';

var generateCustomFields = function(tmp_row) {
	console.log('CustomFields in pcsvcs');
	
	// add the zip code field
	 var tmp_col_half4 = $("<div>")                
                  .addClass(col_half_class)
                  .appendTo(tmp_row);                      
     $("<div>").text("Zip code: ")
             .appendTo(tmp_col_half4 );   
     $("<input id='zipCode'>")
             .attr("type", "text")
             .attr("placeholder", "Zip code")
             .addClass(zipCode_class)
             .appendTo(tmp_col_half4 ); 	
     
     //-------------------------------------------
     
     // add the site code field        
     // var tmp_col_half5 = $("<div>")                
                  // .addClass(col_half_class)
                  // .appendTo(tmp_row);                      
     // $("<div>").text("Email: ")
             // .appendTo(tmp_col_half5 );   
     // $("<input>")
             // .attr("type", "text")
             // .attr("placeholder", "Site")
             // .addClass(site_class)
             // .appendTo(tmp_col_half5 ); 
}
//--------

// Custome Fields validatin
var validateCustomFields = function() {
	console.log('Custom validate');
	
	var zipCode = $('.'+zipCode_class).val();
	//var site = $('.'+site_class).val();
	
	var zipReg =  /(^\d{5}$)|(^\d{5}-\d{4}$)/;
	if(!zipCode.match(zipReg)) {  
	  return 0;
	}
	return 1;
}
//-------
// Custom pcsvcs data function
var generateCustomData = function() {
	
	console.log("S: "+site);
	
	customAttributes = [];
	
	customAttributes[0] = {};
	customAttributes[0]['attributeId'] = 5;
	customAttributes[0]['attributeValue'] = $(".dt_phonenumber").val().replace(/[^0-9]/g,'');

	customAttributes[1] = {};
	customAttributes[1]['attributeId'] = 6;
	customAttributes[1]['attributeValue'] = $('.'+zipCode_class).val();
	
	//site attribute
	customAttributes[2] = {};
	customAttributes[2]['attributeId'] = 7;
	customAttributes[2]['attributeValue'] = site;
	
		
	return customAttributes;
}

var clearCustomFields = function() {
	// $("#zipCode").val("");
	// $("#email").val("");
}

var maskCustomFields = function() {
	$("#zipCode").mask("99999");
}
