import os, sys
from settings.ccc import *


# DEBUG = True
# TEMPLATE_DEBUG = DEBUG
# COMPRESS_ENABLED = False
# SPACELESS_HTML = False

EMAIL_SUBJECT_PREFIX = '[STAGING CCC ALERT]'

DATABASES = {
    'default': {
        'NAME': conf.get('database-staging', 'NAME'),
        'ENGINE': 'django.db.backends.mysql',                      
        'USER': conf.get('database', 'USER'),
        'PASSWORD': conf.get('database', 'PASSWORD'),
        'HOST': conf.get('database', 'HOST'),
    },
    'ccc_blog': {
        'NAME': conf.get('database-blog', 'NAME'),
        'ENGINE': 'django.db.backends.mysql',
        'USER': conf.get('database', 'USER'),
        'PASSWORD': conf.get('database', 'PASSWORD'),
        'HOST': conf.get('database', 'HOST'),
    }
}

AWS_STORAGE_BUCKET_NAME = conf.get('aws', 'AWS_STORAGE_BUCKET_NAME_STAGING')
AWS_S3_CUSTOM_DOMAIN = 'static.staging.' + SITE_NAME
STATIC_URL = 'http://%s/static/' % AWS_S3_CUSTOM_DOMAIN
MEDIA_URL = 'http://%s/media/' % AWS_S3_CUSTOM_DOMAIN
IMAGE_URL = MEDIA_URL[:-1]
INTERNAL_LINK = 'staging.creditcardcompare.com.au'
ALLOWED_HOSTS = ['staging.creditcardcompare.com.au']
CATEGORY_LIMIT = 2

#===============================================================================
# Application settings
#===============================================================================

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
        'LOCATION': '',
    }
}

FB_CLIENT_ID = conf.get('facebook-staging', 'FB_CLIENT_ID')
FB_CLIENT_SECRET = conf.get('facebook-staging', 'FB_CLIENT_SECRET')
FB_NAMESPACE = conf.get('facebook-staging', 'FB_NAMESPACE')
