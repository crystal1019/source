from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save, post_delete
from django.core.urlresolvers import reverse
from django.core.validators import URLValidator
#from django.core.exceptions import ValidationError
from django.core.exceptions import ObjectDoesNotExist

from django.conf import settings
from app.util import unique_slugify

import emails
import logging

logger = logging.getLogger(__name__)

ACCESS_PRIVATE = 0
ACCESS_FRIENDS = 1
ACCESS_PUBLIC = 2

RECIPE_FILE = 0
RECIPE_LINK = 1
RECIPE_MANUAL = 2


class Friendship(models.Model):
    # user1 sent the friend request
    user1 = models.ForeignKey(User, related_name='user1')
    user2 = models.ForeignKey(User, related_name='user2')
    approved = models.BooleanField()

    class Meta:
        unique_together = (('user1', 'user2', 'approved'),)


class Profile(models.Model):
    display_name = models.CharField(max_length=255)
    user = models.OneToOneField(User, db_index=True)
    access = models.IntegerField(default=0)
    # 0: private
    # 1: visible to friends
    # 2: public

    location = models.CharField(max_length=512, blank=True)
    about = models.TextField(blank=True)
    photo = models.CharField(max_length=255, null=True)

    def friends(self):
        fs1 = map(lambda f: f.user2,
                  Friendship.objects.filter(user1=self.user, approved=True))
        fs2 = map(lambda f: f.user1,
                  Friendship.objects.filter(user2=self.user, approved=True))
        return set(fs1).union(set(fs2))

    def blog_posts(self, viewer):
        posts = self.user.blogpost_set.all().order_by('-created_at')
        posts = filter(lambda p: p.can_see_post(viewer), posts)
        return posts


class Setting(models.Model):
    user = models.ForeignKey(User, db_index=True)
    key = models.CharField(max_length=255)
    value = models.CharField(max_length=255)

    class Meta:
        unique_together = (('user', 'key', 'value',),)

default_user_settings = {
    'new_recipes_privacy': ACCESS_PUBLIC,
    'new_comments_email': 'yes',
    'new_bookmarks_email': 'yes',
    'digest_email': 'yes',
}


def get_setting(user, key):
    setting = Setting.objects.filter(
        user=user,
        key=key)
    if len(setting) == 0:
        return default_user_settings[key]
    else:
        return setting[0].value


class Recipe(models.Model):
    author = models.ForeignKey(User, db_index=True)
    title = models.CharField(max_length=512)
    slug = models.SlugField(max_length=60, blank=True)
    description = models.TextField()
    access = models.IntegerField(default=0)
    typ = models.IntegerField(default=0)
    created_at = models.DateField(auto_now_add=True)

    def one_photo(self):
        ris = RecipeImage.objects.filter(recipe=self)
        if len(ris) > 0:
            # from pprint import pprint as pp
            # print "one_photo debug:"
            # pp(ris[0].upload)
            return reverse('recipe_photo', args=[ris[0].id])
        if settings.LIVE:
            return (settings.STATIC_URL + 'placeholder.gif')
        return '/static/placeholder.gif'

    def all_but_first_photos(self):
        ris = RecipeImage.objects.filter(recipe=self)
        if len(ris) > 1:
            return map(lambda ri: reverse('recipe_photo', args=[ri.id]),
                       ris[1:])
        else:
            return None

    def is_bookmarked(self, user):
        anon = user.is_anonymous()
        if not anon:
            bookmarked_recs = [b.recipe for b in user.bookmark_set.all()]
        else:
            bookmarked_recs = []
        return (not anon) and (self in bookmarked_recs)

    def bookmarkers(self):
        return map(lambda b: b.user, self.bookmark_set.all())

    def sorted_tags(self):
        tags = list(self.recipetag_set.all())
        tags.sort(key=lambda rt: rt.tag.tag)
        return tags

    def save_fields(self, data):
        for field in data:
            if hasattr(self, field):
                setattr(self, field, data[field])
        unique_slugify(self, self.title)
        self.save()

    # Associated uploaded files with this recipe.
    # uploaded is a list of ids of model objects.

    def associate_uploaded(self, model, uploaded):
        for uid in uploaded:
            try:
                upload = model.objects.get(id=uid)
                if upload.user == self.author:
                    upload.recipe = self
                    upload.save()
            except ObjectDoesNotExist:
                print 'associate_uploaded, record not found id=',uid

    def add_tag(self, tag):
        tag = tag.lower().strip()
        (tag_obj, _) = Tag.objects.get_or_create(tag=tag)
        (rt, _) = RecipeTag.objects.get_or_create(
            recipe=self,
            tag=tag_obj)
        return tag_obj

    def add_tags(self, tags):
        tags = filter(lambda t: t.strip() != '', tags)
        for tag in tags:
            self.add_tag(tag)

    def photos(self):
        photos = RecipeImage.objects.filter(recipe=self)
        photos = map(lambda ri: ri.id, photos)
        return photos

    def comments(self):
        return RecipeComment.objects.filter(recipe=self).order_by('created_at')

    def get_data(self):
        data = None
        try:
            if self.typ == RECIPE_FILE:
                data = RecipeFile.objects.get(recipe=self)
                print "Recipe.get_data data=", data
            elif self.typ == RECIPE_LINK:
                data = RecipeLink.objects.get(recipe=self)
            elif self.typ == RECIPE_MANUAL:
                data = RecipeManual.objects.get(recipe=self)
        except ObjectDoesNotExist:
            print "EXCEPTION! DoesNotExist RecipeFile/RecipeLink/RecipeManual in:%s typ:%s" % (self.id, self.typ)
            logger.error("EXCEPTION! DoesNotExist RecipeFile/RecipeLink/RecipeManual in:%s typ:%s" % (self.id, self.typ))
        return data

    def save_data(self, typ, post_dict):

        # TODO: fill in

        def save_file(self, post_dict):
            self.__delete_all_files()
            self.associate_uploaded(RecipeFile,
                                    [post_dict['uploaded_file']])

        def save_link(self, post_dict):
            pass

        def save_manual(self, post_dict):
            pass

        save_handlers = {
            RECIPE_FILE: save_file,
            RECIPE_LINK: save_link,
            RECIPE_MANUAL: save_manual}

        return save_handlers[typ](self, post_dict)

    def __delete_all_files(self):
        rfs = RecipeFile.objects.filter(recipe=self)
        for rf in rfs:
            rf.delete()


class RecipeImage(models.Model):
    recipe = models.ForeignKey(Recipe, db_index=True, null=True)
    upload = models.CharField(max_length=255)
    user = models.ForeignKey(User)


def check_blanks(obj, model, fields, *args, **kwargs):
    for f in fields:
        if getattr(obj, f) == "":
            raise
    return super(model, obj).save(*args, **kwargs)


class RecipeFile(models.Model):
    recipe = models.OneToOneField(Recipe,
                                  db_index=True,
                                  unique=True,
                                  null=True)
    upload = models.CharField(max_length=255)
    user = models.ForeignKey(User)

    def save(self, *args, **kwargs):
        return check_blanks(self, RecipeFile, ['upload'], args, kwargs)


class RecipeLink(models.Model):
    recipe = models.OneToOneField(Recipe, db_index=True)
    link = models.CharField(max_length=1024)

    def save(self, *args, **kwargs):
        result = check_blanks(self, RecipeLink, ['link'], args, kwargs)
        validator = URLValidator()
        validator(self.link)        # raises ValidationError if it doesn't validate
        return result


class RecipeManual(models.Model):
    recipe = models.OneToOneField(Recipe, db_index=True)
    contents = models.TextField()

    def save(self, *args, **kwargs):
        return check_blanks(self, RecipeManual, ['contents'], args, kwargs)


class RecipeComment(models.Model):
    recipe = models.ForeignKey(Recipe, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey(User)
    contents = models.TextField(blank=True)

    def send_subscription_emails(self):
        subs = RecipeCommentSubscription.objects.filter(recipe=self.recipe)
        for s in subs:
            if s.subscriber != self.author and s.subscriber != self.recipe.author:
                emails.send_comment_notification(self, s)


class RecipeCommentSubscription(models.Model):
    recipe = models.ForeignKey(Recipe, db_index=True)
    subscriber = models.ForeignKey(User)


class BlogPost(models.Model):
    author = models.ForeignKey(User, db_index=True)
    title = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    contents = models.TextField()
    access = models.IntegerField()

    def can_see_post(self, viewer):
        from friends import friends
        return ((self.author == viewer) or
               (self.access == ACCESS_PUBLIC) or
                (self.access == ACCESS_FRIENDS and
                friends(self.author, viewer)))


class BlogPostComment(models.Model):
    author = models.ForeignKey(User)
    post = models.ForeignKey(BlogPost, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    contents = models.TextField()


class Notification(models.Model):
    typ = models.CharField(max_length=32)
    target_user = models.ForeignKey(User, related_name='target_user',
                                    db_index=True)
    other_user = models.ForeignKey(User, related_name='other_user',
                                   null=True)
    action = models.CharField(max_length=255)
    recipe = models.ForeignKey(Recipe, null=True)
    blog_post = models.ForeignKey(BlogPost, null=True)

    seen = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    dismiss_on_view = models.BooleanField(default=True)


class BlogPostPhoto(models.Model):
    post = models.ForeignKey(BlogPost, db_index=True)
    upload = models.CharField(max_length=255)


class Tag(models.Model):
    tag = models.CharField(max_length=128, primary_key=True)


class RecipeTag(models.Model):
    recipe = models.ForeignKey(Recipe, db_index=True)
    tag = models.ForeignKey(Tag, db_index=True)


class Bookmark(models.Model):
    user = models.ForeignKey(User, db_index=True)
    recipe = models.ForeignKey(Recipe, db_index=True)

    class Meta:
        unique_together = (('user', 'recipe',),)


class FeedEvent(models.Model):
    pass


class CommentEvent(FeedEvent):
    comment = models.ForeignKey(RecipeComment)


class BookmarkEvent(FeedEvent):
    bookmark = models.ForeignKey(Bookmark)


class RecipeEvent(FeedEvent):
    recipe = models.ForeignKey(Recipe)


class FriendshipEvent(FeedEvent):
    friendship = models.ForeignKey(Friendship)


class UserFeed(models.Model):
    user = models.ForeignKey(User, db_index=True)
    event = models.ForeignKey(FeedEvent)
    created = models.DateTimeField(auto_now_add=True)
    # Is this an event that user did (True), or an event that user should see in his
    # updates feed (False)?
    user_own_evt = models.BooleanField(default=False)

    class Meta:
        unique_together = (('user', 'event', 'user_own_evt',),)


def publish_feed_event(user, evt, target_user=None):
    friends = user.profile.friends()

    # Publish event to all friends' feeds
    for friend in friends:
        (feed_evt, _) = UserFeed.objects.get_or_create(
            user=friend,
            event=evt,
            user_own_evt=False)

    # Publish event to user's own user-specific feed
    (feed_evt, _) = UserFeed.objects.get_or_create(
        user=user,
        event=evt,
        user_own_evt=True)

    # Optionally, publish to a special target user's feed
    # (e.g. the author of the recipe being commented on)
    if target_user and (target_user not in friends):
        (feed_evt, _) = UserFeed.objects.get_or_create(
            user=target_user,
            event=evt,
            user_own_evt=False)


def bookmark_post_save(sender, **kw):
    instance = kw['instance']
    created = kw['created']

    if created:
        notification = Notification.objects.create(
            typ='bookmark',
            action='created',
            target_user=instance.recipe.author,
            other_user=instance.user,
            recipe=instance.recipe,
            dismiss_on_view=True)
        notification.save()

        emails.send_bookmark(instance)

        (evt, evt_created) = BookmarkEvent.objects.get_or_create(bookmark=instance)
        if evt_created:
            publish_feed_event(instance.user, evt, instance.recipe.author)


def bookmark_post_delete(sender, **kw):
    instance = kw['instance']

    ns = Notification.objects.filter(
        typ='bookmark',
        action='created',
        target_user=instance.recipe.author,
        other_user=instance.user,
        recipe=instance.recipe)

    for n in ns:
        n.delete()


def friendship_post_save(sender, **kw):
    instance = kw['instance']
    created = kw['created']

    if created:
        notification = Notification.objects.create(
            typ='friend',
            action='request',
            target_user=instance.user2,
            other_user=instance.user1,
            dismiss_on_view=False)
        notification.save()
    elif instance.approved:
        notification = Notification.objects.create(
            typ='friend',
            action='approved',
            target_user=instance.user1,
            other_user=instance.user2)
        notification.save()

        (evt, evt_created) = FriendshipEvent.objects.get_or_create(friendship=instance)
        if evt_created:
            publish_feed_event(instance.user1, evt)
            publish_feed_event(instance.user2, evt)


def comment_post_save(sender, **kw):
    instance = kw['instance']
    created = kw['created']
    if created:
        if instance.recipe.author != instance.author:
            notification = Notification.objects.create(
                typ='comment',
                action=str(instance.id),
                target_user=instance.recipe.author,
                other_user=instance.author,
                recipe=instance.recipe)
            notification.save()

            setting = get_setting(
                instance.recipe.author,
                'new_comments_email')
            if setting == 'yes':
                emails.send_comment(instance)

        (evt, evt_created) = CommentEvent.objects.get_or_create(comment=instance)
        if evt_created:
            publish_feed_event(instance.author, evt, instance.recipe.author)

        instance.send_subscription_emails()


def comment_post_delete(sender, **kw):
    instance = kw['instance']
    ns = Notification.objects.filter(
        typ='comment',
        action=str(instance.id),
        other_user=instance.author)
    for n in ns:
        n.delete()


def blog_comment_post_save(sender, **kw):
    instance = kw['instance']
    created = kw['created']

    if created and instance.post.author != instance.author:
        notification = Notification.objects.create(
            typ='comment',
            action=str(instance.id),
            target_user=instance.post.author,
            other_user=instance.author,
            blog_post=instance.post)
        notification.save()


def recipe_post_save(sender, **kw):
    instance = kw['instance']
    created = kw['created']

    if created:
        (evt, evt_created) = RecipeEvent.objects.get_or_create(recipe=instance)
        if evt_created:
            publish_feed_event(instance.author, evt)


post_save.connect(friendship_post_save, sender=Friendship)
post_save.connect(comment_post_save, sender=RecipeComment)
post_save.connect(blog_comment_post_save, sender=BlogPostComment)
post_save.connect(bookmark_post_save, sender=Bookmark)
post_save.connect(recipe_post_save, sender=Recipe)

post_delete.connect(bookmark_post_delete, sender=Bookmark)
post_delete.connect(comment_post_delete, sender=RecipeComment)
