from django.contrib import admin
from models import Survey, CardReview, CardSurvey
from helpers import DownloaderAdmin


class SurveyAdmin(admin.ModelAdmin):
    list_display = ('title', 'question', 'is_visible')
    list_editable = ('is_visible',)
    
class CardSurveyInline(admin.TabularInline):
    model = CardSurvey
    extra = 0
    
class CardReviewAdmin(DownloaderAdmin):
    model = CardReview
    list_display = ('title', 'card', 'email', 'submitted', 'is_public')
    search_fields = ('card__title',)
    inlines = (CardSurveyInline,)
    surveys = list(Survey.objects.filter(is_visible=True).values_list('title', flat=True))
    
    def extract_value(self, obj, field):
        '''Overriding method of parent class'''
        if field == 'card_id':
            return getattr(obj, 'card').title
        elif field in self.surveys:
            try:
                return obj.cardsurvey_set.filter(survey__title=field).order_by('-id')[0].rating
            except (IndexError, CardSurvey.DoesNotExist):
                return None
        return super(CardReviewAdmin, self).extract_value(obj, field)
    
    def get_field_list(self):
        '''Overriding method of parent class'''
        return [f.column for f in self.model._meta.fields] + self.surveys

admin.site.register(Survey, SurveyAdmin)
admin.site.register(CardReview, CardReviewAdmin)
