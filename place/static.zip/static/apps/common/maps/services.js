angular.module('map.services', []).factory('MapData', ['$http', '$q',
    function($http, $q) {
        // URL defaults to topic edit page URL
        // For PSC, this is overridden by $scope.map_url from PSCCtrl
        return {
            is_dirty: false,
            store: null,
            active: false,
            gmap: null,
            center: null,
            zoom: null,
            defer: $q.defer(),
            selected_feature: null,
            id: null,
            error: null,
            url: "/mapedit/",
            infowindow: null,
            load: function(id) {
                this.id = id;
                var self = this;
                if (!this.active) {
                    this.active = true;
                    $http({
                        method: 'GET',
                        url: this.url,
                        params: {
                            'id': this.id
                        }
                    }).success(function(obj) {
                        self.store = obj.data;
                        self.center = new google.maps.LatLng(obj.data.map_center[0], obj.data.map_center[1]);
                        self.zoom = obj.data.map_zoom;
                        self.defer.resolve(obj);
                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            },
            save: function(data) {
                // array of updates only
                var self = this;
                var defer = $q.defer();
                post_data = {
                    'id': self.id,
                    'data': data
                };
                $http.post(
                    self.url,
                    post_data
                ).success(function(obj) {
                    self.active = true;
                    console.log(obj)
                    self.store = obj.data;
                    if (self.store.new_gids) {
                        var gids = self.store.new_gids;
                        for (var i = 0, len = self.layer.features.length; i < len; i++) {
                            var ft = self.layer.features[i];
                            if (gids.hasOwnProperty(ft.__gm_id)) {
                                ft.gid = gids[ft.__gm_id];
                            }
                            if (gids.hasOwnProperty(ft._ps_id)) {
                                ft.gid = gids[ft._ps_id];
                            }
                        };
                    }
                    defer.resolve({data_type:'map'});
                }).error(function(data, status) {
                    defer.reject(data);
                });
                return defer.promise;
            }
        };
    }
]);