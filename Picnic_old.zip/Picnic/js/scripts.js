(function($){

    /**
     * Document Ready Intializations
    */
	$(window).load(function(){
	  $('#loading').fadeOut(2000);
	});
	$(document).ready(function(){
		
		if(isMobile()){
			// update meta-viewport for mobile devices
			$('meta[name=viewport]').attr({'content':'width=800, user-scalable=0'});
			
		}else{
			// nothing here
		}

		initMainHeight();
		initWhatsThat();
		initBubbleSlide();
		//initSubscribe();
		
		$(window).resize(function(){
			initMainHeight();
		});

		$(document).ready(function(){
			$('.team-member li').each(function() {				
				var obj = this;
				$(obj).qtip({
					content: $(obj).find('.member-wrapper').html(),
			        position: {
			            target: 'mouse', // Track the mouse as the positioning target
			            adjust: { x: 5, y: -150 } // Offset it slightly from under the mouse
			        }
				});
			});
		});


	});


    /**
     * Window onLoad Initializations
    */
	$(window).load(function(){
	});
	
	
	function initMainHeight()
	{
		var viewportHeight = $(window).height();
		if(viewportHeight > 400){
			$('.main').css('height', viewportHeight);
		}
	}
	
	
	function initWhatsThat()
	{
		var callout = $('.callout'),
			invite = $('.invite-container')
			footer = $('.footer-container')
			whatsThat = $('.action')
			;
		
		//callout.hide(0);
		//invite.hide(0);
		
			callout.show(0);
			invite.show(0, function(){
				slideTo(callout, 0);
				initSubscribe();
				setTimeout(function(){
					$('.bubble-container').animate({
						opacity: 1
					}, 300, 'easeInQuint');
				}, 800);
			});
			footer.show(0);
			whatsThat.hide(0);
	}
	
	
	function initBubbleSlide()
	{
		var timeout = 0;
		
		$('.bubble').each(function(i,e){
			var elem = $(this);
			elem.data('side', 'right');
			if(i%2 == 0){
				elem.data('side', 'left');
			}
			var cssProps = {'opacity':0};
			cssProps[elem.data('side')] = -2000;
			elem.css(cssProps);

			$(window).scroll(function(){
				
				var pos = $(window).scrollTop() + $(window).height() - 100;
				if(
					pos > $('.main').height() 
					&& pos >= elem.offset().top 
					&& !elem.hasClass('animated')
				){
					setTimeout(function(){
						elem.addClass('animated');
						timeout = 500;
						var props = {'opacity':1};
						props[elem.data('side')] = 0;
						elem.animate(props, 1200, 'easeOutQuart', function(){
							timeout = 0;
						});
					}, timeout)
				}
			});
			
		});
	}
	
	
	function slideTo(elem, offset)
	{
		var elemtop = parseInt(elem.offset().top) - parseInt(offset);
		$('html, body').animate({
			scrollTop: elemtop
		}, 1500, 'easeInOutCubic');
	}
	
	
	function isEmail(val)
	{
		var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return regex.test(val);
	}
	
	
	function isPhone(val)
	{
		var regex = /[0-9 -()+]+$/;
		return regex.test(val);
	}
	
	
	function initSubscribe()
	{
		var vars = {};
		vars.form = $('#signup-form');
		vars.actionUrl = vars.form.attr('action');
		vars.responseCont = $('#result');
		vars.formContainer = $('.form-container');
		vars.submitButton = vars.form.find('.button');
		//vars.submitButtonInner = vars.submitButton.find('span span');
		vars.overlay = $('.overlay');
		vars.formContainerHeight = vars.formContainer.height();
		
		vars.form.submit(function(e){
			
			e.preventDefault();
			vars.continueText = 'Get another one';
			
			// if input is not email or phone, display message
			
			var val = vars.form.find('.input-text').val(),
				passed = false
				;
			
			if(isEmail(val) || isPhone(val)){
				passed = true;
			}
			
			if(!passed){
				vars.continueText = 'Try again';
				showMessage('invalid', 'Please enter email address <br/>or Phone number', vars);
				return;
			}
			
			
			
			// show overlay, disable button
			vars.overlay.fadeIn(100);
			//vars.submitButton.prop('disabled', true);
			vars.submitButton.addClass('progress');
			
			
			/**/
			// submit the form using Ajax
			$.ajax({
	  			url: vars.actionUrl,
	  			data: vars.form.serialize(),
	  			dataType: 'json',
	  			success: function(d){
	  				//console.log(d);
	  				if('null' == d){
						showMessage('error', 'Подписка не удалась :(', vars);
		  				
	  				}else{
		  				if(d.result){
		  					showMessage('success', d.msg, vars);
		  				}else{
		  					showMessage('invalid', d.msg, vars);
		  				}
	  				}
	  			},
	  			error: function(d){
	  				//console.log(d);
					showMessage('error', 'Подписка не удалась :(', vars);
	  			}
			});
						
		});
		
		vars.responseCont.find('.continue').click(function(){
			showMessage('hide', '', vars);
		});
	}

	
	/**
	 * Display Newsletter Input Message with Given Class and Text String
	*/
	function showMessage(className, msg, vars)
	{			
		var msgCont = vars.responseCont.find('.msg'),
			continueLink = vars.responseCont.find('.continue'),
			speed = 200
			;
		
		// View Signup Form
		if(className == 'hide'){
		
			//speed = 100
			vars.overlay.fadeOut(100);
			vars.submitButton.removeClass('progress');
			vars.formContainer.css({
				display: 'block'
			});
			
			msgCont.animate({
				top: '-100px',
				opacity: 0
			}, speed*2, 'easeInBack', function(){
			
	    		vars.responseCont.animate({
	    				opacity: 0,
	    			}, speed, 'swing', function(){
	    				msgCont.html('');
	    				continueLink.html('');
	    				vars.responseCont.removeClass();
	    				
	    				$(this).animate({
	    					height: 0
	    				}, speed, 'swing', function(){
	    					vars.responseCont.css({'height': '', 'opacity': '', 'display': 'none'});
	    					$('#result img').hide(0);
	    				});
	    				
						vars.formContainer.animate({ 
	    						height: vars.formContainerHeight
	    					}, speed, 'swing', function(){
	    						$(this).animate({
	    							opacity: 1
	    						}, speed);
	    					}
	    				);
	    			}
	    		);
			});
    		

		// View Result Message
		}else{
			if(className == 'success'){
				$('#result img').show(0);
			}
			vars.overlay.fadeOut(100);
			msgCont.html(msg);
			msgCont.css({top: '-100px', opacity: 0});
			continueLink.html(vars.continueText);
			//if(null == vars.responseContHeight){
				vars.responseContHeight = vars.responseCont.height();
			//}
			
			vars.responseCont.css({
			    display: 'block', 
			    opacity: 0, 
			    height: 0
			});
			
			vars.responseCont.addClass(className);
			
			
			vars.formContainer.animate({
			    	opacity: 0
			    }, 150, 'swing', function(){
			    	
			    	vars.formContainer.animate({
			    			height: 0
			    		}, speed, 'linear', function(){
			    			$(this).hide();
			    		}
			    	);
			    	
			    	vars.responseCont.animate({
			    			height: vars.responseContHeight
			    		}, speed, 'linear', function(){
			    			$(this).animate({
			    				opacity: 1
			    			}, speed, 'swing', function(){
			    				msgCont.animate({
			    					top: 0,
			    					opacity: 1
			    				}, speed*2, 'easeInOutBack');
			    			});
			    		}
			    	);
			    }
			);
				
		}
	}
	
	
	function isMobile(){
	    return(
	    	screen.width <= 500
	    	//(navigator.userAgent.toLowerCase().indexOf("ipad") > -1) ||
	        //(navigator.userAgent.toLowerCase().indexOf("mobile") > -1)
	        //(navigator.userAgent.toLowerCase().indexOf("iphone") > -1) ||
	        //(navigator.userAgent.toLowerCase().indexOf("ipod") > -1)
	    );
	}

}(jQuery))
