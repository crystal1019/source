import urllib
import httplib2
http = httplib2.Http()
url = 'http://api.mailcall.com.au/test.php'
key = '784e397ef3c0f458ec288ebd7d6925b2'

xml = '''<?xml version='1.0' encoding='UTF-8' standalone='yes'?><request type='pricelist' />'''

dicts = {'key':key,'xml':xml}
print dicts
params = urllib.urlencode(dicts)
print params
headers = {'Content-type': 'application/x-www-form-urlencoded'}
response, content = http.request(url, 'POST', params, headers=headers)
#f = urllib.urlopen(url, params)
#print f.read()
print response
print content

import xml.dom.minidom
DOMTree = xml.dom.minidom.parseString(content)
allsuburbs = DOMTree.documentElement
suburbs =allsuburbs.getElementsByTagName("suburb") 
data = {}
for x in suburbs:
    postcode = x.getElementsByTagName('postcode')[0].childNodes[0].data
    name = x.getElementsByTagName('name')[0].childNodes[0].data
    price = x.getElementsByTagName('totalcost')[0].childNodes[0].data
    if postcode not in data.keys():
        data[postcode] = {name:price}
    else:
        data[postcode][name] = price
        
print data

import datetime
now = datetime.datetime.now()
bookxml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<request xmlns="http://www.mailcall.com.au" type="book" version="1.4"> <job>
<date>20121119</date>
<fromcompany>Bella Bustiere Pty Ltd</fromcompany> 
<fromaddress1>339 Military Rd</fromaddress1><fromcontact>Reception</fromcontact><fromsuburb>Mosman</fromsuburb>
<frompostcode>2088</frompostcode>
<tocompany>None</tocompany> <fromphone>0123456789</fromphone> 
<toaddress1>007 License St</toaddress1>
<tocontact>Money Penny</tocontact>
<tophone>0123456789</tophone>
<tosuburb>BONDI</tosuburb>
<topostcode>2026</topostcode>
<service>STD</service><vehicle>C</vehicle><weight>1</weight>
<weightunits>kg</weightunits>
<quantity>2</quantity>
<readytime>NOW</readytime>
<driverinstructions>Don't mind the dog, he's friendly</driverinstructions><reference>SR123</reference>
<oktoleave>Y</oktoleave><echo>Y</echo>
</job> </request>'''

dicts = {'key':key,'xml':bookxml}
params = urllib.urlencode(dicts)
headers = {'Content-type': 'application/x-www-form-urlencoded'}
response, content = http.request(url, 'POST', params, headers=headers)
print content

DOMTree = xml.dom.minidom.parseString(content).documentElement
mobilecode = DOMTree.getElementsByTagName('mobileauthcode')[0].childNodes[0].data
lineno = DOMTree.getElementsByTagName('lineno')[0].childNodes[0].data

statusxml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<request xmlns="http://www.mailcall.com.au" type="status" version="1.4">
<mobileauthcode>%s</mobileauthcode><job>
<lineno>%s</lineno><date>20111119</date>
</job> </request>'''%(mobilecode,lineno)
dicts = {'key':key,'xml':statusxml}
params = urllib.urlencode(dicts)
headers = {'Content-type': 'application/x-www-form-urlencoded'}
response, content = http.request(url, 'POST', params, headers=headers)
print content