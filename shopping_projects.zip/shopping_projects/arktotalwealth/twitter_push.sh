cd /home/chaol/projects/arktotalwealth
python manage.py twitter_push  > /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/twitter_process
echo "---------------" >> /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/twitter_process
cat  /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/twitter_process >> /var/www/vhosts/arktotalwealth.com.au/httpdocs/media/index_process/twitter_allprocess
