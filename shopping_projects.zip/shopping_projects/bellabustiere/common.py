'''
@author: chaol
'''
from bellabustiere.shop.models import *
from bellabustiere.website.models import *
from bellabustiere.blog.models import *
from random import *
from django.db.models import Q

from django.conf import settings

import inspect

import hashlib
import datetime

import helpers

def split_list(l, length):
    """
    Takes a list and splits into a list of lists of size X
    """
    if not l:
        return []
    ret = []
    cur = []
    rowdone = False
    l = list(l)
    for x in l:
        cur.append(x)
        if len(cur) == length:
            ret.append(cur)
            cur = []
            rowdone = True
        else:
            rowdone = False
    if not rowdone:
        ret.append(cur)
    return ret

def getNewsItems():
    return NewsItem.objects.filter(publish_date__lte=datetime.datetime.now(), status__display_to_user=True)[:5]
def getCategories():
    cat =  Categories.objects.filter(sites__id=settings.SITE_ID,is_active=True, parent__isnull=True).order_by("-priority","name")
    return cat
def getFeaturedProducts(request):
    # Lets select products based on the type of customer we're working with
    products = Product.objects.distinct().filter(sites__pk=settings.SITE_ID).filter(category_now__is_active=True, status__display_to_user=True, status__is_featured = True)
    if isWholesale(request.user):
        products = products.filter(wholesale_price__gt=0)
    else:
        products = products.filter(price__gt=0)
    p = list(products)
    shuffle(p)
    return p

def getTopFeatured(request):
    
    products = Product.objects.distinct().filter(sites__pk=settings.SITE_ID).filter(category_now__is_active=True, status__display_to_user=True, status__status__iexact = "top featured")
    if request.user.is_active:
        products = products.filter(wholesale_price__gt=0)
    else:
        products = products.filter(price__gt=0)
    p = list(products)
    shuffle(p)
    return p

def getLatestBlogPost():
    bp = BlogPost.objects.select_related().filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate")
    return bp[:8]


def getCurrencyRatio(currency):
    if currency == 'AUD':
        return 1, currency
    else:
        url = "http://www.google.com/ig/calculator?hl=en&q=1AUD=?%s"  % currency
        response = urllib.urlopen(url)
        response = response.read()
        result = re.search(".*rhs: \"(\d*\.\d*)", response)
        if result:
            ratio = formatCurrency(result.group(1))
        else:
            ratio = 'Error, please use AUD'
            
    return ratio, currency

def getMostPop():
    d = {}
    p = Product.objects.all()
    for x in p:
        num = len(x.productorder_set.filter(order__status__status="Shipped"))
        d[x.id,x.title] = num

    sorted_x = sorted(d.items(), key=lambda x: x[1])
    sorted_x.reverse()
    return sorted_x[:8]
    
def commonDict(d, request):
    try:
        sitemeta = SiteMeta.objects.get(site__id=settings.SITE_ID)
    except:
        sitemeta = ''
    
    news = getNewsItems()
    
    clothes_nav = Categories.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False, parent__isnull=True).order_by('-priority')
    designers_nav = Brand.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False)
    activity_nav = Activity.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False)
    
    about_nav = MiscPage.objects.filter(sites__id=settings.SITE_ID, group='about',status__display_to_user=True)
    contact_nav = MiscPage.objects.filter(sites__id=settings.SITE_ID, group='contact',status__display_to_user=True)
    try:
        mostpop = sitemeta.popular_product
    except:
        mostpop = ''
    featured = Product.objects.filter(sites__id=settings.SITE_ID, status__is_featured=True,status__display_to_user=True)[:10]
    
    now = datetime.datetime.now()
    discounted = DiscountPrice.objects.filter(start__lte=now, end__gt=now,coupon=None, product__status__can_buy=True)[:5]
    
    currency = request.session.get('currency', 'AUD')
    
    ratio_error = False
    ratio,currency = getCurrencyRatio(currency)
    try:
        float(ratio)
    except:
        ratio_error = True
        request.session['currency'] = 'AUD'
        ratio = 1
        
    label = '$'
    if currency == 'GBP':
        label = u'\xa3'
    elif currency == 'EUR':
        label = u'\u20ac'

    
    data = {    'usr':None,
                'latestnews': news,
                
                'clothes_nav':clothes_nav,
                'designers_nav': designers_nav,
                'activity_nav': activity_nav,
                'about_nav':about_nav,
                'contact_nav':contact_nav,
                
                'mostpop':mostpop,
                
                'wholesale':False,

                'latestBlogPost': getLatestBlogPost(),
                
                'site_meta':sitemeta,
                
                'alsolike':featured,
                'sale':discounted,
                
                'ratio':(ratio,currency),
                'ratio_error':ratio_error,
                'currency':currency,
                'label':label,
                
                'discounted':discounted,
                
                'shipping_message':FreeShippingValue.objects.getMessage()
                

              }
    coupon = request.session.get('coupon','')
    
    if coupon:
        coupons = Coupon.objects.get_coupon(coupon)
        
        validate = True if coupons else False
    
        if not validate:
            request.session['coupon'] = ''
            order, new = helpers.getCurrentOrder(request)
            if order:
                helpers.sync_productorder(order)
        else:
            request.session['coupon'] = coupon
            
    data['coupon'] = request.session.get("coupon", '')


    if request.user and request.user.is_active:
        data['usr'] = request.user
        data['wholesale'] = isWholesale(request.user)
 
    if request.session.get("order_id", None):
        try:
            o = Order.objects.get(pk=request.session.get("order_id", 0), status=OrderStatus.objects.get(status=settings.TXT_SHOP_ORDER_STATUS_IN_PROGRESS))
            data['order'] = o
            if o.voucher and not o.voucher.is_valid():
                o.voucher = None
                o.save()
                
            if d.get('total', ''):
                currency_total = float(d.get('total','')) * float(ratio)
            else:
                currency_total = float(o.total_charged) * float(ratio)
            d['currency_total'] = formatCurrency(currency_total)
        except:
            del request.session['order_id']
    
    data.update(d)
    return data
def formatCurrency(amount):
    try:
        p = str(amount).split(".")
        if len(p[1]) < 2:
            p[1] = str(p[1])+str(0)
        elif len(p[1]) > 2:
            p[1] = str(p[1][:2])
        price = ".".join(p)
        return price
    except:
        return amount
    
def props(obj):
    pr = {}
    for name in dir(obj):
        try:
            value = getattr(obj, name)
            if not name.startswith('_') and (name[0] == name[0].lower()) and not inspect.ismethod(value):
                pr[name] = value
        except:
            pass
    return pr
    

    