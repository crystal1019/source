from django.core.management.base import BaseCommand
from offers.tools.rate_alert.views import send_alert_command


class Command(BaseCommand):
    def handle(self, *args, **options):
        settings = options.get('custom_settings', None)
        if settings:
            kwargs = {'custom_settings': settings}
        else:
            kwargs = {}
        total_sent = send_alert_command(**kwargs)
        print 'Alerts sent to %s people.' % total_sent  # django_chronograph will fetch this
