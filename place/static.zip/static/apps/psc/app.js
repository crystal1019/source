angular.module('PSCApp', [
    '$strap.directives',
    'ngSanitize',
    'ngRoute',
    'activity.controllers',
    'activity.directives',
    'activity.services',
    'map.services',
    'map.directives',
    'map.controllers',
    'common.directives',
    'psc.controllers',
    'psc.directives',
    'psc.services'
]).config(['$httpProvider', '$routeProvider',
    function($httpProvider, $routeProvider) {
        $httpProvider.defaults.headers.post['X-CSRFToken'] = $('input[name=csrfmiddlewaretoken]').val();
        $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
        $routeProvider
            .when('/settings', {
                //asd
            })
            .when('/team', {
                //asd
            })
            .when('/map', {
                //asd
            })
            .when('/report', {
                //asd
            })
            .when('/activity', {
                //asd
            })
            .otherwise({
                redirectTo: '/settings'
            });
    }
]);
