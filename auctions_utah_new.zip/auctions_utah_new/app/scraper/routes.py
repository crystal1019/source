__author__ = 'RJB'
import subprocess
import time
import flask
from . import scraper

@scraper.route('/runscrapers')
def run_scrapers():
    def inner():
        proc = subprocess.Popen(
            'source venv/bin/activate; python app/scraper/runscrapers.py',
            shell=True,
            stdout=subprocess.PIPE
        )

        for line in iter(proc.stdout.readline, ''):
            time.sleep(1)                           # Don't need this just shows the text streaming
            yield line.rstrip() + '<br/>\n'

    return flask.Response(inner(), mimetype='text/html')