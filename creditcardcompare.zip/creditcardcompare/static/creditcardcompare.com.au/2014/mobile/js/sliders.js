// MAKE THE SLIDERS TITLES STICKY
/*function sticky_relocate() {
	if ($(document).scrollTop() > 241) {
		$('#sticky').addClass('stick');
		$('.standarized-hero-01').addClass('stickyfix');
	} else {
		$('#sticky').removeClass('stick');
		$('.standarized-hero-01').removeClass('stickyfix');
	}
};*/

// SLIDE UP AND DOWN THE SLIDER/CHECKBOXES
$(document).ready(function(e) {	
	$('.sliderdropdowntrigger').on('click',function(){
		$('.sliderdropdownwrapper').slideDown();
	});			
});

// MARK THE SLIDER TITLE AS ACTIVE
$('.slidertopwrapper .slidertopcontainer').on('click', function() {
	$(this).parent().find('.slidertopcontainer.active').removeClass('active');
	$(this).addClass('active');
});

// SLIDE UP THE CHECKBOXES AND REMOVE THE ACTIVE CLASS FROM SLIDER TITLES
$(window).scroll(function(){
	//sticky_relocate();
	$('.sliderdropdownwrapper').slideUp();
	$('.slidertopcontainer.active').removeClass( 'active' );
});

// SLIDER OWLCAROUSEL
$(document).ready(function() {

	var carousel = $("#slidercarousel");

	carousel.owlCarousel({
		navigation : false,
		slideSpeed : 300,
		pagination : false,
		singleItem : true,
		transitionStyle : "fade",
		touchDrag : false,
		mouseDrag : false
	});

	$('.slidertrigger1').click(function(){
		carousel.trigger('owl.goTo', 0)
	});
	$('.slidertrigger2').click(function(){
		carousel.trigger('owl.goTo', 1)
	});
	$('.slidertrigger3').click(function(){
		carousel.trigger('owl.goTo', 2)
	});
});