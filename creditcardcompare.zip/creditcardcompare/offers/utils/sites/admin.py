from django.contrib import admin
from django.contrib.sites.models import Site
from offers.tools.lightbox.models import PostClick
from models import ExtendedSite


class ExtendedSiteInline(admin.StackedInline):
    model = ExtendedSite
    extra = 1
    
class PostClickInline(admin.StackedInline):
    model = PostClick
    extra = 0
    
class SiteAdmin(admin.ModelAdmin):
    inlines = (ExtendedSiteInline, PostClickInline)
    
    
admin.site.unregister(Site)
admin.site.register(Site, SiteAdmin)