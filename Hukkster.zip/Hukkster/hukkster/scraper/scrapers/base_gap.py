#coding=utf-8
import logging
import re
import cgi
import urllib
import lxml.html
from urlparse import urlparse
from urlparse import urlunparse
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions
from ..scraper_utils import ScraperUtility
from ..scraper_utils import ParseFailedError


logger = logging.getLogger('scraper')


class ParseFailedError(Exception):
    pass

class BaseGapScraper(BaseScraper):
    def _extract_pid(self):
        parsed_qs = cgi.parse_qs(urlparse(self.url).query)
        if parsed_qs.has_key("pid"):
            return parsed_qs["pid"][0]
        else:
            logging.error("Failed to extract local_id from URL: %s" % self.url)
            raise ParseFailedError()

    def _extract_price(self, product_data_text, color_image_price_dicts):
        color_price_dicts = self.util._extract_all_value_dicts_using_regex(
                r'arrayVariantStyleColors\[(?P<color_idx>\d+)\]\s+=\s+new\s+objP\.StyleColor\([^\,]+\,"(?P<color>[^"]+)",([^\,]+\,){6}"\${0,1}(?P<original_price>[^,]+)",("\${0,1}(?P<current_price>[^,]+)"|undefined),([^\,]+\,){4}"(?P<size_info>[^\"]+)"',
                product_data_text)
        color_available_sizes = {}
        for color_price_dict in color_price_dicts:
            color = color_price_dict["color"]
            color_available_sizes.setdefault(color, [])
            available_sizes = [item.split("^,^")[1] for item in color_price_dict["size_info"].split("||")]
            color_available_sizes[color] += available_sizes
            original_price = color_price_dict["original_price"]
            current_price = color_price_dict["current_price"]
            if current_price is None:
                current_price = original_price
            color_image_price_dicts[color_price_dict["color_idx"]] = \
                    {"color": color_price_dict["color"],
                     "original_price": float(original_price),
                     "current_price": float(current_price)
                     }
        return color_available_sizes

    def _extract_title(self, product_data_text):
        value_dict = self.util._extract_value_dict_using_regex(
            r'new ProductStyle\(([^\,]+\,){25}"(?P<product_title>[^"]+)"',
            product_data_text
        )
        title = value_dict["product_title"]
        return self.util.clean_string(title)

    def _get_ajax_request_url(self, pid):
        return ("http://%s/browse/productData.do?pid=%s&vid=1"
                "&scid=&actFltr=false&locale=en_US&internationalShippingCurrencyCode="
                "&internationalShippingCountryCode=us&globalShippingCountryCode=us") % (self.get_domain(), pid)

    def _load_product_data(self, pid):
        product_data_text = self.get_content_from_url(self._get_ajax_request_url(pid))
        title = self._extract_title(product_data_text)

        color_image_price_dicts = {}
        color_available_sizes = self._extract_price(product_data_text, color_image_price_dicts)

        image_dicts = self.util._extract_all_value_dicts_using_regex(
                r'setArrayVariantStyleColorImages\(objP\.arrayVariantStyles\["\d+"\]\.arrayVariantStyleColors\[(?P<color_idx>\d+)\]\,[^)]+\^(?P<image>http[^\|]+)\|\|Swatch\^',
                product_data_text
        )
        for image_dict in image_dicts:
            color_image_price_dicts[image_dict["color_idx"]]["image"] = image_dict["image"]

        sizes_text = self.util._extract_value_dict_using_regex(
                r'SizeInfoSummary\(\d+\,\d+\,([^\,]+,){5,6}"(?P<sizes_text>[^"]+)"',
                product_data_text,
                failure_msg="Failed to extract size info from ajax data"
        )["sizes_text"]
        size_info_list = [size_text.split("^,^") for size_text in sizes_text.split("||")]

        product_data_list = []
        for color_image_price_dict in color_image_price_dicts.values():
            color = color_image_price_dict["color"]
            available_sizes = color_available_sizes.get(color, set([]))
            for size_info in size_info_list:
                if size_info[1] in available_sizes:
                    product_data = {
                            "title": title,
                            "selections": {
                                "color": color,
                                "size": size_info[0]
                              },
                              "original_price": {"value": color_image_price_dict["original_price"]},
                              "current_price":  {"value": color_image_price_dict["current_price"]},
                              "image": color_image_price_dict["image"],
                            }
                    product_data_list.append(product_data)
                
        return product_data_list

    def parse_products(self):
        pid = self._extract_pid()
        product_data_list = self._load_product_data(pid)
        for product_data in product_data_list:
            product_data["url"] = self.url
            product_data["store"] = self._get_store()
            product_data["local_id"] = pid
            product_data["promos"] = []
        return product_data_list

    def parse(self):
        self.util = ScraperUtility(self, parse_open_graph_info=False)

        try:
            products = self.parse_products()
        except ParseFailedError:
            products = None

        # Giving up, it doesn't look as a product
        if products is None or not len(products):
            raise HukksterTooManyOptions(self.get_domain(), self.url)

        return products

