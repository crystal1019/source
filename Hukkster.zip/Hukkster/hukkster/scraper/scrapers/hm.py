import json
import logging
import re
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class HMScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'hm.com'

    def clean_title(self, title):
        return re.sub(r'\s+', '', title)

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        breadcrumbs = soup.find('ul', class_='breadcrumbs')
        if breadcrumbs is None:
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)

        title = breadcrumbs.find('strong')
        if title is None:
            logger.critical('Was not able to extract title')
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)
        title = self.clean_title(title.text)

        sku = soup.find('a', attrs={'id': 'link-shareThis'})
        if sku is None:
            logger.critical('Was not able to extract sku')
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)
        sku = sku['data-article']

        price = soup.find('span', attrs={'id': 'text-price'})
        if price is None:
            logger.critical('Was not able to extract price')
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)
        price = float(price.text.replace('$', ''))

        image_container = soup.find('div', attrs={'id': 'product-image-box'})
        if image_container is None:
            logger.critical('Was not able to extract image')
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)
        image = image_container.find('img')
        if image is None:
            logger.critical('Was not able to extract image')
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)
        image = 'http:%s' % image['src']

        selections = []

        for li in soup.find_all('li', attrs={'id': re.compile(r'^option-article-')}):
            data = {
                'title': raw_data['title'] if raw_data else title,
                'current_price': {
                    'value': price
                },
                'url': self.url,
                'store': HMScraper.get_domain(),
                'image': image,
                'local_id': sku,
                'selections': {
                    'size': '',
                    'color': li.a.span.text
                },
                'promos':[]
            }
            selections.append(data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(HMScraper.get_domain(), self.url)

        return selections
