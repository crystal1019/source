from datetime import date
from django.core.management.base import BaseCommand
from offers.core.models import Category

class Command(BaseCommand):
    help = 'Deletes Smart Search result Categories and OfferCategories'

    def handle(self, *args, **options):
        Category.objects.filter(last_modification_date__lt=date.today(),
                                slug__startswith='smart-search-result-'
                        ).delete()
        print 'Smart Search categories deleted.'  # django_chronograph will fetch this
