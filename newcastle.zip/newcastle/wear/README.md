This is the directory for the django app

