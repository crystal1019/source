from django.db import models
from django.core.files.storage import FileSystemStorage
from datetime import datetime, timedelta
from django.utils.timezone import utc

# Create your models here.
from django.contrib.auth.models import User
from roomhints.utils import make_unique
from roomhints.utils import make_unique_photo
from iospush.models import Device

mfs = FileSystemStorage(base_url='/media/')

class Profile(models.Model):
    # This field is required.
    user = models.OneToOneField(User)
    # Other fields here
    designer = models.BooleanField(default=False)
    origin = models.TextField()
    has_account = models.BooleanField(default=False)
    ip = models.IPAddressField(blank=True,null=True)
    device = models.ForeignKey(Device)
    stripe_id = models.TextField(default=None,blank=True,null=True)
    charge_seconds = models.DateTimeField(null=True,blank=True)
    charge_amount = models.FloatField(default=0)
    charge_notifiedus = models.BooleanField(default=False)
    charge_plan = models.TextField(default=None,blank=True,null=True)
    website = models.TextField(blank=True,null=True)
    photo_headshot = models.ImageField(upload_to='pics/headshots/',storage=mfs,default=make_unique_photo)
    photo_vertshot = models.ImageField(upload_to='pics/vertshots/',storage=mfs,default=make_unique_photo)
    location = models.TextField(blank=True,null=True)
    aesthetic = models.TextField(blank=True,null=True)
    talent = models.TextField(blank=True,null=True)

    def __unicode__(self):
        return self.user.username + ":" + str(self.user.id)

class RoomType(models.Model):
    name = models.TextField()

    def __unicode__(self):
        return self.name + ":" + str(self.id)

class RoomSetting(models.Model):
    name = models.TextField()

    def __unicode__(self):
        return self.name + ":" + str(self.id)

class Project(models.Model):
    projuniq = models.TextField(default=make_unique)
    profile = models.ForeignKey(Profile)
    name = models.TextField(blank=True,null=True)
    seconds = models.DateTimeField(default=datetime.utcnow)
    budget = models.IntegerField(default=0,blank=True,null=True)
    photo = models.ImageField(upload_to='pics/projects/',storage=mfs,default=make_unique_photo)
    photo_web = models.ImageField(upload_to='pics/projects/',storage=mfs,blank=True,null=True)
    photo_mob = models.ImageField(upload_to='pics/projects/',storage=mfs,blank=True,null=True)
    photo_square = models.ImageField(upload_to='pics/projects/',storage=mfs,blank=True,null=True)
    custom = models.TextField(null=True,blank=True)
    public = models.BooleanField(default=False) # show was initiated, but decisions were not completed through to submti
    delete_seconds = models.DateTimeField(null=True,blank=True)
    shown_choices = models.IntegerField(default=0)
    roomtype = models.ForeignKey(RoomType)
    roomsetting = models.ForeignKey(RoomSetting,default=5)
    approved = models.BooleanField(default=False)
    dominant_hex = models.TextField(null=True,blank=True)
    hide = models.BooleanField(default=False)
    ip = models.IPAddressField(blank=True,null=True)
    charge_seconds = models.DateTimeField(null=True,blank=True)
    charge_amount = models.FloatField(default=0)
    charge_notifiedus = models.BooleanField(default=False)

    def __unicode__(self):
        ret = str(self.id) + ":"
        extra = 7 - len(ret)
        c = 0
        while c < extra:
            ret = "0" + ret
            c += 1
        if self.custom != None:
            ret += self.custom
        else:
            ret += ""
        if self.name:
            ret += ", " + self.name
        ret += " by " + str(self.profile.user_id)
        return ret

class HintType(models.Model):
    name = models.TextField()

    def __unicode__(self):
        return self.name

class HintTypeSimilarity(models.Model):
    one = models.ForeignKey(HintType,related_name='one')
    two = models.ForeignKey(HintType,related_name='two')

    def __unicode__(self):
        return str(self.one.id) + ":" + str(self.two.id)

# Migration code
# roomhints=> alter table roomhints_hint drop column project_id;
# ALTER TABLE
class Hint(models.Model):
    hintuniq = models.TextField(default=make_unique)
    profile = models.ForeignKey(Profile) # the user who created the hint
    seconds = models.DateTimeField(default=datetime.utcnow)
    price = models.FloatField()
    name = models.TextField()
    source = models.TextField()
    source_url = models.TextField(blank=True,null=True)
    sku = models.TextField(blank=True,null=True)
    keywords = models.TextField(blank=True,null=True)
    photo = models.ImageField(upload_to='pics/hints/',storage=mfs,default=make_unique_photo)
    photo_web = models.ImageField(upload_to='pics/hints/',storage=mfs,blank=True,null=True)
    photo_mob = models.ImageField(upload_to='pics/hints/',storage=mfs,blank=True,null=True)
    love = models.BooleanField()
    love_count = models.IntegerField(default=0)
    public = models.BooleanField(default=True)
    delete_seconds = models.DateTimeField(null=True,blank=True)
    dominant_hex = models.TextField()
    affiliate_url = models.TextField(blank=True,null=True)
    cx = models.IntegerField(default=0,null=True,blank=True) # Coordinates for computer vision
    cy = models.IntegerField(default=0,null=True,blank=True)
    ch = models.IntegerField(default=0,null=True,blank=True)
    cw = models.IntegerField(default=0,null=True,blank=True)

    def __unicode__(self):
        ret = self.source + ", $" + '{:20,}'.format(int(self.price)) + " sku: " + str(self.sku)
        return ret

class HintTypeList(models.Model):
    hint = models.ForeignKey(Hint)
    hinttype = models.ForeignKey(HintType)

    def __unicode__(self):
        ret = str(self.hint.id) + ":" + str(self.hinttype.name)
        return ret

class HintStyle(models.Model):
    name = models.TextField()

    def __unicode__(self):
        return self.name

class HintStyleList(models.Model):
    hint = models.ForeignKey(Hint)
    hintstyle = models.ForeignKey(HintStyle)

    def __unicode__(self):
        ret = str(self.hint.id) + ":" + str(self.style.name)
        return ret

# Migration code
# roomhints=> insert into roomhints_roomhint(project_id,hint_id,profile_id,seconds,love,love_count,public) select p.id, h.id, pr.id, h.seconds, h.love, h.love_count, h.public from roomhints_project p, roomhints_hint h, roomhints_profile pr where p.id = h.project_id and h.profile_id = pr.id;
# INSERT 0 135
class RoomHint(models.Model):
    project = models.ForeignKey(Project)
    hint = models.ForeignKey(Hint)
    profile = models.ForeignKey(Profile) # The user who added this hint to this project
    seconds = models.DateTimeField(default=datetime.utcnow)
    love = models.BooleanField() # Whether the project owner liked this hint
    love_count = models.IntegerField(default=0) # Cached copy of the total likes of this hint on this project
    public = models.BooleanField(default=True) # A RoomHint that was "deleted" is marked non-public
    delete_seconds = models.DateTimeField(null=True,blank=True)
    received_seconds = models.DateTimeField(null=True,blank=True) # Time the user received the hint

    def __unicode__(self):
        try:
            ret = str(self.project.name) + ", " + str(self.hint.source)
        except Exception, e:
            ret = self.project.name
        return ret

# Migration code
# roomhints=> insert into roomhints_roomhintlike(prof_id,roomhint_id,seconds,liked) select l.prof_id, r.id, l.seconds, l.liked from roomhints_like l, roomhints_roomhint r where l.hint_id = r.hint_id;
# INSERT 0 27
class RoomHintLike(models.Model):
    prof = models.ForeignKey(Profile)
    roomhint = models.ForeignKey(RoomHint)
    seconds = models.DateTimeField(default=datetime.utcnow)
    liked = models.BooleanField()

class ProjectImpression(models.Model):
    prof = models.ForeignKey(Profile)
    project = models.ForeignKey(Project)
    seconds = models.DateTimeField(default=datetime.utcnow)
    meta = models.TextField() # metadata, should be a separate table
    # view, web_view, pinterest, facebook, twitter, email
    ip = models.IPAddressField(blank=True,null=True)

# Migration code
# roomhints=> insert into roomhints_roomhintimpression(prof_id,roomhint_id,seconds) select hi.prof_id, rh.id, hi.seconds from roomhints_hintimpression hi, roomhints_roomhint rh where rh.hint_id = hi.hint_id;
# INSERT 0 227
class RoomHintImpression(models.Model):
    prof = models.ForeignKey(Profile)
    roomhint = models.ForeignKey(RoomHint)
    seconds = models.DateTimeField(default=datetime.utcnow)
    meta = models.TextField() # metadata, should be a separate table
    # view, browse_start, browse_stop, web_browse_start, web_browse_stop
    ip = models.IPAddressField(blank=True,null=True)

class Category(models.Model):
    name = models.TextField()

    def __unicode__(self):
        return self.name

class Feedback(models.Model):
    content = models.TextField()
    seconds = models.DateTimeField(default=datetime.utcnow)
    profile = models.ForeignKey(Profile)
    feeduniq = models.TextField()
    notifiedus = models.BooleanField(default=False)

    def __unicode__(self):
        return str(self.seconds.strftime("%Y-%m-%d %H:%M:%S")) + ", " + self.content


class Comment(models.Model):
    project = models.ForeignKey(Project)
    profile = models.ForeignKey(Profile) # the user who created the comment
    communiq = models.TextField(default=make_unique)
    seconds = models.DateTimeField(default=datetime.utcnow)
    content = models.TextField(blank=True,null=True)
    photo = models.ImageField(upload_to='pics/comments/',storage=mfs,blank=True,null=True,default=make_unique_photo)
    photo_web = models.ImageField(upload_to='pics/comments/',storage=mfs,blank=True,null=True)
    photo_mob = models.ImageField(upload_to='pics/comments/',storage=mfs,blank=True,null=True)
    public = models.BooleanField(default=True)
    received_seconds = models.DateTimeField(null=True,blank=True) # Time the user received the hint
    auto_responded = models.BooleanField(default=False)
    # Time the designer received an email about the comment, if this was a paying customer
    des_notified = models.BooleanField(default=False)

    def __unicode__(self):
        return str(self.seconds.strftime("%Y-%m-%d %H:%M:%S")) + ", " + self.content

class FrontPhoto(models.Model):
    seconds = models.DateTimeField(default=datetime.utcnow)
    photo_web = models.ImageField(upload_to='pics/front/',storage=mfs,default=make_unique_photo)

    def __unicode__(self):
        return str(self.photo_web.name)

class Beta(models.Model):
    email = models.EmailField()
    seconds = models.DateTimeField(default=datetime.utcnow)
    betauniq = models.TextField()
    am_designer = models.BooleanField(default=False)
    am_brand = models.BooleanField(default=False)
    want_designer = models.BooleanField(default=False)
    notifiedus = models.BooleanField(default=False)
    notifiedthem = models.BooleanField(default=False)
    used = models.BooleanField(default=False)
    invited = models.BooleanField(default=False)

    def __unicode__(self):
        ret = self.email
        if self.am_designer:
            ret += ", IS designer"
        if self.want_designer:
            ret += ", WANTS designer"
        if self.am_brand:
            ret += ", is BRAND"
        return ret

class DefaultHint(models.Model):
    name = models.TextField()
    # Here is the syntax for adding foreign key constraints later on
    #alter table roomhints_defaulthint add constraint "roomhints_hint_project_id_fkey" FOREIGN KEY (category_id) REFERENCES roomhints_category(id) DEFERRABLE INITIALLY DEFERRED;
    category = models.ForeignKey(Category)
    keywords = models.TextField()
    price = models.FloatField()
    source = models.TextField()
    source_url = models.URLField(max_length=1024)
    photo = models.ImageField(upload_to='pics/default_hints/',storage=mfs,default=make_unique_photo)
    seconds = models.DateTimeField(default=datetime.utcnow)
    hintuniq = models.TextField(default=make_unique)
    public = models.BooleanField(default=True)

    def __unicode__(self):
        return self.name + ", " + self.source + ", $" + '{:20,}'.format(int(self.price)) + ", " + self.category.name

class ChoiceImpressionGroup(models.Model):
    # There is no profile here, because it is only owners of projects that view ChoiceImpressions
    project = models.ForeignKey(Project)
    seconds = models.DateTimeField(default=datetime.utcnow)
    dominant_hex = models.TextField()

class ChoiceImpression(models.Model):
    dhint = models.ForeignKey(DefaultHint)
    group = models.ForeignKey(ChoiceImpressionGroup)
    chosen = models.BooleanField(default=False)
    color_score = models.FloatField()
    feature_score = models.FloatField()
    total_score = models.FloatField()
    dominant_hex = models.TextField()

class SearchImpressionGroup(models.Model):
    project = models.ForeignKey(Project)
    seconds = models.DateTimeField(default=datetime.utcnow)
    custom = models.TextField()

class SearchImpression(models.Model):
    hint = models.ForeignKey(Hint)
    group = models.ForeignKey(SearchImpressionGroup)
    chosen = models.BooleanField(default=False)
    color_score = models.FloatField()
    feature_score = models.FloatField()
    total_score = models.FloatField()
    dominant_hex = models.TextField()

class AffiliateRedirection(models.Model):
    reduniq = models.TextField(default=make_unique)
    seconds = models.DateTimeField(default=datetime.utcnow)
    hint = models.ForeignKey(Hint)
    target = models.TextField()

class HintSimilarity(models.Model):
    one = models.ForeignKey(Hint,related_name='one')
    two = models.ForeignKey(Hint,related_name='two')
    color_score = models.FloatField()
    feature_score = models.FloatField()
    total_score = models.FloatField()

class Event(models.Model):
    prof = models.ForeignKey(Profile)
    seconds = models.DateTimeField(default=datetime.utcnow)
    meta = models.TextField() # metadata, should be a separate table
    # app_start, app_open, app_close
    ip = models.IPAddressField(blank=True,null=True)
