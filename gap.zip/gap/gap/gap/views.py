from django.views.generic.simple import direct_to_template
from django.conf import settings
from django.http import HttpResponsePermanentRedirect, Http404
from django.views.generic import ListView, DetailView
from django.db.models import get_model
from django.utils.translation import ugettext_lazy as _

from oscar.core.loading import get_class
from oscar.apps.catalogue.signals import product_viewed, product_search

Product = get_model('catalogue', 'product')
ProductAttribute = get_model('catalogue', 'ProductAttribute')
AttributeOption = get_model('catalogue', 'AttributeOption')
AttributeOptionGroup = get_model('catalogue', 'AttributeOptionGroup')
AttributeEntityType = get_model('catalogue', 'AttributeEntityType')
ProductReview = get_model('reviews', 'ProductReview')
Category = get_model('catalogue', 'category')
ProductAlert = get_model('customer', 'ProductAlert')
ProductAlertForm = get_class('customer.forms',
                             'ProductAlertForm')

def product_options(request, p_class, id, step):
    step = int(step)
    
    if step == 1:
        attributes = ProductAttribute.objects.filter(entity_type = step).filter(product_class = p_class)
        atrr_options = AttributeOption.objects.get(id=1)
    if step == 2:
        attributes = ProductAttribute.objects.filter(entity_type = step).filter(product_class = p_class)
        request.session['options'] = get_options_from_post(request)
    if step == 3:
        attributes = {}
        if 'options' in request.session:
            opt = get_options_from_post(request) + request.session['options']
            request.session['options'] = opt
            options = Option.objects.filter(id__in=opt)
            print options
    else:
        options = 0

    next_step = int(step) + 1

    return direct_to_template(request, 'product_options.html',{
        'product':Product.objects.get(id = id),
        'p_class':p_class,
        'categories':Category.objects.all(),
        'step':step,
        'next_step':next_step,
        'attributes':attributes,
        'options':options,
        'atrr_options': atrr_options,
        })

def get_options_from_post(request):
    opt = []
    for k, option in request.POST.items():
        print k
        print option
        if k[:k.rfind('_')] == 'options':
            opt.append(request.POST.get(k))
        print opt
    return opt

def get_quote(request, id):
    product = Product.objects.get(id = id),
    product = product[0]
    #prices = product.prices()
    #prices = serializers.serialize('json', product.prices())
    #prices = json.dumps(product.prices())
    #print prices

    return direct_to_template(request, 'get_quote.html',{
        'product': id,
        'categories':2,
        'step':4,
        'prices':{1: 100, 2: 200},
        })