from django.shortcuts import render
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.models import User
from django.core.validators import validate_email
from django.template.response import TemplateResponse
from django.http import HttpResponseRedirect
from .models import SignUp, FileField
from .forms import UploadFileForm

# Create your views here.

def home(request):
    context = {'results': "asdf"}
    return render(request, 'index.html', context)

def registration(request):
    template = 'registration.html'

    if request.method == 'POST':
        first_name = request.POST.get('first_name', None).strip()
        last_name = request.POST.get('last_name', None).strip()
        area = request.POST.get('area', None).strip()
        phone = request.POST.get('phone', None).strip()
        email = request.POST.get('email', None).lower().strip()
        school_name = request.POST.get('school_name', None).strip()
        Academic = request.POST.get('Academic', None).strip()

        try:
            validate_email(email)
        except:
            errors = True
            error_string = "Invalid emaill address"
            return TemplateResponse(request, template, locals())
        username_exits = SignUp.objects.filter(username = email)

        if username_exits:
            errors = True
            error_string = "User already exists"
            return TemplateResponse(request, template, locals())
        # new_user = User.objects.create_user(first_name, last_name, email)
        new_user = SignUp.objects.create_user(first_name, last_name, area, phone, email, school_name, Academic)
        new_user.save()

        return HttpResponseRedirect(reversed('home'))

    return TemplateResponse(request, template, locals())

def publishers(request):
    if request.method == 'POST':
        img = UploadFileForm(request.POST, request.FILES)
        if img.is_valid():
            img.save()
            return HttpResponseRedirect('/publishers/')
    else:
        img = UploadFileForm()
    images = FileField.objects.all()
    return render(request, 'publishers.html', {'form': img, 'images': images})

def features(request):
    context = {'results': "asdf"}
    return render(request, 'features.html', context)

def members(request):
    context = {'results': "asdf"}
    return render(request, 'members.html', context)

