import logging
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from ...core.models import Shop
from ..items import CategoryItem, Product


logger = logging.getLogger('spider')


class MacysSpider(CrawlSpider):
    name = 'macys'
    domain = 'macys.com'
    allowed_domains = ['www.macys.com', 'www1.macys.com',]
    start_urls = [
        'http://www.macys.com/',
    ]

    rules = (
        # Rule(SgmlLinkExtractor(allow=('shop\/product', )), callback='parse_item'),  # We collect products only
        Rule(SgmlLinkExtractor(), callback='parse_category'),  # Continue following all URLs
    )

    def __init__(self, *args, **kwargs):
        self.shop, created = Shop.objects.get_or_create(domain=self.domain)
        if created:
            logger.info('Created a new shop: %s', self.shop)
        super(MacysSpider, self).__init__(*args, **kwargs)

    def parse_category(self, response):
        hxs = HtmlXPathSelector(response)

        categories = hxs.select('//div[@id="nav_title"]/h1/a/text()').extract()
        subcategories = hxs.select('//ul[@class="nav_cat_sub_3"]/li/a/text()')
        if len(categories):
            category = CategoryItem()
            category['shop'] = self.shop
            category['name'] = categories[0].strip()
            if not len(subcategories):
                return category

        for entry in subcategories:
            subcategory = CategoryItem()
            subcategory['shop'] = self.shop
            subcategory['parent'] = category
            subcategory['name'] = entry.extract().strip()
            return subcategory

    def parse_item(self, response):
        hxs = HtmlXPathSelector(response)

        product = Product()
        product['name'] = hxs.select('//h1[@id="productTitle"]/text()').extract()[0].strip()
        product['sku'] = hxs.select('//div[@class="productID"]/text()').re(r'(\d+)')[0]
        product['url'] = response.url
        return product
