# Create your views here.
from django.http import Http404, HttpResponse
from django.template import loader, RequestContext
from arktotalwealth.team.models import *
from arktotalwealth import common

def home(request, slug=None):
    path = TeamPage.objects.filter(parent__isnull=True,active=True)
    path = path[0] if path else ''
    topnav = TeamPage.objects.filter(parent = path, active=True)
    if slug:
        t = loader.get_template('page.html')
        page = TeamPage.objects.get(slug=slug)
    else:
        t = loader.get_template('miscpage.html')
        page = path
        
    teammembers = TeamMember.objects.all()
        
    c = RequestContext(request,common.commondict({'path':path,'page':page,'topnav':topnav,'teammembers':teammembers},request))
    
    return HttpResponse(t.render(c))