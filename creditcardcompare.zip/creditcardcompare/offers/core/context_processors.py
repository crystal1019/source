from sys import modules
from django.conf import settings
from django.contrib.sites.models import Site
from models import Category, PerSiteCategoryOption
from helpers import generate_post_click

def sites(request):
    context = {'IMAGE_URL': settings.IMAGE_URL,
               'FB_CLIENT_ID': settings.FB_CLIENT_ID,
               'FB_CLIENT_SECRET': settings.FB_CLIENT_SECRET,
               'FB_NAMESPACE': settings.FB_NAMESPACE,
               'site': Site.objects.get(id=settings.SITE_ID),
               'domain': settings.INTERNAL_LINK,
            }
    return context

def categories(request):
    try:
        return getattr(modules[__name__], 'categories%s' % settings.SITE_ID)(request)
    except AttributeError:
        return {}

def categories8(request):  # creditcardcompare.com.au
    from offers.helpers.messages.models import Message
    post_click = generate_post_click('bank-accounts') or generate_post_click('loans') or generate_post_click('home-loans')
    if request.is_ajax():
        return {'post_click': post_click}
    
    feature_list = PerSiteCategoryOption.objects.filter(site=Site.objects.get(id=settings.SITE_ID),
                                                        category__parent__slug='credit-card-features',
                                                        category__is_visible=True,
                                                        on_navbar=True).order_by('category__name')
    issuer_list = Category.on_site.filter(parent__slug='credit-card-issuers', is_visible=True)
    feature_count = len(feature_list) + 1
    issuer_count = len(issuer_list) + 2
    
    return {
        'post_click': post_click, 
        'first_feature_list': feature_list[:int(feature_count/2)],
        'second_feature_list': feature_list[int(feature_count/2):],
        'first_issuer_list': issuer_list[:int(issuer_count/2)],
        'second_issuer_list': issuer_list[int(issuer_count/2):],
        'message_objs': Message.objects,
    }
