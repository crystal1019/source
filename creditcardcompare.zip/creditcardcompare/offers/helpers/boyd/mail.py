from django.conf import settings
from django.core.mail import get_connection, EmailMessage
from django.template import Context
from django.template.loader import get_template
from . import GenericThread


class GenericMailThread(GenericThread):
    '''
    GenericMailThread(**{
        'email': '',
        'sender': '',
        'subject': '',
        'context': {},
        'template': '',
        'file_path': '',
        'connection': None,  # remove this line to use Sendgrid
    }).start()
    '''
    def __init__(self, *args, **kwargs):
        super(GenericMailThread, self).__init__(self.send_func, *args, **kwargs)
        
    def send_func(self, *args, **kwargs):
        html = get_template(self.kwargs['template'])
        context = self.kwargs.get('context', {})
        context.update({'domain': settings.INTERNAL_LINK, 'STATIC_URL': settings.STATIC_URL})
        html_content = html.render(Context(context))
        msg = EmailMessage(
                   self.kwargs['subject'],
                   html_content,
                   self.kwargs.get('sender', settings.REVIEW_MODERATOR),
                   [self.kwargs['email']],
                   bcc=self.kwargs.get('bcc', None),
                   connection=self.kwargs.get('connection', self.get_connection()))
        msg.content_subtype = "html"  # Main content is now text/html
        try:
            path = self.kwargs['file_path']
        except KeyError:
            pass
        else:
            msg.attach_file(path)
        msg.send()
        
    def get_connection(self):
        if settings.DEBUG:
            return None
        SENDGRID = settings.SENDGRID
        return get_connection(
                        host=SENDGRID['EMAIL_HOST'], 
                        port=SENDGRID['EMAIL_PORT'],
                        username=SENDGRID['EMAIL_HOST_USER'],
                        password=SENDGRID['EMAIL_HOST_PASSWORD'],
                        use_tls=SENDGRID['EMAIL_USE_TLS']
                    )
