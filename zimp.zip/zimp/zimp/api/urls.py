from django.conf import settings
from django.conf.urls import patterns, include, url
from django.contrib.staticfiles.urls import staticfiles_urlpatterns, static

urlpatterns = patterns('',
    #(r'^$', 'zimp.views.index'),
)
