from googledocs.utils import get_sheet_rows
from offers.core.models import Offer


CREDITCARDCOMPARE = 8  # creditcardcompare.com.au

def replace_desc(offer, desc):
    options = offer.site_options.filter(site__id=CREDITCARDCOMPARE)
    option = options[0]
    option.table_description = desc
    option.save()
    print '%s: --------------------------------------------' % line

rows = get_sheet_rows('Template Tag Enhancements', password='noel2109')
line = 1
for row in rows:
    line += 1
    if row['enhanced'] is None:
        if line < 111:
            print '%s: no enhanced description' % line
        continue
    try:
        offer = Offer.objects.get(title=row['creditcard'])
    except Offer.DoesNotExist:
        print '%s: card not found: "%s"' % (line, row['creditcard'])
        continue
    if row['enhanced'] == offer.seo_page_options['table_description']:
        continue
    if row['existing'] != offer.seo_page_options['table_description']:
        print '%s: outdated description' % line
        continue
    replace_desc(offer, row['enhanced'])