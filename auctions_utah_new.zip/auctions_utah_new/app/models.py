__author__ = 'RJB'
from app import db, login_manager
from sqlalchemy.orm.exc import NoResultFound
import datetime
from flask import request, current_app
import hashlib
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from werkzeug.security import generate_password_hash, check_password_hash
from flask.ext.login import UserMixin


class Properties(db.Model):
    """Represents an upcoming foreclosure auction property"""
    __tablename__     = 'properties'
    id                = db.Column(db.Integer, primary_key=True)
    trustee           = db.Column(db.String, nullable=False)
    tsnumber          = db.Column(db.String(15))
    date_created      = db.Column(db.DateTime, default=datetime.datetime.now)
    date_updated      = db.Column(db.DateTime)
    utahlegals_date   = db.Column(db.DateTime)
    utahlegals_incomplete = db.Column(db.String)
    tax_data_date     = db.Column(db.DateTime)  # when tax data was pulled
    comps_date        = db.Column(db.DateTime)  # when comps were pulled, renew every 90 days
    full_name         = db.Column(db.String(100))
    last_name         = db.Column(db.String(50))
    status            = db.Column(db.Text)
    sale_date         = db.Column(db.DateTime)
    address           = db.Column(db.String)
    county            = db.Column(db.String)
    opening_bid       = db.Column(db.String)
    asking            = db.Column(db.Integer)
    scraped_row       = db.Column(db.Text, nullable=False)  # raw scraped row
    legal_ad          = db.Column(db.Text)  # full legal announcement
    parcel_number     = db.Column(db.String)
    lat_lon           = db.Column(db.String)
    tax_data          = db.relationship('TaxData', backref=db.backref('subject_property', uselist=False, passive_updates=False))
    comps             = db.relationship('Comps', secondary='props_comps', lazy='dynamic')
    basic_analysis    = db.relationship('BasicAnalysis', backref=db.backref('subject_property', uselist=False))
    reports           = db.relationship('Reports', backref='subject_property', lazy='dynamic')
    proc_status       = db.Column(db.String)  # processing comments/status codes?

    def __str__(self):
        return '%s: %s' % (self.tsnumber, self.address)

    def update_or_save(self):
        try:
            existing_entry = db.session.query(Properties).filter(Properties.tsnumber == self.tsnumber).one()
            sale_date_changed = not existing_entry.sale_date or (existing_entry.sale_date != self.sale_date)
            status_changed = (existing_entry.status != self.status)
            bid_changed = (existing_entry.opening_bid != self.opening_bid)
            if sale_date_changed or bid_changed or status_changed:
                print "Updating existing entry for Address: %s" % self.address
                existing_entry.sale_date = self.sale_date
                existing_entry.status = self.status
                existing_entry.opening_bid = self.opening_bid
                existing_entry.date_updated = datetime.datetime.now()
                existing_entry.scraped_row = self.scraped_row
                existing_entry.address = self.address
                existing_entry.full_name = self.full_name
                existing_entry.last_name = self.last_name
                existing_entry.parcel_number = self.parcel_number
                if self.legal_ad:
                    existing_entry.legal_ad = self.legal_ad
            else:
                print "Data for %s under File #: %s is current." % (self.trustee, self.tsnumber)
                return
        except NoResultFound:
            print "Adding new row for %s file #: %s" % (self.trustee, self.tsnumber)
            db.session.add(self)
        db.session.commit()

    def bid_to_int(self):
        """turn the opening bid string into an int (chops off decimal values)
         and stores it under the 'asking' attribute"""
        if self.opening_bid:
            print 'Converting opening bid to integer.'
            self.opening_bid = self.opening_bid.strip()
            print 'Opening bid: ', self.opening_bid
            if (self.opening_bid != '0') and (self.opening_bid != '$0.00'):
                if self.opening_bid.find('.') != -1:
                    tmp = self.opening_bid[:-3]
                else:
                    tmp = self.opening_bid
                self.asking = int(''.join(char for char in tmp if char.isdigit()))


class TaxData(db.Model):
    __tablename__    = 'tax_data'
    id               = db.Column(db.Integer, primary_key=True)
    date_created     = db.Column(db.DateTime, default=datetime.datetime.now)
    date_updated     = db.Column(db.DateTime)
    property_id      = db.Column(db.Integer, db.ForeignKey('properties.id'), nullable=False)
    parcel_number    = db.Column(db.String, nullable=False)
    address          = db.Column(db.String)
    lot_acres        = db.Column(db.Numeric)
    bedrooms         = db.Column(db.Integer)
    full_baths       = db.Column(db.Integer)
    three_quarter_baths = db.Column(db.Integer)
    half_baths       = db.Column(db.Integer)
    bld_style        = db.Column(db.String)
    kitchens         = db.Column(db.Integer)
    total_sqft       = db.Column(db.Integer)
    area_info        = db.Column(db.String)  # Contains db.Strings describing itemized area tally in sqft: 'Main Area: x,xxx sq ft'
    property_type    = db.Column(db.String)
    lat_lon          = db.Column(db.String)
    stories          = db.Column(db.Numeric)
    year_built       = db.Column(db.Integer)
    proc_status      = db.Column(db.String)  # Processing comments/status codes?

    def save(self):
        today = datetime.datetime.today()
        try:
            exists = db.session.query(TaxData).filter_by(property_id=self.property_id).one()
            print 'Tax record exists for parcel#: %s, UPDATING...' % exists.parcel_number
            self.id = exists.id
            self.date_updated = today
            db.session.merge(self)
        except NoResultFound:
            print 'Adding tax data for Parcel#: %s' % self.parcel_number
            db.session.add(self)
        finally:
            db.session.query(Properties).filter_by(id=self.property_id).update({'tax_data_date': today, 'lat_lon': self.lat_lon})
            db.session.commit()


class Comps(db.Model):
    __tablename__    = 'comps'
    mls_id           = db.Column(db.Integer, primary_key=True)
    created_date     = db.Column(db.DateTime, default=datetime.datetime.now)
    address          = db.Column(db.String, nullable=False)
    total_sqft       = db.Column(db.Integer)
    bedrooms         = db.Column(db.Integer)
    bathrooms        = db.Column(db.Integer)
    list_date        = db.Column(db.DateTime, nullable=False)
    sold_date        = db.Column(db.DateTime)
    sold_price       = db.Column(db.Integer)
    style            = db.Column(db.String)
    basement_type    = db.Column(db.String)
    finished_basement= db.Column(db.String)
    garages          = db.Column(db.Integer)
    carports         = db.Column(db.Integer)
    acres            = db.Column(db.String)
    subject_properties = db.relationship('Properties', secondary='props_comps', passive_updates=False)
    list_price       = db.Column(db.Integer, nullable=False)
    status           = db.Column(db.String, nullable=False)
    fm_rooms         = db.Column(db.Integer)
    year_built       = db.Column(db.Integer)
    property_type    = db.Column(db.String)
    lat_lon          = db.Column(db.String, nullable=False)
    sold_terms       = db.Column(db.String)
    concessions      = db.Column(db.Integer)
    taxes            = db.Column(db.Integer)
    hoa_fee          = db.Column(db.Integer)
    price_per        = db.Column(db.Integer)
    area             = db.Column(db.String)
    proj_subdiv      = db.Column(db.String)
    school_dist      = db.Column(db.String)
    tax_id           = db.Column(db.String)
    remarks          = db.Column(db.Text)
    agt_remarks      = db.Column(db.Text)
    dom              = db.Column(db.Integer)
    cdom             = db.Column(db.Integer)
    ctdom            = db.Column(db.Integer)
    contract_date    = db.Column(db.DateTime)

    def existing_or_new(self):
        """determines if the comp entry already exists, if it does then existing entry is returned
        if it does not exist the instance is returned.
        Meant to be used before the instance is appended to the Properties.comps list of a Properties instance"""
        return db.session.query(Comps).get(self.mls_id) or self

    def store(self):
        """saves if new"""
        exists = db.session.query(Comps).get(self.mls_id)
        if not exists:
            db.session.add(self)
            db.session.commit()

    def update(self):
        db.session.merge(self)
        db.session.commit()


class BasicAnalysis(db.Model):
    __tablename__ = 'basic_analysis'
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey('properties.id'), nullable=False)
    opening_bid = db.Column(db.Integer)
    avg_dom = db.Column(db.Integer)
    mad_dom = db.Column(db.String)
    sold_date_high = db.Column(db.DateTime)
    sold_date_low = db.Column(db.DateTime)
    comps_count = db.Column(db.Integer)
    comps_price_high = db.Column(db.Integer)
    comps_price_low = db.Column(db.Integer)
    avg_price = db.Column(db.Integer)
    mad_adj_price = db.Column(db.Integer)
    potential_gross = db.Column(db.Integer)
    mad_adj_gross = db.Column(db.Integer)
    price_sqft = db.Column(db.Integer)
    pct_chng_over_90days = db.Column(db.Integer)

    def save(self):
        db.session.add(self)
        db.session.commit()


#many-to-many between comps and properties
props_comps = db.Table('props_comps', db.metadata,
                       db.Column('property_id', db.Integer, db.ForeignKey('properties.id')),
                       db.Column('comp_id', db.Integer, db.ForeignKey('comps.mls_id')))

#props_reports = db.Table('props_reports', db.metadata,
#                         db.Column('property_id', db.Integer, db.ForeignKey('properties.id')),
#                         db.Column('report_id', db.Integer, db.ForeignKey('reports.id')))


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(64), nullable=False, unique=True, index=True)
    username = db.Column(db.String(64), nullable=False, unique=True, index=True)
    is_admin = db.Column(db.Boolean, default=False)
    password_hash = db.Column(db.String(128))
    name = db.Column(db.String(64))
    location = db.Column(db.String(64))
    member_since = db.Column(db.DateTime(), default=datetime.datetime.now)
    avatar_hash = db.Column(db.String(32))
    reports = db.relationship('Reports', backref='user', lazy='dynamic')

    def save(self):
        db.session.add(self)
        db.session.commit()

    def get_api_token(self, expiration=300):
        s = Serializer(current_app.config['SECRET_KEY'], expiration)
        return s.dumps({'user': self.id}).decode('utf-8')

    @staticmethod
    def validate_api_token(token):
        s = Serializer(current_app.config['SECRET_KEY'])
        try:
            data = s.loads(token)
        except:
            return None
        id = data.get('user')
        if id:
            return User.query.get(id)
        return None

    def __init__(self, **kwargs):
        super(User, self).__init__(**kwargs)
        if self.email is not None and self.avatar_hash is None:
            self.avatar_hash = hashlib.md5(
                self.email.encode('utf-8')).hexdigest()

    def gravatar(self, size=100, default='identicon', rating='g'):
        if request.is_secure:
            url = 'https://secure.gravatar.com/avatar'
        else:
            url = 'http://www.gravatar.com/avatar'
        hash = self.avatar_hash or \
            hashlib.md5(self.email.encode('utf-8')).hexdigest()
        return '{url}/{hash}?s={size}&d={default}&r={rating}'.format(
            url=url, hash=hash, size=size, default=default, rating=rating)

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class Reports(db.Model):
    __tablename__ = 'reports'
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey('properties.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    comp_ids = db.Column(db.String)  # csv string of comp mls_id's
    comments = db.Column(db.Text)
    estimated_sale_price = db.Column(db.Integer)

    def get_estimate(self):
        from app.scraper.utahRE import CompStat
        stats = CompStat(
            self.subject_property.comps.filter(
                Comps.mls_id.in_(self.comp_ids.split(','))
            )
        )
        stats.calculate()
        self.estimated_sale_price = stats.mad_comp