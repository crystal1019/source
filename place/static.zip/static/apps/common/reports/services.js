angular.module('activity.services', []).factory('ConnectionReportData', ['$http', '$q',
    function($http, $q) {
        var url = ' /report/activity/connections/';
        return {
            is_dirty: false,
            layer: null,
            gmap: null,
            store: null,
            originaltable: null,
            active: false,
            defer: $q.defer(),
            obj_id: null,
            load: function(obj_id, is_psc) {
                this.obj_id = obj_id;
                var self = this;
                if (!this.active) {
                    this.active = true;
                    $http({
                        method: 'GET',
                        url: url + obj_id + "/",
                        params: {
                            'psc': is_psc
                        }
                    }).success(function(obj) {
                        _.each(obj.data.data_points, function(day) {
                            day.date = new Date(day.date).getTime();
                        });
                        self.store = obj.data;
                        self.defer.resolve(obj);
                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            }
        };
    }
]).factory('MapLayer', [

    function() {
        return {
            layer: null,
            gmap: null
        };
    }
]).factory('PollReportData', ['$http', '$q',
    function($http, $q) {
        var url = ' /report/activity/poll/';
        return {
            is_dirty: false,
            layer: null,
            gmap: null,
            store: null,
            originaltable: null,
            active: false,
            defer: $q.defer(),
            topic: null,
            load: function(topic) {
                this.topic = topic;
                var self = this;
                if (!this.active) {
                    this.active = true;
                    $http({
                        method: 'GET',
                        url: url + topic + "/",
                        params: {
                            'topic': topic
                        }
                    }).success(function(obj) {
                        _.each(obj.data.data_points, function(day) {
                            day.date = new Date(day.date).getTime();
                        });
                        self.store = obj.data;
                        self.defer.resolve(obj);
                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            }
        };
    }
]).factory('NoticeboardReportData', ['$http', '$q',
    function($http, $q) {
        var url = ' /report/activity/noticeboard/';
        return {
            is_dirty: false,
            layer: null,
            gmap: null,
            store: null,
            originaltable: null,
            active: false,
            defer: $q.defer(),
            topic: null,
            load: function(topic) {
                this.topic = topic;
                var self = this;
                if (!this.active) {
                    this.active = true;
                    $http({
                        method: 'GET',
                        url: url + topic + "/",
                        params: {
                            'topic': topic
                        }
                    }).success(function(obj) {
                        _.each(obj.data.data_points, function(day) {
                            day.date = new Date(day.date).getTime();
                        });
                        self.store = obj.data;
                        self.defer.resolve(obj);
                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            }
        };
    }
]).factory('SurveyReportData', ['$http', '$q',
    function($http, $q) {
        var url = ' /report/activity/survey/';
        return {
            is_dirty: false,
            layer: null,
            gmap: null,
            store: null,
            originaltable: null,
            active: false,
            defer: $q.defer(),
            topic: null,
            load: function(topic) {
                this.topic = topic;
                var self = this;
                if (!this.active) {
                    this.active = true;
                    $http({
                        method: 'GET',
                        url: url + topic + "/",
                        params: {
                            'topic': topic
                        }
                    }).success(function(obj) {
                        _.each(obj.data.data_points, function(day) {
                            day.date = new Date(day.date).getTime();
                        });
                        self.store = obj.data;
                        self.defer.resolve(obj);
                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            }
        };
    }
]).factory('DiscussionReportData', ['$http', '$q',
    function($http, $q) {
        var url = ' /report/activity/discussions/';
        return {
            is_dirty: false,
            layer: null,
            gmap: null,
            store: null,
            originaltable: null,
            active: false,
            defer: $q.defer(),
            topic: null,
            load: function(topic) {
                this.topic = topic;
                var self = this;
                if (!this.active) {
                    this.active = true;
                    $http({
                        method: 'GET',
                        url: url + topic + "/",
                        params: {
                            'topic': topic
                        }
                    }).success(function(obj) {
                        _.each(obj.data.data_points, function(day) {
                            day.date = new Date(day.date).getTime();
                        });
                        self.store = obj.data;
                        self.defer.resolve(obj);
                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            }
        };
    }
]);
/*****urls for services**********\
	' /report/activity/poll/'
	' /report/activity/connections/'
	' /report/activity/noticeboard/'
	' /report/activity/discussions/'
	' /report/activity/surveys/'
	\*********************************/