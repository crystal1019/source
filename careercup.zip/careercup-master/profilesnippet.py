import masterpage

import method_user
import method_url
import method_cache

import logging

class ProfileSnippet(masterpage.MasterPage):
	def get(self):
		userid = method_url.getId(self)
		user_html = method_cache.getObjectForTypeAndKey(method_user.cache_key_user_profile, str(userid))
		if not user_html:
			user = method_user.getUserWithId(userid)
				
			template_values = {
				'item' : user			
			}
			user_html = self.getBody(template_values, 'html/profilesnippet.html')
			method_cache.setObjectForTypeAndKey(method_user.cache_key_user_profile, str(userid), user_html)		
		userinfo = method_user.getLoggedInUserFromCache()
		if userinfo:
			favorites = method_user.getFavoriteUsersForUser(userinfo)
			script = None
			logging.info(userid)
			logging.info(userinfo['uid'])
			if userid == userinfo['uid']:
				script = '<script>$(\'#user' + str(userid) + 'favorite\').hide();</script>'
			else:
				if favorites is not None and userid in favorites:
					script = '<script>postFavoriteResponse(' + str(userid) + ', 1, \'user\');</script>'
			if script:
				user_html = user_html.replace('</body>', script + '</body>')
		self.response.out.write(user_html)