from django import forms
from django.forms.widgets import Input
from django import forms as django_forms

class Html5EmailInput(Input):
    input_type = 'email'


class LoginForm(forms.Form):
    email = forms.CharField(widget=Html5EmailInput(attrs={'placeholder': 'Email'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))


class RecipeForm(forms.Form):
    title = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Title'}))
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 5, 'placeholder': 'Description'}))
    file = forms.ImageField(required=False)
    contents = django_forms.CharField(
        widget = django_forms.Textarea(
            attrs={
                'cols': 80, 'rows': 15, 'class': 'data_field',
                'placeholder': 'Type your recipe here.' + \
                    ' Don\'t forget to mention your sources...'
                }
            ),
        required=False
    )

    extra = forms.CharField(widget=forms.HiddenInput(), initial='photo')
    typ = forms.CharField(widget = django_forms.HiddenInput(), initial='2')