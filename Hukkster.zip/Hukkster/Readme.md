Hukkster.com 
============

Hukkster is a site that records products using per-url scraping. The Scraper Framework is written in Python Django, using PgSQL as a datastore.


## Purpose:

We need to quickly write web scrapers that will capture product details, including it's attributes and it's price, from retail websites.

## What to Deliver:

You'll be expected to provide a scraper that we can plug into our Django Framework. Please use the following scraper as a model:

```
hukkster.scraper.scrapers.macys     
```

Please create a branch here, and name it after the domain you're scraping, for instance:

```
git checkout -b mycool-scraper
```

Then once you've finished, issue a pull request, and we'll review your work, and get back as soon as we can with feedback.

## Code Coverage:

The scraper needs to demonstrate an ability to understand both HTML and Javacript, and should capture the following attributes:

* Product Store Code (Just use the domain name of your URL)
* Product Unique ID (local_id in the json)
* Product Title
* Product Current Price
* Product Size(s)
* Product Color(s)
* Product Image(s) (Per-Color, Largest Available Image Resolution)

The following attributes should also be checked, and if not applicable, return either false (sold out) or a null array "[]" (promo):

* Is Product Sold Out
* Does Product Have a Promo
* Product "Original Price"
* Product Discount Code (If Any)

Your scraper should also use the provided logging actions and have a "debug" mode so evaluating the process in runtime is easy to understand.

## Technology:

You can use any libraries you find appropriate to the task, within limits. Scrapers need to be fast, scalable, and easy to read and modify. 
We currently use BeautifulSoup for most of our work, but you may use any GPL non-licensed Python scraping libraries, provided we can install and
run them in AWS on CentOS 6.2 in Python 2.7.

## Time:

Writing scrapers should be fast. If you�re work is accepted, you�ll be asked to write scrapers that work on every product in a specific website, so keep in mind that the few URLs you scrape may or may not represent all other products on that site.
Your scraper should be able to account for that. If any scraper is very complicated and looks like it will take more than 3 hours to write, 
please communicate that back to us and we'll probably send you a different scraper.

## The Goal:

Hukkster.com wants you to succeed in this exercise, so if this document isn�t clear, feel free to ask questions via oDesk. 
Please make sure that the questions aren�t something found in Google, and should not be about how to write the script, but we want to have success, so will try to be as helpful as possible. 
Also, we have a number of projects being developed at any given moment, so if you do well on this project, and have greater talents or aspirations, other projects may become available with different requirements for different skills. So good luck, we�re counting on you!

## JSON Format

You can find an example of the JSON output here:

https://github.com/Goldcap/hukkster/wiki/JSON-Format

## Testing

We are in the process of writing spiders (crawlers) to obtain all potential product URL's for each domain, and once we have that, your scraper will be tested
against an entire website, and you'll be given direction on which parts of the scraper need more work. We understand it's difficult to know if your scraper
is "perfect", but please be sure to test against multiple products on the site, and provide those URL's when you submit.

## Contacts
Use either oDesk or standard email to communicate with me. Remember, we want this to work out, so if you're having problems, have questions, or want me to
check anything, just email me here and I'll get back as soon as I can. Good Luck!

Andy Madsen (Goldcap)
andy.madsen@hukkster.com