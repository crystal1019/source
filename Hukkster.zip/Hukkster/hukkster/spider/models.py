from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=100)
    parent = models.ForeignKey('self', blank=True, null=True, related_name='children')
    shop = models.ForeignKey('core.Shop', related_name='categories')

    created = models.DateTimeField(auto_now_add=True, blank=True, null=True, editable=False)
    changed = models.DateTimeField(auto_now=True, blank=True, null=True, editable=False)

    class Meta:
        ordering = ('parent__id', 'name',)
        unique_together = ('shop', 'name')
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'

    def __unicode__(self):
        name_list = [cat.name for cat in self._recurse_for_parents(self)]
        name_list.append(self.name)
        return ' -> '.join(name_list)

    def _recurse_for_parents(self, cat_obj):
        p_list = []
        if cat_obj.parent_id:
            p = cat_obj.parent
            p_list.append(p)
            if p != self:
                more = self._recurse_for_parents(p)
                p_list.extend(more)
        if cat_obj == self and p_list:
            p_list.reverse()
        return p_list

    def parents(self):
        return self._recurse_for_parents(self)

    def save(self, *args, **kwargs):
        if self.parent and self.parent_id == self.id:
            if self.parent == self:
                self.parent = None  # An object should never relate to itself

        for p in self._recurse_for_parents(self):
            if self.id == p.id:
                self.parent = None  # An object should never relate to itself

        super(Category, self).save(*args, **kwargs)
