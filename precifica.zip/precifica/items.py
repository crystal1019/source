# -*- coding: utf-8 -*-

import copy

from scrapy import Field, Item
from scrapy.contrib.loader import ItemLoader
from scrapy.contrib.loader.processor import MapCompose, TakeFirst


class CopyableItemLoader(ItemLoader):
    """

    Item loader that can be copied.

        >>> from pprint import pprint
        >>> from scrapy import Field, Item
        >>> class MyItem(Item):
        ...     name = Field()
        ...     colour = Field()
        ...
        >>> loader = CopyableItemLoader(MyItem())
        >>> loader.add_value('colour', "blue")
        >>> blue_1 = loader.copy()
        >>> blue_1.add_value('name', "Blue I")
        >>> pprint(blue_1.load_item())
        {'colour': ['blue'], 'name': ['Blue I']}
        >>> blue_2 = loader.copy()
        >>> blue_2.add_value('name', "Blue II")
        >>> pprint(blue_2.load_item())
        {'colour': ['blue'], 'name': ['Blue II']}
        >>> blue_3 = loader.copy()
        >>> blue_3.add_value('name', "Blue III")
        >>> pprint(blue_3.load_item())
        {'colour': ['blue'], 'name': ['Blue III']}
        >>> pprint(loader.load_item())
        {'colour': ['blue']}

    """

    def __copy__(self):
        """Make a copy of this item loader with its current state."""
        new = type(self)()
        new.__dict__.update(self.__dict__)
        new.context = self.context.copy()
        new.item = new.context['item'] = self.item.copy()
        new._values = self._values.copy()
        return new

    def copy(self):
        return copy.copy(self)


def _strip_if_string(value):
    if isinstance(value, basestring):
        value = value.strip()
    return value


class PrecificaItemLoader(CopyableItemLoader):
    default_output_processor = TakeFirst()
    default_input_processor = MapCompose(_strip_if_string)

    def __init__(self, *args, **kw):
        super(PrecificaItemLoader, self).__init__(*args, **kw)
        try:
            response = self.context.get('response')
            if response is None:
                response = self.selector
            self.add_value('url', response.url)
        except AttributeError:
            pass


class ProductItem(Item):
    """Base item for products, has fields applicable to all products."""

    #: URL. Automatically filled in from response.
    url = Field()

    #: Stock-keeping unit code. Should be unique.
    sku = Field()
    #: Stock-keeping unit code for variations. Should be unique.
    variation_sku = Field()
    #: All possible unique identifiers for a product. Should include but not be
    #: limited to SKU (e.g. a code used by the store or e-commerce platform) 
    #: and product id (e.g. what is probably an autoincrement primary key in a 
    #: database).
    possible_ids = Field()

    #: Product name as given in page.
    name = Field()
    #: Variation label.
    variation_label = Field()
    
    #: Possibly hierarchical list of categories this product belongs to.
    categories = Field()
    #: URL of main product image.
    image_url = Field()
    #: Product description, possibly HTML, possibly more than one value.
    description = Field()
    #: HTML with a description of product specifications, usually a table.
    _specs_html = Field()

    #: Product identification code of any format (e.g. GTIN, EAN, ISBN).
    product_identification = Field()
    #: Manufacturer part number.
    part_number = Field()

    #: Product brand.
    brand = Field()

    #: Availability.
    available = Field()
    #: Regular price.
    price = Field()
    #: Discount price for cash payment.
    special_price = Field()

    #: Number of instalments the product can be paid in.
    instalments = Field()
    #: Value of instalments the product can be paid in.
    instalment_value = Field()
