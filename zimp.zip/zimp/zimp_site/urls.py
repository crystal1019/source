from django.conf import settings
from django.conf.urls import patterns, include, url
from django.contrib.staticfiles.urls import staticfiles_urlpatterns, static
from django.contrib import admin

admin.autodiscover()

js_info_dict = {
    'packages': ('zimp',),
}

urlpatterns = patterns('',
    (r'^login/', 'zimp.views.site.login'),
    (r'^logout/', 'zimp.views.site.logout'),

    (r'^$', 'zimp.views.site.dashboard'),
    (r'^fatura/', 'zimp.views.site.fatura'),
    (r'^alcance/', 'zimp.views.site.alcance'),
    (r'^extrato/$', 'zimp.views.site.extrato'),
    (r'^usuarios/', 'zimp.views.site.usuarios'),
    (r'^reports/', 'zimp.views.site.reports'),
    (r'^lojista/test/', 'zimp.views.lojista.test'),

    # Reports
    (r'^reports/', 'zimp.views.reports.index'),

    # Additional
    (r'^accounts/', include('django.contrib.auth.urls')),
    (r'^jsi18n/', 'django.views.i18n.javascript_catalog', js_info_dict),

    # Admin
    (r'admin/', include(admin.site.urls)),
)

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
