import os
from zimp.test import TestCase
from zimp.models import *


class InternalTest(TestCase):
    def test_models(self):
        print('Brands', [str(s) for s in Brand.objects.all()])
        print('Malls', [str(s) for s in Mall.objects.all()])
        print('Retailers', [str(s) for s in Retailer.objects.all()])
        print('Cards', [str(s) for s in Card.objects.all()])
        print('Users', [str(s) for s in User.objects.all()])
        print('UserInfo', [str(s) for s in UserInfo.objects.all()])

    def test_foreignkey(self):
        # Foreignkey test
        print('Users (Userinfo)', [str(s.userinfo) for s in User.objects.all()])
