from datetime import datetime

from django.contrib.admin.filterspecs import FilterSpec
from django.utils.encoding import force_unicode
from django.utils.safestring import mark_safe
from django.utils.datastructures import MultiValueDictKeyError
from django.core.exceptions import ImproperlyConfigured
from django.utils.translation import ugettext_lazy as _
from django.forms.widgets import Media, MEDIA_TYPES, Input, HiddenInput,\
    MediaDefiningClass
from django import forms as f
from django.template.defaultfilters import date
from django.conf import settings

from filtrate import settings

class FiltrateFilter(FilterSpec):
    """
    The base django_admin_filtrate filter. It requires overriding of 
    `get_title()` and `get_content()` methods. If your are using a form, adding 
    `_form_duplicate_getparams()` inside the form html tags might come in handy.
    
    Requires the altered template for "filter.html".
    """
    def __init__(self, f, request, params, model, model_admin, **kwargs):
        super(FiltrateFilter, self).__init__(f, request, params, model, 
                                             model_admin, **kwargs)
        self._add_media(model_admin)
        self.request = request
        self.params = params
        self.model = model
        self.model_admin = model_admin
        
    class Media():
        js = ( 'js/filtrate.js',)
        css = { 'all': ('css/filtrate.css',) }
    
    def _add_media(self, model_admin):
        def _get_media(obj):
            return Media(media=getattr(obj, 'Media', None))
        
        media = _get_media(model_admin) + _get_media(FiltrateFilter)\
                + _get_media(self)
        
        for name in MEDIA_TYPES:
            setattr(model_admin.Media, name, getattr(media, "_" + name))
            
    def _form_duplicate_getparams(self, omitted_fields):
        """Replicates the get parameters as hidden form fields."""
        s = '<input type="hidden" name="%s" value="%s"/>'
        _omitted_fields = tuple(omitted_fields) + ('e',)
        return "".join([s % (k,v) for k,v in self.request.GET.iteritems() 
                        if k not in _omitted_fields])
        
    def title(self):
        """Triggers the alternate rendering in "filter.html"."""
        return '__filtrate__'
    
    def choices(self, cl):
        """As only title and choices is passed to "filter.html" template, we
        sets title to "__filtrate__" and passes real title and content from 
        here. 
        """
        return [{
            'title': self.get_title(),
            'content': self.get_content(),
        }]
    
    # Must be overridden.
    
    def get_title(self):
        """The title of the filter. Must include "After" in the beginning."""
        raise NotImplementedError()
    
    def get_content(self):
        """The content part of the filter in html."""
        raise NotImplementedError()

class DateRangeFilter(FiltrateFilter):
    
    class Media():
        js = (
            'filtrate/jqueryui-1.8.14/jquery-ui.min.js',
            'filtrate/jqueryui-1.8.14/jquery-ui-i18n.min.js',
            'js/daterangefilter.js',
        )
        css = { 'all': ('filtrate/jqueryui-1.8.14/jquery-ui.css',) }
    
    def _get_form(self, field_name):
        """
        Returns form with from and to fields. The '__alt' fields are alternative
        fields with the correct non localized dateform needed for Django, 
        handled by jsTree.
        """
        from_name = self.field_name + '__gte' 
        to_name = self.field_name + '__lte'
        
        display_widget = Input(attrs={'class': 'filtrate_date'})
        hidden_widget = HiddenInput(attrs={'class': 'filtrate_date_hidden'})
        def add_fields(fields, name, label):
            fields[name + '__alt'] = f.CharField(label=label, 
                                          widget=display_widget, required=False)
            fields[name] = f.CharField(widget=hidden_widget, required=False)
        
        def add_data(data, name, request):
            date = request.GET.get(name)
            
            if date:
                data[name + '__alt'] = date
                
        class DateRangeForm(f.Form):
            def __init__(self, *args, **kwargs):
                super(DateRangeForm, self).__init__(*args, **kwargs)
                add_fields(self.fields, from_name, _('From'))
                add_fields(self.fields, to_name, _('To'))
                
        data = {}
        add_data(data, from_name, self.request)
        add_data(data, to_name, self.request)
        return DateRangeForm(data=data)

    def get_content(self):
        form = self._get_form(self.field_name)
        e = self.request.GET.get('e','0')
        return mark_safe(u"""
            <script>
                var filtrate = filtrate || {};
                filtrate.datepicker_region = '%(datepicker_region)s';
                filtrate.datepicker_date_format = '%(datepicker_date_format)s';
            </script>
            <form class="filtrate_daterange_form" method="get">
                %(form)s
            <input type="hidden" name="e" value="%(e)s" />
            <input type="submit" value="%(submit)s" />
            %(get_params)s
            </form>
        """ % ({
            'form': form.as_p(),
            'e': e,
            'submit': _('Apply filter'),
            'datepicker_region': settings.FILTRATE['datepicker_region'],
            'datepicker_date_format': settings.FILTRATE['datepicker_date_format'],
            'get_params': self._form_duplicate_getparams(form.fields.keys()),
        }))