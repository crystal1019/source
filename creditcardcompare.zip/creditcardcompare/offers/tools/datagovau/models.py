from django.db import models


class Location(models.Model):
    lat = models.FloatField('Latitude', null=True, blank=True)
    lon = models.FloatField('Longitude', null=True, blank=True)
    address = models.CharField(max_length=50, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    data = models.FloatField()
    batch = models.CharField(max_length=50, null=True, blank=True, help_text='ID of all data that were loaded together.')
    
    class Meta:
        ordering = ('batch',)
    
    def __unicode__(self):
        return '%s %s' % (self.lat or self.address, self.lon or '')