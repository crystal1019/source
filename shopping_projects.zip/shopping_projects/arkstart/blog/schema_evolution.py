
# all of your evolution scripts, mapping the from_version and to_version to a list if sql commands
_evolutions = [
    [('fv1:-4983250488336770908','fv1:-1053229217442685279'), # generated 2012-09-27 10:36:23.559812
        "CREATE TABLE `blog_blogpost_membertype` (\n    `id` integer AUTO_INCREMENT NOT NULL PRIMARY KEY,\n    `blogpost_id` integer NOT NULL REFERENCES `blog_blogpost` (`id`),\n    `membertype_id` integer NOT NULL REFERENCES `userprofile_membertype` (`id`),\n    UNIQUE (`blogpost_id`, `membertype_id`)\n)\n;",
    ],
] # don't delete this comment! ## _evolutions_end ##
