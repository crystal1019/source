from django.conf import settings
from django.conf.urls import *
from django.views.generic import TemplateView


urlpatterns = patterns('offers.helpers.lead.views',
    url(r'^ebook/$', 'get_ebook', name='e-book'),
)
if settings.SITE_ID == 8: # creditcardcompare.com.au
    urlpatterns += patterns('offers.helpers.lead.views',
        url(r'^contact/$', 'send_email', name='send-contact'),
    )
