import re
from datetime import datetime, date, timedelta

from django.conf import settings
from django.db import connection, models
from django.utils.translation import ugettext_lazy as _
from django.template.defaultfilters import slugify
from django.contrib.sites.models import Site
from django.contrib.sites.managers import CurrentSiteManager
import reversion

from utils import ping_all_search_engines
from offers.helpers.boyd import add_months
from offers.helpers.template.models import IS_MOBILE
from offers.helpers.lead.models import State as LeadState
from offers.utils import cache_result
from offers.utils.sites.models import ExtendedSite


class BaseContent(models.Model):
    slug = models.SlugField(_('url slug'), max_length=128, unique=True, blank=True)
    creation_date = models.DateTimeField(_('created on'), blank=True, editable=False)
    last_modification_date = models.DateTimeField(_('last modified on'), blank=True, editable=False)
    slider = models.SmallIntegerField('Slider Type', default=0, choices=((0, 'None'),
                                                                         (1, 'Savings (BT)'),
                                                                         (2, 'Earnings'),
                                                                         (3, 'Savings (Purchase)')), help_text='Used in CCC to specify which slider filter to use.')

    # This field alone denotes if content is published or not. If this
    # value is <= datetime.now() then we consider this content as
    # published. This allows us to set days when content will eventually
    # be published and also prevent anyone traveling back in time from
    # seeing the future.
    publication_date = models.DateTimeField(_('expires on'), blank=True, null=True, help_text=_('The date when Balance Transfer Rate and Intro Purchase Rate expires.'))

    objects = models.Manager()
    on_site = CurrentSiteManager('sites')
    
    class Meta:
        abstract = True
        get_latest_by = 'publication_date'
        ordering = ['publication_date']
        
    def __unicode__(self):
        return self.get_title()
        
    @property
    def persiteoption(self):
        options = self.site_options.filter(site__id=settings.SITE_ID)
        try:
            return options[0]
        except IndexError:
            pass
        
    def get_name(self):
        return self.get_title()

    def get_title(self):
        try:
            return self.title
        except AttributeError:
            try:
                return self.name
            except AttributeError:
                pass

    def get_absolute_url(self):
        """
        This will probably always need to be overwritten to use
        the ``@models.permalink`` decorator.
        """
        return '/%(slug)s/' % self

    def save(self, *args, **kwargs):
        """
        We set a bunch of defaults for values not provided. Some of the
        defaults are guessed. We then normalize any data because i'm
        anal about quality.
        """
        # Defaults
        self.last_modification_date = datetime.now()
        if not self.creation_date:
            self.creation_date = self.last_modification_date
        if not self.slug:
            self.slug = self.get_title()

        # Normalization
        self.slug = slugify(self.slug)

        if self.publication_date:
            # Ping search engines new content has been published.
            # todo: Figure out how to make this work for articles set to
            # publish in the future.
            try:
                ping_all_search_engines()
            except:
                # Silently ignore because this could be a variety
                # of odd-case exceptions needed to be caught.
                pass
        return super(BaseContent, self).save(*args, **kwargs)
    
    @property
    @cache_result
    def sorted_meta_fields(self):
        '''This is intended to replace sortable_meta_fields() 2014.03.25
        '''
        try:
            option = self.site_options.get(site__id=settings.SITE_ID)
        except MetaField.DoesNotExist:
            return
        return option.meta_fields.through.objects.filter(persite=option, metafield__is_sortable=True).order_by('order')
        


class MetaField(models.Model):
    key = models.CharField(_('key'), max_length=64)
    default = models.TextField(_('default value'), blank=True, null=True, help_text=_('default value for any offer that uses this meta'))
    is_sortable = models.BooleanField(_('is sortable'), default=False, help_text=_('allows the meta to be used in a table list'))
    has_filter = models.SmallIntegerField(_('filter order'), default=0, help_text=_('Order of slider in filters. Set to 0 to disable.'))
    prefix = models.CharField(_('prefix'), max_length=16, blank=True, null=True, help_text=_('prefix for value when value is displayed (leading and trailing whitespace is preserved), e.g. $'))
    suffix = models.CharField(_('suffix'), max_length=20, blank=True, null=True, help_text=_('suffix for value when value is displayed (leading and trailing whitespace is preserved), e.g. %'))

    class Meta:
        ordering = ['key']

    def __unicode__(self):
        return self.key


class MetaFieldTooltip(models.Model):
    metafield = models.ForeignKey(MetaField, related_name='tooltips')
    text = models.CharField(_('tooltip text'), max_length=200)
    sites = models.ManyToManyField(Site)


class Category(BaseContent):
    sites = models.ManyToManyField(Site, through='core.PerSiteCategoryOption', blank=True)
    name = models.CharField(_('name'), max_length=256)
    is_visible = models.BooleanField(_('is visible'), default=True, help_text=_('if checked, all offers in this category will be visible'))
    parent = models.ForeignKey('Category', blank=True, null=True, \
        help_text=_('this is used for nesting categories. Any offer that belongs to a category will also belong to its parent categories'), related_name='children')
    transfer_limits = models.ManyToManyField('self', through='core.BalanceTransfer', related_name='no_transfer_allowed+', symmetrical=False, blank=True, help_text=_('List of issuers to which balance transfer is not allowed.'))
    hero = models.ImageField('Hero Image', null=True, blank=True, upload_to='uploads/categories/', help_text='Hero image to be used in the page of this category.')
    hero_mobile = models.ImageField('Hero Image (mobile)', null=True, blank=True, upload_to='uploads/categories/', help_text='Hero image to be used in the page of this category.')

    class Meta:
        verbose_name = _('category')
        verbose_name_plural = _('categories')
        ordering = ('name',)
        
    @cache_result
    def menu_parent_category(self):
        features = PerSiteCategoryOption.objects.filter(site=Site.objects.get(id=settings.SITE_ID),
                                                    category__parent__slug='credit-card-features',
                                                    category__is_visible=True, on_navbar=True
                                                    ).order_by('category__name'
                                                    ).values_list('category__slug', flat=True)
        issuers = Category.on_site.filter(parent__slug='credit-card-issuers', is_visible=True).values_list('slug', flat=True)
        filters = list(features) + list(issuers)
        menu = self
        while menu.parent != None and menu.slug not in filters:
            menu = menu.parent
        return menu
        
    def videos(self):
        videos = self.video_set.filter(page__extras__published__lte=date.today())
        if videos.count() == 0 and self.parent is not None:
            return self.parent.videos()
        return videos

    @property
    def meta_fields(self):
        try:
            option = self.site_options.get(site__id=settings.SITE_ID)
        except MetaField.DoesNotExist:
            return
        return option.meta_fields
    
    @property
    def children_on_site(self):
        return self.children.filter(sites=settings.SITE_ID)
    
    @property
    def bank_type(self):
        try:
            return self.issuer_profile.type.name
        except BankProfile.DoesNotExist:
            return ''

    def offers_published_on_site(self, active_only=True, is_mobile=IS_MOBILE, extra_categories=[]):
        offers = Offer.on_site.filter(categories=self, is_active=active_only)
        if extra_categories:
            offers = offers.filter(categories__slug__in=extra_categories)
        params = {'category_id': self.id,
                  'offers': offers,
                  'active_only': active_only,
                  'is_mobile': is_mobile}
        return Offer.sorted_offers.get_list(**params)

    @property
    def required_meta_fields(self):
        return self.meta_fields.filter(is_required=True)
    
    @property
    def sortable_meta_fields(self):
        '''Don't use this method, it has been replaced with sorted_meta_fields() 2014.03.21
        '''
        try:
            return self.__sortable_meta_fields
        except AttributeError:
            self.__sortable_meta_fields = list(self.meta_fields.filter(is_sortable=True))
        return self.__sortable_meta_fields

    # @models.permalink
    def get_absolute_url(self, slug_trailer=None):
        if slug_trailer is None:
            try:
                slug_trailer = self.sites.filter(id=settings.SITE_ID)[0].extendedsite.slug_trailer or '/'
            except (IndexError, ExtendedSite.DoesNotExist):
                slug_trailer='/'
        return '/%s%s' % (self.slug.replace('-alt', ''), slug_trailer)
        # return ('core.views.offer_list_for_category', (), {'category_slug': self.slug})

    def __unicode__(self):
        return self.name
    
    def get_breakout(self):
        breakouts = SiteBreakout.objects.filter(site=settings.SITE_ID,
                                                category=self)
        breakout_site_hits = breakouts.aggregate(models.Sum('promote_counter')
                                                 )['promote_counter__sum']
    
        if breakout_site_hits >= 100:
            for breakout in breakouts:
                breakout.promote_counter = 0
                breakout.save()
            breakout_site_hits = 0
    
        for breakout in breakouts:
            try:
                percentage = 100.0 * breakout.promote_counter / breakout_site_hits
            except ZeroDivisionError:
                percentage = 0
            if percentage <= breakout.promote_frequency:
                breakout.promote_counter += 1
                breakout.save()
                return breakout
        return False
    
    def get_slider_type(self):
        if self.slider:
            return self.slider
        elif self.parent is not None:
            return self.parent.get_slider_type()
        return 0  # don't show any slider
    
    def top_offers_by_meta(self, key='Sign Up Bonus'):
        offers = self.offers_published_on_site()
        sort_by = lambda o: getattr(o.metafield(key), 'numeric_value_or_default', 0)
        return sorted(offers, key=sort_by, reverse=True)

    @property
    def seo_page_options(self):
        if not hasattr(self, 'cached_seo_page_options'):
#             site = Site.objects.get_current()
#             options = self.site_options.filter(site=site)
            if self.persiteoption is not None:
                option = self.persiteoption
                self.cached_seo_page_options = dict(
                    title=option.page_title,
                    description=option.page_description,
                    h1_title=option.h1_title,
                    category_lead_description=option.category_lead_description,
                    category_description=option.category_description,
                    category_short_description=option.category_short_description,
                    qna_sections=option.get_qna_sections(),
                    noindex=option.noindex or False,
                )
            else:
                self.cached_seo_page_options = dict(
                    title=self.page_title,
                    description=self.page_description,
                    category_description=self.description,
                    noindex=False,
                )
        return self.cached_seo_page_options

    def get_top_level_parent(self):
        if not hasattr(self, '_top_level_parent'):
            if self.parent is None:
                self._top_level_parent = self
            else:
                top_level = self.parent
                while top_level.parent is not None:
                    top_level = top_level.parent

                self._top_level_parent = top_level
        return self._top_level_parent

    def get_filter_category(self):
        if not hasattr(self, '__get_filter_category'):
            filters = ('credit-card-issuers', 'credit-card-features',
                       'bank-account-features', 'bank-account-issuers')
            if self.parent is None:
                self.__get_filter_category = self
            else:
                top_level = self
                while top_level.parent != None \
                and top_level.parent.slug not in filters:
                    top_level = top_level.parent
                self.__get_filter_category = top_level
        return self.__get_filter_category

    def clean_name(self):
        top_level = self.get_top_level_parent()
        if top_level == self:
            return self.name
        elif self.slug == 'best-credit-cards':
            return 'Best Credit Cards&#185;'
        else:
            return self.name[:self.name.find(top_level.name)].strip()


class BankType(models.Model):
    name = models.CharField('Bank Type', max_length=50, blank=True, null=True, help_text="E.g. Credit Union, Mutual Bank, etc.")
    
    def __unicode__(self):
        return self.name


class BankProfile(models.Model):
    issuer = models.OneToOneField(Category, related_name='issuer_profile')
    type = models.ForeignKey(BankType, null=True, blank=True, help_text="E.g. Credit Union, Mutual Bank, etc.")
    available_in = models.ManyToManyField(LeadState)
    contact_page_url = models.URLField(max_length =200, blank=True, null=True)
    local_phone = models.CharField(max_length =250, blank=True, null=True)
    intl_phone = models.CharField(max_length =250, blank=True, null=True)
    opening_hours = models.TextField(blank=True, null=True)
    image = models.ImageField(blank=True, upload_to='uploads/categories/', max_length=115, help_text=_('Small-sized bank logo.'))
    image_big = models.ImageField("Image (big)", null=True, blank=True, upload_to='uploads/categories/', max_length=115, help_text=_('Big-sized bank logo.'))
    
    class Meta:
        ordering = ('issuer__name',)
    
    def __unicode__(self):
        return self.issuer.name
    
    def issuer_category(self):
        return self.issuer.parent.name
    
    
class BalanceTransfer(models.Model):
    no_transfer_from = models.ForeignKey('core.Category', related_name='no_transfer_from')
    no_transfer_to = models.ForeignKey('core.Category', related_name='no_transfer_to')
    until = models.IntegerField(blank=True, null=True, help_text='Minimum card ownership period to allow balance transfer.')
    
    class Meta:
        unique_together = ('no_transfer_from', 'no_transfer_to')
        
    def save(self, *args, **kwargs):
        super(BalanceTransfer, self).save(*args, **kwargs)
        balance_transfer, _newly_created = BalanceTransfer.objects.get_or_create(
            no_transfer_from=self.no_transfer_to,
            no_transfer_to=self.no_transfer_from)
        if self.until != balance_transfer.until:
            balance_transfer.until = self.until
            balance_transfer.save()
        
    def delete(self, *args, **kwargs):
        super(BalanceTransfer, self).delete(*args, **kwargs)
        try:
            BalanceTransfer.objects.get(
                no_transfer_from=self.no_transfer_to,
                no_transfer_to=self.no_transfer_from,
                until=self.until).delete()
        except BalanceTransfer.DoesNotExist:
            pass


class PerSiteOption(models.Model):
    site = models.ForeignKey(Site)
    page_title = models.CharField(_('page title'), max_length=256, blank=True, null=True, help_text=_('the title tag'))
    page_description = models.CharField(_('page description'), max_length=256, blank=True, null=True, help_text=_('the description meta tag'))
    h1_title = models.CharField(max_length=256, blank=True, null=True)
    noindex = models.BooleanField(_('don\'t index ?'), default=False, help_text=_(u'If checked, < meta name="Robots" content="noindex, follow"> will be added on the header of its pages.'))
    qna = models.TextField(_("Q&A's"), blank=True, null=True)
    
    class Meta:
        abstract = True
        ordering = ('site__name', '-id',)
        
    def __unicode__(self):
        return self.site.name
    
    @cache_result
    def get_qna_sections(self):
        sections = []
        if not self.qna:
            return sections
        qna = re.sub('(.*)Q: ', r'Q: \1', self.qna)
        for section in qna.split("Q&A's"):
            questions = [item.split('A: ') for item in section.split('Q: ')]
            if sections:
                questions.append(questions.pop(0)[0].split('\n')[0])
            else:  # header is not needed on first section
                questions.pop(0)
            if questions:
                sections.append(questions)
        return sections


class PerSiteCategoryOption(PerSiteOption):
    category = models.ForeignKey(Category, related_name='site_options')
    category_lead_description = models.TextField(_('lead paragraph'), blank=True, null=True, help_text=_('This field is Textile enabled. All HTML entered will be stripped upon saving.'))
    category_description = models.TextField(_('category description'), blank=True, null=True, help_text=_('This field is Textile enabled. All HTML entered will be stripped upon saving.'))
    category_short_description = models.CharField(_('short description'), max_length=100, blank=True, null=True, help_text=_('Needed in the homepage dropdown menu. Might be used somewhere else in the future.'))
    meta_fields = models.ManyToManyField(MetaField, blank=True, through='core.PerSiteCategoryMeta', related_name='persitecategory', help_text=_('what meta values to show in the categories table list'))
    on_navbar = models.BooleanField(_('Include in navigation menu?'), default=False, help_text=_('If checked and has appropriate parent category, it will show up in nav menu. Also affects homepage dropdown menu (in the hero).'))
    
    def __getitem__(self, key):
        return getattr(self.category, key)

        
class PerSiteCategoryMeta(models.Model):
    metafield = models.ForeignKey(MetaField)
    persite = models.ForeignKey(PerSiteCategoryOption, db_column='persitecategoryoption_id')
    display = models.CharField('Display Name', max_length=50, null=True, blank=True)
    order = models.SmallIntegerField(default=0)
        
    def __unicode__(self):
        try:
            return self.metafield.key
        except MetaField.DoesNotExist:
            return self.display


class SortedOfferManager(models.Manager):
    def get_list(self, *args, **kwargs):
        return [offer for offer in self.iter_list(*args, **kwargs)]
    
    def iter_list(self, category_id=1, offers=None, q_filter='sort_order = "" OR TRUE', is_mobile=IS_MOBILE, active_only=True):
        if offers is None:
            filter_by_id = ''
        else:
            offer_ids = '%s' % ([str(offer.id) for offer in offers] or ['0'])
            filter_by_id = 'AND o.id IN ' + offer_ids.replace('[', '(').replace(']', ')')
        
        query = """
            SELECT distinct """ + ','.join('o.' + field.column for field in Offer._meta.fields) + """
            FROM core_offer o
              JOIN core_offer_category oc ON oc.offer_id = o.id
              JOIN core_persiteofferoption po ON po.offer_id = o.id AND po.site_id = %(site_id)s
            WHERE (o.is_active = 1 %(exclude_inactive)s)
              AND oc.category_id = %(category_id)s
              AND (oc.""" + q_filter + """)
              """ + filter_by_id + """
            ORDER BY o.is_exclusive DESC, %(mobile_sort)slength(IFNULL(po.outbound_url,''))>0 DESC, oc.sort_order DESC, o.title"""
        mobile_sort = "length(IFNULL(po.outbound_url_m,''))>0 DESC, " if is_mobile else ''
        cursor = getattr(connection, 'cursor')()
        cursor.execute(query % {'site_id': settings.SITE_ID, 'category_id': category_id, 'mobile_sort': mobile_sort, 'exclude_inactive': 'AND TRUE' if active_only else 'OR source IS NOT NULL'})
        return (Offer(*row) for row in cursor.fetchall())
    
    def get_all_list(self, q_filter='sort_order = "" OR TRUE', is_mobile=IS_MOBILE):
        return self.get_list(q_filter=q_filter, is_mobile=is_mobile, active_only=False)


class Offer(BaseContent):
    sites = models.ManyToManyField(Site, through='core.PerSiteOfferOption', blank=True)
    title = models.CharField(_('name'), max_length=256)
    image = models.ImageField(blank=True, upload_to='uploads/offers/', max_length=115, help_text=_('small sized image of the offer'))
    tiny_image = models.ImageField(blank=True, upload_to='uploads/offers/', help_text=_('tiny sized image for imbedded pages'))
    large_image = models.ImageField(blank=True, upload_to='uploads/offers/', help_text=_('large sized image of the offer'))
    show_outbound_message = models.BooleanField(_('show outbound message'), default=True, help_text=_('if checked, the outbound message will be displayed.'))
    categories = models.ManyToManyField(Category, through='core.OfferCategory', help_text=_('an offer can belong to multipe categories. The first category selected is the offer\'s primary category'))
    meta = models.ManyToManyField(MetaField, through='core.OfferMeta', help_text=_('apr, monthly fee, interest, etc ...'))
    is_active = models.BooleanField(_('is active'), default=True, help_text=_('if checked, the offer is visible'))
    is_exclusive = models.BooleanField(_('is exclusive'), help_text=_('if checked, the offer will be marked as Exclusive'))
    can_be_reviewed = models.BooleanField(_('can be reviewed'), default=True, help_text=_('if checked, the offer can reviewed by users'))
    is_toplevel_offer = models.BooleanField(_(u'Breakout offer'), default=True, help_text=_(u'if checked, the offer will be shown as breakout offer in /other.php'))
    show_lightbox = models.BooleanField(_('show lightbox ?'), default=True, help_text=_('if checked, the lightbox will popup'))
    source = models.CharField(max_length=30, blank=True, null=True, help_text='scraped from')
    bt_fallback = models.ForeignKey(MetaField, verbose_name='BT fallback', related_name='fallback_offers', blank=True, null=True, help_text=_('Fallback rate when Balance Transfer Period matures.'))
    new_on = models.DateField(null=True, blank=True, help_text='Set the start date for a new offer. Expires automatically after 7 days.')
    
    sorted_offers = SortedOfferManager()
    
    class Meta:
        ordering = ('title',)
        
    def is_new(self):
        try:
            return timedelta(days=7) > date.today() - self.new_on
        except TypeError:
            return False

    @property
    def custom_images(self):
        if not hasattr(self, '_custom_images'):
            self._custom_images = dict()
            for img in self.customofferimage_set.filter(sites=settings.SITE_ID):
                self._custom_images[img.slug] = img

        return self._custom_images
    
    @cache_result
    def metafield(self, key):
        try:
            meta = self.meta_instances.filter(meta_field__key=key)[0]
        except IndexError:
            if key:
                try:
                    return OfferMeta(meta_field=MetaField.objects.get(key=key), offer=self, value='-')
                except MetaField.DoesNotExist:
                    return
            return
        return self.metafield(meta.meta_field_alt) or meta
        
    @cache_result
    def get_metadata_dict(self, offer_id=None):            
        metas = self.meta_instances.values('meta_field__key', 'meta_field__default', 'value', 'meta_field__suffix', 'meta_field__prefix')
        metadata = {}
        for meta in metas:
            if meta['value'] in ('', None):
                if meta['meta_field__default'] not in ('', None):
                    value = u'%s%s%s' % (meta['meta_field__prefix'], meta['meta_field__default'], meta['meta_field__suffix'])
                else:
                    value = meta['meta_field__default']
            elif meta['value'].lower() in ('-', 'na', 'n.a.', 'n/a', 'none'):
                value = meta['value']
            else:
                value = u'%s%s%s' % (meta['meta_field__prefix'], meta['value'], meta['meta_field__suffix'])
            if offer_id is None:
                metadata[meta['meta_field__key']] = value
            else:
                metadata[meta['meta_field__key'] + ':%s' % self.id] = value
        return metadata
        
    def savings(self, reference_card, transfered, onetime_purchase=0):
        def get_meta_value(key, default=None):
            value = getattr(self.metafield(key), 'value', default)
            if value == '-' or value is None:
                return default
            try:
                return float(value)
            except ValueError:
                try:
                    return float(re.sub('[^0-9]', '', value))
                except ValueError:
                    return get_meta_value(value, default)
            
        from offers.tools.beatcard.helpers import Card                
        card = Card(get_meta_value('Purchase Rate', 40),
                   float(get_meta_value('Annual Fee', 0)), 
                   get_meta_value('Balance Transfer Rate', get_meta_value(getattr(self.bt_fallback, 'key', ''), 40)),
                   get_meta_value('Balance Transfer Period', 0),
                   get_meta_value('Intro Purchase Rate', get_meta_value('Purchase Rate', 40)),
                   get_meta_value('Intro Purchase Period', 0),
#                    repay_rate=get_meta_value('Minimum Repayment', 2),
                   transfered=transfered,
                   monthly_expense=0,
                   onetime_expense=onetime_purchase,)
        return max(reference_card.get_total_expense(24, get_meta_value('Balance Transfer Period', 0)) - card.get_total_expense(), 0)

    def url(self):
        if self.show_outbound_message:
            return self.get_outbound_url()
        return self.outbound_url

    def thumbnail_image(self):
        return '<img src="/%s" />' % self.image.url
    thumbnail_image.allow_tags = True

    def get_apply_url(self, is_mobile=IS_MOBILE, is_breakout=False):
        '''URL for the application button. Either points to
        interstitial page or goes directly to bank's page.
        '''
        if self.show_outbound_message:
            return self.get_message_url()
        return self.get_outbound_url(is_mobile, is_breakout)
        
    def get_outbound_url(self, is_mobile=IS_MOBILE, is_breakout=False):
        '''The URL of the offer outside this site. Usually a bank page.
        '''
        if is_breakout and self.seo_page_options.has_key('promo_outbound'):
            return self.seo_page_options['promo_outbound']
        return self.outbound_url_m if is_mobile else self.outbound_url

    @property
    def outbound_url(self):
        return getattr(self.persiteoption, 'outbound_url', '')

    @property
    def outbound_url_m(self):
        '''Used for mobile browsers'''
        return getattr(self.persiteoption, 'outbound_url_m', '') or self.outbound_url

    def get_message_url(self):
        '''The interstitial page. Useful for tracking conversion specially in GA.
        '''
        base = "/apply/exclusive/%s/%d" if self.is_exclusive else "/apply/%s/%d"
        try:
            return base % (self.issuer_category.slug, self.id)
        except AttributeError:
            return base % (getattr(self.primary_category, 'slug', 'credit-cards'), self.id)

    def get_absolute_url(self, slug_trailer=None):
        if slug_trailer is None:
            try:
                slug_trailer = self.sites.filter(id=settings.SITE_ID)[0].extendedsite.slug_trailer or '/'
            except (IndexError, ExtendedSite.DoesNotExist):
                slug_trailer='/'
        if not settings.DEBUG and settings.SITE_ID == 8:
            domain = 'http://reviews.' + Site.objects.get_current().domain
        else:
            domain = ''
        return '%s/%s/%s%s' % (domain, getattr(self.primary_category, 'slug', ''), self.slug, slug_trailer)

    def get_compact_url(self, slug_trailer=None):
        return self.get_absolute_url(slug_trailer).replace(self.primary_category.slug, 'compact/%s' % self.primary_category.slug)
    
    def get_sleek_url(self, slug_trailer=None):
        return self.get_absolute_url(slug_trailer).replace(self.primary_category.slug, 'sleek/%s' % self.primary_category.slug)

    def save(self, *args, **kwargs):
        super(Offer, self).save(*args, **kwargs)
        if not self.meta.all():
            meta_fields = []
            for category in self.categories.all():
                meta_fields += category.meta_fields.all()
                category.save()
            for field in set(meta_fields):
                om = OfferMeta(offer=self, meta_field=field)
                om.save()

    def __unicode__(self):
        if self.is_active:
            return self.title
        return "%s (inactive)" % self.title

    @property
    def offer_description(self):
        return self.seo_page_options['offer_description']

    @property
    def seo_page_options(self):
        if not hasattr(self, 'cached_seo_page_options'):
#             options = self.site_options.filter(site__id=settings.SITE_ID)
            if self.persiteoption is not None:
                option = self.persiteoption
                self.cached_seo_page_options = dict(
                    title=option.page_title,
                    description=option.page_description,
                    h1_title=option.h1_title,
                    offer_description=option.offer_description,
                    promo_features=(option.promo_features or '').split('\n'),
                    exclusive_features=(option.exclusive_features or '').split('\n'),
                    pros=option.pros.split('\n') if option.pros else '',
                    cons=option.cons.split('\n') if option.cons else '',
                    table_description=option.table_features,  # for backward compatibility with FFCC
                    noindex=option.noindex or False,
                )
                if option.promo_trackers:
                    promo = option.promo_trackers.split('\n')
                    self.cached_seo_page_options.update({
                                'promo_outbound': promo[0],
                                'promo_tracker': promo[1] if len(promo) > 1 else ''
                            })
            else:
                self.cached_seo_page_options = dict(
                    promo_features=(self.promo_features or '').split('\n'),
                    exclusive_features=(self.exclusive_features or '').split('\n'),
                    noindex=False,
                )
        return self.cached_seo_page_options

    @property
    @cache_result
    def table_fields(self):
        return {
            'features': (getattr(self.persiteoption, 'table_features', '') or '').split('\n'),
            'promo_text_ends': getattr(self.persiteoption, 'promo_text_ends', None),
        }

    @property
    def seo_page_promos(self):
        return self.seo_page_options

    @property
    @cache_result
    def primary_category(self):
        try:
            return self.categories.filter(sites=settings.SITE_ID).order_by('offercategory__pk')[0]
        except IndexError:
            return
    
    @property
    @cache_result
    def issuer_category(self):
        # use offercategory_set so that they can be sorted according to
        # the order they are added to the offer
        categories = self.offercategory_set.filter(
                            category__parent__slug__endswith='-issuers',
                            category__sites=settings.SITE_ID
                    ).exclude(category__parent=None).order_by('id')
        try:
            return categories.exclude(category__parent__slug__startswith='other-')[0].category
        except IndexError:
            try:
                return categories[0].category
            except IndexError:
                return

    @property
    def related_offers(self):
        if hasattr(self, '_related_offers'):
            return self._related_offers
        try:
            slug_trailer = self.sites.filter(id=settings.SITE_ID)[0].extendedsite.slug_trailer or '/'
        except (IndexError, ExtendedSite.DoesNotExist):
            slug_trailer='/'
        query = """
                SELECT
                    o2.id,
                    o2.title,
                    CONCAT('/', pc.category_slug, '/', o2.slug, '%s') AS absolute_url,
                    IF(length(o2.tiny_image)>0, o2.tiny_image, o2.image) AS image
                FROM core_offer o
                  JOIN core_offer_category oc ON oc.offer_id = o.id
                  JOIN core_category c ON c.id = oc.category_id
                  JOIN core_offer_category oc2 ON oc2.category_id = c.id
                  JOIN core_offer o2 ON o2.id = oc2.offer_id
                  JOIN core_persiteofferoption ps ON ps.offer_id = o2.id
                  JOIN (SELECT oc.offer_id AS offer_id, c.slug as category_slug
                        FROM core_category c
                          JOIN core_offer_category oc ON c.id = oc.category_id
                          JOIN (
                            SELECT MIN(oc.id) as id
                            FROM core_offer o
                              JOIN core_offer_category oc ON oc.offer_id = o.id
                              JOIN core_category c ON c.id = oc.category_id
                            GROUP BY o.id
                          ) AS pc ON pc.id = oc.id
                  ) as pc ON pc.offer_id = o2.id
                WHERE o.slug = '%s'
                  AND o2.is_active = 1
                  AND o2.slug != '%s'
                  AND ps.site_id = %s
                  AND length(IFNULL(ps.outbound_url,'')) > 0
                GROUP BY o2.id
                ORDER BY count(oc2.category_id) DESC, o2.slug
                LIMIT 10
            """ % (slug_trailer, self.slug, self.slug, settings.SITE_ID)
        return Offer.objects.raw(query)

    @property
    @cache_result
    def feature_category(self):
        # use offercategory_set so that they can be sorted according to
        # the order they are added to the offer
        categories = self.offercategory_set.filter(
                            category__parent__slug__endswith='-features',
                            category__sites=settings.SITE_ID
                    ).exclude(category__parent=None).order_by('id')
        try:
            return categories.exclude(category__parent__slug__startswith='other-')[0].category
        except IndexError:
            try:
                return categories[0].category
            except IndexError:
                return

    def is_instant_approval(self):
        try:
            self.offercategory_set.get(category__slug="instant-approval-credit-cards")
        except Category.DoesNotExist:
            return False
        return True


class OfferCategory(models.Model):
    category = models.ForeignKey(Category)
    offer = models.ForeignKey(Offer)
    sort_order = models.IntegerField(default=0)

    class Meta:
        db_table = 'core_offer_category'
        unique_together = ('category', 'offer', )
        verbose_name_plural = _('categories (The first category added will be the offer\'s primary category)')
        ordering = ('category',)

    def __unicode__(self):
        return ''


class SiteBreakout(models.Model):
    title = models.CharField('Title (optional)', max_length=100, blank=True, null=True, help_text='Use this in place of the offer title.')
    site = models.ForeignKey(Site)
    offer = models.ForeignKey(Offer)
    category = models.ForeignKey(Category)
    promote_frequency = models.IntegerField(default=100, help_text=_('Ex: to promote this offer in this category to 30% of page visitors, enter a value 30'))
    promote_counter = models.IntegerField(default=0)

    def __unicode__(self):
        return ''
    
    @property
    def breakout_title(self):
        return self.title or self.offer.title


class PerSiteOfferOption(PerSiteOption):
    offer = models.ForeignKey(Offer, related_name='site_options')
    offer_description = models.TextField(_('offer description'), blank=True, null=True, help_text=_('This field is Textile enabled. All HTML entered will be stripped upon saving.'))
    table_features = models.TextField(blank=True, null=True, help_text=_('Used by CCC to show the bullet features on the category table (under "name" column).'))
    outbound_url = models.URLField(_('outbound url'), blank=True, null=True)
    outbound_url_m = models.URLField(_('mobile outbound url'), blank=True, null=True)
    promo_text_ends = models.DateField(_('end date of promo text'), blank=True, null=True)
    promo_features = models.TextField(blank=True, null=True, help_text=_('Breakout offer features. Meta tag-enabled. Separate entries using new line (simply press "Enter")'))
    exclusive_features = models.TextField(blank=True, null=True, help_text=_('Exclusive offer features. Meta tag-enabled. Separate entries using new line (simply press "Enter")'))
    promo_trackers = models.TextField(blank=True, null=True, help_text=_('First entry: "Apply URL". Second entry: "Tracker image URL". Separate entries using new line (simply press "Enter")'))
    pros = models.TextField(blank=True, null=True, help_text=_('Separate entries using new line (simply press "Enter")'))
    cons = models.TextField(blank=True, null=True, help_text=_('Separate entries using new line (simply press "Enter")'))
    meta_fields = models.ManyToManyField(MetaField, blank=True, through='core.PerSiteOfferMeta', related_name='persiteoffer', help_text=_('what meta values to show in the columns'))


class PerSiteOfferMeta(models.Model):
    metafield = models.ForeignKey(MetaField)
    persite = models.ForeignKey(PerSiteOfferOption, db_column='persiteofferoption_id')
    display = models.CharField('Display Name', max_length=50, null=True, blank=True)
    order = models.SmallIntegerField(default=0)
        
    def __unicode__(self):
        try:
            return self.metafield.key
        except MetaField.DoesNotExist:
            return self.display


class OfferMetaHistory(models.Model):
    '''This model is here to give access to the old history of metafields.
    Metafield revision tracking is now handled by django-reversion (2015-02-24)
    '''
    vid = models.IntegerField(primary_key=True)
    id = models.CharField(max_length=36)
    meta_field = models.ForeignKey(MetaField, related_name='meta_history')
    offer = models.ForeignKey(Offer, related_name='meta_history')
    date = models.DateTimeField(auto_now=True)
    value = models.CharField(_('value'), max_length=256, blank=True, null=True)
    expiry = models.DateField(_('date when value ends'), blank=True, null=True)
    logo = models.ImageField(blank=True, null=True, upload_to='uploads/offers/metafields/', help_text=_('Usually used for Rewards Program.'))
    
    class Meta:
        db_table = 'core_offermeta_rev_history'
        
    def restore_meta(self):
        '''Useful to take advantage of the OfferMeta object methods
        '''
        return OfferMeta(meta_field=self.meta_field, offer=self.offer, date=self.date, value=self.value, expiry=self.expiry, logo=self.logo)


class OfferMeta(models.Model):
    meta_field = models.ForeignKey(MetaField, related_name='meta_instances')
    offer = models.ForeignKey(Offer, related_name='meta_instances')
    date = models.DateTimeField(auto_now=True)
    value = models.CharField(_('value'), max_length=256, blank=True, null=True)
    meta_field_alt = models.CharField("Alternate Meta", max_length=64, null=True, blank=True, help_text="Value override. Get the value of this meta field instead.")
    expiry = models.DateField(_('date when value ends'), blank=True, null=True)
    next_value = models.CharField(max_length=256, blank=True, null=True)
    load_next_value = models.DateTimeField(_('next value load time'), blank=True, null=True)
    logo = models.ImageField(blank=True, null=True, upload_to='uploads/offers/metafields/', help_text=_('Usually used for Rewards Program.'))
    logo_mobile  = models.ImageField(blank=True, null=True, upload_to='uploads/offers/metafields/', help_text=_('Usually used for Rewards Program.'))

    class Meta:
        verbose_name_plural = _('Offer Meta')
        ordering = ['meta_field__key']
        unique_together = ('meta_field', 'offer', )
        
    def __init__(self, *args, **kwargs):
        obj = super(OfferMeta, self).__init__(*args, **kwargs)
        self._meta.get_field_by_name('meta_field_alt')[0]._choices = MetaField.objects.values_list('key', 'key')
        return obj
        
    @property
    @cache_result
    def persite_formatted_value(self):
        Format = None
        try:
            exec('from offers.core.metafield_formats.format%s import Format' % settings.SITE_ID)
        except ImportError:
            return
        return Format(self)
    
    @property
    @cache_result
    def persite_old_value(self):
        Format = None
        try:
            exec('from offers.core.metafield_formats.format0 import Format')
        except ImportError:
            return
        return Format(self)

    def date_changed(self):
        try:
            return self.date.strftime('%Y-%m-%d')
        except AttributeError:
            return ''
        
    @cache_result
    def get_revision_meta(self, revision_date):
        '''For string argument, format is: YYYY-mm-dd
        '''
        if self.id is None:
            return
        if not isinstance(revision_date, date):
            revision_date = datetime.strptime(revision_date, '%Y-%m-%d').date()
        try:
            revcopy = reversion.get_for_date(self, revision_date)
        except reversion.models.Version.DoesNotExist:
            try:  # check history from old table
                meta = self.offer.meta_history.filter(meta_field=self.meta_field, date__lt=revision_date).order_by('-date')[0]
            except IndexError:
                return
            else:
                return meta.restore_meta()
        else:
            revcopy.field_dict['meta_field'] = self.meta_field
            revcopy.field_dict['offer'] = self.offer
            return self.__class__(**revcopy.field_dict)

    @cache_result
    def get_archived_value(self, months_ago=1):
        this_month = date.today().replace(day=1)
        archive_date = add_months(this_month, 1 - months_ago)
        try:
            archived_value = reversion.get_for_date(self, archive_date).field_dict
        except reversion.models.Version.DoesNotExist:
            if months_ago == 0:
                return self.bare_value_or_default
            else:
                return self.get_archived_value(months_ago - 1)
        return archived_value['value'] if archived_value['value'] else self.default

    @property
    def value_or_default(self):
        if self.value:
            value = self.value.lower()
            if value in ('-', 'na', 'n.a.', 'n/a', 'none'):
                return self.value
            else:
                return u'%s%s%s' % (self.meta_field.prefix, self.value, self.meta_field.suffix)
        return u'%s%s%s' % (self.meta_field.prefix, self.default, self.meta_field.suffix)

    @property
    def intro_value_or_default(self):
        intro_meta_key = ''
        if self.meta_field.key == 'Purchase Rate':
            intro_meta_key = 'Intro Purchase Rate'
        elif self.meta_field.key == 'Interest Rate':
            intro_meta_key = 'Intro Rate'
        if intro_meta_key:
            intro_rates = self.offer.meta_instances.filter(meta_field__key=intro_meta_key)
            if intro_rates and intro_rates[0].value != '-':
                return intro_rates[0].value_or_default
        return self.value_or_default

    @property
    def bare_value_or_default(self):
        return self.value if self.value else self.default
    
    @property
    def numeric_value_or_default(self):
        return float(re.sub("[^0-9.]", "", self.bare_value_or_default) or 0)

    @property
    def bare_intro_value_or_default(self):
        if self.meta_field.key == 'Purchase Rate':
            intro_rate = self.offer.meta_instances.filter(meta_field__key='Intro Purchase Rate')
            if intro_rate and intro_rate[0].value != '-':
                return intro_rate[0].bare_value_or_default
        return self.bare_value_or_default

    @property
    def key(self):
        return self.meta_field.key

    @property
    def default(self):
        return self.meta_field.default

    @property
    def is_sortable(self):
        return self.meta_field.is_sortable

    def __unicode__(self):
        return '%s: "%s"' % (self.key, self.value_or_default)
    
reversion.register(OfferMeta)
