'''
@author: chaol
'''
from django.conf.urls.defaults import *

urlpatterns = patterns('',
        (r'^order/$','bellabustiere.dashboard_helper.order_statistics'),
        (r'^sale/$','bellabustiere.dashboard_helper.sale_statistics'),
        (r'^datalist/$','bellabustiere.dashboard_helper.build_datalist'),
        (r'^analytics/$','bellabustiere.dashboard_helper.analytics'),
        (r'^order_analytic/$', 'bellabustiere.dashboard_helper.order_analytics')
)
