import re, traceback
from datetime import datetime
from StringIO import StringIO

from django.core.files import File
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.conf import settings
from django.db import models

from offers.core.models import BankProfile, BankType, Category, MetaField, Offer, OfferCategory
from offers.utils import cache_result


msg = '''
Available headers: %s.<br/>
All metafield names are valid headers too.<br/>
This is case-sensitive, which means "title" is not "Title".
'''

class OfferImport(models.Model):
    HEADERS = ['Offer ID', 'Offer', 'Title', 'Bank', 'Issuer Type']
    file = models.FileField(upload_to='uploads/bulkimport/', help_text=msg % HEADERS)
    csv_sep = models.CharField('CSV Separator', max_length=1, default=',')
    date = models.DateTimeField(auto_now=True)
    imported = models.IntegerField(default=0, verbose_name='# of rows imported')
    failed = models.IntegerField(default=0, verbose_name='# of rows failed')
    failed_entries = models.FileField(upload_to='uploads/bulkimport/', blank=True, null=True)
    logs = models.TextField(null=True, blank=True, default='')
    
    class Meta:
        app_label = 'core'
    
    def __unicode__(self):
        return self.file.name.replace('uploads/bulkimport/', '')
        
    def save(self, *args, **kwargs):
        if self.id is None and getattr(self, '_saving', True):
            self._saving = False  # flag to avoid recursion
            try:
                self.import_rows()
            except Exception, e:
                self.logs += str(e)
        super(OfferImport, self).save(*args, **kwargs)
        
    def log_failed(self, row):
        try:
            self.failed_entries.write(row)
        except ValueError:
            if self.failed > 0:
                raise
            f = StringIO()
            filename = 'error.%s.csv' % datetime.today().strftime('%y%m%d')
            f = InMemoryUploadedFile(f, "csv", filename, None, f.tell(), None)
            self.failed_entries = File(f)
            self.log_failed(row)
        else:
            self.failed += 1
    
    def import_rows(self):
        rows = self.file.read().splitlines()
        self.headers = [h.strip() for h in rows[0].split(self.csv_sep)]
        formatter = lambda key: re.sub('[^A-z]', '', key.lower().replace(' ', '_'))
        available_headers = self.HEADERS + list(MetaField.objects.values_list('key', flat=True))
        headers = [h.strip() for h in self.headers if h in available_headers]
        self.logs += 'Headers: %s' % headers
        for row in rows[1:]:
            try:
                values = row.split(self.csv_sep)
            except UnicodeDecodeError:
                values = row.decode('latin-1').split(self.csv_sep)
            try:
                for h in headers:
                    try:
                        getattr(self, formatter(h))(values)
                    except AttributeError:
                        self.update_meta(values, h)
            except Exception, e:
                if settings.DEBUG:
                    traceback.print_exc()
                self.log_failed('%s, %s\n' % (row.strip(), str(e)))
            else:
                self.imported += 1
                    
    @cache_result
    def get_offer(self, row):
        try:
            return Offer.objects.get(id=row[self.headers.index('Offer ID')].strip())
        except (ValueError, Offer.DoesNotExist):
            pass
        try:
            return Offer.objects.get(title=row[self.headers.index('Title')].strip())
        except (ValueError, Offer.DoesNotExist):
            pass
        try:
            return Offer.objects.get(title=row[self.headers.index('Offer')].strip())
        except (ValueError, Offer.DoesNotExist):
            raise ImporterError('Offer not found.')
    
    def title(self, row):
        self.get_offer(row)
    
    def offer(self, row):
        return self.get_offer(row)
    
    def offer_id(self, row):
        self.get_offer(row)
    
    @cache_result
    def bank(self, row):
        bank_name = row[self.headers.index('Bank')].strip()
        if bank_name == '':
            return ''
        bank = self.offer(row).issuer_category
        if bank is None:
            try:
                bank = Category.objects.get(name='%s Credit Cards' % bank_name, parent__slug__endswith='-issuers', sites=8)
            except Category.DoesNotExist:
                try:
                    Category.objects.get(name='%s Credit Cards' % bank_name, parent__slug__endswith='-issuers')
                except Category.DoesNotExist:
                    raise
                else:
                    raise ImporterError('%s Credit Cards is not available to CCC' % bank_name)
            else:
                OfferCategory.objects.create(offer=self.offer(row), category=bank)
        return bank
    
    def update_meta(self, row, key):
        meta = self.offer(row).metafield(key)
        if meta is None:
            raise ImporterError('Metafield %s not found. %s' % (key, self.offer(row)))
        val = row[self.headers.index(key)].strip()
        if meta.value != val:  # this is to avoid unnecessary revisions (history)
            meta.value = val
            meta.save()
        
    def bank_type(self, row):
        return self.issuer_type(row)
    
    def issuer_type(self, row):
        try:
            name = row[self.headers.index('Issuer Type')].strip()
        except ValueError:
            pass
        try:
            name = row[self.headers.index('Bank Type')].strip()
        except ValueError:
            pass
        _type, _newlycreated = BankType.objects.get_or_create(name=name)
        try:
            profile = self.bank(row).issuer_profile
        except BankProfile.DoesNotExist:
            raise BankProfile.DoesNotExist("%s doesn't have bank profile." % self.bank(row).name)
        except AttributeError, e:
            if self.bank(row) == '':
                return ''
            raise e
        profile.type = _type
        profile.save()


class ImporterError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

'''
#===============================================================================
# Use this query to verify changes in the data
#===============================================================================

SELECT o.id as 'Offer ID', o.title as Offer, f.name as 'Primary Category', i.name as Bank, i.type as 'Bank Type', m.value as 'Card Type'
FROM core_offer o
LEFT JOIN (
    SELECT om.offer_id, om.value
    FROM core_offermeta om
    JOIN core_metafield m ON m.id = om.meta_field_id
    WHERE m.key = 'Card Type'
) AS m ON m.offer_id = o.id  # METAFIELD
LEFT JOIN (
    SELECT oc.offer_id, c.slug, c.name, t.name as `type`
    FROM core_category c
    LEFT JOIN core_category p ON p.id = c.parent_id
    LEFT JOIN core_offer_category oc ON oc.category_id = c.id
    LEFT JOIN core_bankprofile b ON b.issuer_id = c.id
    LEFT JOIN core_banktype t ON t.id = b.type_id
    WHERE p.slug LIKE '%credit-card-issuers'
    AND c.slug NOT IN ('visa-credit-cards', 'american-express-credit-cards')
) AS i ON i.offer_id = o.id  # ISSUER CATEGORY
LEFT JOIN (
    SELECT oc.offer_id, c.slug, c.name
    FROM core_category c
    LEFT JOIN core_offer_category oc ON oc.category_id = c.id
    JOIN (
        SELECT MIN(oc.id) AS id
        FROM core_category c
        JOIN core_category p ON p.id = c.parent_id
        JOIN core_offer_category oc ON oc.category_id = c.id
        WHERE p.slug LIKE '%credit-card-features'
        GROUP BY oc.offer_id
    ) AS oc1 ON oc1.id = oc.id
) AS f ON f.offer_id = o.id  # FEATURE CATEGORY
JOIN (
    SELECT oc.offer_id
    FROM core_category c
    JOIN core_offer_category oc ON c.id = oc.category_id
    JOIN (
        SELECT MIN(oc.id) AS id
        FROM core_category c
        JOIN core_offer_category oc ON oc.category_id = c.id
        GROUP BY oc.offer_id
    ) AS pc ON pc.id = oc.id
    WHERE c.slug = 'credit-cards'
) AS p ON p.offer_id = o.id  # PRIMARY CATEGORY
LEFT JOIN core_persiteofferoption s ON s.offer_id = o.id
WHERE s.site_id = 8
ORDER BY o.slug
'''
