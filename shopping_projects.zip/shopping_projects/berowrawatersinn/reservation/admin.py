from berowrawatersinn.reservation.models import *
from django.contrib import admin
#from berowrawatersinn import helpers

class BookingAdmin(admin.ModelAdmin):
    list_display = ('first_name','last_name','date','time','phone','email','quantity','arrive_by','deposite_paid','status','notes','table_value','created')
    list_editable = ('deposite_paid','status','quantity','table_value')
    list_filter = ('status',)
    
    def changelist_view(self, request, extra_context=None):
        bookings = Booking.objects.all()
        seats = sum([x.quantity for x in bookings])
        
        return super(BookingAdmin, self).changelist_view(request, extra_context={'seats':seats})
        
    
admin.site.register(Booking, BookingAdmin)
admin.site.register(ArriveBy)
admin.site.register(SeatsByWeekday)
admin.site.register(SeatsByDate)
admin.site.register(MealType)


