from django.contrib import admin
from models import Category


class CategoryAdmin(admin.ModelAdmin):
    actions = None
    fieldsets = (
        (None, {
            'fields': ('shop', 'parent', 'name')
        }),
    )
    list_display = ('name', 'parent', 'shop', 'changed')
    list_display_links = ('name',)
    list_filter = ('shop',)
    search_fields = ('name',)

admin.site.register(Category, CategoryAdmin)
