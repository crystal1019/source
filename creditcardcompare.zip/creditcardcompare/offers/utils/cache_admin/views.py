#! /usr/bin/env python
#coding=utf-8
import memcache
from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.template.context import RequestContext
from django.core.cache import cache
from utils import mcstats
from django.conf import settings
from utils import get_memcached_stats

hosts = settings.CACHES['default']['LOCATION']

SERVERS = hosts.split(';')

def index(request,pk):
    server,port = SERVERS[int(pk)].split(":")
    key_items = get_keys(server,port)
    return render_to_response('cache_admin/index.html', RequestContext(request, locals()))


def delete_key(request):
    key = request.POST.get("key")
    cache.delete(key)
    return HttpResponse("Y")

def flush_all(request):
    cron_server = '54.252.100.225'
    if not request.user.is_staff and request.META.get('REMOTE_ADDR') != cron_server:
        raise Http404
    cache.clear()
    for i in SERVERS:
        try:
            server,port = i.split(":")
        except ValueError:
            break
        keys = get_keys(server, port)
        for key in keys:
            try:
                cache.has_key(key[0])
            except memcache.Client.MemcachedKeyLengthError:
                pass

    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

def server_list(request):
    statuses = zip(range(len(SERVERS)), SERVERS, map(get_memcached_stats, SERVERS))
    context = {
        'statuses': statuses,
    }
    return render_to_response(
        'cache_admin/stats.html',
        context,
        context_instance=RequestContext(request)
    )

def get_keys(server,port):
    mcs = mcstats(server, int(port))
    slabCounts = mcs.calcSlabsCount(mcs.connect('stats items \r\n'))
    key_items = set(mcs.showKVpairs(slabCounts))
    key_items = [one for one in key_items if int(one[1])>2 ]
    return key_items

#def delete_many(request):
#    key =