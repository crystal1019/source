from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.models import Project
from roomhints.models import Comment
from roomhints.models import Profile
from roomhints.models import Comment

from datetime import datetime, timedelta
from django.utils.timezone import utc
import math
from roomhints.utils import random_response, search_profile_id
from roomhints.views import not_hidden_sql, total_searches, comment_add

class Command(BaseCommand):
    help = 'Send notification emails for some events'

    def handle(self, *args, **options):
        projuniq = None
        for a in args:
            projuniq = a
        pall = []
        output = ""
        up = Profile.objects.filter(pk=search_profile_id()).get()
        #print "up is " + str(up)
        if projuniq != None:
            p = Project.objects.filter(projuniq=projuniq,public=true).get()
            pall.append(p.projuniq)
        else:
            startdate = datetime.utcnow().replace(tzinfo=utc)
            enddate = startdate - timedelta(days=1)
            sql = not_hidden_sql(False,"Surprise me!",True)
            cursor = connection.cursor()
            cursor.execute(sql)
            for row in cursor.fetchall():
                projuniq = row[0]
                pall = Project.objects.filter(projuniq=projuniq,seconds__lt=enddate)
                if len(pall) > 0:
                    p = pall[0]

                    call = Comment.objects.filter(project_id=p.id,public=True)
                    if len(call) == 0: # No other comments
                        sigcount = total_searches(p.profile_id) # total number of searches
                        #thisp_sigcount = project_searches(p) # number of searches for this project
                        if sigcount == 1:
                            # There was only one submission
                            output += "responded to: http://roomhints.com/room?projuniq=" + row[0] + " " + p.custom +"\n"
                            comment = random_response(p.custom)
                            c = comment_add(p,up,comment,True,True)
                            p.hide = True
                            p.save()
                                      
            cursor.close()
            
            #pall = Project.objects.filter(

        print output
