from berowrawatersinn.location.models import *
from berowrawatersinn.website.admin import CommonPageAdmin
from django.contrib import admin

class LocationPageAdmin(CommonPageAdmin):
    list_display = CommonPageAdmin.list_display + ['is_landing']
    
admin.site.register(LocationPage, LocationPageAdmin)