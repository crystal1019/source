import logging
from django.db import transaction
from .models import Category


logger = logging.getLogger('spider')


class CategoryPipeline(object):
    @transaction.commit_on_success
    def process_item(self, item, spider):
        data = dict(shop=item['shop'], name=item['name'])
        if 'parent' in item:
            try:
                parent = Category.objects.get(shop=item['parent']['shop'], name__iexact=item['parent']['name'])
            except Category.DoesNotExist:
                parent = Category.objects.create(**item['parent'])
                logger.debug('Created a new category: %s', parent)
            data['parent'] = parent

        try:
            query_dict = dict(shop=item['shop'], name__iexact=item['name'])
            category = Category.objects.get(**query_dict)
        except Category.DoesNotExist:
            category = Category.objects.create(**data)
            logger.debug('Created a new subcategory: %s', category)

        return category
