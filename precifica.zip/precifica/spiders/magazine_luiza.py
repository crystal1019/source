# -*- coding: utf-8 -*-

from functools import partial
from operator import eq, itemgetter, methodcaller, truth

from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors import LinkExtractor
from scrapy.contrib.loader.processor import MapCompose, TakeFirst

from ..items import PrecificaItemLoader as ItemLoader, ProductItem
from . import PrecificaSpider


class MagazineLuizaSpider(PrecificaSpider, CrawlSpider):
    name = "magazine_luiza"
    site = "Magazine Luiza"
    compat_domain = "www.magazineluiza.com.br"
    allowed_domains = ['magazineluiza.com.br']
    start_urls = ['http://www.magazineluiza.com.br/busca/*/']

    rules = [
        Rule(LinkExtractor(restrict_xpaths=['id("productShowcaseSearch")'
                                            '//li[@itemtype='
                                            '"http://schema.org/Product"]'
                                            '/a[1]']),
             callback='parse_product'),
        Rule(LinkExtractor(restrict_xpaths=['id("productShowcaseSearch")'
                                            '//a[@class="page"]']))
    ]

    def parse_product(self, response):
        item = ItemLoader(ProductItem(), response)
        item.default_output_processor = TakeFirst()

        item.add_css('categories',
                     'ul.breadcrumb li[typeof="v:Breadcrumb"] a::text',
                     itemgetter(slice(1, None)))
        item.add_xpath('sku', 'id("productId")/@value')
        item.add_xpath('image_url',
                       ('//*[@itemtype="http://schema.org/Product"]'
                        '//img[@itemprop="image"]/@src'))
        item.add_xpath('available',
                       ('//*[@itemtype="http://schema.org/Product"]'
                        '//meta[@itemprop="availability"]/@content'),
                       MapCompose(methodcaller('strip'),
                                  partial(eq, "InStock")),
                       truth)
        item.add_xpath('brand',
                       ('//*[@itemtype="http://schema.org/Product"]'
                        '//*[@itemtype="http://schema.org/Brand"]/a/text()'))
        item.add_xpath('price', ('//*[@itemtype="http://schema.org/Product"]'
                                 '//meta[@itemprop="price"]/@content'),
                       re=r'[\d\.,]+')
        item.add_css('instalments', ('*[itemtype="http://schema.org/Product"] '
                                     '.txt-rates-product > span::text'),
                     re=r'(\d+)\s*x\s*de')
        item.add_css('instalment_value',
                     ('*[itemtype="http://schema.org/Product"] '
                      '.txt-rates-product > span::text'),
                     re=r'x\s*de\s*R\$\s*([\d\.,]+)')
        item.add_css('description', ('*[itemtype="http://schema.org/Product"] '
                                     '*[itemprop="description"] '
                                     '.fs-presentation'))
        item.add_css('_specs_html', ('*[itemtype="http://schema.org/Product"] '
                                     '*[itemprop="description"] '
                                     '.fs-content-block'))

        had_variation = False
        for variation in response.css('.opt-basic-information .js-buy-option'):
            had_variation = True
            variation_item = item.copy()
            variation_item.add_value('variation_sku',
                                     variation.xpath('input/@value').extract())
            variation_item.add_value('variation_label',
                                     variation.xpath('span/text()').extract())
            yield variation_item.load_item()

        if not had_variation:
            yield item.load_item()
