angular.module('editor.directives', [])
    .directive('imgmanager', [

        function() {
            return {
                restrict: 'E',
                link: function(scope, elem, attrs) {
                    scope.loadManager = function() {
                        var im = new ImageManager({
                            'topic': data.topic, // global data object
                            'selectable': true,
                            'single_select': false
                        });
                        im.on('show', function(obj) {
                            im.on('ok', function() {
                                var thumbs = im.selectedThumbnails();
                                if (thumbs.length > 0) {
                                    var assets = [];
                                    var thumb_urls = [];
                                    for (var i = thumbs.length - 1; i >= 0; i--) {
                                        var thumb = $(thumbs[i]);
                                        assets.push(thumb.data('asset'));
                                        thumb_urls.push(thumb.find('img').attr('src'));
                                    }
                                    $.getJSON('/assets/meta/', {
                                        assets: assets.join(',')
                                    }, function(json, textStatus) {
                                        for (var i = 0, cnt = json.length; i < cnt; i++) {
                                            var asset = json[i];
                                            asset.url = thumb_urls[i];
                                            asset['media'] = asset.url;
                                            delete asset.url;
                                            scope.$apply(function() {
                                                scope.addImage(asset);
                                            });
                                        }
                                    });
                                }
                                im.close();
                            });
                        });
                        im.show();
                    };
                }
            };
        }
    ])
    .directive("redactor", [

        function() {
            // http://stackoverflow.com/a/16264310 && https://github.com/TylerGarlick/angular-redactor
            return {
                require: 'ngModel',
                link: function(scope, elem, attrs, ctrl) {

                    ctrl.$render = function() {
                        if (elem.hasClass('basic')) {
                            elem.redactor({
                                keyupCallback: function() {
                                    scope.$apply(function() {
                                        ctrl.$setViewValue(elem.getCode());
                                    });
                                },
                                execCommandCallback: function() {
                                    scope.$apply(function() {
                                        ctrl.$setViewValue(elem.getCode());
                                    });
                                }
                            })
                                .getEditor()
                                .addClass('wysiwyg-overides notranslate')
                                .parent()
                                .find('.redactor_toolbar')
                                .hide();
                        } else {
                            elem.redactor(_.extend(EDITOR_TOOLBAR, {
                                keyupCallback: function() {
                                    scope.$apply(function() {
                                        ctrl.$setViewValue(elem.getCode());
                                    });
                                },
                                execCommandCallback: function() {
                                    scope.$apply(function() {
                                        ctrl.$setViewValue(elem.getCode());
                                    });
                                }
                            }))
                                .getEditor()
                                .addClass('wysiwyg-overides notranslate')
                                .height(400);
                        }
                        elem.setCode(ctrl.$viewValue);
                    };
                }
            };
        }
    ])
    .directive('slider', [

        function() {
            return function(scope, elem, attrs) {
                elem.slider({
                    animate: true,
                    step: 1,
                    min: 200,
                    max: 600,
                    stop: function(event, ui) {
                        // Refresh code if slider value changes
                        scope.$apply(scope.updateWidget());
                    },
                    slide: function(event, ui) {
                        // Update widget width text while dragging slider.
                        scope.widget.width = ui.value;
                        scope.$apply();
                    }
                });
            };
        }
    ])
    .directive('toggle', [

        function() {
            return function(scope, elem, attrs) {
                scope.$on('event:toggle', function(env, elem_uid) {
                    if (attrs.toggle === elem_uid) {
                        elem.collapse('toggle');
                    }
                });
            };
        }
    ])
    .directive('validateemail', ["$http",
        function($http) {
            var id;
            return {
                require: 'ngModel',
                link: function(scope, elm, attrs, ctrl) {
                    if (id) clearTimeout(id);
                    id = setTimeout(function() {
                        scope.$watch(attrs.ngModel, function(email) {
                            if (ctrl.$modelValue != "") {
                                $http.get('/editor_v2/validate_invite/', {
                                    params: {
                                        topic: scope.topic,
                                        email: ctrl.$modelValue,
                                        role: attrs.validateemail
                                    }
                                }).success(function(obj) {
                                    ctrl.$setValidity(attrs.ngModel, obj.success);
                                    ctrl.$err_msg = obj.message[0];
                                });
                            }
                        });
                    }, 200);
                }
            };
        }
    ])
    .directive('fileuploader', [

        function() {
            return function(scope, elem, attrs) {
                var upload_btn_text;
                if (BrowserDetect.browser == 'Explorer') {
                    upload_btn_text = '<div>Import document file by clicking here.</div>';
                } else {
                    upload_btn_text = '<div>Import document file by clicking or dropping file here.</div>';
                }
                // Create image uploader for image post.
                var uploader = new qq.FileUploader({
                    element: $('#media-document-uploader')[0],
                    action: '/assets/document_upload/',
                    params: {
                        'topic': scope.topic
                    },
                    debug: false,
                    multiple: true,
                    maxConnections: 5,
                    allowedExtensions: [
                        'pdf',
                        'doc',
                        'docx',
                        'xls',
                        'xlsx',
                        'ppt',
                        'pptx',
                        'txt',
                        'csv',
                        'xml'
                    ],
                    sizeLimit: 10485760,
                    dragText: '<h4>Drop files here</h4>',
                    uploadButtonText: upload_btn_text,
                    enableTooltip: true,
                    showMessage: function(message) {
                        // console.log(message);
                    },
                    onSubmit: function(id, fileName) {
                        ga_tracker('topic edit', 'Import document file submit');
                        $('#id_media .submit').addClass('disabled');
                    },
                    onError: function(id, fileName, reason) {
                        $($(this._listElement).find('li')[id]).hide();
                    },
                    onComplete: function(id, fileName, responseJSON) {
                        scope.$apply(function() {
                            scope.newDocument(responseJSON.data);
                        });
                    }
                });
            };
        }
    ])
    .directive('scrollto', ["$http",
        function($http) {
            var id;
            return {
                link: function(scope, elm, attrs, ctrl) {
                    scope.$watch(function() {
                        return scope.images;
                    }, function(n, o) {
                        if (scope.multifile) {
                            old_len = o.length;
                            new_len = n.length;
                            if (old_len !== 0 && new_len !== 0 && old_len < new_len) {
                                $(elm).animate({
                                    scrollLeft: $(elm).find('.image-list').width()
                                }, "slow");
                            }
                        }
                    }, true);
                }
            };
        }
    ])
    .directive('ngBlur', [

        function() {
            return function(scope, elem, attrs) {
                elem.bind('blur', function() {
                    scope.$eval(attrs.ngBlur);
                });
            };
        }
    ])
    .directive('crop', [

        function() {
            return {
                replace: true,
                link: function(scope, element, attr) {
                    scope.$watch(function() {
                        return scope.selected_image;
                    }, function(nv) {
                        if (nv) {
                            element[0].onload = function() {
                                var img_size = utils.imgNaturalSize(this);
                                var padding_w = img_size.width * .05;
                                var padding_h = img_size.height * .05;
                                select_size = [
                                    padding_w, padding_h,
                                    img_size.width - padding_w, img_size.height - padding_h
                                ];
                                $(element).Jcrop({
                                    bgOpacity: 0.4,
                                    bgColor: '#000',
                                    trueSize: [img_size.width, img_size.height],
                                    setSelect: select_size,
                                    onSelect: function(c) {
                                        scope.crop_size = c;
                                    }
                                }, function() {
                                    scope.jcrop_api = this;
                                });
                            }
                        }
                    });
                }
            };
        }
    ])
    .directive("stickycolumn", [

        function() {
            return function(scope, elem, attrs) {

                var $sticky = elem;

                var height = $sticky.height();
                var offsetTop = $sticky.offset().top - 20,
                    tabContentHeight,
                    windowTop,
                    value;

                $(window).scroll(function() {
                    tabContentHeight = $('#placespeak_tab_content').height();
                    windowTop = $(window).scrollTop();
                    value = tabContentHeight - height;

                    if (tabContentHeight > height) {
                        if (offsetTop < windowTop) {
                            if (height + windowTop - offsetTop <= tabContentHeight) {
                                $sticky.css({
                                    'position': 'fixed',
                                    'top': '20px'
                                });
                            } else {
                                $sticky.css({
                                    'position': 'relative',
                                    'top': value + 50 + 'px'
                                });
                            }
                        } else {
                            $sticky.css({
                                'position': 'static'
                            });
                        }
                    } else {
                        $sticky.css({
                            'position': 'static'
                        });
                    }
                });
            }
        }
    ])
    .directive("fadeinout", [

        function() {
            return function(scope, elem, attrs) {
                scope.$watch('max_number', function(n) {
                    if (n) {
                        elem.fadeIn();
                        setTimeout(function() {
                            scope.max_number = false;
                            scope.$apply();
                        }, 3000);
                    } else {
                        elem.fadeOut();
                    }
                })
            }
        }
    ])
    .directive("slideDown", [

        function() {
            return {
                link: function(scope, elem, attrs) {
                    scope.$watch("confirm_archive", function(nv) {
                        if (nv) {
                            elem.slideDown();
                        } else {
                            elem.slideUp();
                        }
                    });
                }
            };
        }
    ])
    .directive('imgcrop', [

        function() {
            return {
                restrict: 'E',
                replace: true,
                scope: {
                    src: '@',
                    selected: '&'
                },
                link: function(scope, element, attr) {
                    var myImg;
                    var clear = function() {
                        if (myImg) {
                            myImg.next().remove();
                            myImg.remove();
                            myImg = undefined;
                        }
                    };

                    scope.$watch('src', function(nv) {
                        clear();
                        if (nv) {
                            element.after('<img />');
                            myImg = element.next();
                            myImg.attr('src', nv);
                            $(myImg).Jcrop({
                                aspectRatio: 2.33333,
                                boxWidth: scope.$parent.target_image_size.width,
                                boxHeight: scope.$parent.target_image_size.height,
                                trueSize: scope.$parent.image_crop_meta.original_image_size,
                                trackDocument: true,
                                onSelect: function(coords) {
                                    scope.$apply(function() {
                                        scope.$parent.measurements.crop_height = parseInt(coords.h, 10);
                                        scope.$parent.measurements.crop_width = parseInt(coords.w, 10);
                                        scope.$parent.measurements.crop_x2 = parseInt(coords.x2, 10);
                                        scope.$parent.measurements.crop_y2 = parseInt(coords.y2, 10);
                                        scope.$parent.measurements.crop_x = parseInt(coords.x, 10);
                                        scope.$parent.measurements.crop_y = parseInt(coords.y, 10);
                                    });
                                }
                            });
                        }
                    });
                    scope.$on('$destroy', clear);
                }
            };
        }
    ])
    .directive("inputMap", ["$compile",
        function($compile) {
            return function(scope, elem, attrs) {
                scope.IMData.defer.promise.then(function(data) {
                    if (data.reinit) {
                        return;
                    }
                    var map_style = [{
                        featureType: 'poi',
                        elementType: "labels",
                        stylers: [{
                            visibility: "off"
                        }]
                    }];

                    scope.IMData.gmap = new GMap2(elem.attr('id'), {
                        zoom: (scope.IMData.store.inputmap.zoom) ? scope.IMData.store.inputmap.zoom : 13,
                        center: new google.maps.LatLng(scope.IMData.store.inputmap.center.lat, scope.IMData.store.inputmap.center.lng),
                        drawingControl: false,
                        styles: map_style
                    });

                    scope.safeApply(function() {
                        scope.current_map = scope.IMData.gmap;
                    });
                    var infoWindowTpl = '<div id="infowindow" im-infowindow></div>';
                    var iwcontent = $compile(infoWindowTpl)(scope)[0];
                    scope.IMData.infowindow = new google.maps.InfoWindow({
                        content: iwcontent
                    });
                    google.maps.event.addListener(scope.IMData.infowindow, 'closeclick', function() {
                        scope.resetSelection();
                    });

                    if (!scope.IMData.layer) {
                        scope.IMData.layer = new GPolygonLayer(scope.IMData.gmap, {
                            input_map: true
                        });
                        scope.IMData.layer.loadEncodedPolygons(scope.IMData.store.basegeos, true);
                        scope.IMData.layer.startEditing();
                        scope.IMData.layer.bind('featureclicked', function(ft, latlng) {
                            scope.safeApply(function() {
                                scope.IMData.layer.selected_feature = ft;
                                scope.selected_feature = ft;
                            });
                        });

                        scope.IMData.layer.bind('featureedited', function(ft, action) {
                            if (scope.IMData.layer.edit_stack.length > 0) {
                                scope.$emit('tabchange', '/place-it', scope);
                                scope.safeApply(function() {
                                    scope.IMData.layer.edit_stack;
                                });
                            }

                            if (action === 1) { // New Feature
                                scope.safeApply(function() {
                                    scope.IMData.layer.selected_feature;
                                });
                            }
                            scope.fitToMap();
                        });
                        scope.IMData.layer.bind('newpolygon', function(ft) {
                            scope.safeApply(function() {
                                scope.selected_feature = ft;
                                scope.drawPolygon();
                                if (scope.fullscreen) {
                                    scope.fix_bounds_on_fullscreen_close = true;
                                } else {
                                    scope.fitToMap();
                                }
                            });
                        });
                    } else {
                        // Assign new map to the existing layer
                        scope.IMData.layer.setGMap(scope.IMData.gmap);
                    }
                    if (!scope.IMData.gmarklayer) {
                        scope.IMData.gmarklayer = new GeoMarkLayer(scope.IMData.gmap, {
                            draggable: true
                        });
                        scope.IMData.gmarklayer.loadGeoMarks(scope.IMData.store.geomarks);

                        scope.IMData.gmarklayer.bind("select_marker", function(mark) {
                            scope.safeApply(function() {
                                scope.IMData.gmarklayer.disableMarking();
                                scope.selected_feature = mark;
                                scope.selected_marker = mark;
                            });
                            scope.IMData.layer.setClickable(true);
                            scope.IMData.gmap.map.setOptions({
                                draggableCursor: undefined
                            });
                        });

                        scope.IMData.gmarklayer.bind("marker_moved", function(mark) {
                            scope.safeApply(function() {
                                mark.action = GLayer.MODIFIED;
                                scope.$emit("tabchange", "/place-it", scope);
                                if (scope.fullscreen) {
                                    scope.fix_bounds_on_fullscreen_close = true;
                                } else {
                                    scope.fitToMap();
                                }
                            });
                        });
                    } else {
                        scope.IMData.gmarklayer.setGMap(scope.IMData.gmap);
                    }
                });
            };
        }
    ])
    .directive('imInfowindow', [

        function() {
            return {
                templateUrl: '/static/apps/edit/partials/edit/inputmap_infowindow.html'
            }
        }
    ])
    .directive("fullscreenMap", [

        function() {
            var id;
            return {
                link: function(scope, elem, attrs) {
                    id = elem.attr('id')
                    scope.closeFullscreenMap = function(hidefn) {
                        // Hide modal
                        hidefn();
                        // Reset map and move all features back
                        scope.safeApply(function() {
                            scope.fullscreen = false;
                            scope.map_tools.fullscreen = true;
                            scope.current_map = scope.IMData.gmap;
                            scope.IMData.layer.setGMap(scope.current_map);
                            scope.IMData.gmarklayer.setGMap(scope.current_map);
                            if (scope.fix_bounds_on_fullscreen_close) {
                                scope.fitToMap();
                                scope.fix_bounds_on_fullscreen_close = false;
                            }
                        });
                        // Have to remove manually as Angular Strap doesn't
                        // even though it's meant to
                        elem.parent('.modal').remove();
                    };
                    scope.$on('modal-shown', function() {
                        scope.safeApply(function() {
                            scope.map_tools.fullscreen = false;
                            var map_style = [{
                                featureType: 'poi',
                                elementType: "labels",
                                stylers: [{
                                    visibility: "off"
                                }]
                            }];
                            scope.fullscreen_map.gmap = new GMap2(id, {
                                zoom: (scope.IMData.store.inputmap.zoom) ? scope.IMData.store.inputmap.zoom : 13,
                                center: new google.maps.LatLng(
                                    scope.IMData.store.inputmap.center.lat,
                                    scope.IMData.store.inputmap.center.lng
                                ),
                                drawingControl: false,
                                styles: map_style
                            });
                            scope.stopAllEditing();
                            scope.current_map = scope.fullscreen_map.gmap;
                            scope.IMData.layer.setGMap(scope.current_map);
                            scope.IMData.gmarklayer.setGMap(scope.current_map);
                        });
                    });
                }
            };
        }
    ])
    .directive('contenteditable', [

        function() {
            //http://stackoverflow.com/questions/15108602/two-way-binding-of-contenteditable-item-inside-ng-list
            return {
                require: 'ngModel',
                link: function(scope, elm, attrs, ctrl) {
                    elm.bind('keyup', function() {
                        scope.$apply(function() {
                            ctrl.$setViewValue(elm.html());
                        });
                    });

                    ctrl.$render = function() {
                        elm.html(ctrl.$viewValue);
                    };
                }
            };
        }
    ])
    .filter('filterdeleted', [

        function() {
            return function(features) {
                return _.reject(features, function(ft) {
                    return ft.getMap() === null;
                });
            };
        }
    ]);