'''
@author: chaol
'''
from django.conf.urls.defaults import *
from bellabustiere.blog.feeds import BlogFeed

urlpatterns = patterns('',
    (r'^$', 'bellabustiere.blog.views.home'),
    (r'^feed/',BlogFeed()),    
    (r'^tags/(?P<tag>.*).html$', 'bellabustiere.blog.views.tag'),
    (r'^search.html$','bellabustiere.blog.views.blogsearch'),    
    (r'^(?P<category>.*)-archive(?P<offset>.*).html$', 'bellabustiere.blog.views.home'),
   
    (r'^(?P<code>.*).html$', 'bellabustiere.blog.views.post'),

)
