from django.contrib.auth.decorators import login_required
from django.core.context_processors import csrf
from django.shortcuts import render_to_response, redirect
from django.template import RequestContext
from django.http import HttpResponseServerError

from app.models import Recipe, Bookmark
from app.recipes import can_see_recipe
from util import success_json

@login_required
def bookmark(request, rid):
    if request.method == "GET":
        return HttpResponseServerError()
    recipe = Recipe.objects.get(id = rid)
    if can_see_recipe(request.user, recipe):
        bookmark = Bookmark.objects.create(
            user = request.user,
            recipe = recipe
            )
        bookmark.save()

        return action_response(request, True, recipe)

@login_required
def unbookmark(request, rid):
    if request.method == "GET":
        return HttpResponseServerError()
    recipe = Recipe.objects.get(id = rid)
    bookmark = Bookmark.objects.get(
        user = request.user,
        recipe = recipe
        )
    bookmark.delete()

    return action_response(request, False, recipe)

def action_response(request, bookmarked, recipe):
    c = RequestContext(request)
    c.update(csrf(request))
    c.update({
            'bookmarked': bookmarked,
            'recipe': recipe
            })
    return render_to_response('recipes/bookmark_widget.html', c)


@login_required
def bookmarks(request):
    c = RequestContext(request)
    bookmarks = map(lambda b: b.recipe, request.user.bookmark_set.all())
    c.update({'bookmarks': bookmarks})
    return render_to_response('bookmarks.html', c)
    
