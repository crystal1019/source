
var map_preview;

var DATETIME_FORMAT = 'h:mm a, Do MMMM YYYY';
var DATE_FORMAT = 'Do MMMM YYYY';

// For using moment.js with datetime picker
Date.parseDate = function( input, format ){
  return moment(input,format).toDate();
};
Date.prototype.dateFormat = function( format ){
  return moment(this).format(format);
};

function show_image_selector() {
    var im = new ImageManager({
        'topic'        : data.topic,  // global data object
        'selectable'   : true,
        'single_select': true
    });

    function init_image_editor(asset) {
        img_editor = new ImageEditor(data.topic, asset);
        img_editor.on('ok', function() {
            var params = img_editor.vals();
            params['topic'] = data.topic;
            params['csrfmiddlewaretoken'] = document.getElementsByName('csrfmiddlewaretoken')[0].value ;
            $.ajax({
                url: '/editor/overview/image/',
                type: 'post',
                data: params,
                success: function(obj) {
                    $('.overview .no-topic-image').hide();
                    $('.overview .topic-image')
                        .attr('src', obj.data.url + '?' + new Date().getTime())
                        .show();
                    $('.overview input[name="image"]').val(obj.data.thumb);
                    $('.overview .delete-picture-section').show();
                    img_editor.close();
                }
            });
        });
    }

    im.on('show', function() {  // On show overwrite ok event
        im.on('ok', function() {
          var thumb = im.selectedThumbnails();
          if (thumb.length == 1) {
            var asset = thumb.data('asset');
            init_image_editor(asset);
            im.on('close', function() {
                $('#dialog-ok').removeClass('disabled');
                img_editor.show(); // Load on close event b/c reusing markup
            });
            im.close();
          }
        });
    });

    im.on('delete_image', function(objects){
        var over_img_id = $('.overview input[name="image"]').val();
        if (utils.inArray(parseInt(over_img_id, 10), objects.thumbs)) {
            remove_overview_image();
        }
    });

    im.show();
    return;
}


function show_logo_selector() {
    var im = new ImageManager({
        'topic'        : data.topic,  // global data object
        'selectable'   : true,
        'single_select': true
    });

    function init_image_editor(asset) {
        // img_editor = new ImageEditor(data.topic, asset, {aspect_ratio: 2.09});
        img_editor = new ImageEditor(data.topic, asset, {aspect_ratio: null});
        img_editor.on('ok', function() {
            var params = img_editor.vals();
            params['topic'] = data.topic;
            params['csrfmiddlewaretoken'] = document.getElementsByName('csrfmiddlewaretoken')[0].value ;
            $.ajax({
                url: '/editor/proponent/logo/',
                type: 'post',
                data: params,
                success: function(obj) {
                    $('.proponent .no-org-logo').hide();
                    $('.proponent .org-logo')
                        .attr('src', obj.data.url + '?' + new Date().getTime())
                        .show();
                    $('.proponent input[name="logo"]').val(obj.data.thumb);
                    $('.proponent .delete-picture-section').show();
                    img_editor.close();
                }
            });
        });
    }

    im.on('show', function() {  // On show overwrite ok event
        im.on('ok', function() {
            var thumb = im.selectedThumbnails();
          if (thumb.length == 1) {
            var asset = thumb.data('asset');
            init_image_editor(asset);
            im.on('close', function() {
              $('#dialog-ok').removeClass('disabled');
              img_editor.show(); // Load on close event b/c reusing markup
            });
            im.close();
          }
        });
    });

    im.on('delete_image', function(asset){
        var logo_id = $('.proponent input[name="logo"]').val();
        if (utils.inArray(parseInt(logo_id, 10), objects.thumbs)) {
            remove_org_logo();
        }
    });

    im.show();
    return;
}

/*
Manages the sticky element(left side column) in he toicedit page
*/
function scrollSticky(){
	var $sticky = $("#edit-sticky-column"),
   		$content = $("#content");

	var height = $sticky.height();
	var offsetTop = $sticky.offset().top - 20,
	    tabContentHeight,
	    windowTop,
	    value;

	$(window).scroll(function(){

	  	tabContentHeight = $('.tabpane.active').height();
		windowTop = $(window).scrollTop();
		value = tabContentHeight-height;

		if(tabContentHeight > height){
	 		if(offsetTop < windowTop){
	 			if(height+windowTop-offsetTop <= tabContentHeight){
						$sticky.css({'position':'fixed', 'top': '20px'});
					}
					else{
						$sticky.css({'position':'relative', 'top': value+'px'});
						}
	 		}
	 		else{
	 			$sticky.css({'position':'static'});
	 		}
		}else{
			$sticky.css({'position':'static'});
		}
	});
}
/**
 * Add Redactor WYSIWYG editor to element.  The editor
 * toolbar that is used depends on the JS file that is
 * that is loaded. (ex. basic_editing_toolbar.js loads
 * base toolset).
 * @param  {DOMNode} element Element to apply WYSIWYG
 * @return {null}
 */
function enable_editing(element) {
    if (!element) {
        element = $('.editable');
        element2 = $(".editable2");
    }

    var editors = element
        .not('.basic')
        .redactor(EDITOR_TOOLBAR);
    var editors2 = element2
        .not('.basic')
        .redactor({
        focus: true,
        plugins: ['im_plugin', 'fullscreen'],
        buttons: [
            'html',
            '|',
            'bold',
            'italic',
            'underline',
            'deleted',
            '|',
            'file',
            'link'
        ]
    });



    // Add class to overide redactor styling
    // and stop the redactor content from being
    // translated by google translator
    $.each(editors, function(){
        $(this).getEditor()
            .addClass('wysiwyg-overides notranslate')
            .height(400);
    });
    $.each(editors2, function(){
        $(this).getEditor()
            .addClass('wysiwyg-overides notranslate')
            .height(300);
    });

    var basic_editor = element.filter('.basic').redactor({
        focus: false
    });
    var basic_editor2 = element2.filter('.basic').redactor({
        focus: false
    });


    // Stop the redactor content from being
    // translated by google translator
    $.each(basic_editor, function() {
       $(this).getEditor().addClass('notranslate');
    });
     $.each(basic_editor2, function() {
       $(this).getEditor().addClass('notranslate');
    });

    basic_editor.parent()
        .find('.redactor_toolbar')
        .hide();

	basic_editor2.parent()
        .find('.redactor_toolbar')
        .hide();

    show_upload_document();
}


function remove_org_logo() {
    var proponent_container = $('.proponent');
    proponent_container.find('input[name="logo"]').val(-1);
    proponent_container.find('.delete-picture-section').hide();
    proponent_container.find('.org-logo').hide();
    proponent_container.find('.no-org-logo').show();
}

function remove_overview_image() {
    var overview_container = $('.overview');
    overview_container.find('input[name="image"]').val(-1);
    overview_container.find('.delete-picture-section').hide();
    overview_container.find('.topic-image').hide();
    overview_container.find('.no-topic-image').show();
}

function show_upload_spatial_file() {
    var upload_btn_text;
    if (BrowserDetect.browser == 'Explorer') {
        upload_btn_text = '<div>Import KML/KMZ file or a zipped Shapefile by clicking here.</div>';
    }
    else {
        upload_btn_text = '<div>Import KML/KMZ file or a zipped Shapefile by clicking or dropping file here.</div>';
    }
    // Create image uploader for image post.
    var uploader = new qq.FileUploader({
        element: $('#spatial-upload')[0],
        action: '/assets/spatial_upload/',
        params: {
        },
        debug: false,
        multiple: true,
        maxConnections: 5,
        allowedExtensions: ['kml', 'kmz', 'zip'],
        sizeLimit: 10485760,
        dragText: '<h4>Drop files here</h4>',
        uploadButtonText: upload_btn_text,
        enableTooltip: true,
        showMessage: function(message) {
            // console.log(message);
        },
        onSubmit: function(id, fileName) {
            ga_tracker('topic edit', 'Import spatial file submit');
            $('#id_map .submit').addClass('disabled');
        },
        onError: function(id, fileName, reason){
            $($(this._listElement).find('li')[id]).hide();
            $('#spatial-upload-error')
                .show()
                .find('> ul').append(
                '<li><b>' + fileName + '</b>: ' + reason + '</li>'
            );
        },
        onComplete: function(id, fileName, responseJSON) {
            $('#id_map .submit').removeClass('disabled');
            if (responseJSON.success) {
                var label = responseJSON.data.label;
                var geojson = responseJSON.data.geojson;

                if (geojson.features.length > 0 &&
                    !geojson.features[0].properties.hasOwnProperty('label') &&
                    label
                ){
                    var features = geojson.features;
                    for (var i = features.length - 1; i >= 0; i--) {
                        features[i].properties['label'] = features[i].properties[label.name];
                        delete features[i].properties[label.name];
                    }
                }
                var gmap = gmaps['editor'];
                gmap.addTopicPolys(geojson);
                gmap.stopEditing();
                gmap.startEditing();
                gmap.fitExtentToMapData(gmap.TOPIC_POLYS);
            }
            else {
                if(responseJSON.hasOwnProperty('reason') && responseJSON.reason === 'login_required') {
                    redirect_to_login();
                }
            }
          },
          template: '<div class="qq-uploader">' +
                      '<div class="qq-upload-button" style="width: auto;">{uploadButtonText}</div>' +
                      '<div class="qq-upload-drop-area">{dragText}</div>' +
                      '<div class="list"><ul class="qq-upload-list" style="margin-top: 10px; text-align: center;"></ul></div>' +
                    '</div>',
          fileTemplate: '<li>' +
                      '<span class="qq-upload-finished"></span>' +
                      '<span class="qq-upload-file"></span>' +
                      '<span class="qq-upload-size"></span>' +
                      '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
                      '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
                      '<span class="qq-upload-spinner"></span>' +
                      '<div class="qq-progress-bar"></div>' +
                      '<div class="clear_both"></div>' +
                      '<div class="alert alert-error" style="display: none;"></div>' +
                      '</li>'
    });
    return false;
}

function load_map_tab() {

    // restriction is based on subscription plan.
    if (has_feature_kml) {
        show_upload_spatial_file();
    }

    load_edit_map();
    $('#id_map').find('input[name="map_zoom"]').val(gmaps['editor'].map.zoom);
    $('#id_map').find('input[name="map_center_lat"]').val(gmaps['editor'].map.center.lat());
    $('#id_map').find('input[name="map_center_lng"]').val(gmaps['editor'].map.center.lng());
    gmaps['editor'].startEditing();

    map_preview = new MapPreviewWindow(gmaps['editor'].map);
    map_preview.bind("previewchange", function(center, zoom){
        $('#id_map').find('input[name="map_zoom"]').val(zoom);
        $('#id_map').find('input[name="map_center_lat"]').val(center.lat());
        $('#id_map').find('input[name="map_center_lng"]').val(center.lng());
    });

    $('#id_map .toggle-map-preview').click(function() {
        // Show map preview window for setting topic AOI center
        // and map zoom level.
        map_preview.toggle();
    });

    $('#id_map .delete-feature').click(function() {
        // Delete Feature
        if (gmaps['editor'].topic_poly_edit_feature) {
            gmaps['editor'].deleteFeature(
                gmaps['editor'].topic_poly_edit_feature,
                gmaps['editor'].TOPIC_POLYS
            );
        }
    });

    gmaps['editor'].on('feature_click featurecreated stopeditingfeature', function(record) {
        var g = record[TAFFY.geometry_column];
        if(g.getEditable()) {
            $('#id_polygon_label')
                .attr('disabled', false)
                .val(record['label']);
        }
        else {
            $('#id_polygon_label')
                .attr('disabled', true)
                .val('');
        }
    });
    $('#id_polygon_label').on('keydown keypress', function (){
        var self = $(this);
        setTimeout(function(){
            gmaps['editor'].topic_poly_edit_feature['label'] = self.val();
        }, 0);
    });

    $(document).on('click','#id_map .apply-map-params', function () {
        var params = map_preview.getPreviewInfo();
        var form = $('#id_map');
        form.find('input[name="map_zoom"]').val(params.zoom);
        form.find('input[name="map_center_lat"]').val(params.center.lat());
        form.find('input[name="map_center_lng"]').val(params.center.lng());
        map_preview.toggle();
    });
    $('#spatial-upload-error .hide-errors   ').click(function() {
        $('#spatial-upload-error')
            .hide()
            .find('ul')
            .empty();
    });
}

function update_keyword_input() {
    if ($('#current-keywords .delete_keyword').length > 4) {
        $('#add-keyword-btn').addClass('disabled');
        $('#new-keyword-input').attr('disabled', true);
    }
    else {
        $('#add-keyword-btn').removeClass('disabled');
        $('#new-keyword-input').attr('disabled', false);
    }
}

function enable_widgets() {
    $(".datetime-picker").each(function(){
        var is_all_day = $(this).hasClass('all_day');
        var timestamp = $(this).data('date');
        var format = is_all_day ? DATE_FORMAT : DATETIME_FORMAT;
        var time_req = !is_all_day;
        if(timestamp){
            var date = moment(timestamp);
            $(this).datetimepicker({
                format: format,
                defaultDate: date,
                value: date.format(format),
                lazyInit: false,
                step: 5,
                formatTime: 'h:mm a',
                timepicker: time_req
            });
        }
        var self = this;
        $(this).siblings('button').click(function(){
            $(self).datetimepicker('show');
        })
    });

    $(document).on('click', '#id_events input[type=checkbox]', function(){
        if($(this).is(':checked')){
            $(this).siblings('input[name=all_day_event').val('true');
            var $p = $(this).parents('.all_day_checkbox');
            $p.siblings('.start,.end').hide();
            $p.siblings('.all_day').show();
        } else {
            $(this).siblings('input[name=all_day_event').val('false');
            var $p = $(this).parents('.all_day_checkbox');
            $p.siblings('.start,.end').show();
            $p.siblings('.all_day').hide();
        }
    });

    enable_editing();
	scrollSticky();
    addButtonAnchors();  // From site.js
}

function show_upload_document() {
    var upload_btn_text;
    if (BrowserDetect.browser == 'Explorer') {
        upload_btn_text = '<div>Import document file by clicking here.</div>';
    }
    else {
        upload_btn_text = '<div>Import document file by clicking or dropping file here.</div>';
    }
    // Create image uploader for image post.
    var uploader = new qq.FileUploader({
        element: $('#media-document-uploader')[0],
        action: '/assets/document_upload/',
        params: {
            'topic': data.topic
        },
        debug: false,
        multiple: true,
        maxConnections: 5,
        allowedExtensions: [
            'pdf',
            'doc',
            'docx',
            'xls',
            'xlsx',
            'ppt',
            'pptx',
            'txt',
            'csv',
            'xml'
        ],
        sizeLimit: 10485760,
        dragText: '<h4>Drop files here</h4>',
        uploadButtonText: upload_btn_text,
        enableTooltip: true,
        showMessage: function(message) {
            // console.log(message);
        },
        onSubmit: function(id, fileName) {
            ga_tracker('topic edit', 'Import document file submit');
            $('#id_media .submit').addClass('disabled');
        },
        onError: function(id, fileName, reason){
            $($(this._listElement).find('li')[id]).hide();
            // $('#spatial-upload-error')
            //     .show()
            //     .find('> ul').append(
            //     '<li><b>' + fileName + '</b>: ' + reason + '</li>'
            // );
        },
        onComplete: function(id, fileName, responseJSON) {
            $('#id_media .submit').removeClass('disabled');
            if (responseJSON.success) {
                var new_doc = ich.template_document(responseJSON.data);
                $(new_doc).appendTo('.documents');
            }
            else {
                if(responseJSON.hasOwnProperty('reason') && responseJSON.reason === 'login_required') {
                    redirect_to_login();
                }
            }
          },
          template: '<div class="qq-uploader">' +
                      '<div class="qq-upload-button" style="width: auto;">{uploadButtonText}</div>' +
                      '<div class="qq-upload-drop-area">{dragText}</div>' +
                      '<div class="list"><ul class="qq-upload-list" style="margin-top: 10px; text-align: center;"></ul></div>' +
                    '</div>',
          fileTemplate: '<li>' +
                      '<span class="qq-upload-finished"></span>' +
                      '<span class="qq-upload-file"></span>' +
                      '<span class="qq-upload-size"></span>' +
                      '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
                      '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
                      '<span class="qq-upload-spinner"></span>' +
                      '<div class="qq-progress-bar"></div>' +
                      '<div class="clear_both"></div>' +
                      '<div class="alert alert-error" style="display: none;"></div>' +
                      '</li>'
    });
    return false;
}


function load_fluidsurveys() {
    // restriction is based on subscription plan.
    if (has_feature_fluidsurveys) {
        $('#fluidsurveys-list').html('<div class="ajax-load"><img src="/static/img/ajax-loader-ps.gif" alt="" /></div>');
        $.ajax({
            url: '/editor/fluidsurveys_surveys/',
            dataType: 'json',
            data: {
                'topic': data.topic
            },
            type: 'GET',
            success: function(obj, textStatus, jqXHR) {
                $('#fluidsurveys-list').html('');
                if (obj.success) {
                    for (var i = 0, cnt=obj.data.length; i < cnt; i++) {
                        $('#fluidsurveys-list').append(ich.template_fluidsurveys(obj.data[i]));
                    }
                }
                else{
                    if(obj.hasOwnProperty('reason') && obj.reason === 'login_required') {
                        redirect_to_login();
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#fluidsurveys-list').html('');
            },
            complete: function(jqXHR, textStatus) {}
        });
    }
}

function upublish_poll() {
    $.ajax({
        url: '/editor/polls/unpublish/',
        dataType: 'json',
        data: {
            'topic': data.topic,
            'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
        },
        type: 'POST',
        success: function(obj, textStatus, jqXHR) {
            $('#closed-polls').html('');
            $('#no-closed-poll').hide();
            if (obj.success) {
                for (var i = 0, cnt=obj.data.length; i < cnt; i++) {
                    $('#closed-polls').append(
                        ich.template_closedpolls(obj.data[i])
                    );
                }
                $('#published-poll').html('');
                $('#no-published-poll').show();
            }
            else{
                if(obj.hasOwnProperty('reason')) {
                    if (obj.reason === 'login_required') {
                        redirect_to_login();
                    }
                    else if(obj.reason === 'no_published_poll') {
                        $('#no-closed-poll').show();
                    }
                }
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {},
        complete: function(jqXHR, textStatus) {}
    });
}

function load_published_poll() {
    $.ajax({
        url: '/editor/polls/published_poll/',
        dataType: 'json',
        data: {
            topic: data.topic
        },
        type: 'GET',
        success: function(obj, textStatus, jqXHR) {
            $('#no-published-poll').hide();
            if (obj.success) {
                $('#published-poll').html(
                    ich.template_publishedpoll(obj.data[0])
                );

                // Add ability to unpublish poll
                $('#unpublish-poll').click(function(){
                    upublish_poll();
                });
            }
            else{
                if(obj.hasOwnProperty('reason')) {
                    if (obj.reason === 'login_required') {
                        redirect_to_login();
                    }
                    else if(obj.reason === 'no_published_poll') {
                        $('#no-published-poll').show();
                    }
                }
            }
        }
    });
}

function load_closed_poll() {
    $.ajax({
        url: '/editor/polls/closed_polls/',
        dataType: 'json',
        data: {
            topic: data.topic
        },
        type: 'GET',
        success: function(obj, textStatus, jqXHR) {
            $('#template_closedpolls').html('');
            $('#no-closed-poll').hide();
            if (obj.success) {
                for (var i = 0, cnt=obj.data.length; i < cnt; i++) {
                    $('#closed-polls').append(
                        ich.template_closedpolls(obj.data[i])
                    );
                }
            }
            else{
                if(obj.hasOwnProperty('reason')) {
                    if (obj.reason === 'login_required') {
                        redirect_to_login();
                    }
                    else if(obj.reason === 'no_published_poll') {
                        $('#no-closed-poll').show();
                    }
                }
            }
        }
    });
}

function load_reports() {
    $('#tab_reports').html('<div class="ajax-load"><img src="/static/img/ajax-loader-ps.gif" alt="" /></div>');
    $.ajax({
        url: '/editor/reports/load/',
        dataType: 'json',
        data: {
            'topic': data.topic
        },
        type: 'GET',
        success: function(obj, textStatus, jqXHR) {
            if (obj.success) {
                $('#tab_reports').html(obj.html);
            }
            else{
                if(obj.hasOwnProperty('reason') && obj.reason === 'login_required') {
                    redirect_to_login();
                }
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {

        },
        complete: function(jqXHR, textStatus) {

        }
    });
}


function get_iframe () {
    // Collect topic widget options
    var params = {
        'abstract'      : ($('#id_widgets input[name="abstract"]').is(':checked')) ? true : false,
        'map'           : ($('#id_widgets input[name="map"]').is(':checked')) ? true : false,
        'stats'         : ($('#id_widgets input[name="stats"]').is(':checked')) ? true : false,
        // 'rounded_border': ($('#id_widgets input[name="rounded_border"]').is(':checked')) ? true : false,
        'help'          : ($('#id_widgets input[name="help"]').is(':checked')) ? 1 : 0
    };
    // Check to see if topic title has been overwritten
    params['title'] =  $('#widget-title').val();

    // Collect iframe parameters
    var src    = $('#id_widgets input[name="src"]').val();
    var topic  = $('#id_widgets input[name="topic"]').val();
    var width  = $('#slider').slider('value');
    var height = $('#id_widgets input[name="height"]').val();
    var qs     = utils.join(params, '&amp;');

    // $('#slider-width span').text(width); // Update widget width text

    // Assemble all the pieces
    var widget_code = ['<iframe frameborder="0" scrolling="no" border="0" style="border: 0px;" '];
    widget_code.push('width="' + width + 'px" ');
    widget_code.push('height="' + height + 'px" ');
    widget_code.push('src="' + src + '/' + topic + '/' + width + '/?');
    widget_code.push(qs);
    widget_code.push('"></iframe>');

    return widget_code.join('');
}

/*
    Update the topic widget preview window
*/
function refresh_iframe_code() {
    // Update iframe code.
    var iframe_markup = get_iframe();

    // Update widget preview section
    var preview_div = $('#widget-preview');
    // Empty the preview container contents
    preview_div.empty();
    // Add creation = true to the iframe src url so creator can listen
    // for changes in the iframe content height.  Adds JS snippent for
    // pass height to parent container.
    preview_div.html(iframe_markup.replace('?', '?creation=true&amp;'));

    preview_div.find('iframe').attr('name', 'preview-frame');
}

function toggle_publish_topic(topic_data, succ_callback) {

    ajax_data = {'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
                'topic':data.topic}

    /*
        topic_data_example =  {
            contact: true               //not always present
            deferred_publish: false
            first_publish: true
            map: true                   //not always present
            show_distance: true
            title: true
            topic_title: "Belfast Topic"
            unpublish: false
        }

    */

    if(topic_data.first_publish){
         if($("#send-publish-notifications").is(":checked")){
            ajax_data['notify_distance'] = $('#dialog select').val();
        }else{
            ajax_data['deferred_publish'] = true;
        }
    }

    if(topic_data.deferred_publish){
        ajax_data['notify_distance'] = $('#dialog select').val();
    }

    var deferred_notify = false;

    if($("#send-publish-notifications").length > 0 && $("#send-publish-notifications").is(":checked")){
        deferred_publish = true;
    }

    $.ajax({
        url: '/editor/toggle_publish_topic/',
        dataType: 'json',
        data: ajax_data,
        type: 'POST',
        success: function(obj, textStatus, jqXHR) {
            if (obj.success) {
                succ_callback(obj.message[0], obj.data);
            }
            else {
                if (obj.reason == 'login_required') {
                    redirect_to_login();
                    return;
                }
                var msg = '';
                for (var check in obj.data) {
                    if (obj.data[check] !== true) {
                        msg += '<p>' + obj.data[check] + '</p>';
                    }
                }
                $('#admin-bar-msg')
                    .removeClass('alert-info')
                    .addClass('alert-error')
                    .html(msg)
                    .show();
            }
        },
        complete: function(jqXHR, textStatus) {

        }
    });
}


function set_iframe_height(height) {
    if (height && height > 0) {
        $('#widget-preview')
            .height(height + 20)
            .find('iframe')
            .height(height);

        $('#id_widgets').find('input[name="height"]').val(height);
    }
}

function init_publisher_dialog(topic_data){
    var title = topic_data.topic_title;
    $(".distance select").uniform();

    $("#send-publish-notifications").on("change", function(){
        if($(this).attr("checked")){
            $(".distance .selector").removeClass("disabled");
            $(".distance select").removeAttr("disabled");
        }else{
            $(".distance select").attr("disabled", "disabled");
            $(".distance .selector").addClass("disabled");
        }
    });
 $("#dialog .inner").css("overflow", "hidden")
    $(".update-publish-status").click(function(){

        toggle_publish_topic(topic_data, function(msg, obj){

            topic_data = obj;
            topic_data['topic_title'] = title;
            topic_data['id'] = data.topic;

            if(topic_data.first_publish || topic_data.deferred_publish){
                topic_data['show_distance'] = true;
            }

            var publish_msg = ich.publishDialog(topic_data).html();

            $("#dialog .inner").fadeOut(function(){

                $("#dialog .inner").html(publish_msg);
                $(this).fadeIn();
                $('#dialog-alert').text(msg);

                $('#dialog-alert').slideDown(function(){
                    setTimeout(function(){
                        $("#dialog-alert").slideUp();
                    }, 5000);
                });

                init_publisher_dialog(topic_data);
            });
        });
    });

    $("#dialog-archive-btn").click(function(){
        $("#dialog-archive-confirm").slideDown();
    });

    $("#dialog-archive-cancel").click(function(){
        $("#dialog-archive-confirm").slideUp();
    });
}

$(function() {
	/**
		Admin Bar
	**/
	$(document).on('click', '#publish-topic-btn', function(){

        // Do do anything if button is disabled.
        if ($(this).hasClass('disabled')) return;

        $('#admin-bar-msg')
            .hide()
            .html('');

        var title = $('#id_header').val();
        $.ajax({
            url: '/editor/check_topic_requirements/',
            dataType: 'json',
            data: {
                topic: data.topic
            },
            type: 'GET',
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    topic_data = obj.data;
                    topic_data['topic_title'] = title;
                    topic_data['id'] = data.topic;
                    if(topic_data.first_publish || topic_data.deferred_publish){
                        topic_data['show_distance'] = true;
                    }
                    var publish_msg = ich.publishDialog(topic_data).html();
                    publisher_dialog(
                        'Publishing Manager',
                        publish_msg,
                        function(){
                            init_publisher_dialog(topic_data);
                        }
                    );
                }else {
                    if (obj.reason == 'login_required') {
                        redirect_to_login();
                        return;
                    }
                    var msg = '';
                    for (var check in obj.data) {
                        if (obj.data[check] !== true) {
                            msg += '<p>' + obj.data[check] + '</p>';
                        }
                    }

                    if(obj.message.length > 0) {
                        msg += '<p>' + obj.message[0] + '</p>';
                    }

                    $('#admin-bar-msg')
                        .removeClass('alert-info')
                        .addClass('alert-error')
                        .html(msg)
                        .show();
                }
            }
        });
        return;
	});

	$(document).on('click', '#notify-btn', function(){
        // Don't do anything the button is disabled.
        if ($(this).hasClass('disabled')) return;

        $('#admin-bar-msg')
            .hide()
            .html();
		confirmation_dialog(
			'Notify Connected Participants',
			'<p>Are you sure you want to notify the latest topic updates to your ' +
            data.connections +
            ' connected participants by sending them an email?</p>\
            <p>You can add an extra message to the email by including it in the area below.</p>\
            <textarea id="notify-msg" style="width:97%; height: 150px;"></textarea>\
            <script>\
            	$("#notify-msg").redactor(DIALOG_TOOLBAR);\
            </script>',
			function(){
                $.ajax({
                    url: '/editor/notify/',
                    dataType: 'json',
                    data: {
                        'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
                        'topic': data.topic,
                        'message':$("#notify-msg").val()
                    },
                    type: 'POST',
                    success: function(obj, textStatus, jqXHR) {
                        if (obj.success) {
                            $('#admin-bar-msg')
                                .removeClass('alert-error')
                                .addClass('alert-info')
                                .html(obj.message[0])
                                .show()
                                .delay(3000)
                                .slideUp();
                        }
                        else {
                            if (obj.reason == 'login_required') {
                                redirect_to_login();
                                return;
                            }
                            var msg = '';
                            for (var check in obj.data) {
                                if (obj.data[check] !== true) {
                                    msg += '<p>' + obj.data[check] + '</p>';
                                }
                            }

                            if(obj.message.length > 0) {
                                msg += '<p>' + obj.message[0] + '</p>';
                            }

                            $('#admin-bar-msg')
                                .removeClass('alert-info')
                                .addClass('alert-error')
                                .html(msg)
                                .show();
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {},
                    complete: function(jqXHR, textStatus) {}
                });
			}
		);
	});

    /**
        Team Tab
    **/
    $(document).on('click','.role .action a', function() {
        var container = $(this).closest('.role');
        var role = container.find('input[name="role"]').val();
        var action = $(this).hasClass('move-member') ? 'move' : 'remove';

        if (action === 'remove') {  // Remove team member
            confirmation_dialog(
                'Remove a Member',
                'Are you sure you want to remove <b>' + $(container).find('h5').text() + '</b>?',
                function(){
                    $(container)
                        .hide()
                        .find('input[name="role"], input[name="delete_invite"]')
                        .val('delete');

                    if (role === 'moderator' && !$('#team-moderators .role').length) {
                        // Show empty moderator message
                        $('#team-moderators .empty').show();
                    }
                }
            );
        }
        else if (action === 'move') {  // Move team member
            if (role === 'Administrator') {
                // Hide empty moderator message
                $('#team-moderators .empty').hide();
                $(container)
                    .appendTo('#team-moderators')
                    .find('input[name="role"]').val('Moderator');
            }
            else {
                $(container)
                    .appendTo('#team-admins')
                    .find('input[name="role"]').val('Administrator');

                // Hide empty moderator message
                if ($('#team-moderators .role').length) {
                    $('#team-moderators .empty').hide();
                }
                else {
                    $('#team-moderators .empty').show();
                }
            }
            var a_text = $(this).text();
            $(this).text(a_text === 'Move to Administrators' ?
                'Move to Moderators' : 'Move to Administrators');
        }
    });

    $(document).on('click', '#new_team_member_btn',  function() {
        if ($('#new_team_member_btn').hasClass('disabled')) return;

        $('#new_team_member_btn').addClass('disabled');
        $.ajax({
            url: '/editor/invite/',
            dataType: 'json',
            data: {
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
                'topic': data.topic,
                'role': $('#new_team_role').val(),
                'email': $('#new_team_email').val(),
                'first_name': $('#new_team_first_name').val(),
                'last_name': $('#new_team_last_name').val()
            },
            type: 'POST',
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    if ($('#new_team_role').val() === 'Administrator') {
                        $('#team-admins').append(obj.html);
                    }
                    else {
                        // Hide empty moderator message
                        $('#team-moderators .empty').hide();
                        $('#team-moderators').append(obj.html);
                    }
                    $(".new-team-member input").val('');
                    $(".new-team-member select")
                        .val('Administrator')
                        .siblings('span').text('Administrator');

					$(".new-team-member .alert")
                        .removeClass('alert-error')
                        .addClass('alert-info')
                        .html('<h5>Invitation sent.</h5>')
                        .show()
                        .delay(3000)
                        .slideUp('fast', function(){
                            $(this).hide();
                        });
/*                     $(".new-team-member .alert").hide().html(''); */
                }
                else {
                    var errors = obj.data.errors;
                    var err = '';
                    for (var field in errors) {
                        err += '<p>' + errors[field] + '</p>';
                    }
                    $(".new-team-member .alert")
                        .removeClass('alert-info')
                        .addClass('alert-error')
                        .html(err).show();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {},
            complete: function(jqXHR, textStatus) {
                $('#new_team_member_btn').removeClass('disabled');
            }
        });
    });

    $(document).on('click', '.actions .submit', function () {
        if ($(this).hasClass('disabled')) return;
        var self = this;
        var container = $(self).closest('.tabpane');
        $(self).addClass('disabled');
        var form = $(this).closest('form');

        // Need special case for map because of the geojson
        if (form.attr('id') === 'id_map') {
            gmaps['editor'].stopEditingFeature(gmaps['editor'].topic_poly_edit_feature);
            gmaps['editor'].topic_polys().toGeoJson();
            // Update geojson input
            $(form).find('input[name="geojson"]').val(
                JSON.stringify(gmaps['editor'].topic_polys().toGeoJson(true))
            );
        }
        else if (form.attr('id') === 'id_media') {
            // if (BrowserDetect.browser === 'Explorer' && BrowserDetect.version < 10) {
            // Input isn't needed past this point because the file is already uploaded
            // and causes problems with browsers that don't support the file api.
            $('#id_media input[name="file"],input[submitName="file"]').remove();
        } else if (form.attr('id') === 'id_events') {
            $(".event_item").each(function(){
                $c = $(this).find("input:checkbox");
                if($c.first().is(":checked")){
                    $i = $(this).find('input.all_day')
                    var dt = moment($i.val(), DATE_FORMAT);
                    console.log(dt);
                    if(dt.isValid()){
                        $i.siblings('input:hidden').val(dt.format('YYYY-MM-DD'));
                    }
                } else {
                    $(".datetime-picker.start, .datetime-picker.end").each(function(){
                        var dt = moment($(this).val(), DATETIME_FORMAT);
                        if(dt.isValid()){
                            $(this).siblings('input:hidden').val(dt.format('X'));
                        }
                    });
                }
            });
        }

        ga_tracker('topic edit', 'Save button (' + $('#id_category').val() + ')');

        $(form).ajaxSubmit({
            type: 'POST',
            clearForm: false,
            resetForm: false,
            dataType: 'json',
            data: {
                'header': $('#id_header').val(),
                'category': $('#id_category').val()
            },
            success: function(obj, statusText, xhr, $form){
                if (obj.success) {
                    if (obj.html) {
                        container.html(obj.html);
                        enable_widgets();
                    }
                    container.find('.alert.message')
                        .removeClass('alert-error')
                        .addClass('alert-info')
                        .html('<h5>Saved</h5>')
                        .show()
                        .delay(3000)
                        .slideUp('fast', function(){
                            $(this).hide();
                        });
                    if(form.attr('id') === 'id_surveys') {
                        load_fluidsurveys();
                    }
                }
                else {
                    alert_msg = container.find('.alert.message')
                        .removeClass('alert-info')
                        .addClass('alert-error');
                    show_errors(alert_msg, obj);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
            },
            complete: function() {
                $(self).removeClass('disabled');
            }
        });
    });

    /**
        Proponent Tab
    **/
    $(document).on('click', '.proponent .change-picture', function() {
        ga_tracker('topic edit', 'Change logo link');
        show_logo_selector();
    });

    $(document).on('click', '.proponent .delete-picture', function() {
        ga_tracker('topic edit', 'Delete logo link');
        remove_org_logo();
    });

    $(document).on('click', '.proponent .add', function() {
        $('.proponent .empty-contact-list').hide();
        $('.proponent .contact-list').prepend(ich['new_contact']());
    });

    // $(document).on('click', '.proponent .addto', function() {
    //     $('.proponent .empty-contact-list').hide();
    //     $('.proponent .new-contact-list .contact-section')
    //         .appendTo($('.proponent .contact-list'))
    //         .find('input[name="status"]').val('new');

    //     $(this).hide();
    //     proponent_container.find('.add').show();
    //     // Remove new contact
    //     $('.proponent .new-contact-list').html('');
    //     // Hide new contact actions
    //     $('.proponent .new-contact-actions').hide();
    // });

    $(document).on('click', '.proponent .remove', function() {
        var contact = $(this).closest('.contact-section');
        var first_name = contact.find('input[name="first_name"]').val();
        var last_name = contact.find('input[name="last_name"]').val();
        var name = '';
        if (first_name && last_name) {
            name = '<b>' + first_name +  ' ' + last_name + '</b>';
        }
        else {
            name = 'this contact';
        }
        confirmation_dialog(
            'Remove a Contact',
            'Are you sure you want to remove ' + name + '?',
            function(){
                if (contact.find('input[name="id"]').val() === '') {
                    contact.remove();
                }
                else {
                    contact.find('input[name="status"]').val('delete');
                    contact.hide();
                }
                    if ($('.proponent .contact-list .contact-section :visible').length === 0) {
                    $('.proponent .empty-contact-list').show();
                }
            }
        );
    });

	/**
	alacart
	*/
	$(document).on('click', '.alacart-btn', function(){
		alacart_dialog(
			'A-la-Cart Additional Services',
			$('#alacart').html(),
			function(){}
		);
	});
    /**
        Overview Tab
    **/
    $(document).on('click', '.overview .change-picture', function() {
        ga_tracker('topic edit', 'Topic image change link');
        show_image_selector();
    });
    $(document).on('click', '.overview .delete-picture', function() {
        ga_tracker('topic edit', 'Topic image delete link');
        remove_overview_image();
    });

    /**
        Map Tab
    **/
    if (!$('a[rel="tab_map"]').hasClass('active')) {
        $('a[rel="tab_map"]').click(function(){
            if (!gmaps.hasOwnProperty('editor')) {
                load_map_tab();
            }
        });
    }

    /**
        Keywords Tab
    **/
    $('#add-keyword-btn').click(function() {
        if ($(this).hasClass('disabled')) return;

        var new_keyword = $('#new-keyword-input')
            .val()
            .replace(/^\s+|\s+$/g, '');

        if(new_keyword.length === 0) return;

        var kw = ich.template_keyword({"keyword": new_keyword});
        $('#current-keywords').append(kw);
        $('#new-keyword-input').val('');

        update_keyword_input();
    });

    $(document).on('click', '.delete_keyword span', function(){
        $(this).closest('a').remove();
        update_keyword_input();
    });

    $("#recommended-keywords").sortable({
        connectWith: ".keywords_box",
        receive: function( event, ui ) {
            ui.item.find('input').remove();
        }
    }).disableSelection();

    $("#current-keywords").sortable({
        connectWith: ".keywords_box",
        receive: function( event, ui ) {
            var kw = ui.item.text();
            ui.item.append('<input type="hidden" name="keyword" value="'+kw+'"/>');
        }
    }).disableSelection();

    /**
        Social Media Tab
    **/
    $("#id_social_media .add").click(function() {
        $('#id_social_media .twitter-parameters')
            .prepend(ich['twitter_parameter_template']());
    });


    $(document).on('click', '.twitter-parameter-wrapper .remove', function(){
        var self = this;
        confirmation_dialog(
            'Remove a Member',
            'Are you sure you want to remove <b>' + $(self).closest('.twitter-parameter-wrapper').find('input').val() + '</b>?',
            function(){
                $(self).closest('.twitter-parameter-wrapper').remove();
            }
        );
    });


    /**
        Participants Tab
    **/
    $('#new_participant_btn').click( function() {
        if ($('#new_participant_btn').hasClass('disabled')) return;

        $('#new_participant_btn').addClass('disabled');

        $.ajax({
            url: '/editor/invite/',
            dataType: 'json',
            data: {
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
                'topic'              : data.topic,
                'role'               : $('#new_participant_role').val(),
                'email'              : $('#new_participant_email').val(),
                'first_name'         : $('#new_participant_first_name').val(),
                'last_name'          : $('#new_participant_last_name').val()
            },
            type: 'POST',
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    $('#participant-list').append(obj.html);
                    $(".new-participant input").not('#new_participant_role').val('');
                    $(".new-participant .alert").hide().html('');
                }
                else {
                    var errors = obj.data.errors;
                    var err = '';
                    for (var field in errors) {
                        err += '<p>' + errors[field] + '</p>';
                    }
                    $(".new-participant .alert").html(err).show();
                }

            },
            error: function(jqXHR, textStatus, errorThrown) {},
            complete: function(jqXHR, textStatus) {
                $('#new_participant_btn').removeClass('disabled');
            }
        });
    });

    /**
        Events Tab
    **/
    $(document).on('click', '#new-event-btn .add', function() {
        var new_event = ich.template_event();
        $('#events-list').prepend(new_event);
        enable_editing($(new_event).find('textarea[name="description"]'));

        var start = moment();
        var end = moment();
        end.add(1, 'h');
        $(new_event)
            .find('.datetime-picker.start')
            .datetimepicker({
                format: DATETIME_FORMAT,
                defaultDate: start,
                value: start.format(DATETIME_FORMAT),
                lazyInit: false,
                step: 5,
                formatTime: 'h:mm a'
            })
            .siblings('button').click(function(){
                $(this)
                .siblings('.datetime-picker')
                .datetimepicker('show');
            });

        $(new_event)
            .find('.datetime-picker.end')
            .datetimepicker({
                format: DATETIME_FORMAT,
                defaultDate: end,
                value: end.format(DATETIME_FORMAT),
                lazyInit: false,
                step: 5,
                formatTime: 'h:mm a'
            })
            .siblings('button').click(function(){
                $(this)
                .siblings('.datetime-picker')
                .datetimepicker('show');
            });

        $(new_event)
            .find('.datetime-picker.all_day').datetimepicker({
                format: DATE_FORMAT,
                lazyInit: false,
                timepicker: false
            }).siblings('button').click(function(){
                $(this)
                .siblings('.datetime-picker')
                .datetimepicker('show');
            });


        // $(new_event)
        //     .find('input[name="event_date"]')
        //     .val(utils.current_date())
        //     .datepicker();

        // $(new_event).find('input[name="event_time"]').timepicker({
        //     minuteStep: 5,
        //     showInputs: false,
        //     disableFocus: true,
        //     defaultTime: 'current'
        // });
        // $(new_event)
        //     .find('input[name="event_end_date"]')
        //     .val(utils.current_date())
        //     .datepicker();

        // $(new_event).find('input[name="event_end_time"]').timepicker({
        //     minuteStep: 5,
        //     showInputs: false,
        //     disableFocus: true,
        //     defaultTime: 'current'
        // });

    });

    $(document).on('click', '#id_events .editor .remove', function(){

        var container =  $(this).closest('.event-container');
        var event_title = $(container).find('input[name="title"]').val();
        var msg = 'this event';
        if (event_title.length > 0) {
            msg = '<b>' + event_title + '</b>';
        }

        confirmation_dialog(
            'Remove a Event',
            'Are you sure you want to remove ' + msg + '</b>?',
            function(){
                if (container.find('input[name="id"]').val()) {
                    container.find('input[name="delete"]').val('delete');
                    container.hide();
                }
                else {
                    container.remove();
                }
            }
        );
    });

    /**
        Discussion Tab
    **/
    $(document).on('click', '#new-discussion-btn', function() {
        $('#discussion-list').prepend(ich.template_discussion({}, true));
        $('#d1').redactor({
        focus: true,
        plugins: ['im_plugin', 'fullscreen'],
        minHeight: 300,
        buttons: [
            'html',
            '|',
            'bold',
            'italic',
            'underline',
            'deleted',
            '|',
            'file',
            'link'
        ]
    });

    });

    $(document).on('click', '#id_discussions .discussion_item .remove', function(){

        var container =  $(this).closest('.discussion_item');
        var disc_title = $(container).find('input[name="title"]').val();
        var msg = 'this discussion';
        if (disc_title.length > 0) {
            msg = '<b>' + disc_title + '</b>';
        }

        confirmation_dialog(
            'Remove a Discussion',
            'Are you sure you want to remove ' + msg + '</b>?',
            function(){
                if (container.find('input[name="id"]').val()) {
                    container.find('input[name="delete"]').val('delete');
                    container.hide();
                }
                else {
                    container.remove();
                }
            }
        );
    });
    /**
        Media Tab
    **/
    $(document).on('click', '#add-image-btn', function(){
        var im = new ImageManager({
            'topic'        : data.topic,  // global data object
            'selectable'   : true,
            'single_select': false
        });
        im.on('show', function(obj){
            im.on('ok', function() {
              var thumbs = im.selectedThumbnails();
              if (thumbs.length > 0) {
                var assets = [];
                var thumb_urls = [];
                for (var i = thumbs.length - 1; i >= 0; i--) {
                    var thumb = $(thumbs[i]);
                    assets.push(thumb.data('asset'));
                    thumb_urls.push(thumb.find('img').attr('src'));
                }
                $.getJSON('/assets/meta/', {assets: assets.join(',')}, function(json, textStatus) {
                    for (var i = 0, cnt=json.length; i < cnt; i++) {
                        var asset = json[i];
                        asset.url = thumb_urls[i];
                        $('#image-list').append(ich.template_image(asset));
                    }
                });
              }
              im.close();
            });
        });
        im.show();
    });

    $(document).on('click', '#add-video-btn', function(){
        var video_url = $('#video-url').val().replace(/^\s+|\s+$/g, '');
        if (video_url.length === 0) return;
        $.getJSON('/assets/video_thumbnail/', {url: video_url}, function(obj, textStatus) {
            obj.data['url'] = video_url;
            $('#video-list').append(ich.template_video(obj.data));
            $('#video-url').val('');
        });
    });

    $(document).on('click', '#add-link-btn', function(){
        var link_url = $('#link-url').val().replace(/^\s+|\s+$/g, '');
        if (link_url.length === 0) return;
        $('#link-list').append(ich.template_link({'url': link_url}));
        $('#link-url').val('');
    });

    $(document).on('click', '#id_media .remove', function(){
        var media_section = $(this).closest('.media-section');
        confirmation_dialog(
            'Remove a Media Item',
            'Are you sure you want to remove this media item?',
            function(){
                if (media_section.find('input[name$="_id"]').val() === '') {
                    media_section.remove();
                }
                else {
                    media_section.find('input[name$="_delete"]').val('delete');
                    media_section.hide();
                }
            }
        );
    });


    /**
        Surveys Tab
    **/

    $(document).on('click', '#new-lime-survey', function(){
        $('#new-lime-survey').addClass('disabled');
        $.ajax({
            url: '/editor/surveys/limesurvey/add/',
            dataType: 'json',
            data: {
                'topic': data.topic,
                'ls_title': 'New Survey',
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
            },
            type: 'POST',
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    // Hide alert
                    $('#id_surveys')
                        .find('.alert')
                        .hide();
                    $('#limesurvey-list').prepend(
                        ich.template_limesurvey(obj.data)
                    );
                }
                else{
                    // Show error message
                    $('#id_surveys')
                        .find('.alert')
                        .removeClass('alert-info')
                        .addClass('alert-error')
                        .html(obj.message[0])
                        .show();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {},
            complete: function(jqXHR, textStatus) {
                $('#new-lime-survey').removeClass('disabled');
            }
        });
    });

    $(document).on('click', '#id_surveys .remove', function(){
        var survey_section = $(this).closest('.item');
        var title = survey_section.find('input[name$="_title"]').val();
        title = title ? title : 'this survey';
        confirmation_dialog(
            'Remove a Media Item',
            'Are you sure you want to remove ' + title + '?',
            function(){
                if (survey_section.find('input[name$="_id"]').val() === '') {
                    survey_section.remove();
                }
                else {
                    survey_section.find('input[name$="_delete"]').val('delete');
                    survey_section.hide();
                }
            }
        );
    });

    $(document).on('click', '#id_surveys .toggle_buttons a', function(){
        var container = $(this).closest('.item');
        var publish = $(this).hasClass('publish') ? true : false;
        var is_published_input = container.find('input[name$="_is_published"]');

        // Disable other surveys
        $('#id_surveys .toggle_buttons .publish').removeClass('active');
        $('#id_surveys input[name$="_is_published"]').val('false');
        $('#id_surveys .toggle_buttons .draft').addClass('active');

        // ActivateSurvey

        if (publish) {
            $(this).addClass('active');
            container.find('.draft').removeClass('active');
            is_published_input.val(publish);
        }
    });

    $(document).on('click', '.survey-fluidsurveys input[type="checkbox"]', function(){
        var container = $(this).closest('.survey-fluidsurveys');
        var survey_input = container.find('input[name="fs_surveyId"]');
        var checkbox = container.find('input[name="fs_include"]');
        if (checkbox.is(':checked')) {
            checkbox.val(survey_input.val());
        }
        else{
            checkbox.val('');
        }
    });

    $(document).on('click', '#id_surveys .fluidsurveys-credentials .apply', function(){
        var self = this;
        if ($(self).hasClass('disabled')) return;
        $('#fs-error').hide().html('');
        $(self).addClass('disabled');
        var container = $(this).closest('.fluidsurveys-credentials');
        var api = container.find('input[name="fs_api"]').val();
        var pwd = container.find('input[name="fs_password"]').val();
        $.ajax({
            url: '/editor/surveys/fluidsurveys/connect/',
            dataType: 'json',
            data: {
                'topic': data.topic,
                'api': api,
                'password': pwd,
                'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
            },
            type: 'POST',
            success: function(obj, textStatus, jqXHR) {
                if (obj.success) {
                    load_reports();
                }
                else {
                    $('#fs-error').html(obj.message.join('')).show();
                }
            },
            complete: function(jqXHR, textStatus) {
                $(self).removeClass('disabled');
                load_fluidsurveys();
            }
        });

    });

    // Load the FluidSurveys
    load_fluidsurveys();

    /**
        Polls Tab
    **/

    // Add more choices for new poll
    $('#add-more-choices').click(function(){
        $("#choices-ul").append(ich.template_pollchoice());
    });

    // Remove poll choice from new poll
    $(document).on('click', '#id_polls .poll-choice .remove', function(){
        $(this).closest('.poll-choice').remove();
    });

    // Publish new poll
    $('#publish-poll').click(function(){
        var obj = {has_published: false};
        if ($('#published-poll').length > 0) {
            obj.has_published = true;
        }
        var html = ich.template_pollpublish_confirm(obj).html();
        confirmation_dialog(
            'Publish Poll',
            html,
            function(){
                $('#publish-error').hide().html('');
                var container = $('#id_polls .new_poll');
                var question = container.find('input[name="question"]').val();
                var choice = [];
                container.find('input[name="choice"]').each(function(){
                    choice.push($(this).val());
                });
                $.ajax({
                    url: '/editor/polls/publish/',
                    dataType: 'json',
                    data: {
                        csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value,
                        topic: data.topic,
                        question: question,
                        choice: choice
                    },
                    type: 'POST',
                    success: function(obj, textStatus, jqXHR) {
                        if (obj.success) {
                            // Clear inputs
                            container.find('input[name="question"]').val('');
                            container.find('input[name="choice"]').each(function(index, value){
                                if (index === 0) {
                                    $(this).val('');
                                }
                                else {
                                    $(this).closest('li').remove();
                                }
                            });
                            load_published_poll();
                            load_closed_poll();
                        }
                        else {
                            $('#publish-error').html('<p>' + obj.message.join('</p><p>') + '</p>').show();
                        }
                    },
                    complete: function(jqXHR, textStatus) {}
                });

            }
        );
    });

    load_published_poll();
    load_closed_poll();

    // Topic iframe
    // $.receiveMessage(
    //     function(e){
    //         var data = e.data.split('=');
    //         // Check if height parameter otherwise
    //         // ignore.
    //         if (data[0] === 'height') {
    //             var preview_div = $('#widget-preview');
    //             var h = parseInt(data[1], 10);
    //             $('#id_widgets input[name="height"]').val(h);
    //             // Update height of iframe container
    //             preview_div.height(h + 10);
    //             // Update height of iframe
    //             preview_div.find('iframe').attr('height' , h);
    //         }
    //     }
    // );

    /**
     * Topic Widgets
    */
    $( "#slider" ).slider({
        animate: true,
        step: 1,
        min: 200,
        max: 600,
        stop: function(event, ui){
            // Refresh code if slider value changes
            refresh_iframe_code();
        },
        slide: function(event, ui){
            // Update widget width text while dragging slider.
            $('#slider-width span').text(ui.value);
        }
    });

    $('#id_widgets input[type="checkbox"]').click(function(){
        refresh_iframe_code();
    });

    $('#widget-title').blur(function(){
       refresh_iframe_code();
    });

    $('#id_widgets .get-code').click(function(){

        if ($(this).hasClass('disabled')) return;

        var widget = $(this).data('widget');
        var code = '';
        if (widget === 'big_connect') {
            code = ich.template_big_connect().html();
        }
        else if(widget === 'small_connect') {
            code = ich.template_small_connect().html();
        }
        else if(widget === 'topic_iframe') {
            code = ich.template_iframe({
                iframe: "" + get_iframe()
            }).html();
        }
        confirmation_dialog(
            'Widget Code',
            code,
            function(){

            },
            null,
            {
                button1: 'Cancel',
                button2: 'Ok'
            }
        );

        ga_tracker('topic edit', 'Widget get code button (' + widget + ')');
    });

    refresh_iframe_code();

    enable_widgets();

    // Load map if user goes directly to tab.
    if ($('#placespeak_tab_content .tabpane.active').attr('id') === 'tab_map') {
        load_map_tab();
    }

    // Load report dynamically because it requires
    // calls to 3rd party resources.
    load_reports();
});