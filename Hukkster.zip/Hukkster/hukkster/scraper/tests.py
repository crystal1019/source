from django.test import TestCase
from hukkster.scraper.helpers import select_scraper
from hukkster.scraper.scrapers import *


class TestHelpers(TestCase):
    def test_select_scraper(self):
        self.assertIsInstance(select_scraper('http://www.backcountry.com/cw-x-pro-short-mens'), BackCountryScraper)
        self.assertIsInstance(select_scraper('http://www1.macys.com/shop/product/no-retreat-long-sleeve-shirt-tie-ready?ID=622652&CategoryID=20627#fn=sp%3D1%26spc%3D1129%26ruleId%3D66%26slotId%3Drec%287%29'), MacysScraper)


class TestBaseScraper(TestCase):
    fixtures = ['user_agents.json',]

    def test_get_random_user_agent(self):
        scraper = BaseScraper('http://www.macys.com')
        agent = scraper.get_random_user_agent()
        self.assertNotEqual(agent, 'Hukkster Link Checker v2.0')
