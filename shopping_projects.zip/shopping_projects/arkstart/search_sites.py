import haystack
haystack.autodiscover()