
-- UserInfo Fakes
INSERT INTO `userinfo` (`id`, `name`, `cpf`, `ddd`, `phone`, `mobile`, `gender`, `birth_date`, `street`, `number`, `complement`, `city`, `state`, `country`, `cep`, `balance`) VALUES
	('b524a81e-7cd4-11e3-8a1e-6cf049f765f5', 'user 01', 16960205735, 21, 2081620, 999361130, 1, '1990-03-13', 'Rua Cd. Bonfim', 964, 'Apto 502', 'Rio de Janeiro', 'RJ', 'BRA', '20520052', 0.00),
	('bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 'user 05', 82611846332, 21, 2082856, 999368672, 1, '1973-12-21', 'Rua Bom Pastor', 359, 'Apto 704', 'Rio de Janeiro', 'RJ', 'BRA', '20520052', 135.35),
	('c49d5c94-7cd4-11e3-8a1e-6cf049f765f5', 'user 03', 25438081590, 21, 2882024, 999368429, 1, '2005-04-12', 'Rua Alberto de Sequeira', 998, '', 'Belo Horizonte', 'MG', 'BRA', '20550010', 5321.12),
	('ca141cae-7cd4-11e3-8a1e-6cf049f765f5', 'user 04', 32477098438, 21, 5716617, 999360605, 2, '1992-09-30', 'Rua Adolfo Mota', 26, '', 'São Paulo', 'SP', 'BRA', '20260160', 1.00);

-- Mall Fakes
INSERT INTO `malls` (`id`, `cnpj`, `razao_social`, `nome_fantasia`, `ddd`, `phone`, `created_at`, `balance`, `factor`, `active`) VALUES
	('1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', 26645347000185, 'Shopping Rio Sul', 'Shopping Rio Sul', 21, 999891067, '2014-01-14 00:53:28', 465.21, 20.00, 1),
	('de97d425-7cc6-11e3-8a1e-6cf049f765f5', 97805841000108, 'Barra Shopping', 'Barra Shopping', 21, 999786044, '2014-01-14 00:52:13', 132.41, 5.00, 1);

-- Brands Fakes
INSERT INTO `brands` (`id`, `cnpj`, `razao_social`, `nome_fantasia`, `ddd`, `phone`, `created_at`, `balance`, `factor`) VALUES
	('12b29e20-7cc6-11e3-8a1e-6cf049f765f5', 44891691000136, 'Subway', 'Subway', 21, 998910672, '2014-01-14 00:46:31', 0.21, 20.00),
	('7cd9a293-7cc6-11e3-8a1e-6cf049f765f5', 88888991000131, 'Americanas', 'Americanas', 12, 989912999, '2014-01-14 00:49:11', 2.21, 1.00),
	('9849ab48-7cc6-11e3-8a1e-6cf049f765f5', 50636158000120, 'Submarino', 'Submarino', 11, 999919404, '2014-01-14 00:50:15', 45.50, 4.00);

-- Users Fakes
INSERT INTO `users` (`id`, `email`, `password`, `userinfo_id`, `system`, `role`, `admin_of`, `created_at`, `active`) VALUES
	('07b30eac-7cd8-11e3-8a1e-6cf049f765f5', 'user03@gmail.com', 'e88651a416b4778b54b4addbf3db0751', 'c49d5c94-7cd4-11e3-8a1e-6cf049f765f5', 3, 6, '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', '2014-01-14 02:55:03', 1),
	('3245cb8f-7cd8-11e3-8a1e-6cf049f765f5', 'user04@gmail.com', '8f8945aec481db8819614964da6426b1', 'ca141cae-7cd4-11e3-8a1e-6cf049f765f5', 2, 2, NULL, '2014-01-14 02:56:05', 1),
	('5e27aaad-7cd6-11e3-8a1e-6cf049f765f5', 'user01@gmail.com', 'c5cb30ec979b3a55727d9fd887ab7ab0', 'b524a81e-7cd4-11e3-8a1e-6cf049f765f5', 1, 1, NULL, '2014-01-14 02:43:09', 1),
	('9c597326-7cda-11e3-8a1e-6cf049f765f5', 'user05@gmail.com', '46c07d472fb4224ffe9b8d1b25b981bb', 'bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 2, 2, NULL, '2014-01-14 03:13:31', 1),
	('cee0a45e-7cd6-11e3-8a1e-6cf049f765f5', 'user02@gmail.com', 'df6bce7a8fd3a3ee8fd7f7cbb79e2cbe', 'bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 4, 5, '7cd9a293-7cc6-11e3-8a1e-6cf049f765f5', '2014-01-14 02:46:18', 1);

-- Cards Fakes
INSERT INTO `cards` (`userinfo_id`, `code`, `active`, `created_at`) VALUES
	('ca141cae-7cd4-11e3-8a1e-6cf049f765f5', 'AAAA12CFFF', 0, '2014-01-14 02:33:09'),
	('b524a81e-7cd4-11e3-8a1e-6cf049f765f5', 'AB2312CFFF', 1, '2014-01-14 02:32:31'),
	('bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 'BBBB12CFFF', 0, '2014-01-14 02:33:01'),
	('bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 'CCCC12CFFF', 0, '2014-01-14 02:33:01'),
	('ca141cae-7cd4-11e3-8a1e-6cf049f765f5', 'DDDD12CFFF', 1, '2014-01-14 02:32:44'),
	('c49d5c94-7cd4-11e3-8a1e-6cf049f765f5', 'EEEE12CFFF', 1, '2014-01-14 02:32:44'),
	('bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5', 'FFFF12CFFF', 1, '2014-01-14 02:32:31');

-- Retailers Fakes
INSERT INTO `retailers` (`id`, `cnpj`, `razao_social`, `nome_fantasia`, `ddd`, `phone`, `mall_id`, `brand_id`, `balance`, `factor`, `created_at`) VALUES
	('1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', 33364124000105, 'Americanas Loja Rio Sul LTDA', 'Americanas Rio Sul', 21, 99658741, '1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', '7cd9a293-7cc6-11e3-8a1e-6cf049f765f5', 1.01, 45.00, '2014-01-14 03:17:07'),
	('5b54b89a-7cdb-11e3-8a1e-6cf049f765f5', 15436987000169, 'Subway Barra Shopping LTDA', 'Subway Barra', 21, 998856321, 'de97d425-7cc6-11e3-8a1e-6cf049f765f5', '12b29e20-7cc6-11e3-8a1e-6cf049f765f5', 783.81, 10.00, '2014-01-14 03:18:52'),
	('6e0a29cf-7cdb-11e3-8a1e-6cf049f765f5', 34743014000117, 'Submarino Online LTDA', 'Submarino Online', 21, 99865478, NULL, '9849ab48-7cc6-11e3-8a1e-6cf049f765f5', 45.21, 60.00, '2014-01-14 03:19:23');

-- Promotions1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5
INSERT INTO `promotions` (`id`, `name`, `factor`, `owner_type`, `owner_id`, `end_at`) VALUES
	('1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', 'promo 1', 1, 4, '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', '2014-03-03'),
	('5b54b89a-7cdb-11e3-8a1e-6cf049f765f5', 'promo 2', 1, 4, '5b54b89a-7cdb-11e3-8a1e-6cf049f765f5', '2014-03-03'),
	('6e0a29cf-7cdb-11e3-8a1e-6cf049f765f5', 'promo 3', 1, 4, '6e0a29cf-7cdb-11e3-8a1e-6cf049f765f5', '2014-03-03');

UPDATE `retailers` SET balance = 999999 WHERE `id` = '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5';
UPDATE `retailers` SET balance = 999999 WHERE `id` = '5b54b89a-7cdb-11e3-8a1e-6cf049f765f5';
UPDATE `retailers` SET balance = 999999 WHERE `id` = '6e0a29cf-7cdb-11e3-8a1e-6cf049f765f5';
