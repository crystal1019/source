from django.db import connection, models
from offers.core.models import Offer
from offers.helpers.lead.models import Lead
from offers.tools.smart_search.models import STATUS_CHOICES

class SwitchedUserManager(models.Manager):
    def total_saved(self):
        cursor = connection.cursor()
        cursor.execute("SELECT sum(saved) FROM beatcard_switcheduser")
        return cursor.fetchone()[0]

class SwitchedUser(models.Model):
    ip_address = models.GenericIPAddressField()
    email = models.EmailField()
    credit_card = models.ForeignKey(Offer, related_name='switched_users', blank=True, null=True)
    new_card = models.ForeignKey(Offer, blank=True, null=True)
    saved = models.CharField(default='0', max_length=50)
    date_switched = models.DateTimeField(auto_now_add=True)
    
    objects = models.Manager()
    raw_sql = SwitchedUserManager()
    
    class Meta:
        unique_together = ('ip_address','email')

class UserData(models.Model):
    lead = models.ForeignKey(Lead)
    work_status = models.SmallIntegerField(choices=STATUS_CHOICES)
    annual_income = models.IntegerField()
    monthly = models.DecimalField('typical monthly spend', max_digits=20, decimal_places=2 )
    repayment = models.DecimalField('monthly repayment', max_digits=5, decimal_places=2)
    transfered = models.DecimalField('amount to transfer',max_digits=20, decimal_places=2)
    title = models.ForeignKey(Offer, verbose_name = "user's card") 
    date_captured = models.DateTimeField(auto_now_add=True)
    card_ownership_duration = models.IntegerField('length of card ownership')
    
    class Meta:
        verbose_name_plural = 'BMC User Data'
    
    def __unicode__(self):
        return unicode(self.date_captured)
    
    def get_as_dict(self):
        data = super(UserData, self).__dict__
        data.update(self.lead.__dict__)
        data.update(self.title.__dict__)
        try:
            data.update({'birthday': self.lead.birth_date.day,
                         'birthmonth': self.lead.birth_date.month,
                         'birthyear': self.lead.birth_date.year})
        except AttributeError:
            pass
        data['state'] = data['state_id']
        data['exclude_inactive'] = data['terms'] = True
        try:
            data.update({'annual': self.title.meta_instances.get(meta_field__key='Annual Fee').value})
        except IndexError:
            pass
        try:
            data.update({'purchase': self.title.meta_instances.get(meta_field__key='Purchase Rate').value})
        except IndexError:
            pass
        return data
        