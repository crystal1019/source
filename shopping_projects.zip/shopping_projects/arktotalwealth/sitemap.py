import datetime
from django.core.urlresolvers import reverse

from django.contrib.sitemaps import GenericSitemap, Sitemap
from django.conf import settings
from arktotalwealth.mediacenter.models import *
from arktotalwealth.website.models import *
from django.contrib.sites.models import Site
from arktotalwealth.overview.models import *
from arktotalwealth.service.models import *
from arktotalwealth.team.models import *
from django.core.paginator import *

class Generic(object):
    
    def __init__(self,location, modified=datetime.datetime.now()):
        self.location = location
        self.modified = modified
    
    def get_absolute_url(self):
        return self.location
    
    
class IndexSitemap(Sitemap):
    changefreq = 'weekly'
    priority = 1.0
    location = "/"
    
    def items(self):
        return [self]
 
class OverviewSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.5
    
    def items(self):
        pages = OverviewPage.objects.filter(active=True)
        return list(pages)
    
class ServiceSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.5
    
    def items(self):
        pages = ServicePage.objects.filter(active=True)
        return list(pages)
 
class TeamSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.5
    
    def items(self):
        pages = TeamPage.objects.filter(active=True)
        return list(pages)
    
class MiscSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.5
    
    def items(self):
        pages = MiscPage.objects.filter(active=True)
        return list(pages)
    
class MediacenterSitemap(Sitemap):
    changefreq = 'daily'
    priority = 0.5
    
    def items(self):
        allblogs = BlogPost.objects.filter(active=True, publishdate__lte=datetime.datetime.now())
        allpages = []
        perpage = settings.BLOG_POSTS_PER_PAGE
        p = Paginator(allblogs,perpage)
        for x in p.page_range:
            allpages.append(Generic('/financial-advice/all-archive%s.html' %x))
        
        categories = BlogCategory.objects.filter(is_active=True)
        categorypages = []
        for x in categories:
            blogs = BlogPost.objects.filter(active=True, category__slug=x.slug, publishdate__lte=datetime.datetime.now())
            p = Paginator(blogs,perpage)
            for xx in p.page_range:
                categorypages.append(Generic('/financial-advice/%s-archive%s.html' %(x.slug,xx)))
        
        return list(allblogs) + [Generic('/financial-advice/')] + allpages + categorypages

    def lastmod(self, obj):
        return obj.modified
    
sitemaps = {
    'site':IndexSitemap(),
    'overview':OverviewSitemap(),
    'service':ServiceSitemap(),
    'team':TeamSitemap(),
    'misc':MiscSitemap(),
    'mediacenter':MediacenterSitemap(),
}