from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, Http404
from django.views.generic import CreateView, TemplateView, ListView
from offers.helpers.lead.helpers import save_lead
from offers.helpers.lead.models import Lead
from offers.core.models import Offer, Category
from forms import CardReviewForm, RatingFormSet
from models import Survey, CardReview
from helpers import add_len_protocol_to_raw_sql_query


add_len_protocol_to_raw_sql_query()

class ReviewList(ListView):
    template_name = 'reviews/reviews.html'
    template_name_ajax = 'reviews/barereview.html'
    model = CardReview
    paginate_by = 5
    
    def get_queryset(self, *args, **kwargs):
        query = '''
            SELECT DISTINCT r.*
            FROM reviews_cardreview r
            JOIN core_offer o ON o.id = r.card_id
            JOIN core_offer_category oc ON oc.offer_id = o.id
            JOIN core_category c ON c.id = oc.category_id
            JOIN (
                SELECT review_id, AVG(rating) as average
                FROM reviews_cardsurvey
                GROUP BY review_id
            ) AS av ON av.review_id = r.id
            WHERE o.is_active = 1
            AND r.is_public = 1
            AND c.slug = '%s'
        ''' % self.request.GET.get('bank', 'credit-cards')
        if self.request.GET.get('offer', 'all') != 'all':
            if Offer.objects.filter(slug=self.request.GET['offer'], categories__slug=self.request.GET.get('bank', 'credit-cards')):
                query += " AND o.slug = '%s'" % self.request.GET['offer']
        if self.request.GET.get('rating', 'all') != 'all':
            query += " AND av.average >= '%s'" % self.request.GET['rating']
        query += 'ORDER BY submitted DESC'
        
        return self.model.objects.raw(query)
    
    def get_template_names(self):
        if self.request.is_ajax():
            return self.template_name_ajax
        else:
            return self.template_name
    
    def get_context_data(self, *args, **kwargs):
        context = super(ReviewList, self).get_context_data(*args, **kwargs)
        context['issuers'] = self.get_issuers()
        context['offers'] = self.get_offers()
        breadcrumb = context['issuers'][0]
        breadcrumb.name ='reviews'
        context['category'] = breadcrumb
        return context
    
    def get_issuers(self):
        query = '''
            SELECT DISTINCT c.*
            FROM core_category c
            JOIN core_category p ON c.parent_id = p.id
            JOIN core_offer_category oc ON oc.category_id = c.id
            JOIN core_offer o ON o.id = oc.offer_id
            JOIN reviews_cardreview r ON r.card_id = o.id
            WHERE p.slug = 'credit-card-issuers'
            ORDER BY c.name
        '''
        return Category.objects.raw(query)
    
    def get_offers(self):
        query = '''
            SELECT DISTINCT o.*
            FROM core_offer o
            JOIN reviews_cardreview r ON r.card_id = o.id
            JOIN core_offer_category oc ON oc.offer_id = o.id
            JOIN core_category c ON c.id = oc.category_id
            WHERE o.is_active = 1
            AND r.is_public = 1
            AND c.slug = '%s'
            ORDER BY o.title
            ''' % self.request.GET.get('bank', 'credit-cards')
        return Offer.objects.raw(query)

class ThankYouView(TemplateView):
    template_name ='reviews/thankyou.html'
    
    def get(self, request, *args, **kwargs):
        if 'write-a-review.php' not in request.META.get('HTTP_REFERER', ''):
            raise Http404
        return super(ThankYouView, self).get(request, *args, **kwargs)
    
    def get_context_data(self, **kwargs):
        lead = Lead.objects.get(id=self.request.GET['lead'])
        context = super(ThankYouView, self).get_context_data(**kwargs)
        context['lead'] = lead
        return context


class NewReview(CreateView):
    form_class = CardReviewForm
    
    def get_success_url(self):
        return reverse('review-thank-you')
    
    def form_valid(self, form):
        ratings_formset = self.get_context_data()['ratings_formset']
        if ratings_formset.is_valid():
            self.object = form.save()
            ratings_formset.instance = self.object
            ratings_formset.save()
            lead = save_lead({
                'first_name': self.object.name,
                'last_name': '',
                'email': self.object.email,
                'phone': '',
                'state': 1,
                'ip': self.request.META['REMOTE_ADDR'],
                'source': self.request.build_absolute_uri()
            })
            return HttpResponseRedirect(self.get_success_url() + '?lead=' + str(lead.id))
        else:
            context = self.get_context_data(form=form)
            context['ratings_formset'] = ratings_formset
            return self.render_to_response(context)
    
    def get_context_data(self, **kwargs):
        context = super(NewReview, self).get_context_data(**kwargs)
        context['card'] = self.request.POST.get('card', None)
        try:
            context['image'] = Offer.on_site.get(title=context['card']).image.name
        except Offer.DoesNotExist:
            pass
        if self.request.POST:
            context['ratings_formset'] = RatingFormSet(self.request.POST, instance=self.object)
        else:
            context['ratings_formset'] = RatingFormSet(instance=self.object)
        for subform, data in zip(context['ratings_formset'].forms, Survey.objects.all()):
            subform.initial = {'survey': data}
        return context
        