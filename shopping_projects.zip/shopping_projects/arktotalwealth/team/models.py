from django.db import models
from arktotalwealth.component.models import *
# Create your models here.
class TeamPage(models.Model):
	parent = models.ForeignKey('self',blank=True,null=True)
	title = models.CharField(max_length=255, unique=True)
	slug = models.SlugField(unique=True)
	image = models.ImageField(upload_to='images/',blank=True,null=True,help_text='section header image, width:764')	
	short_description = models.TextField(blank=True,null=True,help_text="this is the short description displayed on landing page")
	content = models.TextField(blank=True,null=True)
	priority = models.IntegerField(default=0)
	active = models.BooleanField("is active ?",default=False)
	landingpage = models.BooleanField("is landing page ?",default=False)
	include_teammembers = models.BooleanField("include auto generated team member content ? ", default=False)
	meta_keywords = models.CharField(max_length=255, blank=True,null=True ,help_text="max length 255 characters, please separate it by ','")
	meta_description = models.TextField(blank=True,null=True)
	action_links = models.ManyToManyField(ActionLink, blank=True,null=True)

	def __unicode__(self):
		return str(self.parent) + ' --> ' + self.title if self.parent else self.title
		
	def get_absolute_url(self):
		return '/team/%s.html' %self.slug if self.parent else '/team/'
	
	def get_current_nav(self):
		return 'team'
	
	class Meta:
	    ordering = ['parent__id','-priority',]
	
class TeamMember(models.Model):
    name = models.CharField(max_length=100)
    position = models.CharField(max_length=100)
    image = models.ImageField(upload_to='images/', help_text='size:164 X 200')
    description = models.TextField()
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name
       
    def get_absolute_url(self):
    	return '/team/'
    
    class Meta:
    	ordering = ['-priority',]