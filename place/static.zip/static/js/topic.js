var nb_text_widget = null;
var nb_image_widget = null;
var nb_video_widget = null;


/**
 * Check ajax responses to see if the user's
 * connection status has moved to be connected.
 *
 * @param  {object} obj Ajax response object.
 * @return {null}
 */
function new_connection(obj) {
    if (obj.data.hasOwnProperty('new_connection') && obj.data.new_connection){
        $('#btn_connect').attr('class', '').html('Disconnect');
        var connected_count = parseInt($('.statistic.participants p').text(), 10);
        $('.statistic.participants p').text(connected_count + 1);
    }
    return;
}

// function load_discussion_posts(topic, element) {
//     ga_tracker('topic', 'Discussion read comments button');

//     var forum = $(element).data('forum');
//     $.ajax({
//         url: '/topics/discussion/posts/',
//         type: 'get',
//         data: {
//             forum: forum,
//             topic: topic
//         },
//         success: function(obj) {
//             if (obj.success) {
//                 $(element)
//                 .find('.discussion_comments .inner')
//                 .html(obj.html)
//                 .find('.forumpost-content')
//                 .expander({
//                      slicePoint: 220
//                 });

//                 update_discussion_page_stats(
//                     obj.data.discussion_count,
//                     (obj.data.discussion_count + obj.data.nb_count)
//                 );

//                 var cont = $(element);

//                 // Update the count in the question thread header
//                 cont.find('.data .comment_count')
//                     .text(
//                         obj.data.thread_count + obj.data.reply_count
//                     );

//                 var toggle_button = cont.find('.toggle_read_comment');

//                 // Update comment button count and text
//                 toggle_button.find('.comment_count')
//                     .text(obj.data.thread_count);

//                 // Check the plurality
//                 toggle_button.find('span').text(
//                     'Comment' + utils.pluralize(obj.data.thread_count, 's')
//                 );
//             }
//         }
//     });
// }

// function load_discussion_replies(topic, element) {

//     ga_tracker('topic', 'Discussion read replies button');

//     var forum = $(element).closest('.discussion_container').data('forum');
//     var thread = $(element).find('.discussion_data').data('thread');
//     $.ajax({
//         url: '/topics/discussion/replies/',
//         type: 'get',
//         data: {
//             forum: forum,
//             thread: thread,
//             topic: topic
//         },
//         success: function(obj) {
//             if (obj.success) {
//                 $(element)
//                     .find('.discussion_replies .replies_inner')
//                     .html(obj.html)
//                     .slideDown();

//                 update_discussion_page_stats(
//                     obj.data.discussion_count,
//                     (obj.data.discussion_count + obj.data.nb_count)
//                 );

//                 // Update the count in the question thread header
//                 var qt_cont = $(element).closest('.discussion_data');
//                 var post_count = obj.data.thread_count + obj.data.reply_count;
//                 qt_cont.find('.data .comment_count')
//                     .text(post_count)
//                     .siblings('span')
//                     .first()
//                     .text('post' + utils.pluralize(post_count, 's'));


//                 var toggle_comments_button = qt_cont.find('.toggle_read_comment');
//                 // Update comment button count and text
//                 toggle_comments_button.find('.comment_count')
//                     .text(obj.data.thread_count);

//                 // Check the plurality
//                 toggle_comments_button.find('span').text(
//                     'Comment' + utils.pluralize(obj.data.thread_count, 's')
//                 );

//                 var toggle_button = $(element).find('.discussion_data .toggle_read_reply');
//                 // Update reply button count and text
//                 toggle_button.find('.reply_count')
//                     .text(obj.data.reply_count);

//                 // Check the plurality
//                 toggle_button.find('span').text(
//                     'Repl' + utils.pluralize(obj.data.reply_count, 'y', 'ies')
//                 );
//             }
//         }
//     });
// }


/**
 * Add new thread or reply to disussion forum
 * @param {string} form Form id.
 * @param {element} toggle_button Element to toggle
 * showing threads or reply threads.
 */
// function add_thread(form, toggle_button) {
//     if ($(form).find('textarea').val() === '' ) {
//         return false;
//     }
//     $(form).ajaxSubmit({
//         type: 'POST',
//         clearForm: true,
//         resetForm: false,
//         dataType: 'json',
//         success: function(obj, statusText, xhr, $form){
//             if (obj.success) {
//                 // Show posts.
//                 $(toggle_button).click();

//                 // Update connection if needed
//                 new_connection(obj);

//                 update_discussion_page_stats(
//                     obj.data.discussion_count,
//                     (obj.data.discussion_count + obj.data.nb_count)
//                 );

//                 var cont = $(form).closest('.discussion_container');
//                 // Update Question button
//                 if (toggle_button.hasClass('toggle_read_comment')) {
//                     // Update the count in the question thread header
//                     cont.find('.data .comment_count')
//                         .text(
//                             obj.data.thread_count + obj.data.reply_count
//                         );

//                     // Update comment button count and text
//                     toggle_button.find('.comment_count')
//                         .text(obj.data.thread_count);

//                     // Check the plurality
//                     toggle_button.find('span').text(
//                         'Comment' + utils.pluralize(obj.data.thread_count, 's')
//                     );
//                 }
//                 // Update Post Button
//                 else {
//                     // Update the count in the question thread header
//                     var qt_cont = cont.closest('.discussion_container');
//                     var post_count = obj.data.thread_count + obj.data.reply_count;
//                     qt_cont.find('.data .comment_count')
//                         .text(post_count)
//                         .siblings('span')
//                         .first()
//                         .text('post' + utils.pluralize(post_count, 's'));

//                     var toggle_comments_button = qt_cont.find('.toggle_read_comment');
//                     // Update comment button count and text
//                     toggle_comments_button.find('.comment_count')
//                         .text(obj.data.thread_count);

//                     // Check the plurality
//                     toggle_comments_button.find('span').text(
//                         'Comment' + utils.pluralize(obj.data.thread_count, 's')
//                     );

//                     // Update reply button count and text
//                     toggle_button.find('.reply_count')
//                         .text(obj.data.reply_count);

//                     // Check the plurality
//                     toggle_button.find('span').text(
//                         'Repl' + utils.pluralize(obj.data.reply_count, 'y', 'ies')
//                     );
//                 }
//             }
//             else {
//                 if (obj.reason === 'login_required') {
//                     redirect_to_login('/topic/' + data.topic + '/discussions/');
//                 }
//             }
//         },
//         error: function(jqXHR, textStatus, errorThrown) {

//         }
//     });
//     return false;
// }

/**
 * Vote on a thread or reply post.
 * @param  {element} element Voting element clicked.
 */
// function vote(element) {
//     var vote_num = $(element).hasClass('vote-type-like') ? 1 : -1;
//     var category_type = $(element).closest('.discussion_container').data('category-type');
//     var forum = $(element).closest('.discussion_container').data('forum');
//     var thread_type = $(element).closest('.vote_buttons').data('thread-type');
//     var thread;
//     if (category_type == 'discussion') {
//         thread = $(element).closest('.discussion_data').data('thread');
//     }
//     else {
//         thread = $(element).closest('.noticeboard_data').data('thread');
//     }
//     $.ajax({
//         url: '/topics/discussion/vote/',
//         type: 'post',
//         data: {
//             topic              : data.topic, // Global variable
//             category_type      : category_type,
//             forum              : forum,
//             thread             : thread,
//             thread_type        : thread_type,
//             vote               : vote_num,
//             csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
//         },
//         success: function(obj) {
//             if (obj.success) {
//                 if (thread_type === 'reply') {
//                     if (category_type === 'discussion') {
//                         $(element)
//                             .closest('.reply_container')
//                             .find('.reply .discussion-voterating-rating')
//                             .html(obj.data.up_vote - obj.data.down_vote);
//                     }
//                     else {
//                         $(element)
//                             .closest('.comment_container')
//                             .find('.comment .discussion-voterating-rating')
//                             .html(obj.data.up_vote - obj.data.down_vote);
//                     }
//                 }
//                 else {
//                     if (category_type === 'discussion') {
//                         // Update the rating number
//                         $(element)
//                             .closest('.discussion_data')
//                             .find('.discussion-voterating-rating')
//                             .html(obj.data.up_vote - obj.data.down_vote);
//                     }
//                     else {
//                         $(element)
//                             .closest('.noticeboard_data')
//                             .find('.discussion-voterating-rating')
//                             .html(obj.data.up_vote - obj.data.down_vote);
//                     }
//                 }

//                 // Update the rating number
//                 // $(element)
//                 //     .closest('.discussion_container').find('.discussion .discussion-voterating-rating')
//                 //     .html(obj.data.up_vote - obj.data.down_vote);

//                 var vote_types = $(element).closest('.vote_buttons');
//                 // Update down vote
//                 vote_types
//                     .find('.vote-type-dislike')
//                     .removeClass('disabled')
//                     .find('.vote-type-count')
//                     .html(obj.data.down_vote);

//                 // Update up vote
//                 vote_types
//                     .find('.vote-type-like')
//                     .removeClass('disabled')
//                     .find('.vote-type-count')
//                     .html(obj.data.up_vote);


//                 // Disable voted button
//                 $(element).addClass('disabled');

//                 // Update connection if needed
//                 new_connection(obj);
//             }
//             else {
//                 if (obj.reason === 'login_required') {
//                     redirect_to_login('/topic/' + data.topic + '/discussions/');
//                 }
//             }

//         }
//     });
//     return false;
// }

/**
 * Setup noticeboard new post editors.
 */
// function enable_nb_creator() {
//     if ($('#nb-creators').size() === 0) {
//         return;
//     }

//     // Create redactor widget for text post.
//     nb_text_widget = $('#nb-text .nb-text-input').redactor({
//         focus: true,
//         buttons: [
//             'bold',
//             'italic',
//             'underline',
//             'deleted',
//             '|',
//             'link'
//         ]
//     });

//     // Create redactor widget for video post.
//     nb_video_widget = $('#nb-video .nb-video-input').redactor({
//         focus: true,
//         buttons: [
//             'bold',
//             'italic',
//             'underline',
//             'deleted',
//             '|',
//             'link'
//         ]
//     });

//     // Create redactor widget for image post.
//     nb_image_widget = $('#nb-image .nb-image-input').redactor({
//         focus: true,
//         buttons: [
//             'bold',
//             'italic',
//             'underline',
//             'deleted',
//             '|',
//             'link'
//         ]
//     });

//     var upload_btn_text;
//     if (BrowserDetect.browser == 'Explorer') {
//         upload_btn_text = '<div>Add more images by clicking here.</div>';
//     }
//     else {
//         upload_btn_text = '<div>Add more images by clicking or dropping files here.</div>';
//     }
//     // Create image uploader for image post.
//     var uploader = new qq.FileUploader({
//       element: $('#nb-image-uploader')[0],
//       action: '/assets/nb_image_upload/',
//       params: {
//         'topic': data.topic
//       },
//       debug: false,
//       multiple: true,
//       maxConnections: 5,
//       allowedExtensions: ['jpeg', 'jpg', 'png', 'gif'],
//       sizeLimit: 10485760,
//       dragText: '<h4>Drop files here</h4>',
//       uploadButtonText: upload_btn_text,
//       onSubmit: function(id, fileName) {
//         $('#form-nb-image .button').addClass('disabled');
//       },
//       showMessage: function(msg) {
//          // console.log(msg);
//       },
//       onComplete: function(id, fileName, responseJSON) {
//         $('#nb-image .button').removeClass('disabled');
//         if (responseJSON.success) {
//             $('#nb-image .qq-upload-list li').delay(3000).slideUp('fast');
//             $(responseJSON.html).hide()
//                     .prependTo('#nb-image .images')
//                     .slideDown('fast')
//                     .find('.delete')
//                     .click(function(){
//                         $(this).closest('.nb_image_card').remove();
//                     });
//             $('#nb-image .images')
//                 .sortable({
//                     placeholder: 'draggable-image-placeholder',
//                     forcePlaceholderSize: true,
//                     opacity: 0.8,
//                     start: function(event, ui){
//                         $(ui.item).addClass('shadow');
//                     },
//                     stop: function(event, ui){
//                         $(ui.item).removeClass('shadow');
//                     }
//                 });
//         }
//         else {
//             if(responseJSON.hasOwnProperty('reason') && responseJSON.reason === 'login_required') {
//                 redirect_to_login('/topic/' + data.topic + '/noticeboard/');
//             }
//         }
//       },
//       template: '<div class="qq-uploader">' +
//                   '<div class="qq-upload-button" style="width: auto;">{uploadButtonText}</div>' +
//                   '<div class="qq-upload-drop-area">{dragText}</div>' +
//                   '<div class="list"><ul class="qq-upload-list" style="margin-top: 10px; text-align: center;"></ul></div>' +
//                 '</div>',
//       fileTemplate: '<li>' +
//                   '<span class="qq-upload-finished"></span>' +
//                   '<span class="qq-upload-file"></span>' +
//                   '<span class="qq-upload-size"></span>' +
//                   '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
//                   '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
//                   '<span class="qq-upload-spinner"></span>' +
//                   '<div class="qq-progress-bar"></div>' +
//                   '<div class="clear_both"></div>' +
//                   '</li>'
//     });
//     return false;
// }


/**
 * Update the noticeboard call to action.
 */
// function update_nb_title() {
//     if ($('#tab_notice .nb-creator').size() > 0) {
//         $('.nb-title-nothreads').hide();
//         $('.nb-title').show();
//     }
//     return;
// }

/**
 * Post new text to noticeboard.
 */
// function nb_text_post() {
//     // If not text exit
//     if ( nb_text_widget.getText().replace(/^\s+|\s+$/g,'').length === 0 ) {
//         return false;
//     }
//     $('#form-nb-text').ajaxSubmit({
//         type: 'POST',
//         clearForm: true,
//         resetForm: false,
//         dataType: 'json',
//         success: function(obj, statusText, xhr, $form){
//             if (obj.success) {
//                 nb_text_widget.setCode('<p></p>');
//                 // Show new post.
//                 $(obj.html).hide()
//                     .prependTo('#tab_notice .nb-posts')
//                     .slideDown('fast');

//                 // Update connection if needed
//                 new_connection(obj);

//                 // Update active discussion stats and tab count.
//                 var act_disc_count = parseInt($('.statistic.discussions p').text(), 10);
//                 $('.statistic.discussions p').text(act_disc_count + 1);

//                 // Update noticeboard tab count.
//                 var disc_tab_count = parseInt($('#nb_count').text(), 10);
//                 $('#nb_count').text(disc_tab_count + 1);

//                 update_nb_title();
//             }
//             else {
//                 if(obj.reason === 'login_required') {
//                     redirect_to_login('/topic/' + data.topic + '/noticeboard/');
//                 }
//                 // else if(obj.reason === 'invalid') {
//                 //    // show_errors($('#noticeboard-errors'), obj);
//                 // }
//             }
//         },
//         error: function(jqXHR, textStatus, errorThrown) {

//         }
//     });
//     return false;
// }

/**
 * Post new video to noticeboard.
 */
// function nb_video_post() {
//     $('#form-nb-video').ajaxSubmit({
//         type: 'POST',
//         clearForm: true,
//         resetForm: false,
//         dataType: 'json',
//         success: function(obj, statusText, xhr, $form){
//             if (obj.success) {
//                 // Clear form
//                 nb_video_widget.setCode('<p></p>');

//                 // Show new post.
//                 $(obj.html).hide()
//                     .prependTo('#tab_notice .nb-posts')
//                     .slideDown('fast');

//                 // Update connection if needed
//                 new_connection(obj);

//                 // Update active discussion stats and tab count.
//                 var act_disc_count = parseInt($('.statistic.discussions p').text(), 10);
//                 $('.statistic.discussions p').text(act_disc_count + 1);

//                 // Update noticeboard tab count.
//                 var disc_tab_count = parseInt($('#nb_count').text(), 10);
//                 $('#nb_count').text(disc_tab_count + 1);

//                 $("a[rel^='prettyPhoto']").prettyPhoto({
//                     social_tools: false
//                 });
//                 update_nb_title();
//             }
//             else {
//                 if(obj.reason === 'login_required') {
//                     redirect_to_login('/topic/' + data.topic + '/noticeboard/');
//                 }
//                 else if(obj.reason === 'invalid') {
//                     show_errors($('#noticeboard-errors'), obj);
//                 }
//             }
//         },
//         error: function(jqXHR, textStatus, errorThrown) {

//         }
//     });
//     return false;
// }

/**
 * Post new image to noticeboard.
 */
// function nb_image_post() {
//     if ($('#form-nb-image .button').hasClass('disabled')) return;

//     $('#form-nb-image').ajaxSubmit({
//         type: 'POST',
//         clearForm: true,
//         resetForm: false,
//         dataType: 'json',
//         success: function(obj, statusText, xhr, $form){
//             if (obj.success) {

//                 // Remove images
//                 $('#nb-image .images').empty();

//                 // Clear form
//                 nb_image_widget.setCode('<p></p>');

//                 // Show new post.
//                 $(obj.html).hide()
//                     .prependTo('#tab_notice .nb-posts')
//                     .slideDown('fast')
//                     .find('.flexslider')
//                     .flexslider({
//                         controlNav: false,
//                         randomize: false
//                     });

//                 // Update connection if needed
//                 new_connection(obj);

//                 // Update active discussion stats and tab count.
//                 var act_disc_count = parseInt($('.statistic.discussions p').text(), 10);
//                 $('.statistic.discussions p').text(act_disc_count + 1);

//                 // Update noticeboard tab count.
//                 var disc_tab_count = parseInt($('#nb_count').text(), 10);
//                 $('#nb_count').text(disc_tab_count + 1);

//                 $('.flexslider').flexslider({
//                     controlNav: false,
//                     randomize: false
//                 });

//                 update_nb_title();
//             }
//             else {
//                 if(obj.reason === 'login_required') {
//                     redirect_to_login('/topic/' + data.topic + '/noticeboard/');
//                 }
//                 else if(obj.reason === 'invalid') {
//                     show_errors($('#noticeboard-errors'), obj);
//                 }
//             }
//         },
//         error: function(jqXHR, textStatus, errorThrown) {

//         }
//     });
//     return false;
// }


// function nb_reply(form, toggle_button) {
//     if ($(form).find('textarea').val() === '' ) {
//         return false;
//     }
//     $(form).ajaxSubmit({
//         type: 'POST',
//         clearForm: true,
//         resetForm: false,
//         dataType: 'json',
//         success: function(obj, statusText, xhr, $form){
//             if (obj.success) {
//                 // Show posts.
//                 $(toggle_button).click();

//                 // Update connection if needed
//                 new_connection(obj);

//                 // Update active discussion stats and tab count.
//                 var act_disc_count = parseInt($('.statistic.discussions p').text(), 10);
//                 $('.statistic.discussions p').text(act_disc_count + 1);

//                 // Update noticeboard tab count.
//                 var disc_tab_count = parseInt($('#nb_count').text(), 10);
//                 $('#nb_count').text(disc_tab_count + 1);
//             }
//             else {
//                 if (obj.reason === 'login_required') {
//                     redirect_to_login('/topic/' + data.topic + '/noticeboard/');
//                 }
//             }
//         },
//         error: function(jqXHR, textStatus, errorThrown) {

//         }
//     });
//     return false;
// }

// function load_noticeboard_replies(topic, element) {
//     ga_tracker('topic', 'Noticeboard read replies button');
//     var thread = $(element).data('thread');
//     $.ajax({
//         url: '/topics/noticeboard/replies/',
//         type: 'get',
//         data: {
//             thread: thread,
//             topic: topic
//         },
//         success: function(obj) {
//             if (obj.success) {
//                 $(element)
//                     .find('.noticeboard_replies .inner')
//                     .html(obj.html);
//             }
//             else{
//             }
//         }
//     });
// }

// function admin_invite(invite, role, topic, response){
//     if (response === 'd' || response === 'a') {
//         $.ajax({
//             url: '/invitation_response/',
//             type:'POST',
//             dataType: 'json',
//             data : {
//                 'invite'             : invite,
//                 'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value,
//                 'role'               : role,
//                 'topic_id'           : topic,
//                 'response'           : response
//             },
//             success: function(obj, textStatus, jqXHR){
//                 if (obj.success) {
//                     if (response === 'a') {
//                         $(".invite-alert").html('<p>Please wait while the page reloads...</p>');
//                         window.location.reload();
//                     }
//                     $("#invite-alert").parents('div').remove();
//                 }
//                 else {
//                     if (obj.reason === 'login_required') {
//                         window.location.href = obj.data.url;
//                     }
//                 }
//             }
//         });
//     }
//     else {
//         return;
//     }
// }

// Count views when a user toggles a discussion
// Only one "view" is counted for a discussion per user session.
// function count_discussion_view(discussion_element, forum_id){
//     $.ajax({
//         url: '/topics/discussion/view_counter',
//         data: {'forum_id': forum_id},
//         success: function(obj){
//             if(obj.success){
//                 $(discussion_element)
//                     .find('.view_count')
//                     .text(obj.data.view_count);
//             }
//         }
//     });
// }

// function update_discussion_page_stats(tab_count, topic_discussion_count) {
//     // Update active discussion stats and tab count.
//     $('.statistic.discussions p').text(topic_discussion_count);

//     // Update discussion tab count.
//     $('#discussion_count').text(tab_count);
// }

$(function() {

    // When new dicussion comments change update stat counts.
    /*
    $('.discussion_comments').on('contentchanged', function(a){
        var cnt = $(this).find('.comment_container').size();
        $(this)
            .closest('.discussion_container')
            .find('.comment_count').html(cnt);
    });
    */
    // Toggle viewing comment posts.

    // $(document).on('click', '.toggle_read_comment', function() {
    // // $('.toggle_read_comment').click(function() {
    //     var disc_cont = $(this).parents('.discussion_container');
    //     if (disc_cont.data('category-type') == 'noticeboard') {
    //         var replies = disc_cont.find('.noticeboard_replies');
    //         if (replies.css('display') == 'none') {
    //             // data.topic (global to topic page)
    //             load_noticeboard_replies(data.topic, disc_cont);
    //         }
    //     }
    //     else{
    //         var comments = disc_cont.find('.discussion_comments');
    //         if (comments.css('display') == 'none') {
    //             // data.topic (global to topic page)
    //             load_discussion_posts(data.topic, disc_cont);
    //             count_discussion_view(disc_cont, disc_cont.data('forum'));
    //         }
    //     }
    //     return false;
    // });

    // Toggle viewing reply posts.
    // $(document).on('click', '.toggle_read_reply', function() {
    //     var comms_cont = $(this).closest('.comment_wrapper');
    //     var replies = comms_cont.find('.discussion_replies');
    //     if (replies.css('display') == 'none') {
    //        // data.topic (global to topic page)
    //        load_discussion_replies(data.topic, comms_cont);
    //     }
    //     return false;
    // });

    // Make all question images clicable so they
    // can be viewed in their original size.
    // $.each($(".fullsize_image img"), function() {
    //     $(this).wrap('<a target="_blank" href="' + this.src + '"></a>');
    // });

    // Discussion voting click event.
    // $(document).on('click', '.discussion_data .vote-type', function(){
    //     if (!$(this).hasClass('disabled')) {
    //         vote(this);
    //     }
    //     return false;
    // });

    // // Noticeboard voting click event.
    // $(document).on('click', '.noticeboard_data .vote-type', function(){
    //     if (!$(this).hasClass('disabled')) {
    //         vote(this);
    //     }
    //     return false;
    // });

    // New comment click event to submit form.
  //   $(document).on('click', '.form-new-post .button', function() {
  //       var form = $(this).closest('.form-new-post');
  //       var toggle_btn = $(this)
  //           .closest('.discussion_container')
  //           .find('.toggle_read_comment');
  //       add_thread(form, toggle_btn);
  //   });

  //   // New reply click event to submit form.
  //   $(document).on('click', '.form-new-reply .button', function() {
  //       var form = $(this).closest('.form-new-reply');
  //       var toggle_btn = $(this)
  //           .closest('.comment_wrapper')
  //           .find('.toggle_read_reply');
  //       add_thread(form, toggle_btn);
  //   });

  //   // Handle event for blocking post.
  //   $(document).on('click', '.block-post', function() {
  //       var category_type = $(this).closest('.discussion_container').data('category-type');
  //       var forum = $(this).closest('.discussion_container').data('forum');
  //       var disc_data;
  //       if (category_type == 'discussion') {
  //           disc_data = $(this).closest('.discussion_data');
  //       }
  //       else {
  //           disc_data = $(this).closest('.noticeboard_data');
  //       }
  //       var thread = disc_data.data('thread');
  //       var thread_type = disc_data.data('type');

  //       var form_editor = new FormEditor('form-moderate', '/topics/discussion/moderate/',{
  //           category_type: category_type,
  //           topic: data.topic,
  //           forum: forum,
  //           thread: thread,
  //           thread_type: thread_type
  //       }, {
  //        size: 'small'
  //       });
  //       form_editor.on('show', function(){
  //           $('#form-moderate textarea').focus();
  //       });
  //       form_editor.on('success', function(){
  //           try {
  //               if (category_type == 'discussion') {
  //                   // Refresh discussion list.
  //                   if (thread_type=='thread') {
  //                       load_discussion_posts(
  //                           data.topic,
  //                           disc_data.closest('.discussion_container')
  //                       );
  //                   }
  //                   else{
  //                       load_discussion_replies(
  //                           data.topic,
  //                           disc_data.closest('.comment_wrapper')
  //                       );
  //                   }
  //               }
  //               else {  // Refresh Noticeboard thread.
  //                   if (thread_type=='thread') {
  //                       $('#nb-content-' + thread).remove();
  //                       disc_data.find('.moderated').show();
  //                       disc_data.find('.toggle_post_comment').addClass('disabled');
  //                   }
  //                   else {
  //                       load_noticeboard_replies(
  //                           data.topic,
  //                           disc_data.closest('.discussion_container')
  //                       );
  //                   }
  //               }
  //           }
  //           catch(err) {}
  //       });
  //       form_editor.show();
  //   });

  //   // Report abuse of a forum post.
  //   $(document).on('click', '.report-post', function() {
  //       var element = $(this);
  //       var category_type = $(element).closest('.discussion_container').data('category-type');
  //       var forum = element.closest('.discussion_container').data('forum');
  //       var disc_data;
  //       var dialog;
  //       dialog = new Dialog();
  //       content = "<p>Are you sure this is abuse?</p><p>Please visit the moderation page <a href = '/terms/moderation'> here </a>to determine wether or not this post contains abuse</p></paragraph>";
  //       dialog.static_content =  content;
		// dialog.setHeader("Report Abuse");
		// dialog.size = "medium";

		// $("#dialog-ok, #dialog-cancel").remove();
		// $("#dialog .actions span").append('<a href="#" class="cancel" id="dialog-cancel-custom">cancel</a>');
		// $("#dialog .actions span").append('<a href="#" class="button normal submit" id="dialog-report-custom">Report</a>');
		// dialog.show();
		// $("#dialog-cancel-custom").on("click", function(){
  //   		dialog.close();
  //   		dialog.reset();
  //   	});

		// $("#dialog-report-custom").click(function(){

		// 	if (category_type == 'discussion') {
  //           disc_data = element.closest('.discussion_data');
  //       }
  //       else {
  //           disc_data = element.closest('.noticeboard_data');
  //       }
  //       var thread = disc_data.data('thread');
  //       var thread_type = disc_data.data('type');
  //       $.ajax({
  //           url: '/topics/discussion/abuse/',
  //           type: 'post',
  //           data: {
  //               topic: data.topic,
  //               category_type: category_type,
  //               forum: forum,
  //               thread: thread,
  //               thread_type: thread_type,
  //               csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
  //           },
  //           success: function(obj) {
  //               if (obj.success) {
  //                   element.html('Reported');
  //                   element.removeClass('report-post');
  //               }
  //               else {
  //                   if (obj.reason === 'login_required') {
  //                       redirect_to_login('/topic/' + data.topic + '/discussions/');
  //                   }
  //               }
  //           }
  //       });
  //       dialog.close();
  //   	dialog.reset();
		// });


  //   });

  //   // Delete a forum post.
  //   $(document).on('click', '.delete-post', function() {
  //       var element = $(this);
  //       var category_type = $(element).closest('.discussion_container').data('category-type');
  //       var forum = element.closest('.discussion_container').data('forum');
  //       var disc_data;
  //       if (category_type == 'discussion') {
  //           disc_data = element.closest('.discussion_data');
  //       }
  //       else {
  //           disc_data = element.closest('.noticeboard_data');
  //       }
  //       var thread = disc_data.data('thread');
  //       var thread_type = disc_data.data('type');
  //       $.ajax({
  //           url: '/topics/discussion/delete/',
  //           type: 'post',
  //           data: {
  //               topic: data.topic,
  //               thread: thread,
  //               thread_type: thread_type,
  //               csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
  //           },
  //           success: function(obj) {
  //               if(obj.success) {
  //                   disc_data.slideUp('fast').remove();
  //               }
  //           }
  //       });
  //   });

  //   // Toggle all discussion forums
  //   $(document).on('click', '#follow-discussions', function() {
  //       var element = $(this);
  //       var is_following = element.hasClass('following_discussions');
  //       $.ajax({
  //           url: '/topics/discussion/follow_all/',
  //           type: 'post',
  //           data: {
  //               topic: data.topic, // Global variable
  //               is_following: is_following,
  //               csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
  //           },
  //           success: function(obj) {
  //               if (obj.success) {
  //                   if (is_following) {
  //                       element.removeClass('following_discussions');
  //                       element.html('Follow Discussions');
  //                       $('#tab_discussions')
  //                           .find('.follow-discussion')
  //                           .removeClass('following_discussion')
  //                           .html('Follow this Discussion');
  //                   }
  //                   else{
  //                       element.addClass('following_discussions');
  //                       element.html('Unfollow Discussions');
  //                       $('#tab_discussions')
  //                           .find('.follow-discussion')
  //                           .addClass('following_discussion')
  //                           .html('Unfollow this Discussion');
  //                   }
  //                   // Update connection if needed
  //                   new_connection(obj);
  //               }
  //               else {
  //                   if (obj.reason === 'login_required') {
  //                       redirect_to_login('/topic/' + data.topic + '/discussions/');
  //                   }
  //               }
  //           }

  //       });
  //   });

  //   // Toggle individual discussion forums
  //   $(document).on('click', '.follow-discussion', function() {
  //       var element = $(this);
  //       var forum = element.closest('.discussion_container').data('forum');
  //       var is_following = element.hasClass('following_discussion');
  //       $.ajax({
  //           url: '/topics/discussion/follow/',
  //           type: 'post',
  //           data: {
  //               topic: data.topic, // Global variable
  //               forum: forum,
  //               is_following: is_following,
  //               csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
  //           },
  //           success: function(obj) {
  //               if (obj.success) {
  //                   if (is_following) {
  //                       element.removeClass('following_discussion');
  //                       element.html('Follow Discussion');
  //                       $('#follow-discussions')
  //                           .removeClass('following_discussions')
  //                           .html('Follow this Discussions');
  //                   }
  //                   else{
  //                       element.addClass('following_discussion');
  //                       element.html('Unfollow Discussion');
  //                       if(obj.data.is_following_all) {
  //                           $('#follow-discussions')
  //                               .addClass('following_discussions')
  //                               .html('Unfollow this Discussions');
  //                       }
  //                   }
  //                   // Update connection if needed
  //                   new_connection(obj);
  //               }
  //               else {
  //                   if (obj.reason === 'login_required') {
  //                       redirect_to_login('/topic/' + data.topic + '/discussions/');
  //                   }
  //               }
  //           }
  //       });
  //   });

  //   // Click event expanding map.
  //   $('#topic_google_map .map-fullscreen').click(function() {
  //       ga_tracker('topic', 'Fullscreen Map button');

  //       var dg = new Dialog(
  //       '/topics/topic_map/',
  //       {
  //         topic: data.topic
  //       },
  //       {
  //         size: 'fullscreen'
  //       }
  //       );

  //       dg.on('ok', function() {
  //       dg.close();
  //       });
  //       dg.on('show', function() {

  //           // Settings in global topic json object.
  //           var map_opts = {
  //               zoom: data.map_zoom ? data.map_zoom : 13,
  //               center: new google.maps.LatLng(data.map_center[0], data.map_center[1])
  //           };

  //           // Height adjustments
  //           $('#fullscreen-map').height(
  //               $(window).height() *
  //               0.9 -
  //               $('#map-dialog header').outerHeight() -
  //               $('#dialog .modal-footer').outerHeight()
  //           );
  //           var gmap = new GMap('fullscreen-map', map_opts);
  //           // Load places
  //           $.ajax({
  //               url: '/maps/topic_places/',
  //               type: 'get',
  //               data: {
  //                   'topic': data.topic
  //               },
  //               success: function(places) {
  //                   for (var i = 0, plc_cnt=places.length; i < plc_cnt; i++) {
  //                       var coords = places[i];
  //                       gmap.addUserPin(coords[0], coords[1]);
  //                   }
  //               }
  //           });

  //           // Load polys
  //           $.ajax({
  //               url: '/maps/aois/',
  //               type: 'get',
  //               data: {
  //                   'topic': data.topic
  //               },
  //               success: function(obj) {
  //                   if (obj.success) {
  //                       for (var i = 0, ft_cnt=obj.data.mapdata.features.length; i < ft_cnt; i++) {
  //                           obj.data.mapdata.features[i].properties['style']['clickable'] = false;
  //                       }
  //                       gmap.addTopicPolys(obj.data.mapdata);
  //                   }
  //               }
  //           });

  //           gmap.addTopic(
  //               data.topic,
  //               data.category,
  //               data.map_center[0],
  //               data.map_center[1]
  //           );

  //           // Add topic polys to map
  //           // gmap.addPlaceTopicTiles(data.topic);
  //           // gmap.addTopicPolyTiles(data.topic);
  //       });
  //       dg.show();
  //   });

  //   // Toggle event for noticeboard post creators.
  //   $('#nb-creators a').click(function() {
  //       var sel = $(this).data('switch');
  //       $(sel).slideDown();
  //       $('.nb-creator').not(sel).slideUp();
  //   });

  //   // Noticeboard text post click event to submit form.
  //   $('#form-nb-text .button').click(function() {
  //       $('#noticeboard-errors')
  //           .hide()
  //           .html('');
  //       $('#form-nb-text .content').val(
  //           $('#nb-text .nb-text-input').redactor().getCode()
  //       );
  //       nb_text_post();
  //   });

  //   // Noticeboard video post click event to submit form.
  //   $('#form-nb-video .button').click(function() {
  //       $('#noticeboard-errors')
  //           .hide()
  //           .html('');

  //       $('#form-nb-video .content').val(
  //           $('#nb-video .nb-video-input').redactor().getCode()
  //       );
  //       nb_video_post();
  //   });

  //   // Noticeboard image post click event to submit form.
  //   $('#form-nb-image .button').click(function() {
  //       $('#noticeboard-errors')
  //           .hide()
  //           .html('');

  //       $('#form-nb-image .content').val(
  //           $('#nb-image .nb-image-input').redactor().getCode()
  //       );
  //       nb_image_post();
  //   });

  //   // New comment click event to submit form.
  //   $(document).on('click', '.form-nb-reply .button', function() {
  //       var form = $(this).closest('.form-nb-reply');
  //       var toggle_btn = $(this)
  //           .closest('.discussion_container')
  //           .find('.toggle_read_comment');
  //       nb_reply(form, toggle_btn);
  //   });

  //   $('#follow-noticeboard').click(function() {
  //       var element = $(this);
  //       var is_following = element.hasClass('following_noticeboard');
  //       $.ajax({
  //           url: '/topics/noticeboard/follow/',
  //           type: 'post',
  //           data: {
  //               topic: data.topic, // Global variable
  //               is_following: is_following,
  //               csrfmiddlewaretoken: document.getElementsByName('csrfmiddlewaretoken')[0].value
  //           },
  //           success: function(obj) {
  //               if (obj.success) {
  //                   if (is_following) {
  //                       element.removeClass('following_noticeboard');
  //                       element.html('Follow Noticeboard');

  //                   }
  //                   else{
  //                       element.addClass('following_noticeboard');
  //                       element.html('Unfollow Noticeboard');
  //                   }
  //                   // Update connection if needed
  //                   new_connection(obj);
  //               }
  //               else {
  //                   if (obj.reason === 'login_required') {
  //                       redirect_to_login('/topic/' + data.topic + '/noticeboard/');
  //                   }
  //               }
  //           }
  //       });
  //   });
  //   // Enable noticeboard post creators.
  //   enable_nb_creator();

    // Poll form button click event
    $('.poll .input-submit').click(function() {
        var self = $(this);
        if (self.hasClass('disabled')) return;

        var form = $('#poll-vote');

        // Disable submit button
        self.addClass('disabled');
        form.ajaxSubmit({
            type: 'POST',
            clearForm: false,
            resetForm: false,
            dataType: 'json',
            success: function(obj, statusText, xhr, $form){
                if (obj.success) {
                    form.find('input[type="radio"]').attr('disabled', true);
                    $('#poll-errors').hide();
                    $('#poll_results').html(obj.html);
                    $('#poll_results').slideDown('fast');
                }
                else {
                    self.removeClass('disabled');
                    form.find('input[type="radio"]').attr('disabled', false);
                    if (obj.reason === 'invalid') {
                        show_errors($('#poll-errors'), obj);
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {

            }
        });
        return false;
    });
});

// if (active_tab == 'overview') {
//     load_topic_map();
// }
// else{
//     $('a[rel="tab_overview"]').click(function(){
//         if (!gmaps.hasOwnProperty('topic')) {
//             load_topic_map();
//         }
//     });
// }
