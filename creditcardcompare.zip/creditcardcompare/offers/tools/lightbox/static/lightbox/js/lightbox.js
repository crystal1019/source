var lightbox_caller = null;
function loadLightbox(evt){
	if (evt.type=="click"){
		var template = $(this).attr('lightbox');
		if (template == ''){return true;};
		if (template.indexOf('only')!=-1) evt.preventDefault ? evt.preventDefault() : evt.returnValue = false;
		lightbox_caller = this;
	}else{
		template = lightbox_caller = evt;
	};
	setupOverlay();
	try{  // cookie is optional, orignally used only by smart-search-tool
		$.cookie('lightbox_triggered', 'true');
	}catch(e){};
	$.ajax({
		url: '/lightbox/?template=' + template,
		success: function(data) {
			$("#lightbox-overlay").after(data);
			$('div.lightbox').fadeIn('fast', function(){
				reposition('div.lightbox');
			});
			$('a.lightbox-close, div#lightbox-overlay').click(closeLightbox);
		}
	});
};
function closeLightbox(evt){
	$('div#lightbox-overlay img').hide();
	$('div.lightbox').fadeOut('fast', function(){$('div#lightbox-overlay').fadeOut('fast');});
	$('div.lightbox').remove();
};
function reposition(box){
	$(box).center({withScrolling: false});
	$(box).css('position', 'fixed');
};
function setupOverlay(){
	$('div#lightbox-overlay').fadeIn('fast', function() {
		$('div#lightbox-overlay img').show();
		reposition('div#lightbox-overlay img');
		$('div#lightbox-overlay').css('opacity', 0.7);
	});
	$( window ).resize(function(){reposition('div.lightbox');});
};
var offerMetaData = {};
function getMetaData(method, href, data){
	try{
		var category_id = $('#table')[0].className.split(' ').pop();	
	}catch(e){};
    jQuery.ajax({
        type: method||'GET',
        url: href,
        data: 'metadata_only='+(category_id||'1')+'&'+(data||''),
        dataType: 'json',
        error: function() {
        },
        success: function(data) {
            offerMetaData = data.offerMetaData;
        }
    });	
};
$(document).ready(function() {
	$('.lightbox-trigger').click(loadLightbox);
	$(document).ajaxComplete(function(event, xhr, settings){
		try{
			if (isPagination(event, xhr, settings) || loadedDetails(event, xhr, settings)){
				$('.lightbox-trigger').unbind("click").click(loadLightbox);
			}
		}catch(e){}
	});
});