# from django.http import HttpResponse, HttpResponseRedirect, Http404
# from django.views.generic.simple import direct_to_template
# from django.http import HttpResponse, HttpResponseRedirect
# from django.shortcuts import render_to_response
# from django.template import RequestContext
# from django.http import Http404
# from place.topics.views import all_topics
# from place.topics.models import *
# from place.settings import ALLOWED_IPS
# from django.utils.encoding import smart_str
# from django.views.decorators.csrf import csrf_exempt
# from place.socialregistration.contrib.facebook.models import FacebookProfile
# from place.accounts.models import UserProfile, Place
# from django.utils import simplejson
# from place.libs.message import Msg
# from place.libs.ps_decorators import cross_domain_ajax
# from django.contrib.auth.models import User
# from place.tools.models import TickerObjects, Redirects
# import time
# import datetime

# def staticpages(request, page_name):
#     if page_name != 'index':
#         if page_name == 'about':
#             return HttpResponseRedirect('/about/placespeak/')
#         return render_to_response('staticPages/%s.html' % (page_name, ),
#             {
#                 'request': request,
#                 'user_ip': request.META.get('REMOTE_ADDR', None)
#             },
#             context_instance=RequestContext(request))
#     else:
#         return render_to_response(
#             'home/home.html',
#             {},
#             context_instance=RequestContext(request)
#         )

#         # users = []
#         # featured_users = UserProfile.objects.filter(avatar__gt='').order_by('?')[:27]#27
#         # for user in featured_users:
#         #   users.append('/uploads/'+smart_str(user.avatar)+'/')
#         # required_fb_users = 54 - len(featured_users)
#         # featured_fb_users = FacebookProfile.objects.order_by('?')[:required_fb_users]
#         # for user in featured_fb_users:
#         #   users.append('//graph.facebook.com/'+user.uid+'/picture?return_ssl_resources=1&type=square')
#         # return render_to_response('%s.html' % (page_name, ),
#         #   {
#         #       'request':request, 
#         #       'topics':all_topics(request), 
#         #       'users':users,
#         #       'user_ip': request.META.get('REMOTE_ADDR', None),
#         #       'tickers': TickerObjects.objects.filter(is_active=True)
#         #   }, 
#         #   context_instance=RequestContext(request))
        
# def load_images(request):
    
#     msg = Msg()
    
#     users = []
#     image = []
#     featured_users = UserProfile.objects.filter(avatar__gt='').order_by('?')[:27]#27
#     for user in featured_users:
#         #image = ['/uploads/'+smart_str(user.avatar)+'/']
#         image = [user.get_bestfit_thumbnail(50)]
#         users.append(image)
#     required_fb_users = 54 - len(featured_users)
#     featured_fb_users = FacebookProfile.objects.order_by('?')[:required_fb_users]
#     for user in featured_fb_users:
#         image = ['//graph.facebook.com/'+user.uid+'/picture?return_ssl_resources=1&type=square']
#         users.append(image)
    
#     #json = simplejson.dumps(users)
#     msg.data['images'] = users
#     return HttpResponse(msg.toJson(), mimetype='application/json')
    

# def faqs(request, faq_type):
#     return render_to_response('staticPages/%sFaq.html' % (faq_type, ),{'request':request}, context_instance=RequestContext(request))
            
# def aboutredirect(request):
#     return HttpResponseRedirect('/about/placespeak/')
            
# def redirects(request):
#     return HttpResponseRedirect('/topic/'+request.GET['id']+'/')
    
# def vanity (request, vanity):
    
#     vanity = vanity.lower()
    
#     if vanity == 'backyardcompost':
#         return HttpResponseRedirect('/topic/243/')
#     elif vanity == 'gibsonsharbour':
#         return HttpResponseRedirect('/topic/118/')
#     elif vanity == 'hamiltonareaplan':
#         return HttpResponseRedirect('/topic/413/')
#     elif vanity == 'kpra':
#         return HttpResponseRedirect('/topic/126/')
#     elif vanity == 'oakridgecentre':
#         return HttpResponseRedirect('/topic/525/')
#     elif vanity == 'ourfuture.vsb':
#         return HttpResponseRedirect('/topic/375/')
#     elif vanity == 'OurFuture.VSB':
#         return HttpResponseRedirect('/topic/375/')
#     elif vanity == 'rcbc':
#         return HttpResponseRedirect('/topic/321/')
#     elif vanity == 'tofinotsunamisiren':
#         return HttpResponseRedirect('/topic/322/')
#     elif vanity == 'streetcarcity2050':
#         return HttpResponseRedirect('/topic/399/')
#     elif vanity == 'urbanfuturessurvey':
#         return HttpResponseRedirect('/topic/323/')
#     elif vanity == 'vancouverhousing':
#         return HttpResponseRedirect('/topic/205/')
#     elif vanity == 'vancouvertransportation':
#         return HttpResponseRedirect('/topic/204/')
#     elif vanity == 'vcrp':
#         return HttpResponseRedirect('/topic/279/')
#     elif vanity == 'vfrs':
#         return HttpResponseRedirect('/topic/206/')
#     elif vanity == 'vmm':
#         return HttpResponseRedirect('/topic/12/')
#     elif vanity == 'ubchousingplan':
#         return HttpResponseRedirect('/topic/380/')
#     elif vanity == 'newwestmtp':
#         return HttpResponseRedirect('/topic/531/')
#     elif vanity == 'urbanfuturessurvey-cn':
#         return HttpResponseRedirect('/topic/553/')
#     elif vanity == 'housingtaskforce':
#         return HttpResponseRedirect('/topic/362/')
#     elif vanity == 'northdelta':
#         return HttpResponseRedirect('/topic/561/')
#     elif vanity == 'letstalksitec':
#         return HttpResponseRedirect('/topic/566/')
#     elif vanity == 'aldergroveregionalpark':
#         return HttpResponseRedirect('/topic/583/')
#     elif vanity == 'fahrlands':
#         return HttpResponseRedirect('/topic/562/')
#     elif vanity == 'translinkbaseplan':
#         return HttpResponseRedirect('/topic/582/')
#     else:
#         redirects = Redirects.objects.filter(is_active=True)
#         urls = []
#         for i in redirects:
#             urls.append(i.url)
#         if vanity in urls:
#             topic = Redirects.objects.get(url=vanity)
#             return HttpResponseRedirect(topic.topic.get_absolute_url())
#         else:       
#             raise Http404

# def copyPolygon(request, origin, dest):
#     if request.META['REMOTE_ADDR'] in ALLOWED_IPS:
#         orig = Topic.objects.get(id=origin)
#         new = Topic.objects.get(id=dest)
#         orig_polys = TopicPoly.objects.filter(topic=orig)
#         try:
#             for poly in orig_polys:
#                 new_poly = TopicPoly()
#                 new_poly.area_of_interest = poly.area_of_interest
#                 new_poly.style = poly.style
#                 new_poly.label = poly.label
#                 new_poly.topic = new
#                 new_poly.save()
#         except Exception as e:
#             print e
#             raise Http404
    
#         return HttpResponseRedirect(new.get_absolute_url())
    
#     else:
#         raise Http404

# @csrf_exempt        
# def fb(request):
#     return HttpResponseRedirect('/')

# @cross_domain_ajax
# @csrf_exempt
# def get_user_json(request):

#     msg = Msg()

#     all_users = User.objects.all()
#     users = []
#     unique = request.REQUEST.get('unique','')
#     broken = 0

#     for i in all_users:
#         if unique <> '':
#             date = datetime.date(2011,10,6)
#             if date <> i.date_joined.date():
#                 try:
#                     user = {}
#                     ctime = int(i.date_joined.strftime("%s"))
#                     user['created'] = ctime
#                     users.append(user)
#                 except:
#                     user = {}
#                     ctime = int(i.date_joined.strftime("%s")/1000)
#                     user['created'] = ctime
#                     users.append(user)
#             else:
#                 broken+=1
#         else:
#             places = Place.objects.filter(profile=i.get_profile())
#             for p in places:
#                 try:
#                     user = {}
#                     ctime = int(i.date_joined.strftime("%s"))*1000
#                     user['created'] = ctime
#                     user['lat'] = p.location[1]
#                     user['long'] = p.location[0]
#                     users.append(user)
#                 except:
#                     user = {}
#                     ctime = int(float(i.date_joined.strftime("%s"))/1000)*1000
#                     user['created'] = ctime
#                     user['lat'] = p.location[1]
#                     user['long'] = p.location[0]
#                     users.append(user)
        
#     msg.data['users'] = users
#     msg.data['broken'] = broken

#     return msg.toResponse()
    
# def get_signup_times(request):
#     if request.user.is_staff:
#         return render_to_response("signups.html", {}, context_instance=RequestContext(request))
#     else:
#         raise Http404

# def growth_map(request, region):
    
#     if region == "vancouver":
        
#         return render_to_response("growth_maps/vancouver.html", {'newb':'hi'}, context_instance=RequestContext(request))
#     else:
#         raise Http404
