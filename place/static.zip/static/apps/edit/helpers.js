function getVideoID(url) {

    var getLocation = function(href) {
        var l = document.createElement("a");
        l.href = href;
        return l;
    };

    youtube_hostnames = [
        'youtu.be',
        'youtube.com',
        'www.youtu.be',
        'www.youtube.com',
    ]
    vimeo_hostnames = [
        'vimeo.com',
        'www.vimeo.com'
    ]

    o = getLocation(url);
    hostname = o.hostname.toLowerCase()
    video_id = false;

    if (_.contains(youtube_hostnames, hostname)) {
        if (hostname.indexOf('youtu.be') != -1) {
            video_id = o.pathname.split('/')[1]
        } else {
            qs = parseQueryString(o.search)
            if (angular.isDefined(qs.v)) {
                video_id = qs.v;
            }
        }

        if (video_id) {
            return "https://img.youtube.com/vi/" + video_id + "/0.jpg"
        } else {
            return false;
        }
    } else if (_.contains(vimeo_hostnames, hostname) && angular.isDefined(o.pathname)) {
        path_parts = o.pathname.split("/");
        if (path_parts[1] == "video") {
            video_id = path_parts[2]
        } else {
            video_id = path_parts[1]
        }
        var thumbnail = null;
        $.ajax({
            type: 'GET',
            dataType: "json",
            url: "https://vimeo.com/api/v2/video/" + video_id + ".json",
            async: false,
            crossDomain: true,
            success: function(data) {
                thumbnail = data[0].thumbnail_large;
            }
        });
        return thumbnail;

    } else return false;

}

var parseQueryString = function(queryString) {
    var params = {}, queries, temp, i, l;
    queryString = queryString.replace("?", "");
    // Split into key/value pairs
    queries = queryString.split("&");

    // Convert the array of strings into an object
    for (i = 0, l = queries.length; i < l; i++) {
        temp = queries[i].split('=');
        params[temp[0]] = temp[1];
    }

    return params;
};