from itertools import izip, cycle
from django.conf import settings
from offers.core.models import Offer
from offers.helpers.lead.helpers import save_lead, EmailThread
from models import UserData


def save_user_data(data, request):
    lead = save_lead({
               'first_name':data['first_name'],
               'last_name':data['last_name'],
               'birth_date': '%(birthyear)s-%(birthmonth)s-%(birthday)s' % data,
               'email':data['email'],
               'state':data['state'],
               'source':request.build_absolute_uri().split('?')[0],
               'ip':request.META['REMOTE_ADDR']}) 
    try:
        raise Exception(str(lead.errors))
    except AttributeError:
        pass
    try:
        offer = Offer.objects.get(title=data['title'])
    except Offer.MultipleObjectsReturned:
        offer = Offer.objects.filter(title=data['title']).order_by('id')[0]
    user_data, newly_created = UserData.objects.get_or_create( 
                        lead = lead,
                        work_status = data['work_status'],
                        annual_income = data['annual_income'],
                        monthly = data['monthly'],
                        repayment = data['repayment'],
                        transfered = data['transfered'],
                        card_ownership_duration = data['card_ownership_duration'],
                        title = offer
                      )
    if newly_created:
        EmailThread(**{
            'email': data['email'],
            'sender':'beatmycard@creditcardcompare.com.au',
            'subject':'Your Best Credit Card Alternatives from Beat My Card!',
            'context':{'MEDIA_URL':settings.MEDIA_URL,
                       'result_url':request.build_absolute_uri() + '?details=' + xor_crypt(user_data.id)},
            'template':'beatcard/email.html'
        }).start()
    return user_data

def xor_crypt(data):
    key = 'beat+my+card+key'
    data = str(int(data)) if isinstance(data, long) else data
    return ''.join(chr(ord(x) ^ ord(y)) for (x, y) in izip(data, cycle(key)))

def get_better_cards(old_card_expense, cdata, excluded_issuers=[]):
    offers = Offer.on_site.exclude(category__in=excluded_issuers)
    if cdata['exclude_inactive']:
        '''Filter out inactive offers (as expected) and those that don't have outbound URL (as described in the specs)
        '''
        offers = Offer.sorted_offers.get_list(1, offers, 'id > 0 AND length(IFNULL(po.outbound_url,''))>0')
    else:
        offers = Offer.sorted_offers.get_list(1, offers, active_only=False)
        
    better_cards = []
    for offer in offers:
        all_meta = extract_rates(offer, float(cdata['transfered']), True)
        if not all_meta:
            continue # this card has very high rates, skip it
        bal = Card(all_meta['interest_rate'], 
                   all_meta['annual_fee'], 
                   all_meta['transfer_rate'],
                   all_meta['transfer_period'],
                   all_meta['intro_rate'],
                   all_meta['intro_period'],
                   monthly_expense=float(cdata['monthly']), 
                   repay_rate=float(cdata['repayment']),
                   transfered=float(cdata['transfered']),)
        value = bal.get_total_expense()
        if value <= old_card_expense:
            better_cards.append({'offer':offer, 'meta':value})
            offer.saved = old_card_expense - value
            offer.has_intro = all_meta['intro_period']
    return [x['offer'] for x in sorted(better_cards, key=lambda k: k['meta'])][:3] 

def extract_rates(offer, transfered, new_card=False):
    all_meta = {'interest_rate':'Purchase Rate', 
                'annual_fee':'Annual Fee', 
                'intro_rate':'Intro Purchase Rate',
                'intro_period':'Intro Purchase Period',
                'transfer_rate':'Balance Transfer Rate', 
                'transfer_period':'Balance Transfer Period'}
    for k, v in all_meta.iteritems():
        try:
            val = offer.meta_instances.get(meta_field__key=v).value
        except:
            if k=='intro_rate' or k=='intro_period':
                all_meta[k] = 0 # assume no intro rates
                continue
            else:
                val = '-'
        try:
            all_meta[k] = float(val)
        except ValueError:
            if new_card and (k=='interest_rate' or k=='annual_fee'):
                return 0 #assume a very high value
            elif new_card and k=='transfer_rate' and transfered>0:
                return 0 #assume a very high value when transfered amount > 0
            else:
                all_meta[k] = 0 #assume a very low value
    return all_meta

class Card:
    current_pb = 0
    current_period = 0
    table_stats = None
    
    def __init__(self,  purchase_rate, 
                        annual_fee, 
                        transfer_rate, 
                        transfer_period,
                        intro_rate,
                        intro_period,
                        monthly_expense=1000, 
                        onetime_expense=0,
                        repay_rate=2,
                        transfered=0,):
        self.table_stats = []
        
        self.purchase_rate = purchase_rate/100.0
        self.annual_fee = annual_fee
        self.transfer_rate = transfer_rate/100.0
        self.transfer_period = transfer_period
        self.intro_rate = intro_rate/100.0
        self.intro_period = intro_period
        self.monthly_expense = monthly_expense
        self.current_pb += onetime_expense
        self.monthly_repay_rate = repay_rate/100.0
        self.current_tb = transfered
        
    def go_next(self, previous_expense):
        if self.current_period <= self.intro_period: # ignored period 0 bec interest is 0 anyway
            interest = self.current_pb*self.intro_rate/12
        else:
            interest = self.current_pb*self.purchase_rate/12
            
        table_row = [self.current_period, self.current_pb, previous_expense, interest, \
                self.current_tb, (self.current_tb*self.transfer_rate/12 if self.current_period else 0),]
        
        current_pb = self.current_pb + previous_expense + interest
        current_tb = self.current_tb + (self.current_tb*self.transfer_rate/12 if self.current_period else 0)
        current_pb, current_tb = self.apply_repayment(current_pb, current_tb, previous_expense, table_row)
        
        self.table_stats.append(table_row)
        
        self.current_period += 1
        self.current_pb = current_pb
        self.current_tb = current_tb
        
    def apply_repayment(self, current_pb, current_tb, previous_expense, table_row):
        total_bill = self.current_pb + self.current_tb + previous_expense
        minimum_repayment = total_bill*self.monthly_repay_rate
        table_row.append(minimum_repayment)
        if self.current_period <= self.transfer_period and self.current_tb > 0:
            if self.current_period == self.transfer_period:
                current_pb += current_tb - minimum_repayment
                return current_pb, 0
            if current_tb >= minimum_repayment:
                return current_pb, current_tb - minimum_repayment
            elif current_tb < minimum_repayment:
                return current_pb - (minimum_repayment-current_tb), 0
        elif self.current_period > self.transfer_period or self.current_tb <= 0:        
            return current_pb-minimum_repayment, 0
        
    def print_stats(self):
        for row in self.table_stats:
            print '\t'.join(str(col) for col in row)
            
    def get_total_expense(self, bt_period=None, month=None):
        bt_period = int(bt_period or self.transfer_period)
        month = int(month or bt_period)
        if self.table_stats:
            pass
        else:
            for _p in range(bt_period + 1): # n months + initial month
                self.go_next(self.monthly_expense)
        total_repayment = sum(row[-1] for row in self.table_stats[:month])
        total_spent = sum(row[2] for row in self.table_stats[:month+1])
        try:
            pb = self.table_stats[month+1][1]
        except IndexError:
            pb = self.current_pb
        return pb + total_repayment + self.annual_fee - total_spent + self.table_stats[0][2] - self.table_stats[0][4]
