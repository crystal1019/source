'''
@author: chaol
'''

from django.template import Context, loader, RequestContext
from django.http import HttpResponse, Http404
from django.core.validators import email_re
import datetime, time
from models import *
from bellabustiere.shop.models import *
from django.core.cache import cache
from django.contrib.auth import authenticate
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout

from bellabustiere.userprofile.models import *
from bellabustiere.website.models import *
from django.http import HttpResponseRedirect
from bellabustiere import common
from django.conf import settings
from bellabustiere import helpers
from django.core.paginator import *
from bellabustiere.website.forms import *

from haystack.views import SearchView, search_view_factory
from haystack.forms import SearchForm, HighlightedSearchForm
from haystack.query import SearchQuerySet

#now 404 will redirect to home page because of wildkard redirect
def handler404(request):
    t = loader.get_template('404.html')
    c = RequestContext(request, common.commonDict({}, request))
    return HttpResponse(t.render(c))


def handler500(request):
    t = loader.get_template('500.html')
    c = RequestContext(request, common.commonDict({}, request))
    return HttpResponse(t.render(c))

def sizechart(request):
    t  = loader.get_template('sizechart.html')
    c = RequestContext(request, common.commonDict({},request))
    return HttpResponse(t.render(c))

def home(request):
    t = loader.get_template('index.html')
    
    jsbanner = FlashImage.objects.filter(sites__id=settings.SITE_ID,in_js=True).order_by('-priority')
    
    ads = PromoTile.objects.filter(active=True)[:3]
            
    #return HttpResponse(str(dir(getCategories()[0])))
    c = RequestContext(request,common.commonDict({"openpath": ["home"], 'jsbanner':jsbanner,'ads':ads}, request))
    #return HttpResponse(common.commonDict({"openpath": ["home"],}, request)["products"])
    #raise Exception({'coupon':coupon,'coupon2':validate,'dict':common.commonDict({"openpath": ["home"], }, request)})
    return HttpResponse(t.render(c))

def search(request):
    suggest = False
    form = SearchForm(request.GET, searchqueryset=SearchQuerySet().models(Product), load_all=False)
    sqs = SearchQuerySet().models(Product).autocomplete(content_auto=request.GET.get('q',''))
    rs = [x.pk for x in sqs]
    products = Product.objects.filter(id__in=rs).filter(price__gt=0, status__display_to_user=True, sites__id=settings.SITE_ID).distinct()
        
    rg = request.GET
    
    #sort
    sort = rg.get('sort','')
    products = helpers.sortProduct(products, sort)
    
    #filter
    filter_size = rg.get('size','')
    filter_color = rg.get('color','')
    filter_price = rg.get('price','')
    
    filter_clothes = rg.get('clothes','')
    filter_activity = rg.get('activity','')
    filter_designer = rg.get('designer','')
    
    products = helpers.filterProducts(products, filter_size, filter_color, filter_price, filter_clothes, filter_activity, filter_designer)

    #pagination
    offset = rg.get('page',1)
    showtype = rg.get('limit','')
    numberofshow = helpers.getPerPage(showtype)
    pg = int(offset)
    p = Paginator(products, numberofshow)
    page = p.page(pg)

    designers_nav = Brand.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False).order_by('name')
        
    categories = helpers.getTopCategory(products)
    
    t = loader.get_template('search.html')
    c = RequestContext(request,common.commonDict({

        
        'page':p,
        'pagenumber':pg,
        'currentpage':page,
        'query':request.GET.get('q',''),
        
        'categories':categories,
                      
        'allsizes': SizeGroup.objects.all(),
        'allstyles': StyleGroup.objects.all(),
        'allprices': sorted(settings.PRICE_FILTER_DICT.items(), key=lambda x:int(x[0])),
        
        'designers_index_nav':designers_nav,
        
        'filter_size':filter_size,
        'filter_color':filter_color,
        'filter_price':filter_price,
        'filter_clothes': filter_clothes,
        'filter_activity':filter_activity,
        'filter_designer':filter_designer,
        'filter_sort':sort,
        'filter_page':offset,
        'filter_limit':showtype,
                      
                      
        },request))
    return HttpResponse(t.render(c))

def robots(request):
    t = loader.get_template('robots.txt')
    c = Context()
    return HttpResponse(t.render(c), mimetype = 'text/plain')

def currencychange(request):
    currency = request.POST.get('currency','')
    if currency:
        request.session['currency'] = currency
        
    return HttpResponse(str({'status':'Error'}))

def is_valid_email(email):
    return True if email_re.match(email) else False

def subscribe(request):
    data = {"openpath": ["home"],}
    rp = request.POST
    if is_valid_email(rp.get("email")):
        try:
            o = User.objects.get(email=rp.get("email"))
            
            s,created = subscription_create(rp.get("email"), Profile.objects.get(user=o.id).wholesale,Profile.objects.get(user=o.id).member, ip=request.META["REMOTE_ADDR"])
            
            if created:
                data["error"] = 0
                data["message"] = "Thanks for subscribing to our newsletter."
            else:
                data["error"] = 1
                data["message"] = "There was an error, perhaps you're already subscribed?"
        except:
            s, created = subscription_create(rp.get("email"), False, False, ip=request.META["REMOTE_ADDR"])
            if created:
                data["error"] = 0
                data["message"] = "Thanks for subscribing to our newsletter."
            else:
                data["error"] = 1
                data["message"] = "There was an error, perhaps you're already subscribed?"
    else:
        data["error"] = 1
        data["message"] = "Please use a valid email address"

    return HttpResponse(simplejson.dumps(data), mimetype='application/javascript')

def coupon(request):
    rp = request.GET.copy()
    data = {}
    if rp:
        coupon = rp.get('coupon','')
        status = rp.get('status','')
        if status == 'true':
            validate = False
            coupons = Coupon.objects.get_coupon(coupon)
            
            validate = True if coupons else False
            if validate:
                order_id = request.session.get('order_id',None)
                if order_id:
                    order = Order.objects.get(id=order_id)
                    po = order.productorder_set.all()
                    cp = Coupon.objects.filter(codes=coupon)
                    for x in po:
                        x.price = x.product.getTaxFreePrice(x.quantity,request.user.is_active,coupon)
                        
                        use_coupon = helpers.check_productcoupon(x.product,cp,request.user.is_active)
                
                        x.coupon = coupon if use_coupon else None
                        x.save()
                request.session['coupon'] = coupon
                data['error'] = 0
                data['message'] = 'Congratulations! It is a valid coupon. Enjoy shopping!'
            else:
                data['error'] = 1
                data['message'] = 'There was an error, perhaps your coupon code is not correct or it is expired.'
        else:
            request.session['coupon'] = ''
            order_id = request.session.get('order_id',None)
            if order_id:
                order = Order.objects.get(id=order_id)
                po = order.productorder_set.all()
                cp = Coupon.objects.filter(codes=coupon)
                for x in po:
                    x.price = x.product.getTaxFreePrice(x.quantity,request.user.is_active,'')
                    
                    use_coupon = helpers.check_productcoupon(x.product,cp,request.user.is_active)
                
                    x.coupon = coupon if use_coupon else None
                    x.save()
            data['error'] = 3
            data['message'] = ''
    #raise Exception({'request':request.session['coupon']})
    return HttpResponse(str(data))

def catchall(request, path):
    try:
        document = MiscPage.objects.get(path=path, sites__id =settings.SITE_ID)
        group = document.group
        nav = MiscPage.objects.filter(status__display_to_user=True, sites__id=settings.SITE_ID,group=document.group)
        t = loader.get_template('catchall.html')
        msg = ''
        msg1 = ''
        form = ''
        form1 = ''
        allmedia = ''
        if document.is_subscribe:
            rp = request.POST.copy()
            try:
                rp['ip'] = request.META["HTTP_CF_CONNECTING_IP"] 
            except:
                rp['ip'] = request.META["REMOTE_ADDR"]
            
            if rp.get('subscribe-submit',''):
                email = rp.get('email','')
                thes = ''
                if email:
                    thes =Subscription.objects.filter(email=email).exclude(group__name__iexact = 'Retail')
                    thes = thes[0] if thes else ''
                
                form = SubscribeForm(rp,instance=thes) if thes else SubscribeForm(rp)
                if form.is_valid():
                    form.save()
                    msg = 'Thank you, you are successfully subscribed.'
                    form = SubscribeForm()
                    
            else:
                form = SubscribeForm()
                
        if document.is_media:
            allmedia = MediaUpload.objects.filter(publishdate__lte = datetime.datetime.now())
            
        
        c = RequestContext(request,common.commonDict({"openpath": ["home",group],"page": document,'current_meta':document, 'nav':nav, 'form':form, 'form1':form1, 'msg':msg, 'msg1':msg1, 'allmedia':allmedia}, request))
        return HttpResponse(t.render(c))
    except Exception, e:
        #added for url wildkard between old server and new server
        try:
            if path == 'favicon.ico':
                return HttpResponseRedirect('/media/favicon.ico')
        except:
            raise Http404
        
def about(request):
    
    try:
        document = MiscPage.objects.get(path="about.html", status__display_to_user=True)
        t = loader.get_template('catchall.html')
        c = RequestContext(request,common.commonDict({"openpath": ["about.html"],"document": document,}, request))
        return HttpResponse(t.render(c))
    except Exception, e:
        #TODO make 404
        raise Http404
        #return HttpResponse("Couldn't find the file you were looking for")
    
def readnotification(request):
    rp = request.GET.copy()
    id = rp.get('id',0)
    email = rp.get('email',0)
    es = EmailStatus.objects.filter(subscribe__id=id, email__id=email)
    if es:
        es = es[0]
        es.read = True
        es.save()
    return HttpResponseRedirect('/media/assets/right.png')

    
