import objects
import masterpage

class GlassdoorPost(masterpage.MasterPage):
	def parseRow(self, row):
		columns = row.split(',')
		columns_ = []
		i = 0
		while i < len(columns):
			col1 = columns[i]
			if col1[0] == '"':
				col2 = columns[i+1]
				if col2[len(col2) - 1] == '"':
					col = col1 + ',' + col2
					col = col.replace('"', '')
					i = i + 1
			else:
				col = col1
			columns_.append(col)
			self.response.out.write(col)
			self.response.out.write(' ||| ')
			i = i + 1
		self.response.out.write('<br/><br/><br/><br/>')
		return columns_		
		'''
		columns = []
		start = 0
		count = 0
		while start >= 0:
			if row[start] == '"':
				nextstart = row.find('"', start + 1)
				end = row.find(',', nextstart)
				if end == -1:
					column = row[(start+1):len(row)]			
				else:
					column = row[(start+1):(end-1)]
			else:
				end = row.find(',', start + 1)
				end2 = row.find('\r', start + 1)
				if end2 < end:
					end = end2
				if end == -1:
					column = row[start:len(row)]			
				else:
					column = row[start:end]		
			columns.append(column)
			start = end + 1
			self.response.out.write(column)
			self.response.out.write(' ||| ')
			self.response.out.write(str(start) + ' ' + str(end))
			count = count + 1
			if count > 10:
				self.response.out.write('ENDING NOW')
				break
		self.response.out.write('<br/><br/><br/><br/>')
		return columns
		'''
	def post(self):
		blob = self.request.get('upload')
		start = 0
		end = blob.find('\r', start + 1)
		while (end > 0):
			row = blob[start:end].strip()
			columns = self.parseRow(row)
			if len(columns) < 5:
				self.response.out.write(row)
				return
			attribute_id = columns[0].replace('http://www.careercup.com/page?pid=', '')		
			job_text = columns[1]
			job_url = columns[2]
			salary_text = columns[3]
			salary_url = columns[4]
			
			attribute = objects.Attribute.query(objects.Attribute.pretty_id == attribute_id).get()
			if attribute:
				attribute.glassdoor_job_url = job_url
				attribute.glassdoor_job_text = job_text
				attribute.glassdoor_salary_url = salary_url
				attribute.glassdoor_salary_text = salary_text
				attribute.put()
				self.response.out.write('Updated attribute with id: ' + attribute_id + ' and url ' + columns[0] + '<br/>')
			else:
				self.response.out.write('<strong>Could not find attribute with id: ' + attribute_id + ' and url ' + columns[0] + '</strong><br/>')
			start = end + 1
			end = blob.find('\r', start)
			#self.response.out.write(str(start) + ' ' + str(end))
			#break
			
	def get(self):
		self.pushPage({}, 'Load Data', 'html/glassdoor_post.html')   

