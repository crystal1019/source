from django.contrib.auth.models import User
from app.models import Recipe

f = open('recipes.txt', 'r')
contents = f.read()
f.close()

fs = contents.split('Recipe\n')
for f in fs:
    f = f.split('\n')
    fld_dict = {}
    for fld in f:
        fld = fld.split('#')
        if len(fld) == 2:
            fld[0] = fld[0].strip()
            fld[1] = fld[1].strip()
            if fld[0] != '' and fld[1] != '':
                if fld[0] == 'author':
                    fld[1] = User.objects.get(username = fld[1])
                fld_dict[fld[0]] = fld[1]

    if fld_dict != {}:
        f_obj = Recipe.objects.create(**fld_dict)
        f_obj.save()
