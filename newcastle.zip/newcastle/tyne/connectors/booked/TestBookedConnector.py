'''
Created on Sep 13, 2014

@author: dropslowly
'''

import json
import random
import string
import sys
from tyne.connectors.booked import BookedConnector

DEBUG = True

URL = 'http://localhost'
URL = 'http://dev-demo.appointment.works:8090'
URL = 'https://myhealthplanmarkets.appointment.works'

#blank or end with /
ORG_NAME = '' #'booked/'

USER = 'secret_admin'
PASSWORD = 'se08$$05cheeduh'

#USER = 'admin'
#PASSWORD = 'password'

def dbgprint(msg, isJson = False):
	if DEBUG:
		if isJson:
			print("DEBUG: ")
			print(json.dumps(msg, indent=2, sort_keys=True))
		else:
			print("DEBUG: ", msg)


if __name__ == '__main__':
	#code, url, jsonResult = bt.testScheduleSlots(1, startDateTime='2014-09-11' , endDateTime='2014-09-12', resourceId=2) #2014-09-23T00:00:00-0500

	#URL = 'https://newb.appointment.works'
	#URL = 'http://localhost'


	#USER = 'secret_admin'
	#PASSWORD = 'se08$$05cheeduh'

	### CONNECT ###
	bc= BookedConnector.BookedConnector(URL, ORG_NAME, USER, PASSWORD)
	bc.setSessionAuthHeaders()

	#sc, url, jr = bc.testScheduleSlots(4, startDateTime = "2014-10-01T00:00:00+0000", endDateTime="2014-11-01T00:00:00+0000", resourceId = 1)
	#dbgprint(jr, isJson=True)
	#sys.exit()

	runUsers = False #or True
	runReservations = False or True
	runResources = False #or True
	runSchedules = False #or True
	runGroups = False #or True
	
		
	### USERS ###
	if runUsers:
		"""
		#get user
		print('======= Testing get all users')
		users = bc.getUsers()
		print("USERS COUNT:", len(users['users']))
		for user in users['users']:
			print(user['firstName'], ';', user['id'])

		print('======= Testing get user by phone')
		users = bc.getUsers(phoneNumber='4082091918')
		for user in users['users']:
			print(user['firstName'], ';', user['id'])

		print('======= Testing get user by id')
		users = bc.getUsers(id=3)
		for user in users['users']:
			print(user['firstName'], ';', user['id'])

		print('======= Testing get invalid user')
		users = bc.getUsers(phoneNumber='43e')
		print("result from invalid:")
		print(users)
	"""
		#create user
		print('======= Testing create user')
		eUser = '{"emailAddress":"ccccc@cat.com", "language":"en_us",  "password":"eigcat","firstName":"test","lastName":"user","phone":"3330442022","timezone":"America/New_York","groups":["40"],"customAttributes":[{"attributeId":7,"attributeValue":"Wayne"},{"attributeId":6,"attributeValue":"3330442022"}],"userName":"3330442022--4242"}'
		username = ''.join(random.choice(string.ascii_uppercase) for i in range(8))
		phoneNum = ''.join(random.choice(string.digits) for i in range(10))
		newUser = '{"groups":[3,5], "userName":"%s",      "password":"eigcat",             "emailAddress":"%s@cat.com",                "firstName":"eig-group-custom",   "lastName":"eat",        "language":"en_us",  "timezone":"America/Chicago","phone":%s,"organization":"","position":"", "customAttributes":[{"attributeId":5,"attributeValue":"95129"}, {"attributeId":8,"attributeValue":"San Jose"}]}' % (username, username, phoneNum)
		nu =      '{"userName":"NOEHMBDD","password":"NOEHMBDD_4085551212","emailAddress":"NOEHMBDD@appointment.works","firstName":"Short","lastName":"Giraffe", "phoneNumber": "5056336874","language":"en_us",  "timezone":"America/Chicago"}'

		users = bc.createUser(eUser)
		for user in users['users']:
			print(user['firstName'], ';', user['id'])

		sys.exit(1)
		#create user
		print('======= Testing INVALID create user')
		username = ''.join(random.choice(string.ascii_uppercase) for i in range(8))
		phoneNum = ''.join(random.choice(string.digits) for i in range(10))
		newUser = '{"password":"eigcat",             "emailAddress":"%s@cat.com",                "firstName":"eig",   "lastName":"eat",        "language":"en_us",  "timezone":"America/Chicago","phone":%s,"organization":"","position":""}' % (username, phoneNum)
		users = bc.createUser(newUser)
		print("result from invalid:")
		print(users)

		#print(json.dumps(user, indent=2, sort_keys=True))

	### Resources ###
	if runResources:
		print('======= Testing get all resources')
		resources = bc.getResources()
		print("GET_RESOURCES:", resources)
		for resource in resources['resources']:
			print(resource['name'], ':', resource['resourceId'])

		print('======= Testing get resource by id')
		resources = bc.getResources(resourceId=2)
		print("GET_RESOURCE:", resources)
		for resource in resources['resources']:
			print(resource['name'], ':', resource['resourceId'])
	
		print('======= Testing get resource INVALID ')
		resources = bc.getResources(resourceId='abc')
		print("GET_RESOURCE:", resources)
		print("result from invalid:")
		print(resources)
		
		#print('======= Testing get resource availability')
		#startTime = dateutil.parser.parse("2014-08-2T13:00:00-0500") # 
		#startTime = None #datetime.now(tz.tzutc()) + relativedelta(days=+3)
		#endTime = None #startTime + relativedelta(days=+2)

	if runReservations:
		"""
		print('======= Testing get all reservations')
		reservations = bc.getReservations()
		print("GET_RESERVATIONS COUNT:", len(reservations['reservations']))
		for reservation in reservations['reservations']:
			print(reservation['title'], ':', reservation['startDate'], reservation['endDate'], reservation['userId'], reservation['referenceNumber'])
			#this is needed for the get specific reservation test
			resRefNumberForTest = reservation['referenceNumber']
			resUserIdForTest = reservation['userId']

		print('======= Testing get single reservation')
		#resRefNumberForTest = '546f85a2e3b4a828896395'
		reservations = bc.getReservations(referenceNumber=resRefNumberForTest)
		print("GET_RESERVATION:", reservations)
		for reservation in reservations['reservations']:
			print(reservation['title'], ':', reservation['startDate'], reservation['endDate'], reservation['userId'], reservation['referenceNumber'])


		print('======= Testing get single reservation from userId')
		#resRefNumberForTest = '546f85a2e3b4a828896395'
		reservations = bc.getReservations(userId=331)
		print("GET_RESERVATION:", reservations)
		for reservation in reservations['reservations']:
			print(reservation['title'], ':', reservation['startDate'], reservation['endDate'], reservation['userId'], reservation['referenceNumber'])


		print('======= Testing get next reservation')
		reservations = bc.getReservations(userId=4, nextOnly=True) #resUserIdForTest
		print("GET_RESERVATIONS:", reservations)
		for reservation in reservations['reservations']:
			if reservation:
				print(reservation['title'], ':', reservation['startDate'], reservation['endDate'], reservation['userId'], reservation['referenceNumber'])
		#print("Next res:", nextReservation)

		print('======= Testing create reservation')					                                                                                                                                                            #, "customAttributes":[{"attributeId":5,"attributeValue":     "95129"}]}'
		newResStr = '{"startDateTime":"2014-12-04T10:30:00-0400","endDateTime":"2014-12-04T11:00:00-0400","description":"BookedConnector","resourceId":"19","resources":["19"],"userId":"2858","title":"Connector Test"}'
		#newResStr = '{"startDateTime": "2014-10-20T14:00:00+0000", "userId": "9", "description": "outbound call", "endDateTime": "2014-10-20T15:00:00+0000", "resources": ["1"], "resourceId": "1", "title": "User Appointment"}'
		reservations = bc.createReservation(newResStr)
		for reservation in reservations['reservations']:
			reservationToDelete = reservation['referenceNumber']
			print(reservation['title'], ':', reservation['startDate'], reservation['endDate'], reservation['userId'], reservation['referenceNumber'])

		print('======= Testing create reservation DUPLICATE')
		reservations = bc.createReservation(newResStr)
		print("result from duplicate:")
		print(reservations)

		print('======= Testing create reservation INVALID')
		newResStr = '{"endDateTime":"2014-10-03T13:30:00+0000","description":"BookedConnector","resourceId":"2","resources":["2"],"userId":"6","title":"AppointmentWorks Demo"}'
		reservations = bc.createReservation(newResStr)
		print("result from invalid:")
		print(reservations)
		
		"""
		print('======= Testing create reservation next available with filter')
		resData = {}
		resData['participants'] = [3]
		#resData['startDateTime']="2014-12-19T10:00:00-0500"
		#resData['startDateTime']="2015-01-04"
		#resData['endDateTime']="2015-01-21"
		#filter for afternoon only
		filterList = []
		#filterList.append('startDateTime.hour >= 13')
		#filterList.append('startDateTime.weekday() == 3')

		reservations = bc.createReservationNextAvailable(94, [2], resData, filterList) #resources 1,3 are main offices
		for reservation in reservations['reservations']:
			print(reservation['title'], ':', reservation['startDate'], reservation['endDate'], reservation['userId'], reservation['referenceNumber'])

		"""
		print('======= Testing create reservation next available BAD USER')
		reservations = bc.createReservationNextAvailable('d', [1,3]) #resources 1,3 are main offices
		print("result from bad user")
		print(reservations)
		
		print('======= Testing create reservation next available BAD RESOURCE')
		reservations = bc.createReservationNextAvailable(6, ["nil"]) #resources 1,3 are main offices
		print("result from bad resource")
		print(reservations)
		
		print('======= Testing delete reservation; requires create to work')
		reservationToDelete= '5426e16c4c9fa794029873'
		result = bc.deleteReservation(reservationToDelete)
		dbgprint(result, isJson = True)
		print(result)

		print('======= Testing delete reservation that does not exist')
		#reservationToDelete= '5426e16c4c9fa794029873'
		result = bc.deleteReservation('doesnotexist')
		dbgprint(result, isJson = True)
		print(result)

		xx = bc.getOpenSlotsOnly([1])
		for resourceId in xx:
			for tgtDate in xx[resourceId]['dates']: #availList[resourceId]['dates'][2]['date']
				print("EEE", len(tgtDate['resources'][0]['slots']))
		pass
		print("*****************************")
		dbgprint(xx, isJson=True)
		"""
		
	if runSchedules:
		#https://myhealthplanmarkets.appointment.works/Web/Services/Schedules/2/Slots?resourceId=2&startDateTime=2015-01-01
		#https://mhpm.appointment.works/Web/Services/Schedules/1/Slots?startDateTime=2015-01-01&resourceId=2
		"""
		print('======= Testing get schedules')
		schedules = bc.getSchedules()
		for schedule in schedules['schedules']:
			print(schedule['name'], ':',schedule['id'])

		print('======= Testing get specific schedule')
		schedules = bc.getSchedules(id=1)
		for schedule in schedules['schedules']:
			print(schedule['name'], ':',schedule['id'])

		print('======= Testing get INVALID schedule')
		schedules = bc.getSchedules(id='a')
		print("result from invalid schedule")
		print(schedules)
		print('======= Testing open only schedules')
		schedules = bc.getSchedules(openOnly="true", resourceIds = '1,2,3,4')
		for schedule in schedules['schedules']:
			dbgprint(schedules['schedules'][schedule], isJson = True)

		"""
		
		print('======= Testing getAvailableTimes')
		times = bc.getAvailableTimes(resourceIds = '1,2,3,4', mngaft = 'true')
		for time in times:
			dbgprint(times)


	
	### GROUPS
	if runGroups:

		#get groups
		print('======= Testing get all groups')
		groups = bc.getGroups()
		print("GROUPS:", groups)
		for group in groups['groups']:
			print(group)


		print('======= Testing get group')
		group = bc.getGroup(3)
		print("GROUP:", group)

		print('======= Testing get user ===========================')
		user = bc.getUser(45)
		print("USER:", user)

		username = ''.join(random.choice(string.ascii_uppercase) for i in range(8))
		phoneNum = ''.join(random.choice(string.digits) for i in range(10))
		
		newUser = '{"userName":"%s",      "password":"eigcat",             "emailAddress":"%s@cat.com",                "firstName":"THISS",   "lastName":"GROUPPP",        "language":"en_us",  "timezone":"America/Chicago","phone":%s,"organization":"","position":"", "groups":[{"id":21}]}' % (username, username, phoneNum)
		nu =      '{"userName":"NOEHMBDD","password":"NOEHMBDD_4085551212","emailAddress":"NOEHMBDD@appointment.works","firstName":"Short","lastName":"Giraffe", "phoneNumber": "5056336874","language":"en_us",  "timezone":"America/Chicago"}'
			
		username = ''.join(random.choice(string.ascii_uppercase) for i in range(8)) + 'fff'
		phoneNum = ''.join(random.choice(string.digits) for i in range(10))
		newUser = '{"groups":[3,5], "userName":"%s",      "password":"eigcat",             "emailAddress":"%s@cat.com",                "firstName":"ZZZZ-group-custom",   "lastName":"eat",        "language":"en_us",  "timezone":"America/Chicago","phone":%s,"organization":"","position":"", "customAttributes":[{"attributeId":5,"attributeValue":"95129"}, {"attributeId":8,"attributeValue":"San Jose"}]}' % (username, username, phoneNum)
		nu =      '{"userName":"NOEHMBDD","password":"NOEHMBDD_4085551212","emailAddress":"NOEHMBDD@appointment.works","firstName":"Short","lastName":"Giraffe", "phoneNumber": "5056336874","language":"en_us",  "timezone":"America/Chicago"}'

		users = bc.createUser(newUser)

		for user in users['users']:
			print(user['firstName'], ';', user['id'])
