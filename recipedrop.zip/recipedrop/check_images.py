# -*- coding: utf-8 -*-#
#import os
import boto
from boto.s3.key import Key
from PIL import Image
from io import BytesIO

METAMIME = {'JPEG':{'Content-Type': 'image/jpeg'},
            'PNG': {'Content-Type': 'image/png'},
            '*Unknown*':{'Content-Type': 'application/octet-stream'},
            }

def check_contents_mime(b,contents):
    try:
        file = BytesIO(contents)
        im = Image.open(file)
        return im.format
    except IOError:
        return '*Unknown*'

def change_metadata(b, keyname):
    k = Key(b)
    k.key=keyname                       #"oshein@gmail.com/7FQV25JZWDOZNJR5.jpg"
    cont = k.get_contents_as_string()
    print "content len=", len(cont)
    if len(cont)==0 :
        return
    image_format = check_contents_mime(b, cont)
    print "format=",image_format
    if not image_format in ['JPEG','PNG','*Unknown*']:
        print "bad format", image_format
        exit(1)
    newmime = METAMIME[image_format]

    acp = k.get_acl()
    print "acp=",acp
    if not image_format in ['JPEG','PNG']:
        return
    k.set_acl('public-read')

    # Copy the key onto itself, preserving the ACL but changing the content-type
    # k.copy(k.bucket, k.name, preserve_acl=True, metadata={'Content-Type': 'image/jpeg'})

    k.copy(k.bucket, k.name, preserve_acl=True, metadata=newmime)
    key = b.lookup(keyname)
    print "old",k.content_type,"new",key.content_type
    

def load_bucket_list(b):
    l =  b.list()
    for no,k in zip(range(2030),l):
        keyname =  k.key
        print no,keyname
        if not '@' in keyname:
            continue
        change_metadata(b,keyname)
        print "-" * 40

if __name__ == '__main__':
#    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'settings')
#    from app import models
    c = boto.connect_s3()
    #print conn
    b = c.get_bucket('recipedrop')
    #main(b)
    load_bucket_list(b)
