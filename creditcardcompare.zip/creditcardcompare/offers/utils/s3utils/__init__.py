import os
from os.path import splitext
from django.core.files.base import File
from django.core.files.storage import get_storage_class
from storages.backends.s3boto import S3BotoStorage


class CachedS3BotoStorage(S3BotoStorage):
    """
    S3 storage backend that saves the files locally, too.
    """
    def __init__(self, *args, **kwargs):
        super(CachedS3BotoStorage, self).__init__(*args, **kwargs)
        self.local_storage = get_storage_class("compressor.storage.CompressorFileStorage")()

    def save(self, name, content):
        name = super(CachedS3BotoStorage, self).save(name, content)
        self.local_storage._save(name, content)
        return name
    
class StaticToS3Storage(S3BotoStorage):
    '''From Matt as described here:
    http://stackoverflow.com/questions/8688815/django-compressor-how-to-write-to-s3-read-from-cloudfront
    
    Requires django-storages that has "rewind=True" as implemented here:
    https://github.com/iserko/django-storages
    '''
    def __init__(self, *args, **kwargs):
        super(StaticToS3Storage, self).__init__(*args, **kwargs)
        self.local_storage = get_storage_class("compressor.storage.CompressorFileStorage")()
    
    def save(self, name, content):
        ext = splitext(name)[1] 
        parent_dir = name.split('/')[0] 
        if ext in ['.css', '.js'] and not parent_dir == 'admin': 
            self.local_storage._save(name, content)
            gzip = self.gzip
            self.gzip = False  # upload to S3 but don't compress
            filename = super(StaticToS3Storage, self).save(name, content)
            self.gzip = gzip  # revert to original value
        else:
            filename = super(StaticToS3Storage, self).save(name, content) 
            return filename


StaticS3BotoStorage = lambda: StaticToS3Storage(location='static')
MediaS3BotoStorage = lambda: S3BotoStorage(location='media')
CompressedS3BotoStorage = lambda: CachedS3BotoStorage(location='static')