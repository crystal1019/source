import re
import logging
import pprint
import opengraph

from lxml.html import fromstring, tostring
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class AllSaintsScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'allsaints.com'

    # def fetch_url(self):
    #     with open('mdata.html', 'r') as f:
    #         self.html = f.read()

    def parse_single_product(self, lxml, raw_data):
        # Product id
        sku = ""
        t = lxml.xpath('.//input[@name="prod_desc_id"]/@value')
        if len(t) > 0:
            sku = t[0]
        else:
            logger.debug('SKU nof found')
            return []

        title = ""
        t = lxml.xpath('.//h1[@class="name"]/text()')
        if len(t) > 0:
            title = t[0]
        else:
            logger.error('Title nof found')

        # Product price
        product_current_price = None
        t = lxml.xpath('.//span[@itemprop="price"]/text()')
        if len(t) > 0:
            text_price = t[0].strip()
            prices = re.findall(r'(\d+\.\d+)', text_price)
            if not prices:
                prices = re.findall(r'(\d+\,\d+)', text_price)
            prices  = [x.replace(",", ".") for x in prices]
            product_current_price = float(prices[len(prices) - 1])

        else:
            logger.error('Price nof found')

        # Product sizes
        product_sizes = []
        tl = lxml.xpath('.//div[@class="size_box_container"]')
        if len(tl) > 0:
            te = tl[0]
            tl = te.xpath('.//a[@class="size_box"]/text()')
            for te in tl:
                product_sizes.append(te)

        # Product colours
        product_colours = {}
        tl = lxml.xpath('.//div[@class="colour_swatch"]/div/a')
        for te in tl:
            name = te.get('title')
            img = te.get('img')
            colour_image = ""
            cl = te.xpath('.//img/@src')
            if cl:
                colour_image = cl[0]
            product_colours[name] = colour_image

        # Product images
        tl = lxml.xpath('.//div[@class="product_image"]/a')
        images = []
        for te in tl:
            omo = te.get('onmouseover')
            m = re.search(r'MM_swapImage\((.*),(.*),\'(.*)\',(.*)\)', omo)
            if m is not None:
                imgurl = m.group(3)
                if imgurl.startswith('//'):
                    imgurl = 'http:' + imgurl
                images.append(imgurl)

        # Product promos
        # !!! please send me url's with promo for this site!!!

        selections = []
        data_url = raw_data.get('url', '')
        data_store = raw_data.get('site_name', '')
        data_image = raw_data.get('image', '')

        if not product_colours:
            product_colours = ['Empty']
        if not product_sizes:
            product_sizes = ['Empty']

        for prod_size in product_sizes:
            for color in product_colours:
                data = {'title': title,
                        'current_price': {
                            'value': product_current_price
                        },
                        'url': data_url,
                        'store': data_store.lower(),
                        'image': data_image,
                        'images': images,
                        'local_id': sku,
                        'selections': {
                            'size': prod_size,
                            'color': color,
                        },
                        'promos': []
                }
                selections.append(data)
        return selections

    def parse_multi_part(self, lxml, raw_data):
        sku = ""
        t = lxml.xpath('.//form/div[@class="lookbook_prod_desc_id"]/text()')
        if len(t) > 0:
            sku = t[0]
        else:
            logger.debug('SKU nof found')
            return []

        title = ""
        t = lxml.xpath('.//div[@class="product_options"]/a/text()')
        if t:
            title = t[0]

        price = ""
        t = lxml.xpath('.//div[@class="product_options"]/p[@class="look_price"]/text()')
        if t:
            text_price = t[0].strip()
            prices = re.findall(r'(\d+\.\d+)', text_price)
            product_current_price = float(prices[len(prices) - 1])

        sizes = lxml.xpath('.//div[@class="sizes clear"]/select/option/text()')

        images = lxml.xpath('.//form/a/img/@src')
        if images:
            image = images[0]

        selections = []
        data_url = raw_data.get('url', '')
        data_store = raw_data.get('site_name', '')
        data_image = raw_data.get('image', '')
        for prod_size in sizes:
            data = {'title': title,
                    'current_price': {
                        'value': product_current_price
                    },
                    'url': data_url,
                    'store': data_store,
                    'image': data_image,
                    'images': [],
                    'local_id': sku,
                    'selections': {
                        'size': prod_size,
                    },
                    'promos': []
            }
            selections.append(data)
        return selections

    def parse_multi_product(self, lxml, raw_data):
        tl = lxml.xpath('.//div[@class="productColumn"]/div[@id="detailColumn"]')
        if len(tl) == 1:
            return self.parse_single_product(tl[0], raw_data)

        #for multi
        tl = lxml.xpath('.//div[@class="products"]/div[@class="product"]')
        selections = []
        for te in tl:
            sel = self.parse_multi_part(te, raw_data)
            selections.extend(sel)
        return selections

    def parse(self):
        logger.debug('%s parse started' % AllSaintsScraper.get_domain())

        og = opengraph.OpenGraph(html=self.html)
        raw_data = dict([(k, v) for k, v in og.items()])

        lxml = fromstring(self.html)
        selections = self.parse_multi_product(lxml, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(AllSaintsScraper.get_domain(), self.url)
        return selections

if __name__ == '__main__':
    s = AllSaintsScraper()
    s.fetch_url()
    print "Result=",
    pprint.pprint(s.parse())
