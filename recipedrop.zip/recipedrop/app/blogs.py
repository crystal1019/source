from django.shortcuts import render_to_response, redirect
from django.template.loader import render_to_string
from django.http import HttpResponseServerError, HttpResponseForbidden, \
    HttpResponse
from django.contrib.auth.decorators import login_required
from django.core.urlresolvers import reverse
from django.template import RequestContext

from forms import BlogPostForm, BlogPostCommentForm
from util import success_json
from models import BlogPost, BlogPostComment

@login_required
def new_post(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        post_data['author'] = request.user.id
        post_data['access'] = request.user.profile.access

        form = BlogPostForm(post_data)
        if form.is_valid():
            blog_post = form.save()
            return redirect(reverse('user', args=[request.user.id]) + '#blog')
        else:
            # todo
            pass

    return HttpResponseServerError()
        
def post(request, pid, standalone = False):
    c = RequestContext(request)
    post = BlogPost.objects.get(id = pid)
    if post.can_see_post(request.user):
        c.update({
                'post': post,
                'comment_form': BlogPostCommentForm(),
                'standalone': standalone,
                'base': 'base.html' if standalone else 'embedded.html'
                })
        return render_to_response('blog/post.html', c)

    return HttpResponseForbidden()

def standalone_post(request, pid):
    return post(request, pid, True)

@login_required
def edit_post(request, pid):
    c = RequestContext(request)

    p = BlogPost.objects.get(id = pid)
    if p.author == request.user:

        c.update({
                'post': p
                })

        if request.method == 'POST':
            post_data = request.POST.copy()
            post_data['author'] = request.user.id
            post_data['access'] = p.access

            form = BlogPostForm(post_data, instance = p)
            if form.is_valid():
                blog_post = form.save()
                return post(request, pid)
            else:
                # todo
                pass

        else:
            form = BlogPostForm(instance = p)
            c.update({'form': form})
            return render_to_response('blog/edit.html', c)

    return HttpResponseForbidden()
            
@login_required
def delete_post(request, pid):
    p = BlogPost.objects.get(id = pid);
    if request.method == 'POST':
        if p.author == request.user:
            p.delete()
            return HttpResponse()
        else:
            return HttpResponseForbidden()
    else:
        return HttpResponseServerError()

@login_required
def new_comment(request, pid):
    if request.method== 'POST':
        p = BlogPost.objects.get(id = pid)
        if p.can_see_post(request.user):
            comment = BlogPostComment.objects.create(
                post = p,
                author = request.user,
                contents = request.POST['contents']
                )
            comment.save()

            c = RequestContext(request)
            c.update({'comment': comment, 'post': comment.post})
            return success_json({
                    'html': render_to_string('recipes/comment.html', c),
                    'comment': comment.id
                    })
        else:
            return HttpResponseForbidden()
    
    return HttpResponseServerError()

@login_required
def delete_comment(request):
    if request.method == 'POST':
        comment = BlogPostComment.objects.get(id = request.POST['comment'])
        if comment.author == request.user:
            comment.delete()
            return success_json({'comment': request.POST['comment']})
        return HttpResponseForbidden()
    return HttpResponseServerError()
