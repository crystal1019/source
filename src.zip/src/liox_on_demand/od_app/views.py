from django.shortcuts import render_to_response
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required

from django.contrib.sites.models import get_current_site
from django.views.decorators.http import require_http_methods
from django.views.decorators.http import require_POST
from django.http import HttpResponseRedirect, Http404, HttpResponseForbidden
from django.shortcuts import get_object_or_404
from django.conf import settings
from django.template import RequestContext

from django.utils.functional import wraps
from django.core.urlresolvers import reverse

from models import *
from forms import JobForm, AddFileForm


def co_brand(view):
    """
    This is a wrapper to retrieve the current organization.

    There is also functionality to pull the anonymous jobs out of session
    and associate them with the user if he just logged in.
    """
    def wrapper(request, *args, **kwargs):
        org = Organization.objects.get(site__id__exact=get_current_site(request).id)

        #The user has just logged in. Associate anonymous jobs in session to him.
        if request.user.is_authenticated() and 'anon_jobs' in request.session:
            for job_id in request.session['anon_jobs']:
                job = Job.objects.get(pk=job_id)
                job.owner = request.user
                job.save()
            request.session.pop('anon_jobs', None)

        return view(request, org, *args, **kwargs)

    return wraps(view)(wrapper)


@csrf_protect
def home(request, org):
    """Home Page"""

    job_types = JobType.objects.all()
    return render_to_response('home.html',
        {'media_root': settings.MEDIA_ROOT,
        'job_types': job_types,
        'org': org},
        context_instance=RequestContext(request))


@csrf_protect
def job_type(request, org, service_id):
    """The detail page for the Job Type"""

    job_type = get_object_or_404(JobType, pk=int(service_id))

    return render_to_response('job_type_detail.html',
        {'media_root': settings.MEDIA_ROOT,
        'job_type': job_type,
        'org': org},
        context_instance=RequestContext(request))


@csrf_protect
def add_job(request, org, service_id):
    """Functionality to display the form and process a new job post"""

    job_type = get_object_or_404(JobType, pk=int(service_id))

    if request.method == 'GET':
        form = JobForm()
    else:
        form = JobForm(request.POST,
            request.FILES,
            owner=request.user.is_authenticated() and request.user or None,
            job_type=job_type)
        if form.is_valid():
            job = form.save()
            if not request.user.is_authenticated():
                if 'anon_jobs' in request.session:
                    request.session['anon_jobs'].append(job.id)
                else:
                    request.session['anon_jobs'] = [job.id, ]

            return HttpResponseRedirect(reverse('add_job_confirm', args=[job.id]))

    return render_to_response('add_job.html',
        {'media_root': settings.MEDIA_ROOT,
        'job_type': job_type,
        'form': form,
        'org': org},
        context_instance=RequestContext(request))


@csrf_protect
def add_job_confirm(request, org, job_id):
    """Step to review the job details and submit for quote."""

    job = get_object_or_404(Job, pk=int(job_id))
    if request.method == 'GET':

        file_form = AddFileForm()

        return render_to_response('add_job_confirm.html',
            {'media_root': settings.MEDIA_ROOT,
            'job': job,
            'file_form': file_form,
            'org': org},
            context_instance=RequestContext(request))
    else:
        if request.user.is_authenticated():
            if job.status == 0:
                job.status = 1
                job.save()
            return HttpResponseRedirect(reverse('add_job_thanks', args=[job.id]))
        else:
            return HttpResponseRedirect(reverse('login') + '?next=' + request.get_full_path())


@csrf_protect
def add_job_thanks(request, org, job_id):
    """Thank you page after user has submitted his quote"""

    job = get_object_or_404(Job, pk=int(job_id))

    return render_to_response('add_job_thanks.html',
            {'media_root': settings.MEDIA_ROOT,
            'job': job,
            'org': org},
            context_instance=RequestContext(request))


@require_POST
@csrf_protect
def add_file(request, org, job_id):
    """Adds a new file to a job.  Used in the 'add more files functionality.'"""

    job = get_object_or_404(Job, pk=int(job_id))
    form = AddFileForm(request.POST, request.FILES, job=job)
    if form.is_valid():
        form.save()

    return HttpResponseRedirect(reverse('add_job_confirm', args=[job.id]))


@login_required
def my_jobs(request, org):
    """
    A page that shows the users open and completed jobs.
    """

    my_jobs = Job.objects.filter(owner=request.user)

    return render_to_response('my_jobs.html',
            {'media_root': settings.MEDIA_ROOT,
            'my_jobs': my_jobs,
            'org': org},
            context_instance=RequestContext(request))


@login_required
def job_detail(request, org, job_id):
    """
    Page to view job details.

    We will probably send users here from notification emails.
    """

    job = get_object_or_404(Job, pk=int(job_id), owner=request.user)

    return render_to_response('job_detail.html',
            {'media_root': settings.MEDIA_ROOT,
            'job': job,
            'org': org},
            context_instance=RequestContext(request))

#def forgotPassword(request):
#    if request.POST:
#        email=request.POST.get("email")
#        print email
#        user = UniversityDetails.objects.get(email=email)
#        send_mail("Your PW", user.password, "admin@example.com", [email])
#        print user
#        if(not user):
#            print "No user"
#            return render_to_response("forgotPassword.html")
#        else:
#            return render_to_response("passwordRecovery.html")
#    return render_to_response('forgotPassword.html')