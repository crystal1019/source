import os
import re
from google.appengine.ext.webapp import template

import webapp2

from google.appengine.ext import webapp
from google.appengine.ext.webapp import util

import mainpage
import glassdoor_post
import subscribe
import unsubscribe
import mergeattributes
import thankyou
import activity
import flagquestion
import notifications
import flagcomment
import flagforum
import categorylist
import viewsalary
import flagsalary
import reviewflagged
import profilesnippet
import clearcache
import addquestion
import questionsingle
import masterpage
import addforum
import forumlist
import sitemap
import forumsingle
import videoframe
import usersingle
import edituser
import vote
import page
import submitvote	
import addcomment
import rss
import staticpage
import robots
import addsalary
import bulkquestionedit
import editcomment
import makeadmin
import logging
import questionthread
import reportduplicate
import confirmduplicate
import refreshcounts
import editattribute
import addfavorite
import favorites
import refreshrankings
import editavatar

import utils

webapp.template.register_template_library('utils.filters')

class CanonicalRedirectHandler(webapp.RequestHandler):
	def get(self,path):
		new_url = path #"http://www.careercup.com" + os.environ['PATH_INFO'] + '?' + os.environ['QUERY_STRING']
		self.redirect(new_url, True)
		
def handle_404(request, response, exception):
	logging.exception(exception)
	path = os.path.join(os.path.dirname(__file__), 'html/404.html')
	html = template.render(path, {})
	response.out.write(html) 
	response.set_status(404)		

class DownSiteHandler(masterpage.MasterPage):
	def get(self):
		self.response.out.write(self.getBody({}, 'html/down.html')) 	        				
	
#logging.getLogger().setLevel(logging.DEBUG)	
	
'''if 'HTTP_HOST' in os.environ:
	hostname = os.environ['HTTP_HOST']
else:
	hostname = 'localhost'
if 'localhost' in hostname:
	is_production = False
else:
	is_production = True
m = 'www'
if is_production:
	m = re.match('www', hostname)
elif not is_production:
	m = 'www'
if is_production and not m:
	app = webapp.WSGIApplication([('(.*)', CanonicalRedirectHandler),], False)
else:'''
app = webapp2.WSGIApplication([
		('/add', addquestion.AddQuestion),
		('/question', questionsingle.ViewQuestionSingle),
		('/profilesnippet', profilesnippet.ProfileSnippet),
		('/categories', categorylist.ViewCategoryList), 
		('/editcomment', editcomment.EditComment), 
		('/addforum', addforum.AddForum), 										
		('/forum', forumlist.ViewForumList),									
		('/forumpost', forumsingle.ViewForumSingle), 								  
		('/user', usersingle.ViewUserSingle),								   
		('/edituser', edituser.EditUser), 								
		('/thankyou', thankyou.ThankYou),										
		('/page', page.ViewPage), 
		('/addcomment', addcomment.AddComment),
		('/editavatar', editavatar.EditAvatar),
		('/notifications', notifications.Notifications),
		('/submitvote', submitvote.SubmitVote),	
		('/glassdoor_post', glassdoor_post.GlassdoorPost),
		('/flagquestion', flagquestion.FlagQuestion),
		('/flagcomment', flagcomment.FlagComment),
		('/flagforum', flagforum.FlagForum),
		('/refreshrankings', refreshrankings.RefreshRankings),
		('/editattribute', editattribute.EditAttribute),
		('/addfavorite', addfavorite.AddFavorite),		
		('/followed', favorites.Favorites),					 							
		('/salary', addsalary.AddSalary),	
		('/viewsalary', viewsalary.ViewSalary),	
		('/flagsalary', flagsalary.FlagSalary),							
		('/questionthread', questionthread.ViewQuestionThread),															
		('/vote', vote.Vote),				
		('/subscribe', subscribe.Subscribe),
		('/rss.xml', rss.ViewRss),
		('/sitemap.xml', sitemap.SiteMap),										
		('/makeadmin', makeadmin.MakeAdmin),						
		('/reportduplicate', reportduplicate.ReportDuplicate), 
		('/confirmduplicate', confirmduplicate.ConfirmDuplicate), 
		('/reviewflagged', reviewflagged.ReviewFlagged), 
		('/activity', activity.Activity), 										
		('/bulkquestionedit', bulkquestionedit.BulkQuestionEdit), 		 
		('/refreshcounts', refreshcounts.RefreshCounts),		
		('/mergeattributes', mergeattributes.MergeAttributes),
		('/robots.txt', robots.Robots),
		('/chatroomthings', staticpage.StaticPage),				
		('/video', staticpage.StaticPage),										
		('/book', staticpage.StaticPage),	
		('/interview', staticpage.StaticPage),
		('/videoframe', videoframe.VideoFrame),
		('/resumereview', staticpage.StaticPage),
		('/ctciapp', staticpage.StaticPage),
		('/careercup_book_solutions', staticpage.StaticPage),		
		('/resources', staticpage.StaticPage),
		('/googleresume', staticpage.StaticPage),
		('/resume', staticpage.StaticPage),										
		('/wiserprofile', staticpage.StaticPage),	
		('/about', staticpage.StaticPage),															
		('/helpcareercup', staticpage.StaticPage), 																							
		('/sendmoney', staticpage.StaticPage),
		('/clearcache', clearcache.ClearCache),	
		('/unsubscribe', unsubscribe.Unsubscribe),	
		('/', mainpage.MainPage)],
	   debug=True)
	
app.error_handlers[404] = handle_404	
#util.run_wsgi_app(application)
