import difflib
import logging
from django.core.management.base import BaseCommand
from offers.core.models import Offer


logging = logging.getLogger('django')

class Command(BaseCommand):
    def handle(self, *args, **options):
        result = []
        offers = list(Offer.objects.filter(category__slug='credit-cards'))
        for o1 in offers:
            print 'Checking %s' % o1.title.encode("ascii", "ignore")
            offers.remove(o1)
            for o2 in offers:
                score = 0
                if o1.is_active: score += 1
                if o2.is_active: score += 1
                if score > 1:
                    continue
                ratio = difflib.SequenceMatcher(None, o1.title, o2.title).ratio()
                s = 'Ratio is %s for \n%s\n%s\n' % (ratio, o1.title, o2.title)
                result.append(s)
        result.sort()
        for r in result:
            for line in r.split('\n'):
                logging.info(line)