from classes import Student

DEFAULT_DATA_FORMAT = "%Y-%M-%d"
GREETING_MESSAGE = 'welcome to the %s University' % (Student.UNIVERSITY,)