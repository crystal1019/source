
# all of your evolution scripts, mapping the from_version and to_version to a list if sql commands
_evolutions = [
    [('fv1:8562088241036945259','fv1:-8932500134409554997'), # generated 2012-05-04 09:53:47.062321
        "ALTER TABLE `service_servicepage` ADD COLUMN `tooltip` longtext;",
        "ALTER TABLE `service_servicepage` ADD COLUMN `tooltip_image` varchar(100);",
    ],
    [('fv1:-8932500134409554997','fv1:8023804308133956440'), # generated 2012-05-04 10:18:10.866045
        "ALTER TABLE `service_servicepage` ADD COLUMN `tooltip_class_name` varchar(255);",
    ],
] # don't delete this comment! ## _evolutions_end ##
