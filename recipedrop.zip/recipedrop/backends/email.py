import boto

from django.conf import settings
from django.core.mail.backends.base import BaseEmailBackend

class SESEmailBackend(BaseEmailBackend):

    def __init__(self, **kwargs):
        self.conn = None

    def open(self):
        if settings.LIVE:
            self.conn = boto.connect_ses()

    def send_messages(self, msgs):
        if not self.conn:
            self.open()
        # To do: handle attachments, headers, errors, etc.
        for m in msgs:
            self.send_email(m.from_email, m.subject, m.body, m.to)
        return len(msgs)

    def send_email(self, from_addr, subject, body, to_addr, fmt = 'html'):
        if settings.LIVE:
            self.conn.send_email(from_addr, subject, body, to_addr, format = fmt)
