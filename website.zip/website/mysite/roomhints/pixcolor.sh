#!/bin/sh


HEX=$1
FILE=$2

convert -size 1x1 xc:#$HEX $FILE 2>&1
