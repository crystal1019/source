from django.contrib.auth.models import User
from app.models import Profile

f = open('profiles.txt', 'r')
contents = f.read()
f.close()

profiles = contents.split('Profile\n')
for p in profiles:
    p = p.split('\n')
    fld_dict = {}
    for fld in p:
        fld = fld.split('#')
        if len(fld) == 2:
            fld[0] = fld[0].strip()
            fld[1] = fld[1].strip()
            if fld[0] != '' and fld[1] != '':
                if fld[0] == 'user':
                    fld[1] = User.objects.get(username = fld[1])
                fld_dict[fld[0]] = fld[1]

    if fld_dict != {}:
        p_obj = Profile.objects.create(**fld_dict)
        p_obj.save()
