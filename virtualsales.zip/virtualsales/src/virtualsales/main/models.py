"""
  copyright 2014 Seth Black
"""

from django.db import models
from datetime import datetime
from django.contrib.auth.models import User

def auto_now():
    return datetime.now()

class Campaign(models.Model):
    hash_value = models.CharField(max_length=48, db_index=True)
    owner = models.ForeignKey(User, db_index=True)
    name = models.CharField(max_length=72)
    company = models.CharField(max_length=72)
    packet = models.FileField(upload_to='packets')
    support_number = models.CharField(max_length=15)
    handoff_number = models.CharField(max_length=15)
    created = models.DateTimeField(auto_now_add=True, default=auto_now)
    script = models.TextField()

    def __unicode__(self):
        return self.hash_value

class List(models.Model):
    owner = models.ForeignKey(User, db_index=True)
    campaign = models.ForeignKey(Campaign, db_index=True)
    upload_file = models.FileField(upload_to='lists')
    created = models.DateTimeField(auto_now_add=True, default=auto_now)

class ListNumber(models.Model):
    parent_list = models.ForeignKey(List, db_index=True)
    phone_number = models.CharField(max_length=15)
    name = models.CharField(max_length=128)
    extra = models.TextField()

    def __unicode__(self):
        return self.phone_number

class CallSchedule(models.Model):
    caller = models.ForeignKey(User, db_index=True)
    list_number = models.ForeignKey(ListNumber, db_index=True)
    begin_time = models.DateTimeField()
    end_time = models.DateTimeField()
    caller_type = models.CharField(max_length=24)
    script_used = models.TextField()

    def __unicode__(self):
        return "%s %s" % (caller.username, list_number.phone_number)

class CallNotes(models.Model):
    call_schedule = models.ForeignKey(CallSchedule, db_index=True)
    user = models.ForeignKey(User, db_index=True)
    time = models.DateTimeField(auto_now_add=True, default=auto_now)
    note = models.TextField()