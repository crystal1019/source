'''
@author: chaol
'''

from django.template import Context, loader, RequestContext
from django.http import HttpResponse, HttpResponseRedirect, HttpResponsePermanentRedirect
import datetime, time, math
from models import *
from django.db import connection

import pprint, hashlib

from tagging.models import *

from django.core.cache import cache
from django.core.paginator import *
from django.contrib.auth import authenticate
from django.contrib.auth import login as _login
from django.contrib.auth import logout as _logout

from django.contrib.auth.models import AnonymousUser

from django.conf import settings

from bellabustiere import common

from bellabustiere.userprofile.models import *

from django.core.paginator import Paginator

from forms import *

from django.contrib.sites.models import Site
from django.db.models import Count
from bellabustiere.website.models import SpammerList

from haystack.views import SearchView, search_view_factory
from haystack.forms import SearchForm, HighlightedSearchForm
from haystack.query import SearchQuerySet

def home(request, category='all',offset=1):
    t = loader.get_template('blog_index.html')
    offset = int(offset)
    perpage = settings.BLOG_POSTS_PER_PAGE
    start = offset*perpage
    end = start+perpage
    
#    postcount = BlogPost.objects.select_related().filter(status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate").count()
    current_category = BlogCategory.objects.get(slug=category) if category != 'all' else ''
    
    
    blogposts = BlogPost.objects.select_related().filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate") if category == 'all' else BlogPost.objects.select_related().filter(sites__id=settings.SITE_ID,category__slug=category,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by("-publishdate")
    
    p = Paginator(blogposts, perpage)
    
    page = p.page(offset)
    
    all_tags = Tag.objects.usage_for_model(BlogPost, counts=True)
    all_tags.sort(key=lambda x:x.count, reverse=True)
    
    most_comment = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).annotate(count=Count('comment')).order_by('-count')[:8]
    most_viewed = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by('-viewed')[:8]
    
    #return HttpResponse("")
    c = RequestContext(request,common.commonDict({
        'blogposts': page.object_list,
        'blog_category':BlogCategory.objects.filter(sites__id=settings.SITE_ID,is_active=True).order_by('-priority'),
        'current_category':current_category,
        "openpath": ["blog"],
        "page": page,
        "current_meta":current_category,
        'all_tags':all_tags[:15],
        'most_comment':most_comment,
        'most_viewed':most_viewed,
    }, request))
    return HttpResponse(t.render(c))

def post(request, code):
    t = loader.get_template('blogpost.html')
    #return HttpResponse(str(dir(Product.objects.get(code=code))))
    blogpost = BlogPost.objects.get(slug=code)
    
    
    try:
        blogpost.viewed = blogpost.viewed+1
        blogpost.save()
    except:
        pass
    rp = request.POST.copy()
    messages = []
    if rp:
        form = CommentForm(rp)
    else:
        form = CommentForm()
    if form.is_valid(): # All validation rules pass
        try:
            ip = request.META["HTTP_CF_CONNECTING_IP"] 
        except:
            ip = request.META["REMOTE_ADDR"]

        check_spammer = SpammerList.objects.filter(ip=ip)
        if not check_spammer:
            c = Comment(post=blogpost, name=form.cleaned_data["name"], email=form.cleaned_data["email"], comment=form.cleaned_data["comment"], status=CommentStatus.objects.get(status="Published"), ip=ip)    
            c.save()
            messages.append("Thanks for your comment")  
            form = CommentForm()
    
    
    all_tags = Tag.objects.usage_for_model(BlogPost, counts=True)
    all_tags.sort(key=lambda x:x.count, reverse=True)
    
    
    
    most_comment = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).annotate(count=Count('comment')).order_by('-count')[:8]
    most_viewed = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by('-viewed')[:8]
    c = RequestContext(request,common.commonDict({
        'blogpost': blogpost,
        'blog_category':BlogCategory.objects.filter(sites__id=settings.SITE_ID,is_active=True).order_by('-priority'),
        'form': form,
        'messages': messages,
        "openpath": ["blog"],
        "current_meta":blogpost,
        'all_tags':all_tags[:15],
        'most_comment':most_comment,
        'most_viewed':most_viewed,
    }, request))
    return HttpResponse(t.render(c))

def tag(request,tag):
    t = loader.get_template('blog_index.html')
    
    blog_posts = TaggedItem.objects.get_by_model(BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()),[tag])
    all_tags = Tag.objects.usage_for_model(BlogPost, counts=True)
    all_tags.sort(key=lambda x:x.count, reverse=True)    
    most_comment = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).annotate(count=Count('comment')).order_by('-count')[:8]
    most_viewed = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by('-viewed')[:8]
    
    c = RequestContext(request,common.commonDict({'path':'tag','blogposts':blog_posts,'blog_category':BlogCategory.objects.filter(sites__id=settings.SITE_ID,is_active=True).order_by('-priority'),'tag':tag,"openpath": ["blog"],'all_tags':all_tags[:15],'most_comment':most_comment,'most_viewed':most_viewed,},request))
    
    return HttpResponse(t.render(c))



def blogsearch(request):
    suggest = False
    form = SearchForm(request.GET, searchqueryset=SearchQuerySet().models(BlogPost), load_all=False)
    sqs = SearchQuerySet().models(BlogPost).autocomplete(content_auto=request.GET.get('q',''))
    rs = [x.pk for x in sqs]
    results = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).filter(id__in=rs)
    
    offset = request.GET.get('page','1')
    
    numberofshow = 6
    
    pg = int(offset)
    p = Paginator(results, numberofshow)
    page = p.page(pg)

    all_tags = Tag.objects.usage_for_model(BlogPost, counts=True)
    all_tags.sort(key=lambda x:x.count, reverse=True)
    
    
    
    most_comment = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).annotate(count=Count('comment')).order_by('-count')[:8]
    most_viewed = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by('-viewed')[:8]
    
    t = loader.get_template('blog_index.html')
    c = RequestContext(request,common.commonDict({
        'blogposts': page.object_list,
        'blog_category':BlogCategory.objects.filter(sites__id=settings.SITE_ID,is_active=True).order_by('-priority'),
        "openpath": ["blog"],
        "page": page,
        'all_tags':all_tags[:15],
        'most_comment':most_comment,
        'most_viewed':most_viewed,
        'path':'search',   
                                    
        },request))
    return HttpResponse(t.render(c))