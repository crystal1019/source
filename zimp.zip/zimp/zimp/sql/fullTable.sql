-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 05-Abr-2014 às 04:28
-- Versão do servidor: 5.6.15-log
-- PHP Version: 5.5.8

SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW IF EXISTS `vw_owner_types`, `vw_rel_list`, `vw_transactions`;
DROP TABLE IF EXISTS `brands`, `cards`, `malls`, `promotions`, `retailers`, `rules`, `transactions`, `userinfo`, `users`, `user_rule`, `value_log`, `vw_owner_types`, `vw_rel_list`, `vw_transactions`, `reserva`, `nearbytes`;
DROP PROCEDURE IF EXISTS `create_transaction`;
DROP PROCEDURE IF EXISTS `update_balance`;

CREATE PROCEDURE `update_balance`(
	IN in_type smallint,
	IN in_id varchar(128) CHARSET utf8,
	IN in_value decimal(14, 2)
)

BEGIN
	IF (in_type = 1) OR (in_type = 0) THEN
		UPDATE userinfo SET balance = balance + in_value WHERE id = in_id;
	ELSEIF (in_type = 2) THEN
		UPDATE brands SET balance = balance + in_value WHERE id = in_id;
	ELSEIF (in_type = 3) THEN
		UPDATE malls SET balance = balance + in_value WHERE id = in_id;
	ELSEIF (in_type = 4) THEN
		UPDATE retailers SET balance = balance + in_value WHERE id = in_id;
	END IF;
END;

CREATE PROCEDURE `create_transaction`(
	IN in_type tinyint(1),
	IN in_parent varchar(128) CHARSET utf8,
	IN in_from_id varchar(128) CHARSET utf8,
	IN in_to_id varchar(128) CHARSET utf8,
	IN in_value decimal(14,2),
	IN in_terminal varchar(128) CHARSET utf8,
	IN in_promotion varchar(128) CHARSET utf8
)

BEGIN
	-- O objetivo deste procedimento é validar e criar uma transação para o zimp, em caso de erros o rollback será executado
	DECLARE in_points decimal(14, 2);
	DECLARE default_factor decimal(5, 2) DEFAULT 0;
	DECLARE in_to_type tinyint(1);
	DECLARE in_from_type tinyint(1);
  DECLARE o_id varchar(128);

	IF (in_promotion = '') THEN
		SET in_promotion = NULL;
	END IF;

	IF (in_parent = '') THEN
		SET in_parent = NULL;
	END IF;

  SELECT `type` INTO in_to_type FROM vw_rel_list WHERE id = in_to_id;
  SELECT `type` INTO in_from_type FROM vw_rel_list WHERE id = in_from_id;

	IF (in_from_type = '') OR (in_from_id = '') OR (in_to_type = '') OR (in_to_id = '') OR (in_value = '') THEN
		SELECT 300 AS code, 'Transação não pode ser cadastrada!' AS message;

	-- Verificar se existe um ID para o from_type especificado
	ELSEIF (in_from_type IS NULL) THEN
		SELECT 311 AS code, 'Transação não pode ser cadastrada!' AS message;

	-- Verificar se existe um ID para o to_type especificado
	ELSEIF (in_to_type IS NULL) THEN
		SELECT 312 AS code, 'Transação não pode ser cadastrada!' AS message;

	-- Verificar se a promoção é válida
	ELSEIF (SELECT NOT exists(SELECT 1 FROM promotions WHERE id = in_promotion AND active = 1)) AND (in_promotion IS NOT NULL) AND (in_from_type <> 1) THEN
		SELECT 313 AS code, 'Transação não pode ser cadastrada!' AS message;

	-- Se o cred_type for de um usuário, ou seja, um usuário fizer uma compra com pontos, verifique se o mesmo tem saldo suficiente para tal
	ELSEIF (in_from_type = 1) AND ( (SELECT balance FROM userinfo WHERE id = in_from_id LIMIT 1) < in_value ) THEN
		SELECT 305 AS code, 'Usuário sem saldo suficiente!' AS message;

	ELSEIF (in_parent IS NOT NULL) AND (SELECT NOT exists(SELECT 1 FROM transactions WHERE id = in_parent)) THEN
		-- Transação não pode ser cancelada
		SELECT 301 AS code, 'Transação inexistente, não pode ser cancelada/reativada!' AS message;

	ELSEIF (in_type = 1) AND (in_parent IS NOT NULL) AND (SELECT NOT exists(SELECT 1 FROM transactions WHERE parent = in_parent AND "type" = 2)) THEN
		-- é necessário ter uma transação suspensa
		SELECT 304 AS code, 'Transação já está ativa' AS message;

	ELSEIF (in_type = 1) AND (in_parent IS NOT NULL) AND (SELECT NOT exists(SELECT 1 FROM transactions WHERE parent = in_parent AND "type" = 1)) THEN
		-- Transação já foi reativada
		SELECT 302 AS code, 'Transação já foi reativada!' AS message;

	ELSEIF (in_type = 2) AND (in_parent IS NULL) THEN
		-- Parent requerido para suspender
		SELECT 300 AS code, 'Transação não pode ser cadastrada!' AS message;

	ELSEIF (in_type = 2) AND (in_parent IS NOT NULL) AND (SELECT exists(SELECT 1 FROM transactions WHERE parent = in_parent AND "type" = 2)) THEN
		-- ja existe uma transação suspensa
		SELECT 303 AS code, 'Transação já foi cancelada' AS message;

	ELSE
		IF (in_type = 0) THEN

			SET in_parent = NULL;
			SET in_promotion = NULL;
			SET in_points = 1;
			SET in_value = 1;

		ELSE

			IF (in_from_type = 1) THEN
				-- Se o cred_type for de um usuário, o valor de pontos é o mesmo do valor de entrada
				SET in_points = in_value;

			ELSEIF (in_from_type <> 1) AND (in_promotion IS NULL) THEN
				-- Pega o Factor default do
				SET in_points = in_value * (SELECT factor FROM vw_rel_list WHERE id = in_from_id) / 100;

			ELSE
				-- Calcular a quantidade de pontos (https://github.com/ZimpFidelidade/api/issues/8)
				-- Obter fator DECIMAL de cálculo para a promoção
				SET in_points = in_value * (SELECT factor FROM promotions WHERE id = in_promotion) / 100;

			END IF;

		END IF;

		-- Inserir transação
    SET o_id = UUID();
		INSERT INTO transactions (id, type, from_type, from_id, to_type, to_id, value, points, terminal, promotion_id, parent)
		VALUES (o_id, in_type, in_from_type, in_from_id, in_to_type, in_to_id, in_value, in_points, in_terminal, in_promotion, in_parent);

		-- Atualizar os saldos
		CALL update_balance(in_from_type, in_from_id, -in_points);
		CALL update_balance(in_to_type, in_to_id, in_points);
		SELECT 0 AS code, 'Transação gravada com sucesso!' AS message, o_id as transaction_id;

	END IF;
END;

-- --------------------------------------------------------

--
-- Estrutura da tabela `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
	`id` varchar(128) NOT NULL,
	`cnpj` bigint(14) UNSIGNED ZEROFILL NOT NULL,
	`razao_social` varchar(200) NOT NULL,
	`nome_fantasia` varchar(200) NOT NULL,
	`ddd` int(2) NOT NULL,
	`phone` int(9) NOT NULL,
	`active` tinyint(1) NOT NULL DEFAULT '1',
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`balance` decimal(14,2) NOT NULL DEFAULT '0.00',
	`factor` decimal(5,2) NOT NULL DEFAULT '0.00',
	UNIQUE KEY `id` (`id`),
	UNIQUE KEY `cnpj` (`cnpj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `reserva`
--

CREATE TABLE IF NOT EXISTS `reserva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `fb` longtext,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cards`
--

CREATE TABLE IF NOT EXISTS `cards` (
	`userinfo_id` varchar(128) NOT NULL,
	`code` varchar(20) NOT NULL,
	`active` tinyint(1) NOT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`balance` decimal(14,2) NOT NULL DEFAULT '0.00',
	UNIQUE KEY `code` (`code`),
	UNIQUE KEY `userinfo_id` (`userinfo_id`,`code`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `malls`
--

CREATE TABLE IF NOT EXISTS `malls` (
	`id` varchar(128) NOT NULL,
	`cnpj` bigint(14) UNSIGNED ZEROFILL NOT NULL,
	`razao_social` varchar(200) NOT NULL,
	`nome_fantasia` varchar(200) NOT NULL,
	`ddd` int(2) NOT NULL,
	`phone` int(9) NOT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`balance` decimal(14,2) NOT NULL DEFAULT '0.00',
	`factor` decimal(5,2) NOT NULL DEFAULT '0.00',
	`active` tinyint(1) NOT NULL DEFAULT '1',
	UNIQUE KEY `cnpj` (`cnpj`),
	UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `promotions`
--

CREATE TABLE IF NOT EXISTS `promotions` (
	`id` varchar(128) NOT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`name` varchar(100) NOT NULL,
	`factor` decimal(5,2) NOT NULL DEFAULT '0.00',
	`owner_type` tinyint(1) NOT NULL,
	`owner_id` varchar(128) NOT NULL,
	`end_at` datetime DEFAULT NULL,
	`active` tinyint(1) NOT NULL DEFAULT '1',
	UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `retailers`
--

CREATE TABLE IF NOT EXISTS `retailers` (
	`id` varchar(128) NOT NULL,
	`cnpj` bigint(14) UNSIGNED ZEROFILL NOT NULL,
	`razao_social` varchar(200) NOT NULL,
	`nome_fantasia` varchar(200) NOT NULL,
	`ddd` int(2) NOT NULL,
	`phone` int(9) NOT NULL,
	`mall_id` varchar(128) DEFAULT NULL,
	`brand_id` varchar(128) NOT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`balance` decimal(14,2) NOT NULL DEFAULT '0.00',
	`factor` decimal(5,2) NOT NULL DEFAULT '0.00',
	`active` tinyint(1) NOT NULL DEFAULT '1',
	UNIQUE KEY `id` (`id`),
	UNIQUE KEY `cnpj` (`cnpj`),
	KEY `brand_id` (`brand_id`),
	KEY `mall_id` (`mall_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rules`
--

CREATE TABLE IF NOT EXISTS `rules` (
	`id` bigint(20) NOT NULL AUTO_INCREMENT,
	`name` varchar(50) NOT NULL,
	`opcode` tinyint(1) NOT NULL,
	`model` varchar(50) NOT NULL,
	`message` longtext,
	PRIMARY KEY (`id`),
	UNIQUE KEY `name_model` (`name`,`opcode`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
	`id` varchar(128) NOT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`parent` varchar(128) DEFAULT NULL,
	`type` tinyint(1) NOT NULL DEFAULT '1',
	`from_type` tinyint(1) NOT NULL,
	`from_id` varchar(128) NOT NULL,
	`to_type` tinyint(1) NOT NULL,
	`to_id` varchar(128) NOT NULL,
	`value` decimal(14,2) NOT NULL DEFAULT '0.00',
	`points` decimal(14,2) NOT NULL DEFAULT '0.00',
	`terminal` varchar(128) DEFAULT NULL,
	`promotion_id` varchar(128) DEFAULT NULL,
	UNIQUE KEY `id` (`id`),
	UNIQUE KEY `cred_debt_at` (`from_id`,`to_id`,`created_at`),
	KEY `parent` (`parent`),
	KEY `promotion_id_fk` (`promotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
	`id` varchar(128) NOT NULL,
	`name` varchar(100) NOT NULL,
	`cpf` bigint(11) UNSIGNED ZEROFILL NOT NULL,
	`ddd` int(2) DEFAULT NULL,
	`phone` int(9) DEFAULT NULL,
	`mobile` int(9) DEFAULT NULL,
	`gender` tinyint(1) DEFAULT NULL,
	`birth_date` date DEFAULT NULL,
	`street` varchar(200) DEFAULT NULL,
	`number` int(5) DEFAULT NULL,
	`complement` varchar(200) DEFAULT NULL,
	`city` varchar(200) DEFAULT NULL,
	`state` varchar(2) DEFAULT NULL,
	`country` varchar(3) NOT NULL DEFAULT 'BRA',
	`cep` varchar(8) DEFAULT NULL,
	`balance` decimal(14,2) NOT NULL DEFAULT '0.00',
	UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
	`id` varchar(128) NOT NULL,
	`email` varchar(150) NOT NULL,
	`password` varchar(32) NOT NULL,
	`userinfo_id` varchar(128) NOT NULL,
	`system` tinyint(1) NOT NULL,
	`role` tinyint(1) NOT NULL,
	`admin_of` varchar(128) DEFAULT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`active` tinyint(1) NOT NULL,
	UNIQUE KEY `id` (`id`),
	UNIQUE KEY `email` (`email`,`system`),
	KEY `system` (`system`),
	KEY `userinfo_id` (`userinfo_id`),
	KEY `admin_of` (`admin_of`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_rule`
--

CREATE TABLE IF NOT EXISTS `user_rule` (
	`role` tinyint(1) NOT NULL,
	`rule_id` bigint(20) NOT NULL,
	UNIQUE KEY `role` (`role`,`rule_id`),
	KEY `rules_id_fk` (`rule_id`),
	KEY `role_id` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `value_log`
--

CREATE TABLE IF NOT EXISTS `value_log` (
	`id` bigint(20) NOT NULL AUTO_INCREMENT,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`owner_type` tinyint(1) NOT NULL,
	`owner_id` varchar(128) NOT NULL,
	`old_value` decimal(14,2) NOT NULL DEFAULT '0.00',
	`new_value` decimal(14,2) NOT NULL DEFAULT '0.00',
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nearbytes`
--

CREATE TABLE IF NOT EXISTS `nearbytes` (
  `user_id` varchar(128) NOT NULL,
  `near_auth` int(10) NOT NULL,
  UNIQUE KEY `userID` (`user_id`),
  UNIQUE KEY `nearAuth` (`near_auth`),
  UNIQUE KEY `nearUser` (`user_id`,`near_auth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_owner_types`
--
CREATE TABLE IF NOT EXISTS `vw_owner_types` (
	`type` bigint(20),
	`name` varchar(9),
	`tablename` varchar(9)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_rel_list`
--
CREATE TABLE IF NOT EXISTS `vw_rel_list` (
	`type` tinyint(1),
	`id` varchar(128),
	`cpf` bigint(11),
	`cnpj` bigint(14),
	`name` varchar(200),
	`balance` decimal(5,2),
	`factor` decimal(5,2),
	`active` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_transactions`
--
CREATE TABLE IF NOT EXISTS `vw_transactions` (
	`id` varchar(128),
	`created_at` datetime,
	`type` tinyint(1),
	`terminal` varchar(128),
	`value` decimal(14,2),
	`points` decimal(10,2),
	`cred_name` varchar(200),
	`debt_name` varchar(200),
	`parent` varchar(128),
	`from_id` varchar(128),
	`to_id` varchar(128)
);
-- --------------------------------------------------------

--
-- Structure for view `vw_owner_types`
-- Owner types
--
DROP TABLE IF EXISTS `vw_owner_types`;
CREATE VIEW `vw_owner_types` AS
	SELECT 1 AS `type`,'Users' AS `name`,'userinfo' AS `tablename`
UNION ALL
	SELECT 2 AS `type`,'Brand' AS `Brand`,'brands' AS `brands`
UNION ALL
	SELECT 3 AS `type`,'Mall' AS `Mall`,'malls' AS `malls`
UNION ALL
	SELECT 4 AS `type`,'Retailers' AS `Retailers`,'retailers' AS `retailers`;

-- --------------------------------------------------------

--
-- Structure for view `vw_rel_list`
-- Related owner list
--
DROP TABLE IF EXISTS `vw_rel_list`;
CREATE VIEW `vw_rel_list` AS
	SELECT
		1 AS `type`,
		`userinfo`.`id` AS `id`,
		`userinfo`.`cpf` AS `cpf`,
		NULL AS `cnpj`,
		`userinfo`.`name` AS `name`,
		`userinfo`.`balance` AS `balance`,
		0.00 AS `factor`,
		1 AS `active`
	FROM `userinfo`
UNION ALL
	SELECT
		2 AS `type`,
		`brands`.`id` AS `id`,
		NULL AS `cpf`,
		`brands`.`cnpj` AS `cnpj`,
		`brands`.`nome_fantasia` AS `name`,
		`brands`.`balance` AS `balance`,
		`brands`.`factor` AS `factor`,
		`brands`.`active` AS `active`
	FROM `brands`
UNION ALL
	SELECT
		3 AS `type`,
		`malls`.`id` AS `id`,
		NULL AS `cpf`,
		`malls`.`cnpj` AS `cnpj`,
		`malls`.`nome_fantasia` AS `name`,
		`malls`.`balance` AS `balance`,
		`malls`.`factor` AS `factor`,
		`malls`.`active` AS `active`
	FROM `malls`
UNION ALL
	SELECT
		4 AS `type`,
		`retailers`.`id` AS `id`,
		NULL AS `cpf`,
		`retailers`.`cnpj` AS `cnpj`,
		`retailers`.`nome_fantasia` AS `name`,
		`retailers`.`balance` AS `balance`,
		`retailers`.`factor` AS `factor`,
		`retailers`.`active` AS `active`
	FROM `retailers`;

-- --------------------------------------------------------

--
-- Structure for view `vw_transactions`
-- Transactions report
--
DROP TABLE IF EXISTS `vw_transactions`;
CREATE VIEW `vw_transactions` AS
	SELECT
		`t`.`id` AS `id`,
		`t`.`created_at` AS `created_at`,
		`t`.`type` AS `type`,
		`t`.`terminal` AS `terminal`,
		`t`.`value` AS `value`,
		`t`.`points` AS `points`,
		`cr`.`name` AS `from_name`,
		`dr`.`name` AS `to_name`,
		`t`.`parent` AS `parent`,
		`t`.`from_id` AS `from_id`,
		`t`.`to_id` AS `to_id`
	FROM (
		(
			`transactions` `t`
			JOIN
			`vw_rel_list` `cr` ON(
				(
					(`cr`.`type` = `t`.`from_type`)
					AND
					(`cr`.`id` = `t`.`from_id`)
				)
			)
		)
		JOIN

		`vw_rel_list` `dr` ON(
			(
				(`dr`.`type` = `t`.`to_type`)
				AND
				(`dr`.`id` = `t`.`to_id`)
			)
		)
	);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cards`
--
ALTER TABLE `cards`
	ADD CONSTRAINT `card_userinfo_fk` FOREIGN KEY (`userinfo_id`) REFERENCES `userinfo` (`id`);

--
-- Limitadores para a tabela `retailers`
--
ALTER TABLE `retailers`
	ADD CONSTRAINT `shop_brand_fk` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
	ADD CONSTRAINT `shop_mall_fk` FOREIGN KEY (`mall_id`) REFERENCES `malls` (`id`);

--
-- Limitadores para a tabela `transactions`
--
ALTER TABLE `transactions`
	ADD CONSTRAINT `promotion_id_fk` FOREIGN KEY (`promotion_id`) REFERENCES `promotions` (`id`);

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
	ADD CONSTRAINT `user_info_fk` FOREIGN KEY (`userinfo_id`) REFERENCES `userinfo` (`id`);

--
-- Limitadores para a tabela `user_rule`
--
ALTER TABLE `user_rule`
	ADD CONSTRAINT `rules_id_fk` FOREIGN KEY (`rule_id`) REFERENCES `rules` (`id`);

--
-- Limitadores para a tabela `nearbytes`
--
ALTER TABLE `nearbytes`
	ADD CONSTRAINT `userinfo_fk` FOREIGN KEY (`user_id`) REFERENCES `userinfo` (`id`);

-- Rules
INSERT INTO `rules` (`id`, `name`, `opcode`, `model`) VALUES
	-- User
	(1, 'getUser', 4, 'User'),
	(2, 'inactiveUser', 3, 'User'),
	(3, 'updateUser', 3, 'User'),

	-- Admin
	(4, 'getRules', 4, 'Admin'),
	(5, 'addRule', 1, 'Admin'),
	(6, 'deleteRule', 2, 'Admin'),
	(7, 'addUserRule', 1, 'Admin'),
	(8, 'deleteUserRule', 2, 'Admin'),
	(9, 'registerUser', 1, 'Admin'),
	(10, 'updateUser', 1, 'Admin'),
	(11, 'deleteUser', 2, 'Test'),
	(39, 'changeValue', 2, 'Admin'),

	-- mall
	(12, 'getMall', 4, 'Mall'),
	(13, 'getMalls', 4, 'Mall'),
	(14, 'registerMall', 1, 'Mall'),
	(15, 'inactiveMall', 3, 'Mall'),
	(16, 'updateMall', 3, 'Mall'),
	(17, 'deleteMall', 2, 'Mall'),

	-- brand
	(18, 'getBrand', 4, 'Brand'),
	(19, 'getBrands', 4, 'Brand'),
	(20, 'registerBrand', 1, 'Brand'),
	(21, 'inactiveBrand', 3, 'Brand'),
	(22, 'updateBrand', 3, 'Brand'),
	(23, 'deleteBrand', 2, 'Brand'),

	-- retailer
	(24, 'getRetailer', 4, 'Retailer'),
	(25, 'getRetailers', 4, 'Retailer'),
	(26, 'registerRetailer', 1, 'Retailer'),
	(27, 'inactiveRetailer', 3, 'Retailer'),
	(28, 'updateRetailer', 3, 'Retailer'),
	(29, 'deleteRetailer', 2, 'Retailer'),

	-- promotion
	(30, 'getPromotion', 4, 'Promotion'),
	(31, 'getPromotions', 4, 'Promotion'),
	(32, 'registerPromotion', 1, 'Promotion'),
	(33, 'inactivePromotion', 3, 'Promotion'),
	(34, 'updatePromotion', 3, 'Promotion'),
	(35, 'deletePromotion', 2, 'Promotion'),

	-- transaction
	(36, 'getTransaction', 4, 'Transaction'),
	(37, 'registerTransaction', 1, 'Transaction'),

	-- report
	(38, 'getTransactions', 4, 'Report')
	;

-- Users Rules
INSERT INTO `user_rule` (`role`, `rule_id`) VALUES

	-- * `1` Zimp Admin
	(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14),
	(1, 15), (1, 16), (1, 17), (1, 18), (1, 19), (1, 20), (1, 21), (1, 22), (1, 23), (1, 24), (1, 25), (1, 26), (1, 27),
	(1, 28), (1, 29), (1, 30), (1, 31), (1, 32), (1, 33), (1, 34), (1, 35), (1, 36), (1, 37), (1, 38),

	-- * `2` Participante
	(2, 1),(2, 2),(2, 3),

	-- * `3` Lojista
	(3, 1), (3, 2),

	-- * `4` Dono de Shopping
	-- * `5` Dono de marca
	-- * `6` Funcionário de Loja
	(6, 1), (6, 2), (6, 36), (6, 37),
	-- * `7` Funcionário de Shopping
	(7, 1), (7, 2), (7, 36), (7, 37),
	-- * `8` Funcionário de Marca
	(8, 1), (8, 2), (8, 36), (8, 37);



SET FOREIGN_KEY_CHECKS = 1;


-- REPORTING / BI

CREATE VIEW vw_transactions_type AS
SELECT
0 as checkin_trans,
1 as buy_trans,
2 as share_trans,
3 as rescue_trans,
9 as cancel_trans;

