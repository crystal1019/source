from django.conf.urls import patterns, url


urlpatterns = patterns('offers.tools.lightbox.views',
    url(r'^$', 'show_lightbox', name='show-lightbox'),
)