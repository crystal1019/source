import json
import logging
import opengraph
import re
from bs4 import BeautifulSoup
from urlparse import urljoin
from base import BaseScraper
import leaf

class MoosejawScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'moosejaw.com'

    #def fetch_url(self):
    #   with open('test_data/moosejaw/glasses.html', 'r') as f:
    #      self.html = f.read()

    def make_float(self, value):
        return float(re.sub(r'[^\d\.]', '', value.strip()))

    def leaf_get_text(self, parser, selector):
        ''' Get tag text or return None'''
        tag = parser.get(selector)
        if tag:
            return tag.text.strip()
        else:
            return None

    def parse(self):
        items = list()
        item = dict()
        og_data = self.parse_opengraph()
        doc = leaf.parse(self.html)

        if 'title' not in og_data:
            return []

        # product url
        item_url = og_data['url']
        
        # Product Store Code
        item_store = 'moosejaw'
        
        # Product title
        item_title = self.leaf_get_text(doc, 'div.product-name span')

        # Color - size selectors
        regexp = r'availableItemsAttributeMapArray\[(\d+)\] =' + \
                    ' \'([^@]+)@([^\:]+):(\d+)'
        avail_list = re.findall(regexp, self.html)

        # shipping selectors
        regexp = r'itemShipDateArray\[(\d+)\] = \'(\d+)@([^\']+)'
        shipping_list = re.findall(regexp, self.html)

        # image server url
        image_path = re.search(r'imageServerPath = \'([^\']+)', self.html)
        if image_path:
            image_path = image_path.group(1)
        else:
            image_path = ''

        item_promo = self.leaf_get_text(doc,
                                'span[itemprop="offerdetails"] span.normal b')
        info_list = list()

        # get full list of additional images
        image_list = re.findall(r'replaceMainImageAltView\(\'([^\']+)',doc.html())
        image_list = list(set(image_list))

        for i in xrange(0,len(image_list)):
            image_list[i] = re.sub(r'\$product400\$',
                                   '$product1000$',
                                   image_list[i])
            image_list[i] = image_path + image_list[i]
        
        image_list.sort(reverse=True) # 'zm' indexes to begin

        #item['image_list'] = image_list

        # merge usefull information to one list
        for raw in avail_list:
            # price and local_id
            price = self.leaf_get_text(doc, 'div#' + raw[3]).split(':')
            price[4] = self.make_float(price[4])
            price[5] = self.make_float(price[5])

            # we get other images by this id
            image_id =  re.match(r'(\d+)x(\d+)_', price[1])
            if image_id:
                local_id = str(image_id.group(1))
                image_id = str(image_id.group(2))
            
            item = dict()
            item['url'] = item_url
            item['store'] = item_store
            item['title'] = item_title
            #'local_id': ' or '.join([raw[3],price[0],price[3],local_id])
            # click on size and color to update item id on site
            item['local_id'] = price[0]

            item['current_price'] = {'value': price[4]}
            if price[4] != price[5]:
                item['original_price'] = {'value': price[5]}

            if image_list:
                item['images'] = [img for img in image_list if image_id in img]

            item['selections'] = {'color': raw[1], 'size': raw[2]}

            if item_promo:
                item['promos'] = [{'text': item_promo}]

            # add to common list
            items.append(item)

        
        #item['info_list'] = info_list

        #items.append(item)
        return items
