import masterpage

import method_db
import method_user
import method_url
	
class Subscribe(masterpage.MasterPage):
	def post(self):
		try:
			#  Get logged in user
			user = method_user.getLoggedInUser()
			if not user:
				#self.redirectToLoginWithUrl(self.request.get('redirection'))
				self.response.out.write('login');
				return
	
			referer = self.request.referer
			obj_id = method_url.getIntParamFromUrl(referer, 'id')
			if '/question' in referer:
				att_type = 'question'
			elif '/forumpost' in referer:
				att_type = 'forum'
			else:
				self.response.out.write('error')
				return
			action = self.request.get('action')	
			obj = method_db.getObjectWithTypeAndId(obj_id, att_type)
			
			if action == 'subscribe':
				method_user.subscribe(user, obj)
				self.response.out.write('subscribed')
				return
			elif action == 'unsubscribe':
				method_user.unsubscribe(user, obj, self)
				self.response.out.write('unsubscribed')
				return
			self.response.out.write('error')
			return
		except:
			self.response.out.write('error')