from django.conf.urls import patterns, include, url
from views import *


urlpatterns = patterns('',
    url(r'^$', co_brand(home), name='app_home'),
    url(r'^service/(?P<service_id>\d+)/add_job', co_brand(add_job), name='add_job'),
    url(r'^service/(?P<service_id>\d+)', co_brand(job_type), name='job_type'),
    url(r'^job/(?P<job_id>\d+)/confirm', co_brand(add_job_confirm), name='add_job_confirm'),
    url(r'^job/(?P<job_id>\d+)/thanks', co_brand(add_job_thanks), name='add_job_thanks'),
    url(r'^job/(?P<job_id>\d+)/add_file', co_brand(add_file), name='add_file'),
    url(r'^job/(?P<job_id>\d+)', co_brand(job_detail), name='job_detail'),
    url(r'^account/jobs', co_brand(my_jobs), name='my_jobs'),

)

if settings.DEBUG:
    urlpatterns += patterns('',
        (r'^media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT}),

    )
