# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'Friendship'
        db.create_table('app_friendship', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user1', self.gf('django.db.models.fields.related.ForeignKey')(related_name='user1', to=orm['auth.User'])),
            ('user2', self.gf('django.db.models.fields.related.ForeignKey')(related_name='user2', to=orm['auth.User'])),
            ('approved', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('app', ['Friendship'])

        # Adding unique constraint on 'Friendship', fields ['user1', 'user2', 'approved']
        db.create_unique('app_friendship', ['user1_id', 'user2_id', 'approved'])

        # Adding model 'Profile'
        db.create_table('app_profile', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('display_name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('user', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['auth.User'], unique=True)),
            ('access', self.gf('django.db.models.fields.IntegerField')(default=0)),
            ('location', self.gf('django.db.models.fields.CharField')(max_length=512, blank=True)),
            ('about', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('photo', self.gf('django.db.models.fields.CharField')(max_length=255, null=True)),
        ))
        db.send_create_signal('app', ['Profile'])

        # Adding model 'Setting'
        db.create_table('app_setting', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('key', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('value', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal('app', ['Setting'])

        # Adding unique constraint on 'Setting', fields ['user', 'key', 'value']
        db.create_unique('app_setting', ['user_id', 'key', 'value'])

        # Adding model 'Recipe'
        db.create_table('app_recipe', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('author', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=512)),
            ('description', self.gf('django.db.models.fields.TextField')()),
            ('access', self.gf('django.db.models.fields.IntegerField')(default=0)),
            ('typ', self.gf('django.db.models.fields.IntegerField')(default=0)),
            ('created_at', self.gf('django.db.models.fields.DateField')(auto_now_add=True, blank=True)),
        ))
        db.send_create_signal('app', ['Recipe'])

        # Adding model 'RecipeImage'
        db.create_table('app_recipeimage', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'], null=True)),
            ('upload', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
        ))
        db.send_create_signal('app', ['RecipeImage'])

        # Adding model 'RecipeFile'
        db.create_table('app_recipefile', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.Recipe'], unique=True, null=True)),
            ('upload', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
        ))
        db.send_create_signal('app', ['RecipeFile'])

        # Adding model 'RecipeLink'
        db.create_table('app_recipelink', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.Recipe'], unique=True)),
            ('link', self.gf('django.db.models.fields.CharField')(max_length=1024)),
        ))
        db.send_create_signal('app', ['RecipeLink'])

        # Adding model 'RecipeManual'
        db.create_table('app_recipemanual', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.Recipe'], unique=True)),
            ('contents', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('app', ['RecipeManual'])

        # Adding model 'RecipeComment'
        db.create_table('app_recipecomment', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'])),
            ('created_at', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('author', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('contents', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('app', ['RecipeComment'])

        # Adding model 'RecipeCommentSubscription'
        db.create_table('app_recipecommentsubscription', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'])),
            ('subscriber', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
        ))
        db.send_create_signal('app', ['RecipeCommentSubscription'])

        # Adding model 'BlogPost'
        db.create_table('app_blogpost', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('author', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('title', self.gf('django.db.models.fields.TextField')()),
            ('created_at', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('updated_at', self.gf('django.db.models.fields.DateTimeField')(auto_now=True, blank=True)),
            ('contents', self.gf('django.db.models.fields.TextField')()),
            ('access', self.gf('django.db.models.fields.IntegerField')()),
        ))
        db.send_create_signal('app', ['BlogPost'])

        # Adding model 'BlogPostComment'
        db.create_table('app_blogpostcomment', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('author', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('post', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.BlogPost'])),
            ('created_at', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('contents', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('app', ['BlogPostComment'])

        # Adding model 'Notification'
        db.create_table('app_notification', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('typ', self.gf('django.db.models.fields.CharField')(max_length=32)),
            ('target_user', self.gf('django.db.models.fields.related.ForeignKey')(related_name='target_user', to=orm['auth.User'])),
            ('other_user', self.gf('django.db.models.fields.related.ForeignKey')(related_name='other_user', null=True, to=orm['auth.User'])),
            ('action', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'], null=True)),
            ('blog_post', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.BlogPost'], null=True)),
            ('seen', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('created_at', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('dismiss_on_view', self.gf('django.db.models.fields.BooleanField')(default=True)),
        ))
        db.send_create_signal('app', ['Notification'])

        # Adding model 'BlogPostPhoto'
        db.create_table('app_blogpostphoto', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('post', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.BlogPost'])),
            ('upload', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal('app', ['BlogPostPhoto'])

        # Adding model 'Tag'
        db.create_table('app_tag', (
            ('tag', self.gf('django.db.models.fields.CharField')(max_length=128, primary_key=True)),
        ))
        db.send_create_signal('app', ['Tag'])

        # Adding model 'RecipeTag'
        db.create_table('app_recipetag', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'])),
            ('tag', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Tag'])),
        ))
        db.send_create_signal('app', ['RecipeTag'])

        # Adding model 'Bookmark'
        db.create_table('app_bookmark', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'])),
        ))
        db.send_create_signal('app', ['Bookmark'])

        # Adding unique constraint on 'Bookmark', fields ['user', 'recipe']
        db.create_unique('app_bookmark', ['user_id', 'recipe_id'])

        # Adding model 'FeedEvent'
        db.create_table('app_feedevent', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
        ))
        db.send_create_signal('app', ['FeedEvent'])

        # Adding model 'CommentEvent'
        db.create_table('app_commentevent', (
            ('feedevent_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.FeedEvent'], unique=True, primary_key=True)),
            ('comment', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.RecipeComment'])),
        ))
        db.send_create_signal('app', ['CommentEvent'])

        # Adding model 'BookmarkEvent'
        db.create_table('app_bookmarkevent', (
            ('feedevent_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.FeedEvent'], unique=True, primary_key=True)),
            ('bookmark', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Bookmark'])),
        ))
        db.send_create_signal('app', ['BookmarkEvent'])

        # Adding model 'RecipeEvent'
        db.create_table('app_recipeevent', (
            ('feedevent_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.FeedEvent'], unique=True, primary_key=True)),
            ('recipe', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Recipe'])),
        ))
        db.send_create_signal('app', ['RecipeEvent'])

        # Adding model 'FriendshipEvent'
        db.create_table('app_friendshipevent', (
            ('feedevent_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['app.FeedEvent'], unique=True, primary_key=True)),
            ('friendship', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.Friendship'])),
        ))
        db.send_create_signal('app', ['FriendshipEvent'])

        # Adding model 'UserFeed'
        db.create_table('app_userfeed', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('event', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['app.FeedEvent'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('user_own_evt', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('app', ['UserFeed'])

        # Adding unique constraint on 'UserFeed', fields ['user', 'event', 'user_own_evt']
        db.create_unique('app_userfeed', ['user_id', 'event_id', 'user_own_evt'])


    def backwards(self, orm):
        # Removing unique constraint on 'UserFeed', fields ['user', 'event', 'user_own_evt']
        db.delete_unique('app_userfeed', ['user_id', 'event_id', 'user_own_evt'])

        # Removing unique constraint on 'Bookmark', fields ['user', 'recipe']
        db.delete_unique('app_bookmark', ['user_id', 'recipe_id'])

        # Removing unique constraint on 'Setting', fields ['user', 'key', 'value']
        db.delete_unique('app_setting', ['user_id', 'key', 'value'])

        # Removing unique constraint on 'Friendship', fields ['user1', 'user2', 'approved']
        db.delete_unique('app_friendship', ['user1_id', 'user2_id', 'approved'])

        # Deleting model 'Friendship'
        db.delete_table('app_friendship')

        # Deleting model 'Profile'
        db.delete_table('app_profile')

        # Deleting model 'Setting'
        db.delete_table('app_setting')

        # Deleting model 'Recipe'
        db.delete_table('app_recipe')

        # Deleting model 'RecipeImage'
        db.delete_table('app_recipeimage')

        # Deleting model 'RecipeFile'
        db.delete_table('app_recipefile')

        # Deleting model 'RecipeLink'
        db.delete_table('app_recipelink')

        # Deleting model 'RecipeManual'
        db.delete_table('app_recipemanual')

        # Deleting model 'RecipeComment'
        db.delete_table('app_recipecomment')

        # Deleting model 'RecipeCommentSubscription'
        db.delete_table('app_recipecommentsubscription')

        # Deleting model 'BlogPost'
        db.delete_table('app_blogpost')

        # Deleting model 'BlogPostComment'
        db.delete_table('app_blogpostcomment')

        # Deleting model 'Notification'
        db.delete_table('app_notification')

        # Deleting model 'BlogPostPhoto'
        db.delete_table('app_blogpostphoto')

        # Deleting model 'Tag'
        db.delete_table('app_tag')

        # Deleting model 'RecipeTag'
        db.delete_table('app_recipetag')

        # Deleting model 'Bookmark'
        db.delete_table('app_bookmark')

        # Deleting model 'FeedEvent'
        db.delete_table('app_feedevent')

        # Deleting model 'CommentEvent'
        db.delete_table('app_commentevent')

        # Deleting model 'BookmarkEvent'
        db.delete_table('app_bookmarkevent')

        # Deleting model 'RecipeEvent'
        db.delete_table('app_recipeevent')

        # Deleting model 'FriendshipEvent'
        db.delete_table('app_friendshipevent')

        # Deleting model 'UserFeed'
        db.delete_table('app_userfeed')


    models = {
        'app.blogpost': {
            'Meta': {'object_name': 'BlogPost'},
            'access': ('django.db.models.fields.IntegerField', [], {}),
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'contents': ('django.db.models.fields.TextField', [], {}),
            'created_at': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'title': ('django.db.models.fields.TextField', [], {}),
            'updated_at': ('django.db.models.fields.DateTimeField', [], {'auto_now': 'True', 'blank': 'True'})
        },
        'app.blogpostcomment': {
            'Meta': {'object_name': 'BlogPostComment'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'contents': ('django.db.models.fields.TextField', [], {}),
            'created_at': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'post': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.BlogPost']"})
        },
        'app.blogpostphoto': {
            'Meta': {'object_name': 'BlogPostPhoto'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'post': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.BlogPost']"}),
            'upload': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        'app.bookmark': {
            'Meta': {'unique_together': "(('user', 'recipe'),)", 'object_name': 'Bookmark'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']"}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'app.bookmarkevent': {
            'Meta': {'object_name': 'BookmarkEvent', '_ormbases': ['app.FeedEvent']},
            'bookmark': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Bookmark']"}),
            'feedevent_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.FeedEvent']", 'unique': 'True', 'primary_key': 'True'})
        },
        'app.commentevent': {
            'Meta': {'object_name': 'CommentEvent', '_ormbases': ['app.FeedEvent']},
            'comment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.RecipeComment']"}),
            'feedevent_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.FeedEvent']", 'unique': 'True', 'primary_key': 'True'})
        },
        'app.feedevent': {
            'Meta': {'object_name': 'FeedEvent'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'app.friendship': {
            'Meta': {'unique_together': "(('user1', 'user2', 'approved'),)", 'object_name': 'Friendship'},
            'approved': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'user1': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'user1'", 'to': "orm['auth.User']"}),
            'user2': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'user2'", 'to': "orm['auth.User']"})
        },
        'app.friendshipevent': {
            'Meta': {'object_name': 'FriendshipEvent', '_ormbases': ['app.FeedEvent']},
            'feedevent_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.FeedEvent']", 'unique': 'True', 'primary_key': 'True'}),
            'friendship': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Friendship']"})
        },
        'app.notification': {
            'Meta': {'object_name': 'Notification'},
            'action': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'blog_post': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.BlogPost']", 'null': 'True'}),
            'created_at': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'dismiss_on_view': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'other_user': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'other_user'", 'null': 'True', 'to': "orm['auth.User']"}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']", 'null': 'True'}),
            'seen': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'target_user': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'target_user'", 'to': "orm['auth.User']"}),
            'typ': ('django.db.models.fields.CharField', [], {'max_length': '32'})
        },
        'app.profile': {
            'Meta': {'object_name': 'Profile'},
            'about': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'access': ('django.db.models.fields.IntegerField', [], {'default': '0'}),
            'display_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'location': ('django.db.models.fields.CharField', [], {'max_length': '512', 'blank': 'True'}),
            'photo': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True'}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['auth.User']", 'unique': 'True'})
        },
        'app.recipe': {
            'Meta': {'object_name': 'Recipe'},
            'access': ('django.db.models.fields.IntegerField', [], {'default': '0'}),
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'created_at': ('django.db.models.fields.DateField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'description': ('django.db.models.fields.TextField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'typ': ('django.db.models.fields.IntegerField', [], {'default': '0'})
        },
        'app.recipecomment': {
            'Meta': {'object_name': 'RecipeComment'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'contents': ('django.db.models.fields.TextField', [], {}),
            'created_at': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']"})
        },
        'app.recipecommentsubscription': {
            'Meta': {'object_name': 'RecipeCommentSubscription'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']"}),
            'subscriber': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'app.recipeevent': {
            'Meta': {'object_name': 'RecipeEvent', '_ormbases': ['app.FeedEvent']},
            'feedevent_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.FeedEvent']", 'unique': 'True', 'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']"})
        },
        'app.recipefile': {
            'Meta': {'object_name': 'RecipeFile'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.Recipe']", 'unique': 'True', 'null': 'True'}),
            'upload': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'app.recipeimage': {
            'Meta': {'object_name': 'RecipeImage'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']", 'null': 'True'}),
            'upload': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'app.recipelink': {
            'Meta': {'object_name': 'RecipeLink'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'link': ('django.db.models.fields.CharField', [], {'max_length': '1024'}),
            'recipe': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.Recipe']", 'unique': 'True'})
        },
        'app.recipemanual': {
            'Meta': {'object_name': 'RecipeManual'},
            'contents': ('django.db.models.fields.TextField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['app.Recipe']", 'unique': 'True'})
        },
        'app.recipetag': {
            'Meta': {'object_name': 'RecipeTag'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'recipe': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Recipe']"}),
            'tag': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.Tag']"})
        },
        'app.setting': {
            'Meta': {'unique_together': "(('user', 'key', 'value'),)", 'object_name': 'Setting'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'key': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'value': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        'app.tag': {
            'Meta': {'object_name': 'Tag'},
            'tag': ('django.db.models.fields.CharField', [], {'max_length': '128', 'primary_key': 'True'})
        },
        'app.userfeed': {
            'Meta': {'unique_together': "(('user', 'event', 'user_own_evt'),)", 'object_name': 'UserFeed'},
            'created': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'event': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['app.FeedEvent']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'user_own_evt': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'auth.group': {
            'Meta': {'object_name': 'Group'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        'auth.permission': {
            'Meta': {'ordering': "('content_type__app_label', 'content_type__model', 'codename')", 'unique_together': "(('content_type', 'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        }
    }

    complete_apps = ['app']