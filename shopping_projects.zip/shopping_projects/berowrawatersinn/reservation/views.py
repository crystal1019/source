# Create your views here.
from django.template import loader, RequestContext
from django.http import HttpResponse
import datetime
from berowrawatersinn.reservation.models import *
from berowrawatersinn.reservation.forms import *
from django.utils import simplejson
from django.core.mail import send_mail


def booking(request):
    t = loader.get_template('reservation.html')
    rp = request.POST.copy()
    msg = ''
    if rp:
        rp['status'] = 'Unconfirmed'
        form = BookingForm(rp)
        if form.is_valid():
            r = form.save()
            msg = 'Thank you for your reservation, one of our staff will be in contact within 24 hours to confirm availability.'
            form = BookingForm()
            try:
                message = '''Hi, you have a new online reservation.
                
First Name: %s
Last Name: %s
Phone: %s
Email: %s
Date: %s
Time: %s
Number in Party: %s
Arrive By: %s
Special Requests: %s
Status: %s

You can view/edit this booking from http://www.berowrawatersinn.com/admin/reservation/booking/%s/
''' %(r.first_name, r.last_name, r.phone, r.email, r.date, r.time, r.quantity if r.quantity != 6 else '6 and over', r.arrive_by, r.special_requests, r.status, r.id)
                send_mail('Online Reservation', message,'no-reply@berowrawatersinn.com.au',['reservations@berowrawatersinn.com',],fail_silently=False )
            except:
                pass
    else:
        form = BookingForm()
        
    available_date = SeatsByDate.objects.get_follow_available_date()
        
    c = RequestContext(request, {
        'form':form,
        'msg':msg,
        
        'available_date':available_date
    })
    
    return HttpResponse(t.render(c))


def get_time(request):
    rp = request.GET
    date = rp.get('date','')
    year,month,day = date.split('-')
    thedate = datetime.date(int(year),int(month),int(day))
    alltimes = MealType.objects.get_available_booking_times(date=thedate)
    html = ''
    for x in alltimes:
        html += '''<option value='%s'>%s</option>''' %(x.strftime('%H:%M'),x.strftime('%H:%M'))
        
    return HttpResponse(simplejson.dumps({'html':html}), mimetype='application/javascript')


def get_arrive_info(request):
    rp = request.GET
    tid = rp.get('arrive','')
    try:
        types = ArriveBy.objects.get(id=tid)
        description = types.description
    except:
        description = ''
    return HttpResponse(simplejson.dumps({'text':description}), mimetype='application/javascript')