import requests
from lxml import html
import csv

class scrapping(object):

    HEADERS = { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36',
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Charset':'utf-8;q=0.7,*;q=0.3',
                'Accept-Encoding':'gzip,deflate,sdch',
                'Accept-Language':'it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4',
                'Connection':'keep-alive',
                # 'Content-Type':'application/x-www-form-urlencoded',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                # 'X-Requested-With':'XMLHttpRequest',
                # 'Referer': 'https://wwwapps.ups.com/ctc/request?loc=en_US&WT.svl=PNRO_L1',
                # 'Origin': 'https://wwwapps.ups.com',
                # 'Host': 'wwwapps.ups.com'
                }

    def __init__(self, *args, **kwargs):
        self.session = requests.Session()
        self.session.headers = self.HEADERS
        self.logged_in = False

    def login(self, username, password):
        resp = self.session.get('http://www.smartmfi.com/admin.php?do=product')
        x = html.fromstring(resp.content)
        resp = self.session.post('http://www.smartmfi.com/admin.php?do=product',
            data={'login_username': username,
                  'login_password': password})
        x = html.fromstring(resp.content)
        try:
            check_login = x.xpath(".//a[contains(@class,'menu_level2')]")[0]
            print 'logged in'
            self.logged_in = True
            return True
        except IndexError:
            self.logged_in = False
            return False

    def get_data(self, username, password):
        if not self.logged_in:
            if not self.login(username, password):
                return False

        #login data
        data={
            'login_username': username,
            'login_password': password
        }
        resp = self.session.post('http://www.smartmfi.com/admin.php?do=product', data=data, allow_redirects=True,
                                 headers={'Referer':'http://www.smartmfi.com/admin.php?do=logout',
                                          'Origin':'http://www.smartmfi.com',
                                          'Host':'www.smartmfi.com'})

        x = html.fromstring(resp.content)

        #get pages number
        pg_no_all = x.xpath(".//div[contains(@id,'container')]//div//table//tr//td//a")[16].attrib['href']
        pg_no = int(pg_no_all.split('=')[-1])
        items = []

        # get json data from website
        for i in range(1,pg_no+1):
            resp = self.session.post('http://www.smartmfi.com/admin.php?do=product&status=1&pageset='+str(i), data=data, allow_redirects=True,
                                 headers={'Referer':'http://www.smartmfi.com/admin.php?do=logout',
                                          'Origin':'http://www.smartmfi.com',
                                          'Host':'www.smartmfi.com'})

            x = html.fromstring(resp.content)
            table_no_all = x.xpath(".//form//table//tr")

            for table_no in table_no_all:
                if len(table_no.xpath(".//td")) > 3:
                    product=table_no.xpath(".//td")[2].text_content().strip()
                    SKU=table_no.xpath(".//td")[3].text_content().strip()
                    Price=table_no.xpath(".//td")[8].text_content().strip()
                    SRP=table_no.xpath(".//td")[9].text_content().strip()
                    items.append({'product': product, 'SKU' : SKU, 'Price': Price, 'SRP' : SRP})

        #write into product.csv from json data
        try:
           with open("product.csv", "w") as output_file:
                csv_out = csv.writer(output_file)
                Header = ['product', 'SKU', 'Price','SRP']
                csv_out.writerow(Header)
                for item in items:
                    te = [item['product'],item['SKU'],item['Price'],item['SRP']]
                    csv_out.writerow(te)

                output_file.close()
        except IOError:
           return 'There is no product.csv in directory'
        return items