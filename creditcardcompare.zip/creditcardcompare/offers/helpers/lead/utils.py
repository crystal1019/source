import os
from django.conf import settings
from models import Lead
from helpers import get_age, EmailThread


def batch_download(modeladmin, request, queryset):
    fields = getattr(Lead, '_meta').fields
    file_path = os.path.join(settings.MEDIA_ROOT, 'downloads', 'lead.csv')

    f = file(file_path, 'w')
    f.write(','.join([field.column for field in fields]))  # leads
    f.write(',age,')
    f.write(','.join(['search_type',
                      'search_type_2',
                      'workstatus',
                      'income',
                      'banks_with']))  # search_details
    
    for lead in queryset:
        f.write('\n')
        content = ','.join([_extract(lead, field) for field in fields])
        try:
            f.write(content)
        except UnicodeEncodeError:
            f.write(content.encode('utf-8'))
        f.write(',%s,' % _get_age(lead))
        
        try:
            search_detail = lead.searchdetail_set.order_by('when')[0]
        except IndexError:
            continue
        data = (getattr(search_detail.cardtype, 'name', '').encode('ascii', 'replace'),
                _get_search_type(search_detail),
                search_detail.get_workstatus_display(),
                str(search_detail.income))
        f.write(','.join(data) + ',')
        f.write(','.join([getattr(b.bank, 'name', '') for b in search_detail.bank_set.all()]))
    f.close()
    
    EmailThread(**{
            'email': getattr(request.user, 'email', settings.REVIEW_MODERATOR),
            'subject': 'Leads Download',
            'context': {},
            'template': 'lead/download/email.html',
            'file_path': file_path
        }).start()

def _extract(lead, field):
    if field.column == 'state_id':
        try:
            lead.save()  # in order to load missing lead's State
            return lead.state.code
        except AttributeError:
            return ''
    elif field.column == 'provider_id':
        return lead.provider.name
    elif field.column in ('first_name', 'last_name'):
        return getattr(lead, field.column).title()

    return str(getattr(lead, field.column))

def _get_age(lead):
    try:
        detail = lead.searchdetail_set.order_by('when')[0]
    except IndexError:
        return ''
    return get_age(detail)

def _get_search_type(search_detail):
    if search_detail.balance_transfer:
        return search_detail.balance_transfer
    elif search_detail.frequent_flyer:
        return search_detail.frequent_flyer
    elif search_detail.rewards:
        return search_detail.rewards
    else:
        return ''