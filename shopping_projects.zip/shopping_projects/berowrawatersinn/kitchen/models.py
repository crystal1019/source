from django.db import models
from berowrawatersinn.website.models import CommonPage
# Create your models here.

class KitchenPage(CommonPage):
    nav = '/kitchen/'
    is_landing = models.BooleanField(default=False)
    
    def save(self,*args, **kwargs):
        if self.is_landing:
            try:
                landing = KitchenPage.objects.get(is_landing=True)
                if landing.id != self.id:
                    landing.is_landing = False
                    landing.save()
            except:
                pass
            
        super(KitchenPage, self).save(*args, **kwargs)