'''
Created on Jul 13, 2014

Class for calling Booked API.

All references are in "Booked" context.  That means userId et al. means Booked user id.
Only the broker server should be calling these methods and the broker server is 
responsible for translating data among servers.  
'''

import dateutil.parser
import json
import requests
import sys

#from pytz import timezone

from datetime import *
from dateutil.relativedelta import *
from dateutil import tz
from dateutil import parser

from tyne import awConstants

DEBUG=True

SUCCESS = 0
ERR_BAD_JSON = 100
ERR_NO_USER_FOUND = 101
ERR_NO_RESERVATION_FOUND = 102
ERR_REQUEST_FAILURE = 103
ERR_UNKNOWN = 999

BOOKED_TIME_PATTERN = "%Y-%m-%dT%H:%M:%S%z"
BOOKED_DATE_PATTERN = "%Y-%m-%d"
BOOKED_TIME_REGEX_PATTERN = "(%d+)%-(%d+)%-(%d+)%a(%d+)%:(%d+)%:([%d%.]+)([Z%p])(%d%d)%:?(%d%d)"
DEFAULT_NUM_DAYS = 21
#TODO: add real logging
def dbgprint(msg, isJson = False):
	if DEBUG:
		if isJson:
			print("DEBUG: ")
			print(json.dumps(msg, indent=2, sort_keys=True))
		else:
			print("DEBUG: ", msg)


def getJsonEntries(jsArray, **kwargs):
	filteredArr = []
	
	for jsItem in jsArray:
		match = True
		for kwKey in kwargs:
			if not kwKey in jsItem:
				dbgprint("WARNING: %s not a valid key" % (kwKey))
				match = False
				break
			if not str(jsItem[kwKey]) == str(kwargs[kwKey]):
				match = False
				break
		if match:
			filteredArr.append(jsItem)
	
	return filteredArr

def getMngAft(hourNum):
	return awConstants.MNG_AFT_MAP[hourNum]

class BookedConnector(object):

	URL_BASE_PATH = 'Web/Services'
	URL_PATH_AUTH = 'Authentication/Authenticate'
	URL_PATH_GROUPS = 'Groups/'
	URL_PATH_RESERVATIONS = 'Reservations/'
	URL_PATH_RESOURCES = 'Resources/'
	URL_PATH_AVAILABILITY = 'Availability'
	URL_PATH_SCHEDULES = 'Schedules/'
	URL_PATH_SLOTS = 'Slots'
	URL_PATH_USERS = 'Users/'

	headers = {}


	def __init__(self, serverUrl, orgName, user, password):
		self.serverUrl = serverUrl
		self.orgName = orgName
		self.user = user
		self.password = password
			
		self.urlBase = "%s/%s%s" % (self.serverUrl, self.orgName, self.URL_BASE_PATH)
		self.authUrl = self.urlBase + '/' + self.URL_PATH_AUTH
		self.groupsUrl = self.urlBase + '/' + self.URL_PATH_GROUPS
		self.reservationsUrl = self.urlBase + '/' + self.URL_PATH_RESERVATIONS
		self.resourcesUrl = self.urlBase + '/' + self.URL_PATH_RESOURCES
		self.schedulesUrl = self.urlBase + '/' + self.URL_PATH_SCHEDULES
		self.slotsUrl = self.urlBase + '/' + self.URL_PATH_SCHEDULES + '%s/' + self.URL_PATH_SLOTS
		self.usersUrl = self.urlBase + '/' + self.URL_PATH_USERS


	def request(self, method, url, *args, **kwargs):
		dbgprint("Attempting to get:" + url)
		if 'data' in kwargs and isinstance(kwargs['data'], dict):
			kwargs['data'] = json.dumps(kwargs['data'])
		resp = requests.request(method, url, headers=self.headers, *args, **kwargs)
		#maybe the connection timed out
		if resp.status_code == 401:
			self.setSessionAuthHeaders()
			dbgprint("Retrying after login: " + url)
			resp = requests.request(method, url, headers=self.headers, *args, **kwargs)

		#valid responses
		dbgprint("request url was: " + resp.url)
		if resp.status_code >199 and resp.status_code <300:
			try:
				result = resp.json()
			except ValueError:
				dbgprint("Error trying to json parse valid response, url: %s, text: %s" % (resp.url, resp.reason))
				jsonStr = '{"errors":{"code":"' + str(resp.status_code) + '",' + '"status": "' + str(resp.reason) + '",' + '"text": "' + resp.text + '"}}'
				result = json.loads(jsonStr)
		else:
			dbgprint("Error calling url %s, code: %s, reason: %s, text: %s" % (resp.url, resp.status_code, resp.reason, resp.text))
			#Cannot print value quotes in json str since it will mess up the other quotes
			escTxt = resp.text.replace('"', '*')
			jsonStr = '{"errors":{"code":"' + str(resp.status_code) + '",' + '"status": "' + str(resp.reason) + '",' + '"text": "' + escTxt + '"}}'
			print(jsonStr)
			result = json.loads(jsonStr)
			
		return result


	def setSessionAuthHeaders(self):
		data = json.dumps({'username':self.user, 'password':self.password})

		dbgprint("Authenticating against " + self.authUrl)
		result = requests.post(self.authUrl, data=data)
		jResult = result.json()
		xBookedUserId = jResult['userId']
		xBookedSessionToken = jResult['sessionToken']
		
		self.headers["X-Booked-UserId"] = xBookedUserId
		self.headers["X-Booked-SessionToken"] = xBookedSessionToken

		dbgprint("Headers set as " + str(self.headers))
		

	def getUsers(self, **kwargs):
		url = self.usersUrl
		
		resp = self.request('GET', url)
		#resp = self.request('GET', "https://myhealthplanmarkets.appointment.works/Web/Services/Reservations/543d71f499122293354094")
		if 'users' in resp:
			if len(kwargs):
				#dbgprint(resp, isJson = True)
				resp['users'] = getJsonEntries(resp['users'], **kwargs)		

		return resp


	def getUser(self, userId):
		url = self.usersUrl + str(userId)
		
		resp = self.request('GET', url)

		return resp

		
		
	def createUser(self, userData):
		
		resp = self.request('POST', self.usersUrl, data=userData)
		
		#if valid user made, return a "typical" user record
		if 'userId' in resp:
			resp = self.getUsers(id = resp['userId'])
													
		return resp


	def getReservations(self, **kwargs):
		url = self.reservationsUrl

		#getting a reservation by refNumber gives more detailed data so handle it differently
		#if kwargs and 'referenceNumber' in kwargs:
		#	url= url + kwargs['referenceNumber']

		#	return {'reservations': self.request('GET', url, params=kwargs)}
		
		nextOnly = False
		if 'nextOnly' in kwargs:
			nextOnly = kwargs['nextOnly']
			del kwargs['nextOnly']
	
		resp = self.request('GET', url, params=kwargs, data = {"params":kwargs})

		if 'reservations' in resp:
			if len(kwargs):
				#dbgprint(resp, isJson = True)
				resp['reservations'] = getJsonEntries(resp['reservations'], **kwargs)		
	
			# maybe only return the next reservation
			if resp and nextOnly:
				nextReservation = None
				reservations = resp['reservations']
				for reservation in reservations:
					if nextReservation == None or reservation['startDate'] < nextReservation['startDate']:
						nextReservation = reservation
				resp['reservations'] = [nextReservation]
			
		return resp


	def _resAsHashByStart(self, jsonRes):
		startHash = {}
		
		for jr in jsonRes:
			startDate = dateutil.parser.parse(jr['startDate'])
			#print("JR", startDate)
			ts = startDate.timestamp()
			startHash[ts] = jr
		
		return startHash

			
	def createReservation(self, reqDataInfo):
		dbgprint("Creating reservation with data %s" % (reqDataInfo))
		
		if not isinstance(reqDataInfo, dict):
			reqData = json.loads(reqDataInfo)
		else:
			reqData = reqDataInfo
			
		if 'startDateTime' not in reqData:
			return json.loads('{"error":"Missing startDateTime"}')
		if 'endDateTime' not in reqData:
			return json.loads('{"error":"Missing endDateTime"}')
		
		#createReservation API for booked takes UTC only
		startDate = dateutil.parser.parse(reqData['startDateTime'])
		startDateUtc = startDate.astimezone(tz.gettz('UTC'))
		startDateUtcstr = startDateUtc.strftime(BOOKED_TIME_PATTERN)
		endDate = dateutil.parser.parse(reqData['endDateTime'])
		endDateUtc = endDate.astimezone(tz.gettz('UTC'))
		endDateUtcstr = endDateUtc.strftime(BOOKED_TIME_PATTERN)
		reqData['startDateTime'] = startDateUtcstr
		reqData['endDateTime'] = endDateUtcstr
				
		dbgprint("Creating reservation with data %s" % (reqData))

		resp = self.request('POST', self.reservationsUrl, data=reqData)
		
		#return json that is the same as all reservation info
		if 'referenceNumber' in resp:
			resp = self.getReservations(referenceNumber=resp['referenceNumber'])
			
		return resp
	
	
	def deleteReservation(self, refNumber):
		resp  = self.request('DELETE', self.reservationsUrl + refNumber)
		
		return resp
	
	
	def getResources(self, **kwargs):
		url = self.resourcesUrl
		
		resp = self.request('GET', url)

		if 'resources' in resp:
			if len(kwargs):
				#dbgprint(resp, isJson = True)
				resp['resources'] = getJsonEntries(resp['resources'], **kwargs)		
		
		return resp


	def getSchedules(self, **kwargs):
		openOnly = False
		if 'openOnly' in kwargs:
			openOnly = kwargs['openOnly'].lower() == "true"
			
		if openOnly:
			kwargs['resourceIds'] = kwargs['resourceIds'].split(',')
			
			avail = self.getOpenSlotsOnly(**kwargs)
			
			return {'schedules': avail}
		
		url = self.schedulesUrl

		resp = self.request('GET', url)

		if 'schedules' in resp:
			if len(kwargs):
				#dbgprint(resp, isJson = True)
				resp['schedules'] = getJsonEntries(resp['schedules'], **kwargs)		
		
		return resp


	def getAvailableTimes(self, **kwargs):
		if not 'resourceIds' in kwargs:
			return {'error': "%s requires resourceIds key" % (sys._getframe().f_code.co_name)}

		mngaft = False
		if 'mngaft' in kwargs:
			mngaft = kwargs['mngaft'].lower() == "true"

		resourceIds = kwargs['resourceIds'].split(',')
		del kwargs['resourceIds']
		availSlots = self.getOpenSlotsOnly(resourceIds, **kwargs)

		# return json is availSlots{resourceId}*{'dates'}*[]{'date'}, {'resources'}[]{'slots'}[]{'time'}
		# what we want is:
		# slots {'date'}[availableTime]
		availDates = {}
		for resourceId, resourceInfo in availSlots.items():
			dates = resourceInfo['dates']
			for dateItem in dates:
				tgtDate = parser.parse(dateItem['date']).strftime('%Y-%m-%d')
				if tgtDate not in availDates:
					availDates[tgtDate] = {}
				resources = dateItem['resources']
				for resc in resources:
					slots = resc['slots']
					for slot in slots:
						if mngaft:
							timeStr = getMngAft(parser.parse(slot['startDateTime']).hour)
						else:
							sdt = parser.parse(slot['startDateTime']).strftime('%l:%M%p')
							edt = parser.parse(slot['endDateTime']).strftime('%l:%M%p')
							timeStr = sdt + ' - ' + edt
						availDates[tgtDate][timeStr] = resourceId

		return {'availability': availDates}


	def getOpenSlotsOnly(self, resourceIds, **kwargs):
		availList = self.getSlotResourceList(resourceIds, **kwargs)

		for resourceId in availList:
			for tgtDate in availList[resourceId]['dates']: #availList[resourceId]['dates'][2]['date']
				slots = tgtDate['resources'][0]['slots']
				#print("BBB", len(tgtDate['resources'][0]['slots']))
				filteredSlots = getJsonEntries(slots, isReservable = True, isReserved = False)
				tgtDate['resources'][0]['slots'] = filteredSlots
				#print("CCCC", len(tgtDate['resources'][0]['slots']))

		#for resourceId in availList:
		#	for tgtDate in availList[resourceId]['dates']: #availList[resourceId]['dates'][2]['date']
		#		print("DDD", len(tgtDate['resources'][0]['slots']))

		return availList


	def getNextOpenSlot(self, availList, filterList = None):
		nextOpenSlot = None
		
		availableSlots = {} 
		availableSlotTimes = {} 
		
		#go through each resourceId
		try:
			for resourceId in availList:
				availableSlots[resourceId] = {}
				availableSlotTimes[resourceId] = {}

				#get all available dates in the resource and sort them so earliest is first
				tgtDates = {}
				for tgtDate in availList[resourceId]['dates']: #availList[resourceId]['dates'][2]['date']
					tgtDates[tgtDate['date']] = tgtDate
				tdKeys = list(tgtDates.keys())
				tdKeys.sort()
				
				#go through each date on the resourceId to find open slots
				for tdKey in tdKeys:
					x = tgtDates[tdKey]
					slots = {}
					
					#go through each slot on the date, assume only one resource
					slotsArr = getJsonEntries(x['resources'][0]['slots'], isReservable = True, isReserved = False)
					#print("For %s found %s slots" % (tdKey, len(slotsArr)))
					#list slot by start time; it will help in finding the earliest
					
					for slot in slotsArr:
						#filter slots if desired
						matched = True
						
						if filterList:
							startDateTime = parser.parse(slot['startDateTime'])
							endDateTime = parser.parse(slot['endDateTime'])
							#backwards compatibility
							sdt = startDateTime
							edt = endDateTime
							for fl in filterList:
								if not eval(fl):
									matched = False
									break
						
						if not matched:
							continue
					

						slots[slot['startDateTime']] = slot
						slot['resourceId'] = resourceId
					#create hash of resourceId then date; hold sorted open slots in each one
					#if a date does not have an open slot it will not get in the list
					stKeys = list(slots.keys())
					if len(stKeys):
						stKeys.sort()
						availableSlots[resourceId][tdKey] = slots
						availableSlotTimes[resourceId][tdKey] = stKeys

				pass
			#for each resource compare first slot of earliest resource date;  slots were sorted so this should work 
			earliest = None
			for resourceId in availableSlotTimes:
				if not len(availableSlotTimes[resourceId]):
					continue
				#sort to gets earliest date
				availableDates = list(availableSlotTimes[resourceId])
				availableDates.sort()
				
				#resourceId-earliestDay-earliestSlot
				if not earliest or availableSlotTimes[resourceId][availableDates[0]][0] < earliest:
					earliest = availableSlotTimes[resourceId][availableDates[0]][0]
					nextOpenSlot = availableSlots[resourceId][availableDates[0]][availableSlotTimes[resourceId][availableDates[0]][0]]
		except Exception as e:
			dbgprint("Hit error in getNextOpenSlot")
			dbgprint(sys.exc_info())
			
		return nextOpenSlot
	
		
	def createNextReservationFromList(self, availList, userId, filterList = None, resData = None):

		slot = self.getNextOpenSlot(availList, filterList)

		if not slot:
			jsonStr = '{"errors":{"error":"No open slots found"}}'
			return json.loads(jsonStr)			
		#TOOD: _, resourceId = option.split('##')
		resourceId = slot['resourceId']
		
		#createReservation API for booked takes UTC only
		startDate = dateutil.parser.parse(slot['startDateTime'])
		startDateUtc = startDate.astimezone(tz.gettz('UTC'))
		startDateUtcstr = startDateUtc.strftime(BOOKED_TIME_PATTERN)
		endDate = dateutil.parser.parse(slot['endDateTime'])
		endDateUtc = endDate.astimezone(tz.gettz('UTC'))
		endDateUtcstr = endDateUtc.strftime(BOOKED_TIME_PATTERN)

		#TODO: make this a hash so key can only be set once
		newResFields = []
		newResFields.append('"startDateTime":"%s"' % (startDateUtcstr))
		newResFields.append('"endDateTime":"%s"' % (endDateUtcstr))
		newResFields.append('"description":"AppointmentWorks Connector"')
		newResFields.append('"resourceId":"%s"' % (resourceId))
		newResFields.append('"resources":["%s"]' % (resourceId))
		newResFields.append('"userId":"%s"' % (userId))
		newResFields.append('"title":"AppointmentWorks"')
		
		if resData:
			for k, v in resData.items():
				#skip startDate and endDate because they have to be formatted special (UTC only)
				if k == 'startDateTime':
					continue
				if k == 'endDateTime':
					continue
				if k == 'customAttributes':
					caStr = str(resData['customAttributes'])
					caStr = caStr.replace("'",'"')
					newResFields.append('"customAttributes":%s' % (caStr))
				else:
					if isinstance(v, str):
						v = '"' + v + '"'
					newResFields.append('"%s":%s' % (k, v))
												
		#print(option, slot)
		nrStr = '{' + ','.join(newResFields) + '}'
		#print("CR***:", nrStr)
		resp = self.createReservation(nrStr)
		#print("RESULT:",x)
		
		return resp


	def getSlotResourceList(self, resourceIds, **kwargs):
		'''
		Create a hash of slots for each specified resourceId
		'''
		
		availSlots = {}
		
		for resourceId in resourceIds:
			resource = self.getResources(resourceId=resourceId)
			if (not 'resources' in resource) or (not len(resource["resources"])):
				continue
			scheduleId = resource["resources"][0]['scheduleId']
			kwargs['resourceId'] = resourceId
			
			#default start date is for today, which can be in the past; so add a day
			if 'startDateTime' not in kwargs:
				earliestTime = (datetime.now(tz.tzutc()) + relativedelta(days=+1)).strftime(BOOKED_DATE_PATTERN)
				kwargs['startDateTime'] = earliestTime
			#some booked APIs required end date to work 
			if 'endDateTime' not in kwargs:
				q = dateutil.parser.parse(kwargs['startDateTime'])
				latestTime = (q + relativedelta(days=+ DEFAULT_NUM_DAYS)).strftime(BOOKED_DATE_PATTERN)
				kwargs['endDateTime'] = latestTime
			
			resp = self.request('GET', self.slotsUrl % (scheduleId), params=kwargs)

			#TODO: add filtering here, e.g. certain days or afternoon or morning			
		
			availSlots[resourceId] = resp
		
		return availSlots
	

	"""
	converts resources into schedules then reads schedules to find next open slot
	then create a reservation with that slot and user
	"""
	def createReservationNextAvailable(self, userId, resourceIds, resData, filterList = None):
		print("********************", resData)
		print("******************2", filterList)
		if resData:
			availSlots = self.getSlotResourceList(resourceIds, **resData)
		else:
			availSlots = self.getSlotResourceList(resourceIds)
				
		resp = self.createNextReservationFromList(availSlots, userId, filterList, resData)
		
		return resp


	def testScheduleSlots(self, scheduleId, startDateTime = None, endDateTime=None, resourceId = None):
		params = {'startDateTime': startDateTime, 'endDateTime': endDateTime, 'resourceId': resourceId}
		result = requests.get(self.slotsUrl % (scheduleId), params=params, headers=self.headers)
		#print(result.text)
		#sys.exit()
		try:
			jResult = result.json()
		except ValueError:
			jResult = None
	
		if result.status_code == 500:
			jResult = result.text				
		return result.status_code, result.url, jResult	


	def getGroups(self, **kwargs):
		url = self.groupsUrl
		
		resp = self.request('GET', url)
		#resp = self.request('GET', "https://myhealthplanmarkets.appointment.works/Web/Services/Reservations/543d71f499122293354094")
		if 'groups' in resp:
			if len(kwargs):
				#dbgprint(resp, isJson = True)
				resp['groups'] = getJsonEntries(resp['groups'], **kwargs)		

		return resp

	def getGroup(self, groupId):
		url = self.groupsUrl + str(groupId)
		
		resp = self.request('GET', url)
		#resp = self.request('GET', "https://myhealthplanmarkets.appointment.works/Web/Services/Reservations/543d71f499122293354094")

		return resp

		

if __name__ == '__main__':
	pass
