from berowrawatersinn.kitchen.models import *
from berowrawatersinn.website.admin import CommonPageAdmin
from django.contrib import admin

class KitchenPageAdmin(CommonPageAdmin):
    list_display = CommonPageAdmin.list_display + ['is_landing']
    
admin.site.register(KitchenPage, KitchenPageAdmin)