jQuery(document).ready(function() {
	jQuery('input[value]').each(function(){
		if(this.type == 'text' || this.type == 'password') {
			jQuery(this).focus(function(){ if (this.value == this.defaultValue) { this.value = ''; }
			}).blur(function(){ if (!this.value.length) { this.value = this.defaultValue; }});
		}
	});
	jQuery('textarea').each(function(){
		jQuery(this).focus(function(){ if (this.value == this.defaultValue) { this.value = ''; }
		}).blur(function(){ if (!this.value.length) { this.value = this.defaultValue; }});
	});
	jQuery(".su-dropdown-parent").hover(function(){
		jQuery(this).children(".su-dropdown").toggleClass("su-active");
		jQuery(this).children(".su-name").toggleClass("su-current");
	},function(){
		jQuery(this).children(".su-dropdown").toggleClass("su-active");
		jQuery(this).children(".su-name").toggleClass("su-current");
	});
});
