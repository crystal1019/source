DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'recipedropdb',
        'USER': 'recipedropdb',
        'PASSWORD': 'Recipedrop_123#',
        'HOST': 'recipedropdb.ciceu6r0zyfj.us-west-2.rds.amazonaws.com',
        'PORT': '',
    }
}

ROOT_URLCONF = 'urls'
#LIVE = False
