from gdata.spreadsheet import service


def connect_to_google(username=None, password=None):
    gd_client = service.SpreadsheetsService()
    gd_client.email = username or 'remotenoelp@gmail.com'
    gd_client.password = password or 'Nov261983'
    gd_client.source = 'moneychoices.com.au'
    gd_client.ProgrammaticLogin()
    
    return gd_client

def get_sheet_rows(doc_name, *args, **kwargs):
    """
    Returns list of rows where each row contains a dictionary.
    Ex. [
        {'col1': 'val1a', 'col2': 'val1b'}, 
        {'col1': 'val2'}, 
        {'col1': 'val3'}
        ]
    """  
    q = service.DocumentQuery()
    q['title'] = doc_name
    q['title-exact'] = 'true'
    
    gd_client = connect_to_google(*args, **kwargs)
    feed = gd_client.GetSpreadsheetsFeed(query=q)
    spreadsheet_id = feed.entry[0].id.text.rsplit('/',1)[1]
    feed = gd_client.GetWorksheetsFeed(spreadsheet_id)
    worksheet_id = feed.entry[0].id.text.rsplit('/',1)[1]
    
    rows = gd_client.GetListFeed(spreadsheet_id, worksheet_id).entry

    new_rows = []
    for row in rows:
        new_row = {}
        for key, content in row.custom.iteritems():
            new_row[key] = content.text
        new_rows.append(new_row)
    return new_rows


if __name__=='__main__':
    result = get_sheet_rows('Pro and Con offers', 'remotenoelp@gmail.com', 'Nov261983')
    import code; code.interact(local=locals())