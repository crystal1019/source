from django.conf import settings
from django.core.management.base import BaseCommand
from offers.helpers.lead.helpers import EmailThread
from offers.core.models import Offer


class Command(BaseCommand):
    def handle(self, *args, **options):
        query = """
                SELECT o.id, o.title AS offer, CONCAT('/', c.slug, '/', o.slug, '.php') as url
                FROM core_category c
                  JOIN core_offer_category oc ON c.id = oc.category_id
                  JOIN (
                    SELECT MIN(oc.id) as id
                    FROM core_offer o
                      JOIN core_offer_category oc ON oc.offer_id = o.id
                      JOIN core_category c ON c.id = oc.category_id
                    GROUP BY o.id
                  ) AS pc ON pc.id = oc.id
                  JOIN core_offer o ON o.id = oc.offer_id
                WHERE c.slug != 'credit-cards'
                  AND c.slug != 'broadband'
                  AND c.slug != 'bank-accounts'
                  AND c.slug != 'loans'
                  AND c.slug != 'debit-cards'
                  AND c.slug != 'prepaid-cards'
                  AND c.slug != 'insurance'
                ORDER BY o.slug
            """
        queryset = Offer.objects.raw(query)
        if queryset:
            self.send_notice(queryset)
            
    def send_notice(self, offers):
        EmailThread(**{
            'name':'',
            'email': settings.REVIEW_MODERATOR,
            'sender':'team@creditcardcompare.com.au',
            'subject':'Info: Possible Erroneous URLs on CCC',
            'context':{'offers': offers},
            'template':'emails/wrong_urls.html'
        }).start()
