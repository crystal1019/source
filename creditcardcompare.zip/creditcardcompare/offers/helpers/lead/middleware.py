from models import Lead
from utils import batch_download

class DownloadMiddleware(object):
    def process_request(self, request):
        try:
            get_data = request.GET.copy()
            get_data.pop('download')
        except KeyError:
            return
        request.GET = get_data
        leads = Lead.objects.all()
        try:
            leads = leads.filter(date__gte=get_data['date__gte'],
                                 date__lte=get_data['date__lte'])
        except KeyError:
            pass
        batch_download(None, request, leads)
            
    def process_response(self, request, response):
        if '/lead/lead/' in request.build_absolute_uri():
            submit_btn = '<input type="submit" value="Apply filter" />'
            download_btn = '<input type="checkbox" name="download" />Download<br />'
            response.content = response.content.replace(
                                            submit_btn, 
                                            download_btn + submit_btn)
        return response