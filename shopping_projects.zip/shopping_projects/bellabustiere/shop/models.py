'''
@author: chaol
'''

from django.template import loader, Context

from django.db import models
from django.contrib.auth.models import User
import string
from random import shuffle
import httplib, urllib
from django.contrib.sites.models import Site
from bellabustiere.userprofile.models import UserType, Country
from django.core.mail import EmailMultiAlternatives
from django.db.models.signals import post_save,post_delete

from django.conf import settings
import math

import datetime

from mptt.models import MPTTModel, TreeForeignKey, TreeManager
from django.utils import simplejson
import re

from django.core.exceptions import ValidationError
from django.core.mail import send_mail

import random, string
from django.core.exceptions import ValidationError
from django.template.defaultfilters import slugify
from suds.client import Client
from suds.wsse import Security,UsernameToken
import base64
import urllib
import httplib2
import xml.dom.minidom
from bellabustiere.website.models import *
"""
this is to check if a user is wholesale
"""
def isWholesale(user):
    try:
        if user.is_active and user.get_profile().wholesale:
            return True 
    except:
        pass
    
    return False

def formatCurrency(amount):
    try:
        p = str(amount).split(".")
        if len(p[1]) < 2:
            p[1] = str(p[1])+str(0)
        elif len(p[1]) > 2:
            p[1] = str(p[1][:2])
        price = ".".join(p)
        return price
    except:
        return amount
    
class Brand(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    image = models.ImageField(upload_to="images/", blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    bottom_description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=False)
    is_landing = models.BooleanField(default=False)
    landing_title = models.ImageField(upload_to="images/", blank=True, null=True)
    priority = models.IntegerField(default=0)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    shipping_only_to = models.ManyToManyField(Country, blank=True, null=True, help_text='if empty, shipping will available to all countries.')
    sites = models.ManyToManyField(Site)
    
    def __unicode__(self):
        return self.name
    
    def check_slug(self):
        return self.slug + ','
    
    def get_absolute_url(self):
        return '/shop/collections/%s.html' %self.slug
    

    def first_letter(self):
        return self.name and self.name[0] or ''
    
    def getTopCategory(self):
        c = []
        products = Product.objects.filter(brand__id=self.id, price__gt=0, sites__id=settings.SITE_ID)
        for x in products:
            cat = x.category_now.all()
            for xx in cat:
                if xx.get_root() not in c:
                    c.append(xx)
                    
        c = list(set([x.get_root() for x in c]))
        c = sorted(c, key=lambda x:x.priority, reverse=True)
        return c

    def get_next_entry(self, collection=None):
        if collection:
            c = Collection.objects.get(slug=collection)
            all = c.pages.filter(sites__id=settings.SITE_ID,is_active=True,is_landing=False)
        else:
            all = Brand.objects.filter(sites__id=settings.SITE_ID,is_active=True,is_landing=False)
        all = [x.id for x in all]
        pp = all.index(self.id)
        return Brand.objects.get(id=all[pp+1]) if pp + 1 < len(all) else ''
    
    def get_previous_entry(self, collection=None):
        if collection:
            c = Collection.objects.get(slug=collection)
            all = c.pages.filter(sites__id=settings.SITE_ID,is_active=True,is_landing=False)
        else:
            all = Brand.objects.filter(sites__id=settings.SITE_ID,is_active=True,is_landing=False)
        all = [x.id for x in all]
        pp = all.index(self.id)
        return Brand.objects.get(id=all[pp-1]) if pp - 1 >= 0 else ''        
    
    class Meta:
        verbose_name = 'Collection page'
        verbose_name_plural = 'Collection pages'
        ordering = ('-priority',)
        
    
class Collection(models.Model):
    name = models.CharField(max_length=50)
    slug = models.SlugField()
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=False)
    priority = models.IntegerField(default=0)
    pages = models.ManyToManyField(Brand, limit_choices_to={'is_active':True, 'is_landing':False})
    
    def __unicode__(self):
        return self.name
    
    def get_absolute_url(self):
        return '/shop/collections/%s.html' %(self.slug)
    
    class Meta:
        ordering = ('-priority',)
    
    
class Activity(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    image = models.ImageField(upload_to="images/", blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    bottom_description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=False)
    is_landing = models.BooleanField(default=False)
    landing_title = models.ImageField(upload_to="images/", blank=True, null=True)
    priority = models.IntegerField(default=0)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    sites = models.ManyToManyField(Site)    
    
    def __unicode__(self):
        return self.name
    
    def check_slug(self):
        return self.slug + ','
    
    def get_absolute_url(self, *args, **kwargs):
        return '/shop/activity/%s.html' %self.slug
    
    class Meta:
        verbose_name_plural = 'Activities'
        ordering = ('-priority',)
    
class CategoriesManager(TreeManager):
    def get_all_categories_by_product(self,product):
        c = product.category_now.all()
        l = []
        for x in c:
            l += list(x.get_ancestors())
        return list(set(l)) + list(c)
    
    def get_all_leaf_nodes(self):
        return Categories.objects.filter(sites__id=settings.SITE_ID,is_active=True).filter(lft=models.F('rght')-1)
    

class Categories(MPTTModel):
    parent = TreeForeignKey('self', blank=True, null=True, related_name='children')
    name = models.CharField(max_length=255)
    slug = models.SlugField(blank=True, null=True, unique=True)
    image = models.ImageField(upload_to="images/",blank=True,null=True)
    description = models.TextField(blank=True, null=True)
    bottom_description = models.TextField(blank=True, null=True)
    is_landing = models.BooleanField(default=False)
    landing_title = models.ImageField(upload_to="images/", blank=True, null=True)
    priority = models.IntegerField(default=0, help_text="Used to control ordering of categories, higher numbers show higher in the list")
    is_active = models.BooleanField(default=False)
    meta_keywords = models.CharField(max_length=255, blank=True,default='')
    meta_description = models.TextField(blank=True,default='')
    sites = models.ManyToManyField(Site)
    objects = CategoriesManager()
    '''def __unicode__(self):
        if self.parent:
            return str(self.parent) + " > " + self.name
        return self.name'''
    
    def __unicode__(self):
        return u'%s' % self.name
    
    def check_slug(self):
        return self.slug + ','
    
    def clean(self):
        landing = Categories.objects.filter(is_landing=True)
        if self.parent in landing:
            raise ValidationError('Landing cannot be parent of any categories.')
      
        if self.is_landing and self.parent:
            raise ValidationError('Landing can not have parent categories')

    def getFullPath(self):
        return ' --> '.join([x.name for x in self.get_ancestors()] + [self.name])
    
    def getMostPop(self):
        allleaf = self.get_all_leaf()
        try:
            return Product.objects.filter(category_now__in=allleaf,sites__id=settings.SITE_ID,status__display_to_user=True,price__gt=0 )[:1].get()
        except:
            try:
                return Product.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True,price__gt=0 )[:1].get()
            
            except:
                return ''
            
    def getActiveChildren(self):
        return self.get_children().filter(is_landing=False, is_active=True, sites__id=settings.SITE_ID)
    
    def getName(self):
        return self.__unicode__()
    def geturl(self):
        if  not self.get_children():
            
            if self.slug:
                return "/shop/%s/" % self.slug
            else:
                return "/shop/%s/" % self.id
        
        return "javascript:void()"
    
    def getlandingurl(self):
        if self.slug:
            return "/shop/%s/" % self.slug
        else:
            return "/shop/%s/" % self.id
        
    def get_absolute_url(self, nav='catalogue',designer=None):
        if not designer:
            return '/shop/%s/%s.html' %(nav, self.slug)
        else:
            return '/shop/designer/%s/%s.html' %(designer.slug, self.slug)    
        
    def get_all_leaf(self):
        return self.get_descendants(include_self=True).filter(lft=models.F('rght')-1)
            
    def save(self, **kwargs):
        if self.parent == self:
            self.parent = None
        
        super(Categories,self).save()
            
    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['-priority',]
        
    class MPTTMeta:
        order_insertion_by = ['name']
        ordering = ['-priority',]
        
class SaleManager(models.Manager):
    #will keep checking the sale of one product, and find the price with the highest disocunt and its sale id.
    def get_discount(self, product, order,time, wholesale):
        time = datetime.datetime.now() if not time else time
        categories = Categories.objects.get_all_categories_by_product(product)
        sales = Sale.objects.filter(category__in=categories, start__lte=time, end__gt=time, sites__id=settings.SITE_ID)
        sales_nocat = Sale.objects.filter(category__isnull=True, start__lte=time, end__gt=time, sites__id=settings.SITE_ID)
        sales = list(sales) + list(sales_nocat)
        saleid =  0
        highest = 0
        for x in sales:
            if x.brand and x.activity and x.brand in product.brand.all() and x.activity in product.activity.all():
                quantity = order.getQuantityBySale(x.category, brand=x.brand, activity=x.activity)
            elif x.brand and not x.activity and x.brand in product.brand.all():
                quantity = order.getQuantityBySale(x.category, brand=x.brand)
            elif x.activity and not x.brand and x.activity in product.activity.all():
                quantity = order.getQuantityBySale(x.category, activity=x.activity)
            elif not x.brand and not x.activity:
                quantity = order.getQuantityBySale(x.category)
            else:
                quantity = 0
            
            sb = x.salebased_set.get_discount(x,quantity,wholesale)
            saleid = x.id if sb > highest else saleid
            highest = sb if sb > highest else highest
            
        sitewide = Sale.objects.filter(category__isnull=True, brand__isnull=True, activity__isnull=True)
        if sitewide:
            sitewide = sitewide[0]
            sitequantity = order.getTotalItems()
            sd = sitewide.salebased_set.get_discount(sitewide,sitequantity,wholesale)
            saleid = sitewide.id if sd > highest else saleid
            highest = sd if sd > highest else highest
            
        
        price = (100 - highest) * float(product.getNormalPrice(wholesale)) / 100.0 
            
        return formatCurrency(price), highest, saleid

class Sale(models.Model):
    category = models.ForeignKey(Categories, blank=True, null=True)
    brand = models.ForeignKey(Brand, blank=True, null=True)
    activity = models.ForeignKey(Activity, blank=True, null=True)
    message = models.CharField(max_length=255, blank=True, null=True)
    wholesale_message = models.CharField(max_length=255, blank=True, null=True, editable=False)
    priority = models.IntegerField(default=0)
    start = models.DateTimeField()
    end = models.DateTimeField()
    sites = models.ManyToManyField(Site)
    objects = SaleManager()
    
    def __unicode__(self):
        return 'Site Wide' if not self.category and not self.brand and not self.activity else "%s - %s - %s" %(self.category, self.brand, self.activity )
    
    def clean(self):
        check = ['category', 'brand', 'activity']
        checkstring = {}
        for x in check:
            if eval('self.%s' % x):
                checkstring[x] = self.category
            else:
                checkstring['%s' %(x+'__isnull')] = True
            
       
        same = Sale.objects.filter(**checkstring)
        
        if same:
            raise ValidationError('The sale with the same Category, Brand, Activity already Exists')
            

    class Meta:
        unique_together =(("category", "brand", "activity"),)
    
class SaleBasedManager(models.Manager):
    #will get the discount of a sale based on quantity and user type
    def get_discount(self, sale, quantity, wholesale):
        off = 0
        all = SaleBased.objects.filter(sale=sale, quantity__lte=quantity).order_by('quantity')
        if all:
            one = list(all)[-1]
            off = one.wholesale_off if wholesale else one.off
            
        return off
                
    
class SaleBased(models.Model):
    sale = models.ForeignKey(Sale)
    quantity = models.IntegerField()
    off = models.FloatField()
    wholesale_off = models.FloatField(default=0.0, editable=False)
    objects = SaleBasedManager()
    
    def __unicode__(self):
        return self.sale.__unicode__()
    
    class Meta:
        ordering = ['sale', 'quantity']

class TaxRate(models.Model):
    name = models.CharField(max_length=255)
    rate = models.FloatField()
    countries = models.ManyToManyField(Country)
    is_default = models.BooleanField()
    def __unicode__(self):
        return self.name+" "+str(self.rate)

class ShippingDiscount(models.Model):
    name = models.CharField(max_length=255)
    off = models.FloatField(default=0,help_text='%')
    country = models.ForeignKey(Country,null=True,blank=True,editable=False)
    def __unicode__(self):
        return self.name
    def getRatio(self):
        return float(100-self.off)/float(100)


#currently allow multiple methods for each country
class ShippingManagement(models.Model):
    name = models.CharField(max_length=255)
    api = models.CharField(max_length=50, verbose_name='method', choices=(("aupost", "Australia Post(api)"),('fixed','Fixed Shipping'),('weight','Weight Based'),('price','Price Based',)))
    free_shipping = models.FloatField(blank=True,null=True,help_text='shipping free if total amount(inc gst) above the value here')
    minimum_shipping = models.FloatField(blank=True,null=True,help_text='minimum shipping price allowed')
    maximum_shipping = models.FloatField(blank=True,null=True, help_text='maximum shipping price allowed')
    fixed_shipping = models.FloatField(blank=True,null=True,help_text='if value here, shipping will always be this amount no matter what the method is')
    countries = models.ManyToManyField(Country)
    wholesale = models.BooleanField(default=False,editable=False)
    
    
    def __unicode__(self):
        return self.name
    
    def getBasePrice(self,num):

        for x in self.shippingbased_set.all():
            if num >= x.range_from and num <= x.range_to:
                return x
            
    def display_countries(self):
        return ','.join([x.country for x in self.countries.all()])

class ShippingBased(models.Model):
    shipping = models.ForeignKey(ShippingManagement)
    range_from = models.FloatField(help_text='weight(g), price($)')
    range_to = models.FloatField(help_text='weight(g), price($)')
    amount = models.FloatField(help_text='$')
    
    def __unicode__(self):
        return self.shipping.name
    
    class Meta:
        ordering = ['shipping', 'range_from']  
        verbose_name = 'Shipping range'
    
class Size(models.Model):
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=50, unique=True,help_text="This will be appended to the product (eg. XL)")
    def __unicode__(self):
        return self.name
    
    def check_slug(self):
        return self.code + ','

class Style(models.Model):
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=100, unique=True,help_text="This will be appended to the product (eg. BLACK)")
    brand = models.ForeignKey(Brand, null=True, blank=True)
    color = models.CharField(max_length=7, blank=True, null=True, help_text="Please insert color hex value here e.g. #000000")
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    def __unicode__(self):
        return self.name
    
    def check_slug(self):
        return self.code + ','
    
    def show_color(self):
        return '''<div id='%s' style='background:url(%s) no-repeat center center;width:18px;height:18px;'></div>''' %(self.code, self.image.url) if self.image else '''<div id='%s' style='background:%s;width:18px;height:18px'> </div>''' %(self.code, self.color) if self.color else 'pending'
    show_color.allow_tags = True
    
    def show_color_filter(self):
        return '''<div id='%s' style='background:url(%s) no-repeat center center;' class='colour-select'></div>''' %(self.code, self.image.url) if self.image else '''<div id='%s' style='background:%s;' class='colour-select'> </div>''' %(self.code, self.color) if self.color  else 'pending'

class SizeGroup(models.Model):
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=50, unique=True, null=True)
    size = models.ManyToManyField(Size)
    priority = models.IntegerField(default=0)   
    
    def __unicode__(self):
        return self.name
         
    def check_slug(self):
        return self.code + ','    
class StyleGroup(models.Model):
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=50, unique=True, null=True)
    styles = models.ManyToManyField(Style)
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return self.name
    def check_slug(self):
        return self.code + ','
class Set(models.Model):
    set = models.IntegerField(default=0, unique=True)
    def __unicode__(self):
        return str(self.set)
    
class ProductStatus(models.Model):
    status = models.CharField(max_length=50)
    display_to_user = models.BooleanField(default=True)
    can_buy = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    def __unicode__(self):
        return self.status
    class Meta:
        verbose_name_plural = "Product Status"

class Product(models.Model):
    title = models.CharField(max_length=255)
    code = models.SlugField('sku', unique=True)
    description = models.TextField(help_text="Maximum of 600 characters")
    details = models.TextField(blank=True, null=True)
    size_fit = models.TextField(blank=True, null=True)
    delivery_return = models.TextField(blank=True, null=True)
    price = models.FloatField("Retail price", default=0.00, help_text="If price is 0.00 then it will be unavailable to retail customers")
    wholesale_price = models.FloatField("Wholesale tax free price", default=0.00, help_text="If price is 0.00 then it will be unavailable to wholesalers", editable=False)
    minimum_quantity = models.IntegerField(default=1)
    minimum_quantity_wholesale = models.IntegerField(default=1, editable=False)
    maximum_quantity = models.IntegerField(default=20)
    maximum_quantity_wholesale = models.IntegerField(default=20, editable=False)
    tax_rate = models.ForeignKey(TaxRate, blank=True, null=True, related_name="retail_tax")
    wholesale_tax_rate = models.ForeignKey(TaxRate, blank=True, null=True, related_name="wholesale_tax", editable=False)
    sets = models.ManyToManyField(Set, blank=True,null=True, through='ProductSetPrice')
    category_now = models.ManyToManyField(Categories, limit_choices_to={'lft': models.F('rght')-1})
    brand = models.ManyToManyField(Brand)
    activity = models.ManyToManyField(Activity)
    shipping_only_to = models.ManyToManyField(Country, blank=True, null=True, help_text='if empty, shipping will available to all countries. This one have higher priority than "Shipping only to" in Brand')
    sites = models.ManyToManyField(Site, default=Site.objects.all())
    status = models.ForeignKey(ProductStatus, null=True)
    is_new = models.BooleanField(default=False)
    sibling_products = models.ManyToManyField('self', related_name='siblings', blank=True, null=True)
    related_products = models.ManyToManyField('self', blank=True, null=True)
    related_look = models.ManyToManyField('self', blank=True, null=True, related_name='relatedlook')
    weight = models.IntegerField(default=1, help_text="the weight of the product in grams")
    length = models.FloatField(default=1, help_text="the length of the product in cm")
    width =  models.FloatField(default=1, help_text="the width of the product in cm")
    height =  models.FloatField(default=1, help_text="the height of the product in cm")
    priority = models.IntegerField(default=0)
    meta_keywords = models.CharField(max_length=255,blank=True,null=True)
    meta_description = models.TextField(blank=True,null=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    enquiry = models.TextField(blank=True, null=True, editable=False, default='')
    class Meta:
        ordering = ['-priority','-created','code']

    
    def __unicode__(self):
        return self.code+" "+self.title
    
    def shipping_countries(self):
        result = self.get_shipping_only_country()
        if result:
            return ','.join(result)
        
        return 'All Shipping Countries'
    
    def get_shipping_only_country(self):
        brand = self.getBrand()
        if self.shipping_only_to.all():
            return [x.country for x in self.shipping_only_to.all()]
        elif brand  and brand.shipping_only_to.all():
            return [x.country for x in brand.shipping_only_to.all()]
        
        return ''
        
    def get_previous_entry(self, category=None, brand=None, activity=None):
        try:
            return self.get_previous_by_created(sites__id=settings.SITE_ID,status__display_to_user=True, category_now__id=category.id) if category else self.get_previous_by_created(sites__id=settings.SITE_ID,status__display_to_user=True) 
        except:
            return None
    def get_next_entry(self, category=None, brand=None, activity=None):
        try:
            return self.get_next_by_created(sites__id=settings.SITE_ID,status__display_to_user=True, category_now__id=category.id) if category else self.get_next_by_created(sites__id=settings.SITE_ID,status__display_to_user=True)
        except:
            return None
    
    def geturl(self):
        return "javascript:showproduct('%s')" % self.code
    
    def get_related_products(self):
        return self.related_products.filter(status__display_to_user=True, price__gt=0).distinct()
    
    def get_sibling_products(self):
        return self.sibling_products.filter(status__display_to_user=True,price__gt=0).distinct()
    
    def get_related_look(self):
        return self.related_look.filter(status__display_to_user=True,price__gt=0).distinct()
    
    def get_absolute_url(self):
        return '/shop/product/%s/%s.html' %(self.code, slugify(self.title))
    
    def get_pop_url(self):
        return '/shop/productlanding/%s.html' %self.code
    
    def getRange(self, size=None, color=None):
        if size and color:
            try:
                inventory = self.productsizecolor_set.filter(size=size,style=color)[0]
            except:
                inventory = ''
            
            if inventory and inventory.inventory and inventory.inventory < self.maximum_quantity and inventory.inventory > 0:
                the_range = range(self.minimum_quantity,inventory.inventory+1,1)
            elif inventory and inventory.inventory <= 0:
                the_range = ''
            else:
                the_range = range(self.minimum_quantity,self.maximum_quantity+1,1)
        else:
            the_range = range(self.minimum_quantity,self.maximum_quantity+1,1)
        return the_range
    
    
    def getWholesaleRange(self):
        the_range = range(self.minimum_quantity_wholesale,self.maximum_quantity_wholesale+1,1)
        return the_range  
    
    def getOneCategory(self):
        return self.category_now.all()[0] if self.category_now.all() else ''
    
    def getCategory(self):
        a = []
        categories = self.category_now.all()
        for x in categories:
            a.append(unicode(x))
        
        return ', '.join(a)
    
    def getBrand(self):
        try:
            return self.brand.all()[0]    
        except:
            return ''
    def getActivity(self):
        a = []
        activity = self.activity.all()
        for x in activity:
            a.append(unicode(x))
        
        return ', '.join(a)            
        
    def getWholesaleTax(self):
        if self.wholesale_tax_rate == None:
            return 1
        else:
            return self.wholesale_tax_rate.rate
    def getTax(self):
        if self.tax_rate == None:
            return 1
        else:
            return self.tax_rate.rate
    
    def getNormalPrice(self, wholesale=False):
        if not wholesale:
            return formatCurrency(self.price)
        else:
            return formatCurrency(self.wholesale_price)

    #Suppose different size and style for 1 product is all the same (even later at most only one of them could have a different price and should be in the condition of styles and size are dependent of each other )
    def getCurrentRightPrice(self,quantity,wholesale,couponcode,time=None):
        tt = time

        r = Coupon.objects.get_coupon(couponcode,tt)
    
        unit_price = ProductSetPrice.objects.get_price(wholesale,self,quantity)
        
        unit_normal_price = float(self.getNormalPrice(wholesale))
        
        unit_price_off = (1-unit_price/unit_normal_price) * 100 if unit_normal_price != 0 else 0
        
        off_percentage, discountid = DiscountPrice.objects.get_price(self,wholesale,r,tt)
        
        discountid = 0 if unit_price_off > off_percentage else discountid
        
        off_percentage = unit_price_off if unit_price_off > off_percentage else off_percentage
        
        realprice = (100.0-off_percentage) * unit_normal_price / 100.0
        
        if realprice == 0:
            return formatCurrency(unit_normal_price), 0, 0
        
        return formatCurrency(realprice), off_percentage, discountid

                
    def getTaxFreePrice(self,quantity, wholesale,coupon,time=None, currency='AUD'):
        price, off_percentage, discountid = self.getCurrentRightPrice(quantity,wholesale,coupon,time)
        return formatCurrency(price), off_percentage, discountid

    def getRelatedProducts(self, wholesale=False):
        # this needs to be filtered further for permissions
        products = self.related_products.distinct().filter(sites__pk=settings.SITE_ID, status__display_to_user=True,category_now__is_active=True)
        if wholesale:
            products = products.filter(wholesale_price__gt=0)
        else:
            products = products.filter(price__gt=0)
        p = list(products)
        shuffle(p)
        return p
    
    def getFeaturedImage(self):
        featured = self.productimage_set.filter(is_featured_image=True)
        try:
            if featured:
                return featured[0].image
            else:
                return self.getImages()[0].image
        except:
            return None
        
        
    def getImages(self):
        return self.productimage_set.all()
    
    def getHoverImage(self):
        try:
            return self.getImages()[1].image
        except:
            return ''
    
    def getAllSize(self):
        psc = self.productsizecolor_set.all()
        sizes = [x.size for x in psc]
        return list(set(sizes))
    
    def getAllSizeSelect(self):
        psc = self.productsizecolor_set.filter(inventory__gt=0).order_by('-priority', 'id')
        sizes = [x.size for x in psc]
        return list(sizes)        
    
    def getAllColor(self):
        psc = self.productsizecolor_set.all()
        colors = [x.style for x in psc]
        return list(set(colors))
    
    def getColorSwatch(self):
        try:
            psc = self.productsizecolor_set.all()
            return psc[0].style
        except:
            return ''
    
    #used for search(partial search)
    def get_all_content(self):
        return "%s %s %s %s %s %s" %(self.title, self.code, self.description, ' '.join([x.name for x in self.category_now.all()]), ' '.join([x.name for x in self.brand.all()]), ' '.join([x.name for x in self.activity.all()]) )

    #it will add the email address into enquiry field using the same format.
    def add_to_enquiry(self, name,email):
        if not self.enquiry:
            self.enquiry = name.strip() + '|' + email.strip() + ','
        else:
            self.enquiry = self.enquiry + name.strip() + '|' + email.strip() + ','
        self.save()
        
        return 1
    
    #for every email addresses saved in enquiry, send an email indicate product is in stock now.
    def send_instock_email(self):
        emails = self.enquiry.split(',')
        num = 0
        sent = []
        for x in emails:
            try:
                if x.strip():
                    name, email = x.split('|')
                    if email.strip() and email.strip() not in sent:
                        msg = """Hi %s,

We are pleased to let you know that the %s (%s) is now back in stock and available for sale. Hurry back to our website (http://%s%s) to avoid missing out.

If you have any questions or comments, please contact us via customer@bellabustiere.com or call our team during office hours.


Kind regards
Bella Bustiere Team
                        
                        """ %(name, self.title, self.code, settings.DOMAIN,self.get_absolute_url()) 
                        try:
                            send_mail("Bella Bustiere - Your Pre-Reserved Item is Now Back in Stock and Available", msg, 'no-reply@bellabustiere.com.au', [email.strip()], fail_silently=False)
                            num += 1
                            sent.append(email.strip())
                        except:
                            pass
            except:
                pass
        return num

    #if productstatus change from out_of_stock to available, each email address saved in enquiry will get an email. after email sent, enquiry field will be empty again
    def save(self, *args, **kwargs):
        if self.id:
            try:
                origin = Product.objects.get(id=self.id)
                if self.status != origin.status:
                    if not origin.status.can_buy and self.status.can_buy:
                        self.send_instock_email()
                        self.enquiry = ''
            except:
                pass
            
        try:
            from bellabustiere.vendapi import *
            vend = VendAPI()
            vend.update_price_to_vend(self)
        except:
            pass
                    
        super(Product, self).save(*args, **kwargs)
        
class ProductReview(models.Model):
    RATE_CHOICES = [(str(x), str(x)) for x in xrange(1,6)]
    product = models.ForeignKey(Product)
    star = models.CharField(max_length=10, choices=RATE_CHOICES, null=True)
    first_name = models.CharField(max_length=40)
    last_name = models.CharField(max_length=40)
    comment = models.TextField()
    is_active = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    ip = models.CharField(max_length=50, blank=True, null=True)
    
    def __unicode__(self):
        return self.product.title
    
    def getPercentage(self):
        return '%.2f%%' %(int(self.star)/5.0*100)
    
class ProductSizeColor(models.Model):
    product = models.ForeignKey(Product)
    size = models.ForeignKey(Size)
    style = models.ForeignKey(Style)
    inventory =  models.IntegerField(blank=True,null=True, help_text="leave it empty if inventory is not important for the product")
    sku = models.CharField(max_length=50, blank=True, null=True)
    priority = models.IntegerField(default=0)
    
    def __unicode__(self):
        return ' -- '.join([self.product.title, self.size.name, self.style.name])
    
    def color_check(self):
        return '''<a href='/admin/shop/style/' target='_blank'>color check</a>'''
     
    color_check.allow_tags = True
    
    
    def save(self,*args,**kwargs):
        vend = kwargs.get('vend',True)
        if 'vend' in kwargs.keys():
            kwargs.pop('vend')
        super(ProductSizeColor, self).save(*args, **kwargs)
        if vend:
            try:
                from bellabustiere.vendapi import *
                vend = VendAPI()
                vend.import_to_vend(list=[self])
            except:
                pass               
        
        '''if self.id:
            oldpsc = ProductSizeColor.objects.get(id=self.id)
            inventory = oldpsc.inventory
            if self.inventory != inventory and self.inventory > inventory or not inventory and self.inventory:
                super(ProductSizeColor, self).save(*args, **kwargs)
                try:
                    from bellabustiere.vendapi import *
                    vend = VendAPI()
                    vend.import_to_vend(list=[self])
                except:
                    pass  

        else:
            super(ProductSizeColor, self).save(*args, **kwargs)
            try:
                from bellabustiere.vendapi import *
                vend = VendAPI()
                vend.import_to_vend(list=[self])
            except:
                pass               
        super(ProductSizeColor, self).save(*args, **kwargs)
        '''
    
    def delete(self, *args, **kwargs):
        try:
            from bellabustiere.vendapi import *
            vend = VendAPI()
            a = vend.delete_by_psc(self)
        except:
            pass              
    
        super(ProductSizeColor,self).delete(*args,**kwargs)
        
    class Meta:
        
        verbose_name = 'Stock Management'
        ordering = ['-priority', 'id']

class ProductImage(models.Model):
    product = models.ForeignKey(Product)
    image = models.ImageField(upload_to="images/")
    title = models.CharField(max_length=255, blank=True, null=True)
    is_featured_image = models.BooleanField(default=False, help_text="Use this as a featured image for a product", editable=False)
    style = models.ForeignKey(Style, blank=True, null=True)
    priority = models.IntegerField(default=0)
    def __unicode__(self):
        return self.product.title
    
    class Meta:
        ordering = ['-priority','id']
    

    

class ProductSetPriceManager(models.Manager):
    def get_price(self,wholesale,product,quantity):
        psp = product.productsetprice_set.all().order_by('-set__set')
        for x in psp:
            if quantity >= x.set.set:
                return x.wholesale_price if wholesale else x.price
            
        return product.wholesale_price if wholesale else product.price
        

class ProductSetPrice(models.Model):
    product = models.ForeignKey(Product)
    set = models.ForeignKey(Set)
    price = models.FloatField("Tax Free", default=0.00)
    wholesale_price = models.FloatField("Wholesale Price", default=0.00, editable=False)
    recommend = models.BooleanField(default=False)
    message = models.CharField(max_length=255)
    objects = ProductSetPriceManager()
    
    def __unicode__(self):
        return "%s - %s" %(self.product.title, self.set.set)

#TODO need to figure out how a normal package thing work
class PackageProduct(models.Model):
    product = models.ForeignKey(Product)
    quantity = models.IntegerField(default=1)
    def __unicode__(self):
        return self.status

class Package(models.Model):
    name = models.CharField(max_length=255)
    products = models.ManyToManyField(PackageProduct)
    
    def __unicode__(self):
        return self.name
############################################    

#this is voucher which will deduct money from total
class Voucher(models.Model):
    code = models.CharField(max_length=20, unique=True, blank=True,help_text='if this field is empty, code will be randomly generated')
    value = models.FloatField()
    valid = models.BooleanField(default=False, help_text='if this is not checked, this voucher will be invalid')
    valid_from = models.DateField(null=True)
    valid_to = models.DateField(null=True)
    repeat_use = models.BooleanField(default=False, help_text='if this is not checked, this voucher will be able to be used only once.')
    recipient = models.EmailField(blank=True, null=True)
    recipient_name = models.CharField(max_length=50, blank=True, null=True)
    recipient_title = models.CharField(max_length=255, blank=True, null=True)
    recipient_message = models.TextField(blank=True, null=True)
    send_date = models.DateField(blank=True, null=True)
    use_history = models.TextField(blank=True, null=True, editable=False)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    
    def __unicode__(self):
        return self.code
    
    def clean(self):
        try:
            c = Coupon.objects.get(codes=self.code)
            
        except:
            c = ''
        if c:
            raise ValidationError('This code is existed in Coupon System. Please Change.')

    def is_used(self):
        ov = self.order_set.filter(ordered__isnull=False)
        return True if ov else False
    is_used.boolean = True
    
    def is_valid(self, date=None):
        now = datetime.datetime.now() if not date else date
        checkdate = datetime.date(now.year,now.month,now.day)
        if checkdate >= self.valid_from and checkdate <= self.valid_to and self.valid:
            if not self.is_used() or self.is_used() and self.repeat_use or self.is_used() and self.current_value() > 0:
                return True
            
        
        return False
    is_valid.boolean = True
    
    def current_value(self):
        used = self.order_set.filter(ordered__isnull=False)
        used_value = sum([x.getVoucherValue() for x in used])
        if self.value - used_value < 0.01 and not self.repeat_use:
            return 0.0
        return self.value - used_value if not self.repeat_use else self.value
    
    def order_use_history(self):
        used = self.order_set.filter(ordered__isnull=False)
        return '<br>'.join(['''<a href='/admin/shop/order/%s/'>%s</a>: $%s''' %(x.id,x.getOrderNumber(), formatCurrency(x.getVoucherValue())) for x in used])
    order_use_history.allow_tags = True
    
    def send_email(self, order):
        t = loader.get_template('voucheremail.html')
        try:
            sitemeta = SiteMeta.objects.get(site__id=settings.SITE_ID)
        except:
            sitemeta = ''
        c = Context({'voucher':self, 'order':order, 'site_meta':sitemeta,})
        msg = t.render(c)

        email = EmailMultiAlternatives("Voucher on Bella Bustiere.com - %s" %self.recipient_title, msg, 'no-reply@bellabustiere.com', ['sales@bellabustiere.com',self.recipient],['dou8le@gmail.com'])
        email.attach_alternative(msg, "text/html")
        try:
            email.send()
        except:
            return 2
        return 1
    def getRandom(self, number):
        return ''.join(random.choice(string.letters + string.digits) for i in xrange(number))
    
    
    def getCurrentPrice(self):
        return self.value
    
    def getFeaturedImage(self):
        try:
            sitemeta = SiteMeta.objects.get(site__id=settings.SITE_ID)
        except:
            sitemeta = ''
        if sitemeta.voucher_page_image:
            return sitemeta.voucher_page_image    
                
        return ''
    
    def save(self, *args, **kwargs):
        if not self.code:
            repeat = True
            while(repeat):
                code = self.getRandom(8)
                pp = 0
                try:
                    v = Voucher.objects.get(code=code)
                except:
                    pp += 1
                try:
                    c = Coupon.objects.get(codes=code)
                except:
                    pp += 1
                
                if pp == 2:
                    repeat = False
            
            self.code = code
        now = datetime.datetime.now() if not self.send_date else self.send_date
        if not self.valid_to:
            
            self.valid_to = datetime.date(now.year+1,now.month,now.day)
            
        if not self.valid_from:
            self.valid_from = datetime.date(now.year,now.month,now.day) 
                   
        super(Voucher, self).save(*args, **kwargs)

#TODO need to figure out a generic coupon system, currently coupon in DiscountPrice
class CouponManager(models.Manager):
    def get_coupon(self,code,time=None):
        if code:
            now = datetime.datetime.now() if not time else time
            allcoupon = Coupon.objects.all()
            for x in allcoupon:
                dps = x.discountprice_set.filter(start__lte=now, end__gt=now,coupon=x)
                if x.codes and code and x.codes.strip() == code.strip() and dps:
                    return x
            
        return None
    
    def coupon_available(self):
        now = datetime.datetime.now()
        allcoupon = Coupon.objects.all()
        for x in allcoupon:
            dps = x.discountprice_set.filter(start__lte=now, end__gt=now,coupon=x)
            if dps:
                return True
        return False
            
class Coupon(models.Model):
    name = models.CharField(max_length=255,unique=True)
    number = models.IntegerField(editable=False,blank=True,null=True)
    codes = models.CharField(max_length=255, unique=True)
    used = models.TextField(editable=False,blank=True,null=True)
    #start = models.DateTimeField(default=datetime.datetime.now(),help_text="all products in this coupon's discount will start from this field")
    #end = models.DateTimeField(default=datetime.datetime.now(),help_text="all products in this coupon's discount will end from this field")
    objects = CouponManager()
    
    def __unicode__(self):
        return self.name
    
    def clean(self):
        try:    
            v = Voucher.objects.get(code = self.codes)
        except:
            v = ''
        if v:
            raise ValidationError('This code is exsiting in Voucher System, please Change')

    
    def checkCode(self,code):
        now = datetime.datetime.now()
        dps = self.discountprice_set.filter(start__lte = now, end__gt = now,coupon=self)
        if self.codes.strip()==code.strip() and dps:
            return True
        return False
    
    '''def addUsed(self,code):
        if self.used:
            used = self.used.split(',')
        else:
            used = []
        used.append(code)
        self.used = ','.join(used)
        self.save()
        
    def save(self):
        if not self.codes:
            
            self.codes = getRandom(self.number)
        else:
            length = len(self.codes.split(','))
            if length < self.number:
                number = self.number - length
                self.codes = getRandom(number,self.codes.split(','))
            else:
                if self.used:
                    temp = [x for x in self.codes.split(',') if x not in self.used.split(',')]
                    self.codes = ','.join((self.used.split(',')+temp)[:self.number])
                else:
                    self.codes=','.join(self.codes.split(',')[:self.number])
                
        super(Coupon,self).save()'''
###########################################################

#TODO need to interview
class DiscountPriceManager(models.Manager):
    def get_price(self,product,wholesale,coupon,time=None):
        now = datetime.datetime.now() if not time else time
        dp = DiscountPrice.objects.filter(product=product, start__lte=now, end__gt=now, coupon=coupon).order_by("-start") if coupon else DiscountPrice.objects.filter(product=product, start__lte=now, end__gt=now,coupon=None).order_by("-start")
        dpn = DiscountPrice.objects.filter(product=product, start__lte=now, end__gt=now,coupon=None).order_by("-start") if coupon else []

        dps = [(x.get_percentage(wholesale), x.id) for x in dp] if not dpn else [(x.get_percentage(wholesale), x.id) for x in dp] + [(x.get_percentage(wholesale), x.id) for x in dpn]
        if dps:    
            sort_result = sorted(dps, key=lambda x:x[0])
            percentage, id = sort_result[-1]
            return percentage, id
        return 0, 0
    
    def check_coupon(self,product,coupon,wholesale):
        now = datetime.datetime.now()
        dp = DiscountPrice.objects.filter(product=product, start__lte=now, end__gt=now, coupon=coupon).order_by("-start")
        if dp:
            dp = dp[0]
            if dp.get_percentage(wholesale) != 0:
                return True
        return False
    
    def getTopCategory(self):
        now = datetime.datetime.now()
        products = DiscountPrice.objects.filter(start__lte=now, end__gt=now,coupon=None).distinct()
        c = []
        for x in products:
            cat = x.product.category_now.all()
            for xx in cat:
                if xx.get_root() not in c:
                    c.append(xx)

        c = list(set([x.get_root() for x in c]))
        c = sorted(c, key=lambda x:x.priority, reverse=True)     
        return c
    
#coupon changed from manytomany to foreignkey field for unique_together
class DiscountPrice(models.Model):
    product = models.ForeignKey(Product)
    price = models.FloatField(default=0.0)
    wholesale_price = models.FloatField(default=0.0, editable=False)
    coupon = models.ForeignKey(Coupon, blank=True,null=True)
    start = models.DateTimeField(default=datetime.datetime.now())
    end = models.DateTimeField(default=datetime.datetime.now())
    objects = DiscountPriceManager()
    def __unicode__(self):
        return unicode(self.product)
    
    def getCategory(self):
        return self.product.getCategory()
    
    def getBrand(self):
        return self.product.getBrand()
    
    def getActivity(self):
        return self.product.getActivity()
    
    def getPrice(self, wholesale):
        return formatCurrency(self.wholesale_price) if wholesale else formatCurrency(self.price)
        
    def get_percentage(self,wholesale):
        if wholesale:
            if self.product.wholesale_price != 0:
                percentage = (1-float(self.wholesale_price)/float(self.product.wholesale_price)) * 100
            else:
                percentage = 0
        else:
            if self.product.price != 0:
                percentage = (1-float(self.price)/float(self.product.price)) * 100
            else:
                percentage = 0
        return percentage
            
            
    
    def priceoff(self):
        if self.product.price != 0:
            percentage = (1-float(self.price)/float(self.product.price)) * 100
        else:
            percentage = 0
        return "%.2f" % percentage + '%'
    #getCategory.admin_order_field = 'product__category_now'
    def wholesale_priceoff(self):
        if self.product.wholesale_price != 0:
            percentage = (1-float(self.wholesale_price)/float(self.product.wholesale_price)) * 100
        else:
            percentage = 0
        return "%.2f" % percentage + '%'
    
    def pricecut(self,wholesale):
        return self.wholesale_priceoff() if wholesale else self.priceoff
    
    def coupon_name(self):
        return self.coupon.name
    
    class Meta:
        unique_together = (('product','coupon'),)
    
    
###########################################################################        

            
#TODO In Progress, Ordered, Shipped must be created before it is function.          
class OrderStatus(models.Model):
    status = models.CharField(max_length=255)

    class Meta:
        verbose_name_plural = "Order Status"
    def __unicode__(self):
        return self.status


class Order(models.Model):
    METHOD_CHOICES = [['creditcard','Credit Card'],['paypal','PayPal'],['voucher','Paid in full by voucher']]
    SHIPPING_CHOICES = [['STANDARD', 'STANDARD'], ['EXPRESS', 'EXPRESS']]
    user = models.ForeignKey(User, blank=True, null=True)
    status = models.ForeignKey(OrderStatus)
    started = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    ordered = models.DateTimeField(blank=True,null=True)
    is_wholesale = models.BooleanField(default=False,editable=False)
    shipping_charged = models.FloatField(default=0.00)
    tax_charged = models.FloatField(default=0.00)
    total_charged = models.FloatField(default=0.00)
    paid_from_website = models.CharField(max_length=255,blank=True,default='')
    paid_from_otherway = models.FloatField(default=0.00)
    method = models.CharField("Pay method",max_length=100,blank=True,choices=METHOD_CHOICES)
    shipping_method = models.ForeignKey(ShippingManagement,editable=False,blank=True,null=True,help_text='if nothing chosen, Australia Post will be used')
    shipping = models.CharField(max_length=100, choices=SHIPPING_CHOICES, blank=True, null=True, editable=False)
    payment_term = models.CharField(max_length=255,blank=True,null=True,editable=False)
    tracking_number = models.CharField(max_length=255, blank=True,null=True)
    special_instruction = models.CharField(max_length=255, null=True,blank=True)
    site = models.ForeignKey(Site,null=True,blank=True)
    coupon = models.TextField(editable=False,blank=True, null=True)
    voucher = models.ForeignKey(Voucher,blank=True, null=True,)
    sync_order = models.BooleanField(default=True, help_text='sync this order with the current database, all prices will be set automatically on save')
    ip = models.CharField(max_length=20,blank=True, null=True)
    shipping_final = models.TextField(blank=True, null=True)
    billing_final = models.TextField(blank=True, null=True)
    def __unicode__(self):
        try:
            return self.getOrderNumber() + " " + str(self.user)+" "+str(self.started)+" price: $"+str(self.total_charged)+" items: "+str(self.getTotalItems())+" " 
        except:
            return "?"
    
    def coupon_code(self):
        po = self.productorder_set.all()
        for x in po:
            if x.coupon:
                return x.coupon
        
        return ''
    
    def get_shipping_only_countries(self):
        result = []
        for x in self.productorder_set.all():
            exclusive = x.product.get_shipping_only_country()
            if exclusive:
                result += exclusive
                
        return result
    
    def get_unavailable_shipping_items(self, country):
        result = []
        for x in self.productorder_set.all():
            exclusive = x.product.get_shipping_only_country()
            if exclusive and country not in exclusive:
                result.append(x.product)
                
        return result
    
    def getShippingWay(self):
        return self.shipping if self.shipping else "STANDARD"
        
    def coupon_used(self):
        return self.coupon_code()
        
    def getOrderNumber(self):
        initials = "SR"
        return initials+str(self.id).zfill(4)
    def formatNumber(self):
        initials = "SR"
        try:
            return initials+str(self.id).zfill(4)
        except Exception, e:
            return e
    def is_t_booked(self):
        tl = self.temandologging_set.all()
        if tl:
            tl = tl[0]
            if tl.consignmentDocument:
                return True
            
        return False
    
    def is_m_booked(self):
        ml = self.mailcalllogging_set.all()
        if ml:
            ml = ml[0]
            if ml.book_response:
                return True
        
        return False
        
    def getShippingCharged(self):
        return formatCurrency(self.shipping_charged)
    def getTaxCharged(self):
        return formatCurrency(self.tax_charged)
    def getTotalCharged(self):
        return formatCurrency(self.total_charged)
    def getTotalItems(self):
        try:
            return sum([x.quantity for x in self.productorder_set.all()]) + sum([x.quantity for x in self.voucherorder_set.all()])
        except:
            return 0
    def getTotalWeight(self):
        items = []
        for x in self.productorder_set.all():
            if x.product.weight:
                items.append(x.quantity*x.product.weight)
        return sum(items)
    def getTotalTaxFreePrice(self):
        try:
            price = sum([float(x.getUnitPrice())*float(x.quantity) for x in self.productorder_set.all()]) + sum([float(x.getUnitPrice())*float(x.quantity) for x in self.voucherorder_set.all()]) 
            return formatCurrency(price)
        except Exception:
            return 0
    def getTotalGST(self):

        try:
            price = sum([float(x.getTotalTax()) for x in self.productorder_set.all()]) + sum([float(x.getUnitPrice())*float(x.quantity) for x in self.voucherorder_set.all()])
            price = formatCurrency(price)
        except Exception:
            return 0
        return formatCurrency(float(price) - float(self.getTotalTaxFreePrice()))
    
    #this is the voucher value in this order
    def getVoucherValue(self):
        return float(self.getTotalTaxFreePrice()) + self.shipping_charged + self.tax_charged - self.total_charged

    def checkProductOrder(self):
        for x in self.productorder_set.all():
            try:
                pq = x.product.productsizecolor_set.filter(size=x.size,style=x.style)[0]
            except:
                pq = ''
            if pq and pq.inventory and pq.inventory < 0 or pq and pq.inventory == 0:
                return False
            
            elif pq and pq.inventory and pq.inventory < x.quantity:
                x.save()
            
        return True

    def getShippingMethod(self):
        if not self.productorder_set.all() and self.voucherorder_set.all():
            return 'Email'
        else:
            try:
                country = self.getProfileShipping().country.country
                if country.lower() == 'australia':
                    temando = self.temandologging_set.all()[0]
                    return temando.companyName
            except:
                return 'Standard'
            
        return 'Australia Post' 
   
    def getProfile(self):
        try:
            return self.user.get_profile()
        except:
            return None
    def getProfileShipping(self):
        try:
            return self.user.get_profile().shipping_set.all()[0]
        except:
            return None
    def getProfileBilling(self):
        try:
            return self.user.get_profile().billing_set.all()[0]
        except:
            return None
    def getProfileBillingO(self):
        if self.billing_final:
            try:
                return eval(self.billing_final)
            except:
                pass
        return self.getProfileBilling()
    
    def getProfileShippingO(self):
        if self.shipping_final:
            try:
                return eval(self.shipping_final)
            except:
                pass
        return self.getProfileShipping()        
    def getPostCode(self):
        shipping = self.getProfileShipping()
        return shipping.postcode if shipping else None
    
    def getPostCountry(self):
        shipping = self.getProfileShipping()
        return shipping.country.country if shipping else None        
        
    def getTotal(self):
        try:
            price = sum([float(x.getTotalTax()) for x in self.productorder_set.all()]) + sum([float(x.getUnitPrice())*float(x.quantity) for x in self.voucherorder_set.all()])
        except Exception:
            return 0
        
        return price
    
    def getTotalRetailGST(self):
        try:
            price = sum([float(x.getRetailTax()) for x in self.productorder_set.all()]) + sum([float(x.getRetailTax()) for x in self.voucherorder_set.all()])
        except Exception:
            return 0
        if price and self.shipping_charged and self.special_instruction:
            price += self.shipping_charged / 11.0
        return formatCurrency(float(price))        
    
    def getInitialPay(self):

        return self.getTotalCharged()
    
    def getPaidFromWebsite(self):
        return formatCurrency(sum([float(x) if x else 0.00 for x in self.paid_from_website.split(',')])) if self.paid_from_website else 0.00
    
    def getTotalPaid(self):
        return formatCurrency(self.paid_from_otherway + float(self.getPaidFromWebsite()))
   
    def getOwned(self):
        return formatCurrency(float(self.getTotalCharged()) - float(self.getTotalPaid()))

    def getQuantityBySale(self, category, brand=None, activity=None):
        leafc = category.get_all_leaf() if category else Categories.objects.get_all_leaf_nodes()
        if not brand and not activity:
            pos = self.productorder_set.filter(product__category_now__in = leafc)
        elif brand and not activity:
            pos = self.productorder_set.filter(product__category_now__in = leafc, product__brand__id=brand.id)
        elif activity and not brand:
            pos = self.productorder_set.filter(product__category_now__in = leafc, product__activity__id=activity.id)
        elif brand and activity:
            pos = self.productorder_set.filter(product__category_now__in = leafc, product__activity__id=activity.id, product__brand__id=brand.id)
        return sum([x.quantity for x in pos])
                
        
    def save(self, **kwargs):
        
        if self.user and isWholesale(self.user):
            self.is_wholesale = True
            
            if self.sync_order:

                self.tax_charged = float(self.getTotalGST())
                self.shipping_charged = float(getShippingCost(self,_wholesale=settings.WHOLESALE_SHIPPING))
                self.total_charged = float(self.getTotalGST()) + float(getShippingCost(self,_wholesale=settings.WHOLESALE_SHIPPING)) + float(self.getTotalTaxFreePrice()) 
                if self.voucher and self.voucher.is_valid():
                    total_charged = self.total_charged - self.voucher.current_value()
                    self.total_charged = 0.00 if total_charged < 0 else total_charged


        else:
            self.is_wholesale = False
            
            if self.sync_order:
                self.shipping_charged = float(getShippingCost(self))
                self.total_charged = self.getTotal()+ self.shipping_charged
                if self.voucher and self.voucher.is_valid():
                    total_charged = self.total_charged - self.voucher.current_value()
                    self.total_charged = 0.00 if total_charged < 0 else total_charged

        if self.id:
            origin = Order.objects.get(id=self.id)
            if self.status != origin.status:
                if self.user and (self.status.status == 'Shipped' or self.status.status == 'Cancelled'):
                    send_confirm_email(self)
                    
                '''elif self.user and self.status.status == 'Ship Ready':
                    result = payment_temando(self)
                    if result:
                        self.tracking_number = result.consignmentNumber'''

        super(Order, self).save()
        

class TemandoLogging(models.Model):
    order = models.ForeignKey(Order, unique=True)
    all_quotes = models.TextField(blank=True,null=True)   
    using_quote = models.TextField(blank=True, null=True)
    booking_quote = models.TextField(blank=True, null=True)
    book_info = models.TextField(blank=True, null=True)
    totalPrice = models.CharField(max_length=255, blank=True, null=True, editable=False)
    basePrice = models.CharField(max_length=255, blank=True, null=True, editable=False)
    tax = models.CharField(max_length=255, blank=True, null=True, editable=False)
    currency = models.CharField(max_length=255, blank=True, null=True, editable=False)
    deliveryMethod = models.CharField(max_length=255, blank=True, null=True, editable=False)
    etaFrom = models.CharField(max_length=255, blank=True, null=True, editable=False)
    etaTo = models.CharField(max_length=255, blank=True, null=True, editable=False)
    guaranteedEta = models.CharField(max_length=255, blank=True, null=True, editable=False)
    carrierId = models.CharField(max_length=255, blank=True, null=True, editable=False)
    companyName = models.CharField(max_length=255, blank=True, null=True)
    extras = models.TextField(blank=True, null=True, editable=False)
    requestID = models.CharField(max_length=255, blank=True, null=True)
    consignmentDocument = models.TextField(blank=True, null=True)
    labelDocument = models.TextField(blank=True,null=True)
    consignmentNumber = models.CharField(max_length=255, blank=True, null=True)
    def __unicode__(self):
        return str(self.order.id)
    
    def getAbsolutePath(self):
        return settings.MEDIA_ROOT + self.getFilePath()
    
    def getFilePath(self):
        return 'pdfs/%s.pdf' %self.order.id
    
    def get_file_url(self):
        return settings.MEDIA_URL + self.getFilePath()
    
    def writeToPdf(self,content):
        content = base64.b64decode(content)
        f = open(self.getAbsolutePath(), 'wb')
        f.write(content)
        f.close()
        
        return 1
        
class MailCallLogging(models.Model):
    order = models.ForeignKey(Order, unique=True)
    book_response = models.TextField(blank=True, null=True)
    status_response = models.TextField(blank=True, null=True)
    book_date = models.DateField(auto_now_add=True)
    lineno = models.CharField(max_length=50, blank=True, null=True)
    private_link = models.CharField(max_length=255, blank=True, null=True)
    bookings_link = models.CharField(max_length=255, blank=True, null=True)
    wintrack_link = models.CharField(max_length=255, blank=True, null=True)
    def __unicode__(self):
        return str(self.order.id)
    
    def show_private_link(self):
        return '''<a href='%s' target='_blank'>%s </a>''' %(self.private_link, self.private_link)
    show_private_link.allow_tags = True
    
    def show_bookings_link(self):
        return '''<a href='%s' target='_blank'>%s </a>''' %(self.bookings_link, self.bookings_link)
    show_bookings_link.allow_tags = True
    
    def show_wintrack_link(self):
        return '''<a href='%s' target='_blank'>%s </a>''' %(self.wintrack_link, self.wintrack_link)
    show_wintrack_link.allow_tags = True    
    
class ProductOrderManager(models.Manager):
    def get_total_quantity(self,order,product):
        return sum([x.quantity for x in order.productorder_set.filter(product=product)])
    

class ProductOrder(models.Model):
    order = models.ForeignKey(Order)
    product = models.ForeignKey(Product)
    quantity = models.IntegerField()
    price = models.FloatField("Unit Price", default=0.00)
    size = models.ForeignKey(Size, blank=True, null=True,)
    style = models.ForeignKey(Style, blank=True, null=True,)
    coupon = models.CharField(max_length=255,editable=False, blank=True, null=True)
    sale_applied = models.IntegerField(default=0, editable=False)
    discount_applied = models.IntegerField(default=0, editable=False)
    discount = models.FloatField(default=0.00, editable=False)
    objects = ProductOrderManager()
    
    def __unicode__(self):
        if self.order.is_wholesale:
            return "title: " + str(self.product.title)+" price: "+str(self.product.getTaxFreePrice(self.quantity,True,self.coupon)[0]) + " tax:" + str((float(self.product.getWholesaleTax())-1)*float(self.product.getTaxFreePrice(self.quantity,True,self.coupon)[0])) + " min qty:" + str(self.product.minimum_quantity_wholesale) + " max qty:" + str(self.product.maximum_quantity_wholesale)
        else:
            return "title: " + str(self.product.title)+" price:" +str(self.product.getTaxFreePrice(self.quantity,False,self.coupon)[0]) + " tax:" + str((float(self.product.getTax())-1)*float(self.product.getTaxFreePrice(self.quantity,False,self.coupon)[0]))+ " min qty:" + str(self.product.minimum_quantity) + " max qty:" + str(self.product.maximum_quantity)
    def code(self):
        s = self.product.code
        if self.size:
            s = s + "-%s" % self.size.code
        if self.style:
            s = s + "-%s" % self.style.code
        return s
    
    def getValume(self):
        valume = float(self.product.height*self.product.width*self.product.length)
        valume = float(valume * self.quantity)
        return valume
    
    def getRange(self):
        return self.product.getRange(size=self.size,color=self.style)
    
    def view_product(self):
        return "<a href='/admin/shop/product/%s/'>view product</a>" %self.product.id
    view_product.allow_tags = True
    
    def check_discount_price(self):
        return "<a href='/admin/shop/discountprice/?q=%s'>check this product in DiscountPrice</a>" %self.product.code
    check_discount_price.allow_tags=True
    
    def order_sale_applied(self):
        return "<a href='/admin/shop/sale/%s/'>sale applied, please check discount here</a>" %self.sale_applied if self.sale_applied else 'No sale applied'
    order_sale_applied.allow_tags = True
    
    def order_discount_applied(self):
        return "<a href='/admin/shop/discountprice/%s/'>product discount or coupon applied, please check discount here</a>" %self.discount_applied if self.discount_applied else "No discount applied"
    order_discount_applied.allow_tags = True
    check_discount_price.allow_tags=True
    
    def getCategory(self):
        category = self.product.getCategory()
        return category
    def getOrderNumber(self):
        return self.order.getOrderNumber()
    
    def getOrderStatus(self):
        return self.order.status
    
    def getUnitPrice(self):
        return formatCurrency(self.price)
    def getTotalTax(self):
        if self.order.is_wholesale:
            if self.product.wholesale_tax_rate != None and self.order.getProfileShipping() and self.order.getProfileShipping().country.country.lower() == 'australia':
                unitPrice = self.product.wholesale_tax_rate.rate * self.price
            else:
                unitPrice = self.price
        else:

            unitPrice = self.price
            
        price = unitPrice * self.quantity
        return formatCurrency(price)
    
    def getRetailTax(self):
        if not self.order.is_wholesale:
            if self.product.tax_rate != None:
               
                shipping = self.order.getProfileShippingO()
                try:
                    
                    country = shipping['country']
                except:
                    try:
                        country = shipping.country.country
                    except:
                        country = ''
                        
                if self.order.getProfileShippingO() and country.lower() == 'australia' or not self.order.getProfileShippingO():
                    tax = float(self.price) / (float(self.product.tax_rate.rate) * 10)
                    return tax * self.quantity
            
        return 0            
    
    #this is to get the normal total price of an order item
    def getTotalNormalPrice(self, wholesale=False):
        return formatCurrency(float(self.product.getNormalPrice(wholesale)) * self.quantity)
    
    def getTotalPrice(self):
        if not self.price:
            self.price = self.product.price
            self.save()
        return formatCurrency(self.price * self.quantity)
    def save(self, **kwargs):
        self.quantity = int(self.quantity)
        try:
            pq = self.product.productsizecolor_set.filter(size=self.size, style=self.style)[0]
        except Exception, e:
            pq = ''
        if self.order and self.order.user and isWholesale(self.order.user):
            if self.quantity > self.product.maximum_quantity_wholesale:
                self.quantity = self.product.maximum_quantity_wholesale             
            elif self.quantity < self.product.minimum_quantity_wholesale:
                self.quantity = self.product.minimum_quantity_wholesale      
        else:
            if self.quantity > self.product.maximum_quantity:
                self.quantity = self.product.maximum_quantity
            elif self.quantity < self.product.minimum_quantity:
                self.quantity = self.product.minimum_quantity
            
        if pq and pq.inventory and self.quantity > pq.inventory and pq.inventory > 0:
            self.quantity = pq.inventory                
        elif pq and pq.inventory and pq.inventory < 0:
            self.quantity = 0
        elif pq and pq.inventory == 0 :
            self.quantity = 0

        super(ProductOrder, self).save()
        
        
class VoucherOrder(models.Model):
    order = models.ForeignKey(Order)
    voucher = models.ForeignKey(Voucher)
    quantity = models.IntegerField()
    price = models.FloatField("Unit Price", default=0.00)
    
    def __unicode__(self):
        return self.order.getOrderNumber()
    
    def getUnitPrice(self):
        return formatCurrency(self.price)
    
    def getTotalPrice(self):
        if not self.price:
            self.price = self.voucher.value
            self.save()
        return formatCurrency(self.price * self.quantity)

    def getRetailTax(self):
        if not self.order.is_wholesale:
                       
            shipping = self.order.getProfileShippingO()
            try:
                
                country = shipping['country']
            except:
                try:
                    country = shipping.country.country
                except:
                    country = ''
            
            if self.order.getProfileShippingO() and country.lower() == 'australia' or not self.order.getProfileShippingO():
                tax = float(self.price) / (1.1 * 10)
                return tax * self.quantity
            
        return 0    
    
    
class FreeShippingValueManager(models.Manager):
    def getValue(self):
        try:
            fsv = FreeShippingValue.objects.all()[0]
            if fsv and fsv.free_shipping_amount != None:
                return fsv.free_shipping_amount
        except:
            return None
        
    def getMessage(self):
        try:
            fsv = FreeShippingValue.objects.all()[0]
            if fsv and fsv.free_shipping_amount != None:
                return fsv.message
        except:
            return ''        
        
    
class FreeShippingValue(models.Model):
    free_shipping_amount = models.FloatField(unique=True, help_text='if order subtotal is greater or equal to this value, shipping will be free')
    message = models.CharField(max_length=90)
    objects = FreeShippingValueManager()
    
    def __unicode__(self):
        return str(self.free_shipping_amount)
    
        
#-----------------------shop helpers-------------------------------------------------------
        
#if one country have more than one shipping method, use this to get all the shipping methods
def getShippingMethods(country):
    c = Country.objects.filter(country__iexact = country.strip().lower())
    c = c[0] if c else ''
    
    shipping = ShippingManagement.objects.filter(countries=c)
    
    return shipping

def createAnything(anything, weight, quantity):
        
    anything.__setitem__('class', "General Goods")
    anything.subclass = "Household Goods"
    anything.packaging = 'Parcel'
    anything.qualifierFreightGeneralFragile = 'N'
    anything.weight = str(weight)
    anything.weightMeasurementType = 'Grams'
    anything.quantity = str(quantity)
    anything.packagingOptimisation = 'N'
    anything.length = "28.5"
    anything.width = "38"
    anything.height = "10"
    anything.distanceMeasurementType = 'Centimetres'
    
    return anything

def createAnywhere(anywhere, postcode, suburb):
    anywhere.itemNature = 'Domestic' 
    anywhere.itemMethod = 'Door to Door'
    anywhere.originCountry = 'AU'
    anywhere.originCode = '2011'
    anywhere.originSuburb = 'Potts Point'
    anywhere.destinationCountry = 'AU'
    anywhere.destinationCode = postcode
    anywhere.destinationSuburb = suburb
    anywhere.originIs = "Business"
    anywhere.destinationIs = "Residence"
    anywhere.locationSelection = 'Nearest'
    return anywhere

def shippingInfoValidation(postcode,suburb, country):
    msg = ''
    postcode = postcode.strip()
    if country.strip().lower() == 'australia':    
        '''security = Security()
        url = 'https://api.temando.com/schema/2009_06/server.wsdl'
        client = Client(url)
        token = UsernameToken('julie@bellabustiere.com', 'Password01')
        security.tokens.append(token)
        client.set_options(wsse=security)
        anythings = client.factory.create('ns0:anythings')
    
        anything = client.factory.create('ns0:Anything')
        anything = createAnything(anything, 20, 1)
        anythings.anything = [anything,]
        
        anywhere = client.factory.create('ns0:Anywhere')
        anywhere = createAnywhere(anywhere, postcode, suburb)'''
        try:
            params = urllib.urlencode({"Quantity":1,'Service_Type':'STANDARD','Height':100,'Width':380,'Length':285,'Weight':200,'country':'AU','Destination_Postcode':'2011','Pickup_Postcode':postcode})
            headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
            conn = httplib.HTTPConnection("drc.edeliver.com.au")
            conn.request("POST", "/ratecalc.asp", params, headers)
            response = conn.getresponse()
            data = response.read()
            datas = data.split('\n')
            datass = datas[0].split('=')
            price = float(datass[1])
            if price == 0:
                msg =  'Your Country/Postcode/Suburb in Your Shipping Details is not correct. Please check and ensure they are correct.'   
        except Exception, e:
            msg =  'Your Country/Postcode/Suburb in Your Shipping Details is not correct. Please check and ensure they are correct.'      
            
    return msg


def temandoAPI(order, weight,quantity,postcode,suburb, method='quote', select=None):
    security = Security()
    #url = 'https://training-api.temando.com/schema/2009_06/server.wsdl'
    url = 'https://api.temando.com/schema/2009_06/server.wsdl'
    #print url
    client = Client(url)
    #token = UsernameToken('temandotest', 'password')
    token = UsernameToken('julie@bellabustiere.com', 'Password01')
    security.tokens.append(token)
    client.set_options(wsse=security)
    #cache = client.options.cache
    #cache.setduration(days=10)
    anythings = client.factory.create('ns0:anythings')

    anything = client.factory.create('ns0:Anything')
    anything = createAnything(anything, weight, quantity)
    anythings.anything = [anything,]
    
    anywhere = client.factory.create('ns0:Anywhere')
    anywhere = createAnywhere(anywhere, postcode, suburb)    
    try:
        result = client.service.getQuotesByRequest(anythings ,anywhere,)
        
    except Exception, e:
        raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)    
    
    result = sorted(result, key=lambda x:float(x.totalPrice))
    quote = result[0] if not select else result[select]
    temando,created = TemandoLogging.objects.get_or_create(order=order)
    temando.all_quotes = result #if method != 'book' else temando.all_quotes
    temando.using_quote = quote #if method != 'book' else temando.using_quote
    '''temando.totalPrice = quote.totalPrice
    temando.basePrice = quote.basePrice
    temando.tax = quote.tax
    temando.currency = quote.currency
    temando.deliveryMethod = quote.deliveryMethod
    temando.etaFrom = quote.etaFrom
    temando.etaTo = quote.etaTo
    temando.guaranteedEta = quote.guaranteedEta
    temando.carrierId = quote.carrier.id
    
    temando.extras = quote.extras'''
    temando.companyName = quote.carrier.companyName
    temando.save()
    
    if method == 'book':
        origin = client.factory.create('ns0:origin')

        origin.contactName = ' Julie Stevanja'
        origin.companyName = 'Bella Bustiere Pty Ltd'
        origin.street = 'Macleay St'
        origin.suburb = 'Potts Point'
        origin.state = 'NSW'
        origin.code = '2011'
        origin.country = 'AU'
        origin.email = 'hello@bellabustiere.com'
        origin.phone1 = '02 93562133'
        
        dest = client.factory.create('ns0:destination')
        
        dest.contactName = order.user.first_name + ' ' + order.user.last_name
        thestreet = "%s %s %s" %(order.getProfileShipping().address, order.getProfileShipping().address2,order.getProfileShipping().address3)
        dest.street = thestreet.strip() 
        dest.suburb = order.getProfileShipping().suburb
        dest.code = order.getProfileShipping().postcode
        dest.country = 'AU'
        dest.email = order.user.email
        dest.phone1 = order.getProfileShipping().phone
        
        bookingquote = client.factory.create('ns0:BookingQuote')
        bookingquote.totalPrice = quote.totalPrice
        bookingquote.basePrice = quote.basePrice
        bookingquote.tax = quote.tax
        bookingquote.currency = quote.currency
        bookingquote.deliveryMethod = quote.deliveryMethod
        bookingquote.etaFrom = quote.etaFrom
        bookingquote.etaTo = quote.etaTo
        bookingquote.guaranteedEta = quote.guaranteedEta
        bookingquote.carrierId = quote.carrier.id
        bookingquote.extras = []
        temando.booking_quote = bookingquote
        temando.save()
        
        payment = client.factory.create('ns0:Payment')
        payment.paymentType = 'Account'
            
        try:
            result = client.service.makeBookingByRequest(anythings ,anywhere,origin=origin, destination=dest, quote=bookingquote, payment=payment, labelPrinterType='Thermal')
            print client.last_sent()
        except Exception, e:
            raise ValueError(e)    

    
    return result

class Struct:
    def __init__(self, **entries): 
        self.__dict__.update(entries)

def mailcallAPI(order, method='quote'):
    error = False
    http = httplib2.Http()
    url = 'http://api.mailcall.com.au'#'http://api.mailcall.com.au/test.php'
    key = '386a63bd78f144251b6aaccbd1bb0a3a'#'784e397ef3c0f458ec288ebd7d6925b2'
    
    shipping_detail =  order.getProfileShippingO()
    if type(shipping_detail) == dict:
        shipping_detail = Struct(**shipping_detail)
    if method == 'quote':
        xml = '''<?xml version='1.0' encoding='UTF-8' standalone='yes'?><request type='pricelist' />'''
        
        dicts = {'key':key,'xml':xml}
        params = urllib.urlencode(dicts)
        headers = {'Content-type': 'application/x-www-form-urlencoded'}
        response, content = http.request(url, 'POST', params, headers=headers)
        
        import xml.dom.minidom
        DOMTree = xml.dom.minidom.parseString(content)
        allsuburbs = DOMTree.documentElement
        suburbs =allsuburbs.getElementsByTagName("suburb") 
        data = {}
        for x in suburbs:
            postcode = x.getElementsByTagName('postcode')[0].childNodes[0].data
            name = x.getElementsByTagName('name')[0].childNodes[0].data
            price = x.getElementsByTagName('totalcost')[0].childNodes[0].data
            if postcode not in data.keys():
                data[postcode] = {name:price}
            else:
                data[postcode][name] = price
        
        o_postcode = shipping_detail.postcode.strip()
        o_suburb = shipping_detail.suburb.strip().upper()
    
        result = data[o_postcode][o_suburb]
    
    elif method == 'book':
        now = datetime.datetime.now()
        try:
            phone = shipping_detail.phone
        except:
            phone = order.getProfileBilling().phone
        bookxml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <request xmlns="http://www.mailcall.com.au" type="book" version="1.4"> <job>
        <date>%s</date>
        <fromcompany>Bella Bustiere Pty Ltd</fromcompany> 
        <fromaddress1>Suite 4.11, 46a Macleay St</fromaddress1><fromcontact>Reception</fromcontact><fromsuburb>POTTS POINT</fromsuburb>
        <frompostcode>2011</frompostcode>
        <tocompany>%s %s</tocompany> <fromphone>+612 9356 2133</fromphone> 
        <toaddress1>%s</toaddress1>
        <tocontact>%s %s</tocontact>
        <tophone>%s</tophone>
        <tosuburb>%s</tosuburb>
        <topostcode>%s</topostcode>
        <service>STD</service><vehicle>C</vehicle><weight>%.2f</weight>
        <quantity>%s</quantity>
        <readytime>NOW</readytime>
        <driverinstructions>%s</driverinstructions><reference>%s</reference>
        <oktoleave>Y</oktoleave><echo>Y</echo>
        </job> </request>'''  %(now.strftime("%Y%m%d"), shipping_detail.first_name, shipping_detail.last_name, shipping_detail.address + ' '+ shipping_detail.address2 + ' ' + shipping_detail.address3, shipping_detail.first_name, shipping_detail.last_name,phone,shipping_detail.suburb.strip().upper(),shipping_detail.postcode.strip(), getBoxWeight(order)/1000.0,getBoxes(order),order.special_instruction,order.getOrderNumber())
        
        dicts = {'key':key,'xml':bookxml}
        params = urllib.urlencode(dicts)
        headers = {'Content-type': 'application/x-www-form-urlencoded'}
        response, content = http.request(url, 'POST', params, headers=headers)
        result = content 
    
    elif method == 'status':
        mailcall, created = MailCallLogging.objects.get_or_create(order=order)
        if mailcall.book_response:
            import xml.dom.minidom
            DOMTree = xml.dom.minidom.parseString(mailcall.book_response).documentElement
            mobile = DOMTree.getElementsByTagName('mobileauthcode')[0].childNodes[0].data
            lineno = DOMTree.getElementsByTagName('lineno')[0].childNodes[0].data
            statusxml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <request xmlns="http://www.mailcall.com.au" type="status" version="1.4">
            <mobileauthcode>%s</mobileauthcode><job>
            <lineno>%s</lineno><date>%s</date>
            </job> </request>'''%(mobile,lineno,mailcall.book_date.strftime("%Y%m%d"))
            dicts = {'key':key,'xml':statusxml}
            params = urllib.urlencode(dicts)
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(url, 'POST', params, headers=headers)
            result = content
        else:
            error = True
            result = 'Please book first'
            return error, result
    try:
        import xml.dom.minidom
        DOMTree = xml.dom.minidom.parseString(content).documentElement
        errors = DOMTree.getElementsByTagName('errors')[0]
        if errors.childNodes:
            error = True
            result = ''
        for x in errors.childNodes:
            result += x.childNodes[0].data + ' '
    except:
        pass

    return error,result


def payment_temando(order):
    try:
        result = temandoAPI(order, getBoxWeight(order),getBoxes(order),order.getProfileShipping().postcode,order.getProfileShipping().suburb, method='book')
        print result
        if result:
            temando,created = TemandoLogging.objects.get_or_create(order=order)
            temando.consignmentNumber = result.consignmentNumber
            temando.requestID = result.requestId
            temando.book_info = result
            temando.consignmentDocument = result.consignmentDocument
            temando.save()
            
        return result
    except:
        pass
    return False

'''now:
if the country has no shipping method in backend, use aupost
'''
def postInternational(order, quantity,weight,postcode,country,suburb,orderprice, wholesale,type='random', term=None, service='STANDARD'):
    postcode = postcode.strip()
    if not postcode:
        raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
    countries = {'samoa': 'WS', 'japan': 'JP', 'french southern territories': 'TF', 'tokelau': 'TK', 'korea, republic of': 'KR', 'iran, islamic republic of': 'IR', 'azerbaijan': 'AZ', 'uzbekistan': 'UZ', 'djibouti': 'DJ', 'seychelles': 'SC', 'french guiana': 'GF', 'malta': 'MT', 'guinea-bissau': 'GW', 'hungary': 'HU', 'cyprus': 'CY', 'barbados': 'BB', 'bhutan': 'BT', 'lithuania': 'LT', 'mongolia': 'MN', 'andorra': 'AD', 'tunisia': 'TN', 'rwanda': 'RW', 'aruba': 'AW', 'puerto rico': 'PR', 'argentina': 'AR', 'norway': 'NO', 'sierra leone': 'SL', 'somalia': 'SO', 'ghana': 'GH', 'belarus': 'BY', 'cuba': 'CU', 'zambia': 'ZM', 'french polynesia': 'PF', 'guatemala': 'GT', 'isle of man': 'IM', 'syrian arab republic': 'SY', 'belgium': 'BE', 'haiti': 'HT', 'kazakhstan': 'KZ', 'burkina faso': 'BF', 'liberia': 'LR', 'kyrgyzstan': 'KG', 'netherlands': 'NL', 'kuwait': 'KW', 'denmark': 'DK', 'philippines': 'PH', 'montserrat': 'MS', 'senegal': 'SN', 'tristan da cunha': 'SH', 'congo': 'CG', 'croatia': 'HR', 'bosnia': 'BA', 'chad': 'TD', 'switzerland': 'CH', 'mali': 'ML', 'bulgaria': 'BG', 'jamaica': 'JM', 'albania': 'AL', 'angola': 'AO', 'lebanon': 'LB', 'american samoa': 'AS', 'malaysia': 'MY', 'falkland islands (malvinas)': 'FK', 'christmas island': 'CX', 'mozambique': 'MZ', 'micronesia, federated states of': 'FM', 'greece': 'GR', 'tanzania, united republic of': 'TZ', 'nicaragua': 'NI', 'new zealand': 'NZ', 'brazil': 'BR', 'afghanistan': 'AF', 'qatar': 'QA', 'palau': 'PW', 'turkmenistan': 'TM', 'equatorial guinea': 'GQ', 'pitcairn': 'PN', 'guinea': 'GN', 'panama': 'PA', 'nepal': 'NP', 'central african republic': 'CF', 'luxembourg': 'LU', 'solomon islands': 'SB', 'latvia': 'LV', 'cook islands': 'CK', 'tuvalu': 'TV', 'netherlands antilles': 'AN', 'namibia': 'NA', 'nauru': 'NR', 'russian federation': 'RU', 'british indian ocean territory': 'IO', 'united arab emirates': 'AE', 'south georgia and the south sandwich islands': 'GS', 'saint kitts and nevis': 'KN', 'sri lanka': 'LK', 'paraguay': 'PY', 'china': 'CN', 'armenia': 'AM', 'kiribati': 'KI', 'belize': 'BZ', 'palestinian territory, occupied': 'PS', 'cayman islands': 'KY', 'yemen': 'YE', 'northern mariana islands': 'MP', 'trinidad and tobago': 'TT', 'mayotte': 'YT', 'gambia': 'GM', 'finland': 'FI', 'saint pierre and miquelon': 'PM', 'mauritius': 'MU', 'antigua and barbuda': 'AG', 'niue': 'NU', 'dominican republic': 'DO', "cote d'ivoire": 'CI', 'jersey': 'JE', 'suriname': 'SR', 'pakistan': 'PK', 'romania': 'RO', 'reunion': 'RE', 'czech republic': 'CZ', 'myanmar': 'MM', 'el salvador': 'SV', 'egypt': 'EG', 'guam': 'GU', 'papua new guinea': 'PG', 'united states': 'US', 'austria': 'AT', 'greenland': 'GL', 'colombia': 'CO', 'thailand': 'TH', 'honduras': 'HN', 'niger': 'NE', 'fiji': 'FJ', 'comoros': 'KM', 'turkey': 'TR', 'united kingdom': 'GB', 'madagascar': 'MG', 'iraq': 'IQ', 'bangladesh': 'BD', 'mauritania': 'MR', 'saint barth\xc3\xa9lemy': 'BL', 'uruguay': 'UY', 'france': 'FR', 'bahamas': 'BS', 'slovakia': 'SK', 'gibraltar': 'GI', 'ireland': 'IE', 'nigeria': 'NG', 'anguilla': 'AI', 'malawi': 'MW', 'ecuador': 'EC', 'moldova, republic of': 'MD', 'ukraine': 'UA', 'israel': 'IL', 'congo, the democratic republic of the': 'CD', 'peru': 'PE', 'algeria': 'DZ', 'serbia': 'RS', 'montenegro': 'ME', 'tajikistan': 'TJ', 'svalbard and jan mayen': 'SJ', 'togo': 'TG', 'holy see (vatican city state)': 'VA', 'jordan': 'JO', 'chile': 'CL', 'martinique': 'MQ', 'oman': 'OM', 'turks and caicos islands': 'TC', 'virgin islands, british': 'VG', 'spain': 'ES', 'sao tome and principe': 'ST', 'georgia': 'GE', 'bouvet island': 'BV', 'vietnam': 'VN', 'brunei darussalam': 'BN', 'morocco': 'MA', 'sweden': 'SE', 'heard island and mcdonald islands': 'HM', 'gabon': 'GA', 'guyana': 'GY', 'macedonia, the former yugoslav republic of': 'MK', 'grenada': 'GD', 'guadeloupe': 'GP', 'hong kong': 'HK', 'bahrain': 'BH', "korea, democratic people's republic of": 'KP', 'estonia': 'EE', 'mexico': 'MX', 'india': 'IN', 'new caledonia': 'NC', 'lesotho': 'LS', 'antarctica': 'AQ', 'australia': 'AU', 'saint vincent and the grenadines': 'VC', 'uganda': 'UG', 'burundi': 'BI', 'kenya': 'KE', 'macao': 'MO', 'botswana': 'BW', 'saint martin (french part)': 'MF', 'italy': 'IT', 'western sahara': 'EH', 'south africa': 'ZA', 'cambodia': 'KH', 'ethiopia': 'ET', 'swaziland': 'SZ', 'bermuda': 'BM', 'timor-leste': 'TL', 'vanuatu': 'VU', 'marshall islands': 'MH', 'cameroon': 'CM', 'benin': 'BJ', 'canada': 'CA', "lao, people's democratic republic": 'LA', 'saudi arabia': 'SA', 'singapore': 'SG', 'faroe islands': 'FO', 'iceland': 'IS', 'saint lucia': 'LC', 'monaco': 'MC', 'virgin islands, u.s.': 'VI', 'costa rica': 'CR', 'venezuela': 'VE', 'united states minor outlying islands': 'UM', 'cocos (keeling) islands': 'CC', 'slovenia': 'SI', 'germany': 'DE', '\xc3\x85land islands': 'AX', 'wallis and futuna': 'WF', 'san marino': 'SM', 'dominica': 'DM', 'libyan, arab jamahiriya': 'LY', 'eritrea': 'ER', 'tonga': 'TO', 'maldives': 'MV', 'norfolk island': 'NF', 'poland': 'PL', 'indonesia': 'ID', 'cape verde': 'CV', 'taiwan': 'TW', 'sudan': 'SD', 'liechtenstein': 'LI', 'zimbabwe': 'ZW', 'portugal': 'PT', 'guernsey': 'GG', 'bolivia': 'BO','ascension island': 'AC','east timor': 'TP'}
    c = Country.objects.filter(country__iexact = country.strip().lower())
    c = c[0] if c else ''
    orderprice = float(orderprice)
    
    shipping = ShippingManagement.objects.filter(countries=c) if c else None
    
    if weight == 0 and not order.productorder_set.all() and postcode and suburb:
        return 'free'
    
    if shipping and shipping[0].fixed_shipping:
        return shipping[0].fixed_shipping
    
    if shipping and shipping[0].free_shipping and orderprice > shipping[0].free_shipping:
        return 'free'
    
    if not shipping or shipping[0].api == 'aupost':
        if countries.has_key(country.strip().lower()):
            service = service if country.strip().lower() == 'australia' else 'AIR'
            params = urllib.urlencode({"Quantity":int(quantity),'Service_Type':service,'Height':100,'Width':380,'Length':285,'Weight':int(weight),'country':countries[country.strip().lower()],'Destination_Postcode':'2011','Pickup_Postcode':postcode})
            headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
            conn = httplib.HTTPConnection("drc.edeliver.com.au")
            conn.request("POST", "/ratecalc.asp", params, headers)
            response = conn.getresponse()
            data = response.read()
            datas = data.split('\n')
            datass = datas[0].split('=')
            price = float(datass[1])
            if price == 0:
                raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
            else:
                
                sd = ShippingDiscount.objects.all()
                sd = sd[0] if sd else None
                price = price * sd.getRatio() if sd else price
    
           # return price
        else:
            raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)

    elif shipping and shipping[0].api == 'weight':
        baseprice = shipping[0].getBasePrice(weight*quantity)
        if baseprice:
            price = baseprice.amount
        else:
            raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
    elif shipping and shipping[0].api == 'price':
        baseprice = shipping[0].getBasePrice(orderprice)
        if baseprice:
            price = baseprice.amount
        else:
            raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
    else:
        price = None
        
    if price and shipping and shipping[0].minimum_shipping and price < shipping[0].minimum_shipping:
        price = shipping[0].minimum_shipping
    elif price and shipping and shipping[0].maximum_shipping and price > shipping[0].maximum_shipping:
        price = shipping[0].maximum_shipping
    return 'free' if price == 0 else price   
    '''
    postcode = postcode.strip()
    countries = {'samoa': 'WS', 'japan': 'JP', 'french southern territories': 'TF', 'tokelau': 'TK', 'korea, republic of': 'KR', 'iran, islamic republic of': 'IR', 'azerbaijan': 'AZ', 'uzbekistan': 'UZ', 'djibouti': 'DJ', 'seychelles': 'SC', 'french guiana': 'GF', 'malta': 'MT', 'guinea-bissau': 'GW', 'hungary': 'HU', 'cyprus': 'CY', 'barbados': 'BB', 'bhutan': 'BT', 'lithuania': 'LT', 'mongolia': 'MN', 'andorra': 'AD', 'tunisia': 'TN', 'rwanda': 'RW', 'aruba': 'AW', 'puerto rico': 'PR', 'argentina': 'AR', 'norway': 'NO', 'sierra leone': 'SL', 'somalia': 'SO', 'ghana': 'GH', 'belarus': 'BY', 'cuba': 'CU', 'zambia': 'ZM', 'french polynesia': 'PF', 'guatemala': 'GT', 'isle of man': 'IM', 'syrian arab republic': 'SY', 'belgium': 'BE', 'haiti': 'HT', 'kazakhstan': 'KZ', 'burkina faso': 'BF', 'liberia': 'LR', 'kyrgyzstan': 'KG', 'netherlands': 'NL', 'kuwait': 'KW', 'denmark': 'DK', 'philippines': 'PH', 'montserrat': 'MS', 'senegal': 'SN', 'tristan da cunha': 'SH', 'congo': 'CG', 'croatia': 'HR', 'bosnia': 'BA', 'chad': 'TD', 'switzerland': 'CH', 'mali': 'ML', 'bulgaria': 'BG', 'jamaica': 'JM', 'albania': 'AL', 'angola': 'AO', 'lebanon': 'LB', 'american samoa': 'AS', 'malaysia': 'MY', 'falkland islands (malvinas)': 'FK', 'christmas island': 'CX', 'mozambique': 'MZ', 'micronesia, federated states of': 'FM', 'greece': 'GR', 'tanzania, united republic of': 'TZ', 'nicaragua': 'NI', 'new zealand': 'NZ', 'brazil': 'BR', 'afghanistan': 'AF', 'qatar': 'QA', 'palau': 'PW', 'turkmenistan': 'TM', 'equatorial guinea': 'GQ', 'pitcairn': 'PN', 'guinea': 'GN', 'panama': 'PA', 'nepal': 'NP', 'central african republic': 'CF', 'luxembourg': 'LU', 'solomon islands': 'SB', 'latvia': 'LV', 'cook islands': 'CK', 'tuvalu': 'TV', 'netherlands antilles': 'AN', 'namibia': 'NA', 'nauru': 'NR', 'russian federation': 'RU', 'british indian ocean territory': 'IO', 'united arab emirates': 'AE', 'south georgia and the south sandwich islands': 'GS', 'saint kitts and nevis': 'KN', 'sri lanka': 'LK', 'paraguay': 'PY', 'china': 'CN', 'armenia': 'AM', 'kiribati': 'KI', 'belize': 'BZ', 'palestinian territory, occupied': 'PS', 'cayman islands': 'KY', 'yemen': 'YE', 'northern mariana islands': 'MP', 'trinidad and tobago': 'TT', 'mayotte': 'YT', 'gambia': 'GM', 'finland': 'FI', 'saint pierre and miquelon': 'PM', 'mauritius': 'MU', 'antigua and barbuda': 'AG', 'niue': 'NU', 'dominican republic': 'DO', "cote d'ivoire": 'CI', 'jersey': 'JE', 'suriname': 'SR', 'pakistan': 'PK', 'romania': 'RO', 'reunion': 'RE', 'czech republic': 'CZ', 'myanmar': 'MM', 'el salvador': 'SV', 'egypt': 'EG', 'guam': 'GU', 'papua new guinea': 'PG', 'united states': 'US', 'austria': 'AT', 'greenland': 'GL', 'colombia': 'CO', 'thailand': 'TH', 'honduras': 'HN', 'niger': 'NE', 'fiji': 'FJ', 'comoros': 'KM', 'turkey': 'TR', 'united kingdom': 'GB', 'madagascar': 'MG', 'iraq': 'IQ', 'bangladesh': 'BD', 'mauritania': 'MR', 'saint barth\xc3\xa9lemy': 'BL', 'uruguay': 'UY', 'france': 'FR', 'bahamas': 'BS', 'slovakia': 'SK', 'gibraltar': 'GI', 'ireland': 'IE', 'nigeria': 'NG', 'anguilla': 'AI', 'malawi': 'MW', 'ecuador': 'EC', 'moldova, republic of': 'MD', 'ukraine': 'UA', 'israel': 'IL', 'congo, the democratic republic of the': 'CD', 'peru': 'PE', 'algeria': 'DZ', 'serbia': 'RS', 'montenegro': 'ME', 'tajikistan': 'TJ', 'svalbard and jan mayen': 'SJ', 'togo': 'TG', 'holy see (vatican city state)': 'VA', 'jordan': 'JO', 'chile': 'CL', 'martinique': 'MQ', 'oman': 'OM', 'turks and caicos islands': 'TC', 'virgin islands, british': 'VG', 'spain': 'ES', 'sao tome and principe': 'ST', 'georgia': 'GE', 'bouvet island': 'BV', 'vietnam': 'VN', 'brunei darussalam': 'BN', 'morocco': 'MA', 'sweden': 'SE', 'heard island and mcdonald islands': 'HM', 'gabon': 'GA', 'guyana': 'GY', 'macedonia, the former yugoslav republic of': 'MK', 'grenada': 'GD', 'guadeloupe': 'GP', 'hong kong': 'HK', 'bahrain': 'BH', "korea, democratic people's republic of": 'KP', 'estonia': 'EE', 'mexico': 'MX', 'india': 'IN', 'new caledonia': 'NC', 'lesotho': 'LS', 'antarctica': 'AQ', 'australia': 'AU', 'saint vincent and the grenadines': 'VC', 'uganda': 'UG', 'burundi': 'BI', 'kenya': 'KE', 'macao': 'MO', 'botswana': 'BW', 'saint martin (french part)': 'MF', 'italy': 'IT', 'western sahara': 'EH', 'south africa': 'ZA', 'cambodia': 'KH', 'ethiopia': 'ET', 'swaziland': 'SZ', 'bermuda': 'BM', 'timor-leste': 'TL', 'vanuatu': 'VU', 'marshall islands': 'MH', 'cameroon': 'CM', 'benin': 'BJ', 'canada': 'CA', "lao, people's democratic republic": 'LA', 'saudi arabia': 'SA', 'singapore': 'SG', 'faroe islands': 'FO', 'iceland': 'IS', 'saint lucia': 'LC', 'monaco': 'MC', 'virgin islands, u.s.': 'VI', 'costa rica': 'CR', 'venezuela': 'VE', 'united states minor outlying islands': 'UM', 'cocos (keeling) islands': 'CC', 'slovenia': 'SI', 'germany': 'DE', '\xc3\x85land islands': 'AX', 'wallis and futuna': 'WF', 'san marino': 'SM', 'dominica': 'DM', 'libyan, arab jamahiriya': 'LY', 'eritrea': 'ER', 'tonga': 'TO', 'maldives': 'MV', 'norfolk island': 'NF', 'poland': 'PL', 'indonesia': 'ID', 'cape verde': 'CV', 'taiwan': 'TW', 'sudan': 'SD', 'liechtenstein': 'LI', 'zimbabwe': 'ZW', 'portugal': 'PT', 'guernsey': 'GG', 'bolivia': 'BO','ascension island': 'AC','east timor': 'TP'}
    c = Country.objects.filter(country__iexact = country.strip().lower())
    c = c[0] if c else ''
    orderprice = float(orderprice)
    if type == 'term' and term:
        if wholesale:
            price = term.get_shipping_charge(orderprice)
            return 'free' if price == 0 else price   
        else:
            type = 'random'
    else:
        type = 'random'
        
    if type == 'random':
        shipping = ShippingManagement.objects.filter(countries=c,wholesale=wholesale) if c else None
    elif type == 'wholesale':
        shipping = ShippingManagement.objects.filter(countries=c,wholesale=True) if c else None
    else:
        shipping = ShippingManagement.objects.filter(id=type)

   
    if shipping and shipping[0].fixed_shipping:
        return shipping[0].fixed_shipping
    
    if shipping and shipping[0].free_shipping and orderprice > shipping[0].free_shipping:
        return 'free'
    
    if not shipping or shipping[0].api == 'aupost':
        if countries.has_key(country.strip().lower()):
            service = service if country.strip().lower() == 'australia' else 'AIR'
            params = urllib.urlencode({"Quantity":int(quantity),'Service_Type':service,'Height':350,'Width':240,'Length':460,'Weight':int(weight),'country':countries[country.strip().lower()],'Destination_Postcode':'2077','Pickup_Postcode':postcode})
            headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
            conn = httplib.HTTPConnection("drc.edeliver.com.au")
            conn.request("POST", "/ratecalc.asp", params, headers)
            response = conn.getresponse()
            data = response.read()
            datas = data.split('\n')
            datass = datas[0].split('=')
            price = float(datass[1])
            if price == 0:
                raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
            else:
                
                sd = ShippingDiscount.objects.all()
                sd = sd[0] if sd else None
                price = price * sd.getRatio() if sd else price
        
               
                return price
        else:
            raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
    elif shipping and shipping[0].api == 'weight':
        baseprice = shipping[0].getBasePrice(weight*quantity)
        if baseprice:
            price = baseprice.amount
        else:
            raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
    elif shipping and shipping[0].api == 'price':
        baseprice = shipping[0].getBasePrice(orderprice)
        if baseprice:
            price = baseprice.amount
        else:
            raise ValueError(settings.TXT_SHOP_SHIPPING_UNABLE_TO_CALCULATE)
    else:
        price = None
        
    if price and shipping and shipping[0].minimum_shipping and price < shipping[0].minimum_shipping:
        price = shipping[0].minimum_shipping
    elif price and shipping and shipping[0].maximum_shipping and price > shipping[0].maximum_shipping:
        price = shipping[0].maximum_shipping
    return 'free' if price == 0 else price   
    '''
    
def getBoxes(order):
    weight = order.getTotalWeight()
    box=1
    box_least = 1
    boxValume = float(28.5*38*10)#TO CHANGE
    sum = 0 
    for x in order.productorder_set.all():
        sum = sum + x.getValume()
           
        box = int(math.ceil(sum/boxValume))
        box_least = int(math.ceil(weight/20000.0))
    if box >= box_least:
        return box
    else:
        return box_least



def getBoxWeight(order):
    return float(order.getTotalWeight()/getBoxes(order))
        
"""_wholesale is the indicator showing whether pending wholesale shipping cost for admin to input later
wil be used to sync the order with current database to return the correct shipping fee
"""
def getShippingCost(order, _wholesale ='manual'):
    price = 8.80 if not order.shipping_charged else order.shipping_charged
    try:
        profile = order.user.get_profile()
        shipping = profile.shipping_set.all()[0]

        price = postInternational(order, getBoxes(order), getBoxWeight(order),shipping.postcode, shipping.country.country, shipping.suburb, order.getTotalTaxFreePrice(),order.is_wholesale, type='term', term=profile.payment_term, service=order.getShippingWay() )
        price = 0.00 if price == 'free' else price
        price = formatCurrency(price)
    except Exception, e:
            #raise ValueError(e)
            return price
        
    if _wholesale == 'manual':
        return order.shipping_charged if order.is_wholesale else price
        
    else:
        return price
    
def getTotalPrice(order):
    return formatCurrency(float(order.getTotalGST())+float(order.getTotalTaxFreePrice())+float(getShippingCost(order,_wholesale=settings.WHOLESALE_SHIPPING)))

def send_confirm_email(order):
    profile = order.user.get_profile()
    shipping = order.getProfileShippingO()
    billing = order.getProfileBillingO()
    title = settings.SITE_NAME + " Order Received"
    if order.status.status == 'Cancelled':
        title = settings.SITE_NAME + " Order Cancelled"
    elif order.status.status == 'Shipped':
        title = settings.SITE_NAME + " Order Shipped"
        
    t = loader.get_template('orderconfirmationemail.html')
    d = {"profile":profile, "shipping":shipping, "billing":billing,'order':order}
    c = Context(d)
    msgg = t.render(c)
    email = EmailMultiAlternatives(title + " - Order "+ order.getOrderNumber(), msgg, 'no-reply@'+settings.SITE_DOMAIN, ['sales@'+settings.SITE_DOMAIN, order.user.email], ['dou8le@gmail.com'])
    email.attach_alternative(msgg, "text/html")
    email.send()
    
def productOrderSaved(sender, **kwargs):
        po = kwargs["instance"]
        if po.order.sync_order:
            po.order.shipping_charged = float(getShippingCost(po.order,_wholesale=settings.WHOLESALE_SHIPPING))
            po.order.tax_charged = float(po.order.getTotalGST())
            
            po.order.total_charged = float(getTotalPrice(po.order))
            po.order.save()
            
def voucherOrderSaved(sender, **kwargs):
        po = kwargs["instance"]
        if po.order.sync_order:
            po.order.shipping_charged = float(getShippingCost(po.order,_wholesale=settings.WHOLESALE_SHIPPING))
            po.order.tax_charged = float(po.order.getTotalGST())
            
            po.order.total_charged = float(getTotalPrice(po.order))
            po.order.save()    
 
post_save.connect(productOrderSaved, sender=ProductOrder)
post_delete.connect(productOrderSaved, sender=ProductOrder)

#post_save.connect(voucherOrderSaved, sender=VoucherOrder)
#post_delete.connect(voucherOrderSaved, sender=VoucherOrder)

