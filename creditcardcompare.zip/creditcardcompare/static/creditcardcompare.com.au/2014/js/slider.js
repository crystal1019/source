function displaySavings(data){
	for (var key in data){
		$('#' + key).find('span:first-child').text(data[key]);
	};
};
function showSavings(){
	if ($('.slider-output').length == 0){
		return;
	};
	data = {},
	$('.slider-output').each(function(){
		var id = $(this).attr('id');
		if ($.cookie(id) != $(this).html()){
			$(this).html($.cookie(id));
		};
		data[id] = $(this).html();
	});
	data['offers'] = [];
	$('.card2savingstext').each(function(){
		data['offers'].push($(this).attr('id').replace('savings',''));
	});
	jQuery.ajax({
		type: 'POST',
		url: '/tools/beat-my-card/calculate-savings/',
		data: data,
		dataType: 'json',
		success: function(data) {
			displaySavings(data);
		}
		// init loaded tables ::


	}).always(function(){
			// hide preloaders
			$('.card1row').animate({opacity:1},200);
			$('.card2savingstext').animate({opacity:1},200);
			$('.card1cogpos').hide(200);
		});
	// display preloaders ::
	$('.card1row').animate({opacity:0.5},500);
	$('.card2savingstext').animate({opacity:0},500);
	$('.card1cogpos').show(200);
};
function getCookie(key){
    // there has been js alerts saying $.cookie is undefined
    try {
        return $.cookie(key);
    }catch(e){
        return false;
    };
};
function initSliders(){
    var usercode = Math.random().toString(36).slice(2);
    var slidertype = $('.category1sliders').attr('slidertype');
    try{initSlider1();}
    catch(e){$.ajax({url:'/email-notice/error/', data: {'details': e.message, 'location': window.location.href, 'type': slidertype, 'slider': '1', 'user': usercode}});};
    try{initSlider2();}
    catch(e){$.ajax({url:'/email-notice/error/', data: {'details': e.message, 'location': window.location.href, 'type': slidertype, 'slider': '2', 'user': usercode}});};
    try{initSlider3();}
    catch(e){$.ajax({url:'/email-notice/error/', data: {'details': e.message, 'location': window.location.href, 'type': slidertype, 'slider': '3', 'user': usercode}});};
    try{initSlider4();}
    catch(e){$.ajax({url:'/email-notice/error/', data: {'details': e.message, 'location': window.location.href, 'type': slidertype, 'slider': '4', 'user': usercode}});};
    try{initSlider5();}
    catch(e){$.ajax({url:'/email-notice/error/', data: {'details': e.message, 'location': window.location.href, 'type': slidertype, 'slider': '5', 'user': usercode}});};
};
function initSlider1(){
	$( "#slider-balance-transfer" ).slider({
		min: 0, max: 15000,
		step: 250, value: getCookie('slide1') || 5000,
		range: 'min',
		slide: function( event, ui ) {$('#slide1').html(ui.value);},
		stop: function(evt, ui){$.cookie('slide1', ui.value, {expires: 30, path: '/'}); showSavings();}
	});
};
function initSlider2(){
	$( "#slider-interest-rate" ).slider({
		min: 0, max: 40,
		value: getCookie('slide2') || 17,
		range: 'min',
		slide: function( event, ui ) {$('#slide2').html(ui.value);},
		stop: function(evt, ui){$.cookie('slide2', ui.value, {expires: 30, path: '/'}); showSavings();}
	});
};
function initSlider3(){
	$( "#slider-annual-fee" ).slider({
		min: 0, max: 500,
		step: 10, value: getCookie('slide3') || 90,
		range: 'min',
		slide: function( event, ui ) {$('#slide3').html(ui.value);},
		stop: function(evt, ui){$.cookie('slide3', ui.value, {expires: 30, path: '/'}); showSavings();}
	});
};
function initSlider4(){
	$( "#slider-monthly-spent" ).slider({
		min: 250, max: 15000,
		step: 250, value: getCookie('slide4') || 3000,
		range: 'min',
		slide: function( event, ui ) {$('#slide4').html(ui.value);},
		stop: function(evt, ui){$.cookie('slide4', ui.value, {expires: 30, path: '/'}); showSavings();}
	});
};
function initSlider5(){
	$( "#slider-onetime-purchase" ).slider({
        min: 0, max: 15000,
        step: 250, value: getCookie('slide5') || 5000,
        range: 'min',
        slide: function( event, ui ) {$('#slide5').html(ui.value);},
        stop: function(evt, ui){$.cookie('slide5', ui.value, {expires: 30, path: '/'}); showSavings();}
    });
};
function filterByCategory(){
    $.ajax({
      type: $('.category-page #category-filter-form').attr('method'),
      url: $('.category-page #category-filter-form').attr('action') + '?page=1',
      data: $('.category-page #category-filter-form').serialize(),
      success: function(data){
        $('#sortable-offer-list').html(data.html);
        page = 1;
        toggleShowMoreButton(data.pages);
      },
      dataType: 'json'
    });
};
$(document).ready(function(){
	initSliders();
	showSavings();
	$(document).ajaxComplete(function(event, xhr, settings){
		try{
			if (isPagination(event, xhr, settings)){
				showSavings();
			}
		}catch(e){}
	});
	$('.category-page #category-filter-form input').click(filterByCategory);
});
