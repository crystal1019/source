from django.contrib.syndication.views import Feed
from bellabustiere.blog.models import BlogPost
import datetime

from django.conf import settings

class BlogFeed(Feed):
    title = 'Bella Bustiere blog'
    link = '/blog/'
    description = 'Bella Bustiere blog rss feed '
    
    def items(self):
        temp = list(BlogPost.objects.filter(status__display_to_user=True, publishdate__lte=datetime.datetime.now()).order_by("publishdate"))
        return temp[-20:]
    
    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.content
    
    def item_link(self,item):
        return 'http://%s%s' % (settings.DOMAIN, item.geturl() )
    
    def item_pubdate(self,item):
        return item.publishdate