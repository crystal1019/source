import masterpage

import method_db
import method_email
import method_comment
import method_url
import method_user
	
class FlagComment(masterpage.MasterPage):	
	def post(self):		
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return
	   
		id = method_url.getId(self)
		comment = method_comment.getCommentWithId(id)		
			
		# Add user to comment
		users = comment.flag_users
		if users == None:
			users = []
		elif user.uid in users: # User has already flagged the comment
			return
		users.append(user.uid)			
		comment.flag_users = users
		
		# Add reason to comment
		reason = self.request.get('flagReason')
		reasons = comment.flag_reasons
		if reasons == None:
			reasons = []
		reasons.append(reason)
		comment.flag_reasons = reasons		

		# Delete comment if necessary
		comment.flag_count = comment.flag_count + 1
		if comment.flag_count >= method_comment.flag_limit or method_user.userIsAdmin():
			method_comment.deleteComment(comment)
		comment.under_review = True
		method_db.putObject(comment)
		
		method_comment.clearFlaggedCommentCountCache()
		method_email.sendMeEmail('', 'Flagged Comment Reported', 'Flagged Comment Reported') 	
		self.displayError('Thank You!', 'Thank you!  This flag will be looked at shortly by a moderator. <br/><br/> Wanna be a moderator?  Email gayle@careercup.com.')		
			  
	def get(self):		  
		#  Get logged in user
		user = method_user.getLoggedInUser()
		if user is None:
			self.redirectToLogin()
			return	
		id = method_url.getId(self)
		comment = method_comment.getCommentWithId(id)
		if user.uid in comment.flag_users:
			already_flagged = True
		else:
			already_flagged = False
		
		template_values = {'comment_id': id, 'parent_tab': 'interviews', 'already_flagged' : already_flagged}
		self.pushPage(template_values, 'Flag Comment', 'html/flagcomment.html')   
		
