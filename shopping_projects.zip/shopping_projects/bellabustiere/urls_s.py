'''
@author: chaol
'''

from django.conf.urls.defaults import *

from django.contrib import admin
admin.autodiscover()
from django.conf import settings
#import bellabustiere.shop.filters

from password_required.decorators import password_required
from decorator_include import decorator_include

urlpatterns = patterns('',
    #(r'^blog/', include('bellabustiere.blog.urls')),
    (r'^password_required/$', 'password_required.views.login'),
    (r'^shop/i/(?P<w>\d+)/(?P<h>\d+)/(?P<crop>\d)/(?P<path>.*)$', 'bellabustiere.shop.imageviews.imager'),
    (r'^shop/i/(?P<w>\d+)/(?P<h>\d+)/(?P<path>.*)$', 'bellabustiere.shop.imageviews.imager'),
    (r'^shop/', include(decorator_include(password_required,'bellabustiere.shop.urls'))),
    (r'^blog/', include(decorator_include(password_required, 'bellabustiere.blog.urls'))),
   # (r'^stockists/', include('bellabustiere.stockists.urls')),
    (r'^states/', include('bellabustiere.states_urls')),
    (r'^members/', include(decorator_include(password_required, 'bellabustiere.shop.wholesaleurls'))),
    
    (r'^captcha/', include('captcha.urls')),
    (r'^media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT}),
    (r'^grappelli/', include('grappelli.urls')),
    (r'^admin/filebrowser/', include('filebrowser.urls')), 
    (r'^admin/emails/', 'bellabustiere.admin_views.emails_app_index'),
    (r'^admin/shop/order/(?P<id>.*)/sendconfirmemail/$', 'bellabustiere.admin_views.sendconfirmemail'),
    (r'^admin/shop/order/order(?P<id>.*)/$', "bellabustiere.admin_views.order"),
    (r'^admin/shop/order/invoice(?P<id>.*)/$', "bellabustiere.admin_views.invoice"),
    (r'^admin/shop/order/(?P<id>.*)/packinglist/$', 'bellabustiere.admin_views.packinglist'),
    (r'^admin/auth/user/(?P<id>.*)/orders/$', "bellabustiere.admin_views.order_history"),
   
    (r'^admin/userprofile/profile/add/$', 'bellabustiere.admin_views.addprofile'),
    
    (r'^admin/shop/discountprice/addtocoupon/$','bellabustiere.admin_views.addtocoupon'),
    (r'^admin/shop/product/addtocategory/$','bellabustiere.admin_views.addtocategory'),
    #(r'^admin/shop/product/addtodiscount/$','bellabustiere.admin_views.addtodiscount'),
    (r'^admin/shop/discountprice/category/$',"bellabustiere.admin_views.category"),
    (r'^admin/shop/discountprice/delete/$',"bellabustiere.admin_views.delete"),
    
    (r'^admin/shop/coupon/(?P<id>.*)/modifydate/$', 'bellabustiere.admin_views.modifydate'),
    
    (r'^admin/shop/productorder/good/$', 'bellabustiere.admin_views.productorder'),
    (r'^admin/shop/productorder/good/order(?P<id>.*)/$', 'bellabustiere.admin_views.product_order'),
    (r'^admin/shop/orders/myob/$','bellabustiere.admin_views.myob'),
    (r'^admin/shop/product/addbycsv/$','bellabustiere.admin_views.addbycsv'),

    (r'^admin/website/subscription/sendmail/', 'bellabustiere.admin_views.sendmail'),
    (r'^admin/', include(admin.site.urls)),
    #(r'^tinymce/', include('tinymce.urls')),
    (r'^', include(decorator_include(password_required, 'bellabustiere.website.urls'))),
)
