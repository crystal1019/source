# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import offers.helpers.django_fields.fields


class Migration(migrations.Migration):

    dependencies = [
        ('lead', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Conversion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('uid', models.CharField(max_length=50)),
                ('query', models.CharField(max_length=300)),
                ('cookies', models.TextField(max_length=300)),
                ('meta', models.TextField()),
            ],
        ),
        migrations.AlterField(
            model_name='energylead',
            name='city',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=357),
        ),
        migrations.AlterField(
            model_name='energylead',
            name='email',
            field=offers.helpers.django_fields.fields.EncryptedEmailField(max_length=485),
        ),
        migrations.AlterField(
            model_name='energylead',
            name='name',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=2149),
        ),
        migrations.AlterField(
            model_name='energylead',
            name='phone',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=357),
        ),
        migrations.AlterField(
            model_name='energylead',
            name='postcode',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=229),
        ),
        migrations.AlterField(
            model_name='energylead',
            name='source',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=2149),
        ),
        migrations.AlterField(
            model_name='energylead',
            name='street',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=2149),
        ),
        migrations.AlterField(
            model_name='lead',
            name='country',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=613, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='lead',
            name='email',
            field=offers.helpers.django_fields.fields.EncryptedEmailField(max_length=485),
        ),
        migrations.AlterField(
            model_name='lead',
            name='first_name',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=2149, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='lead',
            name='ip',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=357, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='lead',
            name='last_name',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=2149, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='lead',
            name='phone',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=357, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='lead',
            name='source',
            field=offers.helpers.django_fields.fields.EncryptedCharField(max_length=2149),
        ),
    ]
