from django.conf.urls import *


urlpatterns = patterns('googledocs.views',
    url(r'^sync/(?P<importer_name>[A-Za-z0-9\_]+)/$', 'sync_with_google', name='sync'),
)
