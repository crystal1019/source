import sys
from settings.ccc import *


EMAIL_SUBJECT_PREFIX = '[CCC Reviews ALERT 0]'
ALLOWED_HOSTS = ['reviews.creditcardcompare.com.au']
