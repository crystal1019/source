from django.contrib import admin
from models import UserAgent


class UserAgentAdmin(admin.ModelAdmin):
    model = UserAgent
    list_display = ('hit_count', 'last_hit', 'first_hit', 'is_mobile', 'is_tablet', 'is_smartphone', 'agent')
    search_fields = ('agent',)


admin.site.register(UserAgent, UserAgentAdmin)