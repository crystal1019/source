console.log('demo loaded..');
company_name = "AppointmentWorks"
org_string = "AWDemo";
rest_url = "/ws/broker/" + org_string + "/";
LOC_MAIN_OFFICE = 'Main Office';
LOC_DOWNTOWN_OFFICE = 'Downtown Office';
selected_req_id = 1;
selected_location = LOC_MAIN_OFFICE;
location_id_map ={};
location_id_map[LOC_MAIN_OFFICE] = 1;
location_id_map[LOC_DOWNTOWN_OFFICE] = 4;

selected_zip_code = '12300';
zipcode_resc_map = {};
zipcode_resc_map['12300'] = LOC_MAIN_OFFICE;
zipcode_resc_map['12301'] = LOC_MAIN_OFFICE;
zipcode_resc_map['12302'] = LOC_MAIN_OFFICE;
zipcode_resc_map['12303'] = LOC_DOWNTOWN_OFFICE;
zipcode_resc_map['12304'] = LOC_DOWNTOWN_OFFICE;

//

var UserInfoDialog = new Class({
    initialize: function(container_id, calendar_ctrl ){
        var self = this;
        self.calendarctrl = calendar_ctrl;
        self.blackscreen_class = "dl_blackscreen";
        self.dialogbox_class = "dl_dialogbox";
        self.zipcode_class = "dl_zipcode_txt";
        self.submit_class = "dl_submit_btn";
        self.skip_class = "dl_skip_btn";
        self.row_class = "dl_row";
        self.label_class = "dl_label";
        self.content_class = "dl_content";
        self.title_class = "dl_title";
        self.subtitle_class = "dl_subtitle";
        self.container_id = container_id;
    },
    initialize_dialog: function(){
        var self = this;
        self.container = $("#" + self.container_id );
        $(self.container).css("display", "block");
        self.blackscreen = $("<div>")
                .addClass(self.blackscreen_class )
                .appendTo(self.container );
        self.dialogbox = $("<div>")
                .addClass(self.dialogbox_class )
                .appendTo(self.container );

        $("<div>").text(company_name + " Web Scheduler")
                .addClass(self.title_class )
                .appendTo(self.dialogbox );
        $("<div>").text("Please enter your information to schedule an appointment")
                .addClass(self.subtitle_class )
                .appendTo(self.dialogbox );

        var tmp_row1 = $("<div>")
                .addClass(self.row_class )
                .appendTo(self.dialogbox );
        $("<div>").text("Zip Code:")
                .addClass(self.label_class )
                .appendTo(tmp_row1 );
        var tmp_div1 = $("<div>")
                .addClass(self.content_class )
                .appendTo(tmp_row1)
        self.zipcode = $("<input>")
                .attr("type", "text")
                .addClass(self.zipcode_class )
                .appendTo(tmp_div1 );

        var tmp_row2 = $("<div>")
                .addClass(self.row_class )
                .appendTo(self.dialogbox );
        self.submit = $("<input>")
                .attr("type", "button")
                .attr("value", "Submit")
                .addClass(self.submit_class )
                .click(function(e){
                    var zip_code = $(self.zipcode ).val();
                    if (zip_code == "" ){
                        alert("input the zip code, please");
                        return;
                    }

                    var req_id = self.get_resourceid_from_zipcode(zip_code );
                    if (req_id == -1 ){
                        alert("Sorry, we do not service that zip code. Please enter a different zip code or call 800-555-1212");
                        $(self.zipcode).val("");
                        return;
                    }

                    global.zipcode = zip_code;
                    global.reqid = req_id;
  
                    self.exit_dialog();
                    tmp_calendar.change_reqid(req_id );

                    //tmp_calendar.setdays("", "", req_id );
                })
                .appendTo(tmp_row2 );
        self.skip = $("<input>")
                .attr("type", "button")
                .attr("value", "skip")
                .addClass(self.skip_class )
                .click(function(e){
                    self.exit_dialog();
                })
                .appendTo(tmp_row2 );
    },
    exit_dialog: function(){
        var self = this;
        if (self.container ){
            $(self.container).html("");
            $(self.container).css("display", "none");    
        }
    },
    get_resourceid_from_zipcode: function(zipcode ){
    	if (typeof zipcode_resc_map[zipcode] === 'undefined') {
    		return -1;
    	}

    	mlk = zipcode_resc_map[zipcode]
    	if (typeof location_id_map[mlk] === 'undefined') {
    		return -1;
    	}
    	return location_id_map[mlk]
    }
});
