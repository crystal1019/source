/**
 * Toggle map section
 */
function toggle_map(force, callback) {
    var btn = $('.explore_map_content .toggle_map');
    var text = '';
    if (!force) {
        btn.toggleClass('active');
        var map_sect = btn.attr('rel');
        $('#' + map_sect).slideToggle('fast', callback);

        text = btn.find('span').text();
        btn.find('span').text(text == "show map" ? "hide map" : "show map");
    }
    else {
        if (force === 'show') {
            $('#map-section').slideDown('fast', callback);
            text = 'hide map';
        }
        else if (force === 'hide') {
            $('#map-section').slideUp('fast', callback);
            text = 'show map';
        }
        btn.addClass('active')
            .find('span')
            .html(text);
    }
}

/**
 * Show map and change toggle link text
 */
function show_map() {
    $('#map-section').slideDown('fast');
    $('.explore_map_content toggle_map')
        .addClass('active')
        .find('span')
        .html('hide map');
    return;
}

function search(q, search_type, extra_params) {
    // GA Tracking
    $.ga.trackEvent({ category : 'Explore', action : 'Search', label : ''});

    var is_archived = $('#is_archived').is(':checked');
    //toggle_map('hide', function() { scrollToElement('.toggle_map'); });

    $('.topic-listings .structure_left').html('<div style="text-align: center; padding-top: 50px;"><img src="/static/img/ajax-loader-ps.gif"></img></div>');

    var data = {
        q       : q,
        type    : !search_type ? null : search_type,
        archived: is_archived
    };

    utils.apply(data, extra_params);

    $.ajax({
        url     : '/explore/search/',
        dataType: 'json',
        data    : data,
        type    : 'GET',
        success: function(obj, textStatus, jqXHR) {
            $('.topic-listings .structure_left')
                .html(obj.html);

            // Horizontally align and form topic boxes
            $('.topic_boxes').imagesLoaded(function () {
                $('.topic_boxes').isotope({
                    itemSelector : '.topic_box',
                    resizable: false,
                    containerStyle: {
                        position: 'relative',
                        overflow: 'hidden'
                    },
                    masonry: {
                        columnWidth: 220,
                        gutterWidth: 19
                    }
                });
            });

            var map = gmaps['explore'];
            map.clearTopics();

            // Reset map toolbar
            $('#topic-categories-toolbar .selectable').each(function() {
                if ($(this).data('category') === 'all') {
                    $(this).click();
                }
            });

            // Load topic pins
            var topics = obj.data.topic_pins;
            for (var n=0, cnt=topics.length; n < cnt; n++){
                var topic = topics[n];
                map.addTopic(topic.id, topic.category, topic.coords[1], topic.coords[0], topic.plan_code);
            }
            map.fitExtentToMapData(map.TOPIC_PINS);
        },
        error: function(jqXHR, textStatus, errorThrown) {},
        complete: function(jqXHR, textStatus) {}
    });
}


$(function() {
    $('.toggle_map').click(function(e) {
        toggle_map();
    });

    $('#topic-search .search-btn').click(function(e) {
        search($('#topic-search input').val());
    });

    $('.category-filter').click(function(e) {
        search(
            $(this).data('filter'),
            'category',
            {
                'display_item': $(this).text()
            }
        );
    });

    $('.group-filter').click(function(e) {
        search(
            $(this).data('filter'),
            'group',
            {
                'display_item': $(this).text()
            }
        );
    });

    $('.organization-filter').click(function(e) {
        var filter = $(this).data('filter');
        search(
            filter,
            'organization',
            {
                'display_item': filter
            }
        );
    });

    $('.tag-filter').click(function(e) {
        var filter = $(this).data('filter');
        search(
            filter,
            'tag',
            {
                'display_item': filter
            }
        );
    });

    $(document).on('click', '#btn_connect_all', function(){
        var self = $(this);
        
        // Don't process if disabled
        if (self.hasClass('disabled')) { return; }

        var form = self.closest('form');
        self.addClass('disabled');
        $(form).ajaxSubmit({
            type: 'POST',
            clearForm: false,
            resetForm: false,
            dataType: 'json',
            success: function(obj, statusText, xhr, $form){
                if (obj.success) {
                    var plural = obj.data.new_connections != 1 ? 's' : '';
                    var alert_box = $("#connect-msg");
                    alert_box.find("span").html(
                        'You have ' + obj.data.new_connections +
                        ' new topic connection' + plural + '.'
                    );
                    alert_box.slideDown('fast')
                        .delay(5000)
                        .slideUp('fast', function() {
                            $(this).hide();
                        });
                }
                else {
                    if (obj.reason === 'login_required') {
                        redirect_to_login();
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
        
            },
            complete: function() {
                self.removeClass('disabled');
            }
        });
    });
    
    $(document).on('click', '.l_see_all_topics', function(){
        search(
            $(this).data('filter'),
            'group',
            {
                'display_item': $(this).data('display')
            }
        );

    });

    $('#topic-search input[name="search"]').keypress(function(event) {
        if ( event.which == 13 ) {
         event.preventDefault();
         search($('#topic-search input').val());
       }
    });
});