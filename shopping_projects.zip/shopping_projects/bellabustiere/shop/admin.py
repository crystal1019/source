'''
@author: chaol
'''
from django.contrib import admin
from django.contrib.contenttypes import generic
from django.http import HttpResponseRedirect
from django.contrib.sites.models import Site
from bellabustiere import helpers
from bellabustiere.shop.models import *
from django.forms.models import BaseInlineFormSet
from bellabustiere.shop.forms import OrderForm

from mptt.admin import MPTTModelAdmin

class RequiredInlineFormSet(BaseInlineFormSet):
    """
    Generates an inline formset that is required
    """

    def _construct_form(self, i, **kwargs):
        """
        Override the method to change the form attribute empty_permitted
        """
        form = super(RequiredInlineFormSet, self)._construct_form(i, **kwargs)
        form.empty_permitted = False
        return form

class CountryAdmin(admin.ModelAdmin):
    list_display = ('country', 'shipto',)
    list_filter = ('shipto',)
class StateAdmin(admin.ModelAdmin):
    list_display = ('name', 'country',)
    list_filter = ('country',)

class ProductImageInline(admin.TabularInline):
    model = ProductImage
    
class ProductSetPriceInline(admin.TabularInline):
    model = ProductSetPrice

class ProductOrderInline(admin.TabularInline):
    model = ProductOrder
   # template = 'admin/shop/order/inline.html'
    readonly_fields = ('coupon','view_product','check_discount_price', 'order_sale_applied', 'order_discount_applied', 'discount')
    
class VoucherOrderInline(admin.TabularInline):
    model = VoucherOrder

class ProductOrderAdmin(admin.ModelAdmin):
    
    list_display=('order','product', 'getCategory', 'quantity', 'getOrderStatus',)
    list_filter=('size','style',)
    search_fields =('product','size','style')

class TemandoLoggingInline(admin.StackedInline):
    max_num = 1   
    model = TemandoLogging
    readonly_fields = ('using_quote', 'booking_quote', 'book_info', 'companyName', 'requestID','consignmentNumber')
    exclude = ['all_quotes','consignmentDocument','labelDocument' ]
    
class MailCallLoggingInline(admin.StackedInline):
    max_num = 1
    model = MailCallLogging
    readonly_fields = ('book_date','book_response', 'status_response','lineno',  'show_private_link', 'show_bookings_link', 'show_wintrack_link',)
    exclude = ('private_link', 'bookings_link', 'wintrack_link')

class OrderAdmin(admin.ModelAdmin):
    list_display = ('getOrderNumber', 'user', 'status','shipping_charged','tax_charged', 'getTotalCharged','getTotalItems', 'coupon_used','started', 'updated','ordered','site','ip')
   
    readonly_fields = ('paid_from_website','site',)
    list_filter = ('status','is_wholesale','site' ,'started','updated')
    inlines = [
        ProductOrderInline, VoucherOrderInline, TemandoLoggingInline, MailCallLoggingInline,
    ]
    #readonly_fields = ('user','is_wholesale','shipping_charged','tax_charged','total_charged')
    search_fields = ('id', )
    form = OrderForm

    class Media:    
        js = ['/media/assets/javascripts/admin.js',]

    def get_readonly_fields(self, request, obj=None):
        if obj and obj.ordered:
            return list(self.readonly_fields) + ['ordered']
        return self.readonly_fields
    
    def change_view(self, request, object_id, extra_context=None):
        extra = {}
        if object_id:
            self.change_form_template = 'admin/shop/order/change_form.html'
            o = Order.objects.get(id=object_id)
            extra = {"o":o}
        return super(OrderAdmin, self).change_view(request, object_id,extra_context=extra)    
    
    def save_formset(self, request, form, formset, change):
       
        instances = formset.save()
        order = form.save(commit=True)
        if order.sync_order:

            helpers.sync_productorder(order)
                                
    # only valid if shipping_method can be edit, this function can show the available methods only for the user.
    '''
    def get_form(self, request, obj=None, **kwargs):
        form = super(OrderAdmin,self).get_form(request,**kwargs)
        
        if obj and obj.user:
            country = obj.getPostCountry()
            form.base_fields['shipping_method'].queryset = ShippingManagement.objects.filter(wholesale=obj.is_wholesale,countries__country=country)
        if not obj or not obj.user:
            form.base_fields['shipping_method'].queryset = ShippingManagement.objects.none()
        return form
    
    def queryset(self, request):
        #form.status.queryset = OrderStatus.objects.exclude(status="In Progress")
       
        return super(OrderAdmin,self).queryset(request).exclude(status__status="In Progress",is_wholesale=False)

    def changelist_view(self, request, extra_context=None):
        if not request.user.is_superuser:
            extra_context = {}
            extra_context['inprogress'] = True
        
        requesturi = request.META.get('REQUEST_URI','')
        if not request.GET:
            q = request.GET.copy()
            q['status__status__in'] = 'Ordered,Shipped,In Production,Pending,Order Completed via Phone,Ship Ready'
            request.GET = q
            request.META['QUERY_STRING'] = request.GET.urlencode()
        else:
            q = request.GET.copy()
            try:
                q.pop('status__status__in')
            except:
                pass
            request.GET = q
            request.META['QUERY_STRING'] = request.GET.urlencode()            
        #raise Exception({'1':request})
        return super(OrderAdmin, self).changelist_view(request, extra_context=extra_context)'''
    
    def lookup_allowed(self, key, *args):
        return True
    

class DiscountPriceAdmin(admin.ModelAdmin):
    list_display=('product','start','end','getCategory','getBrand','getActivity','priceoff','wholesale_priceoff','coupon')
    search_fields=('product__code','product__title')
    
    #inlines = [DiscountPriceInline,]
    #exclude = ('coupon',)
    actions =['add_to_coupon']
    DiscountPrice._meta.get_field('coupon').coupon_filter = True
    DiscountPrice._meta.get_field('price').in_coupon_filter = True
    #DiscountPrice._meta.get_field('product').category_filter = True
    list_filter=('start','end','coupon','price','product__category_now', 'product__brand', 'product__activity')
    #inlines = [ DiscountedPriceSizeInline, ]
    def add_to_coupon(self,request,queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        return HttpResponseRedirect('addtocoupon/?ids=%s' % ",".join(selected))
    
    def change_view(self, request, object_id, extra_context={}):
        
        if len(extra_context) > 0:                     
            ref = extra_context['ref']            
            result = super(DiscountPriceAdmin, self).change_view(request, object_id, extra_context.clear() )
            result['Location'] = ref       
            
        else:                   
            extra_context['ref'] = unicode( request.META.get('HTTP_REFERER', '') ) 
            result = super(DiscountPriceAdmin, self).change_view(request, object_id, extra_context )
            
        
        return result
    
    #this is to make the of this landing showing only the active ones
    def changelist_view(self, request, extra_context=None):
        now = datetime.datetime.now()
        ref = request.META.get('HTTP_REFERER','')
        path = request.META.get('PATH_INFO','')
        requesturi = request.META.get('REQUEST_URI','')
        if not request.GET:
            q = request.GET.copy()
            #q['start__lt'] = now
            q['end__gt'] = now
            q['coupon__isnull'] = "True"
            request.GET = q
            request.META['QUERY_STRING'] = request.GET.urlencode()
        return super(DiscountPriceAdmin,self).changelist_view(request, extra_context=extra_context)
    
    #for custom filterspec working, added to allow for django version after 1.3. 
    def lookup_allowed(self, key, *args):
        return True
    
class ProductSizeColorInline(admin.TabularInline):
    model = ProductSizeColor
    readonly_fields = ('color_check',)
    raw_id_fields = ('style',)
    

class ProductAdmin(admin.ModelAdmin):
    #prepopulated_fields = {"code": ("title",)}
    list_display = ('title', 'code', 'getCategory', 'getBrand', 'getActivity','weight', 'height', 'length', 'width','status','priority','shipping_countries')
    
    list_filter = ('category_now','brand','activity','status','sites')
    search_fields = ('code','title','description')
    list_editable = ('weight','height', 'length', 'width','status','priority')
    inlines = [
        ProductSizeColorInline, ProductImageInline,#ProductSetPriceInline
    ]

    
    filter_horizontal = ['related_products','related_look', 'shipping_only_to']
    
    actions = ['add_to_discountprice','add_to_category']
    def add_to_category(self,request,queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        return HttpResponseRedirect('addtocategory/?ids=%s' % ",".join(selected))
        
    def get_form(self,request, obj=None, **kwargs):
        form = super(ProductAdmin,self).get_form(request,obj=obj, **kwargs)
        form.base_fields['category_now'].label_from_instance = lambda obj:obj.getFullPath()
        
        return form
    

    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]

        
class CategoryAdmin(admin.ModelAdmin):
    fields = ("parent", "name", "slug", "image", "priority", "is_active")
    list_display = ("name", "parent", "priority", "is_active")
    list_filter = ("is_active", 'parent', "priority", )
    prepopulated_fields = {"slug": ("name",)}

class CategoriesAdmin(MPTTModelAdmin):
   # fields = ("parent", "name", "slug", "image", "priority", "is_active")
    list_display = ("name", "parent", "priority", "is_active","is_landing")
    list_editable = ("parent","priority","is_active")
    list_filter = ("is_active", 'parent', "priority","sites" )
    prepopulated_fields = {"slug": ("name",)}
    
    actions_on_top = False
    
    '''def changelist_view(self, request, extra_context=None):
        raise Exception({'choices':choices})
        return super(CategoriesAdmin, self).changelist_view(request, extra_context=extra_context)'''
    
    def get_form(self, request, obj=None, **kwargs):
        form = super(CategoriesAdmin, self).get_form(request,obj=obj,**kwargs)
        landing = Categories.objects.filter(is_landing=True)
        if landing and obj not in landing:
            form.base_fields['is_landing'].widget.attrs['disabled'] = 'disabled'
            
        return form

    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]

        

    
class ProductSizePriceAdmin(admin.ModelAdmin):
    list_display = ('product','size','price','wholesale_price')
    list_filter = ('product', 'size')
    search_fields = ('product','size')



class CouponAdmin(admin.ModelAdmin):
    list_display= ('name','codes',)
    
    def change_view(self, request, object_id, extra_context=None):
        extra = {}
        if object_id:
            self.change_form_template = 'admin/shop/coupon/coupon_form.html'
            coupon = Coupon.objects.get(id=object_id)
            display = coupon.discountprice_set.all() if request.GET.get('show_all','') == 'yes' else coupon.discountprice_set.all()[:50]
            extra = {"coupon":coupon, 'display':display}
        return super(CouponAdmin, self).change_view(request, object_id,extra_context=extra)    
    #inlines = [DiscountPriceInline,]
    #__name__ = 'discountprice_set'
    
class ShippingDiscountAdmin(admin.ModelAdmin):
    list_display=('name','off')
    list_editable=('off',)


class ShippingBasedInline(admin.TabularInline):
    model = ShippingBased
    extra = 0
    formset = RequiredInlineFormSet
    
class ShippingManagementAdmin(admin.ModelAdmin):
    inlines = [ShippingBasedInline,]
    list_display = ('name','api','fixed_shipping','display_countries')
    list_editable = ('api','fixed_shipping')
    list_filter = ('countries',)
    filter_horizontal = ('countries',)
    
    #each country can only have 2 shipping method,one for retail, the other for wholesale 
    def get_form(self,request, obj=None, **kwargs):
        form = super(ShippingManagementAdmin,self).get_form(request, **kwargs)

        sm = ShippingManagement.objects.all()
        cs = []
        for x in sm:
            cs += x.countries.all()
        if not obj:
            form.base_fields['countries'].queryset = Country.objects.exclude(country__in=cs)
            
        else:
            itself = obj.countries.all()
            newcs = list(set(cs) - set(itself))
            form.base_fields['countries'].queryset = Country.objects.exclude(country__in=newcs)
                
        return form
    
class StyleAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'show_color')
    
class BrandAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug':('name',)}
    list_display = ('name', 'is_landing')
    filter_horizontal = ('shipping_only_to',)
    
    def get_form(self, request, obj=None, **kwargs):
        form = super(BrandAdmin, self).get_form(request,obj=obj,**kwargs)
        landing = Brand.objects.filter(is_landing=True)
        if landing and obj not in landing:
            form.base_fields['is_landing'].widget.attrs['disabled'] = 'disabled'
            
        return form
    
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]

    
class ActivityAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug':('name',)}
    list_display = ('name', 'is_landing')
    
    def get_form(self, request, obj=None, **kwargs):
        form = super(ActivityAdmin, self).get_form(request,obj=obj,**kwargs)
        landing = Activity.objects.filter(is_landing=True)
        if landing and obj not in landing:
            form.base_fields['is_landing'].widget.attrs['disabled'] = 'disabled'
            
        return form
    
    class Media:
        js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]


class SaleBasedInline(admin.TabularInline):
    model = SaleBased
    extra = 0
    formset = RequiredInlineFormSet

class SaleAdmin(admin.ModelAdmin):
    list_display = ('__unicode__','message','priority','start','end')
    list_editable = ('message','priority','start','end')
    inlines = [SaleBasedInline,]
    list_filter = ('start', 'end', 'sites')
    
    def change_view(self, request, object_id, extra_context={}):
        
        if len(extra_context) > 0:                     
            ref = extra_context['ref']            
            result = super(SaleAdmin, self).change_view(request, object_id, extra_context.clear() )
            result['Location'] = ref       
            
        else:                   
            extra_context['ref'] = unicode( request.META.get('HTTP_REFERER', '') ) 
            result = super(SaleAdmin, self).change_view(request, object_id, extra_context )
            
        
        return result

class VoucherAdmin(admin.ModelAdmin):
    list_display = ('code', 'valid', 'valid_from', 'valid_to', 'repeat_use', 'is_used', 'is_valid', 'current_value', 'order_use_history')
    
class ProductSizeColorAdmin(admin.ModelAdmin):
    list_display = ('product', 'size', 'style', 'inventory' )
    list_editable = ('inventory',)
    list_filter = ('product__category_now', 'size', 'style', 'product__brand', 'product__activity')
    search_fields = ['product__code', 'product__title']
    
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ('product', 'star', 'is_active', 'comment','created')
    list_editable = ('is_active',)

    actions = ['set_as_spammers',]
    
    def set_as_spammers(self,request,queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        return HttpResponseRedirect('addtospammerslist/?ids=%s' % ",".join(selected))

class CollectionAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug':('name',)}
    filter_horizontal = ('pages',)

admin.site.register(Collection, CollectionAdmin)
admin.site.register(ProductReview, ProductReviewAdmin)
#admin.site.register(Category, CategoryAdmin)
admin.site.register(TaxRate)
#admin.site.register(ShippingDiscount,ShippingDiscountAdmin)
admin.site.register(Size)
admin.site.register(Style, StyleAdmin)
#admin.site.register(Set)
admin.site.register(ProductStatus)
admin.site.register(Product, ProductAdmin)
#admin.site.register(PackageProduct)
admin.site.register(DiscountPrice,DiscountPriceAdmin)
admin.site.register(OrderStatus)
#admin.site.register(ProductOrder, ProductOrderAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(Categories,CategoriesAdmin)
admin.site.register(Coupon,CouponAdmin)
admin.site.register(ShippingManagement,ShippingManagementAdmin)
#admin.site.register(ProductSizePrice, ProductSizePriceAdmin)
admin.site.register(Brand, BrandAdmin)
admin.site.register(Activity, ActivityAdmin)
admin.site.register(Sale, SaleAdmin)
admin.site.register(StyleGroup)
admin.site.register(SizeGroup)
admin.site.register(Voucher, VoucherAdmin)
admin.site.register(ProductSizeColor, ProductSizeColorAdmin)
admin.site.register(FreeShippingValue)

from django.contrib.auth.admin import UserAdmin as DJUserAdmin
from bellabustiere.admin import filterspec
from django.db import connection
admin.site.unregister(User)

def get_company(self):
    try:
        company = self.get_profile().company
    except:
        company = ''
    return company
get_company.short_description='Company'

def view_profile(self):
    return "<a href='/admin/userprofile/profile/%s/'>view this profile</a>" %self.get_profile().id

view_profile.allow_tags = True

User.add_to_class('get_company', get_company)
User.add_to_class('view_profile', view_profile)

class RetailUserAdmin(DJUserAdmin):
    model = User
    #User._meta.get_field('username').wholesale_filter = True
    User._meta.get_field('first_name').site_user_filter = True
    #User._meta.get_field('first_name').company_filter = True
    list_display = ['username', 'first_name', 'last_name','get_company' ,'is_active', 'is_staff', 'last_login','view_profile']
    list_filter = ['profile__member', 'is_active', 'is_staff','first_name']
    list_editable = ['is_active', 'is_staff']
    staff_fieldsets = (
        (None, {'fields': ('username',)}),
        (('Personal info'), {'fields': ('first_name', 'last_name', 'email')}),
        (('Permissions'),{'fields':('is_active','is_staff')}),
        #(('Important dates'), {'fields': ('last_login', 'date_joined')}),
        (('Groups'), {'fields': ('groups',)}),
    )

    def change_view(self, request, *args, **kwargs):
        # for non-superuser
        if not request.user.is_superuser:
            try:
                self.fieldsets = self.staff_fieldsets
                response = DJUserAdmin.change_view(self, request, *args, **kwargs)
            finally:
                # Reset fieldsets to its original value
                self.fieldsets = DJUserAdmin.fieldsets
            return response
        else:
            return DJUserAdmin.change_view(self, request, *args, **kwargs)
    
    def queryset(self, request):
        #form.status.queryset = OrderStatus.objects.exclude(status="In Progress")
        if not request.user.is_superuser:
            return super(DJUserAdmin,self).queryset(request).exclude(is_superuser=True) 
        else:
            return super(DJUserAdmin,self).queryset(request)
#    def queryset(self, request):
#        raise ValueError(str(dir(User.objects.filter()[0])))
#        qs = super(RetailUserAdmin, self).queryset(request).exclude(username__startswith="retail")
#        if request.GET.get("username__istartswith", "").lower() == "retail_":
#            qs.filter(username__istartswith="retail_")
#        if int(request.GET.get("is_active__exact", 1)) == 0:
#            pass
#        qs.exclude(username__startswith="retail")
#        #return ValueError(connection.queries)
#        return qs

admin.site.register(User, RetailUserAdmin)
