angular.module('topic.controllers', [])
    .controller('TopicCtrl', ['$scope', '$location', '$http', 'TopicService',
        function($scope, $location, $http, TopicService) {
            $scope.old_browser = (BrowserDetect.browser == 'Explorer' && BrowserDetect.version < 9) ? true : false;
            //http://stackoverflow.com/a/18265285/2807539
            $scope.safeApply = function(fn) {
                var phase = this.$root.$$phase;
                if (phase == '$apply' || phase == '$digest') {
                    if (fn) {
                        fn();
                    }
                } else {
                    this.$apply(fn);
                }
            };

            $scope.$watch('$location.path()', function(new_val) {
                $scope.current_tab = new_val;
            });

            $scope.$location = $location;
            $scope.topic = data.topic;
            TopicService.init();
            $scope.can_post = TopicService.can_post;
            $scope.can_moderate = TopicService.can_moderate;
            $scope.getData = function(data_name) {
                var p = $http({
                    method: 'GET',
                    url: '/topic/json/' + data_name + '/',
                    params: {
                        'topic': $scope.topic
                    }
                });
                return p;
            }
        }
    ])
    .controller('DiscussionsCtrl', ['$scope', '$http', '$modal', '$q', 'TopicService',
        function($scope, $http, $modal, $q, TopicService) {
            $scope.discussions = null;
            $scope.open_threads = [];
            $scope.open_replies = [];
            $scope.reply_to_thread = null;
            $scope.reply_to_post = null;
            $scope.followed_threads = [];
            $scope.viewed_threads = [];

            $scope.report_comment = null;
            $scope.report_type = null;

            var watcher = $scope.$watch('current_tab', function(current, old) {
                if (current === '/discussions') {
                    if (angular.isDefined(TopicService.store.discussions)) {
                        $scope.discussions = TopicService.store.discussions.data;
                        $scope.followed_threads = TopicService.store.discussions.followed;
                        $scope.status = 'ready';
                    } else {
                        $scope.getData('discussions')
                            .success(function(obj) {
                                $scope.discussions = obj.data;
                                $scope.followed_threads = obj.followed;
                                $scope.status = 'ready';
                            })
                            .error(function(data, status, headers, config) {
                                // console.log(data, status, headers, config);
                            });
                    }
                    watcher();
                }
            });

            $scope.reportComment = function(obj, obj_type) {
                $scope.report_comment = obj;
                $scope.report_type = obj_type;
                var modalPromise = $modal({
                    template: '/static/apps/topic/partials/report_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };

            $scope.moderateComment = function(obj, obj_type) {
                $scope.report_comment = obj;
                $scope.report_type = obj_type;
                var modalPromise = $modal({
                    template: '/static/apps/topic/partials/moderate_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };

            $scope.sendReport = function(modal) {
                modal('hide');
                $http.post(
                    '/topic/json/discussions/report/', {
                        'post_type': $scope.report_type,
                        'obj_id': $scope.report_comment.id
                    }
                ).success(function(obj) {}).error(function(data, status) {});
            };

            $scope.sendModerate = function(msg, modal) {
                $http.post(
                    '/topic/json/discussions/moderate/', {
                        'post_type': $scope.report_type,
                        'obj_id': $scope.report_comment.id,
                        'reason': msg
                    }
                ).success(function(obj) {
                    if (!obj.hasOwnProperty('errors')) {
                        $scope.report_comment.is_moderated = true;
                        if(angular.isDefined(msg)){
                            $scope.report_comment.mod_description = msg;
                        }else{
                            $scope.report_comment.mod_description = 'No reason provided';
                        }
                        $scope.report_comment.can_vote.up = false;
                        $scope.report_comment.can_vote.down = false;
                        modal('hide');
                    } else {

                    }
                }).error(function(data, status) {});
            };

            $scope.toggleReplies = function(post_id) {
                if (_.contains($scope.open_replies, post_id)) {
                    $scope.open_replies = _.reject($scope.open_replies, function(r) {
                        return r == post_id;
                    });
                } else {
                    $scope.reply_to_post = null;
                    $scope.open_replies.push(post_id);
                }
            };

            $scope.vote = function(vote, obj_type, obj) {
                if ((vote === 1 && obj.can_vote.up) || (vote === -1 && obj.can_vote.down)) {
                    if (vote === 1) {
                        obj.up_votes += 1;
                        if (!obj.can_vote.down) {
                            obj.down_votes -= 1;
                        }
                        obj.can_vote.up = false;
                        obj.can_vote.down = true;
                    } else {
                        obj.down_votes += 1;
                        if (!obj.can_vote.up) {
                            obj.up_votes -= 1;
                        }
                        obj.can_vote.down = false;
                        obj.can_vote.up = true;
                    }

                    $http.post(
                        '/topic/json/threads/vote/', {
                            'obj_type': obj_type,
                            'obj': obj,
                            'vote': vote
                        }
                    ).success(function(obj) {}).error(function(data, status) {});
                }
            };

            $scope.toggleComments = function(thread_id) {
                if (_.contains($scope.open_threads, thread_id)) {
                    $scope.open_threads = _.reject($scope.open_threads, function(t) {
                        return t == thread_id;
                    });
                } else {
                    $scope.reply_to_thread = null;
                    $scope.open_threads.push(thread_id);
                    if (!_.contains($scope.viewed_threads, thread_id)) {
                        $http.post(
                            '/topic/json/discussions/update_view_count/', {
                                'thread_id': thread_id
                            }
                        ).success(function(obj) {}).error(function(data, status) {});
                        $scope.viewed_threads.push(thread_id);
                    }
                }
            };

            $scope.cancelComment = function() {
                $scope.reply_to_thread = null;
                $scope.reply_to_post = null;
            };

            $scope.replyComment = function(post) {
                if (!$scope.can_post || post.is_moderated) {
                    return;
                }
                $scope.reply_to_thread = null;
                $scope.open_replies = _.reject($scope.open_replies, function(r) {
                    return r === post.id;
                });
                $scope.reply_to_post = post.id;
            };

            $scope.threadComment = function(thread_id) {
                if (!$scope.can_post) {
                    return;
                }
                $scope.reply_to_post = null;
                $scope.open_threads = _.reject($scope.open_threads, function(t) {
                    return t === thread_id;
                });
                $scope.reply_to_thread = thread_id;
            };

            $scope.postComment = function(post_content, obj_id, reply_to_type) {
                if (!$scope.can_post) {
                    return;
                }
                if (reply_to_type == 'thread') {
                    var thread = _.find($scope.discussions, {
                        id: obj_id
                    });
                    var new_index = thread.posts.push({
                        content: post_content
                    }) - 1;
                    $scope.reply_to_thread = null;
                    $scope.open_threads.push(obj_id);
                    if (!_.contains($scope.followed_threads, thread.id)) {
                        $scope.followed_threads.push(thread.id);
                    }
                }
                if (reply_to_type == 'post') {
                    for (var i = 0, len = $scope.discussions.length; i < len; i++) {
                        var post = _.find($scope.discussions[i].posts, {
                            id: obj_id
                        });
                        if (angular.isDefined(post)) {
                            var new_index = post.replies.push({
                                content: post_content
                            }) - 1;
                            $scope.reply_to_post = null;
                            $scope.open_replies.push(obj_id);
                            if (!_.contains($scope.followed_threads, $scope.discussions[i].id)) {
                                $scope.followed_threads.push($scope.discussions[i].id);
                            }
                            break;
                        }
                    }
                }
                $http.post(
                    '/topic/json/discussions/post/', {
                        'obj_id': obj_id,
                        'post_content': post_content,
                        'reply_to_type': reply_to_type
                    }
                ).success(function(obj) {
                    if (!obj.hasOwnProperty('errors')) {
                        if (reply_to_type == 'thread') {
                            thread.posts[new_index] = obj;
                        }
                        if (reply_to_type == 'post') {
                            post.replies[new_index] = obj;
                        }
                    } else {
                        if (reply_to_type == 'thread') {
                            var content = thread.posts[new_index].content;
                            thread.posts.splice(new_index, 1);
                            $scope.threadComment(thread.id);
                            $scope.$broadcast('post-error', {
                                'type': reply_to_type,
                                'obj_id': thread.id,
                                'text_content': content,
                                'errors': obj.errors
                            });
                        }
                        if (reply_to_type == 'post') {
                            var content = post.replies[new_index].content;
                            post.replies.splice(new_index, 1);
                            $scope.replyComment(post);
                            $scope.$broadcast('post-error', {
                                'type': reply_to_type,
                                'obj_id': post.id,
                                'text_content': content,
                                'errors': obj.errors
                            });
                        }
                    }
                }).error(function(data, status) {});
            };

            $scope.toggleFollowThread = function(thread_id) {
                if (_.contains($scope.followed_threads, thread_id)) {
                    $scope.followed_threads = _.reject($scope.followed_threads, function(n) {
                        return n === thread_id;
                    });
                } else {
                    $scope.followed_threads.push(thread_id);
                }
                $http.post(
                    '/topic/json/discussions/toggle_follow_thread/', {
                        'thread_id': thread_id
                    }
                ).success(function(obj) {}).error(function(data, status) {});
            };

            $scope.toggleFollowAll = function() {
                if ($scope.followed_threads.length > 0) {
                    $scope.followed_threads = [];
                } else {
                    for (var i = 0, len = $scope.discussions.length; i < len; i++) {
                        $scope.followed_threads.push($scope.discussions[i].id);
                    }
                }
                $http.post(
                    '/topic/json/discussions/toggle_follow_all/', {
                        'topic_id': $scope.topic
                    }
                ).success(function(obj) {}).error(function(data, status) {});
            };
        }
    ])
    .controller('NoticeboardCtrl', ['$scope', '$http', '$modal', '$q', 'TopicService',
        function($scope, $http, $modal, $q, TopicService) {
            $scope.noticeboard_posts = null;
            $scope.noticeboard_id = null;
            $scope.open_replies = [];
            $scope.post_type = 'text';
            $scope.post_content = '';
            $scope.post_images = [];
            $scope.post_video = '';
            $scope.followed_nb = [];
            $scope.post_errors = [];
            $scope.post_in_progress = false;

            var watcher = $scope.$watch('current_tab', function(current, old) {
                if (current === '/noticeboard') {
                    if (angular.isDefined(TopicService.store.noticeboard)) {
                        $scope.noticeboard_posts = TopicService.store.noticeboard.data;
                        $scope.followed_nb = TopicService.store.noticeboard.followed;
                        $scope.noticeboard_id = TopicService.store.noticeboard.followed;
                        $scope.status = 'ready';
                    } else {
                        $scope.getData('noticeboard')
                            .success(function(obj) {
                                $scope.noticeboard_posts = obj.data;
                                $scope.followed_nb = obj.followed;
                                $scope.noticeboard_id = obj.noticeboard_id;
                                $scope.status = 'ready';
                            })
                            .error(function(data, status, headers, config) {
                                // console.log(data, status, headers, config);
                            });
                    }
                    watcher();
                }
            });

            $scope.deleteImage = function(image) {
                $scope.post_images = _.reject($scope.post_images, function(i) {
                    return i === image;
                });
            };

            $scope.reportComment = function(obj, obj_type) {
                $scope.report_comment = obj;
                $scope.report_type = obj_type;
                var modalPromise = $modal({
                    template: '/static/apps/topic/partials/report_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };

            $scope.moderateComment = function(obj, obj_type) {
                $scope.report_comment = obj;
                $scope.report_type = obj_type;
                var modalPromise = $modal({
                    template: '/static/apps/topic/partials/moderate_modal.html',
                    persist: true,
                    show: false,
                    backdrop: 'static',
                    scope: $scope
                });
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };

            $scope.sendReport = function(modal) {
                modal('hide');
                $http.post(
                    '/topic/json/discussions/report/', {
                        'post_type': $scope.report_type,
                        'obj_id': $scope.report_comment.id
                    }
                ).success(function(obj) {}).error(function(data, status) {});
            };

            $scope.sendModerate = function(msg, modal) {
                $http.post(
                    '/topic/json/discussions/moderate/', {
                        'post_type': $scope.report_type,
                        'obj_id': $scope.report_comment.id,
                        'reason': msg
                    }
                ).success(function(obj) {
                    if (!obj.hasOwnProperty('errors')) {
                        $scope.report_comment.is_moderated = true;
                        $scope.report_comment.mod_description = msg;
                        $scope.report_comment.can_vote.up = false;
                        $scope.report_comment.can_vote.down = false;
                        modal('hide');
                    } else {

                    }
                }).error(function(data, status) {});
            };

            $scope.toggleFollowThread = function() {

                if (_.contains($scope.followed_nb, $scope.noticeboard_id)) {
                    $scope.followed_nb = _.reject($scope.followed_nb, function(n) {
                        return n === $scope.noticeboard_id;
                    });
                } else {
                    $scope.followed_nb.push($scope.noticeboard_id);
                }
                $http.post(
                    '/topic/json/discussions/toggle_follow_thread/', {
                        'thread_id': $scope.noticeboard_id
                    }
                ).success(function(obj) {}).error(function(data, status) {});
            };

            $scope.togglePostType = function(p_type) {
                $scope.post_type = p_type;
            };

            $scope.toggleReplies = function(post_id) {
                if (_.contains($scope.open_replies, post_id)) {
                    $scope.open_replies = _.reject($scope.open_replies, function(r) {
                        return r == post_id;
                    });
                } else {
                    $scope.reply_to_post = null;
                    $scope.open_replies.push(post_id);
                }
            };

            $scope.cancelComment = function() {
                $scope.reply_to_thread = null;
                $scope.reply_to_post = null;
            };

            $scope.replyComment = function(post) {
                if (!$scope.can_post || post.is_moderated) {
                    return;
                }
                $scope.reply_to_thread = null;
                $scope.open_replies = _.reject($scope.open_replies, function(r) {
                    return r === post.id;
                });
                $scope.reply_to_post = post.id;
            };

            $scope.vote = function(vote, obj_type, obj) {
                if ((vote === 1 && obj.can_vote.up) || (vote === -1 && obj.can_vote.down)) {
                    if (vote === 1) {
                        obj.up_votes += 1;
                        if (!obj.can_vote.down) {
                            obj.down_votes -= 1;
                        }
                        obj.can_vote.up = false;
                        obj.can_vote.down = true;
                    } else {
                        obj.down_votes += 1;
                        if (!obj.can_vote.up) {
                            obj.up_votes -= 1;
                        }
                        obj.can_vote.down = false;
                        obj.can_vote.up = true;
                    }

                    $http.post(
                        '/topic/json/threads/vote/', {
                            'obj_type': obj_type,
                            'obj': obj,
                            'vote': vote
                        }
                    ).success(function(obj) {}).error(function(data, status) {});
                }
            };

            $scope.postComment = function(post_content, obj_id, reply_to_type) {
                if (!$scope.can_post) {
                    return;
                }
                if (reply_to_type == 'post') {
                    var post = _.find($scope.noticeboard_posts, {
                        id: obj_id
                    });
                    if (angular.isDefined(post)) {
                        var new_index = post.replies.push({
                            content: post_content
                        }) - 1;
                        $scope.reply_to_post = null;
                        $scope.open_replies.push(obj_id);
                    }
                }
                $http.post(
                    '/topic/json/discussions/post/', {
                        'obj_id': obj_id,
                        'post_content': post_content,
                        'reply_to_type': reply_to_type
                    }
                ).success(function(obj) {
                    if (reply_to_type == 'thread') {
                        thread.posts[new_index] = obj;
                    }
                    if (reply_to_type == 'post') {
                        post.replies[new_index] = obj;
                    }
                }).error(function(data, status) {});
            };

            $scope.validatePostForm = function() {
                if ($scope.post_type == 'text') {
                    if ($scope.post_content.length == 0) {
                        $scope.form_nb_post.post_content.$setValidity('no_text', false);
                        return false;
                    }
                    return true;
                }
                if ($scope.post_type == 'image') {
                    $scope.form_nb_post.post_content.$setValidity('blank', true);
                    if ($scope.post_images.length == 0) {
                        $scope.form_nb_post.$setValidity('no_images', false);
                        return false;
                    }
                    return true;
                }
                if ($scope.post_type == 'video') {
                    $scope.form_nb_post.post_content.$setValidity('blank', true);
                    if ($scope.post_video.length == 0) {
                        $scope.form_nb_post.videourl.$setValidity('no_video', false);
                        return false;
                    }
                    return true;
                }
            };

            $scope.resetPostForm = function() {
                $scope.post_video = '';
                $scope.post_images = [];
                $scope.post_content = '';
                $scope.form_nb_post.$setPristine();
            };

            $scope.makePost = function() {
                if ($scope.post_in_progress || !$scope.can_post) {
                    return;
                }
                if ($scope.validatePostForm()) {
                    $scope.post_errors = [];
                    $scope.post_in_progress = true;
                    var post_data = {
                        post_content: $scope.post_content,
                        thread_id: $scope.noticeboard_id,
                        post_type: angular.copy($scope.post_type)
                    };

                    if ($scope.post_type == 'image') {
                        post_data.images = $scope.post_images;
                    }
                    if ($scope.post_type == 'video') {
                        post_data.video_url = $scope.post_video;
                    }
                    if (!_.contains($scope.followed_nb, $scope.noticeboard_id)) {
                        $scope.followed_nb.push($scope.noticeboard_id);
                    }
                    $http.post(
                        '/topic/json/noticeboard/post/',
                        post_data
                    ).success(function(obj) {
                        $scope.post_in_progress = false;
                        if (!obj.hasOwnProperty('errors')) {
                            $scope.noticeboard_posts.unshift(obj);
                            $scope.resetPostForm();
                        } else {
                            $scope.post_errors = obj.errors;
                        }
                    }).error(function(data, status) {});
                }
            };
        }
    ])
    .controller('ResourceCtrl', ['$scope', '$http', '$modal', '$q', 'TopicService',
        function($scope, $http, $modal, $q, TopicService) {
            $scope.resources = null;
            var watcher = $scope.$watch('current_tab', function(current, old) {
                if (current === '/resources') {
                    if (angular.isDefined(TopicService.store.resources)) {
                        $scope.resources = TopicService.store.resources;
                        $scope.status = 'ready';
                    } else {
                        $scope.getData('resources')
                            .success(function(obj) {
                                $scope.resources = obj;
                                $scope.status = 'ready';
                            })
                            .error(function(data, status, headers, config) {
                                // console.log(data, status, headers, config);
                            });
                    }
                    watcher();
                }
            });
            var modalPromise = $modal({
                template: '/static/apps/topic/partials/fullscreen_image_modal.html',
                persist: true,
                show: false,
                backdrop: 'static',
                scope: $scope
            });
            $scope.$on('modal.hide', function() {
                $scope.selected_img = null;
            });

            $scope.fullscreenImage = function(image){
                $scope.selected_img = image;
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };
        }
    ])
    .controller('EventsCtrl', ['$scope', '$http', 'TopicService',
        function($scope, $http, TopicService) {
            $scope.loaded = false;
            $scope.upcoming_events = [];
            $scope.past_events = [];
            $scope.calculateUpcomingOrPast = function(data) {
                var current_time = moment();
                for (var i = 0, len = data.length; i < len; i++) {
                    var start = null;
                    var end = null;
                    if(data[i].all_day_event){
                        start = moment(data[i].event_date, 'YYYY-MM-D');
                        data[i].event_date = start;
                        if(current_time.isAfter(start, 'day')) {
                            $scope.past_events.push(data[i]);
                        } else {
                            $scope.upcoming_events.push(data[i]);
                        }
                    } else {
                        if(data[i].start_with_tz){
                            start = moment(data[i].start_with_tz);
                            data[i].start_with_tz = start;
                        }
                        if(data[i].end_with_tz){
                            end = moment(data[i].end_with_tz);
                            data[i].end_with_tz = end;
                        }
                        if(end !== null){
                            if(current_time.isAfter(end)){
                                $scope.past_events.push(data[i]);
                            } else {
                                $scope.upcoming_events.push(data[i]);
                            }
                        } else if (start !== null){
                            if(current_time.isAfter(start)){
                                $scope.past_events.push(data[i]);
                            } else {
                                $scope.upcoming_events.push(data[i]);
                            }
                        } else {
                            $scope.past_events.push(data[i]);
                        }
                    }
                }
            };
            var watcher = $scope.$watch('current_tab', function(current, old) {
                if (current === '/events') {
                    if (angular.isDefined(TopicService.store.events)) {
                        $scope.calculateUpcomingOrPast(TopicService.store.events);
                        $scope.status = 'ready';
                        $scope.loaded = true;
                    } else {
                        $scope.getData('events')
                            .success(function(obj) {
                                $scope.calculateUpcomingOrPast(obj);
                                $scope.status = 'ready';
                                $scope.loaded = true;
                            })
                            .error(function(data, status, headers, config) {
                                // console.log(data, status, headers, config);
                            });
                    }
                    watcher();
                }
            });
        }
    ])
    .controller('OverviewMapCtrl', ['$scope', '$http', '$modal', '$q',
        function($scope, $http, $modal, $q) {
            $scope.places = null;
            $scope.polygons = null;
            $scope.tab_loaded = false;
            $scope.gmap = null;
            $scope.polygons_layer = null;
            $scope.place_layer = null;
            $scope.seed_marker = null;
            var watcher = $scope.$watch('current_tab', function(current, old) {
                if (current === '/overview') {
                    $scope.status = 'ready';
                    $scope.tab_loaded = true;
                    $scope.getData('participants')
                        .success(function(obj) {
                            $scope.places = obj;
                        })
                        .error(function(data, status, headers, config) {
                            // console.log(data, status, headers, config);
                        });

                    $scope.getData('polygons')
                        .success(function(obj) {
                            $scope.polygons = obj;
                        })
                        .error(function(data, status, headers, config) {
                            // console.log(data, status, headers, config);
                        });

                    $scope.getData('seed_data')
                        .success(function(obj) {
                            var topic_type = obj['topic_type'];
                            if (topic_type == 'seed') {
                                $scope.seed_marker = obj['map_center'];
                            }
                        })
                        .error(function(data, status, headers, config) {
                            // console.log(data, status, headers, config);
                        });
                    watcher();
                }
            });

            var modalPromise = $modal({
                template: '/static/apps/topic/partials/fullscreen_map_modal.html',
                persist: true,
                show: false,
                backdrop: 'static',
                scope: $scope
            });

            $scope.fullscreenMap = function() {
                $q.when(modalPromise).then(function(modalEl) {
                    modalEl.modal('show');
                });
            };
        }
    ])
    .controller('InputMapFormCtrl', ['$scope', '$http', '$q', 'IMData',
        function($scope, $http, $q, $location, IMData) {
            $scope.NEW_POST_URL = '/topics/im/newpost/';

            $scope.$on('cancel-comment', function() {
                $scope.cancelComment();
            });
            $scope.cancelComment = function() {
                $scope.IMData.infowindow.close();
                $scope.IMData.store.inputmap.comment_schema = angular.copy($scope.clean_comment_schema);
                $scope.form_im_post.$setPristine();
                $scope.IMData.gmarklayer.removeUnsavedMarker();
                $scope.IMData.gmarklayer.enableCommenting();
                $scope.selected_feature = null;
            };
            $scope.savePost = function() {
                $scope.selected_feature.creation = false;
                $scope.selected_feature.vote_counts = {
                    up: 0,
                    down: 0
                };
                $scope.selected_feature.ps_data = {};
                $scope.selected_feature.ps_data.vote_counts = {
                    up: 0,
                    down: 0
                };
                $scope.selected_feature.ps_data.author = {};
                $scope.selected_feature.ps_data.author.id = $scope.user;
                $scope.selected_feature.ps_data.comment = angular.copy($scope.IMData.store.inputmap.comment_schema);
                $scope.selected_feature.marker_type = 'comment';
                $scope.IMData.infowindow.close();
                $scope.IMData.infowindow.open($scope.current_map.map, $scope.selected_feature);
                $scope.IMData.gmarklayer.disableCommenting();
                $scope.IMData.layer.setClickable(true);
                $scope.selected_feature.setDraggable(false);
                $scope.IMData.gmarklayer.unsaved_marker = null;
                $scope.IMData.gmarklayer.unclustered_markers.push($scope.selected_feature);

                $http.post(
                    $scope.NEW_POST_URL, {
                        comment: $scope.IMData.store.inputmap.comment_schema,
                        topic: $scope.topic,
                        location: {
                            lat: $scope.selected_feature.position.lat(),
                            lng: $scope.selected_feature.position.lng()
                        }
                    }
                )
                    .success(function(obj) {
                        $scope.IMData.store.posts.push(obj.data);
                        $scope.selected_feature.ps_data = obj.data;
                        $scope.IMData.gmarklayer.posts.push($scope.selected_feature);
                        $scope.IMData.infowindow.close();
                        $scope.IMData.infowindow.open($scope.current_map.map, $scope.selected_feature);
                    });

                $scope.IMData.store.inputmap.comment_schema = angular.copy($scope.clean_comment_schema);
                $scope.form_im_post.$setPristine();
            };
        }
    ])
    .controller('InputMapCtrl', ['$scope', '$http', '$q', '$location', '$modal', 'IMData',
        function($scope, $http, $q, $location, $modal, IMData) {
            $scope.IMData = IMData;
            $scope.topic = data.topic; // from global
            $scope.is_geomarks_visible = false;
            $scope.is_posts_visible = false;
            $scope.current_sort = 'time';
            $scope.selected_feature = null;
            $scope.map_tools = {
                comment: true,
                fullscreen: true
            };
            $scope.fullscreen_map = {};
            $scope.fullscreen_dimensions = {
                width: window.innerWidth,
                height: window.innerHeight
            };
            $scope.out_of_bounds = false;
            $scope.new_comment_prev_latlng = null;
            $scope.new_comment_new_latlng = null;
            $scope.clean_comment_schema = {};
            $scope.user = data.user;
            var watcher = $scope.$watch('current_tab', function(current, old) {
                if (current === '/place-it') {
                    $scope.IMData.load($scope.topic, false).then(function(obj) {
                        $scope.clean_comment_schema = angular.copy($scope.IMData.store.inputmap.comment_schema);
                        for (var i = 0, len = obj.data.posts.length; i < len; i++) {
                            var result = $scope.checkUserVote(obj.data.posts[i]);
                            if (result === 1) {
                                obj.data.posts[i].hasVotedUp = true;
                            } else if (result === -1) {
                                obj.data.posts[i].hasVotedDown = true;
                            }
                        }
                    }, function(reason) {});
                    watcher();
                }
            });
            $scope.stopAllEditing = function() {
                $scope.toggleCommenting();
                $scope.IMData.layer.setClickable(true);
            };
            $scope.showFullscreenMap = function() {
                $scope.selected_feature = null;
                $scope.IMData.infowindow.close();
                var modalPromise = $modal({
                    template: '/static/apps/topic/partials/inputmap_fullscreen_modal.html',
                    show: false,
                    backdrop: 'static',
                    scope: $scope,
                    persist: false
                });
                $q.when(modalPromise).then(function(modalEl) {
                    $scope.$modal = modalEl.modal;
                    modalEl.modal('show');
                });
            };
            // Load data

            $scope.$watch('selected_feature', function(current_feat, prev_feat) {
                if (current_feat !== null) {
                    if (!angular.isDefined(current_feat.center_marker) && current_feat.feature_type == 'polygon') {
                        current_feat.center_marker = $scope.IMData.layer.getFeatureCenter(current_feat);
                    }
                    if (current_feat.feature_type == 'polygon') {
                        $scope.IMData.infowindow.open($scope.current_map.map, current_feat.center_marker);
                    } else {
                        $scope.IMData.infowindow.open($scope.current_map.map, current_feat);
                    }
                }
                if (prev_feat !== null) {
                    if (prev_feat.creation) {
                        $scope.IMData.gmarklayer.removeUnsavedMarker();
                    }
                }
            });

            // $scope.gotoGeomark = function(geomark) {
            //     $scope.toggleGeomarks();

            //     var marker = _.find(IMData.gmarklayer.marks, function(m){
            //         return _.isEqual(m.ps_id, geomark.id);
            //     });

            //     if(angular.isDefined(marker)){
            //         $scope.IMData.gmarklayer.infowindow.setContent(marker.iwcontent);
            //         $scope.IMData.gmarklayer.infowindow.open($scope.IMData.gmap.map, marker);
            //     }
            // };

            // $scope.togglePosts = function() {
            //     $scope.is_geomarks_visible = false;
            //     $scope.is_posts_visible = !$scope.is_posts_visible;
            // };

            // $scope.toggleGeomarks = function() {
            //     $scope.is_posts_visible = false;
            //     $scope.is_geomarks_visible = !$scope.is_geomarks_visible;
            // };

            // $scope.addPost = function() {
            //     var modalPromise = $modal({
            //         template: '/static/apps/topic/partials/inputmap_form.html',
            //         persist: false,
            //         show: false,
            //         backdrop: 'static',
            //         scope: $scope
            //     });
            //     $q.when(modalPromise).then(function(modalEl) {
            //         modalEl.modal('show');
            //     });
            // };

            $scope.toggleCommenting = function() {
                if ($scope.user !== null) {
                    if (!$scope.IMData.gmarklayer.is_commenting) {
                        $scope.IMData.gmarklayer.enableCommenting();
                        $scope.IMData.layer.setClickable(false);
                        $scope.IMData.gmarklayer.removeUnsavedMarker();
                    } else {
                        $scope.IMData.gmarklayer.disableCommenting();
                        $scope.IMData.layer.setClickable(true);
                    }
                }
            };
            $scope.$on('modal-hidden', function() {
                // Sorry for jQuery in ctrl!
                $('.modal').remove();
            });
            $scope.vote = function(post, vote) {
                if ($scope.user !== null) {
                    if (post.author.id != $scope.user) {
                        if (vote === 1 && !post.hasVotedUp) {
                            post.vote_counts.up++;
                            post.hasVotedUp = true;
                            if (post.hasVotedDown) {
                                post.vote_counts.down--;
                                post.hasVotedDown = false;
                            }
                        }
                        if (vote === -1 && !post.hasVotedDown) {
                            post.vote_counts.down++;
                            post.hasVotedDown = true;
                            if (post.hasVotedUp) {
                                post.vote_counts.up--;
                                post.hasVotedUp = false;
                            }
                        }
                        $http.post(
                            '/topics/im/vote/', {
                                'post': post.id,
                                'vote': vote
                            }
                        ).success(function(obj) {}).error(function(data, status) {});
                    }
                }
            };
            $scope.checkUserVote = function(post) {
                // vote =  1 - user voted up
                // vote = -1 - user voted down
                for (var i = 0, len = post.voters.length; i < len; i++) {
                    if (post.voters[i].voter === $scope.user) {
                        return post.voters[i].vote;
                    }
                    return 0;
                }
            };
            $scope.sortBy = function(sort) {
                return;
                $scope.current_sort = sort;
                if (sort === 'time') {
                    $scope.IMData.store.posts.sort(dynamicSort('-timestamp'));
                } else if (sort === 'popular') {
                    $scope.IMData.store.posts.sort(dynamicSort('-net_votes'));
                }
            };
        }
    ]);