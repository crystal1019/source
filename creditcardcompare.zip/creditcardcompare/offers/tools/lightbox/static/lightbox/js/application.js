function loadApplicationLightbox(){
	try{
		loadNow();
	}catch(e){
		console.log(e);
		$.ajax({url:'/email-notice/error/',data: {'details': e.message, 'location': window.location.href, 'offer': $(lightbox_caller).attr('href')}});
	};
};
function loadNow(){
	var apply_url = $(lightbox_caller).attr('href');
	$('a#id-yes').attr('href', apply_url);
	metakey = $.trim(apply_url).replace('/bare/','/').split('?')[0];
	metakey += '?src=' + escape(window.location.href.split('?')[0]);
	applyMetaData(metakey);
};
function applyImage(offermeta){
	$('img#offer-image').attr('src', offermeta['offer-image']);
};
function applyIncome(offermeta){
	var income = offermeta['Minimum Income'];
	if (income == '-' | income == undefined) {
	    $('span#minimum-income-value').parent().remove();
	}else if (!/[0-9]/.test(income)){ // if contains no numeric value
        $('span#minimum-income-value').parent().text('Earn a regular ' + income.replace('$','').replace('any',''));
    }else{
		$('span#minimum-income-value').text(income);
	};
};
function applyRating(offermeta){
	if(offermeta['Credit Rating']=='Good'){
		var meta = 'Have a good credit history';
	}else if (offermeta['Credit Rating']=='No bad credit history'){
		var meta = 'Have no history of bad credit';
	}else{
		var meta = '';
	};
	$('#apply-box ul #rating').html(meta);
};
function applyJoint(offermeta){
    var joint = offermeta['Joint Application'];
    if(joint == 'Yes' | joint == 'YES'){
        var meta = 'Joint applications are allowed';
    }else if(joint == 'No' | joint == 'NO'){
        var meta = 'Joint applications are not allowed';
        $('#apply-box ul #joint').addClass('cons');
    }else{
        var meta = '';
    };
    $('#apply-box ul #joint').html(meta);
};
function applyResident(offermeta){
    var resident = offermeta['Temporary Resident'];
    if(resident == 'Yes' | resident == 'YES'){
        var meta = 'Temporary residents are eligible';
    }else if(resident == 'No' | resident == 'NO'){
        var meta = 'Temporary residents are not eligible';
        $('#apply-box ul #resident').addClass('cons');
    }else{
        var meta = '';
    };
    $('#apply-box ul #resident').html(meta);
};
function applyMetaData(metakey){
	var offermeta = undefined;
	var myInterval = setInterval(function () {myTimer();}, 100);
	var counter = 0;
	function myTimer(){
		counter += 1;
		offermeta = offerMetaData[metakey];
		if (offermeta != undefined || counter >= 50){ // wait for the ajax response before running applyMetaData, within 5 seconds
			clearInterval(myInterval);
			applyImage(offermeta);
			applyIncome(offermeta);
			applyRating(offermeta);
			applyJoint(offermeta);
			applyResident(offermeta);
		}
	};
};
function postClick(){
	$('a#id-yes').click(function(){$('div.lightbox').remove();});
	$('a#id-yes').click(loadLightbox);
};