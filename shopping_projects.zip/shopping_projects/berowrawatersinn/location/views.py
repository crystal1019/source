# Create your views here.
from berowrawatersinn.location.models import *
from django.template import loader, RequestContext
from django.http import HttpResponse
from berowrawatersinn.common import *

def home(request, slug=None):
    t = loader.get_template('mainpage.html')
    meta = LocationPage.objects.get(slug=slug) if slug else LocationPage.objects.filter(is_landing=True,is_active=True)[0]
    
    nav = LocationPage.objects.filter(is_active=True)
    
    c = RequestContext(request, commondict({
        'current_meta':meta,
        'nav':nav,
        'path':'location'
    },request))
    
    return HttpResponse(t.render(c))