#!/bin/sh

# Restart the vnc server which seems to be what breaks image matching


ps -ef | grep -i vnc | grep -v grep | awk '{ print$2 }' | xargs kill -9
rm -f /tmp/.X*lock
rm -f /tmp/.X11-unix/*
vncserver