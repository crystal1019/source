angular.module('ChannelApp',
	[
        'channel.controllers',
        'channel.directives',
	]
);