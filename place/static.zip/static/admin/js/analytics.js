function createLineGraph(element_id, data, axis){
    // Create monthy registration count
    $.plot($(element_id), [{
            data: data
            ,lines: { show: true }
            ,points: { show: true }
        }],{
            hoverable: true,
            xaxis: { 
                min: 1, 
                ticks: axis, 
                max: data.length
            }
        }
    );
}
function createMap(element_id){

}
function initAnalyticsModuleToggle(){
    $('.toggle-icon').click(function(){
        $(this).parent().parent().find('.dashboard-module-content').toggle();
    }); 
}