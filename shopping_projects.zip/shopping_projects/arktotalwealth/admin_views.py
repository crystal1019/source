from django.contrib import admin
from django.http import HttpResponseRedirect, HttpResponse
from django.template import loader, RequestContext
from arktotalwealth.website.models import SpammerList, Enquiry
from arktotalwealth.mediacenter.models import Comment

class HiddenModelAdmin(admin.ModelAdmin):
	def get_model_perms(self, *args, **kwargs):
		perms = admin.ModelAdmin.get_model_perms(self, *args, **kwargs)
		perms['list_hide'] = True
		return perms
	
def redirect_subpage(request, appname):
	return HttpResponseRedirect('../%s/' %appname)

def addtospammerslist(request, path='comment'):
    t = loader.get_template('add_to_spammer.html')
    rp = request.GET
    ids = rp.get('ids','')
    ids = ids.split(',')
    comments = Comment.objects.filter(id__in=ids).order_by('-created') if path == 'comment' else Enquiry.objects.filter(id__in=ids).order_by('-submitdate')
    ips = {}
    message = ''
    for x in comments:
        if x.ip and x.ip not in ips.keys():
            ips[x.ip] = x.comment if path == 'comment' else x.comments
            
    if request.POST.get('_save',''):
        for x in ips.items():
            try:
                sl = SpammerList.objects.create(ip=x[0], last_post=x[1])
            except:
                pass
        
        comments.delete()
        
        message = 'All Done'
    c = RequestContext(request, {
        'ips':ips,
        'message':message,
        'comments':comments,
        'path':path
    })
    
    return HttpResponse(t.render(c))