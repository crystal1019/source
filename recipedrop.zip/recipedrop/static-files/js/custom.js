$(document).ready(function(){
    
    //Clearing a placeholders
    $('input').click(function(){
        if($(this).attr("placeholder")=="Search..."){
            $(this).attr("placeholder","");
        } 
        if($(this).attr("placeholder")=="Recipe URL..."){
            $(this).attr("placeholder","");
        }
      
    })
    
    //Switching a tabs on new_recipe page
    $(".tabs a").click(function(){
        $(".tabs li").removeClass("current");
        $(this).parent().addClass("current");
        
    });
    
    //Switching a tabs on grid view
    $(".grid_switch  a").click(function(){
        $(".grid_switch  a").removeClass("current");
        $(this).addClass("current");
        
    });
    
    //popups
    $(".sign_up").click(function(){
        $(".ovrly").show();
        $(".sign").show();
    });
    $(".ovrly").click(function(){
        $(".sign").hide();
        $(".login").hide();
        $(this).hide();
    });
     $(".login_btn").click(function(){
        $(".ovrly").show();
        $(".login").show();
    });
});