from googledocs.utils import get_sheet_rows
from offers.core.models import Offer, PerSiteOfferOption


def pros_cons():
    rows = get_sheet_rows('Pro and Con offers')
    
    offer = None
    pros = []
    cons = []
    
    for row in rows:
        # save previous offer
        if row['creditcard'] and offer:
            save_data(offer, pros, cons)
            pros = []
            cons = []
            
        # collect data
        if row['pros']:
            pros.append(row['pros'])
        if row['cons']:
            cons.append(row['cons'])
        if row['creditcard']:
            try:
                offer = Offer.objects.get(title=row['creditcard'].strip())
            except Offer.DoesNotExist:
                return row['creditcard'].strip() + ' does not exists in the database'
            
    save_data(offer, pros, cons)
    
    return 'Import Complete'
            
                    
def save_data(offer, pros, cons):
    persite_option, is_new = PerSiteOfferOption.objects.get_or_create(offer=offer, site__id=8)
    persite_option.pros = '\n'.join(pros)
    persite_option.cons = '\n'.join(cons)
    persite_option.save()        