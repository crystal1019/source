from django.contrib import admin
from models import *
from django.http import HttpResponseRedirect

class NewsPageAdmin(admin.ModelAdmin):
	filter_horizontal = ('action_links',)  
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js',]

class BlogCategoryAdmin(admin.ModelAdmin):
	prepopulated_fields = {"slug": ("name",)}
	
	list_display = ('name', 'is_active')
	list_editable = ('is_active',)
	
	def get_form(self, request, obj=None, **kwargs):
		form = super(BlogCategoryAdmin,self).get_form(request,obj=None,**kwargs)
		article = BlogCategory.objects.filter(is_article=True)
		readonly = []
		if article:
			if obj and not obj.is_article or not obj:
				readonly.append('is_article')
		
		self.readonly_fields = readonly
		
		return form

class BlogPostAdmin(admin.ModelAdmin):
	prepopulated_fields = {"slug": ("title",)}
	list_display = ('title', 'active', 'publishdate','list_category', 'allow_comment')
	list_editable = ('active','allow_comment')
	list_filter = ('created', 'modified', 'active','category', 'allow_comment')
	search_fields = ('title',)
	class Media:
		js = ['/media/adminmedia/tinymce/jscripts/tiny_mce/tiny_mce.js', '/media/adminmedia/tinymce_setup/tinymce_setup.js','/media/assets/js/blogpost/admin.js']

class CommentAdmin(admin.ModelAdmin):
	list_display = ('name', 'active', 'email', 'created',)
	list_filter = ('created', 'active',)
	actions = ['set_as_spammers',]
	
	def set_as_spammers(self,request,queryset):
		selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
		return HttpResponseRedirect('addtospammerslist/?ids=%s' % ",".join(selected))
	

admin.site.register(NewsPage, NewsPageAdmin)
admin.site.register(BlogCategory, BlogCategoryAdmin)
admin.site.register(BlogPost, BlogPostAdmin)
admin.site.register(Comment, CommentAdmin)
