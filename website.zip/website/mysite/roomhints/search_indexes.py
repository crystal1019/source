import datetime
from haystack.indexes import *
#from haystack import site # Removed in Haystack 2.0
#https://github.com/toastdriven/django-haystack/blob/master/docs/migration_from_1_to_2.rst
from roomhints.models import Hint
from roomhints.utils import search_profile_id

class HintIndex(SearchIndex,Indexable):
    name = CharField(model_attr='name')
    #text = CharField(document=True,use_template=True,model_attr='keywords')
    text = CharField(document=True,use_template=True,model_attr='name')
    public = BooleanField(model_attr='public',default=True)
    profile_id = IntegerField(model_attr='profile_id',default=search_profile_id())
    price = FloatField(model_attr='price',default='')
    source = CharField(model_attr='source')
    source_url = CharField(model_attr='source_url',default='')
    photo = CharField(model_attr='photo')
    hintuniq = CharField(model_attr='hintuniq')
    dominant_hex = CharField(model_attr='dominant_hex')

    # FIXME: This feels wrong. Should be indexing hintuniq and then getting back from that what we need

    # additional field for prerendering results
    #rendered = CharField(use_template=True,indexed=False)

    # Removed in Haystack 2.0
    # def index_queryset(self):
    #     """Used when the entire index for model is updated."""
    #     return Hint.objects.filter(profile_id=search_profile_id(),public=True,seconds__lte=datetime.datetime.utcnow())

#site.register(Hint,HintIndex) # Removed in Haystack 2.0

    def get_model(self):
        return Hint

    def index_queryset(self, using=None):
        """Used when the entire index for model is updated."""
        return self.get_model().objects.filter(profile_id=search_profile_id(),public=True,seconds__lte=datetime.datetime.utcnow())
