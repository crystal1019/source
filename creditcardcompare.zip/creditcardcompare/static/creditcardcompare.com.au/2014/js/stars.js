var _ccc_stars = {
	parse :function(){
		$('div[card1stars]').each(this.init);
	},
	init:function(){
		if(this.getAttribute('stars') == 'enabled'){
			return;
		} else {
			this.setAttribute('stars','enabled');
		}
		var show = parseFloat(this.getAttribute('card1stars'));
		$(this).append("<div class='card1starempty'></div>");
		$(this).append('<div class="card1starfull" style="width:' +Math.round(130 * (show/5)) +'px;" ></div>');
		//
	}
};
$(function(){
	_ccc_stars.parse();
	$(document).ajaxComplete(function(event, xhr, settings){
		try{
			if (isPagination(event, xhr, settings)){
				_ccc_stars.parse();
			}
		}catch(e){}
	});
});
