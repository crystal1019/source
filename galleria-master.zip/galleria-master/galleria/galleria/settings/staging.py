"""
Django settings for deploying galleria to a staging site.

"""
"""
Local Django settings for galleria project.

"""

from .base import *

