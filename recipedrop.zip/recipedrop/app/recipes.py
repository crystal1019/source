import json
import urllib2
import cStringIO
from django.contrib.auth.decorators import login_required
from django.core.context_processors import csrf
from django.core.urlresolvers import reverse
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render_to_response, redirect
from django.shortcuts import get_object_or_404
from django.template import RequestContext
from django.http import HttpResponse, HttpResponseServerError, \
    HttpResponseForbidden

from forms import RecipeForm, \
    RecipeCommentForm, SettingsForm
from models import *
from util import success_json, errors_json
from friends import friends
from uploads import *
from compiler.ast import flatten
import settings
import logging

#logger = logging.getLogger(__name__)
logger = logging.getLogger('app.recipe')

THUMB_WIDTH = 340
THUMB_HEIGHT = 230


def recipe_no(request, no):
    logger.error('Recipe_no %s' % no)
    c = RequestContext(request)
    recipe = get_object_or_404(Recipe, id=no)
    data = recipe.get_data()
    # Need authorization!!!
    c.update({'recipe': recipe,
        'tags': recipe.sorted_tags(),
        'recipe_data': data,
        'photos': recipe.all_but_first_photos(),
        'comments': recipe.comments(),
        'comment_form': RecipeCommentForm(),
        'is_mine': recipe.author == request.user if recipe else False,
        'bookmarked': recipe.is_bookmarked(request.user),
        'bookmarkers': recipe.bookmarkers()})
    c.update(recipe_type(recipe.typ))
    return render_to_response('recipes/recipe.html', c)


def recipe(request, slug):
    logger.debug('recipe slug: %s' % slug)
    c = RequestContext(request)
    try:
        (recipe, data) = get_recipe(slug, request.user)
        tags = [x.tag.tag for x in recipe.sorted_tags()]
        logger.debug('recipe tags: %s' % tags)
        c.update({'recipe': recipe,
                'tags': recipe.sorted_tags(),
                'recipe_data': data,
                'photos': recipe.all_but_first_photos(),
                'comments': recipe.comments(),
                'comment_form': RecipeCommentForm(),
                'is_mine': recipe.author == request.user if recipe else False,
                'bookmarked': recipe.is_bookmarked(request.user),
                'bookmarkers': recipe.bookmarkers()})
        c.update(recipe_type(recipe.typ))
    except Exception, e:
        print 'recipe:::Exception',e

    return render_to_response('recipes/recipe.html', c)


@login_required
def new(request):
    if request.method == 'POST':
        return save(request)

    c = RequestContext(request)
    c.update(csrf(request))

    initial_img = None
    initial_link = None

    # handle new recipe from bookmarklet
    if 'link' in request.GET and 'img' in request.GET:
        c.update({'bookmarklet': True})
        initial_link = request.GET['link']
        initial_img = handle_bookmarklet_img(request.user, request.GET['img'])
        c.update({'photos': [initial_img.id]})

    form = RecipeForm(initial={'link': initial_link})

    c.update({'form': form,
              'submit_url': reverse('new_recipe')})

    return render_to_response('recipes/new.html', c)


@login_required
def save(request):

    def delete_association(uploaded):
        for uid in uploaded:
            try:
                rimage = RecipeImage.objects.get(id=uid)
                if rimage.user == recipe.author:
                    rimage.recipe = None
                    rimage.save()
                #if rimage.user == recipe.author:
                #     upload.recipe = self
                #     upload.save()
                else:
                    '!!!user!=author!!! image=',uid
            except ObjectDoesNotExist:
                print 'delete_association record not found id=',uid

    def recipe_err(err):
        c.update({err: True})
        if new_recipe:
            recipe.save_fields({})
            c.update({'recipe': recipe})
            recipe.associate_uploaded(RecipeImage,
                                  request.POST.getlist('uploaded_photo'))

            recipe.add_tags(added_tags)
            recipe.save()
            c.update({'tags':recipe.sorted_tags()})
            c.update({'photos': request.POST.getlist('uploaded_photo')})
            delete_association(request.POST.getlist('uploaded_photo'))
            recipe.delete()
            c.update({'recipe': None})
            
        return render_to_response(error_redir, c)

    def recipe_typ_err():
        return recipe_err('no_recipe_error')

    def recipe_link_err():
        return recipe_err('link_error')

    def recipe_form_err():
        return recipe_err('form_error')

    if request.method != 'POST':
        return HttpResponseServerError()

    form = RecipeForm(request.POST)
    recipe = None
    new_recipe = False

    try:
        recipe = Recipe.objects.get(id=request.POST['recipe'])
        if recipe.author != request.user:
            return HttpResponseForbidden()
        error_redir = 'recipes/edit.html'
        submit_url = reverse('edit_recipe', args=[recipe.id])
    except:
        # Something went wrong: maybe there was no recipe in the POST,
        # or we couldn't find the recipe. So, create a new recipe.
        new_recipe = True
        recipe = Recipe.objects.create(
            author=request.user,
            access=get_setting(request.user, 'new_recipes_privacy')
            )
        error_redir = 'recipes/new.html'
        submit_url = reverse('new_recipe')

    c = RequestContext(request)
    c.update(csrf(request))
    c.update({'form': form,
              'submit_url': submit_url})

    added_tags = request.POST.getlist('added_tag')

    if recipe:
        c.update({'recipe': recipe})

    if form.is_valid():
        recipe.save_fields(form.cleaned_data)
        recipe.associate_uploaded(RecipeImage,
                                  request.POST.getlist('uploaded_photo'))
        recipe.add_tags(request.POST.getlist('added_tag'))

        typ = int(request.POST['typ'])
#        recipe.save_data(typ)

        if typ == RECIPE_FILE:
            rfs = RecipeFile.objects.filter(recipe=recipe)
            for rf in rfs:
                rf.delete()
            try:
                recipe.associate_uploaded(RecipeFile,
                                          [request.POST['uploaded_file']])
            except:
                return recipe_typ_err()

        elif typ == RECIPE_LINK:
            rls = RecipeLink.objects.filter(recipe=recipe)
            rl = rls[0] if len(rls) > 0 else RecipeLink(recipe=recipe)

            try:
                rl.link = request.POST['link']
                if not (rl.link.startswith('http://') or \
                            rl.link.startswith('https://')):
                    rl.link = 'http://' + rl.link
                rl.save()
            except ValidationError:
                return recipe_link_err()
            except:
                return recipe_typ_err()

        elif typ == RECIPE_MANUAL:
            rms = RecipeManual.objects.filter(recipe = recipe)
            if len(rms) > 0:
                rm = rms[0]
            else:
                rm = RecipeManual(recipe = recipe)

            try:
                rm.contents = request.POST['contents']
                rm.save()
            except:
                return recipe_typ_err()

        else:
            return recipe_typ_err()

        return redirect(reverse('recipe', args = [recipe.id]))
    else:
        return recipe_form_err()
    return render_to_response(error_redir, c)

@login_required
def delete(request, rid):
    logger.error('delete recipe # %s' % rid)
    if request.method == 'GET':
        r = Recipe.objects.get(id = rid)
        if r.author == request.user:
            r.delete()
            return redirect('/?msg=deleted')
    if request.method == 'POST':
        r = Recipe.objects.get(id = rid)
        if r.author == request.user:
            r.delete()
            return redirect('/?msg=deleted')

    return HttpResponseServerError()

# TODO: handle errors
@login_required
def upload(request):
    if request.method == 'POST':
        # Upload a file relating to a recipe (image or recipe contents)
        # request.POST['user'] = request.user.id

        if request.POST['extra'] == 'photo':
            mdl = RecipeImage
            thumb_width = THUMB_WIDTH
            thumb_height = THUMB_HEIGHT
        else:
            mdl  = RecipeFile
            thumb_width = None
            thumb_height = None

        upload = upload_handler(
            content_file_name(request.FILES['file'].name),
            request.FILES['file'],
            request.user.email,
            thumb_width,
            thumb_height,
            is_image=(request.POST['extra'] == 'photo'),
            allow_types= settings.ALLOW_MIMES
            )

        upload_data = mdl(upload = upload, user = request.user)
        upload_data.save()

        return success_json({
                'id': upload_data.id,
                'typ': request.POST['extra']
                })

    return HttpResponseServerError()

@login_required
def delete_upload(request):
    if request.method == 'POST':
        if request.POST['delete_typ'] == 'photo':
            mdl = RecipeImage
        else:
            mdl = RecipeFile
        try:
            upload = mdl.objects.get(id = request.POST['id'])
            if upload.user == request.user:
                upload.delete()
                return success_json({
                        'upload': request.POST['id'],
                        'typ': request.POST['delete_typ']
                        })
        except ObjectDoesNotExist:
            print 'ObjectDoesNotExist',mdl
            pass
        return HttpResponseForbidden()

    return HttpResponseServerError()

def photo(request, uid):
    ri = RecipeImage.objects.get(id = uid)
    thumbnail = ('big' not in request.GET)
    return download_handler(request, ri.upload, False, thumbnail)

def recipe_file(request, uid):
    rf = RecipeFile.objects.get(id = uid)
    if can_see_recipe(request.user, rf.recipe):
        return download_handler(request, rf.upload, True)
    return HttpResponseForbidden()

@login_required
def edit(request, rid):
    if request.method == 'POST':
        return save(request)

    c = RequestContext(request)
    c.update(csrf(request))

    r = Recipe.objects.get(id = rid)
    if request.user != r.author:
        return HttpResponseForbidden()

    data = r.get_data()
    form = RecipeForm(recipe = r, rdata = data)

    c.update({
            'form': form,
            'recipe': r,
            'photos': r.photos(),
            'submit_url': reverse('edit_recipe', args = [r.id]),
            })
    c.update(recipe_type(r.typ))

    return render_to_response('recipes/edit.html', c)

@login_required
def new_comment(request, rid):
    if request.method == 'POST':
        if request.POST['contents']:
            recipe = Recipe.objects.get(id = rid)
            if not can_see_recipe(request.user, recipe):
                return HttpResponseForbidden()

            # postsave creates notification for recipe author
            comment = RecipeComment.objects.create(
                recipe = recipe,
                author = request.user,
                contents = request.POST['contents']
                )
            comment.save()

            if 'subscribe' in request.POST:
                (sub, _) = RecipeCommentSubscription.objects.get_or_create(
                    recipe = recipe,
                    subscriber = request.user
                    )

            c = RequestContext(request)
            c.update({'comment': comment})

            return render_to_response('recipes/comment.html', c)
        else:
            return success_json({
                'error': 'This field required'
            })

    return HttpResponseServerError()


@login_required
def delete_comment(request):
    if request.method == 'POST':
        comment = RecipeComment.objects.get(id = request.POST['comment'])
        if comment.author == request.user:
            comment.delete()
            return HttpResponse()
        else:
            return HttpResponseForbidden()

    return HttpResponseServerError()


# helpers

# TODO: seems like this should open up numerous security holes,
# so think about that
def handle_bookmarklet_img(user, img_url):
    resp = urllib2.urlopen(img_url)
    img_data = resp.read()

    upload = upload_handler(
        content_file_name(img_url.split('/')[-1].split('#')[0].split('?')[0]),
        cStringIO.StringIO(img_data),
        user.email,
        THUMB_WIDTH,
        THUMB_HEIGHT,
        is_image=True
        )

    upload_data = RecipeImage.objects.create(upload = upload,
                                             user = user)
    upload_data.save()
    return upload_data

def get_recipe(slug, user):
    r = Recipe.objects.get(slug = slug)

    if can_see_recipe(user, r):
        data = r.get_data()
        return (r, data)

    return (None, None)

def recipe_type(typ):
    return {
        'recipe_link': typ == RECIPE_LINK,
        'recipe_manual': typ == RECIPE_MANUAL,
        'recipe_file': typ == RECIPE_FILE
        }

def can_see_recipe(user, r):
    return r.author == user or \
            r.access == ACCESS_PUBLIC or \
            (r.access == ACCESS_FRIENDS and friends(user, r.author))

@login_required
def unsubscribe_comments(request, rid):
    c = RequestContext(request)
    c.update(csrf(request))

    recipe = Recipe.objects.get(id = rid)
    subs = RecipeCommentSubscription.objects.filter(
        recipe = recipe,
        subscriber = request.user
        )

    if request.method == 'POST':
        for s in subs:
            s.delete()

        return redirect('/?msg=comment_sub_deleted')

    c.update({
            'recipe': recipe,
            'sub_count': len(subs)
            })
    return render_to_response('recipes/unsubscribe_comments.html', c)

@login_required
def comments_count(request,rid):
    if request.method == 'GET':
        count = RecipeComment.objects.filter(
            recipe = rid).count()
        return success_json({'no': str(count)})
    return HttpResponseServerError()
