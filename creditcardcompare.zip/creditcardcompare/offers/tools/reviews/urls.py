from django.conf import settings
from django.conf.urls import patterns, url
from views import NewReview, ThankYouView, ReviewList


urlpatterns = patterns('',
    url(r'^write-a-review\.php$', NewReview.as_view(template_name ='reviews/newreview.html'), name='review'),
    url(r'^competitions/write-a-review\.php$', NewReview.as_view(template_name ='reviews/newreview2.html'), name='review-2'),
    url(r'^write-a-review-thank-you\.php$', ThankYouView.as_view(), name='review-thank-you'),
)
if 'reviews.' in settings.ALLOWED_HOSTS[0]:
    urlpatterns = patterns('',
        url(r'^$', ReviewList.as_view(), name='review-list'),
    ) + urlpatterns