from django.contrib.sitemaps import Sitemap
from models import Category

class CategorySitemap(Sitemap):
    changefreq = 'weekly'
    priority = 0.80
    
    def items(self):
        return Category.objects.all()
    
    def lastmod(self, item):
        return item.last_modification_date
