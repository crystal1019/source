from django.shortcuts import render

def schools(request):
    context = {'results': "asdf"}
    return render(request, 'schools.html', context)

def builder(request):
    context = {'results': "asdf"}
    return render(request, 'schools/builder.html', context)

def browse(request):
    context = {'results': "asdf"}
    return render(request, 'schools/browse.html', context)

def student_portal(request):
    context = {'results': "asdf"}
    return render(request, 'schools/student_portal.html', context)
