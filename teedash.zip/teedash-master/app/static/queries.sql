##Queries:

## Top campaigns since X


SELECT url as link, name, description, SUM(quantity) AS "sold" FROM campaigns JOIN orders ON campaign_id = campaigns.id WHERE order_date > "2014-06-20" GROUP BY campaign_id ORDER BY SUM(quantity) DESC LIMIT 50


## Campaigns in past 3 days that hit 20 sales
select id, url, ordered, tippingpoint, startdate from campaigns where campaign_state_id = 2 and (ordered >= 35 or ordered >= tippingpoint) and startdate >= '2014-07-08' order by ordered desc;  


## All campaigns that contain the word X

SELECT url as link, name, description, SUM(quantity) AS "sold" FROM campaigns JOIN orders ON campaign_id = campaigns.id AND order_date > DATEADD(month, -1, GETDATE()) WHERE name LIKE \"%' + + '%\" OR description LIKE \"%'+ + '%\" GROUP BY campaign_id ORDER BY SUM(quantity) DESC LIMIT 50
