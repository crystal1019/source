

function writeAffiliateCode(source, version) {
	var affiliate = 0;
	if (source == 'softwareinterview.com' || source == 84306) {
		var cc_amazon_code = 'careercup-softwareinterview-20';
	} else if (source == 'usc.com' || source == 104753) {
		var cc_amazon_code = 'careercupkiran-20';
	} else if (source == 130537) {
		var cc_amazon_code = 'careercup-technicalinterview-20';
	} else if (source == 139226) {
		var cc_amazon_code = "careercup-mytechinterviews-20";
	} else if (source == 162685) {
		var cc_amazon_code = "careercupcb-20";
	} else if (cc_amazon_code == undefined || cc_amazon_code == '') {
		var cc_amazon_code = source;
	}	
	
	if (window.cc_width == undefined) {
		cc_width = 540;
	}
	if (window.cc_height == undefined) {
		cc_height = 120;
	}
    var type;
    if (typeof(cc_type) == 'undefined') {
        type = 'horizontal';
    } else {
        type = cc_type;
    }
    var font;
    if (typeof(cc_font) == 'undefined') {
        font = "Verdana";
    } else {
        font = cc_font;
    }
    var ftsize = cc_header_font_size + 3;
    if (type == 'horizontal') {
		cc_height = cc_height - 20;
		cc_width = cc_width - 20;    	
		var cc_author_width = cc_width - 100 - 20 - 100;
        var ccStrVar="";
		ccStrVar += "<div style=\"clear: both; border: 1px solid #000000; width: " + cc_width + "px; height: " + cc_height + "px; padding: 10px; font-size: 11px; font-family: Verdana; margin: 0 auto;\">";
		ccStrVar += "			<a href=\"http:\/\/www.amazon.com\/dp\/098478280X\/ref=as_li_ss_til?tag=" + cc_amazon_code + "&camp=213381&creative=390973&linkCode=as4&creativeASIN=098478280X&adid=1D5MQ1WE82YWY4YY86CP&\"><img src=\"http:\/\/www.careercup.com\/images\/cover_small_outline.gif\" height=\"" + cc_height + "px\" style=\"float: left;\"><\/a>";
		ccStrVar += "			<div style=\"text-align: right\">";
		ccStrVar += "				<div style=\"font-weight: bold; text-align: center;\">";
		ccStrVar += "					<a href=\"http:\/\/www.amazon.com\/dp\/098478280X\/ref=as_li_ss_til?tag=" + cc_amazon_code + "&camp=213381&creative=390973&linkCode=as4&creativeASIN=098478280X&adid=1D5MQ1WE82YWY4YY86CP&\">Cracking the Coding Interview, 5th Edition<\/a>";
		ccStrVar += "				<\/div>";
		ccStrVar += "				<div style=\"text-align: center;\">";
		ccStrVar += "					<i>150 Programming Interview Questions and Solutions<\/i>";
		ccStrVar += "				<\/div>";
		ccStrVar += "				<div style=\"text-align: center; padding-top: 3px;\">";
		ccStrVar += "					150 coding questions and answers, 5 ways to ace algorithm questions, a look<br/> behind the scenes of the interview processes";
		ccStrVar += "					of major companies, and more!";
		ccStrVar += "				<\/div>";
		ccStrVar += "				<div style=\"padding-top: 5px;\">";
		ccStrVar += "					<div style=\"text-align: left; float: left; padding-left: 10px; color: #666666; width: " + cc_author_width + "px;\">";
		ccStrVar += "						by <a href=\"http:\/\/www.technologywoman.com\">Gayle L. McDowell<\/a> (ex-Google \/ Microsoft \/ Apple software engineer &amp; interviewer, founder of <a href=\"http:\/\/www.careercup.com\">CareerCup.com<\/a>)";
		ccStrVar += "					<\/div>";		
		ccStrVar += "					<div style=\"width: 100px; padding: 5px; float: right;\">";
		ccStrVar += "						<a href=\"http:\/\/www.amazon.com\/dp\/098478280X\/ref=as_li_ss_til?tag=" + cc_amazon_code + "&camp=213381&creative=390973&linkCode=as4&creativeASIN=098478280X&adid=1D5MQ1WE82YWY4YY86CP&\"><img src=\"http:\/\/www.careercup.com\/images\/amazon_buy_button.gif\"><\/a>";
		ccStrVar += "					<\/div>	";		


		ccStrVar += "					<div style=\"clear: both;\"><\/div>";
		ccStrVar += "				<\/div>";
		ccStrVar += "			<\/div>";
		ccStrVar += "		<\/div>";
		document.write(ccStrVar);
    }
    if (type == 'vertical') {
    	var ccStrVar="";
ccStrVar += "";
ccStrVar += "<iframe src=\"http:\/\/rcm.amazon.com\/e\/cm?lt1=_blank&bc1=000000&IS2=1&nou=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=" + cc_amazon_code + "&o=1&p=8&l=as4&m=amazon&f=ifr&ref=ss_til&asins=098478280X\" style=\"width:" + cc_width + "px;height:" + cc_height + "px;\" scrolling=\"no\" marginwidth=\"0\" marginheight=\"0\" frameborder=\"0\"><\/iframe>";
ccStrVar += "";
		document.write(ccStrVar);
    }
}