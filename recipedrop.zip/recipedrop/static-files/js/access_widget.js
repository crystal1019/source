$(document).ready(function () {

    function options(widget) {
        var access = widget.find('input[name=access]').val(),
        selected = widget.find('a.access_selected'),

        priv = widget.find('.private').html(),
        friends = widget.find('.friends').html(),
        pub = widget.find('.public').html(),
        access_map = {
            0: priv,
            1: friends,
            2: pub
        };

        selected.html(access_map[access]);
    }

    function setup_widget(widget) {
        options(widget);

        widget.find('a').live('click', function () {
            if ($(this).attr('data-access')) {
                var access = $(this).attr('data-access');
                widget.find('input[name=access]').val(access);
                widget.find('form').trigger('submit');
            }
        });
    }

    function access_submitted(widget) {
        return function () {
            options(widget);
        };
    }

    $('.access_widget').each(function (i, elem) {
        var id = $(elem).attr('id');
        var $form;
        setup_widget($(elem));

        $form = $('#' + id).find('form');
        $form.ajaxify(util.ajax_form_opts($form, access_submitted($(elem))));
    });

});