import os
import mimetypes
import datetime
from django.shortcuts import render
from django.http import StreamingHttpResponse, HttpResponse
from django.conf import settings
from django.db import connection
from .utils import *
try:
    from zimp.ext import reportmod
except:
    pass


def index(request):
    return showreport(request)


def get_connection_string(request):
    settings = connection.settings_dict
    options = ''
    if settings.get('PORT'):
        options = ';PORT=' + settings['PORT']
    return 'HOST=%s;DATABASE=%s;USER=%s;PASSWORD=%s%s' % (settings['HOST'], settings['NAME'],
        settings['USER'], settings['PASSWORD'], options)


def _export(request, report, outfile, fmt='pdf', data={}, xmldata=''):
    connstr = get_connection_string(request)

    #if data:
    #    data['WHERE'] = self.get_sql(data)

    data.update(request.session.get('variables', {}))

    # Send session variables to report
    data = {k: str(v) for k, v in data.items() if not v is None}
    return reportmod.show_report(report, outfile, fmt, connstr, xmldata, '', data)


def _show_report(request, report, outfile='file.pdf', fmt='pdf', data={}, xmldata=''):
    from io import BytesIO
    content_type = mimetypes.types_map.get(format)
    data = _export(request, report, '', fmt, data=data, xmldata=xmldata)
    response = StreamingHttpResponse(BytesIO(data), content_type=content_type)
    if fmt == 'pdf':
        response['Content-Type'] = 'application/pdf'
        response['Content-Disposition'] = 'filename=%s' % outfile
    else:
        response['Content-Disposition'] = 'attachment; filename=%s' % outfile
    return response


# no auth
def viewer(request):
    fmt = request.GET.get('format', 'pdf')
    if fmt == 'fpx':
        r = '<a href="/static/download/ReportViewer.msi">Download do visualizador.</a>'
    else:
        r = '<span>Seleção modificada com sucesso!</span>'
    r = render(request, 'keops/content.html', {'content': r})
    max_age = 365*24*60*60  # one year
    expires = datetime.datetime.strftime(datetime.datetime.utcnow() + datetime.timedelta(seconds=max_age), "%a, %d-%b-%Y %H:%M:%S GMT")
    r.set_cookie('internal-report-viewer', request.GET.get('format', 'pdf'), max_age=max_age, expires=expires)
    return r


def get_output_fmt(request):
    if 'fmt' in request.GET:
        return request.GET.get('fmt')
    return request.COOKIES.get('internal-report-viewer', 'pdf')


def autoreport(request):
    from . import auto
    fmt = get_output_fmt(request)
    model = request.GET['model']
    rep = auto.AutoReport(model)
    return _show_report(request, rep.create_report(), str(model._meta.verbose_name_plural) + '.' + fmt, fmt=fmt, xmldata=rep.xmldata)


def showreport(request):
    fmt = get_output_fmt(request)
    if request.method == 'GET':
        data = request.GET
    else:
        data = request.POST
    data = {k: data[k] for k in data}
    filename = os.path.join(settings.BASE_DIR, 'zimp', 'reports', data.pop('report'))
    return _show_report(request, filename, os.path.basename(filename).split('.')[0] + '.' + fmt, fmt=fmt, data=data)
