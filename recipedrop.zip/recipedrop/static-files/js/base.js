var recipedrop = (function () {
    return {
        'adjust_user_list': function () {
            $('.user_list_link .photo img').load(function () {
                var ht = $(this).height();
                $(this).parents('.user_list_link').find('.name').css(
                    'line-height',
                    ht + 'px'
                );
            });
        },
        'init_users_avatars': function() {
            $('.container').find('.ava-drop, .ava-mini').each(function(){
                var ava_url = $(this).data('photo');
                $(this).css('background', 'url(' + ava_url +
                    ') no-repeat center top');
            })
        },
        'transform_settings_controls': function() {
            $('#id_new_comments_email, #id_new_bookmarks_email, #id_digest_email').each(function(){
                var current_select = $(this);
                var new_checkbox_id = current_select.attr('id') + '_checkbox';
                var new_checkbox = $('<input type="checkbox" />');
                var new_checkbox_label = $('<label></label>');

                new_checkbox.attr('id',new_checkbox_id);
                new_checkbox_label.addClass('on-of-toggle');
                if(current_select.val() == "yes") {
                    new_checkbox.prop('checked', true);
                    new_checkbox_label.addClass('active');
                }
                new_checkbox.appendTo(new_checkbox_label);
                new_checkbox_label.attr('for',new_checkbox_id);
                new_checkbox_label.appendTo(current_select.parent());
                current_select.hide();
                new_checkbox.hide();
                new_checkbox.on('change',function(){
                    if($(this).prop('checked')) {
                        current_select.val('yes');
                        new_checkbox_label.addClass('active');
                    } else {
                        current_select.val('no');
                        new_checkbox_label.removeClass('active');
                    }
                });
            });
        }
    };
            
}());

$(document).ready(function () {
//    recipedrop.adjust_user_list();
    recipedrop.init_users_avatars();
    recipedrop.transform_settings_controls();
});