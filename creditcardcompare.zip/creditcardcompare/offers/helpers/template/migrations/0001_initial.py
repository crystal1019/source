# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
#         migrations.CreateModel(
#             name='UserAgent',
#             fields=[
#                 ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
#                 ('agent', models.CharField(unique=True, max_length=250)),
#                 ('os', models.CharField(max_length=15, null=True, blank=True)),
#                 ('browser', models.CharField(max_length=15, null=True, blank=True)),
#                 ('hit_count', models.IntegerField(default=0)),
#                 ('first_hit', models.DateTimeField(auto_now_add=True)),
#                 ('last_hit', models.DateTimeField(auto_now=True)),
#                 ('is_mobile', models.BooleanField(help_text=b'If this is a smartphone browser.')),
#                 ('is_tablet', models.BooleanField()),
#                 ('is_smartphone', models.BooleanField()),
#             ],
#             options={
#                 'ordering': ('-hit_count', '-last_hit'),
#                 'db_table': 'template_utils_useragent',
#             },
#         ),
    ]
