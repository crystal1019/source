var stop_flag = false;
var year = 2000;
var heatmap_tax;
var map_tax;
function loadData(){
	tax_data = new Array();
  	result = masterData[year];
  	for (var i = 0; i < result.length; i++) { 
		tax_data[i] = {location: new google.maps.LatLng(result[i][0], result[i][1]), weight: result[i][2]}
	};
	heatmap_tax.setData(tax_data);
	ibLabel.setOptions({content: year.toString()});
	setTimeout(
		function() {
			if (!stop_flag && year < 2010){
				year += 1;
				$( "#wage-slider" ).slider( "option", "value", year );
				loadData();
			}else{
				$('#animate_tax').html('<button onclick="javascript: start();">start</button>');
				if (year == 2010){
					year = 2000
				}
			}
		},
		1000
	);
};
function start(){
	$('#animate_tax').html('<button onclick="javascript: pause();">pause</button>');
	stop_flag = false; 
	loadData();
};
function pause(){
	$('#animate_tax').html('<button onclick="javascript: start();">start</button>');
	stop_flag = true;
};
$(document).ready(function(){
	$("#wage-slider").slider({
		min: 2000,
		max: 2010,
		value: year,
		animate: "slow",
		slide: function(event, ui) {
			stop_flag = true;
			year = ui.value;
			loadData();
        }
	});
    var mapOptions_tax = {
		center: new google.maps.LatLng(-28.5, 133.6),
		zoom: 4,
		mapTypeId: google.maps.MapTypeId.HYBRID,
		zoomControl: false,
		panControl: false,
		mapTypeControl: false,
		scrollwheel: false,
		streetViewControl: false
	};
	map_tax = new google.maps.Map(document.getElementById("map_canvas_tax"), mapOptions_tax);
	applyLabels(map_tax);
	heatmap_tax = new google.maps.visualization.HeatmapLayer({
		radius: 5,
		maxIntensity: 56110,
		map: map_tax,
	});
});