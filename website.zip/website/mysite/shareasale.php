<?php

$myAffiliateID = '693902';
$APIToken = "94Uv5QEtNrOQqp8a";
$APISecretKey = "ZZi7cx5e2WIsxf9uCVz4du0l2ZEcdm1r";
$myTimeStamp = gmdate(DATE_RFC1123);

$APIVersion = 1.2;
$actionVerb = "activity";
$sig = $APIToken.':'.$myTimeStamp.':'.$actionVerb.':'.$APISecretKey;

$sigHash = hash("sha256",$sig);

$myHeaders = array("x-ShareASale-Date: $myTimeStamp","x-ShareASale-Authentication: $sigHash");

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://shareasale.com/x.cfm?affiliateId=$myAffiliateID&token=$APIToken&version=$APIVersion&action=$actionVerb");
curl_setopt($ch, CURLOPT_HTTPHEADER,$myHeaders);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, 0);

$returnResult = curl_exec($ch);

if ($returnResult) {
   //parse HTTP Body to determine result of request
   if (stripos($returnResult,"Error Code ")) {
      // error occurred
      	 trigger_error($returnResult,E_USER_ERROR);
	 }
	 else{
		// success
		   echo $returnResult;
		   }
}

else{
	// connection error
	trigger_error(curl_error($ch),E_USER_ERROR);
}

curl_close($ch);

?>