import datetime
from haystack.indexes import *
from haystack import site
from arkstart.blog.models import *
from django.conf import settings

class BlogPostIndex(SearchIndex):
    text = CharField(document=True)
    pub_date = DateTimeField(model_attr='publishdate')
    content_auto = EdgeNgramField(model_attr='get_all_content')

    def index_queryset(self):
        """Used when the entire index for model is updated."""
        return BlogPost.objects.filter(publishdate__lte=datetime.datetime.now(),status__display_to_user=True,sites__id=settings.SITE_ID,)    

site.register(BlogPost, BlogPostIndex)