angular.module('profile.directives', [])
    .directive('profileGmap', ["$http", function ($http) {
        return {
            link: function (scope, elem, attrs) {
                scope.safeApply(function(){
                    scope.gmap = new GMap2(elem.attr('id'), {
                        zoom: 11,
                        center: new google.maps.LatLng(
                            data.places[0].coords[0],
                            data.places[0].coords[1]
                        )
                    });
                    scope.glayer = new GLayer(scope.gmap);
                    for (var i=0; i < data.places.length; i++){
                        var place = data.places[i];
                        scope.glayer.addPlace(place);

                        b = scope.glayer.addNotificationZone(notification_distance, place);
                        if (i === 0) {
                            scope.gmap.map.fitBounds(b.getBounds());
                        }
                    }
                    scope.$on('map_topics', function(origin, topics){

                        scope.glayer.addTopics(topics);
                    });
                });
            }
        };
    }])
    .filter('dateSuffix', ["$filter", function($filter) {
        var suffixes = ["th", "st", "nd", "rd"];
        return function(input, format) {
            var dtfilter = $filter('date')(input, format);
            var day = parseInt($filter('date')(input, 'dd'));
            var relevantDigits = (day < 30) ? day % 20 : day % 30;
            var suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
            return dtfilter.replace('oo', suffix);
        };
    }]);
