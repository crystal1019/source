angular.module('map.directives', [])
    .directive("gmap", ['$compile',
        function($compile) {
            return function(scope, elem, attrs) {

                // Keep reference the parent scope.
                if (!scope.MapData.$parent) {
                    scope.MapData.$parent = scope.$parent;
                }

                scope.MapData.defer.promise.then(function() {
                    scope.MapData.gmap = new GMap2('map_canvas', {
                        zoom: (scope.MapData.zoom) ? scope.MapData.zoom : 13,
                        center: scope.MapData.center,
                        drawingControl: false
                    });

                    scope.MapData.gmap.bind('boundschanged', function(gmap) {
                        scope.safeApply(function(){
                            scope.MapData.store.center = gmap.map.getCenter();
                            scope.MapData.store.zoom = gmap.map.getZoom();
                            if(scope.psc_client) {
                                var c = gmap.map.getCenter();
                                scope.MapData.store.map_center = [c.lat(),c.lng()];
                                scope.MapData.store.map_zoom = gmap.map.getZoom();
                            }
                        });
                    });

                    var infoWindowTpl = '<div id="map-infowindow" map-infowindow></div>';
                    var iwcontent = $compile(infoWindowTpl)(scope)[0];
                    scope.MapData.infowindow = new google.maps.InfoWindow({
                        content: iwcontent
                    });

                    if (!scope.MapData.layer) {
                        scope.MapData.layer = new GPolygonLayer(scope.MapData.gmap, 'polygon');
                        scope.MapData.layer.loadEncodedPolygons(scope.MapData.store.geo, true);
                        scope.MapData.layer.startEditing();
                        scope.MapData.layer.bind('featureclicked', function(ft) {
                            scope.MapData.layer.selected_feature = ft;
                            scope.$apply(scope.MapData.layer.selected_feature);
                        });

                        scope.MapData.layer.bind('featureedited', function(ft, action) {
                            if (scope.MapData.layer.edit_stack.length > 0) {
                                // Need to ensure reference to the parent scope,
                                // losing scope when starting on the map tab, got to
                                // another tab and then back to the map tab.
                                if (!scope.$parent) {
                                    scope.$parent = scope.MapData.$parent;
                                }
                                if (angular.isDefined(scope.psc_client)) {
                                    scope.MapData.layer.fitLayer(true);
                                }
                                scope.$emit('tabchange', '/map', scope);
                                if (!scope.$$phase) {
                                    scope.$apply(scope.MapData.layer.edit_stack);
                                }
                            }

                            if (action === 1) { // New Feature
                                if (!scope.$$phase) {
                                    scope.$apply(scope.MapData.layer.selected_feature);
                                }
                            }
                        });
                        scope.MapData.layer.bind('newpolygon', function(ft) {
                            scope.safeApply(function() {
                                scope.drawPolygon();
                                scope.$emit("tabchange", "/map", scope);
                                if (angular.isDefined(scope.psc_client)) {
                                    scope.MapData.layer.fitLayer(true);
                                }
                            });
                        });
                    } else {
                        // Assign new map to the existing layer
                        scope.MapData.layer.setGMap(scope.MapData.gmap);
                    }
                });
            };
        }
    ])
    .directive("colorpicker", [

        function() {
            return {
                scope: true,
                link: function(scope, elem, attrs) {
                    var cp = ColorPicker(
                        $(elem).find('.slide')[0],
                        $(elem).find('.picker')[0],
                        function(hex, hsv, rgb) {
                            scope.changeColor(hex);
                        }
                    );

                    //  Stop picker from being dragged, happens after you select a colour,
                    //  stop, and then drag around on the colour picker again.
                    $(elem).find('.picker')[0].ondragstart = function() {
                        return false;
                    };
                    $(elem).parents('.popover-inner').mouseleave(function() {
                        scope.hide();
                    });

                    if (attrs.colorpicker.length > 3) {
                        cp.setHex(attrs.colorpicker);
                    }

                    scope.$root.$colorpicker = scope;
                }
            };
        }
    ])
    .directive('mapInfowindow', [

        function() {
            return {
                templateUrl: '/static/apps/common/maps/partials/map_infowindow.html'
            }
        }
    ])
    .filter("length", [

        function() {
            return function(items) {
                return items.length;
            }
        }
    ]);