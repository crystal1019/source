#!/bin/bash
set -e
LOGFILE=/var/log/hukkster/gunicorn.log
LOGDIR=$(dirname $LOGFILE)
NUM_WORKERS=1
WORKER_CLASS=gevent
# user/group to run as
USER=apache
GROUP=webusers
ADDRESS=127.0.0.1:8199

source /var/venvs/jgoodall/bin/activate
cd /var/www/html/sites/jgoodall.hukkster.com/.hub/hukkster
test -d $LOGDIR || mkdir -p $LOGDIR
exec gunicorn wsgi -b $ADDRESS -w $NUM_WORKERS --worker-class $WORKER_CLASS --user=$USER --group=$GROUP --log-level=debug --log-file=$LOGFILE 2>>$LOGFILE
