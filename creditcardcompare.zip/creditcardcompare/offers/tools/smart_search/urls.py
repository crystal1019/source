from django.conf.urls import patterns, url


urlpatterns = patterns('offers.tools.smart_search.views',
    url(r'^\.php$', 'smart_search', name='smart-search'),
    url(r'^-result\.php$', 'smart_search_result', name='smart-search-result'),
)
