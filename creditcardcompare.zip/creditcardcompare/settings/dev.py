# Django settings for offers project.
import os
from ConfigParser import ConfigParser, NoSectionError


DEBUG = True
TEMPLATE_DEBUG = DEBUG

ADMINS = MANAGERS = (('Noel', 'tellnoel@gmail.com'),)

hostname = 'localhost'

DATABASES = {
    'default': {
        'NAME': 'moneychoices',
        'ENGINE': 'django.db.backends.mysql',                      
        'USER': 'root',
        'HOST': hostname,
    },
}
TEST_RUNNER = 'testrunner.DjangoTestSuiteRunner'

project_path = os.path.dirname(os.path.dirname(__file__))
MEDIA_ROOT = os.path.join(project_path, '../../xampp/htdocs/mc/media')
MEDIA_URL = 'http://%s:88/mc/media/' % hostname
# STATIC_URL = 'http://%s:88/mc/static/' % hostname
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(project_path, '../../xampp/htdocs/mc/static')
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.StaticFilesStorage'
# prevent local server from uploading files to S3
DEFAULT_FILE_STORAGE = 'django.core.files.storage.FileSystemStorage'
IMAGE_URL = 'http://images.creditcardcompare.com.au/media'
# IMAGE_URL = MEDIA_URL[:-1]
INTERNAL_LINK = '%s:8000' % hostname
ALLOWED_HOSTS = ['reviews.creditcardcompare.com.au']
CATEGORY_LIMIT = 2

ADMIN_MEDIA_PREFIX = STATIC_URL+'admin/'

conf = ConfigParser()
conf.read(os.path.join(project_path, '../conf', 'ccc.conf'))

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.googlemail.com'
try:
    EMAIL_HOST_PASSWORD = conf.get('gmail', 'EMAIL_HOST_PASSWORD')
except NoSectionError:
    EMAIL_HOST_PASSWORD = ''
EMAIL_HOST_USER = 'remotenoelp@gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True

DEV_APPS = [
    'debug_toolbar',
]

import warnings
warnings.filterwarnings(
        'error', r"DateTimeField received a naive datetime",
        RuntimeWarning, r'django\.db\.models\.fields')

#===============================================================================
# Application settings
#===============================================================================

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
#         'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'unique-snowflake'
    }
}
#WEB_ROOT = os.path.join(project_dir,'..','..','public_html', 'cache')
REVIEW_MODERATOR = ADMINS[0][1]
SPACELESS_HTML = False
COMPRESS_ENABLED = False
#COMPRESS_STORAGE = 'compressor.storage.CompressorFileStorage'

# load debug context
from fnmatch import fnmatch
class glob_list(list):
    def __contains__(self, key):
        for elt in self:
            if fnmatch(key, elt): return True
        return False

INTERNAL_IPS = glob_list([
    '127.0.0.1',
    '192.168.*.*'
    ])
