from .base_gap import BaseGapScraper


class AthletaGapScraper(BaseGapScraper):
    @staticmethod
    def get_domain():
        return 'athleta.gap.com'

    def _get_store(self):
        return 'athleta.gap'

