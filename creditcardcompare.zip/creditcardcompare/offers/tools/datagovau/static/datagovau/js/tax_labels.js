var yearOptions = {
	boxStyle: {
		border: "1px solid white",
		textAlign: "center",
		fontSize: "15pt",
		width: "100px",
		color: "white"
	},
	disableAutoPan: true,
	pixelOffset: new google.maps.Size(-25, 0),
	position: new google.maps.LatLng(-43.068888,101.156739),
	closeBoxURL: "",
	isHidden: false,
	pane: "mapPane",
	enableEventPropagation: true
};
var legendOptions = {
	boxStyle: {
		textAlign: "left",
		fontSize: "12pt",
		width: "100px",
		color: "white"
	},
	disableAutoPan: true,
	pixelOffset: new google.maps.Size(-25, 0),
	position: new google.maps.LatLng(-10,95),
	closeBoxURL: "",
	isHidden: false,
	pane: "mapPane",
	enableEventPropagation: true,
	content: 'Legend:'
};
var barVertical = 95;
var labelVertical = 100;
var redHorizontal = 13;
var greenHorizontal = 14.5;
var barStyle = {
	textAlign: "center",
	fontSize: "5pt",
	width: "50px",
	color: "white"
};
var redBarOptions = {
	boxStyle: barStyle,
	boxClass: 'red-legend',
	disableAutoPan: true,
	pixelOffset: new google.maps.Size(-25, 0),
	position: new google.maps.LatLng(-redHorizontal,barVertical),
	closeBoxURL: "",
	isHidden: false,
	pane: "mapPane",
	enableEventPropagation: true,
	content: '&nbsp;'
};
var greenBarOptions = {
	boxStyle: barStyle,
	boxClass: 'green-legend',
	disableAutoPan: true,
	pixelOffset: new google.maps.Size(-25, 0),
	position: new google.maps.LatLng(-greenHorizontal,barVertical),
	closeBoxURL: "",
	isHidden: false,
	pane: "mapPane",
	enableEventPropagation: true,
	content: '&nbsp;'
};
var labelStyle = {
	textAlign: "center",
	fontSize: "10pt",
	width: "200px",
	color: "white"
};
var redLabelOptions = {
	boxStyle: labelStyle,
	disableAutoPan: true,
	pixelOffset: new google.maps.Size(-25, 0),
	position: new google.maps.LatLng(-redHorizontal+0.4,labelVertical),
	closeBoxURL: "",
	isHidden: false,
	pane: "mapPane",
	enableEventPropagation: true,
	content: 'mean taxable income of $56,109'
};
var greenLabelOptions = {
	boxStyle: labelStyle,
	disableAutoPan: true,
	pixelOffset: new google.maps.Size(-25, 0),
	position: new google.maps.LatLng(-greenHorizontal+0.4,labelVertical),
	closeBoxURL: "",
	isHidden: false,
	pane: "mapPane",
	enableEventPropagation: true,
	content: 'mean taxable income of $26,370'
};
var ibLabel = new InfoBox(yearOptions);
var legend = new InfoBox(legendOptions);
var redLegend = new InfoBox(redBarOptions);
var greenLegend = new InfoBox(greenBarOptions);
var redLabel = new InfoBox(redLabelOptions);
var greenLabel = new InfoBox(greenLabelOptions);
function applyLabels(map_tax){
	ibLabel.open(map_tax);
	legend.open(map_tax);
	redLegend.open(map_tax);
	greenLegend.open(map_tax);
	redLabel.open(map_tax);
	greenLabel.open(map_tax);
};