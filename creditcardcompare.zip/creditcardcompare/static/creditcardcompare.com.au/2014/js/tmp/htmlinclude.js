var $;
var $u;

$(document).ready(function () {
    cardimport();
    cardimport();
});

function cardimport() {
    $('div[include]').each(function () {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', this.getAttribute('include'), false);
        xhr.send();
        var list = this['attributes'];
        var html = xhr.responseText;
        for (var attr = 0; attr < list.length; attr++) {
            html = html.replace("{{" + list[attr].nodeName + "}}", list[attr].nodeValue);
        }
        $(this).replaceWith(html);
        if (xhr.status == 404) {
            // console.log('status 404:', this.getAttribute('include'));
        }
    });
}
//# sourceMappingURL=htmlinclude.js.map
