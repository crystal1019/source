from datetime import datetime
from datetime import timedelta

def getDateString(date):
	return date.strftime('%B %d, %Y')
	
def getMonthAndYearString(date):
	return date.strftime('%B %Y')
	
def getW3CTime(date):
	return date.strftime("%Y-%m-%dT%H:%M+00:00") 

def getToday():
	today = datetime.now()
	delta = timedelta(hours=today.hour, minutes=today.minute, seconds=today.second, microseconds=today.microsecond)
	return today - delta 
	
def getOneWeekAgo():
	today = datetime.now()
	delta = timedelta(hours=today.hour, minutes=today.minute, seconds=today.second, microseconds=today.microsecond)
	return today - delta - timedelta(days=7)