import threading
from django.conf import settings
from django.template.loaders.filesystem import Loader
from models import IS_MOBILE


_agent = threading.local()

def set_agent(is_mobile):
    _agent.is_mobile = is_mobile

class WithMobileLoader(Loader):
    def load_template_source(self, template_name, template_dirs=None):
        if getattr(_agent, 'is_mobile', IS_MOBILE):
            template_dirs = (settings.MOBILE_TEMPLATE_DIR,) + settings.TEMPLATE_DIRS
        return super(WithMobileLoader, self).load_template_source(template_name, template_dirs)