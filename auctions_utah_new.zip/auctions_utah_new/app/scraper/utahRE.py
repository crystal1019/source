__author__ = 'RJB'
# -*- coding: utf-8 -*-
import json
import datetime
import time
import requests
from bs4 import BeautifulSoup
from app.models import Properties, Comps, db
from app.scraper.settings import COMP_SEARCH_DAYS_BACK
from app.scraper.geocode_bounds import GeoLocation
from app.scraper.settings import URE_HEADERS, COMP_SEARCH_DISTANCE, URE_DATA, SQFT_SEARCH_RANGE, URE_LOGIN
import numpy.ma as ma


r_session = requests.session()
r_session.headers.update({'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X) Firefox/36.0'})


class LoginError(Exception):
    """Raised when unable to login"""
    pass


class UtahREScraper(object):
    """Retrieves comparable listings from utahrealestate.com using
     latitude/longitude coordinates"""
    headers        = URE_HEADERS
    request_data   = URE_DATA
    root_url       = 'http://www.utahrealestate.com/'
    login_post_url = root_url + '/auth/login.form/'
    auth_post_url  = root_url + 'auth/authenticate/'
    login_get_url  = root_url + 'auth/login/'
    tax_data_url   = root_url + 'taxdata/index?'
    res_search_url = root_url + 'search/form/type/1/name/full'
    res_clear_search_url = root_url + 'search/form/new/1?clear=1'
    single_listing_url = root_url + '/report/display/report/full/type/1/in_pop/1/listno/'

    def __init__(self, subject_properties):
        self.subject_properties = subject_properties

    @classmethod
    def login(cls):
        log_post        = r_session.post(cls.login_post_url, headers=cls.headers['login_init_post'])
        login_id_num    = log_post.text
        login, pw       = URE_LOGIN
        data            = {'login_'+login_id_num: login, 'pass_'+login_id_num: pw}
        login_auth_post = r_session.post(cls.auth_post_url, headers=cls.headers['login_auth_post'], data=data)
        if login_auth_post.ok:
            return login_auth_post
        else:
            raise LoginError('Could not log into WFRMLS with id: %s' % login)

    @staticmethod
    def logout():
        log_out_response = r_session.post('http://www.utahrealestate.com/auth/logout/')
        return log_out_response

    #TODO find way to calculate an n-sided polygon instead of just a square, MLS uses 20-points
    @staticmethod
    def get_property_polygon(subject_property, search_distance=COMP_SEARCH_DISTANCE):
        """Receives lat/lon coordinates of subject property and returns a square of
        latitude/longitude coordinates with each point x miles from the subject property.
        Used for the comp search request header.
        geocode_bounds input format: latitude, longitude
        Polygon format: longitude, latitude"""
        print 'Lat/Lon: ', subject_property.lat_lon
        lat, lng = subject_property.lat_lon.split(',')
        location = GeoLocation.from_degrees(float(lat), float(lng))
        SW_coords, NE_coords = location.bounding_locations(search_distance)
        SE_coords = SW_coords.deg_lat, NE_coords.deg_lon
        NW_coords = NE_coords.deg_lat, SW_coords.deg_lon
        coords = (NE_coords.deg_lon, NE_coords.deg_lat, SE_coords[1], SE_coords[0],
                  SW_coords.deg_lon, SW_coords.deg_lat, NW_coords[1], NW_coords[0])
        result = 'POLYGON(({0} {1}, {2} {3}, {4} {5}, {6} {7}, {0} {1}))'.format(*coords)
        return result

    @staticmethod
    def get_property_type(tax_data):
        """returns the property type code for the comp search header params"""
        prop_type_encoder = {'Condominium': 2,
                             'Single Family': 1,
                             'Twin': 4,
                             'Townhouse PUD': 8,
                             'Mobile': 16,
                             'Recreational': 32}
        prop_type_string = tax_data.property_type[:40].lower() if tax_data.property_type else None   # cut out most of the description
        print 'Prop Type String: ', prop_type_string
        if not prop_type_string or 'pud' in prop_type_string:
            return None
        p_type = [v for k, v in prop_type_encoder.items()
                  if any(map(lambda x: x.lower() in k.lower(),
                             prop_type_string.split()))]
        return p_type if p_type else ['']

    @staticmethod
    def get_lat_lng(table):
        """extracts lat/lng coords from bs4 soup result set object of
        tables on utahre comp results page"""
        string_conataining_lat_lng = table.find('a', {'title': "View Map"})['onclick']
        lat_start_indx = string_conataining_lat_lng.find('lat')+4
        lat_end_indx = string_conataining_lat_lng.find('/lng/')
        lat = string_conataining_lat_lng[lat_start_indx:lat_end_indx]
        lng_start_indx = string_conataining_lat_lng.find('lng')+4
        lng_end_indx = string_conataining_lat_lng.find('/list/')
        lng = string_conataining_lat_lng[lng_start_indx:lng_end_indx]
        lat_lng = lat+','+lng
        return lat_lng

    @classmethod
    def comp_search_results(cls, tax_data):
        """Receives a TaxData object as input and returns a list of lists,
        each list representing a table of data from a comp property related to the tax_data subject property.
        Format: [[value1, value2...],...]"""
        r_session.get('http://www.utahrealestate.com/search/form/type/1/name/full')
        select_days_back = r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                                          headers=cls.headers['res_search_days_back'],
                                          data=cls.request_data['select_days_back'])
        print 'Select days back success? ', select_days_back.json()['params']['days_back_status']+' days back selected.'
        property_type = cls.get_property_type(tax_data)
        if property_type:
            print 'Proprty type detected: ', property_type[0]
            cls.request_data['select_prop_type']['value'] = property_type[0]
            r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                           headers=cls.headers['res_search_prop_type'],
                           data=cls.request_data['select_prop_type'])
        # property_type is None  so select PUD
        else:
            print 'Property type PUD selected:  ', property_type
            r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                           headers=cls.headers['res_search_prop_type'],
                           data=cls.request_data['select_pud'])
        total_sqft = tax_data.total_sqft
        print 'Total sqft: ', total_sqft
        if total_sqft:
            sqft_from = int(total_sqft - (total_sqft * SQFT_SEARCH_RANGE))
            print 'SQFT from: ', sqft_from
            sqft_to = int(total_sqft + (total_sqft * SQFT_SEARCH_RANGE))
            print 'SQFT to: ', sqft_to
            cls.request_data['sqft_lower_bounds']['value'] = sqft_from
            cls.request_data['sqft_upper_bounds']['value'] = sqft_to
            r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                           headers=cls.headers['res_search_sqft_from'],
                           data=cls.request_data['sqft_lower_bounds'])
            r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                           headers=cls.headers['res_search_sqft_from'],
                           data=cls.request_data['sqft_upper_bounds'])
        r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                       headers=cls.headers['res_search_select_status'],
                       data=cls.request_data['select_status'])
        prop_bounding_polygon = cls.get_property_polygon(tax_data.subject_property)
        print 'POLYGON: ', prop_bounding_polygon
        cls.request_data['search_post']['value'] = prop_bounding_polygon
        map_search_post = r_session.post('http://www.utahrealestate.com/search/chained.update/count/true/criteria/true',
                                         headers=cls.headers['res_search_post_polygon'],
                                         data=cls.request_data['search_post'])
        post_response_json = json.loads(map_search_post.content)
        chksum_string = BeautifulSoup(post_response_json['html']).find('span', {'id': 'params-chksum'}).text
        print 'Chksum string found: ', chksum_string
        get_comp_results = r_session.get('http://www.utahrealestate.com/search/perform/md/%s' % chksum_string)
        if get_comp_results.ok:
            rows = []
            comp_soup = BeautifulSoup(get_comp_results.content)
            listings = comp_soup.find_all('table')
            listings.pop(0)  # remove header table
            for listing in listings:
                rowstrings = [field.strip() for field in listing.strings if field.strip()]
                lat_lng = cls.get_lat_lng(listing)
                rowstrings.append(lat_lng)
                rows.append(rowstrings)
            print 'Comps found: ', len(rows)
            r_session.get('http://www.utahrealestate.com/search/form/type/1/name/full?clear=1')
            return rows
        r_session.get('http://www.utahrealestate.com/search/form/type/1/name/full?clear=1')
        return None

    @staticmethod
    def dollar_string_to_int(dollar_string):
        """converts strings representing currency amounts to ints, chops off any numbers
        to the right of the decimal:
            '$140,000.00' converts to 140000"""
        dollar_string = dollar_string[:dollar_string.find('.')] if dollar_string.find('.') != -1 else dollar_string
        return int(''.join(char for char in dollar_string if char.isdigit()))

    @classmethod
    def comp_row_to_db(cls, value_list):
        """Transforms a list of values representing a comp property into a DB ready dictionary.
        Called with comp value_list and subject property_id"""
        #Each key in dictionary is a db column name and each value is the index position in the list
        # index values below work for active and under contract listings
        target_headers_index = {'mls_id': 1, 'list_price': 2, 'status': 3, 'style': 4, 'total_sqft': 5, 'sold_price': 6,
                                'address': 8, 'city_state': 9, 'acres': 10, 'Bd/Bth/Fm': -7, 'Gar/Port': -6,
                                'Bsmt/% Fin': -5, 'list_date': -4, 'year_built': -3, 'type | ph cnt': -2, 'lat_lon': -1}
        if value_list[3] == 'Sold':  # identifies Sold listings and changes the indexing of pertinent values
            target_headers_index['sold_date']  = -4
            target_headers_index['address']    = 8
            target_headers_index['city_state'] = 9
            target_headers_index['acres']      = 10
            target_headers_index['list_date']  = -5
            target_headers_index['Bsmt/% Fin'] = -6
            target_headers_index['Gar/Port']   = -7
            target_headers_index['Bd/Bth/Fm']  = -8
        result = {}
        for key, value in target_headers_index.items():  # populate the results
            result[key] = datetime.datetime.strptime(value_list[value], '%m/%d/%Y') if 'date' in key \
                else value_list[value]
        result['address']      = result['address']+', '+result['city_state']
        del result['city_state']
        bedrooms, bathrooms, family = result['Bd/Bth/Fm'].split('/')
        result['bedrooms']      = bedrooms
        result['bathrooms']     = bathrooms
        result['fm_rooms']      = family
        del result['Bd/Bth/Fm']
        property_type           = result['type | ph cnt'].split('|')[0].strip()  # only need type which is element 0
        result['property_type'] = property_type
        del result['type | ph cnt']
        garages, carports       = result['Gar/Port'].split('/')
        result['garages']       = garages
        result['carports']      = carports
        del result['Gar/Port']
        bsmt                    = result['Bsmt/% Fin'].split('/')
        bsmt_pct_finished       = bsmt.pop()  # % finished is last element
        #basement type is sometimes 2 or 3 elements: None/Crawlspace, so we join remaining elements in bsmt
        bsmt_type               = '/'.join(bsmt)
        result['basement_type'] = bsmt_type
        result['finished_basement'] = bsmt_pct_finished
        del result['Bsmt/% Fin']
        result['total_sqft'] = int(result['total_sqft'].replace(',', ''))
        result['list_price'] = cls.dollar_string_to_int(result['list_price'])
        result['sold_price'] = cls.dollar_string_to_int(result['sold_price'])
        return result

    def get_comps(self):
        """Iterates over a list of tax data objects and provides comparables for each subject property"""
        self.login()
        for subject_property in self.subject_properties:
            comps = self.comp_search_results(subject_property.tax_data[0])
            subject_property.comps_date = datetime.datetime.now()
            if comps:
                for comp in comps:
                    prepped = self.comp_row_to_db(comp)
                    if prepped['sold_date'] >= datetime.datetime.today()+datetime.timedelta(days=-COMP_SEARCH_DAYS_BACK):
                        print 'Processed: ', prepped
                        stored = Comps(**prepped).existing_or_new()
                        subject_property.comps_date = datetime.datetime.now()
                        stored.subject_properties.append(subject_property)
                        stored.store()
                    else:
                        print 'Comp sold date out of range %s' % prepped['sold_date']
            else:
                print 'Invalid! ', comps
        self.logout()

    @staticmethod
    def convert_string(string):
        """strip all strings of all non-alpha chars except '_', '-', '/'
        replaces spaces with '_'"""
        converted = string.lower().replace(' ', '_').replace('<', '').replace('>', '').replace('=', '')\
            .replace('$', '').replace(',', '').replace('/month', '').replace('/year', '').replace('/quarter', '')
        return converted

    @classmethod
    def get_details(cls, comps):
        cls.login()
        for prop in comps:
            details_response = r_session.get(cls.single_listing_url+str(prop.mls_id)+'/',
                                             headers=URE_HEADERS['get_details'])
            if details_response.ok:
                detail_soup = BeautifulSoup(details_response.content).find_all('tr')
                if detail_soup:
                    target_fields = ('sold_terms', 'dom', 'cdom', 'ctdom', 'tax_id', 'remarks',
                                     'concessions', 'hoa_fee', 'agt_remarks', 'contract_date',
                                     'proj_subdiv', 'price_per', 'area', 'school_dist', 'taxes')
                    for cell in detail_soup:
                        get_next = False
                        for string in cell.stripped_strings:
                            print 'Current string: ', string
                            if string.endswith(':'):
                                print 'Key identified: ', string[:-1]
                                get_next = cls.convert_string(string[:-1]).replace('/', '_')
                            elif get_next in target_fields:
                                if 'date' in get_next:
                                    string = datetime.datetime.strptime(string, '%m/%d/%Y')
                                elif not get_next in ('sold_terms', 'remarks', 'area',
                                                    'proj_subdiv', 'agt_remarks', 'school_dist'):
                                    string = cls.convert_string(string)
                                elif any(map(lambda x: x in get_next,
                                             ('dom', 'taxes', 'price', 'concess', 'hoa_fee'))):
                                    string = int(cls.convert_string(string))
                                print 'Converted string: ', string
                                get_next = cls.convert_string(get_next)
                                print 'Setting: '+get_next+u': %s' % string
                                setattr(prop, get_next, string)
                                get_next = False
            prop.update()
            print 'Merge successful for MLS ID#: ', prop.mls_id
            time.sleep(1)
        cls.logout()


class CompStat(object):
    """creates stats for groups of comparisons"""
    def __init__(self, comp_group):
        self.comp_group = comp_group
        self.avg_comp = None
        self.avg_dom = None
        self.high = None
        self.low = None
        self.ppsqft = None
        self.mad_comp = None
        self.adj_avg_dom = None

    def calculate(self):
        count = len(self.comp_group)
        prices = []
        doms = []
        ppsqft = []
        for comp in self.comp_group:
            prices.append(comp.sold_price)
            doms.append(comp.dom)
            ppsqft.append(comp.price_per)
        self.avg_comp = sum(prices) / float(count)
        self.avg_dom = sum(doms) / float(count)
        self.ppsqft = sum(ppsqft) / float(count)
        self.low, self.high = min(prices), max(prices)
        mad_dev, median = self.med_abs_dev(prices)
        #mad_dev = mad_dev * 1.5  # using 1.5 deviations to filter pricing
        md_low, md_high = median - mad_dev, median + mad_dev
        d_inter = [i for i in prices if md_low <= i <= md_high]
        mad_count = len(d_inter)
        self.mad_comp = sum(d_inter) / float(mad_count)
        mad_dom_dev, dom_median = self.med_abs_dev(doms)
        #mad_dom_dev = mad_dom_dev * 1.5
        mdd_low, mdd_high = dom_median - mad_dom_dev, dom_median + mad_dom_dev
        mdd_inter = [i for i in doms if mdd_low < i < mdd_high]
        mdd_count = len(mdd_inter)
        self.adj_avg_dom = sum(mdd_inter) / float(mdd_count) if mdd_count else None

    @staticmethod
    def med_abs_dev(a, c=0.6745, axis=None):
        """Median Absolute Deviation along given axis of an array:
        median(abs(a - median(a))) / c
        c = 0.6745 is the constant to convert from MAD to std"""
        a = ma.masked_where(a != a, a)
        if a.ndim == 1:
            d = ma.median(a)
            m = ma.median(ma.fabs(a - d) / c)
        else:
            d = ma.median(a, axis=axis)
            if axis > 0:
                aswp = ma.swapaxes(a,0,axis)
            else:
                aswp = a
            m = ma.median(ma.fabs(aswp - d) / c, axis=0)
        return m, d


def run_comps_scraper():
    print 'Starting comps scraper...'
    need_comps = db.session.query(Properties).filter(
        db.and_(Properties.tax_data.any(), Properties.comps_date == None, Properties.lat_lon != None))
    if need_comps.all():
        urescraper = UtahREScraper(need_comps.all())
        urescraper.get_comps()
        need_details = db.session.query(Comps).filter(Comps.contract_date==None).all()
        urescraper.get_details(need_details)
        print 'Done!'


if __name__ == '__main__':
    run_comps_scraper()
