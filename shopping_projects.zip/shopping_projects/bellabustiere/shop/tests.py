"""
This file demonstrates two different styles of tests (one doctest and one
unittest). These will both pass when you run "manage.py test".

Replace these with more appropriate tests for your application.
"""

from django.test import TestCase
from bellabustiere.shop.models import *
from django.test.client import Client
from bellabustiere.helpers import *
from bellabustiere.userprofile.models import *
class SimpleTest(TestCase):
    def test_basic_addition(self):
        """
        Tests that 1 + 1 always equals 2.
        """
        self.failUnlessEqual(1 + 1, 2)

__test__ = {"doctest": """
Another way to test that 1 + 1 is equal to 2.

>>> 1 + 1 == 2
True
"""}

class ShopTest(TestCase):
    def setUp(self):
        self.site = Site.objects.get(id=1)
        australia = Country.objects.create(country='AUSTRALIA', shipto=True)
        status = ProductStatus.objects.create(status='Available',display_to_user=True,can_buy=True)
        austax = TaxRate.objects.create(name='AuTax', rate=1.1,)
        austax.countries.add(australia)
        
        brand = Brand.objects.create(name='Nike', slug='nike')
        brand2 = Brand.objects.create(name='Adidas', slug='adidas')
        
        activity = Activity.objects.create(name='Sport', slug='sport')
        activity2 = Activity.objects.create(name='Yoga', slug='Yoga')
        
        brand.sites.add(self.site)
        brand2.sites.add(self.site)
        activity.sites.add(self.site)
        activity2.sites.add(self.site)
        
        self.set1 = Set.objects.create(set=3)
        self.set2 = Set.objects.create(set=6)
        self.set3 = Set.objects.create(set=9)
        
        self.cat1 = Categories.objects.create(name='cat1', slug='cat1', is_active=True)
        self.cat2 = Categories.objects.create(name='cat2', slug='cat2',is_active=True, parent=self.cat1)
        self.cat3 = Categories.objects.create(name='cat3', slug='cat3',is_active=True, parent=self.cat1)
        self.cat4 = Categories.objects.create(name='cat4', slug='cat4',is_active=True, parent=self.cat2)
        
        self.cat1.sites.add(self.site)
        self.cat2.sites.add(self.site)     
        self.cat3.sites.add(self.site)
        self.cat4.sites.add(self.site)     
        
        self.product1 = Product.objects.create(title="product1", code="p1", price=149.95, wholesale_price=62.48,tax_rate=austax, wholesale_tax_rate=austax,status=status)
        self.product1.sites.add(self.site)
        self.product1.category_now.add(self.cat4)
        self.product1.brand.add(brand)
        self.product1.activity.add(activity)
        
        self.product2 = Product.objects.create(title="product2", code="p2", price=119.95, wholesale_price=49.98,tax_rate=austax, wholesale_tax_rate=austax,status=status)
        self.product2.sites.add(self.site)
        self.product2.category_now.add(self.cat4)
        self.product2.brand.add(brand)
        self.product2.activity.add(activity)
        
        self.product3 = Product.objects.create(title='product3', code='p3', price=110.23, wholesale_price=55.48,tax_rate=austax, wholesale_tax_rate=austax,status=status)
        self.product3.sites.add(self.site)
        self.product3.category_now.add(self.cat3)
        self.product3.brand.add(brand2)
        self.product3.activity.add(activity)
        
        self.product4 = Product.objects.create(title='product4', code='p4', price=120.23, wholesale_price=57.48,tax_rate=austax, wholesale_tax_rate=austax,status=status)
        self.product4.sites.add(self.site)
        self.product4.category_now.add(self.cat3)
        self.product4.brand.add(brand)
        self.product4.activity.add(activity2)
        
        self.product5 = Product.objects.create(title='product5', code='p5', price=120.23, wholesale_price=57.48,tax_rate=austax, wholesale_tax_rate=austax,status=status)
        self.product5.sites.add(self.site)
        self.product5.category_now.add(self.cat3, self.cat4)
        self.product5.brand.add(brand, brand2)
        self.product5.activity.add(activity2, activity)
        
                
        coupon = Coupon.objects.create(name='test',codes='test')
        discountprice4 = DiscountPrice.objects.create(product=self.product1, price=121.84,wholesale_price=51.37, start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        discountprice1 = DiscountPrice.objects.create(product=self.product1, price=120.84,wholesale_price=50.37, start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        discountprice2 = DiscountPrice.objects.create(product=self.product1, price=110.84,wholesale_price=40.37, coupon=coupon,start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        discountprice3 = DiscountPrice.objects.create(product=self.product1, price=122.84,wholesale_price=52.37, start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        priceset1 = ProductSetPrice.objects.create(product = self.product1, set=self.set1, price=129.95,wholesale_price=58.37)
        priceset2 = ProductSetPrice.objects.create(product = self.product1, set=self.set2, price=119.95,wholesale_price=48.37)
        priceset3 = ProductSetPrice.objects.create(product = self.product1, set=self.set3, price=109.95,wholesale_price=38.37)
        
        sale1 = Sale.objects.create(category=self.cat2,start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        sale2 = Sale.objects.create(category=self.cat4,start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        sale3 = Sale.objects.create(brand=brand2,start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        sale4 = Sale.objects.create(activity=activity2,start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        sale5 = Sale.objects.create(category=self.cat3,start=datetime.datetime(2012,3,1,18,0,0), end=datetime.datetime(2013,3,1,18,0,0))
        
        
        sale1.sites.add(self.site)
        sale2.sites.add(self.site)
        sale3.sites.add(self.site)
        sale4.sites.add(self.site)
        sale5.sites.add(self.site)
        
        salebase1 = SaleBased.objects.create(sale=sale1, quantity=20, off=20, wholesale_off=20)
        salebase2 = SaleBased.objects.create(sale=sale2, quantity=10, off=10, wholesale_off=10)
        salebase3 = SaleBased.objects.create(sale=sale3, quantity=5, off=5, wholesale_off=5)
        salebase4 = SaleBased.objects.create(sale=sale4, quantity=10, off=10, wholesale_off=10)
        salebase5 = SaleBased.objects.create(sale=sale5, quantity=20, off=20, wholesale_off=20)
        
        orderstatus = OrderStatus.objects.create(status='In Progress')
        self.order = Order.objects.create(status=orderstatus, site=self.site)
        self.order2 = Order.objects.create(status=orderstatus, site=self.site)
        
        self.productorder1 = ProductOrder.objects.create(order=self.order, quantity=1, product=self.product1 )
        self.productorder2 = ProductOrder.objects.create(order=self.order, quantity=1, product=self.product2)
        
        self.productorder21 = ProductOrder.objects.create(order=self.order2, quantity=1, product=self.product1 )
        self.productorder22 = ProductOrder.objects.create(order=self.order2, quantity=1, product=self.product2)
        self.productorder23 = ProductOrder.objects.create(order=self.order2, quantity=1, product=self.product3)
        self.productorder24 = ProductOrder.objects.create(order=self.order2, quantity=1, product=self.product4)
        
        self.user1 = User.objects.create(first_name='chao',last_name='chao', username='1_ttt_ttt_com', email='ttt@ttt.com')
        self.user2 = User.objects.create(first_name='retail', last_name='retail', username='1member_test_test_com', email='test@test.com')
        
        australia = Country.objects.create(country='AUSTRALIA', shipto=True)
        try:
            self.wholesale = self.user1.get_profile()
        except:
            self.wholesale = self.user1.profile_set.add(Profile.objects.create(user=self.user1))
        wholesale_shipping = Shipping.objects.create(profile=self.wholesale, postcode='2222', country=australia)
        wholesale_billing = Billing.objects.create(profile=self.wholesale, postcode='2222', country=australia)
        
        try:
            self.retail = self.user2.get_profile()
        except:
            self.retail = self.user2.profile_set.add(Profile.objects.create(user=self.user2))
        retail_shipping = Shipping.objects.create(profile=self.retail, postcode='2222', country=australia)
        retail_billing = Shipping.objects.create(profile=self.retail, postcode='2222', country=australia)
        
    '''def test_product_enquiry(self):
        self.product1.add_to_enquiry(' zac ',' zac_8_8_8@hotmail.com ')
        self.product1.add_to_enquiry('chaol ','dou8le@gmail.com  ')
        self.product1.add_to_enquiry(' zac ',' zac_8_8_8@hotmail.com ')
        self.product1.add_to_enquiry('chaol ','dou8le@gmail.com  ')
        self.product1.add_to_enquiry(' zac ',' zac_8_8_8@hotmail.com ')
        self.product1.add_to_enquiry('chaol ','dou8le@gmail.com  ')
        self.assertEqual(self.product1.enquiry, 'zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,')
        
        outofstock = ProductStatus.objects.create(status='Out of Stock', display_to_user=True, can_buy=False)
        featured = ProductStatus.objects.create(status='Out of Stock', display_to_user=True, can_buy=True, is_featured=True)
        available = ProductStatus.objects.create(status='Available',display_to_user=True,can_buy=True)
        
        self.product1.status = featured
        self.product1.save()
        self.assertEqual(self.product1.enquiry, 'zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,')
        
        self.product1.status = available
        self.product1.save()
        self.assertEqual(self.product1.enquiry, 'zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,')
        
        self.product1.status = outofstock
        self.product1.save()
        self.assertEqual(self.product1.enquiry, 'zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,zac|zac_8_8_8@hotmail.com,chaol|dou8le@gmail.com,')
        
        self.assertEqual(self.product1.send_instock_email(), 2)
        
        self.product1.status = available
        self.product1.save()
        self.assertEqual(self.product1.enquiry, '')'''
        
        
    def test_parent(self):
        self.assertEqual(self.cat4.parent, self.cat2)
        self.assertEqual(self.cat3.parent, self.cat1)
        self.assertEqual(settings.SITE_ID, 1)

    def test_get_Ancestors(self):
        self.assertEqual(list(self.cat4.get_ancestors()),[self.cat1, self.cat2])
        self.assertEqual(list(self.cat3.get_ancestors()),[self.cat1])
        self.assertEqual(list(self.cat2.get_ancestors()), [self.cat1])
        
    def test_get_product_ranges(self):
        self.assertEqual(list(self.cat1.get_all_leaf()), [self.cat4, self.cat3])
        self.assertEqual(list(self.cat2.get_all_leaf()), [self.cat4])
        self.assertEqual(list(self.cat3.get_all_leaf()), [self.cat3])
        self.assertEqual(list(self.cat4.get_all_leaf()), [self.cat4])
        
        
    def test_product_all_categories(self):
        self.assertEqual(list(Categories.objects.get_all_categories_by_product(self.product5)), [self.cat1,self.cat2,self.cat4,self.cat3])
        
    def test_in_filter(self):
        self.assertEqual(list(Product.objects.filter(category_now__in=[self.cat3])),[self.product3,self.product4,self.product5])

    def test_product_price(self):
        
        self.assertEqual(self.product1.getNormalPrice(), '149.95')
        self.assertEqual(self.product1.getNormalPrice(wholesale=True), '62.48')
        self.assertEqual(self.product2.getNormalPrice(), '119.95')
        self.assertEqual(self.product2.getNormalPrice(wholesale=True), '49.98')
        
    def test_discount_price(self):

        self.assertEqual(self.product1.getTaxFreePrice(1, False,'',)[0], '120.84')
        self.assertEqual(self.product1.getTaxFreePrice(1, True,'',)[0], '50.37')
        self.assertEqual(self.product1.getTaxFreePrice(1, False,'test',)[0], '110.84')
        self.assertEqual(self.product1.getTaxFreePrice(1, True,'test',)[0], '40.37')
        self.assertEqual(self.product1.getTaxFreePrice(1, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '149.95')
        self.assertEqual(self.product1.getTaxFreePrice(1, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '62.48')
        self.assertEqual(self.product1.getTaxFreePrice(1, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '149.95')
        self.assertEqual(self.product1.getTaxFreePrice(1, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '62.48')
        
    def test_set_price(self):

        
        self.assertEqual(self.product1.getTaxFreePrice(2, False,'',)[0], '120.84')
        self.assertEqual(self.product1.getTaxFreePrice(2, True,'',)[0], '50.37')
        self.assertEqual(self.product1.getTaxFreePrice(2, False,'test',)[0], '110.84')
        self.assertEqual(self.product1.getTaxFreePrice(2, True,'test',)[0], '40.37')
        self.assertEqual(self.product1.getTaxFreePrice(2, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '149.95')
        self.assertEqual(self.product1.getTaxFreePrice(2, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '62.48')
        self.assertEqual(self.product1.getTaxFreePrice(2, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '149.95')
        self.assertEqual(self.product1.getTaxFreePrice(2, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '62.48')        
        
        self.assertEqual(self.product1.getTaxFreePrice(4, False,'',)[0], '120.84')
        self.assertEqual(self.product1.getTaxFreePrice(4, True,'',)[0], '50.37')
        self.assertEqual(self.product1.getTaxFreePrice(4, False,'test',)[0], '110.84')
        self.assertEqual(self.product1.getTaxFreePrice(4, True,'test',)[0], '40.37')
        self.assertEqual(self.product1.getTaxFreePrice(4, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '129.95')
        self.assertEqual(self.product1.getTaxFreePrice(4, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '58.37')
        self.assertEqual(self.product1.getTaxFreePrice(4, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '129.95')
        self.assertEqual(self.product1.getTaxFreePrice(4, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '58.37')     
        
        self.assertEqual(self.product1.getTaxFreePrice(3, False,'',)[0], '120.84')
        self.assertEqual(self.product1.getTaxFreePrice(3, True,'',)[0], '50.37')
        self.assertEqual(self.product1.getTaxFreePrice(3, False,'test',)[0], '110.84')
        self.assertEqual(self.product1.getTaxFreePrice(3, True,'test',)[0], '40.37')
        self.assertEqual(self.product1.getTaxFreePrice(3, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '129.95')
        self.assertEqual(self.product1.getTaxFreePrice(3, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '58.37')
        self.assertEqual(self.product1.getTaxFreePrice(3, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '129.95')
        self.assertEqual(self.product1.getTaxFreePrice(3, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '58.37')    
        
        self.assertEqual(self.product1.getTaxFreePrice(6, False,'',)[0], '119.95')
        self.assertEqual(self.product1.getTaxFreePrice(6, True,'',)[0], '48.37')
        self.assertEqual(self.product1.getTaxFreePrice(6, False,'test',)[0], '110.84')
        self.assertEqual(self.product1.getTaxFreePrice(6, True,'test',)[0], '40.37')
        self.assertEqual(self.product1.getTaxFreePrice(6, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '119.95')
        self.assertEqual(self.product1.getTaxFreePrice(6, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '48.37')
        self.assertEqual(self.product1.getTaxFreePrice(6, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '119.95')
        self.assertEqual(self.product1.getTaxFreePrice(6, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '48.37')     
        
        self.assertEqual(self.product1.getTaxFreePrice(8, False,'',)[0], '119.95')
        self.assertEqual(self.product1.getTaxFreePrice(8, True,'',)[0], '48.37')
        self.assertEqual(self.product1.getTaxFreePrice(8, False,'test',)[0], '110.84')
        self.assertEqual(self.product1.getTaxFreePrice(8, True,'test',)[0], '40.37')
        self.assertEqual(self.product1.getTaxFreePrice(8, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '119.95')
        self.assertEqual(self.product1.getTaxFreePrice(8, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '48.37')
        self.assertEqual(self.product1.getTaxFreePrice(8, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '119.95')
        self.assertEqual(self.product1.getTaxFreePrice(8, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '48.37')     
        
        self.assertEqual(self.product1.getTaxFreePrice(9, False,'',)[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(9, True,'',)[0], '38.37')
        self.assertEqual(self.product1.getTaxFreePrice(9, False,'test',)[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(9, True,'test',)[0], '38.37')
        self.assertEqual(self.product1.getTaxFreePrice(9, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(9, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '38.37')
        self.assertEqual(self.product1.getTaxFreePrice(9, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(9, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '38.37')   
        
        self.assertEqual(self.product1.getTaxFreePrice(12, False,'',)[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(12, True,'',)[0], '38.37')
        self.assertEqual(self.product1.getTaxFreePrice(12, False,'test',)[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(12, True,'test',)[0], '38.37')
        self.assertEqual(self.product1.getTaxFreePrice(12, False,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(12, True,'',time=datetime.datetime(2014,3,1,18,0,0))[0], '38.37')
        self.assertEqual(self.product1.getTaxFreePrice(12, False,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '109.95')
        self.assertEqual(self.product1.getTaxFreePrice(12, True,'test',time=datetime.datetime(2014,3,1,18,0,0))[0], '38.37')     
        
    def test_sale_price(self):
        sync_productorder(self.order)
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 119.95)
        
        p1.quantity = 5
        p1.save()
        p2.quantity = 5 
        p2.save()
        
        sync_productorder(self.order)
        
        self.assertEqual(self.order.getQuantityBySale(self.cat4), 10)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)
        
        p2.quantity = 14
        p2.save()
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)
        
        p2.quantity = 15
        p2.save()
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 119.96)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 95.96)
        
        p1.quantity = 10
        p1.save()
        p2.quantity = 9
        p2.save()        
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 109.95)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)       
        
        p1.quantity = 10
        p1.save()
        p2.quantity = 10
        p2.save()        
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 109.95)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 95.96)
        
    def test_sale_price_order2(self):    
        sync_productorder(self.order2)
        p1 = self.order2.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order2.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 119.95)
        
        p3 = self.order2.productorder_set.filter(product=self.product3)
        p3 = p3[0]
        self.assertEqual(p3.price, 110.23)
        
        p4 = self.order2.productorder_set.filter(product=self.product4)
        p4 = p4[0]
        self.assertEqual(p4.price, 120.23)
        
        
        p1.quantity = 5
        p1.save()
        p2.quantity = 5 
        p2.save()
        p3.quantity = 4
        p3.save()
        p4.quantity = 5
        p4.save()
        
        sync_productorder(self.order2)
        
        self.assertEqual(self.order2.getQuantityBySale(self.cat4), 10)
        
        p1 = self.order2.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order2.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)
        
        p3 = self.order2.productorder_set.filter(product=self.product3)
        p3 = p3[0]
        self.assertEqual(p3.price, 110.23)
        
        p4 = self.order2.productorder_set.filter(product=self.product4)
        p4 = p4[0]
        self.assertEqual(p4.price, 120.23)
        
        p2.quantity = 14
        p2.save()
        p3.quantity = 5
        p3.save()
        p4.quantity = 5
        p4.save()
        
        sync_productorder(self.order2)
        
        p1 = self.order2.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order2.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)
        
        p3 = self.order2.productorder_set.filter(product=self.product3)
        p3 = p3[0]
        self.assertEqual(p3.price, 104.71)
        
        p4 = self.order2.productorder_set.filter(product=self.product4)
        p4 = p4[0]
        self.assertEqual(p4.price, 120.23)
        
        p2.quantity = 15
        p2.save()
        p3.quantity = 8
        p3.save()
        p4.quantity = 10
        p4.save()
        
        sync_productorder(self.order2)
        
        p1 = self.order2.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 119.96)
        
        p2 = self.order2.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 95.96)
        
        p3 = self.order2.productorder_set.filter(product=self.product3)
        p3 = p3[0]
        self.assertEqual(p3.price, 104.71)
        
        p4 = self.order2.productorder_set.filter(product=self.product4)
        p4 = p4[0]
        self.assertEqual(p4.price, 108.20)
        
        p1.quantity = 10
        p1.save()
        p2.quantity = 9
        p2.save()        
        p3.quantity = 20
        p3.save()
        p4.quantity = 20 
        p4.save()
        
        sync_productorder(self.order2)
        
        p1 = self.order2.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 109.95)
        
        p2 = self.order2.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)    
        
        p3 = self.order2.productorder_set.filter(product=self.product3)
        p3 = p3[0]
        self.assertEqual(p3.price, 88.18)
        
        p4 = self.order2.productorder_set.filter(product=self.product4)
        p4 = p4[0]
        self.assertEqual(p4.price, 96.18)   
        
        p1.quantity = 10
        p1.save()
        p2.quantity = 10
        p2.save()    
        p3.quantity = 4
        p3.save()
        p4.quantity = 1
        p4.save()    
        
        sync_productorder(self.order2)
        
        p1 = self.order2.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 109.95)
        
        p2 = self.order2.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 95.96)     
        
        p3 = self.order2.productorder_set.filter(product=self.product3)
        p3 = p3[0]
        self.assertEqual(p3.price, 110.23)
        
        p4 = self.order2.productorder_set.filter(product=self.product4)
        p4 = p4[0]
        self.assertEqual(p4.price, 120.23)   
    
    def test_retail_order_price(self):
        self.order.user = self.user2
        self.order.save()
        
        sync_productorder(self.order)
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 119.95)
        
        p1.quantity = 5
        p1.save()
        p2.quantity = 5 
        p2.save()
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)
        
        p2.quantity = 14
        p2.save()
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 120.84)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)
        
        p2.quantity = 15
        p2.save()
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 119.96)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 95.96)
        
        p1.quantity = 10
        p1.save()
        p2.quantity = 9
        p2.save()        
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 109.95)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 107.95)       
        
        p1.quantity = 10
        p1.save()
        p2.quantity = 10
        p2.save()        
        
        sync_productorder(self.order)
        
        p1 = self.order.productorder_set.filter(product=self.product1)
        p1 = p1[0]
        self.assertEqual(p1.price, 109.95)
        
        p2 = self.order.productorder_set.filter(product=self.product2)
        p2 = p2[0]
        self.assertEqual(p2.price, 95.96)        

        
    '''def test_category_url(self):
        url = self.cat1.getlandingurl()
        c = Client()
        response = c.get(url)
        self.assertEqual(response.status_code, 200)
    
    def test_product_url(self):
        url = self.product1.get_absolute_url()
        c = Client()
        response = c.get(url)
        self.assertEqual(response.status_code, 200)
        
    def test_landing_url(self):
        url = '/shop/'
        c = Client()
        response = c.get(url)
        self.assertEqual(response.status_code, 302)        
        
    def test_cart_url(self):
        url = '/shop/cart.html'
        c = Client()
        response = c.get(url)
        self.assertEqual(response.status_code, 200)   
        
    def test_checkout_url(self):
        c = Client()
        
        url = '/shop/checkout-billing.html'
        response = c.get(url)
        self.assertEqual(response.status_code, 302)
        
        url = '/shop/checkout-shipping.html'
        response = c.get(url)
        self.assertEqual(response.status_code, 302)'''
              
