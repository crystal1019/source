from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.crawler import crawl_hint

class Command(BaseCommand):
    help = 'Tests crawling'

    def handle(self, *args, **options):

        def bad(got,expected):
            return "\n ---> '" + str(got) + "' instead of '" + str(expected) + "'"

        def crawl_test(testfile, expected_price,expected_source):
            # tests extracting price and source, not image
            full_testfile = "tests/crawl/" + testfile
            output = "Test " + full_testfile
            ok = True
            crawl_price, crawl_source, crawl_photo_url, crawl_photo = crawl_hint(full_testfile,testing=True)
            if crawl_price != expected_price:
                ok = False
                output = output + bad(crawl_price,expected_price)
            if crawl_source != expected_source:
                ok = False
                output = output + bad(crawl_source,expected_source)
            if ok == True:
                output = "PASS " + output
            else:
                output = "FAIL " + output
            print output
            
        crawl_test('exclude_script.html','289','Sonoma Black Entryway Organizer')
        crawl_test('price.html','195','Broom Chair')
        crawl_test('currency_in_span.html','1620','TrueModern Luna Condo Sofa Sofas')
        crawl_test('product.html','343','Mansfield Beige Club Chair')
