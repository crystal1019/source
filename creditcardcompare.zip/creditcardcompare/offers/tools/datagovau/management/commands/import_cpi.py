import os
from datetime import date
from django.core.management.base import BaseCommand
from offers.tools.datagovau.models import Location


class Command(BaseCommand):
    quarters = {'Mar': '0', 'Jun': '25', 'Sep': '5', 'Dec': '75'}
    BATCH = 'All Groups'
    
    def handle(self, *args, **options):
        Location.objects.filter(batch=self.BATCH).delete()
        csv_path = os.path.dirname(__file__)
        f = open(os.path.join(csv_path, 'cpi.csv'))
        cities = f.readline().replace('\n','').split(',')[1:]
        
        max_index = []
        quarters = []
        data_per_city = {}
        orig_data_per_city = {}
        australian_index = {}
        for city in cities:
            data_per_city[city] = {}
            orig_data_per_city[city] = {}
        for l in f.readlines():
            data = l.split(',')
            quarters.insert(0, data[0])
            quarter = data[0][4:]+'.'+self.quarters[data[0][:3]]
            australian_index[float(quarter)] = float(data[-1].rstrip('\n'))
            for city, index in zip(cities, data[1:-1]):
                try:
                    index = float(index)
                except ValueError, e:
                    if index == '':
                        index = 0
                    else:
                        raise e 
                max_index.append(index)
                Location(address=city,
                         data=index,
                         date=date(int(data[0].split(' ')[1]), 
                                   {'Mar': 3, 'Jun': 6, 'Sep': 9, 'Dec': 12}[data[0].split(' ')[0]],
                                   1),
                         batch=self.BATCH
                ).save()
                data_per_city[city].update({data[0]: index})
                orig_data_per_city[city].update({float(quarter): index})
        f.close()

        max_index.sort(reverse=True)
        print '\nMax index(%s): \n%s \n%s \n%s \n%s \n%s' % (len(max_index), max_index[:10], max_index[500:510], max_index[1000:1010], max_index[1500:1510], max_index[2000:2010])
        
        f = open(os.path.join(csv_path, 'formatted_cpi.csv'), 'w')
        f.write('Formatted data for google maps:\n\n')
        for city, data in data_per_city.iteritems():
            f.write("'%s': %s,\n" % (city, data))
        f.write('%s' % quarters)
        
        f.write('\n\nFormatted data for highcharts:\n\n')
        for city, data in orig_data_per_city.iteritems():
            f.write("{\ntype: 'line',\nname: '%s',\npointStart: 1948,\ndata: %s\n}," % (city, [[k,data[k]] for k in sorted(data.iterkeys())]))
        f.write("{\ntype: 'line',\nname: '%s',\npointStart: 1948,\ndata: %s\n}," % ('Australia', [[k,australian_index[k]] for k in sorted(australian_index.iterkeys())]))
        f.close()