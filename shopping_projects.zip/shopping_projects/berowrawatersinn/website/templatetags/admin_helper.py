from django.conf import settings
from django import template

import urlparse
import urllib


from django import template
from django.conf import settings
from django.template import defaultfilters
from django.utils.encoding import force_unicode
from django.utils.formats import number_format
from django.utils.translation import pgettext, ungettext, ugettext as _
from datetime import datetime, date
from berowrawatersinn.reservation.models import *

register = template.Library()

def reorder_admin_apps(app_list):
    """
    This will reorder the apps in the admin using weights defined in the RHEC_ADMIN_APP_WEIGHTS dict.
    The names, unfortunately, must be the verbose names displayed in the admin, not the actual app name, 
    because that is what is in the admin app_list var.
    The app_list argument object is modified, it does not return a value.
    Usage: Define your app weights in settings.py like so:
    RHEC_ADMIN_APP_WEIGHTS = {'Sites': 1,
                              'Auth' : 2}
    Override the default admin index.html template and insert the following before the app_list is rendered:
    {% load admin_app_order %}{% reorder_admin_apps app_list %}
    """
    
    weights = getattr(settings, 'RHEC_ADMIN_APP_WEIGHTS', {})
    for app_dict in app_list:
        app_dict['rhec_sort_weight'] = weights.get(app_dict['name'])[0]
        app_dict['rhec_display_label'] = weights.get(app_dict['name'])[1]
    app_list.sort(lambda x, y: cmp(x['rhec_sort_weight'], y['rhec_sort_weight']))
    return ''
    
register.simple_tag(reorder_admin_apps)

def url_target_blank(text):
    return text.replace('<a ', '<a target="_blank" ')
url_target_blank = register.filter(url_target_blank)


@register.tag(name="get_request_manager")
def do_get_request_manager(parser,token):
    bits = token.contents.split()
    if len(bits) != 5:
        raise 
    return GetRequestManager(bits[1], bits[2], bits[3], bits[4])

class GetRequestManager(template.Node):
    def __init__(self,fullpath,command,target,value):
        self.fullpath,self.command, self.target, self.value= fullpath,command,target,value
    
    def render(self,context):
        fullpath = template.resolve_variable(self.fullpath, context)
        command = self.command
        target = self.target
        value = template.resolve_variable(self.value,context)
        
        mainurl,params = fullpath.split('?')
        thedict = dict(urlparse.parse_qsl(params))
        
        if command == 'auto':
            if target not in thedict.keys() or value not in thedict[target].split(','):
                command = 'add'
            else:
                command = 'minus'
            
        
        if command == 'replace':
            thedict[target] = value
            
        elif command == 'add':
            
            if target not in thedict.keys():
                thedict[target] = value
            else:
                
                thedict[target] += ','+value if value not in thedict[target].split(',') else ''
        
        elif command == 'minus':
            try:
                content = thedict[target].split(',')
        
                if value in content:
                    content.remove(value)
                    if not content:
                        del thedict[target]
                    else:
                        thedict[target] = ','.join(content)
            except:
                pass
            
        return ''.join([mainurl+'?', urllib.urlencode(thedict)])

def seats_count(thedate):
    html = ''
    mealtype = MealType.objects.all()
    for x in mealtype:
        booked, total= SeatsByDate.objects.get_calendar_info(thedate, x)
        html += '<a href="/admin/reservation/booking/?date__year=%s&date__month=%s&date__day=%s&mealtype__id=%s">%s: %s/%s</a> <br>' %(thedate.year,thedate.month,thedate.day,x.id,x.name, booked, total) if total > 0 else ''
        
    return html
seats_count = register.filter(seats_count)
    
