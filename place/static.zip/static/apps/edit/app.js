angular.module('PlaceSpeakApp', [
    'ngRoute',
    'ngSanitize',
    'ui.bootstrap.datetimepicker',
    '$strap.directives',
    'activity.controllers',
    'activity.services',
    'activity.directives',
    'map.services',
    "map.controllers",
    "map.directives",
    "common.directives",
    "editor.controllers",
    'editor.services',
    'editor.directives',
    'common.services',
    'angularMoment'
]).config(["$httpProvider", "$routeProvider",
    function($httpProvider, $routeProvider) {
        $httpProvider.defaults.headers.post['X-CSRFToken'] = $('input[name=csrfmiddlewaretoken]').val();
        $routeProvider
            .when('/team', {
                //templateUrl: '/static/apps/edit/partials/edit/e_team.html',
                //controller: 'TeamCtrl'
            })
            .when('/contact', {
                //templateUrl: '/static/apps/edit/partials/edit/e_contact_information.html',
                //controller: 'ContactCtrl'
            })
            .when('/who', {
                //templateUrl: '/static/apps/edit/partials/edit/e_who.html',
                //controller: 'WhoCtrl'
            })
            .when('/features', {
                //templateUrl: '/static/apps/edit/partials/edit/e_features.html',
                //controller: 'FeaturesCtrl'
            })
            .when('/map', {
                //templateUrl: '/static/apps/common/maps/partials/map_edit.html',
                //controller: 'MapEditCtrl'
            })
            .when('/keywords', {
                //templateUrl: '/static/apps/edit/partials/edit/e_keywords.html',
                //controller: 'KeywordsCtrl'
            })
            .when('/surveys', {
                //templateUrl: '/static/apps/edit/partials/edit/e_surveys.html',
                //controller: 'SurveysCtrl'
            })
            .when('/discussions', {
                //templateUrl: '/static/apps/edit/partials/edit/e_discussions.html',
                //controller: 'DiscussionsCtrl'
            })
            .when('/events', {
                //templateUrl: '/static/apps/edit/partials/edit/e_events.html',
                //controller: 'EventsCtrl'
            })
            .when('/resources', {
                //templateUrl: '/static/apps/edit/partials/edit/e_resources.html',
                //controller: 'ResourcesCtrl'
            })
            .when('/social', {
                //templateUrl: '/static/apps/edit/partials/edit/e_social.html',
                //controller: 'SocialCtrl'
            })
            .when('/polls', {
                //templateUrl: '/static/apps/edit/partials/edit/e_polls.html',
                //controller: 'PollsCtrl'
            })
            .when('/participants', {
                //templateUrl: '/static/apps/edit/partials/edit/e_participants.html',
                //controller: 'ParticipantsCtrl'
            })
            .when('/widgets', {
                //templateUrl: '/static/apps/edit/partials/edit/e_widgets.html',
                //controller: 'WidgetsCtrl'
            })
            .when('/reports', {
                //templateUrl: '/static/apps/edit/partials/edit/e_reports.html',
                //controller: 'ReportsCtrl'
            })
            .when('/overview', {
                //templateUrl: '/static/apps/edit/partials/edit/e_overview.html',
                //controller: 'OverviewCtrl'
            })
            .when('/activity', {
                //     //templateUrl: '/static/apps/common/reports/partials/topic_activity.html',
                //     //controller: 'LiveReportsCtrl'
            })
            .when('/place-it', {
                //     //templateUrl: '/static/apps/common/reports/partials/topic_activity.html',
                //     //controller: 'LiveReportsCtrl'
            })
            .otherwise({
                redirectTo: '/team'
            });
    }
]);