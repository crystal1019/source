from django.db import models
from django.utils.html import strip_tags

# Create your models here.
class ActionLink(models.Model):
    title = models.TextField(null=True)
    link = models.URLField()
    def __unicode__(self):
        return strip_tags(self.title)
    
class GenericComponent(models.Model):
    title = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/', null=True)
    content = models.TextField(null=True)
    link = models.URLField(blank=True,null=True)
    link_text = models.CharField(max_length=100,null=True)
    priority = models.IntegerField(default=0)

    def __unicode__(self):
        return strip_tags(self.title)
    
    class Meta:
        ordering = ['-priority']
    