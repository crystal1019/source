
# all of your evolution scripts, mapping the from_version and to_version to a list if sql commands
_evolutions = [
    [('fv1:-4642533563815512343','fv1:4303053814813191678'), # generated 2012-10-17 16:14:26.335318
        "ALTER TABLE `userprofile_country` MODIFY COLUMN `country` varchar(255) NOT NULL UNIQUE;",
    ],
] # don't delete this comment! ## _evolutions_end ##
