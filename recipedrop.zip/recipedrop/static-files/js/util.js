var util = (function () {

    return {

        spinner_opts: {
            lines: 7, // The number of lines to draw
            length: 4, // The length of each line
            width: 4, // The line thickness
            radius: 4, // The radius of the inner circle
            rotate: 0, // The rotation offset
            color: '#000', // #rgb or #rrggbb
            speed: 1, // Rounds per second
            trail: 60, // Afterglow percentage
            shadow: false, // Whether to render a shadow
            hwaccel: false, // Whether to use hardware acceleration
            className: 'spinner', // The CSS class to assign to the spinner
            zIndex: 2e9, // The z-index (defaults to 2000000000)
            top: 'auto', // Top position relative to parent in px
            left: 'auto' // Left position relative to parent in px
        },    

        ajax_form_opts: function ($form, on_submit_done) {
            return {

                before_submit: function (callback) {
                    $form.find('.help-inline').text('');
                    $form.find('.control-group').removeClass('error');
                    $form.find('input[type=submit]').addClass('disabled');
                    $form.find('.spin_submit').spin(this.spinner_opts);
                    callback();
                },

                submit_failure: function (response) {
                    var response = JSON.parse(response.responseText);
                    $form.find('input[type=submit]').removeClass('disabled');
                    $form.find('.spin_submit').spin(false);

                    $form.find('.help-block').html('');
                    $form.find('.control-group').removeClass('error');

                    $(response.errors).each(function (i, err) {
                        var err_msg = $form.find('#' + err[0] + '_errors');
                        err_msg.html(err[1][0]);
                        err_msg.parents('.control-group').addClass('error');
                    });

                    if (response.alert) {
                        $form.find('.alert').text(response.alert).show();
                    }

                    $form.find('.help-block').each(function () {
                        if ($(this).html() !== '') {
                            $(this).show();
                        } else {
                            $(this).hide();
                        }
                    });
                },

                submit_success: function (response) {
                    $form.find('input[type=submit]').removeClass('disabled');
                    $form.find('.spin_submit').spin(false);

                    if (typeof(response.redirect) !== 'undefined') {
                        window.location.replace(response.redirect);
                    } else if (typeof(on_submit_done) !== 'undefined') {
                        on_submit_done(response);
                    }
                }
            };
        },

        draggify_opts: function ($container) {
            return {
                'upload_url': $('#upload_url').val(),
                'extra_data': {
                    'extra': 'photo',
                    'csrfmiddlewaretoken': $('input[name=csrfmiddlewaretoken]').val()
                },

                drop: function (files, callback) {
                    for (var i = 0; i < files.length; i++) {

                        var fname = files[i].file.name.replace('.', '').replace(" ", "-");

                        $container.find('.files').append(
                            '<li class="upload-' + fname + 
                                '">' + files[i].file.name + 
                                ' <i class="remove_outer">(<a class="remove" data-ind="' +
                                files[i].id + 
                                '">Remove</a>)</i> ' + 
                                '<i class="icon-ok-sign upload_ok"> </i></li>'
                        );

                        $container.find('li.upload-' + fname).
                            find('a.remove').click(function () {
                                $container.draggify().remove_file(
                                    $(this).data('ind')
                                );
                                $(this).parents('li').remove();
                            });

                    }
                    $container.find('.upload_ok').hide();

                    callback();
                }
            };
        }
    };
}());


// jQuery plugins

/*
 * opts = {
 *   before_submit (function),
 *   submit_success (function),
 *   submit_failure (function)
 * }
*/

$.fn.ajaxify = function(opts) {

    function ajaxify_form($form) {
        var action = $form.attr('action');
        var method = $form.attr('method');

        $form.submit(function (evt) {
            evt.preventDefault();

            function submit() {
                var data = {};
                var vals;
                var i;

                $form.find(':input').each(function () {

                    if ($(this).is(':checkbox')) {
                        if ($(this).attr('checked')) {
                            data[$(this).attr('name')] = $(this).val();
                        }
                    } else {
                        data[$(this).attr('name')] = $(this).val();
                    }

                });
                
                $.ajax({
                    url: action,
                    type: method,
                    data: data,
                    success: opts.submit_success,
                    error: opts.submit_failure
                });
            }

            if (opts.before_submit) {
                opts.before_submit(submit);
            } else {
                submit();
            }

            return false;
        });
    }

    this.each(function () {
        var $form = $(this);
        if ($form.is('form')) {
            ajaxify_form($form);
        }
    });
    return this;
};


var draggify_uploads = {};
$.fn.draggify = function () {
    var targets = this;
    var uploads_to_do = 0;

    function count_finished_upload(opts) {
        uploads_to_do--;
        if (uploads_to_do === 0 &&
            typeof(opts.all_uploads_done) !== 'undefined') {
            opts.all_uploads_done();
        }
    }

    function upload_single_file($container, file, opts) {
        var fd = new FormData();
        fd.append('file', file.file);
        $.map(opts.extra_data || {}, function (value, key) {
            fd.append(key, value);
        });
        
        $.ajax({
            url: opts.upload_url,
            type: 'POST',
            processData: false,
            contentType: false,
            data: fd,
            success: function (resp) {
                if (typeof(opts.single_upload_done) !== 'undefined') {
                    opts.single_upload_done(file, resp);
                }
                count_finished_upload(opts);
            },
            error: function (resp) {
                if (typeof(opts.single_upload_error) !== 'undefined') {
                    opts.single_upload_error(file, resp);
                }
                count_finished_upload(opts);
            }
        });
    }

    function do_upload($container, files, opts) {
        uploads_to_do = 0;
	for (var i = 0; i < files.length; i++) {
	    if (files[i] !== undefined) {
		uploads_to_do++;
	    }
	}
        if (uploads_to_do === 0) {
            if (typeof(opts.all_uploads_done) !== 'undefined') {
                opts.all_uploads_done();
            }
        } else {
            $.map(files, function (f) {
		if (f !== undefined) {
                    upload_single_file($container, f, opts);
		}
            });
        }
    }

    return {
        
        /*
         * multi: boolean (allows multiple files)
         * upload_on_drag: boolean (upload as soon as a file is dragged into the
         *   container)
         * single_upload_done: function (called when a single upload is completed)
         * single_upload_error: function
         * upload_url: string
         * extra_data: object (extra POST data to include in each upload)
         * drag_enter: function
         * drag_over: function
         * drop: function (called when file is dropped, before uploaded)
         */
        init: function(opts) {

            function default_drag_event(evt) {
                evt.stopPropagation();
                evt.preventDefault();
            }

            function drop($container, opts) {
                return function (evt) {
                    evt.stopPropagation();
                    evt.preventDefault();

                    var dt = evt.dataTransfer;
                    var files = dt.files;
                    var uploads_key = $container.get(0);
                    var id_files;

                    if (!draggify_uploads[uploads_key]) {
                        draggify_uploads[uploads_key] = [];
                    }

                    id_files = $.map(files, function (f, i) {
                        return {
                            'id': draggify_uploads[uploads_key].length + i,
                            'file': f
                        };
                    });

                    function on_drop() {
                        if (opts.upload_on_drag) {
                            do_upload($container, id_files, opts);
                        } else {
                            if (!opts.multi) {
                                id_files = [{
                                    'id': 0,
                                    'file': files[0]
                                }];
                                draggify_uploads[uploads_key] = id_files;
                            } else {
                                draggify_uploads[uploads_key] =
                                    draggify_uploads[uploads_key].
                                    concat(id_files);
                            }
                        }
                    }
                    
                    if (typeof(opts.drop) !== 'undefined') {
                        opts.drop(id_files, on_drop);
                    } else {
                        on_drop();
                    }
                };
            }


            if (typeof(opts.multi) === 'undefined') {
                opts.multi = false;
            }
            if (typeof(opts.submit_on_drag) === 'undefined') {
                opts.submit_on_drag = false;
            }
            if (typeof(opts.drag_enter) === 'undefined') {
                opts.drag_enter = default_drag_event;
            }
            if (typeof(opts.drag_over) === 'undefined') {
                opts.drag_over = default_drag_event;
            }

            targets.each(function () {
                var $this = $(this);
                $this.get(0).addEventListener('dragenter',
                                              opts.drag_enter,
                                              false);
                $this.get(0).addEventListener('dragover',
                                              opts.drag_over,
                                              false);

                $this.get(0).addEventListener('drop',
                                              drop($this, opts),
                                              false);
            });

        },

        /*
         * single_upload_done: function (called when a single upload is completed)
         * all_uploads_done: function (called when all uploads in a particular
             drop zone are completed)
         * upload_url: string
         * extra_data: object (extra POST data to include in each upload)
         */
        upload_files: function (opts) {
            targets.each(function () {
                do_upload($(this), draggify_uploads[this] || [], opts);
            });
        },

        /*
         * file_id (integer): the identifier of a file passed to
         *   opts.drop
         */
        remove_file: function (file_id) {
            targets.each(function () {
                draggify_uploads[this][file_id] = undefined;
            });
        }

    };
};





// from spin-js
$.fn.spin = function(opts) {
    this.each(function() {
        var $this = $(this),
        data = $this.data();

        if (data.spinner) {
            data.spinner.stop();
            delete data.spinner;
        }
        if (opts !== false) {
            data.spinner = new Spinner($.extend({color: $this.css('color')}, opts)).spin(this);
        }
    });
    return this;
};
