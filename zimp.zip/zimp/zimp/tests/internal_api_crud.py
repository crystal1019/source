from zimp.test import TestCase
from zimp.models import *


class CrudTestCase(TestCase):
    def test_user(self):
        # READ user
        u = User.objects.get(id='07b30eac-7cd8-11e3-8a1e-6cf049f765f5')
        self.assertTrue(u.email == 'user03@gmail.com', 'Usuário inválido')

        # CREATE user
        u = UserInfo.objects.create(**{'cpf': '239.523.943-78', 'name': 'TEST USER NAME', 'country': 'BRA'})
        self.assertTrue(u.cpf == '23952394378', 'Erro criando usuário')
        u = User.objects.create(userinfo=u, email='testuser@example.com', password='test', system='2', role='2')
        self.assertTrue(u.email == 'testuser@example.com', 'Erro criando usuário')

    def _test_user_register(self):
        # register user without login
        r = self.client.request('POST', '/user', body={'cpf': '12345678900', 'name': 'TEST USER', 'email': 'testuser@gmail.com'})
        # Invalid CPF
        self.assertTrue(r['code'] == 5, 'user.registerUser!' + str(r))

        r = self.client.request('POST', '/user', body={'name': 'TEST USER NAME', 'email': 'test@example.com', 'country': 'BRA'})
        # no cpf
        self.assertTrue(r['code'] == 5, 'user.registerUser!' + str(r))

        r = self.client.request('POST', '/user', body={'cpf': '239.523.943-78', 'name': 'TEST USER NAME', 'country': 'BRA'})
        # email must have a value
        self.assertTrue(r['code'] == 5, 'user.registerUser!' + str(r))

        user = self.client.request('POST', '/user', body={'cpf': '239.523.943-78', 'name': 'TEST USER NAME', 'country': 'BRA', 'email': 'testuser@gmail.com'})
        self.assertTrue('id' in user and 'userinfo_id' in user, 'user.registerUser!' + str(user))

        # no permission delete created user DELETE /admin/user
        r = self.client.request('DELETE', '/test/user', body={'userinfo_id': user['userinfo_id']})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        self.login()

        # no permisson DELETE /user/:uid
        r = self.client.request('DELETE', '/user/' + user['id'])
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # DELETE /user/:uid
        r = self.client.request('DELETE', '/user/' + user['id'], headers={'Cookie': self.token})
        self.assertTrue(r['id'] == user['id'], 'user.inativeUser!' + str(r))

        # no permission PUT /user/:uid
        r = self.client.request('PUT', '/admin/user/' + user['id'], body={'active': 1})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # PUT /user/:uid
        r = self.client.request('PUT', '/admin/user/' + user['id'], body={'active': 1}, headers={'Cookie': self.token})
        self.assertTrue(r['id'] == user['id'], 'admin.updateUser!' + str(r))

        # delete created user DELETE /admin/user
        r = self.client.request('DELETE', '/test/user', body={'userinfo_id': user['userinfo_id']}, headers={'Cookie': self.token})
        self.assertTrue(r['userinfo_id'] == user['userinfo_id'], 'admin.deleteUser!' + str(r))

    def _test_user_rule(self):
        self.login()

        # GET /admin/rules
        r = self.client.request('GET', '/admin/rules')
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # GET /admin/rules
        r = self.client.request('GET', '/admin/rules', headers={'Cookie': self.token})
        self.assertTrue(len(r) > 0, 'admin.getRules!' + str(r))

        # POST /admin/rules
        r = self.client.request('POST', '/admin/rules', body={'name': 'registerTest', 'model': 'Test', 'opcode': 1})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # POST /admin/rules
        rule = self.client.request('POST', '/admin/rules', body={'name': 'registerTest', 'model': 'Test', 'opcode': 1}, headers={'Cookie': self.token})
        self.assertTrue('id' in rule, 'admin.addRule!' + str(r))

        # no permission DELETE /admin/rule
        r = self.client.request('DELETE', '/admin/rule/%s' % rule['id'])
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # DELETE /admin/rule
        r = self.client.request('DELETE', '/admin/rule/%s' % rule['id'], headers={'Cookie': self.token})
        self.assertTrue(int(r['id']) == int(rule['id']), 'admin.deleteRule!' + str(r) + str(rule))

        # no permission POST /admin/user/rule
        r = self.client.request('POST', '/admin/user/rule', body={'role': -1, 'rule_id': 1})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # POST /admin/user/rule
        rule = self.client.request('POST', '/admin/user/rule', body={'role': -1, 'rule_id': 1}, headers={'Cookie': self.token})
        self.assertTrue('role' in rule, 'admin.addUserRule!' + str(rule))

        # DELETE /admin/user/rule
        rule = self.client.request('DELETE', '/admin/user/rule', body={'role': -1, 'rule_id': 1}, headers={'Cookie': self.token})
        self.assertTrue('role' in rule, 'admin.addUserRule!' + str(rule))

    def _test_mall(self):
        self.login()

        # no permission GET /mall
        r = self.client.request('GET', '/mall/1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5')
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # GET /mall
        r = self.client.request('GET', '/mall/1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', headers={'Cookie': self.token})
        self.assertTrue('id' in r, 'mall.getMall!' + str(r))

        # with no data GET /mall
        r = self.client.request('GET', '/mall/99999999-9999-9999-9999-999999999999', headers={'Cookie': self.token})
        self.assertTrue(r['code'] == 3, 'mall.getMall!' + str(r))

        # no permission POST /mall
        r = self.client.request('POST', '/mall', body={'cnpj': '08856330000195', 'razaosocial': 'Test mall', 'ddd': 71, 'phone': 32881442})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # POST /mall
        mall = self.client.request('POST', '/mall', body={'cnpj': '08856330000195', 'razaosocial': 'Test mall', 'ddd': 71, 'phone': 32881442}, headers={'Cookie': self.token})
        self.assertTrue('id' in mall, 'mall.registerMall!' + str(mall))

        # no permission PUT /mall/:uid
        r = self.client.request('PUT', '/mall/%s' % mall['id'], body={'active': 1})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # PUT /mall/:uid
        r = self.client.request('PUT', '/mall/%s' % mall['id'], body={'active': 1}, headers={'Cookie': self.token})
        self.assertTrue(r['id'] == mall['id'], 'mall.updateMall!' + str(r))

        # no permission DELETE /mall/:uid
        r = self.client.request('DELETE', '/mall/%s' % mall['id'])
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # DELETE /mall/:uid
        r = self.client.request('DELETE', '/mall/%s' % mall['id'], headers={'Cookie': self.token})
        self.assertTrue('id' in mall, 'mall.inactiveMall!' + str(r))

        # no permission permanent DELETE /mall/:uid
        r = self.client.request('DELETE', '/mall', body={'id': mall['id']})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # permanent DELETE /mall/:uid
        r = self.client.request('DELETE', '/mall/', body={'id': mall['id']}, headers={'Cookie': self.token})
        self.assertTrue('id' in mall, 'mall.deleteMall!' + str(mall))

    def _test_retailer(self):
        self.login()

        # no permission GET /retailer
        r = self.client.request('GET', '/retailer/1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5')
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # GET /retailer
        r = self.client.request('GET', '/retailer/1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', headers={'Cookie': self.token})
        self.assertTrue('id' in r, 'retailer.getRetailer!' + str(r))

        # with no data GET /retailer
        r = self.client.request('GET', '/retailer/99999999-9999-9999-9999-999999999999', headers={'Cookie': self.token})
        self.assertTrue(r['code'] == 3, 'retailer.getRetailer!' + str(r))

        # no permission POST /retailer
        r = self.client.request('POST', '/retailer', body={'cnpj': '08856330000195', 'razaosocial': 'Test retailer', 'ddd': 71, 'phone': 32881442, 'mall_id': '1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', 'brand_id': '7cd9a293-7cc6-11e3-8a1e-6cf049f765f5'})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # POST /retailer
        retailer = self.client.request('POST', '/retailer', body={'cnpj': '08856330000195', 'razaosocial': 'Test retailer', 'ddd': 71, 'phone': 32881442, 'mall_id': '1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', 'brand_id': '7cd9a293-7cc6-11e3-8a1e-6cf049f765f5'}, headers={'Cookie': self.token})
        self.assertTrue('id' in retailer, 'retailer.registerRetailer!' + str(retailer))

        # no permission PUT /retailer/:uid
        r = self.client.request('PUT', '/retailer/%s' % retailer['id'], body={'active': 1})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # PUT /retailer/:uid
        r = self.client.request('PUT', '/retailer/%s' % retailer['id'], body={'active': 1}, headers={'Cookie': self.token})
        self.assertTrue(r['id'] == retailer['id'], 'retailer.updateRetailer!' + str(r))

        # no permission DELETE /retailer/:uid
        r = self.client.request('DELETE', '/retailer/%s' % retailer['id'])
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # DELETE /retailer/:uid
        r = self.client.request('DELETE', '/retailer/%s' % retailer['id'], headers={'Cookie': self.token})
        self.assertTrue('id' in retailer, 'retailer.inactiveRetailer!' + str(r))

        # no permission permanent DELETE /retailer/:uid
        r = self.client.request('DELETE', '/retailer', body={'id': retailer['id']})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # permanent DELETE /retailer/:uid
        r = self.client.request('DELETE', '/retailer/', body={'id': retailer['id']}, headers={'Cookie': self.token})
        self.assertTrue('id' in retailer, 'retailer.deleteRetailer!' + str(retailer))

    def _test_brand(self):
        self.login()

        # no permission GET /brand
        r = self.client.request('GET', '/brand/12b29e20-7cc6-11e3-8a1e-6cf049f765f5')
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # GET /brand
        r = self.client.request('GET', '/brand/12b29e20-7cc6-11e3-8a1e-6cf049f765f5', headers={'Cookie': self.token})
        self.assertTrue('id' in r, 'brand.getBrand!' + str(r))

        # with no data GET /brand
        r = self.client.request('GET', '/brand/99999999-9999-9999-9999-999999999999', headers={'Cookie': self.token})
        self.assertTrue(r['code'] == 3, 'brand.getBrand!' + str(r))

        # no permission POST /brand
        r = self.client.request('POST', '/brand', body={'cnpj': '08856330000195', 'razaosocial': 'Test brand', 'ddd': 71, 'phone': 32881442})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # POST /brand
        brand = self.client.request('POST', '/brand', body={'cnpj': '08856330000195', 'razaosocial': 'Test brand', 'ddd': 71, 'phone': 32881442}, headers={'Cookie': self.token})
        self.assertTrue('id' in brand, 'brand.registerBrand!' + str(brand))

        # no permission PUT /brand/:uid
        r = self.client.request('PUT', '/brand/%s' % brand['id'], body={'active': 1})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # PUT /brand/:uid
        r = self.client.request('PUT', '/brand/%s' % brand['id'], body={'active': 1}, headers={'Cookie': self.token})
        self.assertTrue('id' in r, 'brand.updateBrand!' + str(r))

        # no permission DELETE /brand/:uid
        r = self.client.request('DELETE', '/brand/%s' % brand['id'])
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # DELETE /brand/:uid
        r = self.client.request('DELETE', '/brand/%s' % brand['id'], headers={'Cookie': self.token})
        self.assertTrue('id' in brand, 'brand.inactiveBrand!' + str(r))

        # no permission permanent DELETE /brand/:uid
        r = self.client.request('DELETE', '/brand', body={'id': brand['id']})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # permanent DELETE /brand/:uid
        r = self.client.request('DELETE', '/brand/', body={'id': brand['id']}, headers={'Cookie': self.token})
        self.assertTrue('id' in brand, 'brand.deleteBrand!' + str(brand))

    def _test_admin(self):

        self.login()

        # register user without login (Invalid token)
        r = self.client.request('POST', '/admin/user', body={'cpf': '12345678900', 'name': 'TEST USER', 'email': 'testuser@gmail.com', 'system': 1, 'role': 1})
        self.assertTrue(r['code'] == 4, 'user.registerUser!' + str(r))

        # register user POST /admin/user
        r = self.client.request('POST', '/admin/user', body={'cpf': '12345678900', 'name': 'TEST USER', 'email': 'testuser@gmail.com', 'system': 1, 'role': 1}, headers={'Cookie': self.token})
        # Invalid CPF
        self.assertTrue(r['code'] == 5, 'user.registerUser!' + str(r))

        r = self.client.request('POST', '/admin/user', body={'cpf': '239.523.943-78', 'name': 'TEST USER NAME', 'country': 'BRA', 'system': 1, 'role': 1}, headers={'Cookie': self.token})
        # email must have a value
        self.assertTrue(r['code'] == 5, 'user.registerUser!' + str(r))

        user = self.client.request('POST', '/admin/user', body={'cpf': '239.523.943-78', 'name': 'TEST USER NAME', 'country': 'BRA', 'email': 'testuser@gmail.com', 'system': 1, 'role': 1}, headers={'Cookie': self.token})
        self.assertTrue('id' in user and 'userinfo_id' in user, 'user.registerUser!' + str(user))

        # no permission delete created user DELETE /user
        r = self.client.request('DELETE', '/test/user', body={'userinfo_id': user['userinfo_id']})
        self.assertTrue(r['code'] == 4, 'admin.deleteUser!' + str(r))

        # DELETE /user
        r = self.client.request('DELETE', '/test/user', body={'userinfo_id': user['userinfo_id']}, headers={'Cookie': self.token})
        self.assertTrue(r['userinfo_id'] == user['userinfo_id'], 'user.inativeUser!' + str(r))

    def _test_promotion(self):
        self.login()

        # no permission GET /brand
        r = self.client.request('GET', '/promotion/12b29e20-7cc6-11e3-8a1e-6cf049f765f5')
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # GET /promotion
        r = self.client.request('GET', '/promotion/1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5', headers={'Cookie': self.token})
        self.assertTrue('id' in r, 'promotion.getPromotion!' + str(r))

        # with no data GET /promotion
        r = self.client.request('GET', '/promotion/99999999-9999-9999-9999-999999999999', headers={'Cookie': self.token})
        self.assertTrue(r['code'] == 3, 'promotion.getPromotion!' + str(r))

        # no permission POST /promotion
        r = self.client.request('POST', '/promotion', body={'name': 'promo test', 'factor': 0.2, 'owner_type': 3, 'owner_id': '1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', 'end_at': '2014-03-01'})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # POST /promotion
        promotion = self.client.request('POST', '/promotion', body={'name': 'promo test', 'factor': 0.2, 'owner_type': 3, 'owner_id': '1f2ca46a-7cc7-11e3-8a1e-6cf049f765f5', 'end_at': '2014-03-01'}, headers={'Cookie': self.token})
        self.assertTrue('id' in promotion, 'promotion.registerPromotion!' + str(promotion))

        # no permission PUT /promotion/:uid
        r = self.client.request('PUT', '/promotion/%s' % promotion['id'], body={'name': 'promo test 2'})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # PUT /promotion/:uid
        r = self.client.request('PUT', '/promotion/%s' % promotion['id'], body={'name': 'promo test 2'}, headers={'Cookie': self.token})
        self.assertTrue('id' in r, 'promotion.updatePromotion!' + str(r))

        # no permission DELETE /promotion/:uid
        r = self.client.request('DELETE', '/promotion/%s' % promotion['id'])
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # DELETE /promotion/:uid
        r = self.client.request('DELETE', '/promotion/%s' % promotion['id'], headers={'Cookie': self.token})
        self.assertTrue('id' in promotion, 'promotion.inactivePromotion!' + str(r))

        # no permission permanent DELETE /promotion/:uid
        r = self.client.request('DELETE', '/promotion', body={'id': promotion['id']})
        self.assertTrue(r['code'] == 4, 'VULNERABILITY FOUND!' + str(r))

        # permanent DELETE /promotion/:uid
        r = self.client.request('DELETE', '/promotion/', body={'id': promotion['id']}, headers={'Cookie': self.token})
        self.assertTrue('id' in promotion, 'promotion.deletePromotion!' + str(promotion))

    def test_transaction(self):
        r = Transaction.objects.register(
            **{
                'from_id': '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5',
                'to_id': 'bdfd31d7-7cd4-11e3-8a1e-6cf049f765f5',
                'value': 108.50,
                'promotion': '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5'
            }
        )
        self.assertTrue(r[0], 'Transação não pôde ser criada!')
        r = Transaction.objects.register(
            **{
                'from_id': '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5',
                'to_id': 'ca141cae-7cd4-11e3-8a1e-6cf049f765f5',
                'value': 109.50,
                'promotion': '1cc5d7b2-7cdb-11e3-8a1e-6cf049f765f5'
            }
        )
        self.assertTrue(r[0], 'Transação não pôde ser criada!')
