from django.core.management.base import BaseCommand, CommandError
from bellabustiere.shop.models import *
import datetime


class Command(BaseCommand):
    help = 'Send email at specified time for vouchers'
    
    def handle(self, **options):
        now = datetime.datetime.now()
        today = datetime.date(now.year, now.month, now.day)
        vouchers = Voucher.objects.filter(valid=True, send_date=today)
        for x in vouchers:
            try:
                theorder = x.voucherorder_set.all()[0].order
            except:
                theorder = ''
            if x.is_valid() and theorder:
                x.send_email(theorder)
                print "-- Voucher Email sent to %s by order(%s)" %(x.recipient, theorder.getOrderNumber())
                
                