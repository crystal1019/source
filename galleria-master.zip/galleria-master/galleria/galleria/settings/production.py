"""
Django settings for galleria production project.

"""
"""
Local Django settings for galleria project.

"""

from .base import *

