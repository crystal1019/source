'''
@author: chaol
'''
from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^$', 'bellabustiere.shop.wholesaleviews.login'),
    (r'^register.html$', 'bellabustiere.shop.wholesaleviews.register'),
    (r'^register-member.html$', 'bellabustiere.shop.wholesaleviews.memberregister'),
    (r'^registered.html$', 'bellabustiere.shop.wholesaleviews.registered'),
    (r'^login.html$', 'bellabustiere.shop.wholesaleviews.login'),
    (r'^orders.html$', 'bellabustiere.shop.wholesaleviews.orders'),
    (r'^order(?P<id>\d+).html$', 'bellabustiere.shop.wholesaleviews.order'),
    (r'^profile.html$', 'bellabustiere.shop.wholesaleviews.profile'),
    (r'^payment_term.html$','bellabustiere.shop.wholesaleviews.payment_term'),
    (r'^shipping.html$', 'bellabustiere.shop.wholesaleviews.shipping'),
    (r'^logout.html$', 'bellabustiere.shop.wholesaleviews.logout'),
    (r'^forgotpassword.html$', 'bellabustiere.shop.wholesaleviews.forgotpassword'),
)
