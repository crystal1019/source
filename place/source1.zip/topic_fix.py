from place.topics.models import *
from place.django_recurly.models import *
from place.proponents.models import *
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist

Account.objects.all().delete()
Payment.objects.all().delete()
Subscription.objects.all().delete()
Organization.objects.all().delete()
ProponentOrganization.objects.all().delete()
ProponentAccount.objects.all().delete()
TopicSubscription.objects.all().delete()

# This may fail...speak to Dustin

# Get user
user = User.objects.get(email='cgibson@placespeak.com')

# Check if proponent - creates if not
try:
	proponent = Proponent.objects.get(user=user)
except ObjectDoesNotExist:
	proponent = Proponent(user=user)
	proponent.save()

# Creates new Account
account = Account(account_code='FAKE-PlaceSpeak-Legacy-Topics', user=user, email=user.email, first_name=user.first_name, last_name=user.last_name, company_name='PlaceSpeak')
account.save()

# Creates link table entry
ProponentAccount(proponent=proponent, account=account)

# Creates subscription
sub = Subscription(account=account, plan_code='legacy_enterprise')
sub.save()

# List of all topics
topics = Topic.objects.all()

# Creates a TopicSubscription for each usin the same subscription
for topic in topics:
	TopicSubscription(topic=topic, subscription=sub).save()
	
# Creates PlaceSpeak organization	
org = Organization()
org.name = 'PlaceSpeak'
org.org_type = 'OTHER'
org.address1 = '1005 Cypress Street'
org.city = 'Vancouver'
org.postal_code = 'V6J 3K5'
org.province = 'BC'
org.country = 'CA'
org.email = 'place@placespeak.com'
org.save()

# Will manually go through and add all relevant ProponentsOrganization entries - not required for topics to work.

