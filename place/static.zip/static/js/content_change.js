// Trigger contents change on html()
(function( $, oldHtmlMethod ){
    $.fn.html = function(){
        var results = oldHtmlMethod.apply( this, arguments );
        if(arguments.length > 0) {
             this.trigger('contentchanged');
        }
        return results;
    };
})( jQuery, jQuery.fn.html );

// Trigger contents change on append()
(function( $, oldHtmlMethod ){
    $.fn.append = function(){
        var results = oldHtmlMethod.apply( this, arguments );
        if(arguments.length > 0) {
             this.trigger('contentchanged');
        }
        return results;
    };
})( jQuery, jQuery.fn.append );