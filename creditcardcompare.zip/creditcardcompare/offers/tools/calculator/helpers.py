from math import log, pow


CUSTOM_ERROR_MSG = 'Balance will grow if %s is too small.'

def generate_series(name, principal, rate, term=None, annuity=None):
    FUNCTIONS = {
        'Remaining Balance': get_remaining_balance,
        'Interest Paid': get_total_paid_interest,
        }
    if term is None and annuity is not None:
        term = calculate_term_length(principal, rate, annuity)
    elif term is not None and annuity is None:
        annuity = get_annuity(principal, rate, term)
    
    data = []
    for month in range(int(round(float(term)*12) + 1)):
        try:
            remaining = FUNCTIONS.get(name, get_remaining_balance)(principal, annuity, rate/12, month)
        except TypeError:
            remaining = FUNCTIONS.get(name, get_remaining_balance)(principal, annuity, float(rate)/12, month)
        data.append(round(remaining,2))
    return {'name':name, 'data':data}

def get_total_paid_interest(present_value, annuity, rate, term):
    remaining = get_remaining_balance(present_value, annuity, rate, term)
    return annuity * term - (present_value - remaining)
    
def get_annuity(present_value, rate, term):
    '''Phasing out this function
    '''
    return get_annuity_2(rate, term, present_value)

def get_annuity_2(annual_rate, years, P=None, F=None):
    '''Intended to replace get_annuity().
    
    Formula is based from:
    http://www.investopedia.com/articles/03/101503.asp
    
    A = annuity
    P = principal or present value
    F = future value
    i = interest rate
    n = compounding period
    
    A = Pi/[1-(1+i)^-n] or
    A = Fi/[(1+i)^n-1]
    '''
    try:
        i = annual_rate/100.0/12
    except TypeError:
        i = float(annual_rate)/100.0/12
    n = years*12

    if P is not None:
        x = pow((1 + i), -n)
        return P * i / (1 - x)
    else:
        x = pow((1 + i), n)
        return F * i / (x - 1)       
    
def get_future_value(annual_rate, years, P=None, A=None, compound_monthly=True):
    '''Future Value formula:
    A = annuity
    P = principal or present value
    i = interest rate
    n = compounding period
    
    F = P(1+i)^n or
    F = A[(1+i)^n-1]/i
    '''
    try:
        annual_rate = annual_rate/100.0
    except TypeError:
        annual_rate = float(annual_rate)/100.0
    i, n = (annual_rate/12, years*12) if compound_monthly else (annual_rate, years)
    
    if P is not None:
        return P * pow((1 + i), n)
    else:
        x = pow((1 + i), n)
        try:
            return A * (x - 1) / i
        except ZeroDivisionError:
            return A * n

def get_current_balance(B, A, a, b, x, y):
    '''Current balance formula:
    a = promo period (months)
    b = remaining period after promo (months)
    x = promo rate (monthly)
    y = rate after promo period (monthly)
    B = initial deposit
    A = annuity

    F = B(1+x)^a(1+y)^b + (A/x)[(1+x)^a-1](1+y)^b + (A/y)[(1+y)^b-1]
    '''
    promo = get_future_value(x, a, A=A, compound_monthly=False)
    normal = get_future_value(y, b, A=A, compound_monthly=False)
    
    B = get_future_value(x, a, P=B, compound_monthly=False)
    B = get_future_value(y, b, P=B, compound_monthly=False)
    
    return B + get_future_value(y, b, P=promo, compound_monthly=False) + normal

def get_complex_annuity(B, F, a, b, x, y):
    '''Current balance formula:
    a = promo period (months)
    b = remaining period after promo (months)
    x = promo rate (monthly)
    y = rate after promo period (monthly)
    B = initial deposit
    F = future value

    A = (F - B(1+x)^a(1+y)^b) / [ ([(1+x)^a-1]/x)(1+y)^b + [(1+y)^b-1]/y ]
    '''
    B = get_future_value(x, a, P=B, compound_monthly=False)
    B = get_future_value(y, b, P=B, compound_monthly=False)
    
    y = y/100.0
    x = x/100.0
    
    try:
        factor = (pow((1+y), b) - 1) / y
    except ZeroDivisionError:
        factor = 0
    try:
        promo_factor = (pow((1+x), a) - 1) / x
    except ZeroDivisionError:
        promo_factor = 0
    try:
        return (F - B) / (get_future_value(y*100, b, P=promo_factor, compound_monthly=False) + factor)
    except ZeroDivisionError:
        return (F - B) / b
            

def calculate_term_length(present_value, rate, annuity):
    '''Formula is derived from the function get_annuity'''
    try:
        rate = rate/100.0/12
    except TypeError:
        rate = float(rate)/100.0/12
    x = 1 - present_value * rate / annuity
    try:
        return -(log(x)/log(1 + rate)) / 12
    except ZeroDivisionError:  # linear calculation when rate = 0%
        return present_value / annuity / 12
    except ValueError:  # when repayment is too small, balance will grow
        raise Exception(CUSTOM_ERROR_MSG)

def get_remaining_balance(principal, annuity, rate, nth_term):
    '''Formula is based from:
    http://www.financeformulas.net/Remaining_Balance_Formula.html
    '''
    try:
        rate = rate/100.0
    except TypeError:
        rate = float(rate)/100.0
    e_rate = pow((1 + rate), nth_term)
    try:
        return principal * e_rate - annuity * (e_rate-1) / rate
    except ZeroDivisionError:  # linear calculation when rate = 0%
        return principal - annuity * nth_term
