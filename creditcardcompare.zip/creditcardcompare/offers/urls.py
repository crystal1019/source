from django.conf.urls import *
from django.conf import settings
from django.views.generic import TemplateView
from django.contrib import admin

    
admin.autodiscover()

urlpatterns = patterns('',
    (r'^robots.txt$', include('robots.urls')),
    url(r'^admin777/', admin.site.urls),
    url(r'^email-notice/', include('offers.utils.notifier.urls')),
    url(r'^lead/', include('offers.helpers.lead.urls')),
    url(r'^lightbox/', include('offers.tools.lightbox.urls')),
    url(r'^test/', include('offers.helpers.template.urls')),
    url (r'^', include('offers.tools.reviews.urls')),
    url(r'^', include('offers.core.urls')),
)
urlpatterns = patterns('',
    (r'^tools/$', TemplateView.as_view(template_name= 'template/tools.html')),
    (r'^tools/alerts/', include('offers.tools.rate_alert.urls')),
    (r'^tools/beat-my-card/', include('offers.tools.beatcard.urls')),
    (r'^tools/cache_admin/', include('offers.utils.cache_admin.urls')),
    (r'^tools/calculators/', include('offers.tools.calculator.urls')),
    (r'^tools/smart-search', include('offers.tools.smart_search.urls')),
    (r'^tools/', include('offers.tools.datagovau.urls')),
) + urlpatterns
urlpatterns = patterns('',
    (r'^feed/live-stats/$', TemplateView.as_view(template_name='offers/snippets/stats.html')),
    (r'^feed/megamenu/$', TemplateView.as_view(template_name='menu.html')),
) + urlpatterns

if settings.DEBUG:
    urlpatterns = patterns('',
        url(r'^admin/', admin.site.urls),
        url(r'^media/(?P<path>.*)$', 'django.views.static.serve', {
            'document_root': settings.MEDIA_ROOT, 'show_indexes': True
        }),
        url(r'^css/font/(?P<path>.*)$', 'django.views.static.serve', {
            'document_root': settings.PROJECT_DIR + '/static/creditcardcompare.com.au/2014/css/font', 'show_indexes': True
        }),
    ) + urlpatterns
