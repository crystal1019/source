angular.module('channel.directives', []).directive('setMapDimensions', [function(){
	return function(scope, elem, attrs) {
		scope.$watch('mapheight', function(nv, ov){
			if(angular.isDefined(nv)){
				elem.css("height", nv+"px");
			}
		});
	};
}]).directive('setContentDimensions', [function(){
	return function(scope, elem, attrs) {
		scope.$watch('contentheight', function(nv, ov){
			if(angular.isDefined(nv)){
				elem.css("height", nv+"px");
			}
		});
	};
}]).directive('determineWidth', [function(){
	return function(scope, elem, attrs) {
		scope.$watch('width', function(nv, ov){
			if(nv > 600){
				elem.addClass("span4");
			}
			else if(nv <= 600 && nv >= 400){
				elem.addClass("span6");
			}
			else{
				elem.addClass("span12");
			}
		});
	};
}]);