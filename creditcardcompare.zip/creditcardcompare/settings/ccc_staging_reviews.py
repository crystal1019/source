import sys
from settings.ccc_staging import *


ALLOWED_HOSTS = ['reviews.staging.creditcardcompare.com.au']
