angular.module('topic.directives', [])
    .directive("inputmap", ["$compile",
        function($compile) {
            return function(scope, elem, attrs) {

                scope.IMData.defer.promise.then(function() {
                    var map_style = [{
                        featureType: 'poi',
                        elementType: "labels",
                        stylers: [{
                            visibility: "off"
                        }]
                    }];
                    scope.IMData.gmap = new GMap2(elem.attr("id"), {
                        zoom: scope.IMData.store.inputmap.zoom || 10,
                        center: new google.maps.LatLng(scope.IMData.store.inputmap.center.lat, scope.IMData.store.inputmap.center.lng),
                        drawingControl: false,
                        styles: map_style
                    });
                    scope.current_map = scope.IMData.gmap;
                    google.maps.event.addListenerOnce(scope.current_map.map, 'bounds_changed', function() {
                        scope.bounds_restriction_points = [];
                        scope.bounds_restriction = this.getBounds();
                        var ne = scope.bounds_restriction.getNorthEast();
                        var sw = scope.bounds_restriction.getSouthWest();
                        var nw = new google.maps.LatLng(ne.lat(), sw.lng());
                        var se = new google.maps.LatLng(sw.lat(), ne.lng());
                        scope.bounds_restriction_points.push(ne);
                        scope.bounds_restriction_points.push(nw);
                        scope.bounds_restriction_points.push(sw);
                        scope.bounds_restriction_points.push(se);
                        scope.bounds_restriction_points.push(ne);
                        scope.polyline = new google.maps.Polyline({
                            path: scope.bounds_restriction_points,
                            strokeColor: "#FF0000",
                            strokeWeight: 0.7,
                            clickable: false,
                            map: this
                        });
                    });
                    var infoWindowTpl = '<div id="infowindow_content" im-infowindow></div>';

                    var iwcontent = $compile(infoWindowTpl)(scope)[0];

                    scope.IMData.infowindow = new google.maps.InfoWindow({
                        content: iwcontent,
                        maxWidth: 300
                    });

                    google.maps.event.addListener(scope.IMData.infowindow, 'closeclick', function() {
                        scope.safeApply(function() {
                            if (scope.selected_feature.creation) {
                                scope.$broadcast('cancel-comment');
                            }
                            scope.selected_feature = null;
                        })
                    });

                    if (!scope.IMData.layer) {
                        scope.IMData.layer = new GPolygonLayer(scope.IMData.gmap, {
                            editable: false
                        });
                        scope.IMData.layer.loadEncodedPolygons(scope.IMData.store.basegeos, true, false, true);
                        scope.IMData.layer.bind('featureclicked', function(ft, latlng) {
                            scope.safeApply(function() {
                                scope.selected_feature = ft;
                            });
                        });
                        scope.IMData.post_bounds = scope.IMData.gmap.map.getBounds();
                    }
                    if (!scope.IMData.gmarklayer) {
                        scope.IMData.gmarklayer = new GeoMarkLayer(scope.IMData.gmap, {
                            draggable: false
                        });
                        scope.IMData.gmarklayer.loadGeoMarks(scope.IMData.store.geomarks);
                        scope.IMData.gmarklayer.loadIMPosts(scope.IMData.store.posts, scope.user);
                        scope.IMData.gmarklayer.bind("select_marker", function(mark) {
                            scope.safeApply(function() {
                                if (mark.creation) {
                                    if (scope.bounds_restriction.contains(mark.position)) {
                                        scope.selected_feature = mark;
                                    } else {
                                        scope.IMData.gmarklayer.removeUnsavedMarker();
                                        scope.out_of_bounds = true;
                                        scope.IMData.gmarklayer.enableCommenting();
                                    }
                                } else {
                                    scope.selected_feature = mark;
                                }
                            });
                        });
                        scope.IMData.gmarklayer.bind('comment_dragstart', function(latlng) {
                            scope.safeApply(function() {
                                scope.new_comment_prev_latlng = latlng;
                            });
                        });
                        scope.IMData.gmarklayer.bind('comment_dragend', function(latlng) {
                            scope.safeApply(function() {
                                scope.new_comment_new_latlng = latlng;
                                if (!scope.bounds_restriction.contains(scope.new_comment_new_latlng)) {
                                    scope.selected_feature.setPosition(scope.new_comment_prev_latlng);
                                    scope.out_of_bounds = true;
                                }
                            });
                        })
                    }
                    scope.IMData.gmarklayer.cluster(scope.user);
                });
            };
        }
    ])
    .directive('imInfowindow', [

        function() {
            return {
                templateUrl: '/static/apps/topic/partials/inputmap_infowindow.html'
            }
        }
    ])
    .directive("fullscreenInputMap", [

        function() {
            var id;
            return {
                link: function(scope, elem, attrs) {
                    id = elem.attr('id')
                    scope.closeFullscreenMap = function(hidefn) {
                        // Hide modal
                        hidefn();
                        scope.IMData.infowindow.close();
                        scope.IMData.gmarklayer.disableCommenting();
                        // Reset map and move all features back
                        scope.safeApply(function() {
                            scope.fullscreen = false;
                            scope.map_tools.fullscreen = true;
                            scope.current_map = scope.IMData.gmap;
                            scope.IMData.layer.setGMap(scope.current_map);
                            scope.IMData.gmarklayer.setGMap(scope.current_map);
                            scope.polyline.setMap(scope.current_map.map);
                        });
                        // Have to remove manually as Angular Strap doesn't
                        // even though it's meant to
                        elem.parent('.modal').remove();
                    };
                    scope.$on('modal-shown', function() {
                        scope.safeApply(function() {
                            scope.map_tools.fullscreen = false;
                            scope.IMData.gmarklayer.disableCommenting();
                            var map_style = [{
                                featureType: 'poi',
                                elementType: "labels",
                                stylers: [{
                                    visibility: "off"
                                }]
                            }];
                            scope.fullscreen_map.gmap = new GMap2(id, {
                                zoom: (scope.IMData.store.inputmap.zoom) ? scope.IMData.store.inputmap.zoom : 13,
                                center: new google.maps.LatLng(
                                    scope.IMData.store.inputmap.center.lat,
                                    scope.IMData.store.inputmap.center.lng
                                ),
                                drawingControl: false,
                                styles: map_style
                            });
                            scope.current_map = scope.fullscreen_map.gmap;
                            scope.polyline.setMap(scope.current_map.map);
                            scope.IMData.layer.setGMap(scope.current_map);
                            scope.IMData.gmarklayer.setGMap(scope.current_map);
                        });
                    });
                }
            };
        }
    ])
    .filter('truncate', [

        function() {
            return function(text, length, end) {
                if (isNaN(length))
                    length = 10;

                if (end === undefined)
                    end = "https://www.placespeak.com/topic/" + data.topic + "/";

                if (text.length <= length || text.length - end.length <= length) {
                    return text;
                } else {
                    return String(text).substring(0, length - end.length) + end;
                }

            };
        }
    ])
    .filter('striphtml', [

        function() {
            return function(content) {
                return String(content).replace(/<[^>]+>/gm, '');
            };
        }
    ])
    .directive('commentThread', [

        function() {
            return function(scope, elem, attrs) {
                attrs.$observe('openThreads', function(a) {
                    if (_.contains(scope.open_threads, parseInt(attrs['commentThread']))) {
                        elem.slideDown();
                    } else {
                        elem.slideUp();
                    }
                });
            };
        }
    ])
    .directive('isFollowedNb', ["$parse",
        function($parse) {
            return {
                link: function(scope, elem, attrs) {

                    attrs.$observe('followedThreads', function(value) {
                        var thread_id = parseInt(attrs.isFollowedNb);
                        var followed_threads = $parse(value)(scope);
                        if (_.contains(followed_threads, thread_id)) {
                            elem.text("Unfollow Noticeboard");
                        } else {
                            elem.text("Follow Noticeboard");
                        }
                    });
                }
            }
        }
    ])
    .directive('isFollowed', ["$parse",
        function($parse) {
            return {
                link: function(scope, elem, attrs) {
                    var thread_id = parseInt(attrs.isFollowed);

                    attrs.$observe('followedThreads', function(value) {
                        var followed_threads = $parse(value)(scope);
                        if (_.contains(followed_threads, thread_id)) {
                            elem.text("Unfollow this Discussion");
                        } else {
                            elem.text("Follow this Discussion");
                        }
                    })
                }
            }
        }
    ])
    .directive('slice', ["$parse", "$timeout",
        function($parse, $timeout) {
            return {
                link: function(scope, elem, attrs) {

                    elem.text($parse(attrs.slice)(scope));

                    elem.expander({
                        slicePoint: 220
                    });
                }
            }
        }
    ])
    .directive('isFollowingAll', ["$parse",
        function($parse) {
            return {
                link: function(scope, elem, attrs) {
                    attrs.$observe('isFollowingAll', function(value) {
                        var followed_threads = $parse(value)(scope);
                        if (angular.isDefined(followed_threads)) {
                            if (followed_threads.length > 0) {
                                elem.text("Unfollow Discussions");
                            } else {
                                elem.text("Follow Discussions");
                            }
                        }
                    })
                }
            }
        }
    ])
    .directive('replyThread', [

        function() {
            return function(scope, elem, attrs) {
                attrs.$observe('openReplies', function(a) {
                    if (_.contains(scope.open_replies, parseInt(attrs['replyThread']))) {
                        elem.slideDown();
                    } else {
                        elem.slideUp();
                    }
                });
            };
        }
    ])
    .directive('makeReply', [

        function() {
            return {
                restrict: 'A',
                scope: {
                    obj: '=',
                    replyTo: '=',
                    postComment: '&',
                    cancelComment: '&',
                    replyToType: '='
                },
                templateUrl: '/static/apps/topic/partials/discussion_reply_form.html',
                link: function(scope, elem, attrs) {
                    scope.$watch('replyTo', function(nv, ov) {
                        if (nv === scope.obj.id) {
                            elem.slideDown();
                        } else {
                            elem.slideUp();
                        }
                    });
                    scope.$on('post-error', function(evt, data) {
                        if (data.type == scope.replyToType && scope.obj.id == data.obj_id) {
                            scope.reply_content = data.text_content;
                            scope.errors = data.errors;
                        }
                    });
                }
            }
        }
    ])
    .directive('fullscreenMap', [

        function() {
            return {
                link: function(scope, elem, attrs) {
                    scope.$on('modal-shown', function() {
                        elem.height(elem.parent().height());
                        var gmap = new GMap2(elem.attr('id'), {
                            zoom: data.map_zoom ? data.map_zoom : 13,
                            center: new google.maps.LatLng(data.map_center[0], data.map_center[1]),
                            drawingControl: false
                        });
                        var place_layer = new GLayer(gmap, {});
                        place_layer.loadParticipants(scope.places);
                        var polygon_layer = new GPolygonLayer(gmap, {});
                        polygon_layer.loadEncodedPolygons(scope.polygons, false, false);
                    });
                }
            }
        }
    ])
    .directive('overviewMap', [

        function() {
            return function(scope, elem, attrs) {
                var w = scope.$watch('tab_loaded', function(is_loaded) {
                    if (is_loaded) {
                        scope.safeApply(function() {
                            scope.gmap = new GMap2(elem.attr('id'), {
                                zoom: data.map_zoom ? data.map_zoom : 13,
                                center: new google.maps.LatLng(data.map_center[0], data.map_center[1]),
                                drawingControl: false
                            });
                        });
                        w();
                    }
                });
                var v = scope.$watch('places', function() {
                    if (scope.places !== null) {
                        scope.safeApply(function() {
                            scope.place_layer = new GLayer(scope.gmap, {});
                            scope.place_layer.loadParticipants(scope.places);
                        });
                        v();
                    }
                });
                var x = scope.$watch('polygons', function() {
                    if (scope.polygons !== null) {
                        scope.safeApply(function() {
                            scope.polygon_layer = new GPolygonLayer(scope.gmap, {});
                            scope.polygon_layer.loadEncodedPolygons(scope.polygons, false, false);
                        });
                        x();
                    }
                });
                var y = scope.$watchCollection('[places, seed_marker]', function() {
                    if (scope.seed_marker !== null && scope.place_layer !== null) {
                        scope.safeApply(function() {
                            scope.place_layer.loadSeedMarker(scope.seed_marker);
                        });
                        y();
                    }
                });
            }
        }
    ])
    .directive('flexSlider', ['$parse', '$timeout',
        function($parse, $timeout) {
            //https://github.com/EnthusiasticCode/angular-flexslider/
            return {
                restrict: 'AE',
                scope: false,
                replace: true,
                transclude: true,
                template: '<div class="flexslider-container"></div>',
                compile: function(element, attr, linker) {
                    var collectionString, flexsliderDiv, indexString, match, slidesItems, trackBy;

                    match = attr.slide.match(/^\s*(.+)\s+in\s+(.*?)(?:\s+track\s+by\s+(.+?))?\s*$/);
                    indexString = match[1];
                    collectionString = match[2];
                    trackBy = angular.isDefined(match[3]) ? $parse(match[3]) : $parse("" + indexString);
                    flexsliderDiv = null;
                    slidesItems = {};
                    return function($scope, $element) {
                        var addSlide, getTrackFromItem, removeSlide;

                        getTrackFromItem = function(collectionItem) {
                            var locals;

                            locals = {};
                            locals[indexString] = collectionItem;
                            return trackBy($scope, locals);
                        };
                        addSlide = function(collectionItem, index, callback) {
                            var childScope, track;

                            track = getTrackFromItem(collectionItem);
                            if (slidesItems[track] != null) {
                                throw "Duplicates in a repeater are not allowed. Use 'track by' expression to specify unique keys.";
                            }
                            childScope = $scope.$new();
                            childScope[indexString] = collectionItem;
                            childScope['$index'] = index;
                            return linker(childScope, function(clone) {
                                var slideItem;

                                slideItem = {
                                    collectionItem: collectionItem,
                                    childScope: childScope,
                                    element: clone
                                };
                                slidesItems[track] = slideItem;
                                return typeof callback === "function" ? callback(slideItem) : void 0;
                            });
                        };
                        removeSlide = function(collectionItem) {
                            var slideItem, track;

                            track = getTrackFromItem(collectionItem);
                            slideItem = slidesItems[track];
                            if (slideItem == null) {
                                return;
                            }
                            delete slidesItems[track];
                            slideItem.childScope.$destroy();
                            return slideItem;
                        };
                        return $scope.$watchCollection(collectionString, function(collection) {
                            var attrKey, attrVal, c, currentSlidesLength, e, i, idx, n, options, slider, slides, t, toAdd, toRemove, trackCollection, _i, _j, _k, _l, _len, _len1, _len2, _len3;

                            if (!(collection != null ? collection.length : void 0)) {
                                return;
                            }
                            if (flexsliderDiv != null) {
                                slider = flexsliderDiv.data('flexslider');
                                currentSlidesLength = Object.keys(slidesItems).length;
                                if (collection == null) {
                                    collection = [];
                                }
                                trackCollection = {};
                                for (_i = 0, _len = collection.length; _i < _len; _i++) {
                                    c = collection[_i];
                                    trackCollection[c] = getTrackFromItem(c);
                                }
                                toAdd = (function() {
                                    var _j, _len1, _results;

                                    _results = [];
                                    for (_j = 0, _len1 = collection.length; _j < _len1; _j++) {
                                        c = collection[_j];
                                        if (slidesItems[trackCollection[c]] == null) {
                                            _results.push(c);
                                        }
                                    }
                                    return _results;
                                })();
                                toRemove = (function() {
                                    var _results;

                                    _results = [];
                                    for (t in slidesItems) {
                                        i = slidesItems[t];
                                        if (trackCollection[t] == null) {
                                            _results.push(i.collectionItem);
                                        }
                                    }
                                    return _results;
                                })();
                                if ((toAdd.length === 1 && toRemove.length === 0) || toAdd.length === 0) {
                                    for (_j = 0, _len1 = toRemove.length; _j < _len1; _j++) {
                                        e = toRemove[_j];
                                        e = removeSlide(e);
                                        slider.removeSlide(e.element);
                                    }
                                    for (_k = 0, _len2 = toAdd.length; _k < _len2; _k++) {
                                        e = toAdd[_k];
                                        idx = collection.indexOf(e);
                                        addSlide(e, idx, function(item) {
                                            if (idx === currentSlidesLength) {
                                                idx = void 0;
                                            }
                                            return $scope.$evalAsync(function() {
                                                return slider.addSlide(item.element, idx);
                                            });
                                        });
                                    }
                                    return;
                                }
                            }
                            slidesItems = {};
                            if (flexsliderDiv != null) {
                                flexsliderDiv.remove();
                            }
                            slides = angular.element('<ul class="slides"></ul>');
                            flexsliderDiv = angular.element('<div class="flexslider"></div>');
                            flexsliderDiv.append(slides);
                            $element.append(flexsliderDiv);
                            for (i = _l = 0, _len3 = collection.length; _l < _len3; i = ++_l) {
                                c = collection[i];
                                addSlide(c, i, function(item) {
                                    return slides.append(item.element);
                                });
                            }
                            options = {};
                            for (attrKey in attr) {
                                attrVal = attr[attrKey];
                                if (attrKey.indexOf('$') === 0) {
                                    continue;
                                }
                                if (!isNaN(n = parseInt(attrVal))) {
                                    options[attrKey] = n;
                                    continue;
                                }
                                if (attrVal === 'false' || attrVal === 'true') {
                                    options[attrKey] = attrVal === 'true';
                                    continue;
                                }
                                if (attrKey === 'start' || attrKey === 'before' || attrKey === 'after' || attrKey === 'end' || attrKey === 'added' || attrKey === 'removed') {
                                    options[attrKey] = (function(attrVal) {
                                        var f;

                                        f = $parse(attrVal);
                                        return function() {
                                            return $scope.$apply(function() {
                                                return f($scope, {});
                                            });
                                        };
                                    })(attrVal);
                                    continue;
                                }
                                options[attrKey] = attrVal;
                            }
                            return $timeout((function() {
                                return flexsliderDiv.flexslider(options);
                            }), 0);
                        });
                    };
                }
            };
        }
    ])
    .directive('initNb', [

        function() {
            //For noticeboard comments
            return {
                link: function(scope, elem, attrs) {
                    scope.$watch('noticeboard', function(nv) {
                        if (nv !== null) {
                            $('.flexslider').flexslider({
                                randomize: false
                            });
                            $("a[rel='prettyPhoto']").prettyPhoto({
                                social_tools: false,
                                deeplinking: false
                            });
                        }
                    });
                }
            }
        }
    ])
    .directive('prettyPhoto', [

        function() {
            return function(scope, elem, attrs) {
                var watcher = scope.$watch('resources', function(nv, ov) {
                    if (nv !== null) {
                        elem.prettyPhoto({
                            social_tools: false,
                            deeplinking: false
                        });
                    }
                });
            }
        }
    ])
    .directive('addThisEvent', ['$timeout',
        function($timeout){
            return {
                templateUrl: '/static/apps/topic/partials/addthisevent.html',
                replace: false,
                link: function(scope, elem, attrs) {
                    var w = scope.$watch('evt', function(nv, ov){
                        if(nv !== null){
                            $timeout(function(){
                                addthisevent.refresh();
                                w();
                            }, 500, false);
                        }
                    });
                }
            }
        }
    ])
    .directive('togglePostType', [

        function() {
            return {
                link: function(scope, elem, attrs) {
                    attrs.$observe('postType', function(value) {
                        if (value == attrs.togglePostType) {
                            elem.slideDown();
                        } else {
                            elem.slideUp();
                        }
                    });
                }
            }
        }
    ])
    .directive('noticeboardRedactor', [

        function() {
            return {
                require: 'ngModel',
                link: function(scope, elem, attrs, ctrl) {
                    elem.redactor({
                        keyupCallback: function() {
                            scope.$apply(function() {
                                ctrl.$setViewValue(elem.getCode());
                            });
                        },
                        execCommandCallback: function() {
                            scope.$apply(function() {
                                ctrl.$setViewValue(elem.getCode());
                            });
                        },
                        buttons: [
                            'bold',
                            'italic',
                            'underline',
                            'deleted',
                            '|',
                            'link'
                        ]
                    })
                        .getEditor()
                        .addClass('wysiwyg-overides notranslate')
                        .height(100);
                    elem.setCode(ctrl.$viewValue);
                }
            }
        }
    ])
    .directive('nbPostImage', [

        function() {
            return {
                link: function(scope, elem, attrs) {
                    var upload_btn_text;
                    if (BrowserDetect.browser == 'Explorer') {
                        upload_btn_text = '<div>Add more images by clicking here.</div>';
                    } else {
                        upload_btn_text = '<div>Add more images by clicking or dropping files here.</div>';
                    }
                    var uploader = new qq.FileUploader({
                        element: elem[0],
                        action: '/assets/nb_image_upload/',
                        params: {
                            'topic': scope.topic
                        },
                        debug: false,
                        multiple: true,
                        maxConnections: 5,
                        allowedExtensions: ['jpeg', 'jpg', 'png', 'gif'],
                        sizeLimit: 10485760,
                        dragText: '<h4>Drop files here</h4>',
                        uploadButtonText: upload_btn_text,
                        onSubmit: function(id, fileName) {

                        },
                        showMessage: function(msg) {

                        },
                        onComplete: function(id, fileName, responseJSON) {
                            if (responseJSON.success) {
                                var new_image = responseJSON.data;
                                scope.safeApply(function() {
                                    scope.post_images.push(_.extend(new_image, {
                                        title: "",
                                        description: ""
                                    }));
                                });
                                $('.qq-upload-success').empty();
                            } else {
                                if (responseJSON.hasOwnProperty('reason') && responseJSON.reason === 'login_required') {
                                    redirect_to_login('/topic/' + data.topic + '/noticeboard/');
                                }
                            }
                        },
                        template: '<div class="qq-uploader">' +
                            '<div class="qq-upload-button" style="width: auto;">{uploadButtonText}</div>' +
                            '<div class="qq-upload-drop-area">{dragText}</div>' +
                            '<div class="list"><ul class="qq-upload-list" style="margin-top: 10px; text-align: center;"></ul></div>' +
                            '</div>',
                        fileTemplate: '<li>' +
                            '<span class="qq-upload-finished"></span>' +
                            '<span class="qq-upload-file"></span>' +
                            '<span class="qq-upload-size"></span>' +
                            '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
                            '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
                            '<span class="qq-upload-spinner"></span>' +
                            '<div class="qq-progress-bar"></div>' +
                            '<div class="clear_both"></div>' +
                            '</li>'
                    });
                }
            }
        }
    ])
    .directive('noticeboardPost', ["$compile", "$http", "$templateCache",
        function($compile, $http, $templateCache) {
            var textTemplateUrl = '/static/apps/topic/partials/nb_text_post.html';
            var imageTemplateUrl = '/static/apps/topic/partials/nb_image_post.html';
            var videoTemplateUrl = '/static/apps/topic/partials/nb_video_post.html';
            var getTemplate = function(post_type) {
                var templateUrl = '';
                switch (post_type) {
                    case 1:
                        templateUrl = textTemplateUrl;
                        break;
                    case 2:
                        templateUrl = imageTemplateUrl;
                        break;
                    case 3:
                        templateUrl = videoTemplateUrl;
                        break;
                }
                templateLoader = $http.get(templateUrl, {
                    cache: $templateCache
                });
                return templateLoader;
            };
            var linker = function(scope, elem, attrs) {
                var loader = getTemplate(scope.post.post_type);

                var promise = loader.success(function(html) {
                    elem.html(html);
                }).then(function(response) {
                    elem.html($compile(elem.html())(scope));
                });
            }
            return {
                restrict: "A",
                link: linker,
                scope: {
                    post: "="
                }
            }
        }
    ])
    .directive('polyStyle', ["$parse",
        function($parse) {
            return {
                link: function(scope, elem, attrs) {
                    var post = $parse(attrs.polyStyle)(scope);
                    if (post.display_name !== "Topic Administrator" && post.display_name !== "Topic Moderator") {
                        if (post.polygon_style !== null && angular.isDefined(post.polygon_style)) {
                            elem.css('background-color', post.polygon_style.fillColor);
                        }
                    }
                }
            }
        }
    ])
    .directive('polyLabel', ["$parse",
        function($parse) {
            return {
                link: function(scope, elem, attrs) {
                    var post = $parse(attrs.polyLabel)(scope);
                    if (post.display_name != "Topic Administrator" && post.display_name != "Topic Moderator") {
                        elem.text(post.polygon_label);
                    }
                }
            }
        }
    ])
    .directive('discussionQuestion', ["$parse",

        function($parse) {
            return {
                link: function(scope, elem, attrs) {
                    var content = $parse(attrs.discussionQuestion)(scope);
                    elem.html(content);
                }
            }
        }
    ])
    .filter('checkthumbnail', [

        function() {
            return function(image) {
                if (angular.isDefined(image.thumbnails) && image.thumbnails !== null) {
                    return image.thumbnails.url;
                }
                if (image) {
                    if (image.url) {
                        return image.url;
                    }
                }
                return "";
            };
        }
    ])
    .filter('toUTCMoment', [
        function() {
            return function(m) {
                return moment.utc(m);
            };
        }
    ])
    .filter('addHour', [
        function() {
            return function(m) {
                var nm = angular.copy(m);
                return nm.add(1, 'h');
            };
        }
    ]);