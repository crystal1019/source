#!/usr/bin/perl -w

use strict;
use URI::Escape;

#https://jokey.shareasale.com/a-downloadproducts-bulk.cfm?merchantID=11035&assignedID=0
# login: https://www.shareasale.com/a-login.cfm
# params are: username    password

# Our API token is 94Uv5QEtNrOQqp8a
# Our supersecret api token is 


my $host = 'https://www.shareasale.com';
my $cookie_jar = "cookie_jar.txt";
my $agent = '\'Mozilla/5.0 (Windows NT 5.1; rv:15.0) Gecko/20100101 Firefox/15.0.1\'';
my $curl_args = " --insecure " .
    "--cookie-jar $cookie_jar " .
    "--cookie $cookie_jar " . 
#   Used for reverse engineering
#    "--proxy 127.0.0.1:8888 " .
    "-L " .
    "-A $agent ";


my $username = 'tiff@roomhints.com';
my $password = 'monkey1';

sub execute_cmd {
    my $cmd = shift;

    print "****issuing " . $cmd  . "\n";
    system ( $cmd );
}


my $cmd = 'curl ' . $curl_args . $host . '/a-login.cfm -d username=' . $username . ' -d password=' . $password . ' -d step2=True -d hearing=checklist -d ding=metalwork -d jq1=1 -d express=affiliate > shareasale.login.html';
execute_cmd($cmd);

sleep 5;

$cmd = 'curl ' . $curl_args . ' https://jokey.shareasale.com/a-downloadproducts-bulk.cfm?merchantID=11035&assignedID=0 > shareasale.download.html';
execute_cmd($cmd);

sleep 5;

$cmd = 'curl ' . $curl_args . $host . '/a-logoff.cfm > shareasale.logoff.html';
execute_cmd($cmd);
