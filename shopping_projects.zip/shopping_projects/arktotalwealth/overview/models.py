from django.db import models
from arktotalwealth.component.models import *
# Create your models here.

class OverviewPage(models.Model):
    parent = models.ForeignKey('self',blank=True,null=True)
    title = models.CharField(max_length=255,unique=True)
    slug = models.SlugField(unique=True)
    image = models.ImageField(upload_to='images/',blank=True,null=True,help_text='section header image, width:764')    
    tooltip = models.TextField(blank=True, null=True, help_text='this is the tooltip description which will be shown in service navigation landing page')
    tooltip_class_name = models.CharField(max_length=255, null=True, blank=True, help_text='this is the class name to control the position of the tooltip in Service Navigation Landing Page, only pages with this image uploaded and with a class name will be treated as tooltip in the service landing page')
    tooltip_image = models.ImageField(upload_to='images/', blank=True,null=True, help_text='if this page has tooltip image on service navigation landing page, please upload the tooltip image here, only pages with this image uploaded and with a class name will be treated as tooltip in the service landing page, please have a corresponding class to position this image in css')
    short_description = models.TextField(blank=True,null=True,help_text="this is the short description displayed on landing page")
    content = models.TextField(blank=True,null=True)
    priority = models.IntegerField(default=0)
    active = models.BooleanField("is active ?",default=False)
    landingpage = models.BooleanField("is landing page ?",default=False)
    landing_tooltip = models.BooleanField('is landing page with tooltip ?', default=False)
    no_left_nav = models.BooleanField(default=False)
    hidden_h = models.CharField('Hidden H1',max_length=255, blank=True, null=True)
    meta_keywords = models.CharField(max_length=255, blank=True,null=True ,help_text="max length 255 characters, please separate it by ','")
    meta_description = models.TextField(blank=True,null=True)
    action_links = models.ManyToManyField(ActionLink, blank=True,null=True)
    
    def __unicode__(self):
        return str(self.parent) + ' --> ' + self.title if self.parent else self.title
        
    def get_absolute_url(self):
        return '/overview/%s.html' %self.slug if self.parent else '/overview/'

    def get_current_nav(self):
        return 'overview'
    
    def get_children(self):
        return self.overviewpage_set.filter(active=True)
    
    def is_tooltip(self):
        return True if self.tooltip_image and self.tooltip_class_name else False
    
        
    class Meta:
        ordering = ['parent__id','-priority']