$(document).ready(function(){
	var elems = $('input[id$="page_title"]');
	for (var i = 0; i < elems.length; i++) {
	    Countable.live(elems[i], function (counter) {
		  $(this.nextElementSibling).text('Total words: ' + counter.words);
		});
	};
	var elems = $('input[id$="page_description"]');
	for (var i = 0; i < elems.length; i++) {
	    Countable.live(elems[i], function (counter) {
		  $(this.nextElementSibling).text('Total words: ' + counter.words);
		});
	};
	var elems = $('#id_description, textarea[id$="offer_description"], textarea[id$="category_description"]');
	for (var i = 0; i < elems.length; i++) {
	    Countable.live(elems[i], function (counter) {
		  $(this.nextElementSibling).text('Total words: ' + counter.words);
		});
	};
	var elems = $('textarea[id$="table_description"]');
	for (var i = 0; i < elems.length; i++) {
	    Countable.live(elems[i], function (counter) {
		  $(this.nextElementSibling).text('Total words: ' + counter.words);
		});
	};
});
