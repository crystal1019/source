var twitter_interval_id = -1;

function startTwitterRefresh( topic ) {
    // Refresh every 30 seconds
    loadTwitterTicker(topic);
    twitter_interval_id = setInterval(function(){ loadTwitterTicker(topic); }, 30000);
}

function loadTwitterTicker(topic) {
    $.ajax({
        url: '/topic/twitter_parameters/',
        type: 'POST',
        data: {
            'topic': topic,
            'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
        },
        success: function(obj) {
            var tweet_parameters = obj.data.tweet_parameters;
            initTwitterTicker(tweet_parameters, topic);
            if (tweet_parameters.length > 0) {
                //$('#twitter-section-container').show();
                $('#tweet-container').slideDown('slow');
            }
            else{
                //$('#twitter-section-container').hide();
                $('#tweet-container').slideUp('slow');  
                clearInterval(twitter_interval_id);
            }
        },
        error: function() {

        }
    });
}

function initTwitterTicker(tweetParameters, topic) {
    var buildString = '';
    var arrQuery = [];
    for(var i=0; i < tweetParameters.length; i++) {
        arrQuery.push(tweetParameters[i].replace('#', '%23').replace('@','%40'));
    }
    buildString = arrQuery.join('%20OR%20')
    
    $('#twitter-source').remove();
    var fileref = document.createElement('script');
    fileref.setAttribute("type","text/javascript");
    fileref.setAttribute("id","twitter-source");
    fileref.setAttribute("src", "https://search.twitter.com/search.json?q="+buildString+"&callback=TweetTick&rpp=50");
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function TweetTick(ob) {
    var container = $('#tweet-container');
    container.html('');
    
    $(ob.results).each(function(el){
    
        var str = ' <div class="tweet">\
                    <div class="avatar"><a href="https://twitter.com/'+this.from_user+'" target="_blank"><img src="'+this.profile_image_url+'" alt="'+this.from_user+'" /></a></div>\
                    <div class="user"><a href="https://twitter.com/'+this.from_user+'" target="_blank">'+this.from_user+'</a></div>\
                    <div class="time">'+relativeTime(this.created_at)+'</div>\
                    <div class="txt">'+formatTwitString(this.text)+'</div>\
                    </div>';
        
        container.append(str);
    
    });
}

function formatTwitString(str)
{
    str=' '+str;
    str = str.replace(/((ftp|https?):\/\/([-\w\.]+)+(:\d+)?(\/([\w/_\.]*(\?\S+)?)?)?)/gm,'<a href="$1" target="_blank">$1</a>');
    str = str.replace(/([^\w])\@([\w\-]+)/gm,'$1@<a href="https://twitter.com/$2" target="_blank">$2</a>');
    str = str.replace(/([^\w])\#([\w\-]+)/gm,'$1<a href="https://twitter.com/search?q=%23$2" target="_blank">#$2</a>');
    return str;
}

function relativeTime(pastTime)
{   
    var origStamp = Date.parse(pastTime);
    var curDate = new Date();
    var currentStamp = curDate.getTime();
    
    var difference = parseInt((currentStamp - origStamp)/1000);

    if(difference < 0) return false;

    if(difference <= 5)             return "Just now";
    if(difference <= 20)            return "Seconds ago";
    if(difference <= 60)            return "A minute ago";
    if(difference < 3600)           return parseInt(difference/60)+" minutes ago";
    if(difference <= 1.5*3600)      return "One hour ago";
    if(difference < 23.5*3600)      return Math.round(difference/3600)+" hours ago";
    if(difference < 1.5*24*3600)    return "One day ago";
    
    var dateArr = pastTime.split(' ');
    return dateArr[4].replace(/\:\d+$/,'')+' '+dateArr[2]+' '+dateArr[1]+(dateArr[3]!=curDate.getFullYear()?' '+dateArr[3]:'');
}

function twitterTickerEditor(topic) {
    $.ajax({
        url: '/topic/twitter-editor/',
        type: 'POST',
        data: {
            'topic': topic,
            'csrfmiddlewaretoken': document.getElementsByName('csrfmiddlewaretoken')[0].value
        },
        success: function(obj) {
            $('#editor-loader').show();
            $(obj).prependTo('body').modal({
                show: true,
                backdrop: true,
                keyboard: true
            }).on('hidden', function() { // Remove markup when closed.
                $(this).off('hidden'); // Not sure if this is needed.
                $('#btn_editor_save').unbind('click');
                $(this).remove();   
            });
            
            /* SAVE BUTTON */
            $('#btn_editor_save').click(function() {
                $('#editor-loader').show();
                saveTwitterTickerEditor();
            });

        },
        error: function() {

        }
    });
}

function deleteParameter(anchor) {
    $(anchor).parent().remove();
}

function addNewTwitterParameter() {
    template = '<div class="twitter-parameter"> \
                    <a class="close delete-parameter" onclick="deleteParameter(this);">×</a> \
                    <div class="input-wrapper"><input placeholder="New twitter search parameter..." maxlength="255" type="text" value="" name="parameter" /></div> \
                </div>';
    $('#form-editor-twitter .twitter-parameter-container').append(template);
}

function saveTwitterTickerEditor(){
    $('#form-editor-twitter').find('.error').text('');
    $('#form-editor-twitter').ajaxSubmit( {
        success: function(obj) {
            clearInterval(twitter_interval_id);
            $('#modal-editor-dialog').modal('hide');    
            $('#twitter-container').empty();
            $('#twitter-container').append(obj);
            startTwitterRefresh($('#topic_id').val());
        },
        error: function(err) {
            
        },
        complete: function() {
            $('#editor-loader').hide();
        }

    });
}