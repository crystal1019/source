angular.module('ProfileMenuApp', [
    'menu.controllers',
    'menu.directives',
    'ngSanitize'
]);