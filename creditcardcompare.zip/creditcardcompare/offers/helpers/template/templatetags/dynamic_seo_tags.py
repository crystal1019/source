import re
from django import template
from django.template.defaultfilters import striptags
from django_markwhat.templatetags.markup import textile

register = template.Library()

class ApplySEOMetadataNode(template.Node):
    def __init__(self, offer, field_name, varname=None):
        self.offer = template.Variable(offer)
        self.field_name = field_name
        self.varname = varname

    def render(self, context):
        try:
            offer = self.offer.resolve(context)
        except template.VariableDoesNotExist:
            return ''
        try:
            content = getattr(offer, self.field_name).replace('Balance Transfer Rate Period',
                                                              'Balance Transfer Period')
        except AttributeError:
            try:
                content = template.Variable(self.field_name).resolve(context)
            except template.VariableDoesNotExist:
                return ''
        metadata = offer.get_metadata_dict()
        for _id in re.findall('%\([A-z ()/]+:(\d+)\)s', content):
            try:
                o = offer.__class__.objects.get(id=_id)
            except offer.__class__.DoesNotExist:
                continue
            metadata.update(o.get_metadata_dict(_id))
        try:
            content = textile(striptags(content % metadata))
        except (KeyError, ValueError):
            content = textile(striptags(content))
        except TypeError:
            # escape percent (%) character
            content = re.sub(r'([^%]%)([^(%]|$)', r'\g<1>%\g<2>', content) if content else ''
            try:
                content = textile(striptags(content % metadata))
            except (KeyError, ValueError):
                content = content.replace('%%', '%')
                content = textile(striptags(content))
        if self.varname:
            context[self.varname] = content
            return ''
        else:
            return content


@register.tag(name='apply_seo_metadata')
def do_apply_seo_metadata(parser, token):
    parts = token.split_contents()
    if len(parts) not in (3,5):
        raise template.TemplateSyntaxError, '%r tag requires exactly three arguments' % token.split_contents()[0]
    if 'as' in parts:
        return ApplySEOMetadataNode(parts[1], parts[2], varname=parts[4])
    return ApplySEOMetadataNode(parts[1], parts[2])
