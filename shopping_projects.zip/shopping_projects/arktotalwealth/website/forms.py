from django import forms
from django.forms import Form, ModelForm
from arktotalwealth.website.models import *

class EnquiryForm(ModelForm):
    class Meta:
        model = Enquiry
        
    def __init__(self,*args,**kwargs):
        super(EnquiryForm,self).__init__(*args,**kwargs)
        self.fields['interest'] = forms.ModelChoiceField(queryset=Interest.objects.filter(place = 'enquiry'), empty_label="Please select an interest")
        self.fields['first_name'].error_messages = {'required':'Please enter your First Name'}
        self.fields['surname'].error_messages = {'required':'Please enter your Surname'}
        self.fields['email'].error_messages = {'required':'Please use a valid email address'}
        self.fields['phone'].error_messages = {'required':'Please enter your Contact Phone Number'}
        self.fields['interest'].error_messages = {'required':'Please select an interest'}
        self.fields['comments'].error_messages = {'required':'Please enter your comments'}
        self.fields['subscribed'].widget = forms.CheckboxInput(attrs={'checked':'checked'})


class MessageForm(ModelForm):
    class Meta:
        model = Enquiry
    email2 = forms.EmailField()
    
        
    def __init__(self, *args, **kwargs):
        super(MessageForm,self).__init__(*args, **kwargs)
        self.fields['interest'].required = False
        self.fields['first_name'].error_messages = {'required':'Please enter your First Name'}
        self.fields['surname'].error_messages = {'required':'Please enter your Last Name'}
        self.fields['email'].error_messages = {'required':'Please use a valid email address'}
        self.fields['email2'].error_messages = {'required':'Please use a valid email address'}
        self.fields['comments'].error_messages = {'required':'Please enter your messages'}
        self.fields['phone'].error_messages = {'required':'Please enter your Contact Phone Number'}
        
    def clean_email2(self):
        if self.cleaned_data['email'] and self.cleaned_data['email2'] and self.cleaned_data['email'] != self.cleaned_data['email2']:
            raise forms.ValidationError('Email addresses not match')
        
        return self.cleaned_data['email2']
    