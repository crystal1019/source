import json
import logging
import re
from bs4 import BeautifulSoup
from urlparse import urljoin
from django.template.defaultfilters import strip_tags
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions


logger = logging.getLogger('scraper')


class MacysScraper(BaseScraper):
    base_image_url = 'http://slimages.macys.com/is/image/MCY/products/'

    @staticmethod
    def get_domain():
        return 'macys.com'

    # def fetch_url(self):
    #     with open('test_data/macys/lancome.html', 'r') as f:
    #         self.html = f.read()

    def extract_sku(self, val):
        m = re.search(r'\d+', val)
        if m is not None:
            return m.group(0)

    def extract_image_url(self, url):
        return re.sub(r'\?.*', '', url)

    def extract_price(self, val):
        for char in (',', '$'):
            val = val.replace(char, '')
        return float(strip_tags(val))

    def humanize_latch(self, latch):
        return latch.replace('_', ' ')

    def parse_single_product(self, soup, raw_data):
        # SKU
        try:
            sku = soup.find('input', attrs={'id': 'productId'})['value']
            logging.debug('Extracted SKU')
        except (KeyError, TypeError), e:
            logging.debug('Was not able to extract SKU: %s' % e.message)
            return

        # Product variants
        variants = []
        m = re.search(r'MACYS.pdp.upcmap\["%s"\] = (.*)\;' % sku, self.html)
        if m is not None:
            variants = json.loads(m.group(1).decode('utf-8', 'ignore').encode('utf-8'))

        # Product images
        images = []
        m = re.search(r'MACYS.pdp.primaryImages\[%s\] = (.*)\;' % sku, self.html)
        if m is not None:
            images = json.loads(m.group(1))

        title = soup.find('h1', attrs={'itemprop': 'name'})
        if title is None:
            logger.debug('Not able to extract title, moving to multi-product')
            return None
        title = title.text

        price = soup.find('meta', attrs={'itemprop': 'price'})
        if price is not None:
            price = self.extract_price(str(price['content']))
        image = raw_data['image']

        selections = []
        for variant in variants:
            try:
                image = urljoin(self.base_image_url, images[variant['color']])
            except KeyError:
                pass

            data = {
                'title': title,
                'current_price': {
                    'value': price
                },
                'url': raw_data['url'],
                'store': raw_data['site_name'].lower(),
                'image': image,
                'local_id': sku,
                'selections': {
                    'size': variant['size'],
                    'color': variant['color']
                },
                'promos':[]
            }
            selections.append(data)

        return selections

    def extract_promo_code(self, promo):
        m = re.search(r'CODE: (\w+)', promo, re.IGNORECASE)
        if m is not None:
            return m.group(1)
        return ''

    def parse_multi_product(self, soup, raw_data):
        # Latch (size, etc.)
        latch = soup.find('div', attrs={'class': 'latchName'})
        if latch is not None:
            latch = latch.text.strip().lower()[:-1]
        latches = [li['id'] for li in soup.find_all('li', class_='latch') if li is not None]

        prices = [self.extract_price(str(price)) for price in soup.find_all('div', attrs={'class': 'productPrice'}) if price is not None]
        paid_products = [self.extract_sku(product['id']) for product in soup.find_all('div', id=re.compile(r'^member\d+$'))]
        products = dict()

        for sku, product in re.findall(r'MACYS.pdp.upcmap\["(\d+)"\] = (.*)\;', self.html):
            # We filter gifts here
            if sku in paid_products:
                products[sku] = json.loads(product)

        promos = []
        raw_promos = soup.find('span', id='jsonObjBadge')
        if raw_promos is not None:
            raw_promos = json.loads(raw_promos.text)
            for promo in raw_promos:
                for key, content in promo.items():
                    code = self.extract_promo_code(content['DESCRIPTION'])

                    promos.append(dict(
                        text='%s: %s' % (content['HEADER'], content['DESCRIPTION']),
                        code=code,
                        flag='review' if code else ''
                    ))

        i = 0
        selections = []
        for sku, variants in products.items():
            for variant in variants:
                container = soup.find('div', id=re.compile(r'^member%s$' % sku))
                if container is not None:
                    title = container.find('div', attrs={'id': 'prodName'}).text
                    image = self.extract_image_url(container.find('img', attrs={'id': re.compile(r'^%s_memberImg$' % sku)})['src'])
                    price = self.extract_price(str(container.find('div', attrs={'class': 'productPrice'})))

                    data = {
                        'title': title,
                        'current_price': {
                            'value': price
                        },
                        'url': raw_data['url'],
                        'store': raw_data['site_name'].lower(),
                        'image': image,
                        'local_id': sku,
                        'selections': {
                            'size': '',
                            'color': variant['color']
                        },
                        'promos': promos
                    }

                    # We have to create color-size combinations this way
                    added = False
                    for klass in container['class']:
                        if klass in latches:
                            data['selections'][latch] = self.humanize_latch(klass)
                            selections.append(data)
                            added = True

                    if not added:
                        selections.append(data)
                else:
                    data = {
                        'title': title,
                        'current_price': {
                            'value': prices[i]
                        },
                        'url': raw_data['url'],
                        'store': raw_data['site_name'].lower(),
                        'image': image,
                        'local_id': sku,
                        'selections': {
                            latch: variant['size'],
                            'color': variant['color']
                        },
                        'promos': promos
                    }

                    selections.append(data)
            i += 1

        return selections

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        # Try to parse a single-product variant first
        selections = self.parse_single_product(soup, raw_data)

        # We assume it's a multi-product item
        if selections is None or not len(selections):
            selections = self.parse_multi_product(soup, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(MacysScraper.get_domain(), self.url)

        return selections
