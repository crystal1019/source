import masterpage

import method_db
import method_question
	
class BulkQuestionEdit(masterpage.MasterPage):
	def post(self):
		t = self.request.get('ids')
		value = int(self.request.get('id'))
		ids = t.split(' ')
		count = 0
		for id in ids:
			val = int(id)
			question = method_question.getQuestionWithId(val)
			question.topics.append(value)
			method_db.putObject(question)
			count = count + 1
		self.response.out.write(str(count) + " questions updated")
	
	def get(self):
		self.pushPage({}, 'Update Questions', 'html/bulkquestionedit.html')	  
		
