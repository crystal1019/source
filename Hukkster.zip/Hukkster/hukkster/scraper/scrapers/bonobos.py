import logging
import re
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions
import leaf # see reqirements.txt, leaf==0.4.4

# 3 in 1 combo
#http://www.bonobos.com/wedding-standout

# simple
#http://www.bonobos.com/khaki-straight-leg-pants-for-men-the-khakis

#sold out, no sizes
#http://www.bonobos.com/lebronze

logger = logging.getLogger('scraper')

# bonobos
class BonobosScraper(BaseScraper):

    @staticmethod
    def get_domain():
        return 'bonobos.com'

    #def fetch_url(self):
    #   with open('test_data/bonobos/check.html', 'r') as f:
    #      self.html = f.read()

    def get_item_image(self, doc):
        '''
        Getting images list from single product and multi product item,
        it's the same, because there is no way to identify single product
        '''
        #images = list()
        #for img in doc('a.more-views-thumbs'):
        #    images.append(img.element.attrib['href'])

        # Get only one image
        image = doc.get('a.more-views-thumbs')
        if image and image.element.attrib['href']:
            return image.element.attrib['href']
        else:
            return None

    def parse_multi_product(self, raw_data, doc):
        '''
        Parse the multi produce combo
        '''
        data = list()

        titles = iter(doc('dt label'))
        for item in doc('select.bundle-option-select'):
            item = leaf.parse(item.html())

            # get local_id from select
            reg = re.search('\[(\d+)\]', item.element.attrib['name'])
            if reg:
                local_id = reg.group(1)
            else:
                local_id = False

            sizes = list()
            # getting sizes of item
            for opt in item('option'):
                if opt.text != 'Choose a selection...':
                    sizes.append(opt.text)

            # title = 'title' + '$price'
            title = titles.next().text.split('$')
            price = float(re.sub(r'[^\d\.]', '', title[1]))
            title = title[0].strip()


            for size in sizes:
                data.append({'selections': {'size': size},
                            'title': title,
                            'current_price': {'value': price},
                            'url': raw_data['url'],
                            'store': 'bonobos',
                            'image': self.get_item_image(doc),
                            'local_id': local_id})
            if not sizes:
                data.append({'selections': [],
                            'title': title,
                            'current_price': {'value': price},
                            'url': raw_data['url'],
                            'store': 'bonobos',
                            'image': self.get_item_image(doc),
                            'local_id': local_id})

        return data

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')

        logging.debug('Finished parsing HTML data')

        data = dict()
        doc = leaf.parse(self.html)

        if 'new Product.Bundle' in self.html:
            data = self.parse_multi_product(raw_data, doc)
            return data

        # Is product out of stock
        tag = doc.get('p.link-stock-alert')
        if tag:
            return []


        # Product Store Code 
        data['store'] = 'bonobos'

        # Product Unique ID -->
        # "productId":"(\d+)" (because next fields: childProducts)
        reg = re.search(r'"productId"\:"(\d+)"', self.html)
        if reg:
            data['local_id'] = reg.group(1)
        else:
            return []


        # Product Title
        tag = doc.get('div.product-name h1')
        if tag:
            data['title'] = tag.text.strip()
        else:
            return []

        # Product Current Price
        # getting the current price
        tag = doc.get('div.price-box span.price')
        if tag:
            if tag.text:
                data['current_price'] = {
                     'value':float(re.sub(r'[^\d\.]', '', tag.text.strip()))}
            else:
                tag = doc.get('div.price-box span.price span.price')
                if tag:
                    data['current_price'] = {
                     'value': float(re.sub(r'[^\d\.]', '', tag.text.strip()))}
        else:
            return None

        tag = doc.get('div.price-box span.old-price')
        if tag:
            data['original_price'] = {
                     'value': float(re.sub(r'[^\d\.]', '', tag.text.strip()))}


        # Color doesn't present - separated item for each color at this shop

        # Product Image(s)
        data['images'] = self.get_item_images(doc)

        # URL
        if raw_data['url']:
            data['url'] = raw_data['url']

        # Product Size(s)
        sizes = re.findall(r'"label"\:"(\w+)",\"oldPrice"\:"\w+","products"\:\["\w+"\],"in_stock"\:(\w+)', self.html)
        data['selections'] = list()

        items = list()
        for size in sizes:
            if size[1] == 'true':
                item = data.copy()
                item['selections'] = {'size': size[0]}
                items.append(item)

        if not sizes:
            return [data]

        return items
