
-- REPORTING / BI

CREATE VIEW vw_transactions_type AS
SELECT
0 as checkin_trans,
1 as buy_trans,
2 as share_trans,
3 as rescue_trans,
9 as cancel_trans;

ALTER TABLE users add last_login timestamp ;
ALTER TABLE retailers add formula text;
ALTER TABLE brands add formula text;