var COUNTRY_CODES = {
    'CA': 'Canada',
    'US': 'United States of America',
    'AD': 'Andorra',
    'AF': 'Afghanistan',
    'AG': 'Antigua & Barbuda',
    'AI': 'Anguilla',
    'AL': 'Albania',
    'AM': 'Armenia',
    'AN': 'Netherlands Antilles',
    'AO': 'Angola',
    'AQ': 'Antarctica',
    'AR': 'Argentina',
    'AS': 'American Samoa',
    'AT': 'Austria',
    'AU': 'Australia',
    'AW': 'Aruba',
    'AZ': 'Azerbaijan',
    'BA': 'Bosnia and Herzegovina',
    'BB': 'Barbados',
    'BD': 'Bangladesh',
    'BE': 'Belgium',
    'BF': 'Burkina Faso',
    'BG': 'Bulgaria',
    'BH': 'Bahrain',
    'BI': 'Burundi',
    'BJ': 'Benin',
    'BM': 'Bermuda',
    'BN': 'Brunei Darussalam',
    'BO': 'Bolivia',
    'BR': 'Brazil',
    'BS': 'Bahama',
    'BT': 'Bhutan',
    'BV': 'Bouvet Island',
    'BW': 'Botswana',
    'BY': 'Belarus',
    'BZ': 'Belize',
    'CC': 'Cocos Keeling) Islands',
    'CF': 'Central African Republic',
    'CG': 'Congo',
    'CH': 'Switzerland',
    'CI': 'Ivory Coast',
    'CK': 'Cook Iislands',
    'CL': 'Chile',
    'CM': 'Cameroon',
    'CN': 'China',
    'CO': 'Colombia',
    'CR': 'Costa Rica',
    'CU': 'Cuba',
    'CV': 'Cape Verde',
    'CX': 'Christmas Island',
    'CY': 'Cyprus',
    'CZ': 'Czech Republic',
    'DE': 'Germany',
    'DJ': 'Djibouti',
    'DK': 'Denmark',
    'DM': 'Dominica',
    'DO': 'Dominican Republic',
    'DZ': 'Algeria',
    'EC': 'Ecuador',
    'EE': 'Estonia',
    'EG': 'Egypt',
    'EH': 'Western Sahara',
    'ER': 'Eritrea',
    'ES': 'Spain',
    'ET': 'Ethiopia',
    'FI': 'Finland',
    'FJ': 'Fiji',
    'FK': 'Falkland Islands Malvinas)',
    'FM': 'Micronesia',
    'FO': 'Faroe Islands',
    'FR': 'France',
    'FX': 'France, Metropolitan',
    'GA': 'Gabon',
    'GD': 'Grenada',
    'GE': 'Georgia',
    'GF': 'French Guiana',
    'GH': 'Ghana',
    'GI': 'Gibraltar',
    'GL': 'Greenland',
    'GM': 'Gambia',
    'GN': 'Guinea',
    'GP': 'Guadeloupe',
    'GQ': 'Equatorial Guinea',
    'GR': 'Greece',
    'GS': 'South Georgia and the South Sandwich Islands',
    'GT': 'Guatemala',
    'GU': 'Guam',
    'GW': 'Guinea-Bissau',
    'GY': 'Guyana',
    'HK': 'Hong Kong',
    'HM': 'Heard & McDonald Islands',
    'HN': 'Honduras',
    'HR': 'Croatia',
    'HT': 'Haiti',
    'HU': 'Hungary',
    'ID': 'Indonesia',
    'IE': 'Ireland',
    'IL': 'Israel',
    'IN': 'India',
    'IO': 'British Indian Ocean Territory',
    'IQ': 'Iraq',
    'IR': 'Islamic Republic of Iran',
    'IS': 'Iceland',
    'IT': 'Italy',
    'JM': 'Jamaica',
    'JO': 'Jordan',
    'JP': 'Japan',
    'KE': 'Kenya',
    'KG': 'Kyrgyzstan',
    'KH': 'Cambodia',
    'KI': 'Kiribati',
    'KM': 'Comoros',
    'KN': 'St. Kitts and Nevis',
    'KP': 'Korea, Democratic People\'s Republic of',
    'KR': 'Korea, Republic of',
    'KW': 'Kuwait',
    'KY': 'Cayman Islands',
    'KZ': 'Kazakhstan',
    'LA': 'Lao People\'s Democratic Republic',
    'LB': 'Lebanon',
    'LC': 'Saint Lucia',
    'LI': 'Liechtenstein',
    'LK': 'Sri Lanka',
    'LR': 'Liberia',
    'LS': 'Lesotho',
    'LT': 'Lithuania',
    'LU': 'Luxembourg',
    'LV': 'Latvia',
    'LY': 'Libyan Arab Jamahiriya',
    'MA': 'Morocco',
    'MC': 'Monaco',
    'MD': 'Moldova, Republic of',
    'MG': 'Madagascar',
    'MH': 'Marshall Islands',
    'ML': 'Mali',
    'MN': 'Mongolia',
    'MM': 'Myanmar',
    'MO': 'Macau',
    'MP': 'Northern Mariana Islands',
    'MQ': 'Martinique',
    'MR': 'Mauritania',
    'MS': 'Monserrat',
    'MT': 'Malta',
    'MU': 'Mauritius',
    'MV': 'Maldives',
    'MW': 'Malawi',
    'MX': 'Mexico',
    'MY': 'Malaysia',
    'MZ': 'Mozambique',
    'NA': 'Namibia',
    'NC': 'New Caledonia',
    'NE': 'Niger',
    'NF': 'Norfolk Island',
    'NG': 'Nigeria',
    'NI': 'Nicaragua',
    'NL': 'Netherlands',
    'NO': 'Norway',
    'NP': 'Nepal',
    'NR': 'Nauru',
    'NU': 'Niue',
    'NZ': 'New Zealand',
    'OM': 'Oman',
    'PA': 'Panama',
    'PE': 'Peru',
    'PF': 'French Polynesia',
    'PG': 'Papua New Guinea',
    'PH': 'Philippines',
    'PK': 'Pakistan',
    'PL': 'Poland',
    'PM': 'St. Pierre & Miquelon',
    'PN': 'Pitcairn',
    'PR': 'Puerto Rico',
    'PT': 'Portugal',
    'PW': 'Palau',
    'PY': 'Paraguay',
    'QA': 'Qatar',
    'RE': 'Reunion',
    'RO': 'Romania',
    'RU': 'Russian Federation',
    'RW': 'Rwanda',
    'SA': 'Saudi Arabia',
    'SB': 'Solomon Islands',
    'SC': 'Seychelles',
    'SD': 'Sudan',
    'SE': 'Sweden',
    'SG': 'Singapore',
    'SH': 'St. Helena',
    'SI': 'Slovenia',
    'SJ': 'Svalbard & Jan Mayen Islands',
    'SK': 'Slovakia',
    'SL': 'Sierra Leone',
    'SM': 'San Marino',
    'SN': 'Senegal',
    'SO': 'Somalia',
    'SR': 'Suriname',
    'ST': 'Sao Tome & Principe',
    'SV': 'El Salvador',
    'SY': 'Syrian Arab Republic',
    'SZ': 'Swaziland',
    'TC': 'Turks & Caicos Islands',
    'TD': 'Chad',
    'TF': 'French Southern Territories',
    'TG': 'Togo',
    'TH': 'Thailand',
    'TJ': 'Tajikistan',
    'TK': 'Tokelau',
    'TM': 'Turkmenistan',
    'TN': 'Tunisia',
    'TO': 'Tonga',
    'TP': 'East Timor',
    'TR': 'Turkey',
    'TT': 'Trinidad & Tobago',
    'TV': 'Tuvalu',
    'TW': 'Taiwan, Province of China',
    'TZ': 'Tanzania, United Republic of',
    'UA': 'Ukraine',
    'UG': 'Uganda',
    'AE': 'United Arab Emirates',
    'UK': 'United Kingdom',
    'UM': 'United States Minor Outlying Islands',
    'UY': 'Uruguay',
    'UZ': 'Uzbekistan',
    'VA': 'Vatican City State Holy See)',
    'VC': 'St. Vincent & the Grenadines',
    'VE': 'Venezuela',
    'VG': 'British Virgin Islands',
    'VI': 'United States Virgin Islands',
    'VN': 'Viet Nam',
    'VU': 'Vanuatu',
    'WF': 'Wallis & Futuna Islands',
    'WS': 'Samoa',
    'YE': 'Yemen',
    'YT': 'Mayotte',
    'YU': 'Yugoslavia',
    'ZA': 'South Africa',
    'ZM': 'Zambia',
    'ZR': 'Zaire',
    'ZW': 'Zimbabwe',
    'ZZ': 'Unknown'
}

/*jshint smarttabs:true */

/*
    search_string: Can be an address (123 elm street, Kamloops, BC) or latitude longitude ('50.356, -120.544504')
    successcallback: Function to call if successful
    errcallback: Function to call if not successful or error
    completecallback: Function to call after ajax complete.
*/
function geocode(search_string, successcallback, errcallback, completecallback) {
    $.ajax({
        url: '/spatial/geocode/',
        method: 'get',
        data: {
            'address': search_string
        },
        success: function(obj) {
            if ( obj.success ) {
                successcallback(obj.data);
            }
            else {
                if ( errcallback ) {
                    errcallback(obj.message[0]);
                }
            }
        },
        error: function(err){
            if ( errcallback ) {
                errcallback('Problem locating your location.');
            }
        },
        complete: function() {
            if ( completecallback ) {
                completecallback();
            }
        }
    });
}

/*
    Use mapquest to geocode
    
    search_string: Can be an address (123 elm street, Kamloops, BC) or latitude longitude ('50.356, -120.544504')
    successcallback: Function to call if successful
    errcallback: Function to call if not successful or error
    completecallback: Function to call after ajax complete.
*/
function geocode_mq(search_string, successcallback, errcallback, completecallback) {
    $.ajax({
        url: '/spatial/geocode_mq/',
        method: 'get',
        data: {
            'address': search_string
        },
        success: function(obj) {
            if ( obj.success ) {
                successcallback(obj.data);
            }
            else {
                if ( errcallback ) {
                    errcallback(obj.message[0]);
                }
            }
        },
        error: function(err){
            if ( errcallback ) {
                errcallback('Problem locating your location.');
            }
        },
        complete: function() {
            if ( completecallback ) {
                completecallback();
            }
        }
    });
}

/*
    callback: Callback to call if a position was found. (parameters: position)
        -> Position object returned
            coords: Coords object breaks down into...
                latitude
                longitude
                altitude (not always available)
                accuracy
                altitudeAccuracy (not always available)
                heading (not always available)
                speed  (not always available)
            timestamp: DOMTimeStamp

                What can you do with this?
                var d = new Date(domTimeStamp);

                Other formats:
                    Date.toDateString()
                    Date.toLocaleDateString()
                    Date.toLocaleTimeString()
                    Date.toString()
                    Date.toTimeString()
                    Date.toUTCString()

    errcallback: (optional) Function to call if no position was retrieved.
        -> Error object returned.
            code: (1, 2, 3)
                1) PERMISSION_DENIED
                2) POSITION_UNAVAILABLE
                3) TIMEOUT
            message: Error message (for developers)

    options: (optional) Options to pass to the getCurrentPosition f(x)
        -> Defaults to:
            {
                maximumAge        : null,
                timeout           : 10000, // 10 seconds
                enableHighAccuracy: true
            }
  };
*/
function geolocate(callback, errcallback, options){
    var opts = {
        maximumAge        : null,
        timeout           : 10000, // 10 seconds
        enableHighAccuracy: true
    };

    // Apply options
    if ( options ) {
        for ( var k in options ) {
            if ( opts.hasOwnProperty( k ) ) {
                opts[k] = options[k];
            }
        }
    }
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            callback( position );
        },
        function(err) {
            if ( errcallback ) {
                errcallback(err);
            }
        },
        opts
    );
}

/*
    watch_callback: Callback to handle position updates.
    error_callback: Callback if there is an error.
    complete_callback: Callback executes if accuracy_target is obtained or timer reached.
    accuracy_target: Target you would like to reach before quitting (default: null)
                     (Note: may timeout before target reached)
    timer: Length of time (in ms) to watch position.
    options: (optional) Options to pass to the getCurrentPosition f(x)
        -> Defaults to:
            {
                maximumAge        : null,
                timeout           : 10000, // 10 seconds
                enableHighAccuracy: true
            }
*/
function geowatch(watch_callback, error_callback, complete_callback, accuracy_target, timer, options){
    var watchId, current_position;
    accuracy_target = accuracy_target ? accuracy_target : null;

    var opts = {
        maximumAge        : null,
        timeout           : 10000, // 10 seconds
        enableHighAccuracy: true
    };

    // Apply options
    if ( options ) {
        for ( var k in options ) {
            if ( opts.hasOwnProperty( k ) ) {
                opts[k] = options[k];
            }
        }
    }

    function wrapper( position ) {
        current_position = position;
        watch_callback( current_position );
        if ( accuracy_target && current_position.coords.accuracy <= accuracy_target ) {
            navigator.geolocation.clearWatch(watchId);
            complete_callback( current_position );
        }
    }
    watchId = navigator.geolocation.watchPosition( 
        wrapper, 
        error_callback,
        opts
    );

    if ( timer ) {
        setTimeout( function() { 
            navigator.geolocation.clearWatch(watchId);
            complete_callback( current_position );
        }, timer);
    }
}