# -*- coding: utf-8 -*-#
import os
from django.core.exceptions import ObjectDoesNotExist
def main():
    r = models.Recipe.objects.all().count()
    print "Recipe count=", r
    ri = models.RecipeFile.objects.all().count()
    print "RecipeFile count=", ri
    recipes = models.Recipe.objects.all()
    for no,r in zip(range(1,1000),recipes):
        print no,"recipe id=",r.id,"typ=",r.typ,"title=",r.title.encode('utf-8'),
        if r.typ==models.RECIPE_FILE:
            try:
                data = models.RecipeFile.objects.get(recipe = r)
                print "data ok!",
            except ObjectDoesNotExist:
                print "               Recipefile DoesNotExist!",
                if 1:
                    rf = models.RecipeFile(recipe=r, user=r.author, upload="xxx.pdf")
                    rf.save()
                    print "save new RecipeFile",rf,
        else:
            print "skipped typ",r.typ,
        print ""

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'settings')
    from app import models
    main()
