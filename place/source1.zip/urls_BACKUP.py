# from django.conf.urls.defaults import patterns, include, url
# from django.conf import settings
# from accounts.forms import ProfileForm
# from validate.forms import HomeTelForm, MobileTelForm
# from registration.forms import RegistrationForm
# from django.views.generic.simple import direct_to_template
# from profiles.views import edit_profile
# from registration.views import activate
# from registration.views import register
# from accounts.forms import UserRegistrationForm

# from place.libs import views as libs_views
# from django.contrib.staticfiles.urls import staticfiles_urlpatterns

# from django.contrib.sitemaps import *

# from django.contrib import admin
# admin.autodiscover()
# from place.sitemap import *
# import robots
# from platform import node
# server = node()

# try:
#     delete_url = settings.MULTI_FILE_DELETE_URL
# except AttributeError:
#     delete_url = 'multi_delete'

# try:
#     image_url = settings.MULTI_IMAGE_URL
# except AttributeError:
#     image_url = 'multi_image'



# #handler404 = 'place.libs.views.place_404'
# handler500 = 'place.libs.views.place_500'

# urlpatterns = patterns('',
# 	url(r'^admin_tools/', include('admin_tools.urls')),
# 	url(r'^admin/ps_analytics/', 'libs.views.load_analytics_page'),
# 	url(r'^admin/ps_tools/create_topic/(?P<topic_type>ps_topic|oauth2_topic)/', 'libs.views.create_topic'),
# 	url(r'^admin/ps_tools/$', 'libs.views.load_tools_page'),
# 	url(r'^admin/ps_tools/survey_users/$', 'libs.views.get_incomplete_surveys'),
	
# 	url(r"signups/$", "views.get_signup_times"),


# 	(r'^robots.txt$', include('robots.urls')),
# 	# Facebook canvas app URL
# 	url(r'^fb-canvas-app/$', 'place.views.fb'),

# 	#redirect for old links
# 	url(r'^topic.php$', 'place.views.redirects'),
	
# 	#only adding this as its on the google search for 'PlaceSpeak'
# 	url(r'^about.php$', 'place.views.aboutredirect'),
	
# 	# Static pages urls	
#     url(r'^$', 'place.views.staticpages', {'page_name' : 'index'}),
#     url(r'^user_growth/(?P<region>\w+)/$', 'place.views.growth_map'),
    
#     url(r'^load_featured/$', 'place.views.load_images'),
    
#     url(r'^(?P<page_name>about|howitworks|price|privacy|terms|testimonials|translation|terms-of-service|tutorials)/$', 'place.views.staticpages', name='statics'),
#     url(r'^(?P<page_name>contact|invite)/$', 'forms.views.forms'),
#     url(r'^about/(?P<page_name>contact)/$', 'forms.views.forms'),
#     url(r'^about/(?P<page_name>placespeak|board|team|supporters|media)/$', 'place.views.staticpages'),
    
#     url(r'^invite/sent/$', direct_to_template, {'template':'staticPages/invitesent.html'}),
#     url(r'^thanks/$', direct_to_template, {'template':'staticPages/thanks.html'}),
#     url(r'^faq/(?P<faq_type>proponent|user)/$', 'place.views.faqs'),
#     #Not used but page is available
#     ('^features/$', direct_to_template, {'template':'staticPages/feature_info.html'}),
#     #Not used but page is available
#     ('^newteam/$', direct_to_template, {'template':'staticPages/newteam.html'}),
    
#     ('^maintenance/$', direct_to_template, {'template':'staticPages/maintenance.html'}),

# 	# URL to copy polygons accross topics - orig is topic ID to copy from - dest(ination) is topic ID to copy to
# 	url(r'^copypoly/(?P<origin>\d+)/(?P<dest>\d+)/$', 'place.views.copyPolygon'),

# 	# Recurly URLs
# 	url(r'^payment/', include('django_recurly.urls')),
# 	url(r'^subscribe/(?P<plan>basic|bronze|silver|gold)/$', 'recurly.views.payment', name='billing'),
# 	url(r'^subscribe/(?P<org>\w+)/(?P<plan>basic|bronze|silver|gold|bronze-monthly|silver-monthly|gold-monthly|bronze-annual|silver-annual|gold-annual)/$', 'recurly.views.payment', name='billing'),
# 	url(r'^subscribe/confirmation/$', 'recurly.views.confirmation'),
# 	#No longer useful due to multiple "accounts" per user
# 	url(r'^account/manage/$', 'recurly.views.manageAcc'), #Organizations Recurly account management
# 	url(r'^proponent/register/$', 'proponents.views.register'),
# 	url(r'^proponent/confirmation/$', 'proponents.views.confirmation'),
# 	url(r'^proponent/organization/(?P<plan>basic|bronze|silver|gold|bronze-monthly|silver-monthly|gold-monthly|bronze-annual|silver-annual|gold-annual)/$', 'recurly.views.selectOrganization'),
# 	url(r'^dashboard/load_markup/$', 'proponents.views.load_modal_markup'),
# 	url(r'^dashboard/load_contents/$', 'proponents.views.load_dashboard_page'),
# 	url(r'^subscriptions/change_subscription/$', 'proponents.views.change_subscription_plan'),
# 	url(r'^organization/billing_info/$', 'proponents.views.edit_billing_info'),
	
#     # Examples:
#     #url(r'^$', 'place.views.home', name='home'),
#     # url(r'^place/', include('place.foo.urls')),

	
	
#     #url('^profiles/edit', 'profiles.views.edit_profile', {'form_class': ProfileForm,}),

#     #url(r'^profiles/', include('profiles.urls')),

# 	#(r'^accounts/login/$', 'django.contrib.auth.views.login', {'next': '/profiles/profile_detail', }),
	

# 	#url(r'^accounts/', include('registration.backends.place_regbackend.urls')),
# 	#url(r'^accounts/profile/', 'accounts.views.profile',),
# 	#url(r'^accounts/login/$', 'accounts', {'template': 'registration/login.html'}),
		
#     # Uncomment the admin/doc line below to enable admin documentation:
#     url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

#     url(r'^validate/hometel/add/$', 'validate.views.add_homeTel', {}, 'validate_hometel_add'),
#     url(r'^validate/hometel/confirm/', 'validate.views.confirm_homeTel',{}, 'validate_hometel_confirm'),
#     url(r'^validate/hometel/talk/(?P<username>[\w\.]+)/$', 'validate.views.publishPin',),
    
#     url(r'^validate/mobiletel/add/$','validate.views.add_mobileTel', {}, 'validate_mobiletel_add'),
#     url(r'^validate/mobiletel/confirm/', 'validate.views.confirm_mobileTel',{}, 'validate_mobiletel_confirm'),
    
# 	# Topics App
# 	url(r'^topics/get_topics/', 'topics.views.get_topics'),
# 	url(r'^topics/all_topics/', 'topics.views.all_topics'),
# 	url(r'^topics/$', 'topics.views.load_topics'),
# 	url(r'^topics/(?P<page>\d+)/$', 'topics.views.load_topics'),
# 	url(r"^topic/widgets/(?P<id>\d+)/$", 'place.topics.widgets.ps_widgets'),
# 	url(r'^topic/(?P<id>\d+)/$', 'topics.views.load_topic'),
# 	url(r'^topic/(?P<id>\d+)/(?P<slug>[-\w]+)/$', 'topics.views.load_topic'),
	

#         # for PSConnect topics
# 	# url(r'^psc_topic/get_psc_topic_map/', 
#  #            'topics.views.get_psc_topic_map'),
# 	#url(r'^psc_topic/save_map/', 'topics.views.save_map'),

# 	url(r'^topic/editor/', 'topics.views.loadEditor'),
# 	url(r'^topic/save/', 'topics.views.saveEditor'),
# 	url(r'^topic/delete/(?P<id>\d+)/$', 'topics.views.delete'),
# 	url(r'^topic/remove_object/', 'topics.views.removeObject'),
# 	url(r'^topic/update_privacy/', 'topics.views.updatePrivacySetting'),
# 	url(r'^topic/get_topic_map/', 'topics.views.get_topic_map'),
# 	url(r'^topic/save_map/', 'topics.views.save_map'),
# 	url(r'^topic/import_kml/', 'topics.views.import_kml'),
# 	url(r'^topic/connect/', 'topics.views.connectToTopic'),
# 	url(r'^topic/category/(\d+)/$', 'discussion.views.forum_category', name='discussion_category'),
# 	url(r'^topic/toggle_preview/(?P<topic_id>\d+)/$', 'topics.views.toggle_preview'),
# 	url(r'^topic/toggle_publish/', 'topics.views.toggle_publish'),
# 	url(r'^topic/toggle_connection_role/', 'topics.views.toggle_connection_role'),
# 	url(r'^topic/notify_citizens/', 'topics.views.notify_citizens'),
# 	url(r'^topic/connections/', 'topics.views.connections'),
# 	url(r'^topic/invite-admin/$', 'topics.views.invite_admin'),
# 	url(r'^topic/admin-invite/(?P<response>accept|decline)/$', 'topics.views.invitation_response'),
# 	url(r'^topic/archive/(?P<topic_id>\d+)/$', 'topics.views.archive'),
# 	url(r'^topic/cancel_subscription/$', 'proponents.views.cancel_subscription'),
#     url(r'^topic/update_image_ordering', 'topics.views.updateImageOrder'),
#     url(r'^topic/toggle_follow_thread/$', 'discussion.views.toggleFollowThread'),
#     url(r'^topic/toggle_follow_all/$', 'discussion.views.toggleFollowAll'),
#     url(r'^topic/toggle_follow_noticeboard/$', 'discussion.views.toggleFollowNoticeboard'),
#     url(r'^topic/load_section/$', 'topics.views.load_section'),

#     #Private topic views
#     url(r'^topic/invitations/$', 'topics.views.invitations'),
#     url(r'^topic/toggle_invitation_role/$', 'topics.views.toggle_invitation_role'),
#     url(r'^topic/add_invitations/$', 'topics.views.add_user_invitations'),
#     url(r'^topic/revoke_invitations/$', 'topics.views.revoke_invitation'),
#     url(r'^topic/invitations/individual_email/$', 'topics.views.invitation_email'),
#     url(r'^topic/invitations/bulk_email/$', 'topics.views.send_all_invitations'),
#     url(r'^topic/invitation_response/$', 'topics.views.private_invitation_response'),

# 	url(r'^topic/update_image_ordering', 'topics.views.updateImageOrder'),
	
# 	# Proponent Keyword views
# 	url(r'^topic/refresh_keywords/$', 'keywords.views.refreshKeywords'),
# 	url(r'^topic/add_keyword/$', 'keywords.views.addKeywords'),
# 	url(r'^topic/delete_keyword/$', 'keywords.views.deleteKeyword'),
# 	url(r'^topic/keyword_list/$', 'keywords.views.keyword_list'),
	
# 	#User/preview keyword views
# 	url(r'^topic/keywords/follow/$', 'keywords.views.follow_keyword'),
# 	url(r'^topic/keywords/unfollow/$', 'keywords.views.unfollow_keyword'),
# 	url(r'^topic/keywords/refresh_user/$', 'keywords.views.refresh_user_keywords'),

# 	# Topic Social Media
# 	url(r'^topic/twitter-editor/$', 'topics.views.twitter_editor'),
# 	url(r'^topic/twitter-editor-save/$', 'topics.views.twitter_editor_save'),
# 	url(r'^topic/twitter_parameters/$', 'topics.views.twitter_parameters'),
# 	url(r'^topic/facebook-editor/$', 'topics.views.facebook_editor'),
# 	url(r'^topic/facebook-editor-save/$', 'topics.views.facebook_editor_save'),

 
# 	# Assets App
#     url(r'^assets/process_upload_images', 'assets.views.process_upload_images'),
# 	url(r'^assets/ie_process_upload_images', 'assets.views.ie_process_upload_images'),
	
# 	# Survey App
# 	url(r'^survey/launch_ls_admin/', 'survey.views.launch_ls_admin'),
# 	url(r'^survey/survey_info/', 'survey.views.survey_info'),

#     # Uncomment the next line to enable the admin:
#     url(r'^admin/', include(admin.site.urls)),

#     url(r'^discussion/new_post', 'discussion.views.new_post'),
#     url(r'^discussion/new_reply', 'discussion.views.new_reply'),
#     url(r'^discussion/moderate_thread', 'discussion.views.moderate_thread'),
#     url(r'^discussion/view_counter', 'discussion.views.view_counter'),
#     url(r'^discussion/discussion_vote', 'discussion.views.discussion_vote'),
#     url(r'^discussion/report_abuse', 'discussion.views.report_abuse'),
#     url(r'^discussion/load_discussions', 'discussion.views.load_discussions'),

#     # Notice Board
#     url(r'^discussion/load_noticeboard', 'discussion.views.load_noticeboard'),
#     url(r'^discussion/nb_post_process', 'discussion.views.nb_post_process'),
#     url(r'^discussion/nb_delete_post', 'discussion.views.nb_delete_post'),
#     url(r'^discussion/get_nb_post', 'discussion.views.get_nb_post'),    
    
#     url(r'^profile/keywords/follow/$', 'keywords.views.follow_keyword'),
#     url(r'^profile/keywords/refresh/$', 'keywords.views.profileKeywords'),
#     url(r'^profile/keywords/unfollow/$', 'keywords.views.unfollow_keyword'),
#     url(r'^profile/cloud/$', 'keywords.views.load_cloud'),
    
#     url(r'^profile/', 'accounts.views.profile',name='profiles_profile_detail'),
#     url(r'^profiles/profile/', 'accounts.views.profile',name='profiles_profile_detail'),
#     url(r'^accounts/profile/', 'accounts.views.profile',name='profiles_profile_detail'),
    
#     url(r'^profiles/edit/', 'accounts.views.edit_profile', name='edit_profile' ),
#     url(r'^settings/edit/', 'accounts.views.edit_settings', name='edit_settings' ),
    
#     url(r'^profiles/place/add/$', 'accounts.views.edit_place', {}, 'add_place'),
#     url(r'^profiles/place/edit/(?P<id>\d+)/$', 'accounts.views.edit_place', {}, 'edit_place'),
#     url(r'^profiles/place/delete/(?P<id>\d+)/$', 'accounts.views.delete_place', {}, 'delete_place'),
#     url(r'^profiles/','accounts.views.profile',name='profiles_profile_detail'), #if navigate back to profiles/ take to index...
#     #url(r'^profiles/(?P<username>[\w\.]+)/$', 'profiles.views.profile_detail', name='profiles_profile_detail'),

#     #url(r'^profiles/', include('profiles.urls')),
    
#     url(r'^login/$', 'place.accounts.views.mylogin'),
#     url(r'^logout/$', 'place.accounts.views.mylogout'),
    
#     url(r'^accounts/password/reset/complete/$',direct_to_template,{ 'template': 'index.html' }), 
    
#     url(r'^accounts/register/$', 'registration.views.register',{'backend': 'accounts.regbackend.Backend','form_class' : UserRegistrationForm}, name='registration_register'),   
#     url(r'^signup/$', 'registration.views.register',{'backend': 'accounts.regbackend.Backend','form_class' : UserRegistrationForm}, name='registration_register'),	
    

#     #url(r'^activate/complete/$',direct_to_template,{ 'template': 'index.html' }),
    
#     #overwriting a registration url
#     # url(r'^activate/complete/$',direct_to_template,{ 'template': 'index.html' },name='registration_activation_complete'),
    
#     #registration urls
#     url(r'^accounts/', include('registration.backends.default.urls')),
    
#     url(r'^plans/verify/', 'libs.views.verify'),
#     url(r'^alert/', 'libs.views.alert'),
#     url(r'^delete_asset', 'assets.views.deleteAsset'),
#     url(r'^geoip/$', 'libs.views.geoip'),
    
#     #url(r'^fb/', include('fb.urls')),
    
#     #url(r'^facebook/', include('django_facebook.urls')),
    
#     url(r'^social/', include('socialregistration.urls', namespace = 'socialregistration')),
#     url(r'^ps_widgets/', include('topics.urls')),
    
#     url(r'^dashboard/(?P<org_id>\d+)/(?P<org_name>[-\w]+)/$', 'proponents.views.load_dashboard'),
#     url(r'^dashboard/(?P<org_id>\d+)/$', 'proponents.views.load_dashboard'),
#     url(r'^manage/(?P<org_id>\d+)/(?P<org_name>[-\w]+)/$', 'proponents.views.load_org_dashboard'),
#     url(r'^manage/(?P<org_id>\d+)/$', 'proponents.views.load_org_dashboard'),
#     url(r'^reports/discussions/(?P<topic_id>\d+)/$', 'topics.views.create_discussions_nbs_report'),
#     url(r'^reports/polls/(?P<topic_id>\d+)/$', 'topics.views.create_polls_report'),
#     url(r'^organization/confirm_manager/$', 'proponents.views.add_manager'),
#     url(r'^organization/remove_from_team/$', 'proponents.views.remove_from_team'),
#     url(r'^organization/invite_team/$', 'proponents.views.invite_team'),
#     url(r'^accept/(?P<verif_code>\w+)/$', 'proponents.views.accept_team'),
#     url(r'^decline/(?P<verif_code>\w+)/$', 'proponents.views.decline_team'),

#     url(r'^assistant/', include('help.urls')),

#     # OAuth stuff
#     url(r'^oauth2/', include('place.psc.urls')),
#     url(r'^psc_api/', include('place.psc_api.urls')),

#     url(r'^polls/', include('polls.urls')),

#     url(r'^spatial/geocode/$', 'libs.views.geocode'),	

#     url(r'^user-json/$', 'views.get_user_json'),
    
#     #redirect for old vanity urls
# 	url(r'^(?i)(?P<vanity>backyardcompost|gibsonsharbour|hamiltonareaplan|HamiltonAreaPlan|KPRA|oakridgecentre|ourfuture.vsb|OurFuture.VSB|rcbc|tofinotsunamisiren|streetcarcity2050|urbanfuturessurvey|vancouverhousing|vancouvertransportation|VCRP|VFRS|VMM|ubchousingplan|UBCHousingPlan|NewWestMTP|newwestmtp|urbanfuturessurvey-cn|housingtaskforce|northdelta|LetsTalkSiteC|aldergroveregionalpark|fahrlands|translinkbaseplan)/$', 'place.views.vanity'),
	 
# 	#redirect for old vanity urls
# 	url(r'^(?i)(?P<vanity>[-\w]+)/$', 'place.views.vanity'),

# )

# sitemaps = {
# 	'topic':Topicsitemap,
# 	'index':Indexsitemap,
# 	'team':AboutTeamsitemap,
# 	'media':AboutMediasitemap,
# 	'contact':Contactsitemap,
# 	'howitworks':HowItWorkssitemap,
# 	'pricing':Pricingsitemap,
# 	'userfaq':UserFAQsitemap,
# 	'proponentfaq':ProponentFAQsitemap,
# 	'tutorial':Tutorialsitemap,
# 	'register':Registersitemap,
# 	'topicslist':Topicssitemap,
# 	'proponentterms':PropTermssitemap,
# 	'userterms':UserTermssitemap,
# 	'privpolicy':Privacysitemap,
# 	}

# urlpatterns += patterns('',
#     (r'^sitemap\.xml', 'django.contrib.sitemaps.views.sitemap', {'sitemaps': sitemaps}),
# )

# if not settings.CURRENT_SERVER in ['prod', 'dev']:
#         urlpatterns += patterns('',
#             url(r'^uploads/(?P<path>.*)$', 'django.views.static.serve',{'document_root': settings.MEDIA_ROOT}),
#             url(r'^static/(?P<path>.*)$', 'django.views.static.serve',{'document_root': settings.STATIC_ROOT}),
#         )

