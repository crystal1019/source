import objects
import masterpage
import method_question
import method_url
	
class MergeAttributes(masterpage.MasterPage):				  	
	def get(self):
		deletion = method_url.getStringParam(self, 'delete')
		if deletion:
			attribute = method_question.getAttributeWithPid(deletion)
			attribute.key.delete()
		source = method_url.getStringParam(self, 'source')
		destination = method_url.getStringParam(self, 'destination')
		if source and destination:
			attribute = method_question.getAttributeWithPid(source)
			type = attribute.type
			if type == 'company':
				filter_text = 'companies_pretty ='
			elif type == 'job':
				filter_text = 'jobs_pretty ='
			else:
				filter_text = 'topics_pretty ='		
			questions = objects.Question.query.filter(filter_text, source)
			count = 0
			lst = []
			brokeEarly = False
			for question in questions:
				if count > 20:
					brokeEarly = True
					break
				if type == 'company':
					question.companies_pretty.remove(source)
					if not(destination in question.companies_pretty):
						question.companies_pretty.append(destination)					
				elif type == 'job':
					question.jobs_pretty.remove(source)
					if not(destination in question.jobs_pretty):
						question.jobs_pretty.append(destination)					
				else:
					question.topics_pretty.remove(source)
					if not(destination in question.topics_pretty):
						question.topics_pretty.append(destination)
				lst.append(question.uid)					
				question.put()
				count = count + 1
			attribute_dest = method_question.getAttributeWithPid(destination)
			attribute_dest.question_count = attribute_dest.question_count + count
			attribute.question_count = attribute.question_count - count
			attribute_dest.put()
			attribute.put()
			if not brokeEarly or attribute.question_count == 0:
				attribute.key.delete()
			
			for i in lst:
				self.response.out.write('<a href="/question?id=' + str(i) + '">Updated Question ' + str(i) + '</a><br/>')
			
		attributes = method_question.getAllAttributes()
		template_values = {
			'companies': attributes['company'],
			'topics': attributes['topic'],
			'jobs': attributes['job'],
		}			  
		self.pushPage(template_values, 'Merge Attributes', 'html/mergeattributes.html')  
				
		
		
