from django import template
from django.conf import settings
from django.contrib.flatpages.models import FlatPage

register = template.Library()

from offers.core.models import Category
from offers.core.templatetags import varname_re
from offers.core.views import offer_list_for_category

class HomepageOffersNode(template.Node):
    def __init__(self, varname, q_filter):
        self.varname = varname
        self.filter = q_filter

    def render(self, context):
        _filter = self.filter
        homepage_offers = list()
        if settings.SITE_ID == 8:  # creditcardcompare.com.au
            for cat in Category.on_site.filter(**_filter):
                homepage_offers.append(dict(
                    category=cat,
                    editor_choices=cat.offer_set.filter(sites=settings.SITE_ID, is_active=True,
                                            offercategory__editor_choice=True
                                            ).order_by('-outbound_link'),
                    offer_list=cat.offer_set.filter(sites=settings.SITE_ID, is_active=True,
                                            offercategory__editor_choice=False
                                            ).order_by('-outbound_link')
                ))
        else:
            request = template.Variable('request').resolve(context)
            for cat in Category.on_site.filter(**_filter).order_by('id'):
                offer_list = offer_list_for_category(request, cat.slug, template='offers/bare_offer_list.html')
                offer_list.content = offer_list.content
                homepage_offers.append({'offers':offer_list, 'category':cat})
        context[self.varname] = homepage_offers

        return ''

@register.tag(name='homepage_offers')
def do_homepage_offers(parser, token):
    try:
        tag_name, _as, varname, raw_filter = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    q_filter = dict()
    kw, val = raw_filter.split('=')
    if not (val[0] == val[-1] and val[0] in ('"', "'")):
        raise template.TemplateSyntaxError, '%r tag filter value must be in quotes.' % tag_name
    q_filter[str(kw)] = val[1:-1]
    return HomepageOffersNode(varname, q_filter)

class GetFlatpagesUnderNode(template.Node):
    def __init__(self, varname, top_dir):
        self.varname = varname
        self.top_dir = top_dir

    def render(self, context):
        context[self.varname] = FlatPage.objects.filter(
                                        sites=settings.SITE_ID,
                                        url__istartswith='/%s/' % self.top_dir
                                    ).exclude(url__iexact='/%s/' % self.top_dir
                                    ).order_by('title')
        return ''

#tag used for broadbandcompare.com.au  and frequentflyercreditcards.com.au
@register.tag(name='get_flatpages_under')
def do_get_flatpages_under(parser, token):
    try:
        tag_name, raw_top_dir, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    if not (raw_top_dir[0] == raw_top_dir[-1] and raw_top_dir[0] in ('"', "'")):
        raise template.TemplateSyntaxError, '%r tag top_dir value must be in quotes.' % tag_name
    top_dir = raw_top_dir[1:-1]
    return GetFlatpagesUnderNode(varname, top_dir)

class SplitOnNode(template.Node):
    def __init__(self, obj, delim, varname):
        self.obj = template.Variable(obj)
        self.delim = delim
        self.varname = varname

    def render(self, context):
        try:
            obj = self.obj.resolve(context)
        except template.VariableDoesNotExist:
            context[self.varname] = []
            return ''

        try:
            context[self.varname] = map(lambda s: s.strip(), obj.split(self.delim))
        except:
            context[self.varname] = []

        return ''

#tag used for broadbandcompare.com.au only
@register.tag(name='split')
def split(parser, token):
    try:
        tag_name, obj, _on, raw_delim, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 5 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    if not (raw_delim[0] == raw_delim[-1] and raw_delim[0] in ('"', "'")):
        raise template.TemplateSyntaxError, '%r tag delim value must be in quotes.' % tag_name
    delim = raw_delim[1:-1]
    return SplitOnNode(obj, delim, varname)
