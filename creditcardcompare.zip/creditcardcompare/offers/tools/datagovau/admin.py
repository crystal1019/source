from django.contrib import admin
from models import Location


class LocationAdmin(admin.ModelAdmin):
    model = Location
    list_display = ('data', 'date', 'lat', 'lon', 'batch', 'address')
    list_filter = ('batch', 'address')

#admin.site.register(Location, LocationAdmin)