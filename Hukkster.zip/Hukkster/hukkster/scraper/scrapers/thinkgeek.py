import json
import logging
import re
import requests
from bs4 import BeautifulSoup
from .base import BaseScraper
from ..exceptions import HukksterTooManyOptions, HukksterTechnicalDifficulties


logger = logging.getLogger('scraper')


class ThinkGeekScraper(BaseScraper):
    @staticmethod
    def get_domain():
        return 'thinkgeek.com'
    
    def __init__(self, url):
        self.url = url
        logger.debug('Initiated the scraper for %s' % (self.url))
        self.fetch_url()    

    def fetch_url(self):
        try:
            request = requests.request('get', self.url)
            self.html = request.content
            logging.debug('Successfully fetched URL %s' % self.url)
        except Exception, e:
            logging.error('Error %s for %s' % (e.msg, self.url))
            raise HukksterTechnicalDifficulties(ThinkGeek.domain(), self.url)

    def parse_selection(self, data):
        """
        Parse color, size, price
        """
        data = data.replace('$', '')
        arr = data.split(',')
        results = []
        results.append(arr[0])
        tmp = arr[1].split()
        results.append(tmp[0])
        results.append(tmp[1])
        
        return results

    def generate_record(self, url, site, title, price, image,
                        sku, size='', color='', promos=[]):
        """
        Generate a dictionary record from existing data
        return a dictionary of data
        """
        record = {
            'title': title,
            'current_price': {
                'value': price
            },
            'url': url,
            'store': site,
            'image': image,
            'local_id': sku,
            'selections': {
                'size': size,
                'color': color
            },
            'promos': promos
        }
        return record

    def craw_html_data(self, soup, html, raw_data):
        """ 
        This function is the root of our scraper, grabs the html and runs our scrapers.
        return array of data
        """

        # site name
        try:
            site_name = raw_data['site_name']
        except TypeError:
            raise HukksterTooManyOptions(ThinkGeekScraper.get_domain(), self.url)

        # url 
        url = raw_data['url']

        # description
        description = raw_data['description']

        # image
        image = raw_data['image']

        # title
        title = raw_data['title']

        results = []
        
        pid = soup.find('input', attrs={'name':'pid'})['value']

        # Parsing product variants
        selections = soup.find('select', attrs={'id': 'sku'})
        if selections is not None:
            for row in selections.findAll('option'):
                # SKU
                sku = row['value']
                if sku != '-':
                    sel = self.parse_selection(row.text)
                    # color
                    color = sel[0]

                    # size
                    size = sel[1]

                    # current price
                    price = sel[2]
                    price = float(price.replace('$', ''))
                    record = self.generate_record(url, site_name, title,
                                                  price, image,
                                                  pid, size, color)

                    results.append(record)
        else:
            # We assume we are dealing with a product having no variants
            sku = soup.find('input', attrs={'name': 'sku'})
            if sku is None:
                raise HukksterTooManyOptions(ThinkGeekScraper.get_domain(), self.url)
            sku = sku['value']
            print sku

            price = soup.find('option', attrs={'value': sku})
            if price is None:
                raise HukksterTooManyOptions(ThinkGeekScraper.get_domain(), self.url)
            price = float(price.text.replace('$', ''))

            record = self.generate_record(url, site_name, title, price, image, pid)

            results.append(record)

        return results 

    def get_base(self, regex, html):
        """
        Pull subset of the HTML for regex evaluation.
        """

        return re.compile(regex).findall(html)[0]

    def get_data_regexes(self, regexes, base):
        """
        Loop over regex rules and pull data.
        return dictionary
        """

        result = {}

        for aregex in regexes:
            try:
                resunts = re.compile(aregex['find']).findall(base)
                result[aregex['name']] = (',').join(resunts)
            except: # TODO: too broad, please improve
                result[aregex['name']] = 'NOTHING'
        return result

    def get_data_json(self, data):
        """
        Parse json to dictionary.
        """
        return json.loads(data)

    def parse(self):
        raw_data = self.parse_opengraph()

        # Getting missing parts
        logging.debug('Parsing HTML data')
        soup = BeautifulSoup(self.html)
        logging.debug('Finished parsing HTML data')

        selections = self.craw_html_data(soup, self.html, raw_data)

        # Giving up, it doesn't look as a product
        if selections is None or not len(selections):
            raise HukksterTooManyOptions(ThinkGeekScraper.get_domain(), self.url)

        return selections
