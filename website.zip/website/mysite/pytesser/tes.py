from pytesser import *
image = Image.open('ostock_rendered.jpg')  # Open image object using PIL
print image_to_string(image)     # Run tesseract.exe on image
#print image_file_to_string('ostock_rendered.png')

