from settings import *


EMAIL_SUBJECT_PREFIX = '[CCC AWS ALERT 0]'
SITE_ID = 8
SITE_NAME = 'creditcardcompare.com.au'
INTERNAL_LINK = 'www.creditcardcompare.com.au'
ALLOWED_HOSTS = [SITE_NAME, 'www.creditcardcompare.com.au']
IMAGE_URL = 'http://images.creditcardcompare.com.au/media'
AWS_S3_CUSTOM_DOMAIN = 'static.' + SITE_NAME
STATIC_URL = 'http://%s/static/' % AWS_S3_CUSTOM_DOMAIN
MEDIA_URL = 'http://%s/media/' % AWS_S3_CUSTOM_DOMAIN
COMPRESS_OUTPUT_DIR = 'compressed/' + SITE_NAME

RECAPTCHA_PUBLIC_KEY = '6LegT8kSAAAAAC8Bfk0UtOaEWWc0pMdP3ZVZ_baR'
RECAPTCHA_PRIVATE_KEY = '6LegT8kSAAAAAD-rxm6VwBzNAmdcHYA-C7vp3WC-'
RECAPTCHA_USE_SSL = True

WP_DATABASE = 'ccc_blog'
WP_TABLE_PREFIX = 'ccctcl'

MOBILE_TEMPLATE_DIR = os.path.join(PROJECT_DIR, 'templates', SITE_NAME, '2014', 'mobile')
DEVICES = {'smartphone': 0, 'desktop': 1}
DEFAULT_TEMPLATE = DEVICES['smartphone']
TEMPLATE_DIRS = (
    os.path.join(PROJECT_DIR, 'templates', SITE_NAME, '2014'),
    os.path.join(PROJECT_DIR, 'templates', SITE_NAME, '2013'),
    os.path.join(PROJECT_DIR, 'templates', 'all_sites'),
)

CCC_APPS = [
    'captcha',
]
INSTALLED_APPS += CCC_APPS

try:
    from settings.dev import *
except ImportError:
    pass
else:
    INSTALLED_APPS += DEV_APPS