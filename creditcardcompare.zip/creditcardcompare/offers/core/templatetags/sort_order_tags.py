"""
Used for gcc only
"""

from django import template
from offers.core.templatetags import varname_re


register = template.Library()

class OfferSortOrder(template.Node):
    def __init__(self, offer, category, varname):
        self.offer = template.Variable(offer)
        self.category = template.Variable(category)
        self.varname = varname

    def render(self, context):
        offer = self.offer.resolve(context)
        category = self.category.resolve(context)
        context[self.varname] = offer.offercategory_set.get(category=category).sort_order \
                                or 1 # 0 and 1 have the same design
        return ''
    
@register.tag(name='get_sort_order')
def do_get_sort_order(parser, token):
    try:
        tag_name, offer, category, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 arguments' % token.split_contents()[0]

    if not varname_re.search(varname):
        raise template.TemplateSyntaxError, '%r tag. %r is not a valid variable name.' % (tag_name, varname)

    return OfferSortOrder(offer, category, varname)