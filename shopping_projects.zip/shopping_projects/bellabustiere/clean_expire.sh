cd /home/chaol/projects/bellabustiere
python manage.py cleanup > /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/clean_process
echo "---------------" >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/clean_process
cat  /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/clean_process >> /var/www/vhosts/bellabustiere.com/httpdocs/media/index_process/clean_allprocess
