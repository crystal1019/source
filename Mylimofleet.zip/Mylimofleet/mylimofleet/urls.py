# from django.conf.urls.defaults import *
from django.conf.urls.i18n import i18n_patterns
from django.conf.urls import patterns, include, url
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = patterns('',
                       (r'^login/$', {'template_name': 'accounts/login.html'}),

                       (r'^logout/$', {'template_name': 'accounts/logged_out.html'}),

                       (r'^password_change/$',
                        'django.contrib.auth.views.password_change',
                        {'template_name': 'accounts/password_change_form.html'}),

                       (r'^password_change/done/$',
                        'django.contrib.auth.views.password_change_done',
                        {'template_name': 'accounts/password_change_done.html'}),

                       (r'^password_reset/$',
                        'django.contrib.auth.views.password_reset',
                        {'template_name': 'accounts/password_reset_form.html',
                         'email_template_name': 'accounts/password_reset_email.html'}),

                       (r'^password_reset/done/$',
                        'django.contrib.auth.views.password_reset_done',
                        {'template_name': 'accounts/password_reset_done.html'}),

                       (r'^reset/(?P<uidb36>[0-9A-Za-z]+)-(?P<token>.+)/$',
                        'django.contrib.auth.views.password_reset_confirm',
                        {'template_name': 'accounts/password_reset_confirm.html'}),

                       (r'^reset/done/$',
                        'django.contrib.auth.views.password_reset_complete',
                        {'template_name': 'accounts/password_reset_complete.html'}),

                       # (r'^signup/$',
                       #  'mylimofleet.views.signup',
                       #  {'template_name': 'accounts/signup_form.html',
                       #   'email_template_name': 'accounts/signup_email.html'}),
                       #
                       # (r'^signup/done/$',
                       #  'mylimofleet.views.signup_done',
                       #  {'template_name': 'accounts/signup_done.html'}),
                       #
                       # (r'^signup/(?P<uidb36>[0-9A-Za-z]+)-(?P<token>.+)/$',
                       #  'mylimofleet.views.signup_confirm'),
                       #
                       # (r'^signup/complete/$',
                       #  'mylimofleet.views.signup_complete',
                       #  {'template_name': 'accounts/signup_complete.html'}),
)
urlpatterns += staticfiles_urlpatterns()