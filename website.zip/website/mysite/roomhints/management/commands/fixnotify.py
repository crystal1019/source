from django.conf import settings

from django.core.management.base import BaseCommand, CommandError, NoArgsCommand
from django.db import connection, transaction
from roomhints.MyEmailSend import MyEmailSend

from roomhints.models import Project
from roomhints.models import Feedback
from roomhints.models import Beta
from roomhints.models import Profile

from datetime import datetime, timedelta
from django.utils.timezone import utc
import math
from roomhints.utils import paid_days

class Command(BaseCommand):
    help = 'Send notification emails for some events'

    def handle(self, *args, **options):
        # projuniq = None
        # for a in args:
        #     projuniq = a
        output = ""

        #
        # Migrate existing per-profile payments to per-room payments. Giving each user free service for all their rooms if they at least paid once
        startdate = datetime.utcnow().replace(tzinfo=utc)
        enddate = startdate - timedelta(days=paid_days)
        upall = Profile.objects.filter(stripe_id__isnull=False,charge_seconds__gt=enddate,charge_notifiedus=True).all()
        if len(upall) > 0:
            for up in upall:
                pall = Project.objects.filter(profile_id=up.id,public=True,charge_notifiedus=False).all()
                if len(pall) > 0:
                    for p in pall:
                        p.charge_notifiedus = up.charge_notifiedus
                        p.charge_amount = up.charge_amount
                        p.charge_seconds = up.charge_seconds
                        p.save()
                        output += "resaved " + p.projuniq + "\n"

        if len(upall) > 0:
            output = str(datetime.utcnow().replace(tzinfo=utc)) + "\n\n" + output

        print output
