        $(function(){
            $('.commentRegex').regValidator({
               tooltips : {               
                      "\\n\\s\\s\\s|\\nQ1[\\s\\S]*\\nQ2|class [\\s\\S]*{|struct [\\s\\S]*\{|class [\\s\\S]*\{|for [\\s\\S]*\{|while [\\s\\S]*\{" : "It looks like you're typing some code. Surround it with {{{ and }}} to preserve whitespace properly.",
               }
            });         
            
            $('.questionRegex').regValidator({
               tooltips : {               
                      "class [\\s\\S]*{|struct [\\s\\S]*\{|class [\\s\\S]*\{|for [\\s\\S]*\{|while [\\s\\S]*\{" : "It looks like you're typing some code. Surround it with {{{ and }}} to preserve whitespace properly.",
                      "\\n\\s\\s\\s|Q1[\\s\\S]*\\nQ2|1\\)[\\s\\S]*\\n2\\)|1\\.[\\s\\S]*\\n2\\." : "Adding multiple questions? Add them in separate boxes (below), so that people can comment on them separately.",
               }
            });             
        });