from django.contrib import admin
from models import Shop


class ShopAdmin(admin.ModelAdmin):
    actions = None
    fieldsets = (
        (None, {
            'fields': ('domain',)
        }),
    )
    list_display = ('domain', 'changed')
    list_display_links = ('domain',)
    search_fields = ('domain',)

admin.site.register(Shop, ShopAdmin)
