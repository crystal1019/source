from django.contrib.auth.models import User
from place.accounts.models import Place
import json

all_users = User.objects.all()
print '['
for i in all_users:
	profile = i.get_profile()
	places = Place.objects.filter(profile=profile)
	for p in places:
		user = {}
		user['name'] = i.first_name
		user['created'] = i.date_joined.isoformat()
		user['lat'] = p.location[0]
		user['long'] = p.location[1]
		print '%s,' % user	
print ']'