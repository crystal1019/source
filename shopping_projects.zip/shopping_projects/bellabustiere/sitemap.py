import datetime
from django.core.urlresolvers import reverse

from django.contrib.sitemaps import GenericSitemap, Sitemap
from django.conf import settings
from bellabustiere.blog.models import *
from bellabustiere.website.models import *
from django.contrib.sites.models import Site
from bellabustiere.shop.models import *
from bellabustiere.stockists.models import *
from django.core.paginator import *
from bellabustiere import helpers
class Generic(object):
    
    def __init__(self,location, modified=datetime.datetime.now()):
        self.location = location
        self.modified = modified
    
    def get_absolute_url(self):
        return self.location
    
class IndexSitemap(Sitemap):
    changefreq = 'weekly'
    priority = 1.0
    location = "/"
    
    def items(self):
        return [self]
    
class BlogSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.5

    def items(self):
        allblogs = BlogPost.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True, publishdate__lte=datetime.datetime.now())
        allpages = []
        perpage = settings.BLOG_POSTS_PER_PAGE
        p = Paginator(allblogs,perpage)
        for x in p.page_range:
            allpages.append(Generic('/blog/all-archive%s.html' %x))
            
        
        categories = BlogCategory.objects.filter(is_active=True, sites__id=settings.SITE_ID)
        categorypages = []
        for x in categories:
            blogs = BlogPost.objects.filter(status__display_to_user=True, category__slug=x.slug, publishdate__lte=datetime.datetime.now())
            p = Paginator(blogs,perpage)
            for xx in p.page_range:
                categorypages.append(Generic('/blog/%s-archive%s.html' %(x.slug,xx)))
        
        return list(allblogs) + [Generic('/blog/')] + allpages + categorypages

    def lastmod(self, obj):
        return obj.modified
    
class MiscSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.5
    
    def items(self):
        return MiscPage.objects.filter(sites__id=settings.SITE_ID,status__display_to_user=True)
    
class ProductSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.8
    
    def items(self):
        return Product.objects.filter(sites__id=settings.SITE_ID, status__display_to_user=True, price__gt=0)
    
class NavSiteMap(Sitemap):
    changefreq = "daily"
    priority = 0.6
    
    def items(self):
        shopleftnav = Categories.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False, parent__isnull=True).order_by('-priority')
        shopurls = [Generic('/shop/catalogue/all.html')]
        for x in shopleftnav:
            shopurls.append(Generic('/shop/catalogue/%s.html' %x.slug))
        
        designerurls = [Generic('/shop/designer/')]
        designernav = Brand.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False) 
        for x in designernav:
            designerurls += [Generic('/shop/designer/%s.html' %x.slug), Generic('/shop/designer/%s/all.html' %x.slug)]
            thedesigner = Brand.objects.get(slug=x.slug)
            subdesigner = thedesigner.getTopCategory()
            for xx in subdesigner:
                designerurls += [Generic('/shop/designer/%s/%s.html' %(x.slug, xx.slug))]
                
        activityurls = [Generic('/shop/activity/all.html')]
        activitynav = Activity.objects.filter(sites__id=settings.SITE_ID, is_active=True, is_landing=False)
        for x in activitynav:
            activityurls += [Generic('/shop/activity/%s.html' %x.slug)]
            
        now = datetime.datetime.now()
        delta = datetime.timedelta(days=90)
        end_date = now-delta
        products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True, created__gte=end_date).distinct()
        if not products:
            products = Product.objects.filter(price__gt=0, sites__id=settings.SITE_ID, status__display_to_user=True).distinct()[:18]
            
            products = Product.objects.filter(id__in=[x.id for x in products]).distinct()
        allactivity, allbrand, allclothes = helpers.getAllRelated(products)
        leftnav = allclothes
        justinurls = [Generic('/shop/just-in/')]
        for x in leftnav:
            justinurls += [Generic('/shop/just-in/%s.html' %x.slug)]
        
        saleurls = []
        have_sale = DiscountPrice.objects.filter(start__lte=now, end__gt=now,coupon=None, product__status__display_to_user=True,price__gt=0).distinct('product')
        if have_sale:
            saleurls += [Generic('/shop/sale/')]
        return shopurls + designerurls + activityurls + justinurls + saleurls


sitemaps = {
    'site': IndexSitemap(),
    'shop':ProductSitemap(),
    'blog': BlogSitemap(),
    'misc':MiscSitemap(),        
    'nav':NavSiteMap(),  
}