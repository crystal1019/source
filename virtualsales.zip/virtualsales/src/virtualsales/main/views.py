"""
copyright 2014 Seth Black
"""

from django.template.response import TemplateResponse
from django.contrib.auth.models import User
from django.core.validators import validate_email
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.shortcuts import get_object_or_404
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from virtualsales.main.models import *

def signup(request):
    template = 'signup.html'

    if request.method == 'POST':
        password = request.POST.get('password', None)
        first_name = request.POST.get('first_name', None).strip()
        last_name = request.POST.get('last_name', None).strip()
        email = request.POST.get('email', None).lower().strip()
        errors = False

        try:
            validate_email(email)
        except:
            errors = True
            error_string = "Invalid email address"
            return TemplateResponse(request, template, locals())

        username_exists = User.objects.filter(username=email)

        if username_exists:
            errors = True
            error_string = "User already exists"
            return TemplateResponse(request, template, locals())

        if len(password) < 4:
            errors = True
            error_string = "Password is too short"
            return TemplateResponse(request, template, locals())

        new_user = User.objects.create_user(email, email, password)

        if first_name:
            new_user.first_name = first_name.strip()

        if last_name:
            new_user.last_name = last_name.strip()

        new_user.save()

        user = authenticate(username=email, password=password)
        login(request, user)

        request.session['first_login'] = True

        return HttpResponseRedirect(reverse('dashboard'))

    return TemplateResponse(request, template, locals())

@login_required
def dashboard(request):
    return TemplateResponse(request, 'dashboard.html', locals())

@login_required
def assigner(request):
    campaigns = Campaign.objects.all()

    return TemplateResponse(request, 'assigner.html', locals())