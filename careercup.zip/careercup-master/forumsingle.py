import masterpage

import method_comment
import method_forum
import method_url
import method_user
import method_cache
import method_notification

		
class ViewForumSingle(masterpage.MasterPage):		 
	def get(self):
		id = method_url.getId(self)
		if not(id):
			self.redirect('/forum')
			return
		user = method_user.getLoggedInUser()	
		
		if method_url.getIntParam(self, "mark") and user != None:
			method_notification.markForumAsRead(user, id)
		
		forum_html = method_cache.getObjectForTypeAndKey(method_forum.cache_key_forum_post, id)
		forum_title = method_cache.getObjectForTypeAndKey(method_forum.cache_key_forum_title, id)
		if not forum_html or not forum_title:		
			# Get messages.
			message = method_forum.getForumPostWithId(id)
			if not message:
				self.redirect('/forum')
				return
			
			# Get comments.
			comment_list = method_comment.getCommentsWithAncestor(id)				
	
			message.independent = True
			
			template_values = {
				'item': message,
				'comments': comment_list,
				'comment_form_type': 'forum',
				'parent_tab': 'forum',			
				'comment_parent_id': message.uid,
				'comment_ancestor_id': message.uid,				  
			}
			
			if message.subject:
				length = len(message.subject)
			else:
				length = 0
			template_values['title'] = message.subject.encode('utf-8')
			forum_html = self.getBody(template_values, 'html/control-forumsingle.html')
			forum_title = message.subject
			if not forum_title:
				forum_title = ''
			#forum_html = message.subject.encode('utf-8') + '###TITLE###' + forum_html
			method_cache.setObjectForTypeAndKey(method_forum.cache_key_forum_post, id, forum_html)
			method_cache.setObjectForTypeAndKey(method_forum.cache_key_forum_title, id, forum_title)
		template_values = {}
		template_values['rendered_body'] = forum_html	
		
		# Get messages.
		message = method_forum.getForumPostWithId(id)
		if not message:
			self.redirect('/forum')
			return				
			
		user = method_user.getLoggedInUser()
		if user and user.user.email() in message.subscriptions:
			is_subscribed = True
		else:
			is_subscribed = False				
			
		template_values = {
			'title' : forum_title,
			'rendered_forum': forum_html,
			'comment_form_type': 'forum',
			'comment_parent_id': id,
			'is_subscribed': is_subscribed,
			'comment_ancestor_id': id,					
			'parent_tab': 'forum',			   
		}		
			
		self.pushPage(template_values, forum_title, 'html/forumsingle.html')				