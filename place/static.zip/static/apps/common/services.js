angular.module('common.services', []).factory("IMData", ['$http', '$q',
    function($http, $q) {
        var editor_url = '/editor_v2/input_map/';
        var participant_url = '/topics/im/';

        return {
            is_dirty: false,
            store: null,
            active: false,
            defer: $q.defer(),
            topic: null,
            gmap: null,
            infowindow: null,
            dirty: false,
            load: function(topic, is_editor) {
                this.topic = topic;
                var self = this;
                if (!this.active) {
                    var url = '';
                    if (is_editor) {
                        url = editor_url;
                    } else {
                        url = participant_url;
                    }
                    this.active = true;

                    $http({
                        method: 'GET',
                        url: url,
                        params: {
                            'topic': topic
                        }
                    }).success(function(obj) {
                        if (self.store !== null) {
                            self.reinit(obj.data);
                            self.defer.resolve({
                                reinit: true
                            });
                        } else {
                            self.store = obj.data;
                            self.defer.resolve(obj);
                        }

                    }).error(function(data, status) {
                        self.defer.reject(data);
                    });
                    return self.defer.promise;
                } else {
                    return this.defer.resolve(self.store);
                }
            },
            reinit: function(data) {
                this.store = data;
                this.layer.redraw(this.store.basegeos);
                this.gmarklayer.redraw(this.store.geomarks);
            }
        };
    }
])
.factory('addCategoryIcons', function() {

    function addCategoryIcons(cardTopics) {
        /* Give each topic card a category icon (i.e. a mini map marker
         * image). */
        for (var i = 0; i < cardTopics.length; i++) {
            var topic = cardTopics[i];
            var category = topic.category;
            var icon = getCategoryIcon(category);
            topic.categoryIcon = icon;
        }
    }

    function getCategoryIcon(category) {
        /* Return the URL of the icon for the given topic category. */
        var url = '/static/img/';
        if (category === 'archived')
            url += 'ico_archived';
        else {
            url += 'marker_';
            if (category === 'government')
                url += 'govt';
            else
                url += category;
            url += '_sm';
        }
        url += '.png';
        return url;
    }

    return addCategoryIcons;

});
