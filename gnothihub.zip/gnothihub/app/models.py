from django.db import models
# from django.utils.encoding import smart_unicode
from captcha.fields import CaptchaField

class SignUp(models.Model):
    first_name = models.CharField(max_length=120, null= True, blank=True)
    last_name = models.CharField(max_length=120, null= True, blank=True)
    area = models.CharField(max_length=120, null= True, blank=True)
    phone = models.CharField(max_length=120, null= True, blank=True)
    email = models.EmailField()
    school_name = models.CharField(max_length=120, null= True, blank=True)
    Academic = models.CharField(max_length=120, null= True, blank=True)
    captcha = CaptchaField()
    # def __unicode__(self):
    #     return smart_unicode(self.email)

# Create your models here.

class FileField(models.Model):
    title = models.CharField(max_length=120)
    file = models.FileField()