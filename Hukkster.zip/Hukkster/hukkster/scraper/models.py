from django.db import models


class UserAgent(models.Model):
    identifier = models.CharField(max_length=500, unique=True)

    def __unicode__(self):
        return self.identifier


class Target(models.Model):
    PRODUCT = 1
    MULTI_PRODUCT = 2
    OTHER = 3
    TARGET_TYPE_CHOICES = (
        (PRODUCT, 'Product'),
        (MULTI_PRODUCT, 'Multi Product'),
        (OTHER, 'Other')
    )

    url = models.URLField()
    target_type = models.PositiveSmallIntegerField(choices=TARGET_TYPE_CHOICES)


class Event(models.Model):
    target = models.ForeignKey(Target)
    user_agent = models.ForeignKey(UserAgent)
    status = models.PositiveSmallIntegerField(db_index=True)

    created = models.DateTimeField(auto_now_add=True, db_index=True, editable=False)

    class Meta:
        ordering = ('-created',)
