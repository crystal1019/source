
$(document).ready(function(){
	// get the select
	var $dd = $('#id_helprecords');
	$dd.html($("option", $dd).sort(function(a, b) { 
	    var arel = $(a).text();
	    var brel = $(b).text();
	    return arel == brel ? 0 : arel < brel ? -1 : 1 
	}));
});