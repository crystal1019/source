import simplejson as json
import sys
from django.contrib.gis.geoip import GeoIP

g = GeoIP('/home/roomhints/devel/RH/website/mysite/geoip/')
ip = sys.argv[1]
city = g.city(ip)
print json.dumps(city)

