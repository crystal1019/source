import masterpage

import method_url
import method_forum
import method_cache
		
class ViewForumList(masterpage.MasterPage):
	number_forums = 0
	
	def addSortToList(self, list, sort, prettyprint, current_sort, islast):
		html = ''
		if sort == current_sort:
			html = '<span class="pageNumberActive">' + prettyprint + '</span> '	 
		else:
			url = method_url.createUrlWithAttribute(self, 'sort', sort)
			html = '<a class="pageNumber" href="' + url + '">' + prettyprint + '</a>'
		if not islast:
			html = html + ' | '
		list.append(html)
	
	def getSortList(self):
		sort_html = []
		current_sort = method_url.getStringParam(self, 'sort')
		if not current_sort or current_sort == '':
			current_sort = 'date'
		self.addSortToList(sort_html, 'date', 'Date Added', current_sort, False)
		self.addSortToList(sort_html, 'comments', 'Number of Comments', current_sort, False)
		self.addSortToList(sort_html, 'recentcomments', 'Most Recently Commented', current_sort, True)
		
		return sort_html
		
	def getCurrentSort(self):
		current_sort = method_url.getStringParam(self, 'sort')
		if not current_sort or current_sort == '':
			current_sort = 'date'
		return current_sort	
		
	def getPageCacheKey(self, sort):
		page_cache_key = 'forum'	+ '-' + sort
		return page_cache_key					 
		
	def get(self):	
		page_num = self.getPageIndex()
		sort = self.getCurrentSort()
		page_cache_key = self.getPageCacheKey(sort)
		
		forum_html = method_cache.getObjectForTypeAndKey(page_cache_key, page_num)
		if not forum_html:
			# Get forum posts.
			results = method_forum.getForumPosts(page_num, sort)
			all_forum_posts = results[0]
			has_more_sets = results[2]
			
			page_calcs = method_url.doPageCalculations(has_more_sets, page_num, method_forum.pages_per_set, method_forum.per_page, len(all_forum_posts))			
			forum_posts = self.pruneToPage(all_forum_posts, page_calcs['current_page'] - page_calcs['first_page_of_set'], method_forum.per_page)			

			
			template_values = {
				'messages': forum_posts,
				'page_calcs' : page_calcs,
				'url_root' : method_url.getUrlWithoutPage(self),
				'current_sort': sort,
				'sorts': method_forum.sorts,
			}		 
	
			forum_html = self.getBody(template_values, 'html/forumlist.html')
			method_cache.setObjectForTypeAndKey(page_cache_key, str(page_num), forum_html)

		template_values = {}
		template_values['rendered_body'] = forum_html
		template_values['parent_tab'] = 'forum'
		self.pushPage(template_values, 'Forum', 'html/main.html')	
		
		