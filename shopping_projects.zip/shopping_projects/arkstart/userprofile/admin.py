from arkstart.userprofile.models import *
from django.contrib import admin

admin.site.register(Interest)
admin.site.register(Profile)
admin.site.register(MemberType)