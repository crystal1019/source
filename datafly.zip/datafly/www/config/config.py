import os
from os.path import abspath, join, dirname

CONFIG_ROOT = abspath(dirname(__file__))
# SITE ROOT - /www
SITE_ROOT = abspath(join(CONFIG_ROOT, '..'))
# one level above site
PROJECT_ROOT = abspath(join(SITE_ROOT, '..'))

class Default(object):
    """ Uncomment SYNC to download db and `static/upload` only once
        with "fab runserver" command from specified remote version """
    # SYNC = 'Production'
    CACHE_TIMESTAMP = 'Sep14-0225' 
    WEBSITE = 'DataFly'    
    MONGO = {
        'host': 'localhost',
        'port': 27017        
    }
    MANDRILL_API_KEY = 'vl9dUiOidJ_KJJRyBm9_sg'
    EMAIL = 'sean@datafly.net'
    ADMIN_USER = {
        'login': 'admin@datafly.net',
        'password': 'PyF4www2'
    }   
    DB = 'datafly'
    IMG_PREFIX = ''
    SECRET = 'EJdDcCRXHTyW8UXcQnRhWyujGWnK7Bjf4ZD68ve9Heu9tvCwacPc9zYjwJrb'
    SENTRY = {
        'Python': '',
        'JS': ''
    }  
    # add BugHerd API key, e.g. '//www.bugherd.com/sidebarv2.js?apikey=[KEY]'
    BUGHERD = None

class Production(Default):
    BASE_URL = 'http://datafly.net'

class Staging(Default):
    BASE_URL = 'http://staging.datafly.net'

class Development(Default):
    BASE_URL = 'http://127.0.0.1:8080'
    HOST = '127.0.0.1'
    PORT = 8080    

"""
    please, define class Development(Default) in myconfig.py
    with your local settings    

    myconfig.py file is not versioned by Git, however
    add a copy of yours as myconfig_name.py to Git
    (or better add a symlink `ln -s myconfig.py myconfig_name.py`)
"""

# environ variable is defined in uwsgi.ini uWSGI configuration file
config_name = os.environ.get('CONFIG', False)
if config_name:
    # Config = Production or Config = Staging
    Config = vars()[config_name]
else:        
    try:  
        import myconfig
        Config = myconfig.Development
    except ImportError:
        Config = Development