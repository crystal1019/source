import os
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template

import objects 
import method_cache
import time

page_cache_key = 'activity-rendered'

class Activity(webapp.RequestHandler):
	
	def getActivities(self):
		body = method_cache.getObjectForTypeAndKey(page_cache_key, None)
		if not body:
			activities = objects.ActivityItem.query().order(-objects.ActivityItem.date).fetch(5)
			count = 0
			for activity in activities:
				activity.index = count
				count = count + 1
			if count > 0:
				values = {"activities": activities, 'last_time': int(activities[0].timestamp)}
				path = os.path.join(os.path.dirname(__file__), "html/activity.html")
				body = template.render(path, values)		
				method_cache.setObjectForTypeAndKey(page_cache_key, None, body)
		return body			
	
	def lastUpdate(self):
		v = method_cache.getObjectForTypeAndKey('activity-rendered-last-time', None)
		if v:
			return int(v)
		else:
			return None
			
	def getRenderedActivity(self, key):
		uid = key.id()
		body = method_cache.getObjectForTypeAndKey(page_cache_key, uid)
		if not body:
			a = objects.ActivityItem.query(objects.ActivityItem._key == key).get()
			if a is None:
				a = objects.ActivityItem.query(objects.ActivityItem.uid == uid).get()
				if a is None:
					return None
			values = {'activity': a}
			path = os.path.join(os.path.dirname(__file__), "html/control-activity.html")
			body = template.render(path, values)
			
			title = ''
			image = ''
			text = ''
			url = ''
			
			if a.image_url:
				image = a.image_url
			if a.url:
				url = a.url
			
			if a.type == 'comment':
				title = a.name + ' commented...'
				text = a.subtitle
			elif a.type == 'question':
				title = a.name + ' added a question'
				text = a.subtitle
			elif a.type == 'forum':
				title = a.name + ' added a forum post'
				text = a.subtitle
			#elif a.type == 'vote':
			#	title = a.name + ' ' + a.subtype + '-voted a comment'
			#	text = a.name + ' ' + a.subtitle
				
			sub_separator ='<--><--><--><--><--><-->'
			body = body + '<-><-><-><-><-><->' + title + sub_separator + image + sub_separator + text + sub_separator + url
			
			method_cache.setObjectForTypeAndKey(page_cache_key, uid, body)
		return body
		
	def post(self):
		last_item = self.request.get('last_time')
		if last_item == '' or last_item.lower() == 'nan':
			self.response.out.write('<><><><><><>' + str(int(time.time())))
			return 
		last_update = int(last_item)				
		last_activity = self.lastUpdate()
		if last_update < last_activity and last_activity != None:
			activities = objects.ActivityItem().query(objects.ActivityItem.timestamp > last_update).order(-objects.ActivityItem.timestamp).fetch(5, keys_only = True)
			string = ''
			for activity in activities:	
				body = self.getRenderedActivity(activity)
				if body:
					string = string + body + '<><><><><><>'
			if string != '':
				string = string + str(int(time.time()))
			self.response.out.write(string)
		else:
			self.response.out.write('<><><><><><>' + str(int(time.time())))
	
	def get(self):
		body = self.getActivities()
		self.response.out.write(body)