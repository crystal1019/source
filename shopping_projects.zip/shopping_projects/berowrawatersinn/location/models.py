from django.db import models
from berowrawatersinn.website.models import CommonPage
# Create your models here.

class LocationPage(CommonPage):
    nav = '/location/'
    is_landing = models.BooleanField(default=False)
    

    def save(self,*args, **kwargs):
        if self.is_landing:
            try:
                landing = LocationPage.objects.get(is_landing=True)
                if landing.id != self.id:
                    landing.is_landing = False
                    landing.save()
            except:
                pass
            
        super(LocationPage, self).save(*args, **kwargs)