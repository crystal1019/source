"""
  copyright 2013 Lazar
"""

from fabric.api import *

def help():
    print "usage: fab [dev|prod] [deploy|restart]"

def prod():
    env.hosts = ['root@virtualsales.io']

def dev():
    env.hosts = ['root@virtualsales.io']

def deploy():
    with cd('/home/virtualsales/site'):
        run('git pull')

def restart():
    run('supervisorctl restart virtualsales')
