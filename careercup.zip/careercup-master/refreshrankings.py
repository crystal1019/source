import objects
import masterpage

import method_url
import method_user
	
class RefreshRankings(masterpage.MasterPage):				  	
	def get(self):
		userid = method_url.getIntParam(self, 'last_user')
		users = objects.UserInfo.query(objects.UserInfo.uid > userid).order(objects.UserInfo.uid).fetch(800)
		last_id = None
		
		strings = []
		strings.append('<ol>')
		
		equivalent = []
		
		for user in users:
			old_reputation = user.reputation
			method_user.refreshUserReputation(user)
			new_reputation = user.reputation
			if old_reputation != new_reputation:
				strings.append('<li><a href="/user?id=' + str(user.uid) + '">refreshed ' + str(user.uid) + ' from ' + str(old_reputation) + ' to ' + str(new_reputation) + '</a></li>')
			else:
				equivalent.append('<a href="/user?id=' + str(user.uid) + '">' + str(user.uid) + '</a>')
			last_id = user.uid
		strings.append('</ol>')
		
		s = ''.join(strings)
		self.response.out.write('<a href="/refreshrankings?last_user=' + str(last_id) + '">next</a><br/>')
		
		self.response.out.write('<br/>Same Users: ' + ', '.join(equivalent) + '<br/>')
		
		self.response.out.write(s)