import locale

from django import template
from django.db.models import Q
from django.contrib.sites.models import Site

register = template.Library()

from offers.core.models import Category, MetaField
from offers.core.utils import find_sortable_meta_field, NON_DIGIT_RE, NON_DIGIT_RE_END

CURRENT_SITE = Site.objects.get_current()

def get_cheapest(meta_key, last_month=False, q=None, cat_slug=None, is_rate=False):
    def to_float(value):
        try:
            return float(value)
        except ValueError:
            return float(value.replace('%','').replace('p.a.','').replace('-','0'
                             ).replace('months','').replace('Life','1'))
    if cat_slug is None:
        cat_slug = 'credit-cards'
    meta = MetaField.objects.filter(key=meta_key)[0]
    meta_instances = meta.meta_instances.filter(offer__category__slug=cat_slug, offer__sites=CURRENT_SITE, offer__is_active=True
        ).exclude(value='-').exclude(value=None).exclude(value='None').exclude(value='NA').exclude(value='N/A')
    if q is not None: 
        meta_instances = meta_instances.filter(q)
    cheapest = None
    longer_is_better = meta_key.find('Period')!=-1
    for field_instance in meta_instances:
        value = to_float(field_instance.value_last_month if last_month else field_instance.value)
        if is_rate:
            meta = MetaField.objects.filter(key=meta_key.replace('Rate','Period'))[0]
            period = to_float(meta.meta_instances.filter(offer=field_instance.offer)[0].value)
            if period == 0:
                continue
            elif value == 0:
                value = 0-period
            else:
                value = value/period
        if (cheapest is None or value < cheapest['meta_value']) and not longer_is_better:
            cheapest = {'offer':field_instance.offer, 'meta_value':value}
        elif (cheapest is None or value > cheapest['meta_value']) and longer_is_better:
            cheapest = {'offer':field_instance.offer, 'meta_value':value}
        elif value == cheapest['meta_value'] and meta_key != 'Purchase Rate':
            winning_offer = get_cheapest('Purchase Rate',last_month=last_month, 
                               q=Q(offer__id__in=[cheapest['offer'].id,field_instance.offer.id]))['offer']
            cheapest = {'offer':winning_offer, 'meta_value':value}
    return cheapest

def get_cheapest_cards(last_month=False):
    cheapest_balance_transfer = get_cheapest('Balance Transfer Rate', last_month=last_month, is_rate=True)
    cheapest_cash_advance = get_cheapest('Cash Advance Rate', last_month=last_month)
    cheapest_purchase = get_cheapest('Purchase Rate', last_month=last_month)
    longest_balance_transfer = get_cheapest('Balance Transfer Period', last_month=last_month)
    longest_intro_purchase = get_cheapest('Intro Purchase Period', last_month=last_month)
    
    intro_purchase = get_cheapest('Intro Purchase Rate', last_month=last_month, is_rate=True)
    if intro_purchase['meta_value'] >=0 and cheapest_purchase['meta_value'] > intro_purchase['meta_value']:
        cheapest_purchase = intro_purchase
    
    
    return   {'cheapest_balance_transfer':cheapest_balance_transfer,
              'cheapest_cash_advance':cheapest_cash_advance,
              'cheapest_purchase':cheapest_purchase,
              'longest_balance_transfer':longest_balance_transfer,
              'longest_intro_purchase':longest_intro_purchase,
              }
        
def get_meta_field_minimum(meta_field_instances):
    values = list()
    for field_instance in meta_field_instances:
        try:
            value = float(NON_DIGIT_RE_END.sub('', NON_DIGIT_RE.sub('', field_instance.value)))
        except ValueError:
            value = 0.0
        values.append(value)
    values.sort()
    if len(values) != 0:
        return values[0]
    else:
        return 0

def get_meta_field_maximum(meta_field_instances):
    values = list()
    for field_instance in meta_field_instances:
        try:
            value = float(NON_DIGIT_RE_END.sub('', NON_DIGIT_RE.sub('', field_instance.value)))
        except ValueError:
            value = 0.0
        values.append(value)
    values.sort(reverse=False)
    if len(values) != 0:
        return values[0]
    else:
        return 0

def get_meta_field_average(meta_field_instances, last_month=False):
    months_ago = int(last_month)
    num_instances = meta_field_instances.count()
    total = 0.0
    for field_instance in meta_field_instances:
        try:
            value = field_instance.get_archived_value(months_ago)
            total += float(NON_DIGIT_RE_END.sub('', NON_DIGIT_RE.sub('', value)))
        except ValueError:
            num_instances -= 1

    if num_instances > 0:
        return total / num_instances
    else:
        return 0

@register.filter(name='any_income')
def do_any_income(value):
    if value.find('$weekly')!=-1 or value.find('$Weekly')!=-1:
        return 'any ' + value.replace('$W','w').replace('$','')
    elif value.find('$any')!=-1 or value.find('$Any')!=-1:
        return value.replace('$','')
    return value

@register.filter(name='replace')
def do_replace(value, replacement):
    to_replace, replace_with = replacement.split('::')
    return value.replace(to_replace,replace_with)

@register.filter(name='expand_meta_field_data')
def do_apply_meta_field_data(value, category):
    stats = dict()
    # Get statistics for current category.
    stats['Offers in Category'] = locale.format('%d', category.offer_set.count(), True)
    for meta_field in category.sortable_meta_fields:
        meta_field_instances = meta_field.meta_instances.filter(offer__category=category, offer__sites=CURRENT_SITE).exclude(value='-').exclude(value=None).exclude(value='None').exclude(value='NA').exclude(value='N/A')
        stats['Average %s' % meta_field.key] = get_meta_field_average(meta_field_instances)
        stats['Minimum %s' % meta_field.key] = get_meta_field_minimum(meta_field_instances)
        stats['Maximum %s' % meta_field.key] = get_meta_field_maximum(meta_field_instances)

    # Get statistics for top-level category.
    top_level = category.get_top_level_parent()
    for meta_field in top_level.sortable_meta_fields:
        if top_level.pk == category.pk:
            stats['Average %s Overall' % meta_field.key] = stats['Average %s' % meta_field.key]
            stats['Minimum %s Overall' % meta_field.key] = stats['Minimum %s' % meta_field.key]
            stats['Maximum %s Overall' % meta_field.key] = stats['Maximum %s' % meta_field.key]
        else:
            meta_field_instances = meta_field.meta_instances.filter(offer__category=category, offer__sites=CURRENT_SITE).exclude(value='-').exclude(value=None).exclude(value='None').exclude(value='NA').exclude(value='N/A')
            stats['Average %s Overall' % meta_field.key] = get_meta_field_average(meta_field_instances)
            stats['Minimum %s Overall' % meta_field.key] = get_meta_field_minimum(meta_field_instances)
            stats['Maximum %s Overall' % meta_field.key] = get_meta_field_maximum(meta_field_instances)

    fields = ', '.join(stats.keys())
    stats['Available Fields'] = '*AVAILABLE META FIELDS: ' + fields + '*'
    try:
        return value % stats
    except (KeyError, ValueError, TypeError):
        return value

class OffersInCategoryNode(template.Node):
    def __init__(self, category, varname=None):
        self.category = category
        self.varname = varname

    def render(self, context):
        category = None
        if self.category[0] == self.category[-1] and self.category[0] in ('"', "'"):
            category_slug = self.category[1:-1]
            try:
                category = Category.objects.get(slug=category_slug, sites=CURRENT_SITE)
            except Category.DoesNotExist:
                pass
        else:
            try:
                category = template.Variable(self.category).resolve(context)
            except template.VariableDoesNotExist:
                pass

        if category is None:
            return '0'
        elif category.slug in ('credit-card-compare-home', 'credit-cards'):
            category = Category.objects.get(slug='credit-cards', sites=CURRENT_SITE)
            return category.offer_set.count()

        result = locale.format('%d', category.offer_set.filter(sites=CURRENT_SITE).count(), True)
        if self.varname is not None:
            context[self.varname] = result
            return ''
        else:
            return result

class IssuersInCategoryNode(template.Node):
    def __init__(self, category, varname):
        self.category = category
        self.varname = varname

    def render(self, context):
        category = None
        if self.category[0] == self.category[-1] and self.category[0] in ('"', "'"):
            category_slug = self.category[1:-1]
            try:
                category = Category.objects.get(slug=category_slug, sites=CURRENT_SITE)
            except Category.DoesNotExist:
                pass
        else:
            try:
                category = template.Variable(self.category).resolve(context)
            except template.VariableDoesNotExist:
                pass

        if category is None:
            return ''
        elif category.slug in ('credit-card-compare-home', 'credit-cards'):
            context[self.varname] = Category.on_site.filter(parent__slug='credit-card-issuers'
                                  ).exclude(slug='mastercard-credit-cards'
                                  ).exclude(slug='visa-credit-cards').count()
            return ''
        
        issuers_categories = Category.on_site.filter(parent__slug='credit-card-issuers'
              ).exclude(slug='mastercard-credit-cards').exclude(slug='visa-credit-cards')
        selected_offers = category.offer_set.filter(sites=CURRENT_SITE, is_active=True
                                           ).order_by('-outbound_link')
        selected_offers = selected_offers.filter(category__parent__slug='credit-card-issuers'
                                        ).values('id')
        
        for category in issuers_categories:
            if not category.offer_set.filter(id__in=selected_offers, is_active=True):
                issuers_categories = issuers_categories.exclude(id=category.id)
                
            
        context[self.varname] = locale.format('%d', issuers_categories.count(), True)
        return ''

class StatisticalAnalysisNode(template.Node):
    def __init__(self, category, field_name, stat_function, from_top_level=False):
        self.category = category
        self.field_name = field_name
        self.stat_function = stat_function
        self.from_top_level = from_top_level

    def render(self, context):
        category = None
        if self.category[0] == self.category[-1] and self.category[0] in ('"', "'"):
            category_slug = self.category[1:-1]
            try:
                category = Category.objects.get(slug=category_slug, sites=CURRENT_SITE)
            except Category.DoesNotExist:
                pass
        else:
            try:
                category = template.Variable(self.category).resolve(context)
            except template.VariableDoesNotExist:
                pass

        if category is None:
            return ''

        field_name = self.field_name
        if field_name[0] == field_name[-1] and field_name[0] in ('"', "'"):
            field_name = field_name[1:-1]
        else:
            field_name = template.Variable(field_name).resolve(context)

        if self.from_top_level:
            category = category.get_top_level_parent()

        meta = find_sortable_meta_field(category, field_name)

        if meta is None:
            return ''

        result = self.stat_function(meta.meta_instances.filter(offer__category=category, offer__sites=CURRENT_SITE
                ).exclude(value='-').exclude(value=None).exclude(value='None').exclude(value='NA').exclude(value='N/A'))
        if result == int(result):
            return '%d' % result
        else:
            return '%.02f' % result

class MetaFieldTooltipNode(template.Node):
    def __init__(self, meta):
        self.meta = template.Variable(meta)

    def render(self, context):
        try:
            meta = self.meta.resolve(context)
        except template.VariableDoesNotExist:
            return ''

        tooltips = meta.tooltips.filter(sites=CURRENT_SITE)
        if tooltips.count() != 0:
            return tooltips[0].text
        else:
            return ''
        
class MetaFieldValueNode(template.Node):
    def __init__(self, offer, meta):
        self.meta_key = meta.strip("'").strip('"')
        self.offer = template.Variable(offer)

    def render(self, context):
        offer = self.offer.resolve(context)
        try:
            self.meta_key = template.Variable(self.meta_key).resolve(context)
        except template.VariableDoesNotExist:
            self.meta_key = self.meta_key
        meta = offer.meta_instances.filter(meta_field__key=self.meta_key)
        try:
            return meta[0].value.strip()
        except IndexError:
            return '-'
        except AttributeError, e:
            if meta[0].value is None:
                return '-'
            raise e

@register.tag(name='meta_field_overall_minimum_value')
def do_overall_minimum_value(parser, token):
    try:
        _tag_name, category, field_name = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments.' % token.split_contents()[0]

    return StatisticalAnalysisNode(category, field_name, get_meta_field_minimum, from_top_level=True)

@register.tag(name='meta_field_overall_maximum_value')
def do_overall_maximum_value(parser, token):
    try:
        _tag_name, category, field_name = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments.' % token.split_contents()[0]

    return StatisticalAnalysisNode(category, field_name, get_meta_field_maximum, from_top_level=True)

@register.tag(name='meta_field_minimum_value')
def do_minimum_value(parser, token):
    try:
        _tag_name, category, field_name = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments.' % token.split_contents()[0]

    return StatisticalAnalysisNode(category, field_name, get_meta_field_minimum)

@register.tag(name='meta_field_maximum_value')
def do_maximum_value(parser, token):
    try:
        _tag_name, category, field_name = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 2 arguments.' % token.split_contents()[0]

    return StatisticalAnalysisNode(category, field_name, get_meta_field_maximum)

@register.tag(name='offers_in_category')
def do_offers_in_category(parser, token):
    varname = None
    try:
        _tag_name, category = token.split_contents()
    except ValueError:
        try:
            _tag_name, category, _as, varname = token.split_contents()
        except ValueError:
            raise template.TemplateSyntaxError, '%r tag requires exactly 1 or 3 argument.' % token.split_contents()[0]

    return OffersInCategoryNode(category, varname)

@register.tag(name='issuers_in_category')
def do_issuers_in_category(parser, token):
    try:
        _tag_name, category, _as, varname = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 3 argument.' % token.split_contents()[0]

    return IssuersInCategoryNode(category, varname)

@register.tag(name='metafield_tooltip')
def do_metafield_tooltip(parser, token):
    try:
        _tag_name, meta = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 1 argument.' % token.split_contents()[0]

    return MetaFieldTooltipNode(meta)

@register.tag(name='metafield_value')
def do_metafield_value(parser, token):
    try:
        _tag_name, offer, meta = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, '%r tag requires exactly 1 argument.' % token.split_contents()[0]

    return MetaFieldValueNode(offer, meta)
